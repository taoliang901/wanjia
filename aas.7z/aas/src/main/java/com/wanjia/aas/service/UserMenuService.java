package com.wanjia.aas.service;

import java.util.List;

import com.wanjia.aas.TreeDataModel;
import com.wanjia.aas.bo.UserMenuBean;

/**
 * This element is automatically generated on 16-3-3 ����4:12, do not modify. <br>
 * Service interface
 */
public interface UserMenuService  {
	

	
	public List<TreeDataModel<UserMenuBean>> getUserList(String sysCode,String userCode);
}