package com.wanjia.aas.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.aas.ProConstant;
import com.wanjia.aas.TreeDataModel;
import com.wanjia.aas.bo.UserMenuBean;
import com.wanjia.aas.service.UserMenuService;

@Controller
public class UserMenuTestController {

	@Resource(name="aas.userMenuService")
	private UserMenuService userMenuService;
	
	
	@RequestMapping("initMenu")
	@ResponseBody
	public ModelAndView init(HttpServletRequest req,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView("menu");
		List<TreeDataModel<UserMenuBean>> list = userMenuService.getUserList(ProConstant.WEBCMS_PROJECT_NAME,"wanjia");
		mv.addObject("list",list);
		return mv;
	}
}
