package com.wanjia.aas.service;

import com.wanjia.aas.TreeDataModel;
import com.wanjia.aas.bo.UserMenuBean;
import com.wanjia.aas.dao.UserMenuMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service(value = "aas.userMenuService")
@Transactional
public class UserMenuServiceImpl implements UserMenuService{
	

	private static final Logger logger = Logger
			.getLogger(UserMenuServiceImpl.class);
	
	
    @Autowired
    private UserMenuMapper userMenuMapper;

    private List<UserMenuBean> queryMenuResourceBeanByUserCode(Map<String,Object> paraMap){
		return userMenuMapper.queryMenuResourceBeanByUserCode(paraMap);
	}
	
    private List<UserMenuBean> queryParentMenuByUserCode(Map<String,Object> paraMap){
		return userMenuMapper.queryParentMenuByUserCode(paraMap);
	}

    
	public List<TreeDataModel<UserMenuBean>> getUserList(String sysCode,String userCode){
		Map<String,Object> paraMap = new HashMap<String,Object>();
		paraMap.put("sysCode", sysCode);
		paraMap.put("userCode", userCode);
		logger.info("用户："+userCode);
		logger.info("项目名称："+sysCode);
    	if(sysCode == null || sysCode.equals("") || userCode == null || userCode.equals("")){
    		return null;
    	}
		List<UserMenuBean> menuList = queryMenuResourceBeanByUserCode(paraMap);
		
		//返回树形数据结构
		TreeDataModel<UserMenuBean> rootBean = new TreeDataModel<UserMenuBean>("0","根菜单");
		List<TreeDataModel<UserMenuBean>> rootList = new ArrayList<TreeDataModel<UserMenuBean>>();

		//查询该用户所拥有的一级菜单
		List<UserMenuBean> p_List = queryParentMenuByUserCode(paraMap);
    	//一级节点list
		List<TreeDataModel<UserMenuBean>> list = new ArrayList<TreeDataModel<UserMenuBean>>();
    	TreeDataModel<UserMenuBean> p_model = null;
    	//二级节点list
    	List<TreeDataModel<UserMenuBean>> childlist = null;
    	if(p_List != null){
    		for(UserMenuBean bean:p_List){
        		p_model = new TreeDataModel<UserMenuBean>(bean.getMenuId(),bean.getName());
        		
        		p_model.setIconCls(bean.getIconUrl());
        		p_model.setAttributes(bean);
        		childlist = new ArrayList<TreeDataModel<UserMenuBean>>();
        		for(UserMenuBean bean2 : menuList){
        			if(bean2.getParentId() != null && bean.getMenuId().equals(bean2.getParentId())){
        				TreeDataModel<UserMenuBean> 
        				c_model = new TreeDataModel<UserMenuBean>(bean2.getMenuId(),bean2.getName());
        				c_model.setIconCls(bean2.getIconUrl());
        				c_model.setAttributes(bean2);
        				childlist.add(c_model);
        			}
        		}
        		p_model.setChildren(childlist);
        		list.add(p_model);
        	}
    	}
    	
    	rootBean.setChildren(list);
    	logger.info("The size of menu list..."+list!=null?list.size():"0");
    	rootList.add(rootBean);
    	return rootList;
	}
}