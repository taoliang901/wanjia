package com.wanjia.aas;

/**
 * 存放系统变量
 * @author TaoLiang
 *
 */

public class ProConstant {
    
	public static final String WEBCMS_PROJECT_NAME  = "webcms";

	public static final String BI_PROJECT_NAME  = "BI";
}
