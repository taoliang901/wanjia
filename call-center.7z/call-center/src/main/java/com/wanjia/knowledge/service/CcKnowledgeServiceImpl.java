package com.wanjia.knowledge.service;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.ht.bo.SysDict;
import com.wanjia.ht.service.SysDictService;
import com.wanjia.knowledge.bo.CcKnowledge;
import com.wanjia.knowledge.dao.CcKnowledgeMapper;
import com.wanjia.knowledge.service.CcKnowledgeService;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.poi.util.SystemOutLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-7-18 ����7:03, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class CcKnowledgeServiceImpl implements CcKnowledgeService {

	@Autowired
    private CcKnowledgeMapper ccKnowledgeMapper;

	@Autowired
	private SysDictService sysDictService;
	
	private final Object SYN = new Object();
	
    @Override
    @Transactional(readOnly=true)
    public CcKnowledge findById(Long id) {
        return (CcKnowledge)ccKnowledgeMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcKnowledge> findWithPagination(int offset, int count) {
        return (List<CcKnowledge>)ccKnowledgeMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcKnowledge> findAll() {
        return (List<CcKnowledge>)ccKnowledgeMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcKnowledge> findByEntity(CcKnowledge model) {
        return (List<CcKnowledge>)ccKnowledgeMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcKnowledge> findByEntityWithPagination(CcKnowledge model, int offset, int count) {
        return (List<CcKnowledge>)ccKnowledgeMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public CcKnowledge findOneByEntity(CcKnowledge model) {
        return (CcKnowledge)ccKnowledgeMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcKnowledge> findByProperty(String propertyName, String propertyValue) {
        return (List<CcKnowledge>)ccKnowledgeMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public CcKnowledge findOneByProperty(String propertyName, String propertyValue) {
        return (CcKnowledge)ccKnowledgeMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcKnowledge> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<CcKnowledge>)ccKnowledgeMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcKnowledge> findByProperties(Map<String, Object> map) {
        return (List<CcKnowledge>)ccKnowledgeMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(CcKnowledge model) {
        return (long)ccKnowledgeMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)ccKnowledgeMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)ccKnowledgeMapper.countByProperties(map);
    }

    @Override
    public void update(CcKnowledge model) {
        model.setModifyDate(new Date());
        ccKnowledgeMapper.update(model);
    }

    @Override
    public void insert(CcKnowledge model) {
        model.setCreateDate(new Date());
        ccKnowledgeMapper.insert(model);
    }

    @Override
    public void deleteByEntity(CcKnowledge model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        ccKnowledgeMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.ccKnowledgeMapper.countAll();
    }

    public void insertBatch(List<CcKnowledge> list) {
        this.ccKnowledgeMapper.insertBatch(list);
    }

    public void delete(Long id) {
        CcKnowledge model = new CcKnowledge();
        model.setDelFlag(SysConstant.DEL_FLAG);
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.ccKnowledgeMapper.update(model);
    }

	@Override
	public List<CcKnowledge> queryKnowledge(Map<String, Object> map) {
		return ccKnowledgeMapper.queryKnowledge(map);
	}
	
	//查询 启用的常见问题数量
	@Override
	public long countCommonNum(){
		return ccKnowledgeMapper.countCommonNum();
	}
	
	public List<CcKnowledge> selectQuestionType(){
		return ccKnowledgeMapper.selectQuestionType();
	}
	
	public long searchMaxType(){
		return ccKnowledgeMapper.searchMaxType();
	}
	
	public void saveOrUpdateType(String type_desc[],String dictKey_array[]){
		
		//先清除未使用过的问题类型数据
		sysDictService.deleteUnusedTypeByCode();
		//获取下一个dict_key
		long maxTypeId = searchMaxType();
		long nextTypeId = maxTypeId +1;
		
		for(int i = 0 ; i < type_desc.length ;i++){
			SysDict sysDict = new SysDict();
			String status = dictKey_array[i].substring(SysConstant.QUEST_TYPE_STATUS_POS.length(),SysConstant.QUEST_TYPE_STATUS_POS.length()+1);
			
			if(dictKey_array[i].contains("oldType") && status.equals("1")){
				String dictKey =  dictKey_array[i].substring(SysConstant.QUEST_TYPE_POS.length());
				//查询ID
				SysDict paramModel = new SysDict();
				paramModel.setDictCode(SysConstant.QUESTION_TYPE_DICT_CODE);
				paramModel.setDictKey(dictKey);
				paramModel = sysDictService.findOneByEntity(paramModel);

				sysDict.setId(paramModel.getId());
				sysDict.setDictKey(dictKey);     //已经在使用的字典项不能更改dict_key
				sysDict.setDictDescription(type_desc[i]);	
				sysDictService.update(sysDict);
			}else{
				sysDict.setId(UUID.randomUUID().toString());
				sysDict.setDictCode(SysConstant.QUESTION_TYPE_DICT_CODE);
				sysDict.setDictName(SysConstant.QUESTION_TYPE_DICT_NAME);
				sysDict.setDictKey(String.valueOf(nextTypeId + i)); //
				sysDict.setDictDescription(type_desc[i]);	
				sysDictService.insert(sysDict);
			}

		}
	}
	
/*	public static void main(String args[]){
		String var = "oldType#3#12";
		System.out.println(var.substring(8, 9));
		System.out.println(var.substring(10));
	}*/

	@Override
	public void createKnowledge(CcKnowledge model){
		synchronized(SYN){
			long seq = searchMaxSeq();
			model.setId(UUID.randomUUID().toString());
			model.setSeq(String.valueOf(seq+1));
			model.setIsCommonProblem("0");
			model.setDelFlag(SysConstant.NOT_DEL_FLAG);
			insert(model);
		}
	
	}
	
	@Override
	public List<CcKnowledge> getKnowledge(Map<String, Object> map) {
		return ccKnowledgeMapper.getKnowledge(map);
	}
	
	@Override
	public long searchMaxSeq(){
		return ccKnowledgeMapper.searchMaxSeq();
	}

	@Override
	public Map<String, Object> getNextKnowledge(Map<String, Object> map) {
		return ccKnowledgeMapper.getNextKnowledge(map);
	}
}