package com.wanjia.knowledge.service;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseService;
import com.wanjia.knowledge.bo.CcKnowledge;

/**
 * This element is automatically generated on 16-7-18 ����7:03, do not modify. <br>
 * Service interface
 */
public interface CcKnowledgeService extends IBaseService<CcKnowledge, Long> {
	
	/**
	 * 查询知识库 
	 * @param map
	 * @return CcKnowledge对象中包含了问题类型的描述，即typeDesc
	 */
	List<CcKnowledge> queryKnowledge(Map<String,Object> map);
	
	/**
	 * 查询知识库（不关联字典项）
	 * @param map
	 * @return
	 */
	List<CcKnowledge> getKnowledge(Map<String,Object> map);
	
	public long countCommonNum();
	
	public List<CcKnowledge> selectQuestionType();
	
	public long searchMaxType();
	
	public void saveOrUpdateType(String type_desc[],String dictKey_array[]);
	
	public void createKnowledge(CcKnowledge model);
	
	public long searchMaxSeq();
	
	/**
	 * 获取下一个问题（用于问题详情页）
	 * @param map
	 * @return
	 */
	Map<String,Object> getNextKnowledge(Map<String,Object> map);
}