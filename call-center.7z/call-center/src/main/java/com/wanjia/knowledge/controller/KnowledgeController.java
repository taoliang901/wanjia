package com.wanjia.knowledge.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.model.EasyUIDataGridModel;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.ht.bo.SysDict;
import com.wanjia.ht.service.SysDictService;
import com.wanjia.knowledge.bo.CcKnowledge;
import com.wanjia.knowledge.service.CcKnowledgeService;
import com.wanjia.utils.StringUtil;

@Controller
public class KnowledgeController extends BaseController{

	private final String knowledge_page ="knowledge/knowledgeList"; 
	
	@Autowired
	private CcKnowledgeService ccKnowledgeService;

	@Autowired
	private SysDictService sysDictService;
	
	@RequestMapping("knowledge/initList.do")
	public ModelAndView initWorkSheetMgmt(HttpServletRequest request){
		ModelAndView mv = new ModelAndView(knowledge_page);
		
		return mv;
	}
	
	@RequestMapping("knowledge/initKnowledgeHome.do")
	public String initKnowledgeHome(){
	    return "knowledge/knowledgeHome";
	}
	
	
	
	@RequestMapping("/knowledge/getKnowledgeList.do")
	@ResponseBody
	public EasyUIDataGridModel getKnowledgeList(HttpServletRequest request){
		EasyUIDataGridModel dg = new EasyUIDataGridModel();

		String pageNumber = request.getParameter("page");
		String pageSize = request.getParameter("rows");
		String type = request.getParameter("type");
		String queryParams = request.getParameter("queryParams");
		int pageNo = 1;
	 	int pageS= SysConstant.PAGE_SIZE;
	 	if(!StringUtils.isEmpty(pageNumber)){
	 		pageNo = Integer.parseInt(pageNumber);
	 	}
	 	if(!StringUtils.isEmpty(pageSize)){
	 		pageS = Integer.parseInt(pageSize);
	 	}
	 	PageHelper.startPage(pageNo,pageS );//设置分页页号和页码
	 	Map<String , Object> paramMap = new HashMap<String , Object>();
	 	paramMap.put("delFlag", SysConstant.NOT_DEL_FLAG);
	 	if(!StringUtils.isEmpty(queryParams)){
	 		paramMap.put("key", queryParams);
	 	}
	 	if(!StringUtils.isEmpty(type)){
	 		paramMap.put("type", type);
	 	}
		List<CcKnowledge> list = handleCommonQuestion(ccKnowledgeService.queryKnowledge(paramMap));
		
		PageInfo page = new PageInfo(list);
	 	dg.setTotal(page.getTotal());
	 	dg.setRows(list);
	 	
	 	return dg;
	}
	
	//当常见问题已经达到7个时，“设为常见问题”按钮隐藏。
	private List<CcKnowledge> handleCommonQuestion(List<CcKnowledge> list){
		List<CcKnowledge> result = new ArrayList<CcKnowledge>();
		long num = ccKnowledgeService.countCommonNum();
		if(num < 7 && list !=null){
			for(CcKnowledge model : list){
				model.setCommFlag("0");
				result.add(model);
			}
		}else{
			return list;
		}
		
		return result;
	}
	
	@RequestMapping("/knowledge/createKnowledge.do")
	@ResponseBody
	public JsonResponse<Void> createKnowledge(HttpServletRequest request,HttpServletResponse reponse){
		//构造返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		//获参
		String question = request.getParameter("question");
		String typeId = request.getParameter("typeId");
		String answer = request.getParameter("answer");
		String status = request.getParameter("status");
		
		//插入 
		CcKnowledge model = new CcKnowledge();	
		model.setQuestion(question);
		model.setType(typeId);
		model.setAnswer(answer);
		model.setStatus(status);
		model.setCreateUser(getCurrentUser(request));
		ccKnowledgeService.createKnowledge(model);
		
		//返回结果集
		jr.setStatus(JsonResponse.Status.SUCCESS);
		return jr;
	}
	
	@RequestMapping("/knowledge/updateKnowledge.do")
	@ResponseBody
	public JsonResponse<Void> updateKnowledge(HttpServletRequest request,HttpServletResponse reponse){
		//构造返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		//获参
		String id = request.getParameter("id");
		String question = request.getParameter("question");
		String typeId = request.getParameter("typeId");
		String answer = request.getParameter("answer");
		String status = request.getParameter("status");
		//更新
		CcKnowledge model = new CcKnowledge();
		model.setId(id);
		model.setQuestion(question);
		model.setType(typeId);
		model.setAnswer(answer);
		model.setStatus(status);
		model.setModifyUser(getCurrentUser(request));
		ccKnowledgeService.update(model);
		
		//返回结果集
		jr.setStatus(JsonResponse.Status.SUCCESS);
		return jr;
	}
	
	
	@RequestMapping("/knowledge/setCommonKnowledge.do")
	@ResponseBody
	public JsonResponse<Void> setCommonKnowledge(HttpServletRequest request,HttpServletResponse reponse){
		//构造返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		//获参
		String id = request.getParameter("id");
		String isCommon = request.getParameter("isCommon");
		//更新
		CcKnowledge model = new CcKnowledge();
		model.setId(id);
		model.setIsCommonProblem(isCommon);
		model.setModifyUser(getCurrentUser(request));
		ccKnowledgeService.update(model);
		
		//返回结果集
		jr.setStatus(JsonResponse.Status.SUCCESS);
		return jr;
	}
	
	@RequestMapping("/knowledge/delKnowledge.do")
	@ResponseBody
	public JsonResponse<Void> delKnowledge(HttpServletRequest request,HttpServletResponse reponse){
		//构造返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		//获参
		String id = request.getParameter("id");
		
		//更新
		CcKnowledge model = new CcKnowledge();
		model.setId(id);
		model.setDelFlag(SysConstant.DEL_FLAG);
		model.setModifyUser(getCurrentUser(request));
		ccKnowledgeService.update(model);
		
		//返回结果集
		jr.setStatus(JsonResponse.Status.SUCCESS);
		return jr;
	}
	
	/**
	 * 
	 * 保存问题类别 
	 * */
	@RequestMapping("/knowledge/saveOrUpdateType.do")
	@ResponseBody
	public JsonResponse<Void> saveOrUpdateType(HttpServletRequest request,HttpServletResponse reponse){
		//构造返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		//获参
		String typeNames = request.getParameter("typeNames");
		String type_desc[] = StringUtil.splitString(typeNames,",");
		
		String typeId_array = request.getParameter("typeId_array");
		String dictKey_array[] = StringUtil.splitString(typeId_array,",");
			
		ccKnowledgeService.saveOrUpdateType(type_desc,dictKey_array);
		
		//返回结果集
		jr.setStatus(JsonResponse.Status.SUCCESS);
		return jr;
	}
	

	
	@RequestMapping("/knowledge/initTypeList.do")
	@ResponseBody
	public List<SysDict> initTypeList(HttpServletRequest request){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dictCode",SysConstant.QUESTION_TYPE_DICT_CODE);
		List<SysDict> list = sysDictService.findByProperties(map);
		return list;
	}
	
	@RequestMapping("/knowledge/getExistingQuestionType.do")
	@ResponseBody
	public List<SysDict> getExistingQuestionType(HttpServletRequest request){
		
		List<SysDict> resultList = new ArrayList<SysDict>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dictCode",SysConstant.QUESTION_TYPE_DICT_CODE);
		List<SysDict> dictList = sysDictService.findByProperties(map);
		List<CcKnowledge> typeList = ccKnowledgeService.selectQuestionType();
		if(dictList !=null && typeList !=null){
			for(SysDict sysDict : dictList){
				
				for(CcKnowledge ccKnowledge : typeList){
					if(sysDict.getDictKey().equals(ccKnowledge.getType())) {
						//说明此类型正在使用，不能删除
						sysDict.setStatus("1");
					}
				}
				resultList.add(sysDict);
			}
		}
		
		return resultList;
	}
	
}
