package com.wanjia.knowledge.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseDao;
import com.wanjia.knowledge.bo.CcKnowledge;

public interface CcKnowledgeMapper extends IBaseDao {
	
	public long countCommonNum();
	
	public List<CcKnowledge> queryKnowledge(Map<String,Object> map);
	
	public List<CcKnowledge> selectQuestionType();
	
	public long searchMaxType();
	
	public List<CcKnowledge> getKnowledge(Map<String,Object> map);
	
	public long searchMaxSeq();
	
	public Map<String,Object> getNextKnowledge(Map<String,Object> map);
}