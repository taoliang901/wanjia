package com.wanjia.knowledge.enums;

/**
 * 坐席问题状态枚举类
 * @author QIANXIN510
 *
 */
public enum KnowledgeStatus {
	
	ENABLE("ENABLE", "1", "启用"), DISABLE("DISABLE", "0", "停用");
	
	private String code;
    private String value;
    private String desc;
    
	private KnowledgeStatus(String code, String value, String desc) {
		this.code = code;
		this.value = value;
		this.desc = desc;
	}
    
    public static KnowledgeStatus getKnowledgeStatus(String value){
   	 for (KnowledgeStatus c : KnowledgeStatus.values()) {
            if (c.getValue().equals(value) ) {
                return c;
            }
        }
   	 return null;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
