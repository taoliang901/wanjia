package com.wanjia.knowledge.service.impl;

import com.wanjia.common.utils.ThreadLocalContext;
import com.wanjia.knowledge.bo.CcSurveyOption;
import com.wanjia.knowledge.dao.CcSurveyOptionMapper;
import com.wanjia.knowledge.service.CcSurveyOptionService;

import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-8-5 上午11:27, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class CcSurveyOptionServiceImpl implements CcSurveyOptionService {
    @Autowired
    private CcSurveyOptionMapper ccSurveyOptionMapper;

    @Override
    @Transactional(readOnly=true)
    public CcSurveyOption findById(String id) {
        return (CcSurveyOption)ccSurveyOptionMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveyOption> findWithPagination(int offset, int count) {
        return (List<CcSurveyOption>)ccSurveyOptionMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveyOption> findAll() {
        return (List<CcSurveyOption>)ccSurveyOptionMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveyOption> findByEntity(CcSurveyOption model) {
        return (List<CcSurveyOption>)ccSurveyOptionMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveyOption> findByEntityWithPagination(CcSurveyOption model, int offset, int count) {
        return (List<CcSurveyOption>)ccSurveyOptionMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public CcSurveyOption findOneByEntity(CcSurveyOption model) {
        return (CcSurveyOption)ccSurveyOptionMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveyOption> findByProperty(String propertyName, String propertyValue) {
        return (List<CcSurveyOption>)ccSurveyOptionMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public CcSurveyOption findOneByProperty(String propertyName, String propertyValue) {
        return (CcSurveyOption)ccSurveyOptionMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveyOption> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<CcSurveyOption>)ccSurveyOptionMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveyOption> findByProperties(Map<String, Object> map) {
        return (List<CcSurveyOption>)ccSurveyOptionMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(CcSurveyOption model) {
        return (long)ccSurveyOptionMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)ccSurveyOptionMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)ccSurveyOptionMapper.countByProperties(map);
    }

    @Override
    public void update(CcSurveyOption model) {
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        ccSurveyOptionMapper.update(model);
    }

    @Override
    public void insert(CcSurveyOption model) {
        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        ccSurveyOptionMapper.insert(model);
    }

    @Override
    public void deleteByEntity(CcSurveyOption model) {
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        ccSurveyOptionMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.ccSurveyOptionMapper.countAll();
    }

    public void insertBatch(List<CcSurveyOption> list) {
        this.ccSurveyOptionMapper.insertBatch(list);
    }

    public void delete(String id) {
        CcSurveyOption model = new CcSurveyOption();
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.ccSurveyOptionMapper.update(model);
    }
}