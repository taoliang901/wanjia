package com.wanjia.knowledge.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseDao;
import com.wanjia.knowledge.bo.CcSurveySubject;
import com.wanjia.knowledge.bo.SurveySubjectModel;

public interface CcSurveySubjectMapper extends IBaseDao<CcSurveySubject,String> {

    public List<SurveySubjectModel> findSubjectModelBySurveyId(String surveyId);
    
    List<SurveySubjectModel> getSubjectBySurvey(Map<String,Object> map);
}