package com.wanjia.knowledge.bo;

import java.util.List;

public class SurveySubjectModel extends CcSurveySubject{
    /**
     * 
     */
    private static final long serialVersionUID = 6740197517237407087L;
    
    private List<CcSurveyOption> surveyOptionList;

    private String pfCount;
    
    private int choiceNumber;
    
    public int getChoiceNumber() {
        return choiceNumber;
    }

    public void setChoiceNumber(int choiceNumber) {
        this.choiceNumber = choiceNumber;
    }

    public List<CcSurveyOption> getSurveyOptionList() {
        return surveyOptionList;
    }

    public void setSurveyOptionList(List<CcSurveyOption> surveyOptionList) {
        this.surveyOptionList = surveyOptionList;
    }

	public String getPfCount() {
		return pfCount;
	}

	public void setPfCount(String pfCount) {
		this.pfCount = pfCount;
	}
}
