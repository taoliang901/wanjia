package com.wanjia.knowledge.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.utils.ThreadLocalContext;
import com.wanjia.knowledge.bo.CcSurveySubject;
import com.wanjia.knowledge.bo.SurveySubjectModel;
import com.wanjia.knowledge.dao.CcSurveySubjectMapper;
import com.wanjia.knowledge.service.CcSurveySubjectService;

/**
 * This element is automatically generated on 16-8-5 上午11:40, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class CcSurveySubjectServiceImpl implements CcSurveySubjectService {
    @Autowired
    private CcSurveySubjectMapper ccSurveySubjectMapper;

    @Override
    @Transactional(readOnly=true)
    public CcSurveySubject findById(String id) {
        return (CcSurveySubject)ccSurveySubjectMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveySubject> findWithPagination(int offset, int count) {
        return (List<CcSurveySubject>)ccSurveySubjectMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveySubject> findAll() {
        return (List<CcSurveySubject>)ccSurveySubjectMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveySubject> findByEntity(CcSurveySubject model) {
        return (List<CcSurveySubject>)ccSurveySubjectMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveySubject> findByEntityWithPagination(CcSurveySubject model, int offset, int count) {
        return (List<CcSurveySubject>)ccSurveySubjectMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public CcSurveySubject findOneByEntity(CcSurveySubject model) {
        return (CcSurveySubject)ccSurveySubjectMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveySubject> findByProperty(String propertyName, String propertyValue) {
        return (List<CcSurveySubject>)ccSurveySubjectMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public CcSurveySubject findOneByProperty(String propertyName, String propertyValue) {
        return (CcSurveySubject)ccSurveySubjectMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveySubject> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<CcSurveySubject>)ccSurveySubjectMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurveySubject> findByProperties(Map<String, Object> map) {
        return (List<CcSurveySubject>)ccSurveySubjectMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(CcSurveySubject model) {
        return (long)ccSurveySubjectMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)ccSurveySubjectMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)ccSurveySubjectMapper.countByProperties(map);
    }

    @Override
    public void update(CcSurveySubject model) {
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        ccSurveySubjectMapper.update(model);
    }

    @Override
    public void insert(CcSurveySubject model) {
        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        ccSurveySubjectMapper.insert(model);
    }

    @Override
    public void deleteByEntity(CcSurveySubject model) {
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        ccSurveySubjectMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.ccSurveySubjectMapper.countAll();
    }

    public void insertBatch(List<CcSurveySubject> list) {
        this.ccSurveySubjectMapper.insertBatch(list);
    }

    public void delete(String id) {
        CcSurveySubject model = new CcSurveySubject();
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.ccSurveySubjectMapper.update(model);
    }

	@Override
	public List<SurveySubjectModel> getSubjectBySurvey(Map<String, Object> map) {
		return ccSurveySubjectMapper.getSubjectBySurvey(map);
	}
}