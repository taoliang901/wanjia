package com.wanjia.knowledge.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueProcess;
import com.wanjia.issue.dao.IssueMapper;
import com.wanjia.issue.dao.IssueProcessMapper;
import com.wanjia.issue.enums.IssueStatus;
import com.wanjia.knowledge.bo.SurveyAnswer;
import com.wanjia.knowledge.dao.SurveyAnswerMapper;
import com.wanjia.knowledge.service.SurveyAnswerService;

/**
 * This element is automatically generated on 16-8-7 下午4:38, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class SurveyAnswerServiceImpl implements SurveyAnswerService {
    @Autowired
    private SurveyAnswerMapper surveyAnswerMapper;
    @Autowired
    private IssueMapper issueMapper;
    @Autowired
    private IssueProcessMapper issueProcessMapper;
    
    @Override
    @Transactional(readOnly=true)
    public SurveyAnswer findById(String id) {
        return (SurveyAnswer)surveyAnswerMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SurveyAnswer> findWithPagination(int offset, int count) {
        return (List<SurveyAnswer>)surveyAnswerMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SurveyAnswer> findAll() {
        return (List<SurveyAnswer>)surveyAnswerMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<SurveyAnswer> findByEntity(SurveyAnswer model) {
        return (List<SurveyAnswer>)surveyAnswerMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SurveyAnswer> findByEntityWithPagination(SurveyAnswer model, int offset, int count) {
        return (List<SurveyAnswer>)surveyAnswerMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public SurveyAnswer findOneByEntity(SurveyAnswer model) {
        return (SurveyAnswer)surveyAnswerMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SurveyAnswer> findByProperty(String propertyName, String propertyValue) {
        return (List<SurveyAnswer>)surveyAnswerMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public SurveyAnswer findOneByProperty(String propertyName, String propertyValue) {
        return (SurveyAnswer)surveyAnswerMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SurveyAnswer> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<SurveyAnswer>)surveyAnswerMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SurveyAnswer> findByProperties(Map<String, Object> map) {
        return (List<SurveyAnswer>)surveyAnswerMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(SurveyAnswer model) {
        return (long)surveyAnswerMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)surveyAnswerMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)surveyAnswerMapper.countByProperties(map);
    }

    @Override
    public void update(SurveyAnswer model) {
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        surveyAnswerMapper.update(model);
    }

    @Override
    public void insert(SurveyAnswer model) {
//        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        surveyAnswerMapper.insert(model);
    }

    @Override
    public void deleteByEntity(SurveyAnswer model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        surveyAnswerMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.surveyAnswerMapper.countAll();
    }

    public void insertBatch(List<SurveyAnswer> list) {
        this.surveyAnswerMapper.insertBatch(list);
    }

    public void delete(String id) {
        SurveyAnswer model = new SurveyAnswer();
        model.setDelFlag(SysConstant.DEL_FLAG);
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(id);
        this.surveyAnswerMapper.update(model);
    }

	@Override
	public void insertAnswers(List<SurveyAnswer> list) {
		if(list!=null && !list.isEmpty()){
			//保存答案
			for(SurveyAnswer sa : list){
				surveyAnswerMapper.insert(sa);
			}
			
			//更新工单状态
			String issueId = list.get(0).getIssueId();
			Issue issue = (Issue) issueMapper.findById(issueId);
			if(issue!=null){
				if(issue.getHandler()==null || "".equals(issue.getHandler())){
					String handler = list.get(0).getCreateUser();
					issue.setModifyUser(handler);
					issue.setHandler(handler);
				}else{
					issue.setModifyUser(issue.getHandler());
				}
				issue.setCallTime(new Date());
				issue.setStatus(IssueStatus.SOLVED.getValue());
				issue.setModifyDate(new Date());
				issueMapper.update(issue);
			}
			
			//记录流水
			Map<String,Object> map = new HashMap<String, Object>();
			map.put("issueId", issueId);
			map.put("delFlag", SysConstant.NOT_DEL_FLAG);
			List<IssueProcess> ipList = issueProcessMapper.findByProperties(map);
			if(ipList!=null && !ipList.isEmpty()){
				IssueProcess process = ipList.get(0);
				process.setStatus(IssueStatus.SOLVED.getValue());
				issueProcessMapper.update(process);
			}else{
				//没有流水，表示直接从领取页面直接呼出
				IssueProcess issueProcess = new IssueProcess();
				issueProcess.setId(UUID.randomUUID().toString());
				issueProcess.setIssueId(issue.getId());
				issueProcess.setAssignee(issue.getHandler());
				issueProcess.setAssignDate(new Date());
				issueProcess.setDelFlag(SysConstant.NOT_DEL_FLAG);
				issueProcess.setCreateDate(new Date());
				issueProcess.setCreateUser(issue.getCreateUser());
				issueProcess.setStatus(IssueStatus.SOLVED.getValue());
				issueProcessMapper.insert(issueProcess);
			}
		}
	}
}