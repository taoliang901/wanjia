package com.wanjia.knowledge.service;

import java.util.List;

import com.wanjia.base.IBaseService;
import com.wanjia.knowledge.bo.SurveyAnswer;

/**
 * This element is automatically generated on 16-8-7 ����4:32, do not modify. <br>
 * Service interface
 */
public interface SurveyAnswerService extends IBaseService<SurveyAnswer, String> {
	void insertAnswers(List<SurveyAnswer> list);
}