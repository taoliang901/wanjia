package com.wanjia.knowledge.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.ThreadLocalContext;
import com.wanjia.ht.bo.SysDict;
import com.wanjia.ht.dao.SysDictMapper;
import com.wanjia.ht.service.SysDictService;
import com.wanjia.knowledge.bo.CcSurvey;
import com.wanjia.knowledge.bo.CcSurveyOption;
import com.wanjia.knowledge.bo.CcSurveySubject;
import com.wanjia.knowledge.bo.SurveyModel;
import com.wanjia.knowledge.bo.SurveySubjectModel;
import com.wanjia.knowledge.dao.CcSurveyMapper;
import com.wanjia.knowledge.dao.CcSurveyOptionMapper;
import com.wanjia.knowledge.dao.CcSurveySubjectMapper;
import com.wanjia.knowledge.service.CcSurveyService;

/**
 * This element is automatically generated on 16-8-5 上午11:17, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class CcSurveyServiceImpl implements CcSurveyService {
    
    private Logger logger = LoggerFactory.getLogger(CcSurveyServiceImpl.class);
    
    @Autowired
    private CcSurveyMapper ccSurveyMapper;
    
    @Autowired
    private CcSurveySubjectMapper ccSurveySubjectMapper;
    
    @Autowired
    private CcSurveyOptionMapper ccSurveyOptionMapper;
    
    @Autowired
    private SysDictService sysDictService;
    
    @Autowired
    private SysDictMapper sysDictMapper;
    
    @Override
    @Transactional(readOnly=true)
    public CcSurvey findById(String id) {
        return (CcSurvey)ccSurveyMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findWithPagination(int offset, int count) {
        return (List<CcSurvey>)ccSurveyMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findAll() {
        return (List<CcSurvey>)ccSurveyMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByEntity(CcSurvey model) {
        return (List<CcSurvey>)ccSurveyMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByEntityWithPagination(CcSurvey model, int offset, int count) {
        return (List<CcSurvey>)ccSurveyMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public CcSurvey findOneByEntity(CcSurvey model) {
        return (CcSurvey)ccSurveyMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByProperty(String propertyName, String propertyValue) {
        return (List<CcSurvey>)ccSurveyMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public CcSurvey findOneByProperty(String propertyName, String propertyValue) {
        return (CcSurvey)ccSurveyMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<CcSurvey>)ccSurveyMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByProperties(Map<String, Object> map) {
        return (List<CcSurvey>)ccSurveyMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(CcSurvey model) {
        return (long)ccSurveyMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)ccSurveyMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)ccSurveyMapper.countByProperties(map);
    }

    @Override
    public void update(CcSurvey model) {
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        ccSurveyMapper.update(model);
    }

    @Override
    public void insert(CcSurvey model) {
        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        ccSurveyMapper.insert(model);
    }

    @Override
    public void deleteByEntity(CcSurvey model) {
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        ccSurveyMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.ccSurveyMapper.countAll();
    }

    public void insertBatch(List<CcSurvey> list) {
        this.ccSurveyMapper.insertBatch(list);
    }

    public void delete(String id) {
        CcSurvey model = new CcSurvey();
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.ccSurveyMapper.update(model);
    }
    
    @Override
    public JsonResponse<Void> deleteSurvey(HttpServletRequest request,String userName){
        
        JsonResponse<Void> jr = new JsonResponse<Void>();
        
        String surveyId = request.getParameter("surveyId");
        
        CcSurvey ccSurvey = ccSurveyMapper.findById(surveyId);
        
        if(ccSurvey != null){
            ccSurvey.setDelFlag("1");
            ccSurvey.setModifyDate(new Date());
            ccSurvey.setModifyUser(userName);
            ccSurveyMapper.update(ccSurvey);
        }else{
            jr.setSuccessMsg("无法找到该调研问卷");
        }
        
        /*--start 删除题目--*/
        Map<String,Object> subjectMap = new HashMap<String,Object>();
        subjectMap.put("delFlag", "0");
        subjectMap.put("surveyId", surveyId);
        List<CcSurveySubject> ccSurveySubjectList = ccSurveySubjectMapper.findByProperties(subjectMap);
        for(CcSurveySubject ccSurveySubject : ccSurveySubjectList){
            ccSurveySubject.setDelFlag("1");
            ccSurveySubject.setModifyDate(new Date());
            ccSurveySubject.setModifyUser(userName);
            ccSurveySubjectMapper.update(ccSurveySubject);
            
            /*--start 删除选项--*/
            Map<String,Object> optionMap = new HashMap<String,Object>();
            optionMap.put("delFlag", "0");
            optionMap.put("subjectId", ccSurveySubject.getId());
            List<CcSurveyOption> optionList = ccSurveyOptionMapper.findByProperties(optionMap);
            
            for(CcSurveyOption ccSurveyOption : optionList){
                ccSurveyOption.setDelFlag("1");
                ccSurveyOption.setModifyDate(new Date());
                ccSurveyOption.setModifyUser(userName);
                ccSurveyOptionMapper.update(ccSurveyOption);
            }
            /*--end 删除选项--*/
        }
        /*--end 删除题目--*/
        
        jr.setSuccessMsg("提交成功");
        return jr;
    }
    
    @Override
    public JsonResponse<Void> saveSurvey(HttpServletRequest request,String userName){
        
        JsonResponse<Void> jr = new JsonResponse<Void>();
        
        String survey = request.getParameter("surveyModel");
        
        JSONObject jsonObject = JSONObject.parseObject(survey);
        
        /*--start 插入调查问卷--*/
        CcSurvey ccSurvey = new CcSurvey();
        
        long surveyConut = ccSurveyMapper.countAll();
        
        String surveyId = jsonObject.getString("surveyId");
        String surveyName = jsonObject.getString("surveyName");
        String surveyType = jsonObject.getString("surveyType");
        String surveyUUID = UUID.randomUUID().toString();
        String surveyStatus = jsonObject.getString("surveyStatus");
        
        ccSurvey.setSurveyName(surveyName);
        ccSurvey.setSurveyType(surveyType);
        ccSurvey.setModifyDate(new Date());
        ccSurvey.setModifyUser(userName);
        ccSurvey.setSurveyStatus(surveyStatus);
        
        ccSurvey.setDelFlag("0");
        
        if(StringUtils.isEmpty(surveyId)){
            String surveySequence = String.valueOf(surveyConut+1);
            ccSurvey.setSurveySequence(surveySequence);
            ccSurvey.setId(surveyUUID);
            ccSurvey.setCreateDate(new Date());
            ccSurvey.setCreateUser(userName);
            ccSurveyMapper.insert(ccSurvey);
        }else{
            ccSurvey.setId(surveyId);
            ccSurveyMapper.update(ccSurvey);
            
            Map<String,Object> oldSurveySubjectMap = new HashMap<String,Object>();
            oldSurveySubjectMap.put("surveyId", surveyId);
            oldSurveySubjectMap.put("delFlag", "0");
            List<CcSurveySubject> oldSurveySubject = ccSurveySubjectMapper.findByProperties(oldSurveySubjectMap);
            for(CcSurveySubject old : oldSurveySubject){
                old.setDelFlag("1");
                ccSurveySubjectMapper.update(old);
                
                Map<String,Object> oldSurveyOptionMap = new HashMap<String,Object>();
                oldSurveyOptionMap.put("subjectId", old.getId());
                oldSurveyOptionMap.put("delFlag", "0");
                List<CcSurveyOption> oldSurveyOption = ccSurveyOptionMapper.findByProperties(oldSurveyOptionMap);
                for(CcSurveyOption oldOption : oldSurveyOption){
                    oldOption.setDelFlag("0");
                    ccSurveyOptionMapper.update(oldOption);
                }
            }
        }
        /*--end 插入调查问卷--*/
        
        
        
        List<CcSurveySubject> subjectList = new ArrayList<CcSurveySubject>();
        JSONArray surveySubjectList = jsonObject.getJSONArray("surveySubjectList");
        for(int i=0;i<surveySubjectList.size();i++){
            CcSurveySubject ccSurveySubject = new CcSurveySubject();
            
            String subjectName = surveySubjectList.getJSONObject(i).getString("subjectName");
            String subjectSequence = surveySubjectList.getJSONObject(i).getString("subjectSequence");
            String subjectType = surveySubjectList.getJSONObject(i).getString("subjectType");
            String subjectUUID = UUID.randomUUID().toString();
            String rank = surveySubjectList.getJSONObject(i).getString("rank");
            String minChoose = surveySubjectList.getJSONObject(i).getString("minChoose");
            String maxChoose = surveySubjectList.getJSONObject(i).getString("maxChoose");
            
            ccSurveySubject.setId(subjectUUID);
            if(StringUtils.isEmpty(surveyId)){
                ccSurveySubject.setSurveyId(surveyUUID);
            }else{
                ccSurveySubject.setSurveyId(surveyId);
            }
            
            if("02".equals(subjectType)){//多选题
                ccSurveySubject.setMinChoose(minChoose);
                ccSurveySubject.setMaxChoose(maxChoose);
            }
            
            if("03".equals(subjectType)){//评分题
                ccSurveySubject.setRank(rank);
            }
            
            ccSurveySubject.setSubjectType(subjectType);
            ccSurveySubject.setSubjectName(subjectName);
            ccSurveySubject.setSubjectSequence(subjectSequence);
            ccSurveySubject.setCreateDate(new Date());
            ccSurveySubject.setCreateUser(userName);
            ccSurveySubject.setModifyDate(new Date());
            ccSurveySubject.setModifyUser(userName);
            ccSurveySubject.setIsRequired("0");
            ccSurveySubject.setDelFlag("0");
            subjectList.add(ccSurveySubject);
        }
        
        List<CcSurveyOption> optionList = new ArrayList<CcSurveyOption>();
        for(int i=0;i<surveySubjectList.size();i++){
            JSONArray surveyOptionList = surveySubjectList.getJSONObject(i).getJSONArray("surveyOptionList");
            String subjectType = surveySubjectList.getJSONObject(i).getString("subjectType");
            String subjectId = subjectList.get(i).getId();
                switch(subjectType){
                    case "01" : 
                        for(int j=0;j<surveyOptionList.size();j++){
                            String optionUUID = UUID.randomUUID().toString();
                            CcSurveyOption ccSurveyOption = new CcSurveyOption();
                            String optionName = surveyOptionList.getJSONObject(j).getString("optionName");
                            String optionSequence = surveyOptionList.getJSONObject(j).getString("optionSequence");
                            String nextSubjectId = surveyOptionList.getJSONObject(j).getString("nextSubjectId");
                            
                            if(StringUtils.isNotEmpty(nextSubjectId)){
                                if(!("next".equals(nextSubjectId)||"over".equals(nextSubjectId))){
                                    int nextSubject = Integer.parseInt(nextSubjectId);
                                    nextSubjectId = subjectList.get(nextSubject).getId();
                                }
                                ccSurveyOption.setNextSubjectId(nextSubjectId);
                            }
                            
                            ccSurveyOption.setId(optionUUID);
                            ccSurveyOption.setSubjectId(subjectId);
                            ccSurveyOption.setCreateDate(new Date());
                            ccSurveyOption.setCreateUser(userName);
                            ccSurveyOption.setModifyDate(new Date());
                            ccSurveyOption.setModifyUser(userName);
                            ccSurveyOption.setOptionName(optionName);
                            ccSurveyOption.setOptionSequence(optionSequence);
                            ccSurveyOption.setDelFlag("0");
                            
                            optionList.add(ccSurveyOption);
                        }
                        break;
                    case "02" :
                        for(int j=0;j<surveyOptionList.size();j++){
                            String optionUUID = UUID.randomUUID().toString();
                            CcSurveyOption ccSurveyOption = new CcSurveyOption();
                            String optionName = surveyOptionList.getJSONObject(j).getString("optionName");
                            String optionSequence = surveyOptionList.getJSONObject(j).getString("optionSequence");
                            
                            ccSurveyOption.setId(optionUUID);
                            ccSurveyOption.setSubjectId(subjectId);
                            ccSurveyOption.setCreateDate(new Date());
                            ccSurveyOption.setCreateUser(userName);
                            ccSurveyOption.setModifyDate(new Date());
                            ccSurveyOption.setModifyUser(userName);
                            ccSurveyOption.setOptionName(optionName);
                            ccSurveyOption.setOptionSequence(optionSequence);
                            ccSurveyOption.setDelFlag("0");
                            
                            optionList.add(ccSurveyOption);
                        }
                        break;
                    case "03" :
                        for(int j=0;j<surveyOptionList.size();j++){
                            String optionUUID = UUID.randomUUID().toString();
                            CcSurveyOption ccSurveyOption = new CcSurveyOption();
                            String minValue = surveyOptionList.getJSONObject(j).getString("minValue");
                            String maxValue = surveyOptionList.getJSONObject(j).getString("maxValue");
                            String optionSequence = surveyOptionList.getJSONObject(j).getString("optionSequence");
                            
                            ccSurveyOption.setId(optionUUID);
                            ccSurveyOption.setSubjectId(subjectId);
                            ccSurveyOption.setCreateDate(new Date());
                            ccSurveyOption.setCreateUser(userName);
                            ccSurveyOption.setModifyDate(new Date());
                            ccSurveyOption.setModifyUser(userName);
                            ccSurveyOption.setOptionSequence(optionSequence);
                            ccSurveyOption.setMaxValue(maxValue);
                            ccSurveyOption.setMinValue(minValue);
                            ccSurveyOption.setDelFlag("0");
                            
                            optionList.add(ccSurveyOption);
                        }
                        break;
                }
        }
        if(subjectList.size()>0){
            ccSurveySubjectMapper.insertBatch(subjectList);
        }
        
        if(optionList.size()>0){
            ccSurveyOptionMapper.insertBatch(optionList);
        }

        jr.setStatus(JsonResponse.Status.SUCCESS);
        jr.setSuccessMsg("提交成功！");
        
        return jr;
    }
    
    @Override
    public ModelAndView viewSurvey(HttpServletRequest request) throws Exception{
        ModelAndView mv = new ModelAndView();
        
        String surveyId = request.getParameter("surveyId");
        String btnType = request.getParameter("btnType");
        
        List<SysDict> surveyTypeList = new ArrayList<SysDict>();
        SurveyModel surveyModel = null;
        List<SurveySubjectModel> ccSurveySubjectModelList = null;
        
        if(StringUtils.isNotEmpty(surveyId)){
            surveyModel = ccSurveyMapper.findSurveyModelBySurveyId(surveyId);
            
            ccSurveySubjectModelList = ccSurveySubjectMapper.findSubjectModelBySurveyId(surveyId);
            
            for(int i=0;i<ccSurveySubjectModelList.size();i++){
                List<CcSurveyOption> ccSurveyOptionList = ccSurveyOptionMapper.findOptionOrderBySequence(ccSurveySubjectModelList.get(i).getId());
                ccSurveySubjectModelList.get(i).setSurveyOptionList(ccSurveyOptionList);
                ccSurveySubjectModelList.get(i).setChoiceNumber(ccSurveyOptionList.size());
            }
            if(ccSurveySubjectModelList != null){
                surveyModel.setSurveySubjectList(ccSurveySubjectModelList);
            }
            
        }
        
        surveyTypeList = sysDictMapper.findByProperty("DICT_CODE", "SURVEY_TYPE");
        
        mv.setViewName("knowledge/knowledgeSurvey/knowledgeSurveyEdit");
        
        mv.addObject("btnType", btnType);
        mv.addObject("surveyTypeList", surveyTypeList);
        mv.addObject("ccSurveySubjectModelList", ccSurveySubjectModelList);
        mv.addObject("surveyModel", surveyModel);
        return mv;
        
    }
    
    @Override
    public List<CcSurvey> findSurveyList(Map<String,Object> map){
        return ccSurveyMapper.findSurveyList(map);
    }
    
    @Override
    public JsonResponse<Void> saveOrUpdateType(String type_desc[],String dictKey_array[]){
        
        sysDictMapper.deleteUnusedSurveyTypeByCode();
        
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("dictCode","SURVEY_TYPE");
        List<SysDict> sysDictList= sysDictService.findByProperties(map);
        
        int i = 0;
        for(String type:type_desc){
            boolean flag = true;
            for(SysDict sysDict:sysDictList){
                if(type.equals(sysDict.getDictDescription())){
                    flag = false;
                    continue;
                }
            }
            if(flag){
                i++;
                SysDict sd = new SysDict();
                sd.setId(UUID.randomUUID().toString());
                sd.setDictCode("SURVEY_TYPE");
                sd.setDictName("调研问卷分类");
                sd.setDictKey(String.valueOf(sysDictList.size()+i));
                sd.setDictDescription(type);
                sysDictMapper.insert(sd);
            }
        }
        
        JsonResponse<Void> jr = new JsonResponse<Void>();
        jr.setSuccessMsg("提交成功");
        return jr;
    }
    
    @Override
    public List<String> selectSurveyType(){
        return ccSurveyMapper.selectSurveyType();
    }

	@Override
	public JsonResponse<Void> updateAbnormalSurvey(HttpServletRequest request,String userName) {
		JsonResponse<Void> jr = new JsonResponse<Void>();
        
		String surveyId = request.getParameter("id");
        String prdTypeId = request.getParameter("prdTypeId");
        String issueType = request.getParameter("issueType");
        
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("issueType", issueType);
        map.put("prdTypeId", prdTypeId);
        map.put("delFlag", "0");
        List<CcSurvey> issueSurveyList = ccSurveyMapper.findByProperties(map);
        
        if(null != issueSurveyList&&issueSurveyList.size()>0){
            for(CcSurvey ccSurvey : issueSurveyList){
                ccSurvey.setPrdTypeId(" ");
                ccSurvey.setIssueType(" ");
                ccSurvey.setModifyDate(new Date());
                ccSurvey.setModifyUser(userName);
                ccSurveyMapper.update(ccSurvey);
            }
        }
        
        CcSurvey ccSurvey = ccSurveyMapper.findById(surveyId);
        if(null != ccSurvey){
            ccSurvey.setPrdTypeId(prdTypeId);
            ccSurvey.setIssueType(issueType);
            ccSurvey.setModifyDate(new Date());
            ccSurvey.setModifyUser(userName);
            ccSurveyMapper.update(ccSurvey);
        }else{
            jr.setStatus(Status.ERROR);
            jr.setErrorMsg("提交失败，请稍后再试");
            logger.error("此调查问卷无法找到，请稍后再试");
        }
        
        jr.setStatus(Status.SUCCESS);
        jr.setSuccessMsg("提交成功");
        return jr;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}