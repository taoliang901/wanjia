package com.wanjia.knowledge.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.model.EasyUIDataGridModel;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.ht.bo.SysDict;
import com.wanjia.ht.service.SysDictService;
import com.wanjia.knowledge.bo.CcSurvey;
import com.wanjia.knowledge.service.CcSurveyService;
import com.wanjia.product.bo.PrdType;
import com.wanjia.product.service.PrdTypeService;
import com.wanjia.utils.StringUtil;

@Controller
public class KnowledgeSurveyController extends BaseController {
	
	private static Logger logger = LoggerFactory.getLogger(KnowledgeSurveyController.class);
	
	@Autowired
	private SysDictService sysDictService;
	
	@Autowired
	private CcSurveyService ccSurveyService;
	
    @Autowired
    private PrdTypeService prdTypeService;
	
	@RequestMapping("knowledge/knowledgeSurvey/knowledgeSurveyList.do")
	public String initKnowledgeSurveyList(HttpServletRequest request,HttpServletResponse response){
		return "knowledge/knowledgeSurvey/knowledgeSurveyList";
	}
	
    @RequestMapping("knowledge/knowledgeSurvey/getSurveyList.do")
    @ResponseBody
    public EasyUIDataGridModel getSurveyList(HttpServletRequest request){
        EasyUIDataGridModel dg = new EasyUIDataGridModel();

        String pageNumber = request.getParameter("page");
        String pageSize = request.getParameter("rows");
        String surveyType = request.getParameter("surveyType");
        String surveyName = request.getParameter("surveyName");
        String surveyStatus = request.getParameter("surveyStatus");
        int pageNo = 1;
        int pageS= SysConstant.PAGE_SIZE;
        if(!StringUtils.isEmpty(pageNumber)){
            pageNo = Integer.parseInt(pageNumber);
        }
        if(!StringUtils.isEmpty(pageSize)){
            pageS = Integer.parseInt(pageSize);
        }
        PageHelper.startPage(pageNo,pageS );//设置分页页号和页码
        Map<String , Object> paramMap = new HashMap<String , Object>();
        paramMap.put("delFlag", SysConstant.NOT_DEL_FLAG);
        if(!StringUtils.isEmpty(surveyName)){
            paramMap.put("surveyName", surveyName);
        }
        if(!StringUtils.isEmpty(surveyStatus)){
            paramMap.put("surveyStatus", surveyStatus);
        }
        if(!StringUtils.isEmpty(surveyType)){
            paramMap.put("surveyType", surveyType);
        }
        List<CcSurvey> list = ccSurveyService.findSurveyList(paramMap);
        
        PageInfo page = new PageInfo(list);
        dg.setTotal(page.getTotal());
        dg.setRows(list);
        
        return dg;
    }
	
	
	@RequestMapping("knowledge/knowledgeSurvey/surveyInfoPage.do")
	public ModelAndView surveyInfoPage(HttpServletRequest request) throws Exception{
		ModelAndView mv = new ModelAndView();
		
		mv = ccSurveyService.viewSurvey(request);
		
		return mv;
	}
	
	@RequestMapping("knowledge/knowledgeSurvey/save.do")
	@ResponseBody
	public JsonResponse<Void> save(HttpServletRequest request){
	    
        JsonResponse<Void> jr = new JsonResponse<>();
        
        String userName = getCurrentUserName(request);
        
        jr = ccSurveyService.saveSurvey(request, userName);
        
	    return jr;
	}
	
    @RequestMapping("knowledge/knowledgeSurvey/deleteSurvey.do")
    @ResponseBody
	public JsonResponse<Void> deleteSurvey(HttpServletRequest request){
        JsonResponse<Void> jr = new JsonResponse<>();
        
        String userName = getCurrentUserName(request);
        
        jr = ccSurveyService.deleteSurvey(request, userName);
        
        return jr;
	}
	
	/**
     * 
     * 保存问题类别 
     * */
    @RequestMapping("knowledge/knowledgeSurvey/saveOrUpdateType.do")
    @ResponseBody
    public JsonResponse<Void> saveOrUpdateType(HttpServletRequest request,HttpServletResponse reponse){
        //构造返回值
        JsonResponse<Void> jr = new JsonResponse<Void>();
        //获参
        String typeNames = request.getParameter("typeNames");
        String type_desc[] = StringUtil.splitString(typeNames,",");
        
        String typeId_array = request.getParameter("typeId_array");
        String dictKey_array[] = StringUtil.splitString(typeId_array,",");
            
        ccSurveyService.saveOrUpdateType(type_desc,dictKey_array);
        
        //返回结果集
        jr.setStatus(JsonResponse.Status.SUCCESS);
        return jr;
    }
    

    
    @RequestMapping("knowledge/knowledgeSurvey/initTypeList.do")
    @ResponseBody
    public List<SysDict> initTypeList(HttpServletRequest request){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("dictCode","SURVEY_TYPE");
        List<SysDict> list = sysDictService.findByProperties(map);
        return list;
    }
    
    @RequestMapping("knowledge/knowledgeSurvey/getExistingQuestionType.do")
    @ResponseBody
    public List<SysDict> getExistingQuestionType(HttpServletRequest request){
        
        List<SysDict> resultList = new ArrayList<SysDict>();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("dictCode","SURVEY_TYPE");
        List<SysDict> dictList = sysDictService.findByProperties(map);
        List<String> typeList = ccSurveyService.selectSurveyType();
        if(dictList !=null && typeList !=null){
            for(SysDict sysDict : dictList){
                
                for(String surveyType : typeList){
                    if(sysDict.getDictKey().equals(surveyType)) {
                        //说明此类型正在使用，不能删除
                        sysDict.setStatus("1");
                    }
                }
                resultList.add(sysDict);
            }
        }
        
        return resultList;
    }

    
      //20161215版本废弃
//    @RequestMapping("knowledge/knowledgeSurvey/getAllSurvey.do")
//    @ResponseBody
//    public JsonResponse<List<CcSurvey>> getAllSurvey(){
//        JsonResponse<List<CcSurvey>> jr = new JsonResponse<List<CcSurvey>>();
//        List<CcSurvey> list = ccSurveyService.findByProperty("DEL_FLAG", "0");
//        jr.setResult(list);
//        return jr;
//    }
    
    @RequestMapping("knowledge/knowledgeSurvey/getAllPrdType.do")
    @ResponseBody
    public JsonResponse<List<PrdType>> getAllPrdType(){
        JsonResponse<List<PrdType>> jr = new JsonResponse<List<PrdType>>();
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("delFlag", 0);
        map.put("status", "0");//已启用的产品类型
        List<PrdType> list = prdTypeService.findByProperties(map);
        jr.setResult(list);
        return jr;
    }
    
    @RequestMapping("knowledge/knowledgeSurvey/getAbnormalSurvey.do")
    @ResponseBody
    public JsonResponse<List<SysDict>> getAbnormalSurvey(){
        JsonResponse<List<SysDict>> jr = new JsonResponse<List<SysDict>>();
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("dictCode", "ABNORMAL_SURVEY_TYPE");
        List<SysDict> list = sysDictService.findByProperties(map);
        jr.setResult(list);
        return jr;
    }
    
    
    @RequestMapping("knowledge/knowledgeSurvey/setAbnormalSurvey.do")
    @ResponseBody
    public  JsonResponse<Void> setAbnormalSurvey(HttpServletRequest request){
    	JsonResponse<Void> jr = new JsonResponse<>();
    	String userName = getCurrentUserName(request);
        jr = ccSurveyService.updateAbnormalSurvey(request, userName);
        
        return jr;
    }
	
	
	
	
}
