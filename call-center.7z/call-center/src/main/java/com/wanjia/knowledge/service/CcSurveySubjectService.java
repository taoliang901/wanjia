package com.wanjia.knowledge.service;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseService;
import com.wanjia.knowledge.bo.CcSurveySubject;
import com.wanjia.knowledge.bo.SurveySubjectModel;

/**
 * This element is automatically generated on 16-8-5 上午11:40, do not modify. <br>
 * Service interface
 */
public interface CcSurveySubjectService extends IBaseService<CcSurveySubject, String> {
	
	List<SurveySubjectModel> getSubjectBySurvey(Map<String,Object> map);
}