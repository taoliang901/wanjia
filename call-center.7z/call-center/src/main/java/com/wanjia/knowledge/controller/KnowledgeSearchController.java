package com.wanjia.knowledge.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.knowledge.bo.CcKnowledge;
import com.wanjia.knowledge.enums.KnowledgeStatus;
import com.wanjia.knowledge.service.CcKnowledgeService;

@Controller
@RequestMapping("/knowledge/")
public class KnowledgeSearchController {

	@Autowired
	private CcKnowledgeService ccKnowledgeService;
	
	/** 初始化页面url */
	private final String init_page_url = "knowledge/knowledgeSearch";
	
	/**
	 * 呼入页面初始化
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("initKnowledge.do")
	public ModelAndView initKnowledge(HttpServletRequest request,HttpServletResponse response){
		ModelAndView mv = new ModelAndView();
		mv.setViewName(init_page_url);	
		return mv;
	}
	
	/**
	 * 查询问题
	 * @param key 关键字
	 * @return
	 */
	@RequestMapping("queryKnowledge.do")
	@ResponseBody
	public JsonResponse<List<CcKnowledge>> queryKnowledge(String key,String limit){
		JsonResponse<List<CcKnowledge>> response = new JsonResponse<List<CcKnowledge>>();
		Map<String,Object> map = new HashMap<String,Object>();
		if(StringUtils.isNotBlank(key))
			map.put("key", key.trim());
		if(StringUtils.isNotBlank(limit))
			map.put("limit", Integer.parseInt(limit));
		map.put("delFlag", SysConstant.NOT_DEL_FLAG);
		map.put("status", KnowledgeStatus.ENABLE.getValue());
		try{
			List<CcKnowledge> list = ccKnowledgeService.getKnowledge(map);
			response.setResult(list);
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			e.printStackTrace();
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("搜索常见问题异常！");
		}
		
		return response;
	}
}
