package com.wanjia.knowledge.dao;

import java.util.List;

import com.wanjia.base.IBaseDao;
import com.wanjia.knowledge.bo.CcSurveyOption;

public interface CcSurveyOptionMapper extends IBaseDao<CcSurveyOption,String> {
    
    public List<CcSurveyOption> findOptionOrderBySequence(String subjectId);
    
}