package com.wanjia.knowledge.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.ModelAndView;

import com.wanjia.base.IBaseService;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.knowledge.bo.CcSurvey;

/**
 * This element is automatically generated on 16-8-5 上午11:17, do not modify. <br>
 * Service interface
 */
public interface CcSurveyService extends IBaseService<CcSurvey, String> {
    
    public JsonResponse<Void> saveSurvey(HttpServletRequest request,String userName);
    
    public ModelAndView viewSurvey(HttpServletRequest request) throws Exception;
    
    public List<CcSurvey> findSurveyList(Map<String, Object> map);
    
    public JsonResponse<Void> saveOrUpdateType(String type_desc[],String dictKey_array[]);
    
    public List<String> selectSurveyType();
    
    public JsonResponse<Void> deleteSurvey(HttpServletRequest request,String userName);
    
    public JsonResponse<Void> updateAbnormalSurvey(HttpServletRequest request,String userName);

}