package com.wanjia.knowledge.bo;

import java.util.List;

public class SurveyModel extends CcSurvey {
    
    /**
     * 
     */
    private static final long serialVersionUID = 7215070059071286409L;
    
    private List<SurveySubjectModel> surveySubjectList;

    public List<SurveySubjectModel> getSurveySubjectList() {
        return surveySubjectList;
    }

    public void setSurveySubjectList(List<SurveySubjectModel> surveySubjectList) {
        this.surveySubjectList = surveySubjectList;
    }
    
    
}
