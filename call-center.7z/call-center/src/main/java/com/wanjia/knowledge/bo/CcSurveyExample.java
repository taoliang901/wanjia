package com.wanjia.knowledge.bo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CcSurveyExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CcSurveyExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceIsNull() {
            addCriterion("SURVEY_SEQUENCE is null");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceIsNotNull() {
            addCriterion("SURVEY_SEQUENCE is not null");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceEqualTo(String value) {
            addCriterion("SURVEY_SEQUENCE =", value, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceNotEqualTo(String value) {
            addCriterion("SURVEY_SEQUENCE <>", value, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceGreaterThan(String value) {
            addCriterion("SURVEY_SEQUENCE >", value, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceGreaterThanOrEqualTo(String value) {
            addCriterion("SURVEY_SEQUENCE >=", value, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceLessThan(String value) {
            addCriterion("SURVEY_SEQUENCE <", value, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceLessThanOrEqualTo(String value) {
            addCriterion("SURVEY_SEQUENCE <=", value, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceLike(String value) {
            addCriterion("SURVEY_SEQUENCE like", value, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceNotLike(String value) {
            addCriterion("SURVEY_SEQUENCE not like", value, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceIn(List<String> values) {
            addCriterion("SURVEY_SEQUENCE in", values, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceNotIn(List<String> values) {
            addCriterion("SURVEY_SEQUENCE not in", values, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceBetween(String value1, String value2) {
            addCriterion("SURVEY_SEQUENCE between", value1, value2, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceNotBetween(String value1, String value2) {
            addCriterion("SURVEY_SEQUENCE not between", value1, value2, "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveyNameIsNull() {
            addCriterion("SURVEY_NAME is null");
            return (Criteria) this;
        }

        public Criteria andSurveyNameIsNotNull() {
            addCriterion("SURVEY_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andSurveyNameEqualTo(String value) {
            addCriterion("SURVEY_NAME =", value, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameNotEqualTo(String value) {
            addCriterion("SURVEY_NAME <>", value, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameGreaterThan(String value) {
            addCriterion("SURVEY_NAME >", value, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameGreaterThanOrEqualTo(String value) {
            addCriterion("SURVEY_NAME >=", value, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameLessThan(String value) {
            addCriterion("SURVEY_NAME <", value, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameLessThanOrEqualTo(String value) {
            addCriterion("SURVEY_NAME <=", value, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameLike(String value) {
            addCriterion("SURVEY_NAME like", value, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameNotLike(String value) {
            addCriterion("SURVEY_NAME not like", value, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameIn(List<String> values) {
            addCriterion("SURVEY_NAME in", values, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameNotIn(List<String> values) {
            addCriterion("SURVEY_NAME not in", values, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameBetween(String value1, String value2) {
            addCriterion("SURVEY_NAME between", value1, value2, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyNameNotBetween(String value1, String value2) {
            addCriterion("SURVEY_NAME not between", value1, value2, "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeIsNull() {
            addCriterion("SURVEY_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeIsNotNull() {
            addCriterion("SURVEY_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeEqualTo(String value) {
            addCriterion("SURVEY_TYPE =", value, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeNotEqualTo(String value) {
            addCriterion("SURVEY_TYPE <>", value, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeGreaterThan(String value) {
            addCriterion("SURVEY_TYPE >", value, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeGreaterThanOrEqualTo(String value) {
            addCriterion("SURVEY_TYPE >=", value, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeLessThan(String value) {
            addCriterion("SURVEY_TYPE <", value, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeLessThanOrEqualTo(String value) {
            addCriterion("SURVEY_TYPE <=", value, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeLike(String value) {
            addCriterion("SURVEY_TYPE like", value, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeNotLike(String value) {
            addCriterion("SURVEY_TYPE not like", value, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeIn(List<String> values) {
            addCriterion("SURVEY_TYPE in", values, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeNotIn(List<String> values) {
            addCriterion("SURVEY_TYPE not in", values, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeBetween(String value1, String value2) {
            addCriterion("SURVEY_TYPE between", value1, value2, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeNotBetween(String value1, String value2) {
            addCriterion("SURVEY_TYPE not between", value1, value2, "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusIsNull() {
            addCriterion("SURVEY_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusIsNotNull() {
            addCriterion("SURVEY_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusEqualTo(String value) {
            addCriterion("SURVEY_STATUS =", value, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusNotEqualTo(String value) {
            addCriterion("SURVEY_STATUS <>", value, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusGreaterThan(String value) {
            addCriterion("SURVEY_STATUS >", value, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusGreaterThanOrEqualTo(String value) {
            addCriterion("SURVEY_STATUS >=", value, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusLessThan(String value) {
            addCriterion("SURVEY_STATUS <", value, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusLessThanOrEqualTo(String value) {
            addCriterion("SURVEY_STATUS <=", value, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusLike(String value) {
            addCriterion("SURVEY_STATUS like", value, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusNotLike(String value) {
            addCriterion("SURVEY_STATUS not like", value, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusIn(List<String> values) {
            addCriterion("SURVEY_STATUS in", values, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusNotIn(List<String> values) {
            addCriterion("SURVEY_STATUS not in", values, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusBetween(String value1, String value2) {
            addCriterion("SURVEY_STATUS between", value1, value2, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusNotBetween(String value1, String value2) {
            addCriterion("SURVEY_STATUS not between", value1, value2, "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagIsNull() {
            addCriterion("OVERTIME_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagIsNotNull() {
            addCriterion("OVERTIME_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagEqualTo(String value) {
            addCriterion("OVERTIME_FLAG =", value, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagNotEqualTo(String value) {
            addCriterion("OVERTIME_FLAG <>", value, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagGreaterThan(String value) {
            addCriterion("OVERTIME_FLAG >", value, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagGreaterThanOrEqualTo(String value) {
            addCriterion("OVERTIME_FLAG >=", value, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagLessThan(String value) {
            addCriterion("OVERTIME_FLAG <", value, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagLessThanOrEqualTo(String value) {
            addCriterion("OVERTIME_FLAG <=", value, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagLike(String value) {
            addCriterion("OVERTIME_FLAG like", value, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagNotLike(String value) {
            addCriterion("OVERTIME_FLAG not like", value, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagIn(List<String> values) {
            addCriterion("OVERTIME_FLAG in", values, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagNotIn(List<String> values) {
            addCriterion("OVERTIME_FLAG not in", values, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagBetween(String value1, String value2) {
            addCriterion("OVERTIME_FLAG between", value1, value2, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagNotBetween(String value1, String value2) {
            addCriterion("OVERTIME_FLAG not between", value1, value2, "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagIsNull() {
            addCriterion("HEALTH_OVERTIME_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagIsNotNull() {
            addCriterion("HEALTH_OVERTIME_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagEqualTo(String value) {
            addCriterion("HEALTH_OVERTIME_FLAG =", value, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagNotEqualTo(String value) {
            addCriterion("HEALTH_OVERTIME_FLAG <>", value, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagGreaterThan(String value) {
            addCriterion("HEALTH_OVERTIME_FLAG >", value, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagGreaterThanOrEqualTo(String value) {
            addCriterion("HEALTH_OVERTIME_FLAG >=", value, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagLessThan(String value) {
            addCriterion("HEALTH_OVERTIME_FLAG <", value, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagLessThanOrEqualTo(String value) {
            addCriterion("HEALTH_OVERTIME_FLAG <=", value, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagLike(String value) {
            addCriterion("HEALTH_OVERTIME_FLAG like", value, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagNotLike(String value) {
            addCriterion("HEALTH_OVERTIME_FLAG not like", value, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagIn(List<String> values) {
            addCriterion("HEALTH_OVERTIME_FLAG in", values, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagNotIn(List<String> values) {
            addCriterion("HEALTH_OVERTIME_FLAG not in", values, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagBetween(String value1, String value2) {
            addCriterion("HEALTH_OVERTIME_FLAG between", value1, value2, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagNotBetween(String value1, String value2) {
            addCriterion("HEALTH_OVERTIME_FLAG not between", value1, value2, "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdIsNull() {
            addCriterion("PRD_TYPE_ID is null");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdIsNotNull() {
            addCriterion("PRD_TYPE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdEqualTo(String value) {
            addCriterion("PRD_TYPE_ID =", value, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdNotEqualTo(String value) {
            addCriterion("PRD_TYPE_ID <>", value, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdGreaterThan(String value) {
            addCriterion("PRD_TYPE_ID >", value, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdGreaterThanOrEqualTo(String value) {
            addCriterion("PRD_TYPE_ID >=", value, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdLessThan(String value) {
            addCriterion("PRD_TYPE_ID <", value, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdLessThanOrEqualTo(String value) {
            addCriterion("PRD_TYPE_ID <=", value, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdLike(String value) {
            addCriterion("PRD_TYPE_ID like", value, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdNotLike(String value) {
            addCriterion("PRD_TYPE_ID not like", value, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdIn(List<String> values) {
            addCriterion("PRD_TYPE_ID in", values, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdNotIn(List<String> values) {
            addCriterion("PRD_TYPE_ID not in", values, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdBetween(String value1, String value2) {
            addCriterion("PRD_TYPE_ID between", value1, value2, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdNotBetween(String value1, String value2) {
            addCriterion("PRD_TYPE_ID not between", value1, value2, "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("CREATE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("CREATE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("CREATE_DATE =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("CREATE_DATE <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("CREATE_DATE >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("CREATE_DATE <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("CREATE_DATE in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("CREATE_DATE not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("CREATE_USER is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("CREATE_USER is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("CREATE_USER =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("CREATE_USER <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("CREATE_USER >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("CREATE_USER >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("CREATE_USER <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("CREATE_USER <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("CREATE_USER like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("CREATE_USER not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("CREATE_USER in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("CREATE_USER not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("CREATE_USER between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("CREATE_USER not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNull() {
            addCriterion("MODIFY_DATE is null");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNotNull() {
            addCriterion("MODIFY_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andModifyDateEqualTo(Date value) {
            addCriterion("MODIFY_DATE =", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotEqualTo(Date value) {
            addCriterion("MODIFY_DATE <>", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThan(Date value) {
            addCriterion("MODIFY_DATE >", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE >=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThan(Date value) {
            addCriterion("MODIFY_DATE <", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE <=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateIn(List<Date> values) {
            addCriterion("MODIFY_DATE in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotIn(List<Date> values) {
            addCriterion("MODIFY_DATE not in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE not between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNull() {
            addCriterion("MODIFY_USER is null");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNotNull() {
            addCriterion("MODIFY_USER is not null");
            return (Criteria) this;
        }

        public Criteria andModifyUserEqualTo(String value) {
            addCriterion("MODIFY_USER =", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotEqualTo(String value) {
            addCriterion("MODIFY_USER <>", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThan(String value) {
            addCriterion("MODIFY_USER >", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER >=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThan(String value) {
            addCriterion("MODIFY_USER <", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER <=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLike(String value) {
            addCriterion("MODIFY_USER like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotLike(String value) {
            addCriterion("MODIFY_USER not like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserIn(List<String> values) {
            addCriterion("MODIFY_USER in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotIn(List<String> values) {
            addCriterion("MODIFY_USER not in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserBetween(String value1, String value2) {
            addCriterion("MODIFY_USER between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotBetween(String value1, String value2) {
            addCriterion("MODIFY_USER not between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("DEL_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("DEL_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(String value) {
            addCriterion("DEL_FLAG =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(String value) {
            addCriterion("DEL_FLAG <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(String value) {
            addCriterion("DEL_FLAG >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(String value) {
            addCriterion("DEL_FLAG <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLike(String value) {
            addCriterion("DEL_FLAG like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotLike(String value) {
            addCriterion("DEL_FLAG not like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<String> values) {
            addCriterion("DEL_FLAG in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<String> values) {
            addCriterion("DEL_FLAG not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(String value1, String value2) {
            addCriterion("DEL_FLAG between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(String value1, String value2) {
            addCriterion("DEL_FLAG not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andIssueTypeIsNull() {
            addCriterion("ISSUE_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andIssueTypeIsNotNull() {
            addCriterion("ISSUE_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andIssueTypeEqualTo(String value) {
            addCriterion("ISSUE_TYPE =", value, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeNotEqualTo(String value) {
            addCriterion("ISSUE_TYPE <>", value, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeGreaterThan(String value) {
            addCriterion("ISSUE_TYPE >", value, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeGreaterThanOrEqualTo(String value) {
            addCriterion("ISSUE_TYPE >=", value, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeLessThan(String value) {
            addCriterion("ISSUE_TYPE <", value, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeLessThanOrEqualTo(String value) {
            addCriterion("ISSUE_TYPE <=", value, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeLike(String value) {
            addCriterion("ISSUE_TYPE like", value, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeNotLike(String value) {
            addCriterion("ISSUE_TYPE not like", value, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeIn(List<String> values) {
            addCriterion("ISSUE_TYPE in", values, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeNotIn(List<String> values) {
            addCriterion("ISSUE_TYPE not in", values, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeBetween(String value1, String value2) {
            addCriterion("ISSUE_TYPE between", value1, value2, "issueType");
            return (Criteria) this;
        }

        public Criteria andIssueTypeNotBetween(String value1, String value2) {
            addCriterion("ISSUE_TYPE not between", value1, value2, "issueType");
            return (Criteria) this;
        }

        public Criteria andIdLikeInsensitive(String value) {
            addCriterion("upper(ID) like", value.toUpperCase(), "id");
            return (Criteria) this;
        }

        public Criteria andSurveySequenceLikeInsensitive(String value) {
            addCriterion("upper(SURVEY_SEQUENCE) like", value.toUpperCase(), "surveySequence");
            return (Criteria) this;
        }

        public Criteria andSurveyNameLikeInsensitive(String value) {
            addCriterion("upper(SURVEY_NAME) like", value.toUpperCase(), "surveyName");
            return (Criteria) this;
        }

        public Criteria andSurveyTypeLikeInsensitive(String value) {
            addCriterion("upper(SURVEY_TYPE) like", value.toUpperCase(), "surveyType");
            return (Criteria) this;
        }

        public Criteria andSurveyStatusLikeInsensitive(String value) {
            addCriterion("upper(SURVEY_STATUS) like", value.toUpperCase(), "surveyStatus");
            return (Criteria) this;
        }

        public Criteria andOvertimeFlagLikeInsensitive(String value) {
            addCriterion("upper(OVERTIME_FLAG) like", value.toUpperCase(), "overtimeFlag");
            return (Criteria) this;
        }

        public Criteria andHealthOvertimeFlagLikeInsensitive(String value) {
            addCriterion("upper(HEALTH_OVERTIME_FLAG) like", value.toUpperCase(), "healthOvertimeFlag");
            return (Criteria) this;
        }

        public Criteria andPrdTypeIdLikeInsensitive(String value) {
            addCriterion("upper(PRD_TYPE_ID) like", value.toUpperCase(), "prdTypeId");
            return (Criteria) this;
        }

        public Criteria andCreateUserLikeInsensitive(String value) {
            addCriterion("upper(CREATE_USER) like", value.toUpperCase(), "createUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLikeInsensitive(String value) {
            addCriterion("upper(MODIFY_USER) like", value.toUpperCase(), "modifyUser");
            return (Criteria) this;
        }

        public Criteria andDelFlagLikeInsensitive(String value) {
            addCriterion("upper(DEL_FLAG) like", value.toUpperCase(), "delFlag");
            return (Criteria) this;
        }

        public Criteria andIssueTypeLikeInsensitive(String value) {
            addCriterion("upper(ISSUE_TYPE) like", value.toUpperCase(), "issueType");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}