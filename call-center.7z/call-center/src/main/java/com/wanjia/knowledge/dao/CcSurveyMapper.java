package com.wanjia.knowledge.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseDao;
import com.wanjia.knowledge.bo.CcSurvey;
import com.wanjia.knowledge.bo.SurveyModel;

public interface CcSurveyMapper extends IBaseDao<CcSurvey,String> {
    
    public SurveyModel findSurveyModelBySurveyId(String Id);
    
    public List<CcSurvey> findSurveyList(Map<String,Object> map);
    
    public List<String> selectSurveyType();
    

    
}