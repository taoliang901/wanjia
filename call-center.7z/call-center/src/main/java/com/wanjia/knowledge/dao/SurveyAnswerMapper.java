package com.wanjia.knowledge.dao;

import com.wanjia.base.IBaseDao;

public interface SurveyAnswerMapper extends IBaseDao {
}