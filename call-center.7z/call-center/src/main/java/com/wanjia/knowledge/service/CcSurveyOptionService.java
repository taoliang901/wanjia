package com.wanjia.knowledge.service;

import com.wanjia.base.IBaseService;
import com.wanjia.knowledge.bo.CcSurveyOption;

/**
 * This element is automatically generated on 16-8-5 上午11:27, do not modify. <br>
 * Service interface
 */
public interface CcSurveyOptionService extends IBaseService<CcSurveyOption, String> {
}