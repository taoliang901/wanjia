package com.wanjia.knowledge.enums;

/**
 * 调研问题类型枚举类
 * @author QIANXIN510
 *
 */
public enum SubjectType {
	
	SINGLE("SINGLE", "01", "单选题"), MULTI("MULTI", "02", "所选题"),RANK("RANK", "03", "评分题"),DESCRIPTION("DESCRIPTION", "04", "开放描述题");
	
	private String code;
    private String value;
    private String desc;
    
	private SubjectType(String code, String value, String desc) {
		this.code = code;
		this.value = value;
		this.desc = desc;
	}
    
    public static SubjectType getSubjectType(String value){
   	 for (SubjectType c : SubjectType.values()) {
            if (c.getValue().equals(value) ) {
                return c;
            }
        }
   	 return null;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
