package com.wanjia.issue.service;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.CcIssueType;

/**
 * This element is automatically generated on 16-9-19 ����11:06, do not modify. <br>
 * Service interface
 */
public interface CcIssueTypeService extends IBaseService<CcIssueType, String> {
}