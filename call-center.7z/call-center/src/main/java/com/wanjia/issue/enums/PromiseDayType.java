package com.wanjia.issue.enums;

/**
 * 坐席承诺时效枚举类
 * @author QIANXIN510
 *
 */
public enum PromiseDayType {
	
	ONE("one", "1", "1个工作日"), THREE("three", "3", "3个工作日"), FIVE("five", "5", "5个工作日"), SEVEN("seven", "7", "7个工作日")
	, TEN("ten", "10", "10个工作日"), FIFTEEN("fifteen", "15", "15个工作日");
	
	private String code;
    private String value;
    private String desc;
    
	private PromiseDayType(String code, String value, String desc) {
		this.code = code;
		this.value = value;
		this.desc = desc;
	}
    
    public static PromiseDayType getPromiseDayType(String value){
   	 for (PromiseDayType c : PromiseDayType.values()) {
            if (c.getValue().equals(value)) {
                return c;
            }
        }
   	 return null;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
