package com.wanjia.issue.service;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueAbnormalLog;
import com.wanjia.issue.bo.IssueProcess;
import com.wanjia.issue.controller.CallOutController;
import com.wanjia.issue.dao.IssueAbnormalLogMapper;
import com.wanjia.issue.dao.IssueMapper;
import com.wanjia.issue.dao.IssueProcessMapper;
import com.wanjia.issue.enums.IssueStatus;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-9-18 上午9:53, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class IssueAbnormalLogServiceImpl implements IssueAbnormalLogService {
    
	private Logger logger = Logger.getLogger(IssueAbnormalLogServiceImpl.class);
	
	@Autowired
    private IssueAbnormalLogMapper issueAbnormalLogMapper;
    
    @Autowired
    private IssueMapper issueMapper;
    
    @Autowired
    private IssueProcessMapper issueProcessMapper;
    
    @Override
    @Transactional(readOnly=true)
    public IssueAbnormalLog findById(String id) {
        return (IssueAbnormalLog)issueAbnormalLogMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueAbnormalLog> findWithPagination(int offset, int count) {
        return (List<IssueAbnormalLog>)issueAbnormalLogMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueAbnormalLog> findAll() {
        return (List<IssueAbnormalLog>)issueAbnormalLogMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueAbnormalLog> findByEntity(IssueAbnormalLog model) {
        return (List<IssueAbnormalLog>)issueAbnormalLogMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueAbnormalLog> findByEntityWithPagination(IssueAbnormalLog model, int offset, int count) {
        return (List<IssueAbnormalLog>)issueAbnormalLogMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueAbnormalLog findOneByEntity(IssueAbnormalLog model) {
        return (IssueAbnormalLog)issueAbnormalLogMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueAbnormalLog> findByProperty(String propertyName, String propertyValue) {
        return (List<IssueAbnormalLog>)issueAbnormalLogMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueAbnormalLog findOneByProperty(String propertyName, String propertyValue) {
        return (IssueAbnormalLog)issueAbnormalLogMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueAbnormalLog> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<IssueAbnormalLog>)issueAbnormalLogMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueAbnormalLog> findByProperties(Map<String, Object> map) {
        return (List<IssueAbnormalLog>)issueAbnormalLogMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(IssueAbnormalLog model) {
        return (long)issueAbnormalLogMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)issueAbnormalLogMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)issueAbnormalLogMapper.countByProperties(map);
    }

    @Override
    public void update(IssueAbnormalLog model) {
      //  model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        issueAbnormalLogMapper.update(model);
    }

    @Override
    public void insert(IssueAbnormalLog model) {
      //  model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        issueAbnormalLogMapper.insert(model);
    }

    @Override
    public void deleteByEntity(IssueAbnormalLog model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        issueAbnormalLogMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.issueAbnormalLogMapper.countAll();
    }

    public void insertBatch(List<IssueAbnormalLog> list) {
        this.issueAbnormalLogMapper.insertBatch(list);
    }

    public void delete(String id) {
        IssueAbnormalLog model = new IssueAbnormalLog();
        model.setDelFlag(SysConstant.DEL_FLAG);
     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.issueAbnormalLogMapper.update(model);
    }
    
    
    public void saveAbnormalIssue(IssueAbnormalLog model){
    	logger.info("saveCalloutAbnormal --异常的issueId---" + model.getIssueId());
    	logger.info("异常原因----"+model.getAbnormalReason());
    	model.setId(UUID.randomUUID().toString());
    	model.setCreateDate(new Date());
    	model.setDelFlag(SysConstant.NOT_DEL_FLAG);
        issueAbnormalLogMapper.insert(model);
        
        Issue issue = new Issue();
        issue.setId(model.getIssueId());
        issue.setCallTime(new Date());
        issue.setModifyDate(new Date());
        issue.setModifyUser(model.getCreateUser());
        issue.setHandler(model.getCreateUser());
        issueMapper.update(issue);
    }
    
    
    public void saveAbnormalIssueClosed(IssueAbnormalLog model){
    	logger.info("closeAbnormalIssue --关闭的issueId---" + model.getIssueId());
    	logger.info("异常原因----"+model.getAbnormalReason());
    	//插入 通话异常表
    	model.setId(UUID.randomUUID().toString());
    	model.setCreateDate(new Date());
    	model.setDelFlag(SysConstant.NOT_DEL_FLAG);
        issueAbnormalLogMapper.insert(model);
        //更新工单表中状态
        Issue issue = new Issue();
        issue.setId(model.getIssueId());
        issue.setCallTime(new Date());
        issue.setStatus(IssueStatus.CLOSED.getValue());
        issue.setModifyDate(new Date());
        issue.setModifyUser(model.getCreateUser());
        issue.setHandler(model.getCreateUser());
        issueMapper.update(issue);
        //更新工单流转表中状态
        IssueProcess issueProcess = new IssueProcess();
        issueProcess.setIssueId(model.getIssueId());
        issueProcess.setDelFlag(SysConstant.NOT_DEL_FLAG);
        issueProcess = (IssueProcess) issueProcessMapper.findOneByEntity(issueProcess);
        if(issueProcess!=null){
        	issueProcess.setStatus(IssueStatus.CLOSED.getValue());
            issueProcess.setModifyDate(new Date());
            issueProcess.setModifyUser(model.getCreateUser());
            issueProcessMapper.update(issueProcess);
        }
    }
}