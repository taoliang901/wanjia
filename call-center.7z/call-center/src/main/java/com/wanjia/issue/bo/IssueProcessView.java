package com.wanjia.issue.bo;

import java.io.Serializable;

public class IssueProcessView extends IssueProcess implements Serializable {
	private static final long serialVersionUID = 1L;
	private String statusName;
    private String userName;
    private String callType;
    private String isConvey;
    private String callTime;
	public String getCallTime() {
		return callTime;
	}
	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCallType() {
		return callType;
	}
	public void setCallType(String callType) {
		this.callType = callType;
	}
	public String getIsConvey() {
		return isConvey;
	}
	public void setIsConvey(String isConvey) {
		this.isConvey = isConvey;
	}

}