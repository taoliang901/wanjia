package com.wanjia.issue.service;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.issue.bo.ClinicInfo;
import com.wanjia.issue.dao.ClinicInfoMapper;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-9-19 ����7:37, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class ClinicInfoServiceImpl implements ClinicInfoService {
    @Autowired
    private ClinicInfoMapper clinicInfoMapper;

    @Override
    @Transactional(readOnly=true)
    public ClinicInfo findById(String id) {
        return (ClinicInfo)clinicInfoMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ClinicInfo> findWithPagination(int offset, int count) {
        return (List<ClinicInfo>)clinicInfoMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ClinicInfo> findAll() {
        return (List<ClinicInfo>)clinicInfoMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<ClinicInfo> findByEntity(ClinicInfo model) {
        return (List<ClinicInfo>)clinicInfoMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ClinicInfo> findByEntityWithPagination(ClinicInfo model, int offset, int count) {
        return (List<ClinicInfo>)clinicInfoMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public ClinicInfo findOneByEntity(ClinicInfo model) {
        return (ClinicInfo)clinicInfoMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ClinicInfo> findByProperty(String propertyName, String propertyValue) {
        return (List<ClinicInfo>)clinicInfoMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public ClinicInfo findOneByProperty(String propertyName, String propertyValue) {
        return (ClinicInfo)clinicInfoMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ClinicInfo> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<ClinicInfo>)clinicInfoMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ClinicInfo> findByProperties(Map<String, Object> map) {
        return (List<ClinicInfo>)clinicInfoMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(ClinicInfo model) {
        return (long)clinicInfoMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)clinicInfoMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)clinicInfoMapper.countByProperties(map);
    }

    @Override
    public void update(ClinicInfo model) {
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        clinicInfoMapper.update(model);
    }

    @Override
    public void insert(ClinicInfo model) {
//        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        clinicInfoMapper.insert(model);
    }

    @Override
    public void deleteByEntity(ClinicInfo model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        clinicInfoMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.clinicInfoMapper.countAll();
    }

    public void insertBatch(List<ClinicInfo> list) {
        this.clinicInfoMapper.insertBatch(list);
    }

    public void delete(String id) {
        ClinicInfo model = new ClinicInfo();
        model.setDelFlag(SysConstant.DEL_FLAG);
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(id);
        this.clinicInfoMapper.update(model);
    }
}