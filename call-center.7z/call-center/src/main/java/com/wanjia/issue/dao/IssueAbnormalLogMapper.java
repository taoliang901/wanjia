package com.wanjia.issue.dao;

import com.wanjia.base.IBaseDao;

public interface IssueAbnormalLogMapper extends IBaseDao {
}