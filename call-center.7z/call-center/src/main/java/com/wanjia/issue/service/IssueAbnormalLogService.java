package com.wanjia.issue.service;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.IssueAbnormalLog;

/**
 * This element is automatically generated on 16-9-18 上午9:53, do not modify. <br>
 * Service interface
 */
public interface IssueAbnormalLogService extends IBaseService<IssueAbnormalLog, String> {
	
	public void saveAbnormalIssue(IssueAbnormalLog model);
	
	public void saveAbnormalIssueClosed(IssueAbnormalLog model);
}