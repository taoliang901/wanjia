package com.wanjia.issue.service;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.IssueOBInfo;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueOBInfoModel;

/**
 * This element is automatically generated on 16-8-3 下午8:14, do not modify. <br>
 * Service interface
 */
public interface IssueOBInfoService extends IBaseService<IssueOBInfo, String> {
	
	public String searchMaxSeq();
	
	public void createUploadIssue(List<Issue> issueList,List<IssueOBInfo> oblist);
	
	public List<IssueOBInfoModel> searchUploadInfo(Map<String, Object> map);
	
	public String countUnassignedOBIssueNum(Map<String, Object> map);
	
	public List<IssueOBInfo> searchUnassignedOBIssue(Map<String, Object> map);
	
	public String checkIfExistingOBIssue(Map<String,Object> map);
}