package com.wanjia.issue.bo;

import java.io.Serializable;

public class CtiAppletParam implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;

    private String roleCode;

    private String guiFlag;

    private String ctiType;

    private String agentInfo;

    private String dataType;

    private String notReadyReasonCodetype;

    private String notReadyReasonCode;

    private String agentReadyMode;

    private String dialstringOut;

    private String acwSwitch;

    private String env;

    private String sumitEndcodetime;

    private String defaultEndcode;

    private String buttonStyle;

    private String butLoginLogin;

    private String butOutbound;

    private String butHangup;

    private String butAnswer;

    private String butDtmf;

    private String butWorkingStatusOpen;

    private String butBook;

    private String butHoldon;

    private String butTransfer;

    private String butMeeting;

    private String butAttachjob;

    private String butListen;

    private String butForceInsert;

    private String butForceBackout;

    private String aniText;

    private String dnisText;

    private String talkTimeText;

    private String currentStateTimeText;

    private String talkCountText;

    private String dialFrame;

    private String ver;

    private String stopFlag;

    private String outdailNumber;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getGuiFlag() {
        return guiFlag;
    }

    public void setGuiFlag(String guiFlag) {
        this.guiFlag = guiFlag;
    }

    public String getCtiType() {
        return ctiType;
    }

    public void setCtiType(String ctiType) {
        this.ctiType = ctiType;
    }

    public String getAgentInfo() {
        return agentInfo;
    }

    public void setAgentInfo(String agentInfo) {
        this.agentInfo = agentInfo;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getNotReadyReasonCodetype() {
        return notReadyReasonCodetype;
    }

    public void setNotReadyReasonCodetype(String notReadyReasonCodetype) {
        this.notReadyReasonCodetype = notReadyReasonCodetype;
    }

    public String getNotReadyReasonCode() {
        return notReadyReasonCode;
    }

    public void setNotReadyReasonCode(String notReadyReasonCode) {
        this.notReadyReasonCode = notReadyReasonCode;
    }

    public String getAgentReadyMode() {
        return agentReadyMode;
    }

    public void setAgentReadyMode(String agentReadyMode) {
        this.agentReadyMode = agentReadyMode;
    }

    public String getDialstringOut() {
        return dialstringOut;
    }

    public void setDialstringOut(String dialstringOut) {
        this.dialstringOut = dialstringOut;
    }

    public String getAcwSwitch() {
        return acwSwitch;
    }

    public void setAcwSwitch(String acwSwitch) {
        this.acwSwitch = acwSwitch;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getSumitEndcodetime() {
        return sumitEndcodetime;
    }

    public void setSumitEndcodetime(String sumitEndcodetime) {
        this.sumitEndcodetime = sumitEndcodetime;
    }

    public String getDefaultEndcode() {
        return defaultEndcode;
    }

    public void setDefaultEndcode(String defaultEndcode) {
        this.defaultEndcode = defaultEndcode;
    }

    public String getButtonStyle() {
        return buttonStyle;
    }

    public void setButtonStyle(String buttonStyle) {
        this.buttonStyle = buttonStyle;
    }

    public String getButLoginLogin() {
        return butLoginLogin;
    }

    public void setButLoginLogin(String butLoginLogin) {
        this.butLoginLogin = butLoginLogin;
    }

    public String getButOutbound() {
        return butOutbound;
    }

    public void setButOutbound(String butOutbound) {
        this.butOutbound = butOutbound;
    }

    public String getButHangup() {
        return butHangup;
    }

    public void setButHangup(String butHangup) {
        this.butHangup = butHangup;
    }

    public String getButAnswer() {
        return butAnswer;
    }

    public void setButAnswer(String butAnswer) {
        this.butAnswer = butAnswer;
    }

    public String getButDtmf() {
        return butDtmf;
    }

    public void setButDtmf(String butDtmf) {
        this.butDtmf = butDtmf;
    }

    public String getButWorkingStatusOpen() {
        return butWorkingStatusOpen;
    }

    public void setButWorkingStatusOpen(String butWorkingStatusOpen) {
        this.butWorkingStatusOpen = butWorkingStatusOpen;
    }

    public String getButBook() {
        return butBook;
    }

    public void setButBook(String butBook) {
        this.butBook = butBook;
    }

    public String getButHoldon() {
        return butHoldon;
    }

    public void setButHoldon(String butHoldon) {
        this.butHoldon = butHoldon;
    }

    public String getButTransfer() {
        return butTransfer;
    }

    public void setButTransfer(String butTransfer) {
        this.butTransfer = butTransfer;
    }

    public String getButMeeting() {
        return butMeeting;
    }

    public void setButMeeting(String butMeeting) {
        this.butMeeting = butMeeting;
    }

    public String getButAttachjob() {
        return butAttachjob;
    }

    public void setButAttachjob(String butAttachjob) {
        this.butAttachjob = butAttachjob;
    }

    public String getButListen() {
        return butListen;
    }

    public void setButListen(String butListen) {
        this.butListen = butListen;
    }

    public String getButForceInsert() {
        return butForceInsert;
    }

    public void setButForceInsert(String butForceInsert) {
        this.butForceInsert = butForceInsert;
    }

    public String getButForceBackout() {
        return butForceBackout;
    }

    public void setButForceBackout(String butForceBackout) {
        this.butForceBackout = butForceBackout;
    }

    public String getAniText() {
        return aniText;
    }

    public void setAniText(String aniText) {
        this.aniText = aniText;
    }

    public String getDnisText() {
        return dnisText;
    }

    public void setDnisText(String dnisText) {
        this.dnisText = dnisText;
    }

    public String getTalkTimeText() {
        return talkTimeText;
    }

    public void setTalkTimeText(String talkTimeText) {
        this.talkTimeText = talkTimeText;
    }

    public String getCurrentStateTimeText() {
        return currentStateTimeText;
    }

    public void setCurrentStateTimeText(String currentStateTimeText) {
        this.currentStateTimeText = currentStateTimeText;
    }

    public String getTalkCountText() {
        return talkCountText;
    }

    public void setTalkCountText(String talkCountText) {
        this.talkCountText = talkCountText;
    }

    public String getDialFrame() {
        return dialFrame;
    }

    public void setDialFrame(String dialFrame) {
        this.dialFrame = dialFrame;
    }

    public String getVer() {
        return ver;
    }

    public void setVer(String ver) {
        this.ver = ver;
    }

    public String getStopFlag() {
        return stopFlag;
    }

    public void setStopFlag(String stopFlag) {
        this.stopFlag = stopFlag;
    }

    public String getOutdailNumber() {
        return outdailNumber;
    }

    public void setOutdailNumber(String outdailNumber) {
        this.outdailNumber = outdailNumber;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        CtiAppletParam other = (CtiAppletParam) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getRoleCode() == null ? other.getRoleCode() == null : this.getRoleCode().equals(other.getRoleCode()))
            && (this.getGuiFlag() == null ? other.getGuiFlag() == null : this.getGuiFlag().equals(other.getGuiFlag()))
            && (this.getCtiType() == null ? other.getCtiType() == null : this.getCtiType().equals(other.getCtiType()))
            && (this.getAgentInfo() == null ? other.getAgentInfo() == null : this.getAgentInfo().equals(other.getAgentInfo()))
            && (this.getDataType() == null ? other.getDataType() == null : this.getDataType().equals(other.getDataType()))
            && (this.getNotReadyReasonCodetype() == null ? other.getNotReadyReasonCodetype() == null : this.getNotReadyReasonCodetype().equals(other.getNotReadyReasonCodetype()))
            && (this.getNotReadyReasonCode() == null ? other.getNotReadyReasonCode() == null : this.getNotReadyReasonCode().equals(other.getNotReadyReasonCode()))
            && (this.getAgentReadyMode() == null ? other.getAgentReadyMode() == null : this.getAgentReadyMode().equals(other.getAgentReadyMode()))
            && (this.getDialstringOut() == null ? other.getDialstringOut() == null : this.getDialstringOut().equals(other.getDialstringOut()))
            && (this.getAcwSwitch() == null ? other.getAcwSwitch() == null : this.getAcwSwitch().equals(other.getAcwSwitch()))
            && (this.getEnv() == null ? other.getEnv() == null : this.getEnv().equals(other.getEnv()))
            && (this.getSumitEndcodetime() == null ? other.getSumitEndcodetime() == null : this.getSumitEndcodetime().equals(other.getSumitEndcodetime()))
            && (this.getDefaultEndcode() == null ? other.getDefaultEndcode() == null : this.getDefaultEndcode().equals(other.getDefaultEndcode()))
            && (this.getButtonStyle() == null ? other.getButtonStyle() == null : this.getButtonStyle().equals(other.getButtonStyle()))
            && (this.getButLoginLogin() == null ? other.getButLoginLogin() == null : this.getButLoginLogin().equals(other.getButLoginLogin()))
            && (this.getButOutbound() == null ? other.getButOutbound() == null : this.getButOutbound().equals(other.getButOutbound()))
            && (this.getButHangup() == null ? other.getButHangup() == null : this.getButHangup().equals(other.getButHangup()))
            && (this.getButAnswer() == null ? other.getButAnswer() == null : this.getButAnswer().equals(other.getButAnswer()))
            && (this.getButDtmf() == null ? other.getButDtmf() == null : this.getButDtmf().equals(other.getButDtmf()))
            && (this.getButWorkingStatusOpen() == null ? other.getButWorkingStatusOpen() == null : this.getButWorkingStatusOpen().equals(other.getButWorkingStatusOpen()))
            && (this.getButBook() == null ? other.getButBook() == null : this.getButBook().equals(other.getButBook()))
            && (this.getButHoldon() == null ? other.getButHoldon() == null : this.getButHoldon().equals(other.getButHoldon()))
            && (this.getButTransfer() == null ? other.getButTransfer() == null : this.getButTransfer().equals(other.getButTransfer()))
            && (this.getButMeeting() == null ? other.getButMeeting() == null : this.getButMeeting().equals(other.getButMeeting()))
            && (this.getButAttachjob() == null ? other.getButAttachjob() == null : this.getButAttachjob().equals(other.getButAttachjob()))
            && (this.getButListen() == null ? other.getButListen() == null : this.getButListen().equals(other.getButListen()))
            && (this.getButForceInsert() == null ? other.getButForceInsert() == null : this.getButForceInsert().equals(other.getButForceInsert()))
            && (this.getButForceBackout() == null ? other.getButForceBackout() == null : this.getButForceBackout().equals(other.getButForceBackout()))
            && (this.getAniText() == null ? other.getAniText() == null : this.getAniText().equals(other.getAniText()))
            && (this.getDnisText() == null ? other.getDnisText() == null : this.getDnisText().equals(other.getDnisText()))
            && (this.getTalkTimeText() == null ? other.getTalkTimeText() == null : this.getTalkTimeText().equals(other.getTalkTimeText()))
            && (this.getCurrentStateTimeText() == null ? other.getCurrentStateTimeText() == null : this.getCurrentStateTimeText().equals(other.getCurrentStateTimeText()))
            && (this.getTalkCountText() == null ? other.getTalkCountText() == null : this.getTalkCountText().equals(other.getTalkCountText()))
            && (this.getDialFrame() == null ? other.getDialFrame() == null : this.getDialFrame().equals(other.getDialFrame()))
            && (this.getVer() == null ? other.getVer() == null : this.getVer().equals(other.getVer()))
            && (this.getStopFlag() == null ? other.getStopFlag() == null : this.getStopFlag().equals(other.getStopFlag()))
            && (this.getOutdailNumber() == null ? other.getOutdailNumber() == null : this.getOutdailNumber().equals(other.getOutdailNumber()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getRoleCode() == null) ? 0 : getRoleCode().hashCode());
        result = prime * result + ((getGuiFlag() == null) ? 0 : getGuiFlag().hashCode());
        result = prime * result + ((getCtiType() == null) ? 0 : getCtiType().hashCode());
        result = prime * result + ((getAgentInfo() == null) ? 0 : getAgentInfo().hashCode());
        result = prime * result + ((getDataType() == null) ? 0 : getDataType().hashCode());
        result = prime * result + ((getNotReadyReasonCodetype() == null) ? 0 : getNotReadyReasonCodetype().hashCode());
        result = prime * result + ((getNotReadyReasonCode() == null) ? 0 : getNotReadyReasonCode().hashCode());
        result = prime * result + ((getAgentReadyMode() == null) ? 0 : getAgentReadyMode().hashCode());
        result = prime * result + ((getDialstringOut() == null) ? 0 : getDialstringOut().hashCode());
        result = prime * result + ((getAcwSwitch() == null) ? 0 : getAcwSwitch().hashCode());
        result = prime * result + ((getEnv() == null) ? 0 : getEnv().hashCode());
        result = prime * result + ((getSumitEndcodetime() == null) ? 0 : getSumitEndcodetime().hashCode());
        result = prime * result + ((getDefaultEndcode() == null) ? 0 : getDefaultEndcode().hashCode());
        result = prime * result + ((getButtonStyle() == null) ? 0 : getButtonStyle().hashCode());
        result = prime * result + ((getButLoginLogin() == null) ? 0 : getButLoginLogin().hashCode());
        result = prime * result + ((getButOutbound() == null) ? 0 : getButOutbound().hashCode());
        result = prime * result + ((getButHangup() == null) ? 0 : getButHangup().hashCode());
        result = prime * result + ((getButAnswer() == null) ? 0 : getButAnswer().hashCode());
        result = prime * result + ((getButDtmf() == null) ? 0 : getButDtmf().hashCode());
        result = prime * result + ((getButWorkingStatusOpen() == null) ? 0 : getButWorkingStatusOpen().hashCode());
        result = prime * result + ((getButBook() == null) ? 0 : getButBook().hashCode());
        result = prime * result + ((getButHoldon() == null) ? 0 : getButHoldon().hashCode());
        result = prime * result + ((getButTransfer() == null) ? 0 : getButTransfer().hashCode());
        result = prime * result + ((getButMeeting() == null) ? 0 : getButMeeting().hashCode());
        result = prime * result + ((getButAttachjob() == null) ? 0 : getButAttachjob().hashCode());
        result = prime * result + ((getButListen() == null) ? 0 : getButListen().hashCode());
        result = prime * result + ((getButForceInsert() == null) ? 0 : getButForceInsert().hashCode());
        result = prime * result + ((getButForceBackout() == null) ? 0 : getButForceBackout().hashCode());
        result = prime * result + ((getAniText() == null) ? 0 : getAniText().hashCode());
        result = prime * result + ((getDnisText() == null) ? 0 : getDnisText().hashCode());
        result = prime * result + ((getTalkTimeText() == null) ? 0 : getTalkTimeText().hashCode());
        result = prime * result + ((getCurrentStateTimeText() == null) ? 0 : getCurrentStateTimeText().hashCode());
        result = prime * result + ((getTalkCountText() == null) ? 0 : getTalkCountText().hashCode());
        result = prime * result + ((getDialFrame() == null) ? 0 : getDialFrame().hashCode());
        result = prime * result + ((getVer() == null) ? 0 : getVer().hashCode());
        result = prime * result + ((getStopFlag() == null) ? 0 : getStopFlag().hashCode());
        result = prime * result + ((getOutdailNumber() == null) ? 0 : getOutdailNumber().hashCode());
        return result;
    }
}