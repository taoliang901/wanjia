package com.wanjia.issue.service;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.IssueSurvey;

/**
 * This element is automatically generated on 16-8-7 ����9:43, do not modify. <br>
 * Service interface
 */
public interface IssueSurveyService extends IBaseService<IssueSurvey, String> {
}