package com.wanjia.issue.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.model.EasyUIDataGridModel;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.ht.service.HtUserService;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueModel;
import com.wanjia.issue.service.IssueProcessService;
import com.wanjia.issue.service.IssueService;

@Controller
public class MyIssueController extends BaseController{

	private Logger logger = Logger.getLogger(MyIssueController.class);
	
	private final String issue_page ="worksheet/myIssue"; 
	
	private final String receive_issue_page ="worksheet/receiveMyIssue"; 
	
	@Autowired
	private IssueService issueService;
	
	@Autowired
	private HtUserService htUserService;
	
	@Autowired
	private IssueProcessService issueProcessService;
	
	
	@RequestMapping("worksheet/myWorksheet.do")
	public ModelAndView initWorkSheetMgmt(HttpServletRequest request){
		ModelAndView mv = new ModelAndView(issue_page);
		
		String queryType = request.getParameter("queryType");
		Map<String , Object> paramMap = new HashMap<String , Object>();
		paramMap.put("currentUser",getCurrentUser(request));
		//list 
		paramMap.put("callType", "0");
		paramMap.put("status", "0");
		List<Issue> iblist = issueService.searchMyIssueList(paramMap);
		mv.addObject("ibNum", iblist.size());
		//list 
		paramMap.put("callType", "1");
		List<IssueModel> oblist = issueService.searchAssignedOBList(paramMap);
		mv.addObject("obNum", oblist.size());
		//list 
		paramMap.remove("callType");
		paramMap.remove("status");
		paramMap.put("sysdate", "sysdate");
		List<Issue> todayList = issueService.searchMyIssueList(paramMap);
		mv.addObject("todayListNum", todayList.size());
		//list
		paramMap.remove("sysdate");
		List<Issue> allList = issueService.searchMyIssueList(paramMap);
		mv.addObject("allListNum", allList.size());
		/*--以下为20161110添加--*/
        //list 
		paramMap.clear();
        paramMap.put("overtimeType",new String[]{"1","2"});//超时类型--1.口腔产品2.健康险产品
        paramMap.put("currentUser",getCurrentUser(request));
        List<IssueModel> overTimeoblist = issueService.searchAssignedOBList(paramMap);
        mv.addObject("overtimeType", overTimeoblist.size());
		
		mv.addObject("queryType",queryType);
		
		//增加领取按钮权限
		Map<String, Object> map = new HashMap<String,Object>();
		map.put("name", SysConstant.CC_GET_ISSUE_BUTTON);
		request.setAttribute("isShowGetIssueButton", checkUserHasButtonAuth(request,map));
		
		return mv;
	}
	
	@RequestMapping("/worksheet/getMyIssueList.do")
	@ResponseBody
	public EasyUIDataGridModel getMyIssueList(HttpServletRequest request){
		EasyUIDataGridModel dg = new EasyUIDataGridModel();

		String pageNumber = request.getParameter("page");
		String pageSize = request.getParameter("rows");
		//1:呼入处理中，2:呼出处理中 3:我的今日工单 4:我的所有工单 5:预约超时处理中
		String queryType = request.getParameter("queryType"); 
		Map<String , Object> map = new HashMap<String , Object>();
		if(queryType.equals("1")){
			map.put("status", "0");
			map.put("callType", "0");
		}
		if(queryType.equals("2")){
			map.put("status", "0");
			map.put("callType", "1");
		}
		//commented by tl on 12-15 @version
//		if(queryType.equals("3")){
//			map.put("sysdate", "sysdate");
//		}
		
        if(queryType.equals("5")){
            map.put("overtimeType", new String[]{"1","2"});
        }
		
		map.put("currentUser",getCurrentUser(request));

		int pageNo = 1;
	 	int pageS= SysConstant.PAGE_SIZE;
	 	if(!StringUtils.isEmpty(pageNumber)){
	 		pageNo = Integer.parseInt(pageNumber);
	 	}
	 	if(!StringUtils.isEmpty(pageSize)){
	 		pageS = Integer.parseInt(pageSize);
	 	}
	 	PageHelper.startPage(pageNo,pageS );//设置分页页号和页码
	 	if(queryType.equals("1")||queryType.equals("4")){
	 	    List<Issue> list = issueService.searchMyIssueList(map);
            PageInfo page = new PageInfo(list);
            dg.setTotal(page.getTotal());
            dg.setRows(list);
	 	}else if(queryType.equals("2")||queryType.equals("5")){
	 	   List<IssueModel> issueModelList = issueService.searchAssignedOBList(map);
           PageInfo page = new PageInfo(issueModelList);
           dg.setTotal(page.getTotal());
           dg.setRows(issueModelList);
	 	}
		

		return dg;
	}
	
	@RequestMapping("worksheet/refreshIssueNum.do")
	@ResponseBody
	public JsonResponse<Map<String,Object>> refreshIssueNum(HttpServletRequest request){
		JsonResponse<Map<String,Object>> jason = new JsonResponse<Map<String,Object>>();
		Map<String,Object> map = new HashMap<String , Object>();
		
		Map<String , Object> paramMap1 = new HashMap<String , Object>();
		paramMap1.put("currentUser",getCurrentUser(request));
		paramMap1.put("status", "0");
		paramMap1.put("callType", "0");
		List<Issue> ibList = issueService.searchMyIssueList(paramMap1);
		map.put("ibNum", ibList == null? "0":ibList.size());
		
		//list 
		Map<String , Object> paramMap3 = new HashMap<String , Object>();
		paramMap3.put("currentUser",getCurrentUser(request));
		paramMap3.put("sysdate", "sysdate");
		List<Issue> todayList = issueService.searchMyIssueList(paramMap3);
		map.put("todayNum", todayList == null? "0": todayList.size());
		//list
		Map<String , Object> paramMap4 = new HashMap<String , Object>();
		paramMap4.put("currentUser",getCurrentUser(request));
		List<Issue> allList = issueService.searchMyIssueList(paramMap4);
		map.put("totalNum", allList == null ? "0":allList.size());
		
	    //list
        Map<String , Object> paramMap5 = new HashMap<String , Object>();
        paramMap5.put("currentUser",getCurrentUser(request));
        paramMap5.put("status", "0");
        paramMap5.put("callType", "1");
        paramMap5.put("overtimeType",new String[]{"1","2"});//超时类型--1.口腔产品2.健康险产品
        List<IssueModel> overtimeType = issueService.searchAssignedOBList(paramMap5);
        map.put("overtimeType", overtimeType == null ? "0":overtimeType.size());
		
        //list
        Map<String , Object> paramMap2 = new HashMap<String , Object>();
        paramMap2.put("currentUser",getCurrentUser(request));
        paramMap2.put("status", "0");
        paramMap2.put("callType", "1");
        List<IssueModel> oblist = issueService.searchAssignedOBList(paramMap2);
        map.put("obNum", oblist == null? "0":oblist.size());
        
		jason.setResult(map);
		jason.setStatus(JsonResponse.Status.SUCCESS);
		return jason;
	}

	/**
	 * 初始化超时预约领取工单页面
	 * @param request
	 * @return
	 */
	@RequestMapping("worksheet/initReceiveIssue.do")
	public ModelAndView initReceiveIssue(HttpServletRequest request){
		ModelAndView mv = new ModelAndView(receive_issue_page);
		/*1110版本不加此权限
		Map<String, Object> map = new HashMap<String,Object>();
		map.put("name", SysConstant.CC_RECEIVE_BUTTON);
		request.setAttribute("isShowReceiveButton", checkUserHasButtonAuth(request,map));*/
		return mv;
	}
	
	
	@RequestMapping("receive/queryAppointmentIssue.do")
	@ResponseBody
	public EasyUIDataGridModel<IssueModel> queryAppointmentIssue(HttpServletRequest request,String templateId){
		EasyUIDataGridModel<IssueModel> dg = new EasyUIDataGridModel<IssueModel>();
		
		/** 获取分页参数和查询条件 */
		String pageNumber = request.getParameter("page");
		String pageSize = request.getParameter("rows");
		
		/** 获取查询条件 */
		String clinicName = request.getParameter("clinicName");
		String prdName = request.getParameter("prdName");
		
		/** 封装查询条件 */
		Map<String , Object> map = new HashMap<String , Object>();
		
		/** 设置指定标准ID和标准类型 */
		if(StringUtils.isNotEmpty(clinicName))
			map.put("clinicName",clinicName);
		if(StringUtils.isNotEmpty(prdName))
			map.put("prdName",prdName);
		
		/** 设置数据状态为“未删除” */
		map.put("delFlag",SysConstant.NOT_DEL_FLAG);

		/** 设置当前页和分页大小 */
	 	if(StringUtils.isEmpty(pageNumber))
	 		pageNumber = SysConstant.PAGE_START_NUMBER+"";
	 	if(StringUtils.isEmpty(pageSize))
	 		pageSize = SysConstant.PAGE_SIZE+"";
	 	
	 	/** 分页查询认证标准版本信息 */
	 	PageHelper.startPage(Integer.parseInt(pageNumber),Integer.parseInt(pageSize));
		List<IssueModel> list = issueService.queryAppointmentIssue(map);
		PageInfo<IssueModel> page = new PageInfo<IssueModel>(list);
	 	dg.setTotal(page.getTotal());
	 	dg.setRows(list);
		return dg;
	}
	
	/**
	 * 查询工单
	 * @param issueId
	 * @return
	 */
	@RequestMapping("receive/queryIssue.do")
	@ResponseBody
	public JsonResponse<Issue> queryIssue(String issueId){
		JsonResponse<Issue> response = new JsonResponse<Issue>();
		if(StringUtils.isEmpty(issueId)){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("为获取到当前工单id");
			return response;
		}
		
		Issue issue = issueService.findById(issueId);
		if(issue == null || SysConstant.DEL_FLAG.equals(issue.getDelFlag())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("当前工单不存在");
			return response;
		}
		
		response.setStatus(JsonResponse.Status.SUCCESS);
		response.setResult(issue);
		return response;
	}
	
	/**
	 * 领取工单
	 * @param ids
	 * @param request
	 * @return
	 */
	@RequestMapping("receive/receiveIssue.do")
	@ResponseBody
	public JsonResponse<Integer> receiveIssue(@RequestParam(value = "issueIds[]") String[] issueIds ,HttpServletRequest request){
		JsonResponse<Integer> response = new JsonResponse<Integer>();
		if(issueIds==null || issueIds.length<1){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到需要领取的工单");
			return response;
		}
		
		Integer res = issueService.updateReceiveIssues(issueIds, getCurrentUser(request));
		response.setResult(res);
		response.setStatus(JsonResponse.Status.SUCCESS);
		return response;
	}
}
