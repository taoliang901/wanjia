package com.wanjia.issue.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseDao;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueModel;

public interface IssueMapper extends IBaseDao {
	public List<Issue> queryLastIssue(Map<String,Object> map);

	public List<Issue> searchUnassignedIBList();
	
	public List<Issue> searchUnassignedNormalOBList();
	
	public List<Issue> searchUnassignedOTOBList(Map<String,Object> map);

	public List<IssueModel> searchAssignedOBList(Map<String,Object> map);

	
	
	public List<Issue> searchMyIssueList(Map<String,Object> map); 
	
	public List<Issue> getIBList(Map<String,Object> map);
	
	public List<Issue> getNormalOBList(Map<String,Object> map);
	
	public List<Issue> getOTOBList(Map<String,Object> map);
	
	/**
	 * 查询未被指派的预约超时工单
	 * @param map
	 * @return
	 */
	public List<IssueModel> queryAppointmentIssue(Map<String, Object> map);
	
	public int updateReceiveIssue(Map<String,Object> map);
	
	Map<String, Object> findKucun(String cardId);
}