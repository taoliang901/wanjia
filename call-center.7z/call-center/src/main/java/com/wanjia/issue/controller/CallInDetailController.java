package com.wanjia.issue.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.ht.bo.HtUser;
import com.wanjia.ht.service.HtUserService;
import com.wanjia.ht.service.SysAreaCityService;
import com.wanjia.issue.bo.CcIssueType;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueView;
import com.wanjia.issue.enums.ClientType;
import com.wanjia.issue.enums.IsConvey;
import com.wanjia.issue.enums.IssueType;
import com.wanjia.issue.enums.PromiseDayType;
import com.wanjia.issue.service.CcIssueTypeService;
import com.wanjia.issue.service.IssueService;
import com.wanjia.utils.DateUtil;

@Controller
@RequestMapping("/issue/")
public class CallInDetailController extends BaseController{

	private Logger logger = Logger.getLogger(CallInDetailController.class);
	
	@Autowired
	private IssueService issueService;
	@Autowired
	private CcIssueTypeService ccIssueTypeService;
	@Autowired
	private SysAreaCityService sysAreaCityService;
	@Autowired
	private HtUserService htUserService;
	
	/** 初始化页面url */
	private final String init_page_url = "issue/callInDetail";
	
	/**
	 * 呼入页面初始化
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("callInDetail.do")
	public ModelAndView initCallInDetail(HttpServletRequest request,HttpServletResponse response){
		ModelAndView mv = new ModelAndView();
		
		//判断是否需要隐藏申请流转和隐藏按钮
		String hiddenType = request.getParameter("hiddenType");
		mv.addObject("hiddenType", hiddenType);
		
		/** 获取事件id */
		String issueId = request.getParameter("issueId");
		if(StringUtils.isNotBlank(issueId)){
			
			/** 查询事件 */
			Issue issue = issueService.findById(issueId);
			if(issue!=null){
				IssueView iv = new IssueView();
				BeanUtils.copyProperties(issue, iv);
				iv.setClientTypeName(ClientType.getClientTypeDesc(iv.getClientTypeId()));
				iv.setIssueTypeName(IssueType.getIssueTypeDesc(iv.getIssueType()));
				iv.setProvinceName(sysAreaCityService.getAreaByAreaid(iv.getProvincecode()).getName());
				iv.setCityName(sysAreaCityService.getAreaByAreaid(iv.getCitycode()).getName());
				iv.setDistrictName(sysAreaCityService.getAreaByAreaid(iv.getDistrictcode()).getName());
				if(StringUtils.isNotBlank(iv.getPromiseDays())){
					iv.setPromiseDaysName(PromiseDayType.getPromiseDayType(iv.getPromiseDays()).getDesc());
				}
				
				CcIssueType model = new CcIssueType();
				model.setParentCode(issue.getIssueType());
				model.setCode(issue.getIssueTypeSub());
				model.setDelFlag(SysConstant.NOT_DEL_FLAG);
				CcIssueType ccIssueType = ccIssueTypeService.findOneByEntity(model);
				if(ccIssueType!=null){
					iv.setIssueTypeSubName(ccIssueType.getDesc());
				}
				
				iv.setIssueDate(DateUtil.date2String_format(iv.getCallTime(), "yyyy-MM-dd HH:mm:ss"));
				
				Map<String,Object> map = new HashMap<String,Object>();
				map.put("delFlag",SysConstant.NOT_DEL_FLAG);
				map.put("userCode",iv.getHandler());
				List<HtUser> users = htUserService.findByProperties(map);
				if(users!=null && !users.isEmpty()){
					iv.setLastHandlerName(users.get(0).getName());
				}else{
					iv.setLastHandlerName(iv.getHandler());
				}
				
				/** 事件 */
				mv.addObject("issue", iv);
				mv.addObject("redirctPage", request.getParameter("redirctPage"));
			}
			
		}
		
		/** 呼入页面url */
		mv.setViewName(init_page_url);	
		
		mv.addObject("queryType", request.getParameter("queryType"));
		mv.addObject("issueType", request.getParameter("issueType"));
		mv.addObject("issueStatus", request.getParameter("issueStatus"));
		mv.addObject("asignee", request.getParameter("asignee"));
		mv.addObject("beginDate", request.getParameter("beginDate"));
		mv.addObject("endDate", request.getParameter("endDate"));
		mv.addObject("phone", request.getParameter("phone"));
		return mv;
	}
	
	/**
	 * 申请流转
	 * @param request
	 * @return
	 */
	@RequestMapping("applyConvey.do")
	@ResponseBody
	public JsonResponse<Issue> applyConvey(HttpServletRequest request){
		JsonResponse<Issue> response = new JsonResponse<Issue>();
		
		/** 获取工单id */
		String issueId = request.getParameter("issueId");
		if(!StringUtils.isNotBlank(issueId)){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到工单id！");
			return response;
		}
		
		/** 查询工单 */
		Issue model = new Issue();
		model.setId(issueId);
		model.setDelFlag(SysConstant.NOT_DEL_FLAG);
		Issue issue = issueService.findOneByEntity(model);
		if(issue == null){
			logger.info("id为["+issueId+"]的工单不存在");
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("当前工单不存在！");
			return response;
		}
		
		/** 设为已流转 */
		issue.setIsConvey(IsConvey.TRANSFER.getValue());
		
		/** 设置修改人 */
		issue.setModifyDate(new Date());
		issue.setModifyUser(getCurrentUser(request));
		
		try{
			issueService.updateIssue(issue);
		}catch(Exception e){
			e.printStackTrace();
			logger.error("申请id为["+issueId+"]的工单流转时出错！");
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("系统异常！");
			return response;
		}
		
		return response;
	}
	
	
	/**
	 * 查询工单
	 * @param issueId 工单id
	 * @return
	 */
	@RequestMapping("getIssue.do")
	@ResponseBody
	public JsonResponse<Issue> getIssue(String issueId){
		JsonResponse<Issue> response = new JsonResponse<Issue>();
		
		/** 查询工单 */
		if(StringUtils.isNotBlank(issueId)){
			Issue model = new Issue();
			model.setId(issueId);
			model.setDelFlag(SysConstant.NOT_DEL_FLAG);
			Issue issue = issueService.findOneByEntity(model);
			if(issue != null){
				response.setStatus(JsonResponse.Status.SUCCESS);
				response.setResult(issue);
			}
		}else{
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到当前工单id");
		}
		
		return response;
	}
}
