package com.wanjia.issue.service;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.CtiAppletParam;


public interface CtiAppletParamService extends IBaseService<CtiAppletParam, Long> {
	
	List<CtiAppletParam> findByCtiEmployee(Map<String,Object> map);
	
	List<CtiAppletParam> checkLoginAccount(Map<String, Object> map);
	
}