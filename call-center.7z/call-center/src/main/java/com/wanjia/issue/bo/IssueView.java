package com.wanjia.issue.bo;

public class IssueView extends Issue {
	private static final long serialVersionUID = 1L;
	
	private String issueDate;
	
	private String statusName;
	
	private String clientTypeName;
	
	private String provinceName;
	
	private String cityName;
	
	private String districtName;
	
	private String issueTypeName;
	
	private String issueTypeSubName;
	
	private String lastHandlerName;
	
	private String promiseDaysName;

	public String getPromiseDaysName() {
		return promiseDaysName;
	}

	public void setPromiseDaysName(String promiseDaysName) {
		this.promiseDaysName = promiseDaysName;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getClientTypeName() {
		return clientTypeName;
	}

	public void setClientTypeName(String clientTypeName) {
		this.clientTypeName = clientTypeName;
	}

	public String getProvinceName() {
		
		
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getIssueTypeName() {
		return issueTypeName;
	}

	public void setIssueTypeName(String issueTypeName) {
		this.issueTypeName = issueTypeName;
	}

	public String getIssueTypeSubName() {
		return issueTypeSubName;
	}

	public void setIssueTypeSubName(String issueTypeSubName) {
		this.issueTypeSubName = issueTypeSubName;
	}

	public String getLastHandlerName() {
		return lastHandlerName;
	}

	public void setLastHandlerName(String lastHandlerName) {
		this.lastHandlerName = lastHandlerName;
	}

}
