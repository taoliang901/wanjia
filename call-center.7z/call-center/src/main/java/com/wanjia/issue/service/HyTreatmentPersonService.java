package com.wanjia.issue.service;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.HyTreatmentPerson;

/**
 * This element is automatically generated on 16-9-19 ����7:22, do not modify. <br>
 * Service interface
 */
public interface HyTreatmentPersonService extends IBaseService<HyTreatmentPerson, String> {
	String getLoginnameByUserid(String userId);
}