package com.wanjia.issue.bo;

public class IssueModel extends Issue {
    
    private String healthProductName;
    
    private String clinicName;
    
    private String apptStatus;
    
    private String issueSource;
    
    private String rownum;
    
    private String createDateStr;

    private String patientVisitName;
    
    public String getCreateDateStr() {
		return createDateStr;
	}

	public void setCreateDateStr(String createDateStr) {
		this.createDateStr = createDateStr;
	}

	public String getHealthProductName() {
        return healthProductName;
    }

    public void setHealthProductName(String healthProductName) {
        this.healthProductName = healthProductName;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getApptStatus() {
        return apptStatus;
    }

    public void setApptStatus(String apptStatus) {
        this.apptStatus = apptStatus;
    }

	public String getIssueSource() {
		return issueSource;
	}

	public void setIssueSource(String issueSource) {
		this.issueSource = issueSource;
	}

	public String getRownum() {
		return rownum;
	}

	public void setRownum(String rownum) {
		this.rownum = rownum;
	}

    public String getPatientVisitName() {
        return patientVisitName;
    }

    public void setPatientVisitName(String patientVisitName) {
        this.patientVisitName = patientVisitName;
    }
    
}
