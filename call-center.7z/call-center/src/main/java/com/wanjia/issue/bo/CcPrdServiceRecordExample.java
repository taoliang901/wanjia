package com.wanjia.issue.bo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CcPrdServiceRecordExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CcPrdServiceRecordExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andObIdIsNull() {
            addCriterion("OB_ID is null");
            return (Criteria) this;
        }

        public Criteria andObIdIsNotNull() {
            addCriterion("OB_ID is not null");
            return (Criteria) this;
        }

        public Criteria andObIdEqualTo(String value) {
            addCriterion("OB_ID =", value, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdNotEqualTo(String value) {
            addCriterion("OB_ID <>", value, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdGreaterThan(String value) {
            addCriterion("OB_ID >", value, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdGreaterThanOrEqualTo(String value) {
            addCriterion("OB_ID >=", value, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdLessThan(String value) {
            addCriterion("OB_ID <", value, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdLessThanOrEqualTo(String value) {
            addCriterion("OB_ID <=", value, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdLike(String value) {
            addCriterion("OB_ID like", value, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdNotLike(String value) {
            addCriterion("OB_ID not like", value, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdIn(List<String> values) {
            addCriterion("OB_ID in", values, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdNotIn(List<String> values) {
            addCriterion("OB_ID not in", values, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdBetween(String value1, String value2) {
            addCriterion("OB_ID between", value1, value2, "obId");
            return (Criteria) this;
        }

        public Criteria andObIdNotBetween(String value1, String value2) {
            addCriterion("OB_ID not between", value1, value2, "obId");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeIsNull() {
            addCriterion("APPTORDER_CODE is null");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeIsNotNull() {
            addCriterion("APPTORDER_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeEqualTo(String value) {
            addCriterion("APPTORDER_CODE =", value, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeNotEqualTo(String value) {
            addCriterion("APPTORDER_CODE <>", value, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeGreaterThan(String value) {
            addCriterion("APPTORDER_CODE >", value, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeGreaterThanOrEqualTo(String value) {
            addCriterion("APPTORDER_CODE >=", value, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeLessThan(String value) {
            addCriterion("APPTORDER_CODE <", value, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeLessThanOrEqualTo(String value) {
            addCriterion("APPTORDER_CODE <=", value, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeLike(String value) {
            addCriterion("APPTORDER_CODE like", value, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeNotLike(String value) {
            addCriterion("APPTORDER_CODE not like", value, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeIn(List<String> values) {
            addCriterion("APPTORDER_CODE in", values, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeNotIn(List<String> values) {
            addCriterion("APPTORDER_CODE not in", values, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeBetween(String value1, String value2) {
            addCriterion("APPTORDER_CODE between", value1, value2, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeNotBetween(String value1, String value2) {
            addCriterion("APPTORDER_CODE not between", value1, value2, "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptStatusIsNull() {
            addCriterion("APPT_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andApptStatusIsNotNull() {
            addCriterion("APPT_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andApptStatusEqualTo(Integer value) {
            addCriterion("APPT_STATUS =", value, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusNotEqualTo(Integer value) {
            addCriterion("APPT_STATUS <>", value, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusGreaterThan(Integer value) {
            addCriterion("APPT_STATUS >", value, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("APPT_STATUS >=", value, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusLessThan(Integer value) {
            addCriterion("APPT_STATUS <", value, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusLessThanOrEqualTo(Integer value) {
            addCriterion("APPT_STATUS <=", value, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusIn(List<Integer> values) {
            addCriterion("APPT_STATUS in", values, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusNotIn(List<Integer> values) {
            addCriterion("APPT_STATUS not in", values, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusBetween(Integer value1, Integer value2) {
            addCriterion("APPT_STATUS between", value1, value2, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("APPT_STATUS not between", value1, value2, "apptStatus");
            return (Criteria) this;
        }

        public Criteria andApptTimeIsNull() {
            addCriterion("APPT_TIME is null");
            return (Criteria) this;
        }

        public Criteria andApptTimeIsNotNull() {
            addCriterion("APPT_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andApptTimeEqualTo(String value) {
            addCriterion("APPT_TIME =", value, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeNotEqualTo(String value) {
            addCriterion("APPT_TIME <>", value, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeGreaterThan(String value) {
            addCriterion("APPT_TIME >", value, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeGreaterThanOrEqualTo(String value) {
            addCriterion("APPT_TIME >=", value, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeLessThan(String value) {
            addCriterion("APPT_TIME <", value, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeLessThanOrEqualTo(String value) {
            addCriterion("APPT_TIME <=", value, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeLike(String value) {
            addCriterion("APPT_TIME like", value, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeNotLike(String value) {
            addCriterion("APPT_TIME not like", value, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeIn(List<String> values) {
            addCriterion("APPT_TIME in", values, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeNotIn(List<String> values) {
            addCriterion("APPT_TIME not in", values, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeBetween(String value1, String value2) {
            addCriterion("APPT_TIME between", value1, value2, "apptTime");
            return (Criteria) this;
        }

        public Criteria andApptTimeNotBetween(String value1, String value2) {
            addCriterion("APPT_TIME not between", value1, value2, "apptTime");
            return (Criteria) this;
        }

        public Criteria andClinicIdIsNull() {
            addCriterion("CLINIC_ID is null");
            return (Criteria) this;
        }

        public Criteria andClinicIdIsNotNull() {
            addCriterion("CLINIC_ID is not null");
            return (Criteria) this;
        }

        public Criteria andClinicIdEqualTo(String value) {
            addCriterion("CLINIC_ID =", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdNotEqualTo(String value) {
            addCriterion("CLINIC_ID <>", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdGreaterThan(String value) {
            addCriterion("CLINIC_ID >", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_ID >=", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdLessThan(String value) {
            addCriterion("CLINIC_ID <", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_ID <=", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdLike(String value) {
            addCriterion("CLINIC_ID like", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdNotLike(String value) {
            addCriterion("CLINIC_ID not like", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdIn(List<String> values) {
            addCriterion("CLINIC_ID in", values, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdNotIn(List<String> values) {
            addCriterion("CLINIC_ID not in", values, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdBetween(String value1, String value2) {
            addCriterion("CLINIC_ID between", value1, value2, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdNotBetween(String value1, String value2) {
            addCriterion("CLINIC_ID not between", value1, value2, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicNameIsNull() {
            addCriterion("CLINIC_NAME is null");
            return (Criteria) this;
        }

        public Criteria andClinicNameIsNotNull() {
            addCriterion("CLINIC_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andClinicNameEqualTo(String value) {
            addCriterion("CLINIC_NAME =", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotEqualTo(String value) {
            addCriterion("CLINIC_NAME <>", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameGreaterThan(String value) {
            addCriterion("CLINIC_NAME >", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_NAME >=", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLessThan(String value) {
            addCriterion("CLINIC_NAME <", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_NAME <=", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLike(String value) {
            addCriterion("CLINIC_NAME like", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotLike(String value) {
            addCriterion("CLINIC_NAME not like", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameIn(List<String> values) {
            addCriterion("CLINIC_NAME in", values, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotIn(List<String> values) {
            addCriterion("CLINIC_NAME not in", values, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameBetween(String value1, String value2) {
            addCriterion("CLINIC_NAME between", value1, value2, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotBetween(String value1, String value2) {
            addCriterion("CLINIC_NAME not between", value1, value2, "clinicName");
            return (Criteria) this;
        }

        public Criteria andScheduleDateIsNull() {
            addCriterion("SCHEDULE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andScheduleDateIsNotNull() {
            addCriterion("SCHEDULE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andScheduleDateEqualTo(String value) {
            addCriterion("SCHEDULE_DATE =", value, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateNotEqualTo(String value) {
            addCriterion("SCHEDULE_DATE <>", value, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateGreaterThan(String value) {
            addCriterion("SCHEDULE_DATE >", value, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateGreaterThanOrEqualTo(String value) {
            addCriterion("SCHEDULE_DATE >=", value, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateLessThan(String value) {
            addCriterion("SCHEDULE_DATE <", value, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateLessThanOrEqualTo(String value) {
            addCriterion("SCHEDULE_DATE <=", value, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateLike(String value) {
            addCriterion("SCHEDULE_DATE like", value, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateNotLike(String value) {
            addCriterion("SCHEDULE_DATE not like", value, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateIn(List<String> values) {
            addCriterion("SCHEDULE_DATE in", values, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateNotIn(List<String> values) {
            addCriterion("SCHEDULE_DATE not in", values, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateBetween(String value1, String value2) {
            addCriterion("SCHEDULE_DATE between", value1, value2, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andScheduleDateNotBetween(String value1, String value2) {
            addCriterion("SCHEDULE_DATE not between", value1, value2, "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeIsNull() {
            addCriterion("TIME_SPAN_START_TIME is null");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeIsNotNull() {
            addCriterion("TIME_SPAN_START_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeEqualTo(String value) {
            addCriterion("TIME_SPAN_START_TIME =", value, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeNotEqualTo(String value) {
            addCriterion("TIME_SPAN_START_TIME <>", value, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeGreaterThan(String value) {
            addCriterion("TIME_SPAN_START_TIME >", value, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeGreaterThanOrEqualTo(String value) {
            addCriterion("TIME_SPAN_START_TIME >=", value, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeLessThan(String value) {
            addCriterion("TIME_SPAN_START_TIME <", value, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeLessThanOrEqualTo(String value) {
            addCriterion("TIME_SPAN_START_TIME <=", value, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeLike(String value) {
            addCriterion("TIME_SPAN_START_TIME like", value, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeNotLike(String value) {
            addCriterion("TIME_SPAN_START_TIME not like", value, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeIn(List<String> values) {
            addCriterion("TIME_SPAN_START_TIME in", values, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeNotIn(List<String> values) {
            addCriterion("TIME_SPAN_START_TIME not in", values, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeBetween(String value1, String value2) {
            addCriterion("TIME_SPAN_START_TIME between", value1, value2, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeNotBetween(String value1, String value2) {
            addCriterion("TIME_SPAN_START_TIME not between", value1, value2, "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeIsNull() {
            addCriterion("TIME_SPAN_END_TIME is null");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeIsNotNull() {
            addCriterion("TIME_SPAN_END_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeEqualTo(String value) {
            addCriterion("TIME_SPAN_END_TIME =", value, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeNotEqualTo(String value) {
            addCriterion("TIME_SPAN_END_TIME <>", value, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeGreaterThan(String value) {
            addCriterion("TIME_SPAN_END_TIME >", value, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeGreaterThanOrEqualTo(String value) {
            addCriterion("TIME_SPAN_END_TIME >=", value, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeLessThan(String value) {
            addCriterion("TIME_SPAN_END_TIME <", value, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeLessThanOrEqualTo(String value) {
            addCriterion("TIME_SPAN_END_TIME <=", value, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeLike(String value) {
            addCriterion("TIME_SPAN_END_TIME like", value, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeNotLike(String value) {
            addCriterion("TIME_SPAN_END_TIME not like", value, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeIn(List<String> values) {
            addCriterion("TIME_SPAN_END_TIME in", values, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeNotIn(List<String> values) {
            addCriterion("TIME_SPAN_END_TIME not in", values, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeBetween(String value1, String value2) {
            addCriterion("TIME_SPAN_END_TIME between", value1, value2, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeNotBetween(String value1, String value2) {
            addCriterion("TIME_SPAN_END_TIME not between", value1, value2, "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmIsNull() {
            addCriterion("IS_CLINIC_APPT_CONFIRM is null");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmIsNotNull() {
            addCriterion("IS_CLINIC_APPT_CONFIRM is not null");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmEqualTo(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM =", value, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmNotEqualTo(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM <>", value, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmGreaterThan(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM >", value, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmGreaterThanOrEqualTo(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM >=", value, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmLessThan(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM <", value, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmLessThanOrEqualTo(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM <=", value, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmIn(List<Integer> values) {
            addCriterion("IS_CLINIC_APPT_CONFIRM in", values, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmNotIn(List<Integer> values) {
            addCriterion("IS_CLINIC_APPT_CONFIRM not in", values, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmBetween(Integer value1, Integer value2) {
            addCriterion("IS_CLINIC_APPT_CONFIRM between", value1, value2, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmNotBetween(Integer value1, Integer value2) {
            addCriterion("IS_CLINIC_APPT_CONFIRM not between", value1, value2, "isClinicApptConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmIsNull() {
            addCriterion("IS_USER_TREATMENT_CONFIRM is null");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmIsNotNull() {
            addCriterion("IS_USER_TREATMENT_CONFIRM is not null");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmEqualTo(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM =", value, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmNotEqualTo(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM <>", value, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmGreaterThan(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM >", value, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmGreaterThanOrEqualTo(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM >=", value, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmLessThan(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM <", value, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmLessThanOrEqualTo(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM <=", value, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmIn(List<Integer> values) {
            addCriterion("IS_USER_TREATMENT_CONFIRM in", values, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmNotIn(List<Integer> values) {
            addCriterion("IS_USER_TREATMENT_CONFIRM not in", values, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmBetween(Integer value1, Integer value2) {
            addCriterion("IS_USER_TREATMENT_CONFIRM between", value1, value2, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmNotBetween(Integer value1, Integer value2) {
            addCriterion("IS_USER_TREATMENT_CONFIRM not between", value1, value2, "isUserTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmIsNull() {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM is null");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmIsNotNull() {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM is not null");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmEqualTo(Integer value) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM =", value, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmNotEqualTo(Integer value) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM <>", value, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmGreaterThan(Integer value) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM >", value, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmGreaterThanOrEqualTo(Integer value) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM >=", value, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmLessThan(Integer value) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM <", value, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmLessThanOrEqualTo(Integer value) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM <=", value, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmIn(List<Integer> values) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM in", values, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmNotIn(List<Integer> values) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM not in", values, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmBetween(Integer value1, Integer value2) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM between", value1, value2, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andIsClinicTreatmentConfirmNotBetween(Integer value1, Integer value2) {
            addCriterion("IS_CLINIC_TREATMENT_CONFIRM not between", value1, value2, "isClinicTreatmentConfirm");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeIsNull() {
            addCriterion("APPT_CANCEL_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeIsNotNull() {
            addCriterion("APPT_CANCEL_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeEqualTo(String value) {
            addCriterion("APPT_CANCEL_TYPE =", value, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeNotEqualTo(String value) {
            addCriterion("APPT_CANCEL_TYPE <>", value, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeGreaterThan(String value) {
            addCriterion("APPT_CANCEL_TYPE >", value, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeGreaterThanOrEqualTo(String value) {
            addCriterion("APPT_CANCEL_TYPE >=", value, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeLessThan(String value) {
            addCriterion("APPT_CANCEL_TYPE <", value, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeLessThanOrEqualTo(String value) {
            addCriterion("APPT_CANCEL_TYPE <=", value, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeLike(String value) {
            addCriterion("APPT_CANCEL_TYPE like", value, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeNotLike(String value) {
            addCriterion("APPT_CANCEL_TYPE not like", value, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeIn(List<String> values) {
            addCriterion("APPT_CANCEL_TYPE in", values, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeNotIn(List<String> values) {
            addCriterion("APPT_CANCEL_TYPE not in", values, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeBetween(String value1, String value2) {
            addCriterion("APPT_CANCEL_TYPE between", value1, value2, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeNotBetween(String value1, String value2) {
            addCriterion("APPT_CANCEL_TYPE not between", value1, value2, "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andCardIdIsNull() {
            addCriterion("CARD_ID is null");
            return (Criteria) this;
        }

        public Criteria andCardIdIsNotNull() {
            addCriterion("CARD_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCardIdEqualTo(String value) {
            addCriterion("CARD_ID =", value, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdNotEqualTo(String value) {
            addCriterion("CARD_ID <>", value, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdGreaterThan(String value) {
            addCriterion("CARD_ID >", value, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdGreaterThanOrEqualTo(String value) {
            addCriterion("CARD_ID >=", value, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdLessThan(String value) {
            addCriterion("CARD_ID <", value, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdLessThanOrEqualTo(String value) {
            addCriterion("CARD_ID <=", value, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdLike(String value) {
            addCriterion("CARD_ID like", value, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdNotLike(String value) {
            addCriterion("CARD_ID not like", value, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdIn(List<String> values) {
            addCriterion("CARD_ID in", values, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdNotIn(List<String> values) {
            addCriterion("CARD_ID not in", values, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdBetween(String value1, String value2) {
            addCriterion("CARD_ID between", value1, value2, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardIdNotBetween(String value1, String value2) {
            addCriterion("CARD_ID not between", value1, value2, "cardId");
            return (Criteria) this;
        }

        public Criteria andCardNoIsNull() {
            addCriterion("CARD_NO is null");
            return (Criteria) this;
        }

        public Criteria andCardNoIsNotNull() {
            addCriterion("CARD_NO is not null");
            return (Criteria) this;
        }

        public Criteria andCardNoEqualTo(String value) {
            addCriterion("CARD_NO =", value, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoNotEqualTo(String value) {
            addCriterion("CARD_NO <>", value, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoGreaterThan(String value) {
            addCriterion("CARD_NO >", value, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoGreaterThanOrEqualTo(String value) {
            addCriterion("CARD_NO >=", value, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoLessThan(String value) {
            addCriterion("CARD_NO <", value, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoLessThanOrEqualTo(String value) {
            addCriterion("CARD_NO <=", value, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoLike(String value) {
            addCriterion("CARD_NO like", value, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoNotLike(String value) {
            addCriterion("CARD_NO not like", value, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoIn(List<String> values) {
            addCriterion("CARD_NO in", values, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoNotIn(List<String> values) {
            addCriterion("CARD_NO not in", values, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoBetween(String value1, String value2) {
            addCriterion("CARD_NO between", value1, value2, "cardNo");
            return (Criteria) this;
        }

        public Criteria andCardNoNotBetween(String value1, String value2) {
            addCriterion("CARD_NO not between", value1, value2, "cardNo");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdIsNull() {
            addCriterion("HEALTH_PRODUCT_ID is null");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdIsNotNull() {
            addCriterion("HEALTH_PRODUCT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ID =", value, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdNotEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ID <>", value, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdGreaterThan(String value) {
            addCriterion("HEALTH_PRODUCT_ID >", value, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdGreaterThanOrEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ID >=", value, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdLessThan(String value) {
            addCriterion("HEALTH_PRODUCT_ID <", value, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdLessThanOrEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ID <=", value, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdLike(String value) {
            addCriterion("HEALTH_PRODUCT_ID like", value, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdNotLike(String value) {
            addCriterion("HEALTH_PRODUCT_ID not like", value, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdIn(List<String> values) {
            addCriterion("HEALTH_PRODUCT_ID in", values, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdNotIn(List<String> values) {
            addCriterion("HEALTH_PRODUCT_ID not in", values, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdBetween(String value1, String value2) {
            addCriterion("HEALTH_PRODUCT_ID between", value1, value2, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdNotBetween(String value1, String value2) {
            addCriterion("HEALTH_PRODUCT_ID not between", value1, value2, "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameIsNull() {
            addCriterion("HEALTH_PRODUCT_NAME is null");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameIsNotNull() {
            addCriterion("HEALTH_PRODUCT_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_NAME =", value, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameNotEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_NAME <>", value, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameGreaterThan(String value) {
            addCriterion("HEALTH_PRODUCT_NAME >", value, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameGreaterThanOrEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_NAME >=", value, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameLessThan(String value) {
            addCriterion("HEALTH_PRODUCT_NAME <", value, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameLessThanOrEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_NAME <=", value, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameLike(String value) {
            addCriterion("HEALTH_PRODUCT_NAME like", value, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameNotLike(String value) {
            addCriterion("HEALTH_PRODUCT_NAME not like", value, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameIn(List<String> values) {
            addCriterion("HEALTH_PRODUCT_NAME in", values, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameNotIn(List<String> values) {
            addCriterion("HEALTH_PRODUCT_NAME not in", values, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameBetween(String value1, String value2) {
            addCriterion("HEALTH_PRODUCT_NAME between", value1, value2, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameNotBetween(String value1, String value2) {
            addCriterion("HEALTH_PRODUCT_NAME not between", value1, value2, "healthProductName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameIsNull() {
            addCriterion("PRODUCT_TYPE_NAME is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameIsNotNull() {
            addCriterion("PRODUCT_TYPE_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameEqualTo(String value) {
            addCriterion("PRODUCT_TYPE_NAME =", value, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameNotEqualTo(String value) {
            addCriterion("PRODUCT_TYPE_NAME <>", value, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameGreaterThan(String value) {
            addCriterion("PRODUCT_TYPE_NAME >", value, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_TYPE_NAME >=", value, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameLessThan(String value) {
            addCriterion("PRODUCT_TYPE_NAME <", value, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_TYPE_NAME <=", value, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameLike(String value) {
            addCriterion("PRODUCT_TYPE_NAME like", value, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameNotLike(String value) {
            addCriterion("PRODUCT_TYPE_NAME not like", value, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameIn(List<String> values) {
            addCriterion("PRODUCT_TYPE_NAME in", values, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameNotIn(List<String> values) {
            addCriterion("PRODUCT_TYPE_NAME not in", values, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameBetween(String value1, String value2) {
            addCriterion("PRODUCT_TYPE_NAME between", value1, value2, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_TYPE_NAME not between", value1, value2, "productTypeName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdIsNull() {
            addCriterion("HEALTH_PRODUCT_ITEM_ID is null");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdIsNotNull() {
            addCriterion("HEALTH_PRODUCT_ITEM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID =", value, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdNotEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID <>", value, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdGreaterThan(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID >", value, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdGreaterThanOrEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID >=", value, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdLessThan(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID <", value, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdLessThanOrEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID <=", value, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdLike(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID like", value, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdNotLike(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID not like", value, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdIn(List<String> values) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID in", values, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdNotIn(List<String> values) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID not in", values, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdBetween(String value1, String value2) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID between", value1, value2, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdNotBetween(String value1, String value2) {
            addCriterion("HEALTH_PRODUCT_ITEM_ID not between", value1, value2, "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameIsNull() {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME is null");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameIsNotNull() {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME =", value, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameNotEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME <>", value, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameGreaterThan(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME >", value, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameGreaterThanOrEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME >=", value, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameLessThan(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME <", value, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameLessThanOrEqualTo(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME <=", value, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameLike(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME like", value, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameNotLike(String value) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME not like", value, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameIn(List<String> values) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME in", values, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameNotIn(List<String> values) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME not in", values, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameBetween(String value1, String value2) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME between", value1, value2, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameNotBetween(String value1, String value2) {
            addCriterion("HEALTH_PRODUCT_ITEM_NAME not between", value1, value2, "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andClinicScoreIsNull() {
            addCriterion("CLINIC_SCORE is null");
            return (Criteria) this;
        }

        public Criteria andClinicScoreIsNotNull() {
            addCriterion("CLINIC_SCORE is not null");
            return (Criteria) this;
        }

        public Criteria andClinicScoreEqualTo(BigDecimal value) {
            addCriterion("CLINIC_SCORE =", value, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreNotEqualTo(BigDecimal value) {
            addCriterion("CLINIC_SCORE <>", value, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreGreaterThan(BigDecimal value) {
            addCriterion("CLINIC_SCORE >", value, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("CLINIC_SCORE >=", value, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreLessThan(BigDecimal value) {
            addCriterion("CLINIC_SCORE <", value, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreLessThanOrEqualTo(BigDecimal value) {
            addCriterion("CLINIC_SCORE <=", value, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreIn(List<BigDecimal> values) {
            addCriterion("CLINIC_SCORE in", values, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreNotIn(List<BigDecimal> values) {
            addCriterion("CLINIC_SCORE not in", values, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CLINIC_SCORE between", value1, value2, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicScoreNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CLINIC_SCORE not between", value1, value2, "clinicScore");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountIsNull() {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountIsNotNull() {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountEqualTo(Integer value) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT =", value, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountNotEqualTo(Integer value) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT <>", value, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountGreaterThan(Integer value) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT >", value, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT >=", value, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountLessThan(Integer value) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT <", value, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountLessThanOrEqualTo(Integer value) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT <=", value, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountIn(List<Integer> values) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT in", values, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountNotIn(List<Integer> values) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT not in", values, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountBetween(Integer value1, Integer value2) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT between", value1, value2, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andClinicTreatmentConfirmImageCountNotBetween(Integer value1, Integer value2) {
            addCriterion("CLINIC_TREATMENT_CONFIRM_IMAGE_COUNT not between", value1, value2, "clinicTreatmentConfirmImageCount");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNull() {
            addCriterion("USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(String value) {
            addCriterion("USER_ID =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(String value) {
            addCriterion("USER_ID <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(String value) {
            addCriterion("USER_ID >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(String value) {
            addCriterion("USER_ID >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(String value) {
            addCriterion("USER_ID <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(String value) {
            addCriterion("USER_ID <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLike(String value) {
            addCriterion("USER_ID like", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotLike(String value) {
            addCriterion("USER_ID not like", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<String> values) {
            addCriterion("USER_ID in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<String> values) {
            addCriterion("USER_ID not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(String value1, String value2) {
            addCriterion("USER_ID between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(String value1, String value2) {
            addCriterion("USER_ID not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdIsNull() {
            addCriterion("PATIENT_VISIT_ID is null");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdIsNotNull() {
            addCriterion("PATIENT_VISIT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdEqualTo(String value) {
            addCriterion("PATIENT_VISIT_ID =", value, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdNotEqualTo(String value) {
            addCriterion("PATIENT_VISIT_ID <>", value, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdGreaterThan(String value) {
            addCriterion("PATIENT_VISIT_ID >", value, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdGreaterThanOrEqualTo(String value) {
            addCriterion("PATIENT_VISIT_ID >=", value, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdLessThan(String value) {
            addCriterion("PATIENT_VISIT_ID <", value, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdLessThanOrEqualTo(String value) {
            addCriterion("PATIENT_VISIT_ID <=", value, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdLike(String value) {
            addCriterion("PATIENT_VISIT_ID like", value, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdNotLike(String value) {
            addCriterion("PATIENT_VISIT_ID not like", value, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdIn(List<String> values) {
            addCriterion("PATIENT_VISIT_ID in", values, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdNotIn(List<String> values) {
            addCriterion("PATIENT_VISIT_ID not in", values, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdBetween(String value1, String value2) {
            addCriterion("PATIENT_VISIT_ID between", value1, value2, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdNotBetween(String value1, String value2) {
            addCriterion("PATIENT_VISIT_ID not between", value1, value2, "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeIsNull() {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME is null");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeIsNotNull() {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME is not null");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeEqualTo(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME =", value, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeNotEqualTo(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME <>", value, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeGreaterThan(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME >", value, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME >=", value, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeLessThan(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME <", value, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeLessThanOrEqualTo(Integer value) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME <=", value, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeIn(List<Integer> values) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME in", values, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeNotIn(List<Integer> values) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME not in", values, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeBetween(Integer value1, Integer value2) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME between", value1, value2, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsClinicApptConfirmOvertimeNotBetween(Integer value1, Integer value2) {
            addCriterion("IS_CLINIC_APPT_CONFIRM_OVERTIME not between", value1, value2, "isClinicApptConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeIsNull() {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME is null");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeIsNotNull() {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME is not null");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeEqualTo(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME =", value, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeNotEqualTo(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME <>", value, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeGreaterThan(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME >", value, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME >=", value, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeLessThan(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME <", value, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeLessThanOrEqualTo(Integer value) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME <=", value, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeIn(List<Integer> values) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME in", values, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeNotIn(List<Integer> values) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME not in", values, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeBetween(Integer value1, Integer value2) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME between", value1, value2, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andIsUserTreatmentConfirmOvertimeNotBetween(Integer value1, Integer value2) {
            addCriterion("IS_USER_TREATMENT_CONFIRM_OVERTIME not between", value1, value2, "isUserTreatmentConfirmOvertime");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("CREATE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("CREATE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("CREATE_DATE =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("CREATE_DATE <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("CREATE_DATE >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("CREATE_DATE <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("CREATE_DATE in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("CREATE_DATE not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("CREATE_USER is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("CREATE_USER is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("CREATE_USER =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("CREATE_USER <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("CREATE_USER >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("CREATE_USER >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("CREATE_USER <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("CREATE_USER <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("CREATE_USER like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("CREATE_USER not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("CREATE_USER in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("CREATE_USER not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("CREATE_USER between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("CREATE_USER not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNull() {
            addCriterion("MODIFY_DATE is null");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNotNull() {
            addCriterion("MODIFY_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andModifyDateEqualTo(Date value) {
            addCriterion("MODIFY_DATE =", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotEqualTo(Date value) {
            addCriterion("MODIFY_DATE <>", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThan(Date value) {
            addCriterion("MODIFY_DATE >", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE >=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThan(Date value) {
            addCriterion("MODIFY_DATE <", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE <=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateIn(List<Date> values) {
            addCriterion("MODIFY_DATE in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotIn(List<Date> values) {
            addCriterion("MODIFY_DATE not in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE not between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNull() {
            addCriterion("MODIFY_USER is null");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNotNull() {
            addCriterion("MODIFY_USER is not null");
            return (Criteria) this;
        }

        public Criteria andModifyUserEqualTo(String value) {
            addCriterion("MODIFY_USER =", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotEqualTo(String value) {
            addCriterion("MODIFY_USER <>", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThan(String value) {
            addCriterion("MODIFY_USER >", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER >=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThan(String value) {
            addCriterion("MODIFY_USER <", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER <=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLike(String value) {
            addCriterion("MODIFY_USER like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotLike(String value) {
            addCriterion("MODIFY_USER not like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserIn(List<String> values) {
            addCriterion("MODIFY_USER in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotIn(List<String> values) {
            addCriterion("MODIFY_USER not in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserBetween(String value1, String value2) {
            addCriterion("MODIFY_USER between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotBetween(String value1, String value2) {
            addCriterion("MODIFY_USER not between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("DEL_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("DEL_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(String value) {
            addCriterion("DEL_FLAG =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(String value) {
            addCriterion("DEL_FLAG <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(String value) {
            addCriterion("DEL_FLAG >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(String value) {
            addCriterion("DEL_FLAG <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLike(String value) {
            addCriterion("DEL_FLAG like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotLike(String value) {
            addCriterion("DEL_FLAG not like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<String> values) {
            addCriterion("DEL_FLAG in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<String> values) {
            addCriterion("DEL_FLAG not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(String value1, String value2) {
            addCriterion("DEL_FLAG between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(String value1, String value2) {
            addCriterion("DEL_FLAG not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andIdLikeInsensitive(String value) {
            addCriterion("upper(ID) like", value.toUpperCase(), "id");
            return (Criteria) this;
        }

        public Criteria andObIdLikeInsensitive(String value) {
            addCriterion("upper(OB_ID) like", value.toUpperCase(), "obId");
            return (Criteria) this;
        }

        public Criteria andApptorderCodeLikeInsensitive(String value) {
            addCriterion("upper(APPTORDER_CODE) like", value.toUpperCase(), "apptorderCode");
            return (Criteria) this;
        }

        public Criteria andApptTimeLikeInsensitive(String value) {
            addCriterion("upper(APPT_TIME) like", value.toUpperCase(), "apptTime");
            return (Criteria) this;
        }

        public Criteria andClinicIdLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_ID) like", value.toUpperCase(), "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicNameLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_NAME) like", value.toUpperCase(), "clinicName");
            return (Criteria) this;
        }

        public Criteria andScheduleDateLikeInsensitive(String value) {
            addCriterion("upper(SCHEDULE_DATE) like", value.toUpperCase(), "scheduleDate");
            return (Criteria) this;
        }

        public Criteria andTimeSpanStartTimeLikeInsensitive(String value) {
            addCriterion("upper(TIME_SPAN_START_TIME) like", value.toUpperCase(), "timeSpanStartTime");
            return (Criteria) this;
        }

        public Criteria andTimeSpanEndTimeLikeInsensitive(String value) {
            addCriterion("upper(TIME_SPAN_END_TIME) like", value.toUpperCase(), "timeSpanEndTime");
            return (Criteria) this;
        }

        public Criteria andApptCancelTypeLikeInsensitive(String value) {
            addCriterion("upper(APPT_CANCEL_TYPE) like", value.toUpperCase(), "apptCancelType");
            return (Criteria) this;
        }

        public Criteria andCardIdLikeInsensitive(String value) {
            addCriterion("upper(CARD_ID) like", value.toUpperCase(), "cardId");
            return (Criteria) this;
        }

        public Criteria andCardNoLikeInsensitive(String value) {
            addCriterion("upper(CARD_NO) like", value.toUpperCase(), "cardNo");
            return (Criteria) this;
        }

        public Criteria andHealthProductIdLikeInsensitive(String value) {
            addCriterion("upper(HEALTH_PRODUCT_ID) like", value.toUpperCase(), "healthProductId");
            return (Criteria) this;
        }

        public Criteria andHealthProductNameLikeInsensitive(String value) {
            addCriterion("upper(HEALTH_PRODUCT_NAME) like", value.toUpperCase(), "healthProductName");
            return (Criteria) this;
        }

        public Criteria andProductTypeNameLikeInsensitive(String value) {
            addCriterion("upper(PRODUCT_TYPE_NAME) like", value.toUpperCase(), "productTypeName");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemIdLikeInsensitive(String value) {
            addCriterion("upper(HEALTH_PRODUCT_ITEM_ID) like", value.toUpperCase(), "healthProductItemId");
            return (Criteria) this;
        }

        public Criteria andHealthProductItemNameLikeInsensitive(String value) {
            addCriterion("upper(HEALTH_PRODUCT_ITEM_NAME) like", value.toUpperCase(), "healthProductItemName");
            return (Criteria) this;
        }

        public Criteria andUserIdLikeInsensitive(String value) {
            addCriterion("upper(USER_ID) like", value.toUpperCase(), "userId");
            return (Criteria) this;
        }

        public Criteria andPatientVisitIdLikeInsensitive(String value) {
            addCriterion("upper(PATIENT_VISIT_ID) like", value.toUpperCase(), "patientVisitId");
            return (Criteria) this;
        }

        public Criteria andCreateUserLikeInsensitive(String value) {
            addCriterion("upper(CREATE_USER) like", value.toUpperCase(), "createUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLikeInsensitive(String value) {
            addCriterion("upper(MODIFY_USER) like", value.toUpperCase(), "modifyUser");
            return (Criteria) this;
        }

        public Criteria andDelFlagLikeInsensitive(String value) {
            addCriterion("upper(DEL_FLAG) like", value.toUpperCase(), "delFlag");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}