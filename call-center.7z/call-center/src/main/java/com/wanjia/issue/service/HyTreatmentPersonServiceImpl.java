package com.wanjia.issue.service;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.issue.bo.HyTreatmentPerson;
import com.wanjia.issue.dao.HyTreatmentPersonMapper;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-9-19 ����7:22, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class HyTreatmentPersonServiceImpl implements HyTreatmentPersonService {
    @Autowired
    private HyTreatmentPersonMapper hyTreatmentPersonMapper;

    @Override
    @Transactional(readOnly=true)
    public HyTreatmentPerson findById(String id) {
        return (HyTreatmentPerson)hyTreatmentPersonMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<HyTreatmentPerson> findWithPagination(int offset, int count) {
        return (List<HyTreatmentPerson>)hyTreatmentPersonMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<HyTreatmentPerson> findAll() {
        return (List<HyTreatmentPerson>)hyTreatmentPersonMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<HyTreatmentPerson> findByEntity(HyTreatmentPerson model) {
        return (List<HyTreatmentPerson>)hyTreatmentPersonMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<HyTreatmentPerson> findByEntityWithPagination(HyTreatmentPerson model, int offset, int count) {
        return (List<HyTreatmentPerson>)hyTreatmentPersonMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public HyTreatmentPerson findOneByEntity(HyTreatmentPerson model) {
        return (HyTreatmentPerson)hyTreatmentPersonMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<HyTreatmentPerson> findByProperty(String propertyName, String propertyValue) {
        return (List<HyTreatmentPerson>)hyTreatmentPersonMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public HyTreatmentPerson findOneByProperty(String propertyName, String propertyValue) {
        return (HyTreatmentPerson)hyTreatmentPersonMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<HyTreatmentPerson> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<HyTreatmentPerson>)hyTreatmentPersonMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<HyTreatmentPerson> findByProperties(Map<String, Object> map) {
        return (List<HyTreatmentPerson>)hyTreatmentPersonMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(HyTreatmentPerson model) {
        return (long)hyTreatmentPersonMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)hyTreatmentPersonMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)hyTreatmentPersonMapper.countByProperties(map);
    }

    @Override
    public void update(HyTreatmentPerson model) {
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        hyTreatmentPersonMapper.update(model);
    }

    @Override
    public void insert(HyTreatmentPerson model) {
//        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        hyTreatmentPersonMapper.insert(model);
    }

    @Override
    public void deleteByEntity(HyTreatmentPerson model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        hyTreatmentPersonMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.hyTreatmentPersonMapper.countAll();
    }

    public void insertBatch(List<HyTreatmentPerson> list) {
        this.hyTreatmentPersonMapper.insertBatch(list);
    }

    public void delete(String id) {
        HyTreatmentPerson model = new HyTreatmentPerson();
        model.setDelFlag(SysConstant.DEL_FLAG);
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setVisitId(id);
        this.hyTreatmentPersonMapper.update(model);
    }

	@Override
	public String getLoginnameByUserid(String userId) {
		return hyTreatmentPersonMapper.getLoginnameByUserid(userId);
	}
}