package com.wanjia.issue.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.utils.ExcelUtil;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.github.pagehelper.StringUtil;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueOBInfoModel;
import com.wanjia.issue.service.IssueService;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.model.EasyUIDataGridModel;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.issue.service.IssueOBInfoService;
import com.wanjia.issue.bo.IssueOBInfo;
import com.wanjia.knowledge.bo.CcSurvey;
import com.wanjia.knowledge.service.CcSurveyService;
import com.wanjia.ht.service.SysAreaCityService;
import com.wanjia.ht.bo.SysAreaCity;

@Controller
public class UploadIssueController extends BaseController{

	private Logger logger = Logger.getLogger(UploadIssueController.class);
	
	@Autowired
	private IssueService issueService;
	@Autowired
	private IssueOBInfoService issueOBInfoService;
	@Autowired
	private SysAreaCityService sysAreaCityService;
	@Autowired
	private CcSurveyService ccSurveyService;
	
	private static final String INPUT = "This should go to the output.";  
	 
	
	@Value("#{config['OB_ISSUE_TEMPLATE']}")
	private String templateURL;
	
	@RequestMapping("businessMgmt/uploadPage.do")
	public ModelAndView initWorkSheetMgmt(HttpServletRequest request){
		ModelAndView mv = new ModelAndView("businessMgmt/uploadPage");
		return mv;
	}
	
	@RequestMapping("businessMgmt/getUploadList.do")
	@ResponseBody
	public EasyUIDataGridModel getMyIssueList(HttpServletRequest request){
		EasyUIDataGridModel dg = new EasyUIDataGridModel();
		
		String pageNumber = request.getParameter("page");
		String pageSize = request.getParameter("rows");
		
		int pageNo = 1;
	 	int pageS= SysConstant.PAGE_SIZE;
	 	if(!StringUtils.isEmpty(pageNumber)){
	 		pageNo = Integer.parseInt(pageNumber);
	 	}
	 	if(!StringUtils.isEmpty(pageSize)){
	 		pageS = Integer.parseInt(pageSize);
	 	}
	 	PageHelper.startPage(pageNo,pageS );//设置分页页号和页码
	 	
	 	Map<String , Object> map = new HashMap<String , Object>();
	 //	List<Issue> list = issueService.findByProperties(map);
	 	List<IssueOBInfoModel> list = issueOBInfoService.searchUploadInfo(map);
		PageInfo page = new PageInfo(list);
	 	dg.setTotal(page.getTotal());
	 	dg.setRows(list);
	 	
	 	return dg; 
	}
	
	@RequestMapping("businessMgmt/downloadTemplate.do")
	public void export(HttpServletRequest request, HttpServletResponse response) {
	//	String nfs = "E:\\uploadOBIssue.xlsx"; 
	//	FileInputStream inputStream = null;
		OutputStream os = null;
     //   response.setHeader("Pragma", "public");
	//	response.setHeader("Cache-Control", "max-age=0"); 
		try {
			logger.info("templateURL...." + templateURL);
			File file = new File(templateURL);
			
			//1.设置文件ContentType类型，这样设置，会自动判断下载文件类型  
			response.setContentType("multipart/form-data");
			//response.setContentType("application/x-msdownload");
			
			//2.设置文件头：最后一个参数是设置下载文件名
			response.setHeader("Content-Disposition", "attachment;filename=" + ExcelUtil.encodeFileNameForDownload(request, file.getName()));
	
//			inputStream = new FileInputStream(file);
			os = response.getOutputStream();  
		/*	
			byte[] b = new byte[1024];  
			while(inputStream.read(b)!= -1){ 
				os.write(b);     
			}
			os.flush();*/
//			FileUtils.readFileToByteArray(file);
			os.write(FileUtils.readFileToByteArray(file));
			
		}catch(Exception e){
			e.printStackTrace();
			logger.error("没有找到工单上传模板");
		}finally{
			try {
				os.flush();
				os.close();
			} catch (IOException e) {	
				e.printStackTrace();
			}
			
		}
    
	}
	
	
	@RequestMapping("businessMgmt/uploadFile.do")
	@ResponseBody
	public String uploadFile(@RequestParam("excelUpload") MultipartFile[] files, HttpServletRequest request, HttpServletResponse response) {
		response.setContentType("text/html;charset=UTF-8");  
		String result = "";
		JsonResponse<String> resp = new JsonResponse<String>();
		String surveyId = request.getParameter("surveyId");
		int num = 0;
		int invalidNum = 0;
		//boolean isE2007 = false;		
		try{
			List<Issue> issueList = new ArrayList<Issue>();
			List<IssueOBInfo> obList = new ArrayList<IssueOBInfo>();
			
			MultipartFile fileToUpload = null;
			for (int i = 0; i < files.length; i++) {
				fileToUpload = files[i];			
				if (!fileToUpload.isEmpty()) {
					break;
				}
			}
			logger.info("上传文件名为:" + fileToUpload.getOriginalFilename());
		//	if(fileToUpload.getOriginalFilename().endsWith("xlsx")){
				//isE2007 = true;  
		//	}  
			InputStream input = fileToUpload.getInputStream();
			
			Workbook wb  = new XSSFWorkbook(input);  
			Sheet sheet = wb.getSheetAt(0);     //获得第一个表单  
            int rowNum = sheet.getLastRowNum(); //获得第一个表单的迭代器  
            
            for(int i = 1 ; i <= rowNum; i++) {  
            	Row row = sheet.getRow(i);  //获得行数据  
            	 //插入工单表
            	 Issue issue = new Issue();
            	 issue.setId(UUID.randomUUID().toString());
            	 issue.setIssueCode(issue.getId());
            	 issue.setCallType(SysConstant.OB_TYPE);
            	 //客户名称	  
            	 if(row.getCell(0)==null){
            		 continue;
            	 }
            	 issue.setClientName(getCellValue(row.getCell(0),false));
            	 //联系方式
            	 if(row.getCell(1) == null){
            		 continue;
            	 }
            	 Map<String , Object> paramMap = new HashMap<String , Object>();
            	 paramMap.put("phone", getCellValue(row.getCell(1),true));
            	 paramMap.put("surveyId", surveyId);
            	 String invalidNo = issueOBInfoService.checkIfExistingOBIssue(paramMap);
            	 if(StringUtils.isNotEmpty(invalidNo) && Integer.valueOf(invalidNo)>0){
            		 invalidNum ++ ;
            		 continue;
            	 }
            	 issue.setPhone(getCellValue(row.getCell(1),true));
            	 //城市
            	
            	 if(row.getCell(4) != null && StringUtil.isNotEmpty(getCellValue(row.getCell(4),false))){
            		 //查询城市code
            		 SysAreaCity areaModel = new SysAreaCity();
                	 areaModel.setName(getCellValue(row.getCell(4),false));
                	 areaModel.setDelFlag(SysConstant.NOT_DEL_FLAG);
                	 areaModel = sysAreaCityService.findOneByEntity(areaModel);
                	 if(areaModel != null){
                		 issue.setCitycode(areaModel.getAreaId());
                	 }      	 
            	 }
            	 CcSurvey ccSurvey = ccSurveyService.findById(surveyId);
    			 issue.setIssueTopic(ccSurvey.getSurveyName());
    				
            	 issue.setStatus("0");
            	 issue.setIsConvey("0");
            	 issue.setCreateUser(SysConstant.SOURCE_EXPORT);
            	 issue.setDelFlag(SysConstant.NOT_DEL_FLAG);
            	 issue.setCreateDate(new Date());
            	 issueList.add(issue);
            	
            	 //插入OB工单详情表
            	 String type = getCellValue(row.getCell(2),false);
            	 String clinicName = getCellValue(row.getCell(3),false);
            	 String approveStatus = getCellValue(row.getCell(5),false);
            	 String rz_status = getCellValue(row.getCell(6),false);
            	 String remark = getCellValue(row.getCell(7),false);
            	 
            	 IssueOBInfo model = new IssueOBInfo();
            	 model.setId(UUID.randomUUID().toString());
            	 model.setIssueId(issue.getId());
            	 model.setSurveyId(surveyId); //调研问卷ID
            	 model.setBusinessType(type);
            	 model.setClinicName(clinicName);
            	 model.setRzStatus(rz_status);
            	 model.setApproveStatus(approveStatus);
            	 model.setRemark(remark);
            	 model.setSeq(issueOBInfoService.searchMaxSeq());
            	// model.setCreateUser(getCurrentUser(request));
            	 model.setCreateUser(SysConstant.SOURCE_EXPORT);
            	 model.setDelFlag(SysConstant.NOT_DEL_FLAG);
            	 model.setCreateDate(new Date());
            	 obList.add(model);
            	 
            	 num ++;//上传成功纪录条数 
            }
            if(num > 0){
            	 issueOBInfoService.createUploadIssue(issueList,obList);
            }
          
            resp.setResult(String.valueOf(num));
            resp.setStatus(Status.SUCCESS);
            String warningMessage = "";
            if(invalidNum > 0){
            	warningMessage = ",存在重复记录 "+invalidNum + " 条";
            }
            result = String.valueOf(num);
         
    		logger.info("上传成功纪录条数-----" + num);
		}catch(Exception e){
			e.printStackTrace();
			logger.error("文件上传错误，请确保上传的内容正确！");
			result = "0";
		//	resp.setStatus(Status.ERROR);
		}	
		
		return result;
	}
	
	private String getCellValue(Cell cell,boolean isFormatPhone){
		DecimalFormat df = new DecimalFormat("#"); 
		String cellValue = "";   
		if(cell==null){
			return cellValue;
		}
		switch (cell.getCellType()) {      
			case Cell.CELL_TYPE_STRING://字符串类型   		
				cellValue = cell.getStringCellValue();      
	            if(StringUtil.isEmpty(cellValue)){
	            	cellValue="";      
	            }      
	                
	            break;  
			 case Cell.CELL_TYPE_NUMERIC: //数值类型   
				 if(isFormatPhone){
					 cellValue = df.format(cell.getNumericCellValue());
				 }else{
					 cellValue = String.valueOf(cell.getNumericCellValue());      
				 }
		         break;      
			 case Cell.CELL_TYPE_BLANK:      
		         cellValue=" ";      
		         break;
		     case Cell.CELL_TYPE_ERROR:      
		         break;  
			 default:      
		         break;      
		}
		return cellValue;      
		
	}
	

}
