package com.wanjia.issue.service;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.CcPrdServiceRecord;

/**
 * This element is automatically generated on 16-9-19 ����5:56, do not modify. <br>
 * Service interface
 */
public interface CcPrdServiceRecordService extends IBaseService<CcPrdServiceRecord, String> {
	
	public CcPrdServiceRecord updateLatestOneByEntity(CcPrdServiceRecord model);
}