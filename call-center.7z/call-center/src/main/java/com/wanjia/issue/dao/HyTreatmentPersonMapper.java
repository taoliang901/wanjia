package com.wanjia.issue.dao;

import com.wanjia.base.IBaseDao;

public interface HyTreatmentPersonMapper extends IBaseDao {
	String getLoginnameByUserid(String userId);
}