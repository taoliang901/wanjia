package com.wanjia.issue.controller;

import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.pinganwj.clinic.api.EvaluationApiService;
import com.pinganwj.clinic.api.domain.Evaluation.EvaluationInfo;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.ht.bo.HtUser;
import com.wanjia.ht.bo.SysAreaCity;
import com.wanjia.ht.service.HtUserService;
import com.wanjia.ht.service.SysAreaCityService;
import com.wanjia.issue.bo.CcPrdServiceRecord;
import com.wanjia.issue.bo.ClinicInfo;
import com.wanjia.issue.bo.HyTreatmentPerson;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueAbnormalLog;
import com.wanjia.issue.bo.IssueOBInfo;
import com.wanjia.issue.enums.CallType;
import com.wanjia.issue.enums.IssueStatus;
import com.wanjia.issue.service.CcPrdServiceRecordService;
import com.wanjia.issue.service.ClinicInfoService;
import com.wanjia.issue.service.HyTreatmentPersonService;
import com.wanjia.issue.service.IssueAbnormalLogService;
import com.wanjia.issue.service.IssueOBInfoService;
import com.wanjia.issue.service.IssueService;
import com.wanjia.issue.service.IssueSurveyService;
import com.wanjia.knowledge.bo.SurveyAnswer;
import com.wanjia.knowledge.bo.SurveySubjectModel;
import com.wanjia.knowledge.enums.SubjectType;
import com.wanjia.knowledge.service.CcSurveySubjectService;
import com.wanjia.knowledge.service.SurveyAnswerService;
import com.wanjia.utils.DateUtil;

@Controller
@RequestMapping("/issue/")
public class CallOutController extends BaseController{

	private Logger logger = Logger.getLogger(CallOutController.class);
	
	@Autowired
	private IssueService issueService;
	@Autowired
	private IssueOBInfoService issueOBInfoService;
	@Autowired
	private SysAreaCityService sysAreaCityService;
	@Autowired
	private IssueSurveyService issueSurveyService;
	@Autowired
	private CcSurveySubjectService ccSurveySubjectService;
	@Autowired
	private SurveyAnswerService surveyAnswerService;
	@Autowired
	private IssueAbnormalLogService issueAbnormalLogService;
	@Autowired
	private CcPrdServiceRecordService ccPrdServiceRecordService;
	@Autowired
	private HyTreatmentPersonService hyTreatmentPersonService;
	@Autowired
	private ClinicInfoService clinicInfoService;
	@Autowired
	private HtUserService htUserService;
	
	@Autowired
	private EvaluationApiService evaluationApiService;
	
	/** 初始化呼出调研页面url */
	private final String init_page_url = "issue/callOut";
	/** 初始化呼出调研详情页面url */
	private final String init_detail_page_url = "issue/callOutDetail";
	
	/**
	 * 呼出调研页面初始化
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("callOut.do")
	public ModelAndView initCallOut(HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		
		/** 校验事件id */
		String issueId = request.getParameter("issueId");
		if(StringUtils.isNotBlank(issueId)){
			Issue issue = issueService.findById(issueId);
			if(issue != null){
				/** 查询城市名 */
				Map<String,Object> citymap = new HashMap<String,Object>(2);
				citymap.put("areaId", issue.getCitycode());
				citymap.put("delFlag", SysConstant.NOT_DEL_FLAG);
				List<SysAreaCity> cities = sysAreaCityService.findByProperties(citymap);
				if(cities !=null && !cities.isEmpty()){
					issue.setCity(cities.get(0).getName());
				}
				mv.addObject("issue",issue);
				
				/**异常记录**/
				Map<String, Object> logMap = new HashMap<String, Object>(); 
				logMap.put("issueId",issueId);
				logMap.put("delFlag",SysConstant.NOT_DEL_FLAG);
				List<IssueAbnormalLog> logList =  issueAbnormalLogService.findByProperties(logMap);
				mv.addObject("logList",logList);
				if(logList != null && logList.size () > 0){
					int num= logList.size()+1;
					String recordNum = " (第"+num+"次呼出)";
					mv.addObject("recordNum",recordNum);
				}
	
				/** 获取呼出调研工单诊所属性 */
				Map<String,Object> map = new HashMap<String,Object>();
				map.put("issueId", issueId);
				map.put("delFlag", SysConstant.NOT_DEL_FLAG);
				List<IssueOBInfo> obInfos = issueOBInfoService.findByProperties(map);
				if(obInfos !=null && !obInfos.isEmpty()){
					mv.addObject("obInfo",obInfos.get(0));
					mv.addObject("surveyId",obInfos.get(0).getSurveyId());
					
					/** 获取预约明细 */
					IssueOBInfo obinfo = obInfos.get(0);
					if(obinfo!=null&&"1".equals(obinfo.getObType())){
						CcPrdServiceRecord model = new CcPrdServiceRecord();
						model.setObId(obinfo.getId());
						model.setDelFlag(SysConstant.NOT_DEL_FLAG);
						CcPrdServiceRecord prdService = ccPrdServiceRecordService.updateLatestOneByEntity(model);			
						
						if(prdService!=null){
							if(prdService.getApptTime()!=null){
								mv.addObject("apptTime",prdService.getApptTime());
							}
							if(prdService.getScheduleDate()!=null){
								mv.addObject("scheduleDate",prdService.getScheduleDate().substring(0, 10)+" "+prdService.getTimeSpanStartTime());
							}
							
							/** 获取卡号 */
							String cardId = prdService.getCardId();
							if(StringUtils.isNotBlank(cardId)){
								Map<String,Object> kucun = issueService.findKucun(cardId);
								if(kucun != null && kucun.get("all_card_no")!=null && !"".equals(kucun.get("all_card_no"))){
									prdService.setCardNo(kucun.get("all_card_no")+"");
								}else{
									prdService.setCardNo(cardId);
								}
							}
							
							/** 获取就诊人名称 */
							/*if(prdService.getPatientVisitId()!=null){
								HyTreatmentPerson hyTreatmentPerson = hyTreatmentPersonService.findById(prdService.getPatientVisitId());
								if (hyTreatmentPerson != null && hyTreatmentPerson.getVisitName() != null
										&& !"".equals(hyTreatmentPerson.getVisitName())) {
									prdService.setPatientVisitName(hyTreatmentPerson.getVisitName());
								}
							}*/
							
							/** 获取诊所电话 */
							if(prdService.getClinicId()!=null){
								ClinicInfo ClinicInfo = clinicInfoService.findById(prdService.getClinicId());
								if(ClinicInfo!=null){
									if(ClinicInfo.getPhone()!=null&&!"".equals(ClinicInfo.getPhone())){
										prdService.setClinicPhone(ClinicInfo.getPhone());
									}else if(ClinicInfo.getMobile()!=null&&!"".equals(ClinicInfo.getMobile())){
										prdService.setClinicPhone(ClinicInfo.getMobile());
									}
								}
							}
							
							/** 获取预约账户 */
							if(prdService.getAgentUserId()!=null && !"".equals(prdService.getAgentUserId())){
								/*String loginName = hyTreatmentPersonService.getLoginnameByUserid(prdService.getUserId());
								if(loginName!=null&&!"".equals(loginName)){
									prdService.setLoginName(loginName);
								}*/
								
								HtUser htUser = htUserService.getHtUserById(prdService.getAgentUserId());
								if(htUser!=null){
									prdService.setLoginName(htUser.getName());
								}
							}
							
							mv.addObject("prdService",prdService);
						}
					}
					
					/** 查询调研卷 */
					map.clear();
					map.put("surveyId", obInfos.get(0).getSurveyId());
					List<SurveySubjectModel> subjects = ccSurveySubjectService.getSubjectBySurvey(map);
					if(subjects !=null && !subjects.isEmpty()){
						
						boolean isAllDesc = true;
						boolean isAllSingleAndDesc = true;
						
						for(SurveySubjectModel model : subjects){
							/** 存在不是单选题的题目 */
							if(!SubjectType.SINGLE.getValue().equals(model.getSubjectType())){
								mv.addObject("isAllSingle","N");
							}
							
							//只存在描述题
							if(!SubjectType.DESCRIPTION.getValue().equals(model.getSubjectType())){
								isAllDesc = false;
							}
							
							//存在单选加描述题
							if(SubjectType.MULTI.getValue().equals(model.getSubjectType())
									|| SubjectType.RANK.getValue().equals(model.getSubjectType())){
								isAllSingleAndDesc = false;
							}
							
							if(isAllSingleAndDesc && !isAllDesc){
								mv.addObject("isAllSingleAndDesc","Y");
							}
							
							/** 判断评分题会出现几组 */
							if(SubjectType.RANK.getValue().equals(model.getSubjectType())){
								Integer pfCount = model.getSurveyOptionList().size()-1;
								model.setPfCount(pfCount+"");
							}
						}
						mv.addObject("subjectInfo",subjects);
						mv.addObject("subjectCount",subjects.size());
					}else{
						mv.addObject("subjectCount",0);
					}
				}
			}
		}
		
		/** 打开软电话开关 */
		mv.addObject("ctiSwitch",true);
		
		/** 呼入页面url */
		mv.setViewName(init_page_url);	
		
		/** 用于从我的工单页面进详情后的返回标识 */
		mv.addObject("backType", request.getParameter("backType"));
		return mv;
	}
	
	/**
	 * 提交坐席工单事件
	 * @param request
	 * @param issue 参数对象
	 * @return
	 */
	@RequestMapping("saveCallOut.do")
	@ResponseBody
	public JsonResponse<Void> saveCallOut(HttpServletRequest request,@RequestParam(value = "answers[]") String[] answers,String issueId,String surveyId){
		JsonResponse<Void> response = new JsonResponse<Void>();
		/** 校验工单ID */
		if(!StringUtils.isNotBlank(issueId)){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到工单ID！");
			return response;
		}
		
		Issue issue = issueService.findById(issueId);
		if(issue!=null && IssueStatus.SOLVED.getValue().equals(issue.getStatus())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("当前工单状态为[已解决]，不允许再次提交！");
			return response;
		}
		
		/** 校验调研卷ID */
		if(!StringUtils.isNotBlank(surveyId)){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到调研卷ID！");
			return response;
		}
		
		/** 校验答案 */
		if(answers == null || answers.length == 0){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到调研答案！");
			return response;
		}
		
		List<SurveyAnswer> list = new ArrayList<SurveyAnswer>();
		for(String str : answers){
			String[] answer = str.split("\\|\\|");
			if(answer.length>=3){//可能由于跳题导致答案为空，所以没有答案的题目属于跳题，不需要检索保存答案
				String subjectId = answer[0];
				String subjectType = answer[1];
				String subjectAnswer = answer[2];
				
				SurveyAnswer sa = new SurveyAnswer();
				sa.setId(UUID.randomUUID().toString());
				sa.setIssueId(issueId);
				sa.setSurveyId(surveyId);
				sa.setSubjectId(subjectId);
				sa.setSubjectType(subjectType);
				sa.setAnswer(subjectAnswer);
				sa.setCreateUser(getCurrentUser(request));
				sa.setCreateDate(new Date());
				sa.setDelFlag(SysConstant.NOT_DEL_FLAG);
				list.add(sa);
			}
		}
		try{
			surveyAnswerService.insertAnswers(list);
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			e.printStackTrace();
			logger.error("保存工单["+issueId+"]关联的问卷["+surveyId+"]答案出错！");
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("提交工单出错！");
		}
		return response;
	}
	
	/**
	 * 呼出调研详情页面初始化
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("callOutDetail.do")
	public ModelAndView callOutDetail(HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		try{
			/** 校验事件id */
			String issueId = request.getParameter("issueId");
			if(StringUtils.isNotBlank(issueId)){
				Issue issue = issueService.findById(issueId);
				if(issue != null){
					/** 查询城市名 */
					Map<String,Object> citymap = new HashMap<String,Object>(2);
					citymap.put("areaId", issue.getCitycode());
					citymap.put("delFlag", SysConstant.NOT_DEL_FLAG);
					List<SysAreaCity> cities = sysAreaCityService.findByProperties(citymap);
					if(cities !=null && !cities.isEmpty()){
						issue.setCity(cities.get(0).getName());
					}
					mv.addObject("issue",issue);
					
					/** 获取呼出时间 */
					if(issue.getModifyDate()!=null){
						String CalloutTime = DateUtil.date2String_format(issue.getModifyDate(), "yyyy-MM-dd HH:mm:ss");
						mv.addObject("CalloutTime",CalloutTime);
					}
					/**异常记录**/
					mv.addObject("logList",getAbnormalLogList(issueId));
					
					/** 获取呼出调研工单诊所属性 */
					Map<String,Object> map = new HashMap<String,Object>();
					map.put("issueId", issueId);
					map.put("delFlag", SysConstant.NOT_DEL_FLAG);
					List<IssueOBInfo> obInfos = issueOBInfoService.findByProperties(map);
					if(obInfos !=null && !obInfos.isEmpty()){
						mv.addObject("obInfo",obInfos.get(0));
						mv.addObject("surveyId",obInfos.get(0).getSurveyId());
						
						/** 获取预约明细 */
						IssueOBInfo obinfo = obInfos.get(0);
						if(obinfo!=null&&"1".equals(obinfo.getObType())){
							CcPrdServiceRecord model = new CcPrdServiceRecord();
							model.setObId(obinfo.getId());
							model.setDelFlag(SysConstant.NOT_DEL_FLAG);
							CcPrdServiceRecord prdService = ccPrdServiceRecordService.updateLatestOneByEntity(model);
							if(prdService!=null){
								if(prdService.getApptTime()!=null){
									mv.addObject("apptTime",prdService.getApptTime());
								}
								if(prdService.getScheduleDate()!=null){
									mv.addObject("scheduleDate",prdService.getScheduleDate().substring(0, 10)+" "+prdService.getTimeSpanStartTime());
								}
								
								/** 获取卡号 */
								String cardId = prdService.getCardId();
								if(StringUtils.isNotBlank(cardId)){
									Map<String,Object> kucun = issueService.findKucun(cardId);
									if(kucun != null && kucun.get("all_card_no")!=null && !"".equals(kucun.get("all_card_no"))){
										prdService.setCardNo(kucun.get("all_card_no")+"");
									}else{
										prdService.setCardNo(cardId);
									}
								}
								
								/** 获取就诊人名称 */
								if(prdService.getPatientVisitId()!=null){
									HyTreatmentPerson hyTreatmentPerson = hyTreatmentPersonService.findById(prdService.getPatientVisitId());
									if (hyTreatmentPerson != null && hyTreatmentPerson.getVisitName() != null
											&& !"".equals(hyTreatmentPerson.getVisitName())) {
										prdService.setPatientVisitName(hyTreatmentPerson.getVisitName());
									}
								}
								
								/** 获取诊所电话 */
								if(prdService.getClinicId()!=null){
									ClinicInfo ClinicInfo = clinicInfoService.findById(prdService.getClinicId());
									if(ClinicInfo!=null){
										if(ClinicInfo.getPhone()!=null&&!"".equals(ClinicInfo.getPhone())){
											prdService.setClinicPhone(ClinicInfo.getPhone());
										}else if(ClinicInfo.getMobile()!=null&&!"".equals(ClinicInfo.getMobile())){
											prdService.setClinicPhone(ClinicInfo.getMobile());
										}
									}
								}
								
								/** 获取预约账户 */
								if(prdService.getUserId()!=null){
									String loginName = hyTreatmentPersonService.getLoginnameByUserid(prdService.getUserId());
									if(loginName!=null&&!"".equals(loginName)){
										prdService.setLoginName(loginName);
									}
								}
							
								mv.addObject("prdService",prdService);
							}
						}
						
						/** 查询调研卷 */
						map.clear();
						map.put("surveyId", obInfos.get(0).getSurveyId());
						List<SurveySubjectModel> subjects = ccSurveySubjectService.getSubjectBySurvey(map);
						if(subjects !=null && !subjects.isEmpty()){
							mv.addObject("subjectInfo",subjects);
						}
					}
				}
			}
			
			/** 打开软电话开关 */
			mv.addObject("ctiSwitch",true);
			
			/** 呼入页面url */
			mv.setViewName(init_detail_page_url);
			//请求跳转页面
			mv.addObject("redirctPage", request.getParameter("redirctPage"));
			/** 回跳到工单记录页面 */
			mv.addObject("queryType", request.getParameter("queryType"));
			
			/** 用于从我的工单页面进详情后的返回标识 */
			mv.addObject("backType", request.getParameter("backType"));
			
			//记录工单记录页面传入的参数
			mv.addObject("issueType", request.getParameter("issueType"));
			mv.addObject("issueStatus", request.getParameter("issueStatus"));
			mv.addObject("asignee", request.getParameter("asignee"));
			mv.addObject("beginDate", request.getParameter("beginDate"));
			mv.addObject("endDate", request.getParameter("endDate"));
			
			String clinicName = request.getParameter("clinicName");
			if(StringUtils.isNotEmpty(clinicName)){
				clinicName = URLDecoder.decode(clinicName,"UTF-8");
			}
			mv.addObject("clinicName", clinicName);
			
			String patientVisitName = request.getParameter("patientVisitName");
			if(StringUtils.isNotEmpty(patientVisitName)){
				patientVisitName = URLDecoder.decode(patientVisitName,"UTF-8");
			}
			mv.addObject("patientVisitName", patientVisitName);
		
			mv.addObject("phone", request.getParameter("phone"));
			String hiddenType = request.getParameter("hiddenType");
			if(StringUtils.isNotBlank(hiddenType)){
				mv.addObject("hiddenType", hiddenType);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	
		return mv;
	}
	
	@RequestMapping("queryAnswer.do")
	@ResponseBody
	public JsonResponse<List<SurveyAnswer>> queryAnswer(String issueId){
		JsonResponse<List<SurveyAnswer>> response = new JsonResponse<List<SurveyAnswer>>();
		/** 校验工单ID */
		if(!StringUtils.isNotBlank(issueId)){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到工单ID！");
			return response;
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("issueId", issueId);
		map.put("delFlag", SysConstant.NOT_DEL_FLAG);
		List<SurveyAnswer> list = surveyAnswerService.findByProperties(map);
		if(list!=null && !list.isEmpty()){
			response.setResult(list);
		}
		response.setStatus(JsonResponse.Status.SUCCESS);
		return response;
	} 
	
	
	/**
	 * 呼出工单发生异常
	 * 
	 * */
	@RequestMapping("saveAbnormalIssue.do")
	@ResponseBody
	public JsonResponse<Void> saveAbnormalIssue(HttpServletRequest request){
		JsonResponse jason = new JsonResponse();
		String issueId = request.getParameter("issueId");
		String reason = request.getParameter("reason");
		
		IssueAbnormalLog model = new IssueAbnormalLog();
		model.setIssueId(issueId);
		model.setAbnormalReason(reason);
		model.setCallType(CallType.OUT.getValue());
		model.setCreateUser(getCurrentUser(request));
		issueAbnormalLogService.saveAbnormalIssue(model);
		jason.setStatus(JsonResponse.Status.SUCCESS);
		return jason;
	}
	
	/**
	 * 呼出工单发生异常,并关闭工单
	 * 
	 * */
	
	@RequestMapping("saveAbnormalIssueClosed.do")
	@ResponseBody
	public JsonResponse<Void> saveAbnormalIssueClosed(HttpServletRequest request){
		JsonResponse jason = new JsonResponse();
		String issueId = request.getParameter("issueId");
		String reason = request.getParameter("reason");
		
		IssueAbnormalLog model = new IssueAbnormalLog();
		model.setIssueId(issueId);
		model.setAbnormalReason(reason);
		model.setCallType(CallType.OUT.getValue());
		model.setCreateUser(getCurrentUser(request));
		issueAbnormalLogService.saveAbnormalIssueClosed(model);
		jason.setStatus(JsonResponse.Status.SUCCESS);
		return jason;
	}
	
	/**
	 * 查询异常通话时间 及异常原因
	 * 
	 * */
	private List<IssueAbnormalLog> getAbnormalLogList(String issueId){
		List<IssueAbnormalLog> resultList = new ArrayList<IssueAbnormalLog>();
		Map<String, Object> logMap = new HashMap<String, Object>(); 
		logMap.put("issueId",issueId);
		logMap.put("delFlag",SysConstant.NOT_DEL_FLAG);
		List<IssueAbnormalLog> logList =  issueAbnormalLogService.findByProperties(logMap);
		if(logList != null){
			
			for(IssueAbnormalLog model:logList){
				Date date = model.getCreateDate();
				if(date !=null){
					SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String phoneTime = sdformat.format(date);
					model.setPhoneTime(phoneTime);
				}	
				
				resultList.add(model);
			}
		}else{
			return null;	
		}
		return resultList;
	}
	
	/**
	 * 查询呼出工单异常日志
	 * @param issueId
	 * @return
	 */
	@RequestMapping("queryIssueAbnormalLog.do")
	@ResponseBody
	public JsonResponse<List<IssueAbnormalLog>> queryIssueAbnormalLog(String issueId){
		JsonResponse<List<IssueAbnormalLog>> response = new JsonResponse<List<IssueAbnormalLog>>();
		try{
			if(StringUtils.isNotBlank(issueId)){
				Map<String, Object> logMap = new HashMap<String, Object>(); 
				logMap.put("issueId",issueId);
				logMap.put("delFlag",SysConstant.NOT_DEL_FLAG);
				List<IssueAbnormalLog> list =  issueAbnormalLogService.findByProperties(logMap);
				if(list != null&&!list.isEmpty()){
					for(IssueAbnormalLog model:list){
						Date date = model.getCreateDate();
						if(date !=null){
							SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							String phoneTime = sdformat.format(date);
							model.setPhoneTime(phoneTime);
						}	
						
						logMap.clear();
						logMap.put("delFlag",SysConstant.NOT_DEL_FLAG);
						logMap.put("userCode",model.getCreateUser());
						List<HtUser> users = htUserService.findByProperties(logMap);
						if(users!=null && !users.isEmpty()){
							model.setUserName(users.get(0).getName());
						}
					}
				}
				response.setResult(list);
				response.setStatus(JsonResponse.Status.SUCCESS);
			}	
		}catch(Exception e){
			response.setStatus(JsonResponse.Status.ERROR);
			logger.error("查询呼出工单异常日志出错！", e);
		}
		return response;
	}
	
	

	@RequestMapping("/getEvaluation.do")
	@ResponseBody
	public JsonResponse<EvaluationInfo> getEvaluation(HttpServletRequest request) {
		JsonResponse<EvaluationInfo> result = new JsonResponse<EvaluationInfo>();
		String apptOrderCode = request.getParameter("apptOrderCode");

		// get score
		com.pinganwj.clinic.api.domain.JsonResponse<EvaluationInfo> json = evaluationApiService
				.getEvaluation(apptOrderCode);

		EvaluationInfo resultModel = json.getResult();
		result.setResult(resultModel);
		result.setStatus(JsonResponse.Status.SUCCESS);
		return result;
	}
}
