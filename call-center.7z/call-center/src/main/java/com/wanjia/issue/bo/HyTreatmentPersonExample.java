package com.wanjia.issue.bo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HyTreatmentPersonExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public HyTreatmentPersonExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andVisitIdIsNull() {
            addCriterion("VISIT_ID is null");
            return (Criteria) this;
        }

        public Criteria andVisitIdIsNotNull() {
            addCriterion("VISIT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andVisitIdEqualTo(String value) {
            addCriterion("VISIT_ID =", value, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdNotEqualTo(String value) {
            addCriterion("VISIT_ID <>", value, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdGreaterThan(String value) {
            addCriterion("VISIT_ID >", value, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdGreaterThanOrEqualTo(String value) {
            addCriterion("VISIT_ID >=", value, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdLessThan(String value) {
            addCriterion("VISIT_ID <", value, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdLessThanOrEqualTo(String value) {
            addCriterion("VISIT_ID <=", value, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdLike(String value) {
            addCriterion("VISIT_ID like", value, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdNotLike(String value) {
            addCriterion("VISIT_ID not like", value, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdIn(List<String> values) {
            addCriterion("VISIT_ID in", values, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdNotIn(List<String> values) {
            addCriterion("VISIT_ID not in", values, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdBetween(String value1, String value2) {
            addCriterion("VISIT_ID between", value1, value2, "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitIdNotBetween(String value1, String value2) {
            addCriterion("VISIT_ID not between", value1, value2, "visitId");
            return (Criteria) this;
        }

        public Criteria andMemberIdIsNull() {
            addCriterion("MEMBER_ID is null");
            return (Criteria) this;
        }

        public Criteria andMemberIdIsNotNull() {
            addCriterion("MEMBER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andMemberIdEqualTo(Long value) {
            addCriterion("MEMBER_ID =", value, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdNotEqualTo(Long value) {
            addCriterion("MEMBER_ID <>", value, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdGreaterThan(Long value) {
            addCriterion("MEMBER_ID >", value, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdGreaterThanOrEqualTo(Long value) {
            addCriterion("MEMBER_ID >=", value, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdLessThan(Long value) {
            addCriterion("MEMBER_ID <", value, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdLessThanOrEqualTo(Long value) {
            addCriterion("MEMBER_ID <=", value, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdIn(List<Long> values) {
            addCriterion("MEMBER_ID in", values, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdNotIn(List<Long> values) {
            addCriterion("MEMBER_ID not in", values, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdBetween(Long value1, Long value2) {
            addCriterion("MEMBER_ID between", value1, value2, "memberId");
            return (Criteria) this;
        }

        public Criteria andMemberIdNotBetween(Long value1, Long value2) {
            addCriterion("MEMBER_ID not between", value1, value2, "memberId");
            return (Criteria) this;
        }

        public Criteria andVisitNameIsNull() {
            addCriterion("VISIT_NAME is null");
            return (Criteria) this;
        }

        public Criteria andVisitNameIsNotNull() {
            addCriterion("VISIT_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andVisitNameEqualTo(String value) {
            addCriterion("VISIT_NAME =", value, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameNotEqualTo(String value) {
            addCriterion("VISIT_NAME <>", value, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameGreaterThan(String value) {
            addCriterion("VISIT_NAME >", value, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameGreaterThanOrEqualTo(String value) {
            addCriterion("VISIT_NAME >=", value, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameLessThan(String value) {
            addCriterion("VISIT_NAME <", value, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameLessThanOrEqualTo(String value) {
            addCriterion("VISIT_NAME <=", value, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameLike(String value) {
            addCriterion("VISIT_NAME like", value, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameNotLike(String value) {
            addCriterion("VISIT_NAME not like", value, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameIn(List<String> values) {
            addCriterion("VISIT_NAME in", values, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameNotIn(List<String> values) {
            addCriterion("VISIT_NAME not in", values, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameBetween(String value1, String value2) {
            addCriterion("VISIT_NAME between", value1, value2, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitNameNotBetween(String value1, String value2) {
            addCriterion("VISIT_NAME not between", value1, value2, "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitSexIsNull() {
            addCriterion("VISIT_SEX is null");
            return (Criteria) this;
        }

        public Criteria andVisitSexIsNotNull() {
            addCriterion("VISIT_SEX is not null");
            return (Criteria) this;
        }

        public Criteria andVisitSexEqualTo(String value) {
            addCriterion("VISIT_SEX =", value, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexNotEqualTo(String value) {
            addCriterion("VISIT_SEX <>", value, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexGreaterThan(String value) {
            addCriterion("VISIT_SEX >", value, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexGreaterThanOrEqualTo(String value) {
            addCriterion("VISIT_SEX >=", value, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexLessThan(String value) {
            addCriterion("VISIT_SEX <", value, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexLessThanOrEqualTo(String value) {
            addCriterion("VISIT_SEX <=", value, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexLike(String value) {
            addCriterion("VISIT_SEX like", value, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexNotLike(String value) {
            addCriterion("VISIT_SEX not like", value, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexIn(List<String> values) {
            addCriterion("VISIT_SEX in", values, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexNotIn(List<String> values) {
            addCriterion("VISIT_SEX not in", values, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexBetween(String value1, String value2) {
            addCriterion("VISIT_SEX between", value1, value2, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitSexNotBetween(String value1, String value2) {
            addCriterion("VISIT_SEX not between", value1, value2, "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayIsNull() {
            addCriterion("VISIT_BRITHDAY is null");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayIsNotNull() {
            addCriterion("VISIT_BRITHDAY is not null");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayEqualTo(String value) {
            addCriterion("VISIT_BRITHDAY =", value, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayNotEqualTo(String value) {
            addCriterion("VISIT_BRITHDAY <>", value, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayGreaterThan(String value) {
            addCriterion("VISIT_BRITHDAY >", value, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayGreaterThanOrEqualTo(String value) {
            addCriterion("VISIT_BRITHDAY >=", value, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayLessThan(String value) {
            addCriterion("VISIT_BRITHDAY <", value, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayLessThanOrEqualTo(String value) {
            addCriterion("VISIT_BRITHDAY <=", value, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayLike(String value) {
            addCriterion("VISIT_BRITHDAY like", value, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayNotLike(String value) {
            addCriterion("VISIT_BRITHDAY not like", value, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayIn(List<String> values) {
            addCriterion("VISIT_BRITHDAY in", values, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayNotIn(List<String> values) {
            addCriterion("VISIT_BRITHDAY not in", values, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayBetween(String value1, String value2) {
            addCriterion("VISIT_BRITHDAY between", value1, value2, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayNotBetween(String value1, String value2) {
            addCriterion("VISIT_BRITHDAY not between", value1, value2, "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeIsNull() {
            addCriterion("VISIT_ID_CARD_TYPE_CODE is null");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeIsNotNull() {
            addCriterion("VISIT_ID_CARD_TYPE_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeEqualTo(String value) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE =", value, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeNotEqualTo(String value) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE <>", value, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeGreaterThan(String value) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE >", value, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeGreaterThanOrEqualTo(String value) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE >=", value, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeLessThan(String value) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE <", value, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeLessThanOrEqualTo(String value) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE <=", value, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeLike(String value) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE like", value, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeNotLike(String value) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE not like", value, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeIn(List<String> values) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE in", values, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeNotIn(List<String> values) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE not in", values, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeBetween(String value1, String value2) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE between", value1, value2, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeNotBetween(String value1, String value2) {
            addCriterion("VISIT_ID_CARD_TYPE_CODE not between", value1, value2, "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeIsNull() {
            addCriterion("VISIT_ID_CARD_CODE is null");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeIsNotNull() {
            addCriterion("VISIT_ID_CARD_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeEqualTo(String value) {
            addCriterion("VISIT_ID_CARD_CODE =", value, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeNotEqualTo(String value) {
            addCriterion("VISIT_ID_CARD_CODE <>", value, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeGreaterThan(String value) {
            addCriterion("VISIT_ID_CARD_CODE >", value, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeGreaterThanOrEqualTo(String value) {
            addCriterion("VISIT_ID_CARD_CODE >=", value, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeLessThan(String value) {
            addCriterion("VISIT_ID_CARD_CODE <", value, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeLessThanOrEqualTo(String value) {
            addCriterion("VISIT_ID_CARD_CODE <=", value, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeLike(String value) {
            addCriterion("VISIT_ID_CARD_CODE like", value, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeNotLike(String value) {
            addCriterion("VISIT_ID_CARD_CODE not like", value, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeIn(List<String> values) {
            addCriterion("VISIT_ID_CARD_CODE in", values, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeNotIn(List<String> values) {
            addCriterion("VISIT_ID_CARD_CODE not in", values, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeBetween(String value1, String value2) {
            addCriterion("VISIT_ID_CARD_CODE between", value1, value2, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeNotBetween(String value1, String value2) {
            addCriterion("VISIT_ID_CARD_CODE not between", value1, value2, "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitMobileIsNull() {
            addCriterion("VISIT_MOBILE is null");
            return (Criteria) this;
        }

        public Criteria andVisitMobileIsNotNull() {
            addCriterion("VISIT_MOBILE is not null");
            return (Criteria) this;
        }

        public Criteria andVisitMobileEqualTo(String value) {
            addCriterion("VISIT_MOBILE =", value, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileNotEqualTo(String value) {
            addCriterion("VISIT_MOBILE <>", value, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileGreaterThan(String value) {
            addCriterion("VISIT_MOBILE >", value, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileGreaterThanOrEqualTo(String value) {
            addCriterion("VISIT_MOBILE >=", value, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileLessThan(String value) {
            addCriterion("VISIT_MOBILE <", value, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileLessThanOrEqualTo(String value) {
            addCriterion("VISIT_MOBILE <=", value, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileLike(String value) {
            addCriterion("VISIT_MOBILE like", value, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileNotLike(String value) {
            addCriterion("VISIT_MOBILE not like", value, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileIn(List<String> values) {
            addCriterion("VISIT_MOBILE in", values, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileNotIn(List<String> values) {
            addCriterion("VISIT_MOBILE not in", values, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileBetween(String value1, String value2) {
            addCriterion("VISIT_MOBILE between", value1, value2, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andVisitMobileNotBetween(String value1, String value2) {
            addCriterion("VISIT_MOBILE not between", value1, value2, "visitMobile");
            return (Criteria) this;
        }

        public Criteria andAddressIsNull() {
            addCriterion("ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andAddressIsNotNull() {
            addCriterion("ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andAddressEqualTo(String value) {
            addCriterion("ADDRESS =", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressNotEqualTo(String value) {
            addCriterion("ADDRESS <>", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressGreaterThan(String value) {
            addCriterion("ADDRESS >", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressGreaterThanOrEqualTo(String value) {
            addCriterion("ADDRESS >=", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressLessThan(String value) {
            addCriterion("ADDRESS <", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressLessThanOrEqualTo(String value) {
            addCriterion("ADDRESS <=", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressLike(String value) {
            addCriterion("ADDRESS like", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressNotLike(String value) {
            addCriterion("ADDRESS not like", value, "address");
            return (Criteria) this;
        }

        public Criteria andAddressIn(List<String> values) {
            addCriterion("ADDRESS in", values, "address");
            return (Criteria) this;
        }

        public Criteria andAddressNotIn(List<String> values) {
            addCriterion("ADDRESS not in", values, "address");
            return (Criteria) this;
        }

        public Criteria andAddressBetween(String value1, String value2) {
            addCriterion("ADDRESS between", value1, value2, "address");
            return (Criteria) this;
        }

        public Criteria andAddressNotBetween(String value1, String value2) {
            addCriterion("ADDRESS not between", value1, value2, "address");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("CREATE_USER is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("CREATE_USER is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("CREATE_USER =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("CREATE_USER <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("CREATE_USER >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("CREATE_USER >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("CREATE_USER <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("CREATE_USER <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("CREATE_USER like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("CREATE_USER not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("CREATE_USER in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("CREATE_USER not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("CREATE_USER between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("CREATE_USER not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("CREATE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("CREATE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("CREATE_DATE =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("CREATE_DATE <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("CREATE_DATE >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("CREATE_DATE <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("CREATE_DATE in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("CREATE_DATE not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNull() {
            addCriterion("MODIFY_USER is null");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNotNull() {
            addCriterion("MODIFY_USER is not null");
            return (Criteria) this;
        }

        public Criteria andModifyUserEqualTo(String value) {
            addCriterion("MODIFY_USER =", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotEqualTo(String value) {
            addCriterion("MODIFY_USER <>", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThan(String value) {
            addCriterion("MODIFY_USER >", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER >=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThan(String value) {
            addCriterion("MODIFY_USER <", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER <=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLike(String value) {
            addCriterion("MODIFY_USER like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotLike(String value) {
            addCriterion("MODIFY_USER not like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserIn(List<String> values) {
            addCriterion("MODIFY_USER in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotIn(List<String> values) {
            addCriterion("MODIFY_USER not in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserBetween(String value1, String value2) {
            addCriterion("MODIFY_USER between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotBetween(String value1, String value2) {
            addCriterion("MODIFY_USER not between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNull() {
            addCriterion("MODIFY_DATE is null");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNotNull() {
            addCriterion("MODIFY_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andModifyDateEqualTo(Date value) {
            addCriterion("MODIFY_DATE =", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotEqualTo(Date value) {
            addCriterion("MODIFY_DATE <>", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThan(Date value) {
            addCriterion("MODIFY_DATE >", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE >=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThan(Date value) {
            addCriterion("MODIFY_DATE <", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE <=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateIn(List<Date> values) {
            addCriterion("MODIFY_DATE in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotIn(List<Date> values) {
            addCriterion("MODIFY_DATE not in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE not between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("DEL_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("DEL_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(String value) {
            addCriterion("DEL_FLAG =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(String value) {
            addCriterion("DEL_FLAG <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(String value) {
            addCriterion("DEL_FLAG >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(String value) {
            addCriterion("DEL_FLAG <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLike(String value) {
            addCriterion("DEL_FLAG like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotLike(String value) {
            addCriterion("DEL_FLAG not like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<String> values) {
            addCriterion("DEL_FLAG in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<String> values) {
            addCriterion("DEL_FLAG not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(String value1, String value2) {
            addCriterion("DEL_FLAG between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(String value1, String value2) {
            addCriterion("DEL_FLAG not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andIsDefaultIsNull() {
            addCriterion("IS_DEFAULT is null");
            return (Criteria) this;
        }

        public Criteria andIsDefaultIsNotNull() {
            addCriterion("IS_DEFAULT is not null");
            return (Criteria) this;
        }

        public Criteria andIsDefaultEqualTo(String value) {
            addCriterion("IS_DEFAULT =", value, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultNotEqualTo(String value) {
            addCriterion("IS_DEFAULT <>", value, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultGreaterThan(String value) {
            addCriterion("IS_DEFAULT >", value, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultGreaterThanOrEqualTo(String value) {
            addCriterion("IS_DEFAULT >=", value, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultLessThan(String value) {
            addCriterion("IS_DEFAULT <", value, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultLessThanOrEqualTo(String value) {
            addCriterion("IS_DEFAULT <=", value, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultLike(String value) {
            addCriterion("IS_DEFAULT like", value, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultNotLike(String value) {
            addCriterion("IS_DEFAULT not like", value, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultIn(List<String> values) {
            addCriterion("IS_DEFAULT in", values, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultNotIn(List<String> values) {
            addCriterion("IS_DEFAULT not in", values, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultBetween(String value1, String value2) {
            addCriterion("IS_DEFAULT between", value1, value2, "isDefault");
            return (Criteria) this;
        }

        public Criteria andIsDefaultNotBetween(String value1, String value2) {
            addCriterion("IS_DEFAULT not between", value1, value2, "isDefault");
            return (Criteria) this;
        }

        public Criteria andVisitIdLikeInsensitive(String value) {
            addCriterion("upper(VISIT_ID) like", value.toUpperCase(), "visitId");
            return (Criteria) this;
        }

        public Criteria andVisitNameLikeInsensitive(String value) {
            addCriterion("upper(VISIT_NAME) like", value.toUpperCase(), "visitName");
            return (Criteria) this;
        }

        public Criteria andVisitSexLikeInsensitive(String value) {
            addCriterion("upper(VISIT_SEX) like", value.toUpperCase(), "visitSex");
            return (Criteria) this;
        }

        public Criteria andVisitBrithdayLikeInsensitive(String value) {
            addCriterion("upper(VISIT_BRITHDAY) like", value.toUpperCase(), "visitBrithday");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardTypeCodeLikeInsensitive(String value) {
            addCriterion("upper(VISIT_ID_CARD_TYPE_CODE) like", value.toUpperCase(), "visitIdCardTypeCode");
            return (Criteria) this;
        }

        public Criteria andVisitIdCardCodeLikeInsensitive(String value) {
            addCriterion("upper(VISIT_ID_CARD_CODE) like", value.toUpperCase(), "visitIdCardCode");
            return (Criteria) this;
        }

        public Criteria andVisitMobileLikeInsensitive(String value) {
            addCriterion("upper(VISIT_MOBILE) like", value.toUpperCase(), "visitMobile");
            return (Criteria) this;
        }

        public Criteria andAddressLikeInsensitive(String value) {
            addCriterion("upper(ADDRESS) like", value.toUpperCase(), "address");
            return (Criteria) this;
        }

        public Criteria andCreateUserLikeInsensitive(String value) {
            addCriterion("upper(CREATE_USER) like", value.toUpperCase(), "createUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLikeInsensitive(String value) {
            addCriterion("upper(MODIFY_USER) like", value.toUpperCase(), "modifyUser");
            return (Criteria) this;
        }

        public Criteria andDelFlagLikeInsensitive(String value) {
            addCriterion("upper(DEL_FLAG) like", value.toUpperCase(), "delFlag");
            return (Criteria) this;
        }

        public Criteria andIsDefaultLikeInsensitive(String value) {
            addCriterion("upper(IS_DEFAULT) like", value.toUpperCase(), "isDefault");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}