package com.wanjia.issue.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.common.utils.ThreadLocalContext;
import com.wanjia.issue.bo.CcIssueType;
import com.wanjia.issue.dao.CcIssueTypeMapper;

/**
 * This element is automatically generated on 16-9-19 ����11:06, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class CcIssueTypeServiceImpl implements CcIssueTypeService {
    @Autowired
    private CcIssueTypeMapper ccIssueTypeMapper;

    @Override
    @Transactional(readOnly=true)
    public CcIssueType findById(String id) {
        return (CcIssueType)ccIssueTypeMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcIssueType> findWithPagination(int offset, int count) {
        return (List<CcIssueType>)ccIssueTypeMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcIssueType> findAll() {
        return (List<CcIssueType>)ccIssueTypeMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcIssueType> findByEntity(CcIssueType model) {
        return (List<CcIssueType>)ccIssueTypeMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcIssueType> findByEntityWithPagination(CcIssueType model, int offset, int count) {
        return (List<CcIssueType>)ccIssueTypeMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public CcIssueType findOneByEntity(CcIssueType model) {
        return (CcIssueType)ccIssueTypeMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcIssueType> findByProperty(String propertyName, String propertyValue) {
        return (List<CcIssueType>)ccIssueTypeMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public CcIssueType findOneByProperty(String propertyName, String propertyValue) {
        return (CcIssueType)ccIssueTypeMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcIssueType> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<CcIssueType>)ccIssueTypeMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcIssueType> findByProperties(Map<String, Object> map) {
        return (List<CcIssueType>)ccIssueTypeMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(CcIssueType model) {
        return (long)ccIssueTypeMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)ccIssueTypeMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)ccIssueTypeMapper.countByProperties(map);
    }

    @Override
    public void update(CcIssueType model) {
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        ccIssueTypeMapper.update(model);
    }

    @Override
    public void insert(CcIssueType model) {
        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        ccIssueTypeMapper.insert(model);
    }

    @Override
    public void deleteByEntity(CcIssueType model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        ccIssueTypeMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.ccIssueTypeMapper.countAll();
    }

    public void insertBatch(List<CcIssueType> list) {
        this.ccIssueTypeMapper.insertBatch(list);
    }

    public void delete(String id) {
        CcIssueType model = new CcIssueType();
        model.setDelFlag(SysConstant.DEL_FLAG);
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(id);
        this.ccIssueTypeMapper.update(model);
    }
}