package com.wanjia.issue.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.web.dictionary.model.Dictionary;
import com.wanjia.ht.bo.SysAreaCity;
import com.wanjia.ht.bo.SysDict;
import com.wanjia.ht.service.SysAreaCityService;
import com.wanjia.ht.service.SysDictService;
import com.wanjia.issue.bo.CcIssueType;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueView;
import com.wanjia.issue.enums.CallType;
import com.wanjia.issue.enums.IsConvey;
import com.wanjia.issue.enums.IssueStatus;
import com.wanjia.issue.service.CcIssueTypeService;
import com.wanjia.issue.service.IssueService;
import com.wanjia.knowledge.bo.CcKnowledge;
import com.wanjia.knowledge.enums.KnowledgeStatus;
import com.wanjia.knowledge.service.CcKnowledgeService;

@Controller
@RequestMapping("/issue/")
public class CallInController extends BaseController{

	private Logger logger = Logger.getLogger(CallInController.class);
	
//	@Autowired
//	private DictionaryService dictionaryService;
	@Autowired
	private IssueService issueService;
	@Autowired
	private CcKnowledgeService ccKnowledgeService;
	@Autowired
	private SysAreaCityService sysAreaCityService;
	@Autowired
	private SysDictService sysDictService;
	@Autowired
	private CcIssueTypeService ccIssueTypeService;
	
	/** 初始化页面url */
	private final String init_page_url = "issue/callIn";
	/** 问题详情url */
	private final String knowledge_page_url = "issue/knowledgeDtl";
	
	/** 数据字典code数组 */
	private static String[] dicts = {"CC_CLIENT_TYPE","CC_ISSUE_TYPE","CC_PROMISE_DAYS"};
	
	/** 问题类型dict_code */
	private static String cc_knowledge_type = "CC_QUESTION_TYPE";
	
	/** 上一个 */
	private static String last_one = "last";
	/** 下一个 */
	private static String next_one = "next";
	
	/**
	 * 呼入页面初始化
	 * @param request
	 * @param response
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping("callIn.do")
	public ModelAndView initCallIn(HttpServletRequest request,HttpServletResponse response){
		ModelAndView mv = new ModelAndView();
		
		/** 获取所有省 */
		Map<String,Object> map = new HashMap<String,Object>(2);
		map.put("parentId", "0");
		map.put("delFlag", SysConstant.NOT_DEL_FLAG);
		List<SysAreaCity> provinces = sysAreaCityService.findByProperties(map);
		if(provinces !=null && !provinces.isEmpty()){
			mv.addObject("provinces",provinces);
		}
		
		/** 获取相关数据字典：事件类型和用户类型 */
		//Map<String,List<Dictionary>> dictMap = issueService.getDicts(dicts);
		Map<String,List<SysDict>> dictMap = issueService.getDicts(dicts);
		if(dictMap !=null && !dictMap.isEmpty()){
			for(Entry<String,List<SysDict>> dict : dictMap.entrySet()){
				mv.addObject(dict.getKey(),dict.getValue());
			}
			
			List<SysDict> list = dictMap.get("CC_PROMISE_DAYS");
			if(list!=null && !list.isEmpty()){
				Collections.sort(list, new DictComparator()); 
			}
			mv.addObject("CC_PROMISE_DAYS",list);
		}
		
		/** 打开软电话开关 */
		mv.addObject("ctiSwitch",true);
		
		/** 呼入页面url */
		mv.setViewName(init_page_url);	
		return mv;
	}
	
	static class DictComparator implements Comparator<SysDict> {  
        public int compare(SysDict object1, SysDict object2) {// 实现接口中的方法  
        	SysDict sd1 = object1; // 强制转换  
        	SysDict sd2 = object2;  
            return new Integer(sd1.getDictKey()).compareTo(new Integer(sd2.getDictKey()));  
        }  
    }  
	
	/**
	 * 根据省份查询城市地区
	 * @param provinceId 省份id
	 * @param cityId 城市id
	 * @return
	 */
	@RequestMapping("getCityAndDistrict.do")
	@ResponseBody
	public JsonResponse<List<SysAreaCity>> getCityAndDistrict(String provinceId,String cityId){
		JsonResponse<List<SysAreaCity>> response = new JsonResponse<List<SysAreaCity>>();
		
		try{
			/** 获取所有市或区，参数中省份id和城市id二者只有一个存在值 */
			SysAreaCity sac = new SysAreaCity();
			if(StringUtils.isNotBlank(provinceId))
				sac.setParentId(provinceId);
			else if(StringUtils.isNotBlank(cityId))
				sac.setParentId(cityId);
			else{
				response.setStatus(JsonResponse.Status.ERROR);
				response.setErrorMsg("查询城市或地区时参数为空！");
				return response;
			}
			sac.setDelFlag(SysConstant.NOT_DEL_FLAG);
			List<SysAreaCity> areas = sysAreaCityService.findByEntity(sac);
			if(areas !=null && !areas.isEmpty()){
				response.setResult(areas);
			}
			
		}catch(Exception e){
			String msg = null;
			if(StringUtils.isNotBlank(provinceId))
				msg = "根据省份[areaId:"+provinceId+"]获取城市出错！";
			else if(StringUtils.isNotBlank(cityId))
				msg = "根据城市[areaId:"+cityId+"]获取地区出错！";
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg(msg);
		}
		return response;
	}
	
	/**
	 * 查询数据字典
	 * @param dictCodes 字典代码
	 * @return
	 */
	@RequestMapping("getDict.do")
	@ResponseBody
	public JsonResponse<Map<String,List<Dictionary>>> getDict(@RequestParam(value = "dictCodes[]") String[] dictCodes){
		JsonResponse<Map<String,List<Dictionary>>> response = new JsonResponse<Map<String,List<Dictionary>>>();
		Map<String,List<Dictionary>> map = new HashMap<String,List<Dictionary>>();
		Map<String,Object> queryParam = new HashMap<String,Object>();
		for(String dictCode : dictCodes){
			queryParam.put("dictCode", dictCode);
			//List<Dictionary> list = dictionaryService.findByProperties(queryParam);
			//if(list!=null && !list.isEmpty()) map.put(dictCode, list);
		}
		
		response.setResult(map);
		response.setStatus(JsonResponse.Status.SUCCESS);
		return response;
	}
	
	/**
	 * 提交坐席工单事件
	 * @param request
	 * @param issue 参数对象
	 * @return
	 */
	@RequestMapping("submitIssue.do")
	@ResponseBody
	public JsonResponse<Void> submitIssue(HttpServletRequest request,Issue issue){
		JsonResponse<Void> response = new JsonResponse<Void>();
		
		/** 校验联系方式 */
		if(!StringUtils.isNotBlank(issue.getPhone())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("联系方式为空！");
			return response;
		}
		
		/** 校验用户类型 */
		if(!StringUtils.isNotBlank(issue.getClientTypeId())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("用户类型为空！");
			return response;
		}
		
		/** 校验地区 */
		if(!StringUtils.isNotBlank(issue.getProvincecode())
				||!StringUtils.isNotBlank(issue.getCitycode())
				||!StringUtils.isNotBlank(issue.getDistrictcode())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("省市区选择不完全！");
			return response;
		}
		
		/** 校验事件类型 */
		if(!StringUtils.isNotBlank(issue.getIssueType())
				||!StringUtils.isNotBlank(issue.getIssueTypeSub())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("事件类型输入不完全！");
			return response;
		}
		
		/** 校验事件标题 */
		if(!StringUtils.isNotBlank(issue.getIssueTopic())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("事件标题为空！");
			return response;
		}
		
		/** 校验事件描述 */
		if(!StringUtils.isNotBlank(issue.getIssueDesc())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("事件描述为空！");
			return response;
		}
		
		/** 校验解决方案 */
		if(IssueStatus.SOLVED.getValue().equals(issue.getStatus())
				&&!StringUtils.isNotBlank(issue.getIssueSolution())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("解决方案为空！");
			return response;
		}
		
		/** 当状态为已解决时，是否流转都为不流转 */
		if(IssueStatus.SOLVED.getValue().equals(issue.getStatus())){
			issue.setIsConvey(IsConvey.UNTRANSFER.getValue());
		}
		
		/** 获取当前用户和时间 */
		String userCode = getCurrentUser(request);
		Date date = new Date();
		
		/** 插入记录 */
		issue.setId(UUID.randomUUID().toString());
		issue.setCallType(CallType.IN.getValue());
		issue.setHandler(userCode);
		issue.setCallTime(date);
		issue.setCreateDate(date);
		issue.setCreateUser(userCode);
		issue.setDelFlag(SysConstant.NOT_DEL_FLAG);
		
		/** 目前未确定工单编号的生产规则，此字段暂时保留，暂存为uuid */
		issue.setIssueCode(issue.getId());
		
		try{
			issueService.createIssue(issue);
		}catch(Exception e){
			logger.error("坐席提交事件异常！提交参数为：" + ToStringBuilder.reflectionToString(issue, ToStringStyle.MULTI_LINE_STYLE));
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("提交异常！");
			return response;
		}
		
		response.setStatus(JsonResponse.Status.SUCCESS);
		return response;
	}
	
	/**
	 * 查询问题详情
	 * @param knowledgeId 问题id
	 * @return
	 */
	@RequestMapping("queryKnowledgeDtl.do")
	public ModelAndView queryKnowledgeDtl(String knowledgeId){
		ModelAndView mv = new ModelAndView();
		
		/** 根据id查询问题详情 */
		if(StringUtils.isNotBlank(knowledgeId)){
			CcKnowledge model = new CcKnowledge();
			model.setId(knowledgeId);
			model.setDelFlag(SysConstant.NOT_DEL_FLAG);
			model.setStatus(KnowledgeStatus.ENABLE.getValue());
			CcKnowledge ck = ccKnowledgeService.findOneByEntity(model);
			if(ck!=null){
				ck.setTypeDesc(sysDictService.getDescriptionByDictKey(cc_knowledge_type, ck.getType()));
				mv.addObject("ck",ck);
			}
		}
		
		/** 问题详情页面url */
		mv.setViewName(knowledge_page_url);
		return mv;
	}
	
	/**
	 * 查询常见问题
	 * @param key 关键字
	 * @return
	 */
	@RequestMapping("queryCommonKnowledge.do")
	@ResponseBody
	public JsonResponse<List<CcKnowledge>> queryCommonKnowledge(String key,String limit){
		JsonResponse<List<CcKnowledge>> response = new JsonResponse<List<CcKnowledge>>();
		Map<String,Object> map = new HashMap<String,Object>();
		if(StringUtils.isNotBlank(key))
			map.put("key", key.trim());
		else{
			if(StringUtils.isNotBlank(limit))
				map.put("limit", Integer.parseInt(limit));
			map.put("isCommonProblem", SysConstant.YES);
		}
		map.put("delFlag", SysConstant.NOT_DEL_FLAG);
		map.put("status", KnowledgeStatus.ENABLE.getValue());
		try{
			List<CcKnowledge> list = ccKnowledgeService.queryKnowledge(map);
			response.setResult(list);
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.error("搜索常见问题出错！", e);
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("搜索常见问题异常！");
		}
		
		return response;
	}
	
	/**
	 * 查询问题
	 * @param ck
	 * @return
	 */
	@RequestMapping("getKnowledge.do")
	@ResponseBody
	public JsonResponse<CcKnowledge> getKnowledge(String seq,String searchType){
		JsonResponse<CcKnowledge> response = new JsonResponse<CcKnowledge>();
		if(!StringUtils.isNotBlank(seq)){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到当前问题序号！");
			return response;
		}

		try{
			/** 小于当前序号的问题中序号最大的，如果不存在记录则说明已经到尽头了;
			 *  大于当前序号的问题中序号小的，如果不存在记录则说明已经到尽头了 */
			Map<String,Object> queryParam = new HashMap<String,Object>();
			queryParam.put("searchType", searchType);
			queryParam.put("delFlag", SysConstant.NOT_DEL_FLAG);
			queryParam.put("status", KnowledgeStatus.ENABLE.getValue());
			queryParam.put("seq", seq);
			Map<String,Object> map = ccKnowledgeService.getNextKnowledge(queryParam);
			if(map!=null){
				BigDecimal ccSeq = new BigDecimal(map.get("SEQ")+"");
				ccSeq = ccSeq.setScale(0, BigDecimal.ROUND_HALF_UP);
				CcKnowledge param = new CcKnowledge();
				param.setSeq(ccSeq+"");
				param.setDelFlag(SysConstant.NOT_DEL_FLAG);
				param.setStatus(KnowledgeStatus.ENABLE.getValue());
				CcKnowledge ck = ccKnowledgeService.findOneByEntity(param);
				if(ck!=null){
					ck.setTypeDesc(sysDictService.getDescriptionByDictKey(cc_knowledge_type, ck.getType()));
				}
				response.setResult(ck);
			}
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.error("获取问题出错！", e);
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("获取问题异常！");
		}
		
		return response;
	}
	
	/**
	 * 查询用户最近事件
	 * @param limit 最近多少条
	 * @return
	 */
	@RequestMapping("queryIssue.do")
	@ResponseBody
	public JsonResponse<List<IssueView>> queryIssue(HttpServletRequest request,String limit,String phone){
		JsonResponse<List<IssueView>> response = new JsonResponse<List<IssueView>>();
		Map<String,Object> map = new HashMap<String,Object>();
		if(StringUtils.isNotBlank(limit)){
			map.put("limit", Integer.parseInt(limit));
		}
		//map.put("userCode", getCurrentUser(request));
		map.put("phone", phone);
		map.put("delFlag", SysConstant.NOT_DEL_FLAG);
		try{
			List<Issue> list = issueService.queryLastIssue(map);
			if(list!=null && !list.isEmpty()){
				List<IssueView> ivs = new ArrayList<IssueView>(list.size());
				for(Issue issue : list){
					IssueView iv = new IssueView();
					BeanUtils.copyProperties(issue, iv);
					iv.setIssueDate(DateUtils.format(issue.getCreateDate(), "yyyy-MM-dd HH:mm:ss"));
					iv.setStatusName(IssueStatus.getIssueStatus(issue.getStatus()).getDesc());
					ivs.add(iv);
				}
				response.setResult(ivs);
			}
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.error("获取用户最近事件出错！", e);
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("获取用户最近事件异常！");
		}
		
		return response;
	}
	
	@RequestMapping("queryIssueSubType.do")
	@ResponseBody
	public JsonResponse<List<CcIssueType>> queryIssueSubType(String issueType){
		JsonResponse<List<CcIssueType>> response = new JsonResponse<List<CcIssueType>>();
		try{
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("parentCode", issueType);
			map.put("delFlag", SysConstant.NOT_DEL_FLAG);
			List<CcIssueType> list = ccIssueTypeService.findByProperties(map);
			response.setResult(list);
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.error("获取二级事件类型出错！", e);
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("获取二级事件类型异常！");
		}
		
		return response;
	}
	
	/**
	 * 通过呼入号码查找呼入工单
	 * @param issueType
	 * @return
	 */
	@RequestMapping("getIssueByPhone.do")
	@ResponseBody
	public JsonResponse<Issue> getIssueByPhone(String phone){
		JsonResponse<Issue> response = new JsonResponse<Issue>();
		try{
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("phone", phone);
			map.put("callType", CallType.IN.getValue());
			map.put("delFlag", SysConstant.NOT_DEL_FLAG);
			List<Issue> list = issueService.findByProperties(map);
			if(list!=null && !list.isEmpty()){
				Issue issue = new Issue();
				for(Issue item : list){
					if(StringUtils.isNotBlank(item.getClientName())){
						issue.setClientName(item.getClientName());
						issue.setGender(item.getGender());
						issue.setProvincecode(item.getProvincecode());
						issue.setCitycode(item.getCitycode());
						issue.setDistrictcode(item.getDistrictcode());
						break;
					}
				}
				
				if(!StringUtils.isNotBlank(issue.getClientName())){
					issue.setProvincecode(list.get(0).getProvincecode());
					issue.setCitycode(list.get(0).getCitycode());
					issue.setDistrictcode(list.get(0).getDistrictcode());
					issue.setGender(list.get(0).getGender());
				}
				response.setResult(issue);
			}
			
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.error("通过呼入号码查找目前工单出错！", e);
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("通过呼入号码查找目前工单异常！");
		}
		
		return response;
	}
}
