package com.wanjia.issue.enums;

/**
 * 坐席呼叫类型枚举类
 * @author QIANXIN510
 *
 */
public enum CallType {
	
	IN("IN", "0", "呼入"), OUT("OUT", "1", "呼出");
	
	private String code;
    private String value;
    private String desc;
    
	private CallType(String code, String value, String desc) {
		this.code = code;
		this.value = value;
		this.desc = desc;
	}
    
    public static CallType getCallType(String value){
   	 for (CallType c : CallType.values()) {
            if (c.getValue() == value) {
                return c;
            }
        }
   	 return null;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
