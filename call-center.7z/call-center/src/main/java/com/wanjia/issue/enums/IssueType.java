package com.wanjia.issue.enums;

/**
 * 坐席事件类型枚举类
 * @author QIANXIN510
 *
 */
public enum IssueType {
	
	CONSULTATION("CONSULTATION", "01", "咨询查询"), COMPLAINT("COMPLAINT", "02", "投诉"), FEEDBACK("FEEDBACK", "03", "一般反馈");
	
	private String code;
    private String value;
    private String desc;
    
	private IssueType(String code, String value, String desc) {
		this.code = code;
		this.value = value;
		this.desc = desc;
	}
    
    public static IssueType getIssueType(String value){
   	 for (IssueType c : IssueType.values()) {
            if (c.getValue().equals(value) ) {
                return c;
            }
        }
   	 return null;
    }
    
    public static String getIssueTypeDesc(String value){
      	 for (IssueType c : IssueType.values()) {
               if (c.getValue().equals(value) ) {
                   return c.getDesc();
               }
           }
      	 return null;
       }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
