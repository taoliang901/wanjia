package com.wanjia.issue.enums;

/**
 * 坐席工单流转状态枚举类
 * @author QIANXIN510
 *
 */
public enum IsConvey {
	
	UNTRANSFER("UNTRANSFER", "0", "未流转"), TRANSFER("TRANSFER", "1", "流转");
	
	private String code;
    private String value;
    private String desc;
    
	private IsConvey(String code, String value, String desc) {
		this.code = code;
		this.value = value;
		this.desc = desc;
	}
    
    public static IsConvey getIsConvey(String value){
   	 for (IsConvey c : IsConvey.values()) {
            if (c.getValue().equals(value) ) {
                return c;
            }
        }
   	 return null;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
