package com.wanjia.issue.enums;

/**
 * 坐席工单状态枚举类
 * @author QIANXIN510
 *
 */
public enum IssueStatus {
	
	UNSOLVED("UNSOLVED", "0", "未解决"), SOLVED("SOLVED", "1", "已解决"), DEALING("DEALING", "2", "解决中"), CLOSED("CLOSED","3","已关闭");
	
	private String code;
    private String value;
    private String desc;
    
	private IssueStatus(String code, String value, String desc) {
		this.code = code;
		this.value = value;
		this.desc = desc;
	}
    
    public static IssueStatus getIssueStatus(String value){
   	 for (IssueStatus c : IssueStatus.values()) {
            if (c.getValue().equals(value)) {
                return c;
            }
        }
   	 return null;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
}
