package com.wanjia.issue.controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.base.AppletParamBean;
import com.wanjia.base.GuiDisplayBean;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.web.BaseController;
import com.wanjia.cas.client.filter.PropertiesReadUtil;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.issue.bo.CtiAppletParam;
import com.wanjia.issue.service.CtiAppletParamService;

@Controller
public class CtiController extends BaseController{

	private Logger logger = Logger.getLogger(CallInController.class);
	
	@Autowired
	private CtiAppletParamService ctiAppletParamService;
	
	/** 初始化页面url */
	private final String init_page_url = "phone/header";
	
	@RequestMapping("/cc/cti/initCti.do")
	public ModelAndView initCti(HttpServletRequest request,HttpServletResponse response){
		ModelAndView mv = new ModelAndView();
		
		/** 打开软电话开关 */
		mv.addObject("ctiSwitch",true);
		
		/** 呼入页面url */
		mv.setViewName(init_page_url);	
		return mv;
	}
	
	/**
	 * 软电话登录验证及配置初始化
	 * @param request
	 * @param reponse
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/cc/cti/queryAppletParams")
	@ResponseBody
    public JsonResponse<AppletParamBean> queryAppletParams(HttpServletRequest request, HttpServletResponse reponse) throws Exception {
		JsonResponse<AppletParamBean> jr = new JsonResponse<AppletParamBean>();
		
		/** 获取分机号*/
		String ctiExtNumberId = request.getParameter("ctiExtNumberId");
		/** 获取工号 */
		String ctiEmployeeId = request.getParameter("ctiEmployeeId");
        
		/** 校验工号和分机号*/
		if(!StringUtils.isNotBlank(ctiExtNumberId)||!StringUtils.isNotBlank(ctiEmployeeId)){
        	jr.setStatus(Status.ERROR);
        	jr.setErrorMsg("工号和分机号不能为空");
        	return jr;
        }
        
        /** 登录校验 */
        Map<String,Object> map = new HashMap<String,Object>();
        //Updated by TL 2017-01-17
   //      map.put("agentInfo", ctiEmployeeId+";"+ctiExtNumberId);
   //     List<CtiAppletParam> list = ctiAppletParamService.findByProperties(map);
        map.put("ctiEmployeeId",ctiEmployeeId);
        map.put("ctiExtNumberId",ctiExtNumberId);
        List<CtiAppletParam> list = ctiAppletParamService.checkLoginAccount(map);
        if(list == null || list.isEmpty()){
        	jr.setStatus(Status.ERROR);
        	jr.setErrorMsg("工号["+ctiEmployeeId+"]和分机号["+ctiExtNumberId+"]的登录信息不存在！");
        	return jr;
        }
        /*map.put("agentInfo", ctiEmployeeId+";");
        List<CtiAppletParam> list = ctiAppletParamService.findByCtiEmployee(map);
        if(list == null || list.isEmpty()){
        	jr.setStatus(Status.ERROR);
        	jr.setErrorMsg("工号["+ctiEmployeeId+"]的登录信息不存在！");
        	return jr;
        }*/
        
        /** 如果存在多条，则只取一条 */
        CtiAppletParam cap =list.get(0);
        
        /** 配置applet参数 */
        AppletParamBean params = new AppletParamBean();
        BeanUtils.copyProperties(cap, params);
        params.setVersion(cap.getVer());
        params.setOutDailNumber(cap.getOutdailNumber());
        params.setDialStringOut(cap.getDialstringOut());
        
        /** 配置软电话组件 */
        GuiDisplayBean guiDisplayBean = new GuiDisplayBean();
        BeanUtils.copyProperties(cap, guiDisplayBean);
        guiDisplayBean.setButLogin(cap.getButLoginLogin());
        params.setGuiDisplay(guiDisplayBean);

        /** 获取applet的codebase */
        String codebase = getCodebase(request, params);
        if (StringUtils.isEmpty(codebase)) {
            logger.info("软电话程序地址获取失败");
            jr.setStatus(Status.ERROR);
        	jr.setErrorMsg("软电话程序地址获取失败！");
        	return jr;
        }

        /** 设置applet版本 */ 
        String version = getAppletVersion(codebase, params);
        if (StringUtils.isEmpty(version )) {
        	logger.info("软电话版本获取失败。userId=; codebase=" + codebase + ";roleCode="+params.getRoleCode());
            jr.setStatus(Status.ERROR);
        	jr.setErrorMsg("软电话版本获取失败！");
        	return jr;
        }
        
        jr.setResult(params);
        logger.info(ToStringBuilder.reflectionToString(params, ToStringStyle.MULTI_LINE_STYLE));
        jr.setStatus(Status.SUCCESS);
        return jr;
    }
	

	
	 /**
     * 获取applet的codebase
     * @param request
     * @param params
     * @return
     */
    private String getCodebase(HttpServletRequest request, AppletParamBean params) {
    	String codebase = request.getParameter("codebase");
        if (params != null && StringUtils.isEmpty(codebase)) {
            if (StringUtils.equals(params.getEnv(), SysConstant.CTI_ENV_STG)) {
                codebase = PropertiesReadUtil.getPropertyVal(SysConstant.CTI_CODEBASE_STG);
            }
            else if (StringUtils.equals(params.getEnv(), SysConstant.CTI_ENV_PRD)) {
                codebase = PropertiesReadUtil.getPropertyVal(SysConstant.CTI_CODEBASE_PRD);
            }
        }
    	params.setCodebase(codebase);
        return codebase;
    }
    
    
    /**
     * 获取applet程序版本
     * 如果数据库中设置了版本，使用数据库中的设置
     * 没有的话使用version.properties文件中的配置
     * @param codebase
     * @param params
     * @return
     * @throws IOException
     */
    private String getAppletVersion(String codebase, AppletParamBean params) throws IOException {
        String version = null;
        if (params != null) {
            if (StringUtils.isEmpty(params.getVersion())) {
                String ctiType = params.getCtiType();
                String dataType = params.getDataType();
                Properties versionProperties = new Properties();
                try {
                    URL url = new URL(codebase + "version.properties");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    InputStream inputStream = conn.getInputStream();
                    versionProperties.load(inputStream);
                }
                catch (Exception ex) {
                	ex.printStackTrace();
                    logger.error(ex.getMessage());
                }
                version = versionProperties.getProperty(dataType + "." + ctiType + ".DEFAULT");
                params.setVersion(version);
            }
            else {
                version = params.getVersion();
            }
        }
        return version;
    }
}
