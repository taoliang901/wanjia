package com.wanjia.issue.enums;

/**
 * 坐席用户类型枚举类
 * @author QIANXIN510
 *
 */
public enum ClientType {
	
	PERSONAL("PERSONAL", "01", "个人客户"), INNER("INNER", "02", "内部客户"), CLINIC("CLINIC", "03", "合作诊所"), ENTERPEISE(
			"ENTERPEISE", "04", "企业客户"), PARTNER("PARTNER", "05", "合作伙伴"), OTHER("OTHER", "06", "其他");
	
	private String code;
    private String value;
    private String desc;
    
	private ClientType(String code, String value, String desc) {
		this.code = code;
		this.value = value;
		this.desc = desc;
	}
    
    public static String getClientTypeDesc(String value){
   	 for (ClientType c : ClientType.values()) {
            if (c.getValue().equals(value)) {
                return c.getDesc();
            }
        }
   	 return null;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
