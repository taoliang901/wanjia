package com.wanjia.issue.service;

import com.pinganwj.clinic.api.ProductApptApi;
import com.pinganwj.clinic.api.domain.JsonResponse;
import com.pinganwj.clinic.api.domain.appt.product.ProductServiceRecord;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.issue.bo.CcPrdServiceRecord;
import com.wanjia.issue.dao.CcPrdServiceRecordMapper;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-9-19 ����5:56, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class CcPrdServiceRecordServiceImpl implements CcPrdServiceRecordService {
	
	private Logger logger = LoggerFactory.getLogger(CcPrdServiceRecordServiceImpl.class);
	
    @Autowired
    private CcPrdServiceRecordMapper ccPrdServiceRecordMapper;

	@Autowired
	private ProductApptApi productApptApi;
	
	
    @Override
    @Transactional(readOnly=true)
    public CcPrdServiceRecord findById(String id) {
        return (CcPrdServiceRecord)ccPrdServiceRecordMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcPrdServiceRecord> findWithPagination(int offset, int count) {
        return (List<CcPrdServiceRecord>)ccPrdServiceRecordMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcPrdServiceRecord> findAll() {
        return (List<CcPrdServiceRecord>)ccPrdServiceRecordMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcPrdServiceRecord> findByEntity(CcPrdServiceRecord model) {
        return (List<CcPrdServiceRecord>)ccPrdServiceRecordMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcPrdServiceRecord> findByEntityWithPagination(CcPrdServiceRecord model, int offset, int count) {
        return (List<CcPrdServiceRecord>)ccPrdServiceRecordMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public CcPrdServiceRecord findOneByEntity(CcPrdServiceRecord model) {
        return (CcPrdServiceRecord)ccPrdServiceRecordMapper.findOneByEntity(model);
        
        
    }
    
   

    @Override
    @Transactional(readOnly=true)
    public List<CcPrdServiceRecord> findByProperty(String propertyName, String propertyValue) {
        return (List<CcPrdServiceRecord>)ccPrdServiceRecordMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public CcPrdServiceRecord findOneByProperty(String propertyName, String propertyValue) {
        return (CcPrdServiceRecord)ccPrdServiceRecordMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcPrdServiceRecord> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<CcPrdServiceRecord>)ccPrdServiceRecordMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcPrdServiceRecord> findByProperties(Map<String, Object> map) {
        return (List<CcPrdServiceRecord>)ccPrdServiceRecordMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(CcPrdServiceRecord model) {
        return (long)ccPrdServiceRecordMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)ccPrdServiceRecordMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)ccPrdServiceRecordMapper.countByProperties(map);
    }

    @Override
    public void update(CcPrdServiceRecord model) {
        //model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        ccPrdServiceRecordMapper.update(model);
    }

    @Override
    public void insert(CcPrdServiceRecord model) {
        //model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        ccPrdServiceRecordMapper.insert(model);
    }

    @Override
    public void deleteByEntity(CcPrdServiceRecord model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
        //model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        ccPrdServiceRecordMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.ccPrdServiceRecordMapper.countAll();
    }

    public void insertBatch(List<CcPrdServiceRecord> list) {
        this.ccPrdServiceRecordMapper.insertBatch(list);
    }

    public void delete(String id) {
        CcPrdServiceRecord model = new CcPrdServiceRecord();
        model.setDelFlag(SysConstant.DEL_FLAG);
        //model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(id);
        this.ccPrdServiceRecordMapper.update(model);
    }
    
    /**
     * 调用深圳接口更新预约订单状态
     * 预约订单状态实时同步，打开页面即为最新状态
     * Added by TL on 12-01
     * */
    public CcPrdServiceRecord updateLatestOneByEntity(CcPrdServiceRecord model){
    	CcPrdServiceRecord result = findOneByEntity(model);
		try{
			if(StringUtils.isNotEmpty(result.getApptorderCode())){
				JsonResponse<ProductServiceRecord> jason = productApptApi.getProductServiceRecordByApptOrderCode(result.getApptorderCode());
				if(jason.getStatus().equals(JsonResponse.Status.SUCCESS)){
					ProductServiceRecord productServiceRecord = jason.getResult();
					if(productServiceRecord != null){
						result.setApptStatus(productServiceRecord.getApptStatus());
						if(productServiceRecord.getClinicScore()!=null){
							result.setClinicScore(new BigDecimal(productServiceRecord.getClinicScore()));
							result.setStr_clinicScore(String.valueOf(productServiceRecord.getClinicScore()));
						}
						result.setScheduleDate(productServiceRecord.getScheduleDate());
						result.setIsUserTreatmentConfirm(productServiceRecord.getIsUserTreatmentConfirm());
						result.setIsClinicTreatmentConfirm(productServiceRecord.getIsClinicTreatmentConfirm());
						result.setModifyUser("system");
						update(result);
					}

				}else{
					logger.info("调用深圳接口未返回success状态！");
					return result;
				}	
			}

			return result;
		}catch(Exception e){
			logger.info("同步更新工单状态出错！");
		}
		return result;
    }
}