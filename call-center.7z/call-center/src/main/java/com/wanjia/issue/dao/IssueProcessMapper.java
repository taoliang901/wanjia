package com.wanjia.issue.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseDao;
import com.wanjia.issue.bo.IssueProcess;
import com.wanjia.issue.bo.IssueProcessView;


public interface IssueProcessMapper extends IBaseDao {
	
	public IssueProcess searchProcessByIssueID(String issueID);
	
	List<IssueProcessView> queryIssueOperateLog(Map<String,Object> map);
}