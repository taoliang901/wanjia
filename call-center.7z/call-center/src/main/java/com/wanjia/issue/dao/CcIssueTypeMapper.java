package com.wanjia.issue.dao;

import com.wanjia.base.IBaseDao;

public interface CcIssueTypeMapper extends IBaseDao {
}