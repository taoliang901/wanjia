package com.wanjia.issue.bo;

import java.util.ArrayList;
import java.util.List;

public class CtiAppletParamExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CtiAppletParamExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andRoleCodeIsNull() {
            addCriterion("ROLE_CODE is null");
            return (Criteria) this;
        }

        public Criteria andRoleCodeIsNotNull() {
            addCriterion("ROLE_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andRoleCodeEqualTo(String value) {
            addCriterion("ROLE_CODE =", value, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeNotEqualTo(String value) {
            addCriterion("ROLE_CODE <>", value, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeGreaterThan(String value) {
            addCriterion("ROLE_CODE >", value, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeGreaterThanOrEqualTo(String value) {
            addCriterion("ROLE_CODE >=", value, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeLessThan(String value) {
            addCriterion("ROLE_CODE <", value, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeLessThanOrEqualTo(String value) {
            addCriterion("ROLE_CODE <=", value, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeLike(String value) {
            addCriterion("ROLE_CODE like", value, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeNotLike(String value) {
            addCriterion("ROLE_CODE not like", value, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeIn(List<String> values) {
            addCriterion("ROLE_CODE in", values, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeNotIn(List<String> values) {
            addCriterion("ROLE_CODE not in", values, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeBetween(String value1, String value2) {
            addCriterion("ROLE_CODE between", value1, value2, "roleCode");
            return (Criteria) this;
        }

        public Criteria andRoleCodeNotBetween(String value1, String value2) {
            addCriterion("ROLE_CODE not between", value1, value2, "roleCode");
            return (Criteria) this;
        }

        public Criteria andGuiFlagIsNull() {
            addCriterion("GUI_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andGuiFlagIsNotNull() {
            addCriterion("GUI_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andGuiFlagEqualTo(String value) {
            addCriterion("GUI_FLAG =", value, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagNotEqualTo(String value) {
            addCriterion("GUI_FLAG <>", value, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagGreaterThan(String value) {
            addCriterion("GUI_FLAG >", value, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagGreaterThanOrEqualTo(String value) {
            addCriterion("GUI_FLAG >=", value, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagLessThan(String value) {
            addCriterion("GUI_FLAG <", value, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagLessThanOrEqualTo(String value) {
            addCriterion("GUI_FLAG <=", value, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagLike(String value) {
            addCriterion("GUI_FLAG like", value, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagNotLike(String value) {
            addCriterion("GUI_FLAG not like", value, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagIn(List<String> values) {
            addCriterion("GUI_FLAG in", values, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagNotIn(List<String> values) {
            addCriterion("GUI_FLAG not in", values, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagBetween(String value1, String value2) {
            addCriterion("GUI_FLAG between", value1, value2, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andGuiFlagNotBetween(String value1, String value2) {
            addCriterion("GUI_FLAG not between", value1, value2, "guiFlag");
            return (Criteria) this;
        }

        public Criteria andCtiTypeIsNull() {
            addCriterion("CTI_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andCtiTypeIsNotNull() {
            addCriterion("CTI_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andCtiTypeEqualTo(String value) {
            addCriterion("CTI_TYPE =", value, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeNotEqualTo(String value) {
            addCriterion("CTI_TYPE <>", value, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeGreaterThan(String value) {
            addCriterion("CTI_TYPE >", value, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeGreaterThanOrEqualTo(String value) {
            addCriterion("CTI_TYPE >=", value, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeLessThan(String value) {
            addCriterion("CTI_TYPE <", value, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeLessThanOrEqualTo(String value) {
            addCriterion("CTI_TYPE <=", value, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeLike(String value) {
            addCriterion("CTI_TYPE like", value, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeNotLike(String value) {
            addCriterion("CTI_TYPE not like", value, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeIn(List<String> values) {
            addCriterion("CTI_TYPE in", values, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeNotIn(List<String> values) {
            addCriterion("CTI_TYPE not in", values, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeBetween(String value1, String value2) {
            addCriterion("CTI_TYPE between", value1, value2, "ctiType");
            return (Criteria) this;
        }

        public Criteria andCtiTypeNotBetween(String value1, String value2) {
            addCriterion("CTI_TYPE not between", value1, value2, "ctiType");
            return (Criteria) this;
        }

        public Criteria andAgentInfoIsNull() {
            addCriterion("AGENT_INFO is null");
            return (Criteria) this;
        }

        public Criteria andAgentInfoIsNotNull() {
            addCriterion("AGENT_INFO is not null");
            return (Criteria) this;
        }

        public Criteria andAgentInfoEqualTo(String value) {
            addCriterion("AGENT_INFO =", value, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoNotEqualTo(String value) {
            addCriterion("AGENT_INFO <>", value, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoGreaterThan(String value) {
            addCriterion("AGENT_INFO >", value, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoGreaterThanOrEqualTo(String value) {
            addCriterion("AGENT_INFO >=", value, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoLessThan(String value) {
            addCriterion("AGENT_INFO <", value, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoLessThanOrEqualTo(String value) {
            addCriterion("AGENT_INFO <=", value, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoLike(String value) {
            addCriterion("AGENT_INFO like", value, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoNotLike(String value) {
            addCriterion("AGENT_INFO not like", value, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoIn(List<String> values) {
            addCriterion("AGENT_INFO in", values, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoNotIn(List<String> values) {
            addCriterion("AGENT_INFO not in", values, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoBetween(String value1, String value2) {
            addCriterion("AGENT_INFO between", value1, value2, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andAgentInfoNotBetween(String value1, String value2) {
            addCriterion("AGENT_INFO not between", value1, value2, "agentInfo");
            return (Criteria) this;
        }

        public Criteria andDataTypeIsNull() {
            addCriterion("DATA_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andDataTypeIsNotNull() {
            addCriterion("DATA_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andDataTypeEqualTo(String value) {
            addCriterion("DATA_TYPE =", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeNotEqualTo(String value) {
            addCriterion("DATA_TYPE <>", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeGreaterThan(String value) {
            addCriterion("DATA_TYPE >", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_TYPE >=", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeLessThan(String value) {
            addCriterion("DATA_TYPE <", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeLessThanOrEqualTo(String value) {
            addCriterion("DATA_TYPE <=", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeLike(String value) {
            addCriterion("DATA_TYPE like", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeNotLike(String value) {
            addCriterion("DATA_TYPE not like", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeIn(List<String> values) {
            addCriterion("DATA_TYPE in", values, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeNotIn(List<String> values) {
            addCriterion("DATA_TYPE not in", values, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeBetween(String value1, String value2) {
            addCriterion("DATA_TYPE between", value1, value2, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeNotBetween(String value1, String value2) {
            addCriterion("DATA_TYPE not between", value1, value2, "dataType");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeIsNull() {
            addCriterion("NOT_READY_REASON_CODETYPE is null");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeIsNotNull() {
            addCriterion("NOT_READY_REASON_CODETYPE is not null");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeEqualTo(String value) {
            addCriterion("NOT_READY_REASON_CODETYPE =", value, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeNotEqualTo(String value) {
            addCriterion("NOT_READY_REASON_CODETYPE <>", value, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeGreaterThan(String value) {
            addCriterion("NOT_READY_REASON_CODETYPE >", value, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeGreaterThanOrEqualTo(String value) {
            addCriterion("NOT_READY_REASON_CODETYPE >=", value, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeLessThan(String value) {
            addCriterion("NOT_READY_REASON_CODETYPE <", value, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeLessThanOrEqualTo(String value) {
            addCriterion("NOT_READY_REASON_CODETYPE <=", value, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeLike(String value) {
            addCriterion("NOT_READY_REASON_CODETYPE like", value, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeNotLike(String value) {
            addCriterion("NOT_READY_REASON_CODETYPE not like", value, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeIn(List<String> values) {
            addCriterion("NOT_READY_REASON_CODETYPE in", values, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeNotIn(List<String> values) {
            addCriterion("NOT_READY_REASON_CODETYPE not in", values, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeBetween(String value1, String value2) {
            addCriterion("NOT_READY_REASON_CODETYPE between", value1, value2, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeNotBetween(String value1, String value2) {
            addCriterion("NOT_READY_REASON_CODETYPE not between", value1, value2, "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeIsNull() {
            addCriterion("NOT_READY_REASON_CODE is null");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeIsNotNull() {
            addCriterion("NOT_READY_REASON_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeEqualTo(String value) {
            addCriterion("NOT_READY_REASON_CODE =", value, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeNotEqualTo(String value) {
            addCriterion("NOT_READY_REASON_CODE <>", value, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeGreaterThan(String value) {
            addCriterion("NOT_READY_REASON_CODE >", value, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeGreaterThanOrEqualTo(String value) {
            addCriterion("NOT_READY_REASON_CODE >=", value, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeLessThan(String value) {
            addCriterion("NOT_READY_REASON_CODE <", value, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeLessThanOrEqualTo(String value) {
            addCriterion("NOT_READY_REASON_CODE <=", value, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeLike(String value) {
            addCriterion("NOT_READY_REASON_CODE like", value, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeNotLike(String value) {
            addCriterion("NOT_READY_REASON_CODE not like", value, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeIn(List<String> values) {
            addCriterion("NOT_READY_REASON_CODE in", values, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeNotIn(List<String> values) {
            addCriterion("NOT_READY_REASON_CODE not in", values, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeBetween(String value1, String value2) {
            addCriterion("NOT_READY_REASON_CODE between", value1, value2, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeNotBetween(String value1, String value2) {
            addCriterion("NOT_READY_REASON_CODE not between", value1, value2, "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeIsNull() {
            addCriterion("AGENT_READY_MODE is null");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeIsNotNull() {
            addCriterion("AGENT_READY_MODE is not null");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeEqualTo(String value) {
            addCriterion("AGENT_READY_MODE =", value, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeNotEqualTo(String value) {
            addCriterion("AGENT_READY_MODE <>", value, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeGreaterThan(String value) {
            addCriterion("AGENT_READY_MODE >", value, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeGreaterThanOrEqualTo(String value) {
            addCriterion("AGENT_READY_MODE >=", value, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeLessThan(String value) {
            addCriterion("AGENT_READY_MODE <", value, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeLessThanOrEqualTo(String value) {
            addCriterion("AGENT_READY_MODE <=", value, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeLike(String value) {
            addCriterion("AGENT_READY_MODE like", value, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeNotLike(String value) {
            addCriterion("AGENT_READY_MODE not like", value, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeIn(List<String> values) {
            addCriterion("AGENT_READY_MODE in", values, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeNotIn(List<String> values) {
            addCriterion("AGENT_READY_MODE not in", values, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeBetween(String value1, String value2) {
            addCriterion("AGENT_READY_MODE between", value1, value2, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeNotBetween(String value1, String value2) {
            addCriterion("AGENT_READY_MODE not between", value1, value2, "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andDialstringOutIsNull() {
            addCriterion("DIALSTRING_OUT is null");
            return (Criteria) this;
        }

        public Criteria andDialstringOutIsNotNull() {
            addCriterion("DIALSTRING_OUT is not null");
            return (Criteria) this;
        }

        public Criteria andDialstringOutEqualTo(String value) {
            addCriterion("DIALSTRING_OUT =", value, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutNotEqualTo(String value) {
            addCriterion("DIALSTRING_OUT <>", value, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutGreaterThan(String value) {
            addCriterion("DIALSTRING_OUT >", value, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutGreaterThanOrEqualTo(String value) {
            addCriterion("DIALSTRING_OUT >=", value, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutLessThan(String value) {
            addCriterion("DIALSTRING_OUT <", value, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutLessThanOrEqualTo(String value) {
            addCriterion("DIALSTRING_OUT <=", value, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutLike(String value) {
            addCriterion("DIALSTRING_OUT like", value, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutNotLike(String value) {
            addCriterion("DIALSTRING_OUT not like", value, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutIn(List<String> values) {
            addCriterion("DIALSTRING_OUT in", values, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutNotIn(List<String> values) {
            addCriterion("DIALSTRING_OUT not in", values, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutBetween(String value1, String value2) {
            addCriterion("DIALSTRING_OUT between", value1, value2, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andDialstringOutNotBetween(String value1, String value2) {
            addCriterion("DIALSTRING_OUT not between", value1, value2, "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchIsNull() {
            addCriterion("ACW_SWITCH is null");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchIsNotNull() {
            addCriterion("ACW_SWITCH is not null");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchEqualTo(String value) {
            addCriterion("ACW_SWITCH =", value, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchNotEqualTo(String value) {
            addCriterion("ACW_SWITCH <>", value, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchGreaterThan(String value) {
            addCriterion("ACW_SWITCH >", value, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchGreaterThanOrEqualTo(String value) {
            addCriterion("ACW_SWITCH >=", value, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchLessThan(String value) {
            addCriterion("ACW_SWITCH <", value, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchLessThanOrEqualTo(String value) {
            addCriterion("ACW_SWITCH <=", value, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchLike(String value) {
            addCriterion("ACW_SWITCH like", value, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchNotLike(String value) {
            addCriterion("ACW_SWITCH not like", value, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchIn(List<String> values) {
            addCriterion("ACW_SWITCH in", values, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchNotIn(List<String> values) {
            addCriterion("ACW_SWITCH not in", values, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchBetween(String value1, String value2) {
            addCriterion("ACW_SWITCH between", value1, value2, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchNotBetween(String value1, String value2) {
            addCriterion("ACW_SWITCH not between", value1, value2, "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andEnvIsNull() {
            addCriterion("ENV is null");
            return (Criteria) this;
        }

        public Criteria andEnvIsNotNull() {
            addCriterion("ENV is not null");
            return (Criteria) this;
        }

        public Criteria andEnvEqualTo(String value) {
            addCriterion("ENV =", value, "env");
            return (Criteria) this;
        }

        public Criteria andEnvNotEqualTo(String value) {
            addCriterion("ENV <>", value, "env");
            return (Criteria) this;
        }

        public Criteria andEnvGreaterThan(String value) {
            addCriterion("ENV >", value, "env");
            return (Criteria) this;
        }

        public Criteria andEnvGreaterThanOrEqualTo(String value) {
            addCriterion("ENV >=", value, "env");
            return (Criteria) this;
        }

        public Criteria andEnvLessThan(String value) {
            addCriterion("ENV <", value, "env");
            return (Criteria) this;
        }

        public Criteria andEnvLessThanOrEqualTo(String value) {
            addCriterion("ENV <=", value, "env");
            return (Criteria) this;
        }

        public Criteria andEnvLike(String value) {
            addCriterion("ENV like", value, "env");
            return (Criteria) this;
        }

        public Criteria andEnvNotLike(String value) {
            addCriterion("ENV not like", value, "env");
            return (Criteria) this;
        }

        public Criteria andEnvIn(List<String> values) {
            addCriterion("ENV in", values, "env");
            return (Criteria) this;
        }

        public Criteria andEnvNotIn(List<String> values) {
            addCriterion("ENV not in", values, "env");
            return (Criteria) this;
        }

        public Criteria andEnvBetween(String value1, String value2) {
            addCriterion("ENV between", value1, value2, "env");
            return (Criteria) this;
        }

        public Criteria andEnvNotBetween(String value1, String value2) {
            addCriterion("ENV not between", value1, value2, "env");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeIsNull() {
            addCriterion("SUMIT_ENDCODETIME is null");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeIsNotNull() {
            addCriterion("SUMIT_ENDCODETIME is not null");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeEqualTo(String value) {
            addCriterion("SUMIT_ENDCODETIME =", value, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeNotEqualTo(String value) {
            addCriterion("SUMIT_ENDCODETIME <>", value, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeGreaterThan(String value) {
            addCriterion("SUMIT_ENDCODETIME >", value, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeGreaterThanOrEqualTo(String value) {
            addCriterion("SUMIT_ENDCODETIME >=", value, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeLessThan(String value) {
            addCriterion("SUMIT_ENDCODETIME <", value, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeLessThanOrEqualTo(String value) {
            addCriterion("SUMIT_ENDCODETIME <=", value, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeLike(String value) {
            addCriterion("SUMIT_ENDCODETIME like", value, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeNotLike(String value) {
            addCriterion("SUMIT_ENDCODETIME not like", value, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeIn(List<String> values) {
            addCriterion("SUMIT_ENDCODETIME in", values, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeNotIn(List<String> values) {
            addCriterion("SUMIT_ENDCODETIME not in", values, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeBetween(String value1, String value2) {
            addCriterion("SUMIT_ENDCODETIME between", value1, value2, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeNotBetween(String value1, String value2) {
            addCriterion("SUMIT_ENDCODETIME not between", value1, value2, "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeIsNull() {
            addCriterion("DEFAULT_ENDCODE is null");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeIsNotNull() {
            addCriterion("DEFAULT_ENDCODE is not null");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeEqualTo(String value) {
            addCriterion("DEFAULT_ENDCODE =", value, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeNotEqualTo(String value) {
            addCriterion("DEFAULT_ENDCODE <>", value, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeGreaterThan(String value) {
            addCriterion("DEFAULT_ENDCODE >", value, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeGreaterThanOrEqualTo(String value) {
            addCriterion("DEFAULT_ENDCODE >=", value, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeLessThan(String value) {
            addCriterion("DEFAULT_ENDCODE <", value, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeLessThanOrEqualTo(String value) {
            addCriterion("DEFAULT_ENDCODE <=", value, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeLike(String value) {
            addCriterion("DEFAULT_ENDCODE like", value, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeNotLike(String value) {
            addCriterion("DEFAULT_ENDCODE not like", value, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeIn(List<String> values) {
            addCriterion("DEFAULT_ENDCODE in", values, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeNotIn(List<String> values) {
            addCriterion("DEFAULT_ENDCODE not in", values, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeBetween(String value1, String value2) {
            addCriterion("DEFAULT_ENDCODE between", value1, value2, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeNotBetween(String value1, String value2) {
            addCriterion("DEFAULT_ENDCODE not between", value1, value2, "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andButtonStyleIsNull() {
            addCriterion("BUTTON_STYLE is null");
            return (Criteria) this;
        }

        public Criteria andButtonStyleIsNotNull() {
            addCriterion("BUTTON_STYLE is not null");
            return (Criteria) this;
        }

        public Criteria andButtonStyleEqualTo(String value) {
            addCriterion("BUTTON_STYLE =", value, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleNotEqualTo(String value) {
            addCriterion("BUTTON_STYLE <>", value, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleGreaterThan(String value) {
            addCriterion("BUTTON_STYLE >", value, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleGreaterThanOrEqualTo(String value) {
            addCriterion("BUTTON_STYLE >=", value, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleLessThan(String value) {
            addCriterion("BUTTON_STYLE <", value, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleLessThanOrEqualTo(String value) {
            addCriterion("BUTTON_STYLE <=", value, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleLike(String value) {
            addCriterion("BUTTON_STYLE like", value, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleNotLike(String value) {
            addCriterion("BUTTON_STYLE not like", value, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleIn(List<String> values) {
            addCriterion("BUTTON_STYLE in", values, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleNotIn(List<String> values) {
            addCriterion("BUTTON_STYLE not in", values, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleBetween(String value1, String value2) {
            addCriterion("BUTTON_STYLE between", value1, value2, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButtonStyleNotBetween(String value1, String value2) {
            addCriterion("BUTTON_STYLE not between", value1, value2, "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginIsNull() {
            addCriterion("BUT_LOGIN_LOGIN is null");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginIsNotNull() {
            addCriterion("BUT_LOGIN_LOGIN is not null");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginEqualTo(String value) {
            addCriterion("BUT_LOGIN_LOGIN =", value, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginNotEqualTo(String value) {
            addCriterion("BUT_LOGIN_LOGIN <>", value, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginGreaterThan(String value) {
            addCriterion("BUT_LOGIN_LOGIN >", value, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_LOGIN_LOGIN >=", value, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginLessThan(String value) {
            addCriterion("BUT_LOGIN_LOGIN <", value, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginLessThanOrEqualTo(String value) {
            addCriterion("BUT_LOGIN_LOGIN <=", value, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginLike(String value) {
            addCriterion("BUT_LOGIN_LOGIN like", value, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginNotLike(String value) {
            addCriterion("BUT_LOGIN_LOGIN not like", value, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginIn(List<String> values) {
            addCriterion("BUT_LOGIN_LOGIN in", values, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginNotIn(List<String> values) {
            addCriterion("BUT_LOGIN_LOGIN not in", values, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginBetween(String value1, String value2) {
            addCriterion("BUT_LOGIN_LOGIN between", value1, value2, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginNotBetween(String value1, String value2) {
            addCriterion("BUT_LOGIN_LOGIN not between", value1, value2, "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButOutboundIsNull() {
            addCriterion("BUT_OUTBOUND is null");
            return (Criteria) this;
        }

        public Criteria andButOutboundIsNotNull() {
            addCriterion("BUT_OUTBOUND is not null");
            return (Criteria) this;
        }

        public Criteria andButOutboundEqualTo(String value) {
            addCriterion("BUT_OUTBOUND =", value, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundNotEqualTo(String value) {
            addCriterion("BUT_OUTBOUND <>", value, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundGreaterThan(String value) {
            addCriterion("BUT_OUTBOUND >", value, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_OUTBOUND >=", value, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundLessThan(String value) {
            addCriterion("BUT_OUTBOUND <", value, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundLessThanOrEqualTo(String value) {
            addCriterion("BUT_OUTBOUND <=", value, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundLike(String value) {
            addCriterion("BUT_OUTBOUND like", value, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundNotLike(String value) {
            addCriterion("BUT_OUTBOUND not like", value, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundIn(List<String> values) {
            addCriterion("BUT_OUTBOUND in", values, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundNotIn(List<String> values) {
            addCriterion("BUT_OUTBOUND not in", values, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundBetween(String value1, String value2) {
            addCriterion("BUT_OUTBOUND between", value1, value2, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButOutboundNotBetween(String value1, String value2) {
            addCriterion("BUT_OUTBOUND not between", value1, value2, "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButHangupIsNull() {
            addCriterion("BUT_HANGUP is null");
            return (Criteria) this;
        }

        public Criteria andButHangupIsNotNull() {
            addCriterion("BUT_HANGUP is not null");
            return (Criteria) this;
        }

        public Criteria andButHangupEqualTo(String value) {
            addCriterion("BUT_HANGUP =", value, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupNotEqualTo(String value) {
            addCriterion("BUT_HANGUP <>", value, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupGreaterThan(String value) {
            addCriterion("BUT_HANGUP >", value, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_HANGUP >=", value, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupLessThan(String value) {
            addCriterion("BUT_HANGUP <", value, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupLessThanOrEqualTo(String value) {
            addCriterion("BUT_HANGUP <=", value, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupLike(String value) {
            addCriterion("BUT_HANGUP like", value, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupNotLike(String value) {
            addCriterion("BUT_HANGUP not like", value, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupIn(List<String> values) {
            addCriterion("BUT_HANGUP in", values, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupNotIn(List<String> values) {
            addCriterion("BUT_HANGUP not in", values, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupBetween(String value1, String value2) {
            addCriterion("BUT_HANGUP between", value1, value2, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButHangupNotBetween(String value1, String value2) {
            addCriterion("BUT_HANGUP not between", value1, value2, "butHangup");
            return (Criteria) this;
        }

        public Criteria andButAnswerIsNull() {
            addCriterion("BUT_ANSWER is null");
            return (Criteria) this;
        }

        public Criteria andButAnswerIsNotNull() {
            addCriterion("BUT_ANSWER is not null");
            return (Criteria) this;
        }

        public Criteria andButAnswerEqualTo(String value) {
            addCriterion("BUT_ANSWER =", value, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerNotEqualTo(String value) {
            addCriterion("BUT_ANSWER <>", value, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerGreaterThan(String value) {
            addCriterion("BUT_ANSWER >", value, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_ANSWER >=", value, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerLessThan(String value) {
            addCriterion("BUT_ANSWER <", value, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerLessThanOrEqualTo(String value) {
            addCriterion("BUT_ANSWER <=", value, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerLike(String value) {
            addCriterion("BUT_ANSWER like", value, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerNotLike(String value) {
            addCriterion("BUT_ANSWER not like", value, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerIn(List<String> values) {
            addCriterion("BUT_ANSWER in", values, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerNotIn(List<String> values) {
            addCriterion("BUT_ANSWER not in", values, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerBetween(String value1, String value2) {
            addCriterion("BUT_ANSWER between", value1, value2, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButAnswerNotBetween(String value1, String value2) {
            addCriterion("BUT_ANSWER not between", value1, value2, "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButDtmfIsNull() {
            addCriterion("BUT_DTMF is null");
            return (Criteria) this;
        }

        public Criteria andButDtmfIsNotNull() {
            addCriterion("BUT_DTMF is not null");
            return (Criteria) this;
        }

        public Criteria andButDtmfEqualTo(String value) {
            addCriterion("BUT_DTMF =", value, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfNotEqualTo(String value) {
            addCriterion("BUT_DTMF <>", value, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfGreaterThan(String value) {
            addCriterion("BUT_DTMF >", value, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_DTMF >=", value, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfLessThan(String value) {
            addCriterion("BUT_DTMF <", value, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfLessThanOrEqualTo(String value) {
            addCriterion("BUT_DTMF <=", value, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfLike(String value) {
            addCriterion("BUT_DTMF like", value, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfNotLike(String value) {
            addCriterion("BUT_DTMF not like", value, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfIn(List<String> values) {
            addCriterion("BUT_DTMF in", values, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfNotIn(List<String> values) {
            addCriterion("BUT_DTMF not in", values, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfBetween(String value1, String value2) {
            addCriterion("BUT_DTMF between", value1, value2, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButDtmfNotBetween(String value1, String value2) {
            addCriterion("BUT_DTMF not between", value1, value2, "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenIsNull() {
            addCriterion("BUT_WORKING_STATUS_OPEN is null");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenIsNotNull() {
            addCriterion("BUT_WORKING_STATUS_OPEN is not null");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenEqualTo(String value) {
            addCriterion("BUT_WORKING_STATUS_OPEN =", value, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenNotEqualTo(String value) {
            addCriterion("BUT_WORKING_STATUS_OPEN <>", value, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenGreaterThan(String value) {
            addCriterion("BUT_WORKING_STATUS_OPEN >", value, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_WORKING_STATUS_OPEN >=", value, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenLessThan(String value) {
            addCriterion("BUT_WORKING_STATUS_OPEN <", value, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenLessThanOrEqualTo(String value) {
            addCriterion("BUT_WORKING_STATUS_OPEN <=", value, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenLike(String value) {
            addCriterion("BUT_WORKING_STATUS_OPEN like", value, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenNotLike(String value) {
            addCriterion("BUT_WORKING_STATUS_OPEN not like", value, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenIn(List<String> values) {
            addCriterion("BUT_WORKING_STATUS_OPEN in", values, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenNotIn(List<String> values) {
            addCriterion("BUT_WORKING_STATUS_OPEN not in", values, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenBetween(String value1, String value2) {
            addCriterion("BUT_WORKING_STATUS_OPEN between", value1, value2, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenNotBetween(String value1, String value2) {
            addCriterion("BUT_WORKING_STATUS_OPEN not between", value1, value2, "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButBookIsNull() {
            addCriterion("BUT_BOOK is null");
            return (Criteria) this;
        }

        public Criteria andButBookIsNotNull() {
            addCriterion("BUT_BOOK is not null");
            return (Criteria) this;
        }

        public Criteria andButBookEqualTo(String value) {
            addCriterion("BUT_BOOK =", value, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookNotEqualTo(String value) {
            addCriterion("BUT_BOOK <>", value, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookGreaterThan(String value) {
            addCriterion("BUT_BOOK >", value, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_BOOK >=", value, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookLessThan(String value) {
            addCriterion("BUT_BOOK <", value, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookLessThanOrEqualTo(String value) {
            addCriterion("BUT_BOOK <=", value, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookLike(String value) {
            addCriterion("BUT_BOOK like", value, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookNotLike(String value) {
            addCriterion("BUT_BOOK not like", value, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookIn(List<String> values) {
            addCriterion("BUT_BOOK in", values, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookNotIn(List<String> values) {
            addCriterion("BUT_BOOK not in", values, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookBetween(String value1, String value2) {
            addCriterion("BUT_BOOK between", value1, value2, "butBook");
            return (Criteria) this;
        }

        public Criteria andButBookNotBetween(String value1, String value2) {
            addCriterion("BUT_BOOK not between", value1, value2, "butBook");
            return (Criteria) this;
        }

        public Criteria andButHoldonIsNull() {
            addCriterion("BUT_HOLDON is null");
            return (Criteria) this;
        }

        public Criteria andButHoldonIsNotNull() {
            addCriterion("BUT_HOLDON is not null");
            return (Criteria) this;
        }

        public Criteria andButHoldonEqualTo(String value) {
            addCriterion("BUT_HOLDON =", value, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonNotEqualTo(String value) {
            addCriterion("BUT_HOLDON <>", value, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonGreaterThan(String value) {
            addCriterion("BUT_HOLDON >", value, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_HOLDON >=", value, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonLessThan(String value) {
            addCriterion("BUT_HOLDON <", value, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonLessThanOrEqualTo(String value) {
            addCriterion("BUT_HOLDON <=", value, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonLike(String value) {
            addCriterion("BUT_HOLDON like", value, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonNotLike(String value) {
            addCriterion("BUT_HOLDON not like", value, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonIn(List<String> values) {
            addCriterion("BUT_HOLDON in", values, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonNotIn(List<String> values) {
            addCriterion("BUT_HOLDON not in", values, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonBetween(String value1, String value2) {
            addCriterion("BUT_HOLDON between", value1, value2, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButHoldonNotBetween(String value1, String value2) {
            addCriterion("BUT_HOLDON not between", value1, value2, "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButTransferIsNull() {
            addCriterion("BUT_TRANSFER is null");
            return (Criteria) this;
        }

        public Criteria andButTransferIsNotNull() {
            addCriterion("BUT_TRANSFER is not null");
            return (Criteria) this;
        }

        public Criteria andButTransferEqualTo(String value) {
            addCriterion("BUT_TRANSFER =", value, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferNotEqualTo(String value) {
            addCriterion("BUT_TRANSFER <>", value, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferGreaterThan(String value) {
            addCriterion("BUT_TRANSFER >", value, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_TRANSFER >=", value, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferLessThan(String value) {
            addCriterion("BUT_TRANSFER <", value, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferLessThanOrEqualTo(String value) {
            addCriterion("BUT_TRANSFER <=", value, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferLike(String value) {
            addCriterion("BUT_TRANSFER like", value, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferNotLike(String value) {
            addCriterion("BUT_TRANSFER not like", value, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferIn(List<String> values) {
            addCriterion("BUT_TRANSFER in", values, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferNotIn(List<String> values) {
            addCriterion("BUT_TRANSFER not in", values, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferBetween(String value1, String value2) {
            addCriterion("BUT_TRANSFER between", value1, value2, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButTransferNotBetween(String value1, String value2) {
            addCriterion("BUT_TRANSFER not between", value1, value2, "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButMeetingIsNull() {
            addCriterion("BUT_MEETING is null");
            return (Criteria) this;
        }

        public Criteria andButMeetingIsNotNull() {
            addCriterion("BUT_MEETING is not null");
            return (Criteria) this;
        }

        public Criteria andButMeetingEqualTo(String value) {
            addCriterion("BUT_MEETING =", value, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingNotEqualTo(String value) {
            addCriterion("BUT_MEETING <>", value, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingGreaterThan(String value) {
            addCriterion("BUT_MEETING >", value, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_MEETING >=", value, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingLessThan(String value) {
            addCriterion("BUT_MEETING <", value, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingLessThanOrEqualTo(String value) {
            addCriterion("BUT_MEETING <=", value, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingLike(String value) {
            addCriterion("BUT_MEETING like", value, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingNotLike(String value) {
            addCriterion("BUT_MEETING not like", value, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingIn(List<String> values) {
            addCriterion("BUT_MEETING in", values, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingNotIn(List<String> values) {
            addCriterion("BUT_MEETING not in", values, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingBetween(String value1, String value2) {
            addCriterion("BUT_MEETING between", value1, value2, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButMeetingNotBetween(String value1, String value2) {
            addCriterion("BUT_MEETING not between", value1, value2, "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButAttachjobIsNull() {
            addCriterion("BUT_ATTACHJOB is null");
            return (Criteria) this;
        }

        public Criteria andButAttachjobIsNotNull() {
            addCriterion("BUT_ATTACHJOB is not null");
            return (Criteria) this;
        }

        public Criteria andButAttachjobEqualTo(String value) {
            addCriterion("BUT_ATTACHJOB =", value, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobNotEqualTo(String value) {
            addCriterion("BUT_ATTACHJOB <>", value, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobGreaterThan(String value) {
            addCriterion("BUT_ATTACHJOB >", value, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_ATTACHJOB >=", value, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobLessThan(String value) {
            addCriterion("BUT_ATTACHJOB <", value, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobLessThanOrEqualTo(String value) {
            addCriterion("BUT_ATTACHJOB <=", value, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobLike(String value) {
            addCriterion("BUT_ATTACHJOB like", value, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobNotLike(String value) {
            addCriterion("BUT_ATTACHJOB not like", value, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobIn(List<String> values) {
            addCriterion("BUT_ATTACHJOB in", values, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobNotIn(List<String> values) {
            addCriterion("BUT_ATTACHJOB not in", values, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobBetween(String value1, String value2) {
            addCriterion("BUT_ATTACHJOB between", value1, value2, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButAttachjobNotBetween(String value1, String value2) {
            addCriterion("BUT_ATTACHJOB not between", value1, value2, "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButListenIsNull() {
            addCriterion("BUT_LISTEN is null");
            return (Criteria) this;
        }

        public Criteria andButListenIsNotNull() {
            addCriterion("BUT_LISTEN is not null");
            return (Criteria) this;
        }

        public Criteria andButListenEqualTo(String value) {
            addCriterion("BUT_LISTEN =", value, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenNotEqualTo(String value) {
            addCriterion("BUT_LISTEN <>", value, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenGreaterThan(String value) {
            addCriterion("BUT_LISTEN >", value, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_LISTEN >=", value, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenLessThan(String value) {
            addCriterion("BUT_LISTEN <", value, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenLessThanOrEqualTo(String value) {
            addCriterion("BUT_LISTEN <=", value, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenLike(String value) {
            addCriterion("BUT_LISTEN like", value, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenNotLike(String value) {
            addCriterion("BUT_LISTEN not like", value, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenIn(List<String> values) {
            addCriterion("BUT_LISTEN in", values, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenNotIn(List<String> values) {
            addCriterion("BUT_LISTEN not in", values, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenBetween(String value1, String value2) {
            addCriterion("BUT_LISTEN between", value1, value2, "butListen");
            return (Criteria) this;
        }

        public Criteria andButListenNotBetween(String value1, String value2) {
            addCriterion("BUT_LISTEN not between", value1, value2, "butListen");
            return (Criteria) this;
        }

        public Criteria andButForceInsertIsNull() {
            addCriterion("BUT_FORCE_INSERT is null");
            return (Criteria) this;
        }

        public Criteria andButForceInsertIsNotNull() {
            addCriterion("BUT_FORCE_INSERT is not null");
            return (Criteria) this;
        }

        public Criteria andButForceInsertEqualTo(String value) {
            addCriterion("BUT_FORCE_INSERT =", value, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertNotEqualTo(String value) {
            addCriterion("BUT_FORCE_INSERT <>", value, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertGreaterThan(String value) {
            addCriterion("BUT_FORCE_INSERT >", value, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_FORCE_INSERT >=", value, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertLessThan(String value) {
            addCriterion("BUT_FORCE_INSERT <", value, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertLessThanOrEqualTo(String value) {
            addCriterion("BUT_FORCE_INSERT <=", value, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertLike(String value) {
            addCriterion("BUT_FORCE_INSERT like", value, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertNotLike(String value) {
            addCriterion("BUT_FORCE_INSERT not like", value, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertIn(List<String> values) {
            addCriterion("BUT_FORCE_INSERT in", values, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertNotIn(List<String> values) {
            addCriterion("BUT_FORCE_INSERT not in", values, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertBetween(String value1, String value2) {
            addCriterion("BUT_FORCE_INSERT between", value1, value2, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceInsertNotBetween(String value1, String value2) {
            addCriterion("BUT_FORCE_INSERT not between", value1, value2, "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutIsNull() {
            addCriterion("BUT_FORCE_BACKOUT is null");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutIsNotNull() {
            addCriterion("BUT_FORCE_BACKOUT is not null");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutEqualTo(String value) {
            addCriterion("BUT_FORCE_BACKOUT =", value, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutNotEqualTo(String value) {
            addCriterion("BUT_FORCE_BACKOUT <>", value, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutGreaterThan(String value) {
            addCriterion("BUT_FORCE_BACKOUT >", value, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutGreaterThanOrEqualTo(String value) {
            addCriterion("BUT_FORCE_BACKOUT >=", value, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutLessThan(String value) {
            addCriterion("BUT_FORCE_BACKOUT <", value, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutLessThanOrEqualTo(String value) {
            addCriterion("BUT_FORCE_BACKOUT <=", value, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutLike(String value) {
            addCriterion("BUT_FORCE_BACKOUT like", value, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutNotLike(String value) {
            addCriterion("BUT_FORCE_BACKOUT not like", value, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutIn(List<String> values) {
            addCriterion("BUT_FORCE_BACKOUT in", values, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutNotIn(List<String> values) {
            addCriterion("BUT_FORCE_BACKOUT not in", values, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutBetween(String value1, String value2) {
            addCriterion("BUT_FORCE_BACKOUT between", value1, value2, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutNotBetween(String value1, String value2) {
            addCriterion("BUT_FORCE_BACKOUT not between", value1, value2, "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andAniTextIsNull() {
            addCriterion("ANI_TEXT is null");
            return (Criteria) this;
        }

        public Criteria andAniTextIsNotNull() {
            addCriterion("ANI_TEXT is not null");
            return (Criteria) this;
        }

        public Criteria andAniTextEqualTo(String value) {
            addCriterion("ANI_TEXT =", value, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextNotEqualTo(String value) {
            addCriterion("ANI_TEXT <>", value, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextGreaterThan(String value) {
            addCriterion("ANI_TEXT >", value, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextGreaterThanOrEqualTo(String value) {
            addCriterion("ANI_TEXT >=", value, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextLessThan(String value) {
            addCriterion("ANI_TEXT <", value, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextLessThanOrEqualTo(String value) {
            addCriterion("ANI_TEXT <=", value, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextLike(String value) {
            addCriterion("ANI_TEXT like", value, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextNotLike(String value) {
            addCriterion("ANI_TEXT not like", value, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextIn(List<String> values) {
            addCriterion("ANI_TEXT in", values, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextNotIn(List<String> values) {
            addCriterion("ANI_TEXT not in", values, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextBetween(String value1, String value2) {
            addCriterion("ANI_TEXT between", value1, value2, "aniText");
            return (Criteria) this;
        }

        public Criteria andAniTextNotBetween(String value1, String value2) {
            addCriterion("ANI_TEXT not between", value1, value2, "aniText");
            return (Criteria) this;
        }

        public Criteria andDnisTextIsNull() {
            addCriterion("DNIS_TEXT is null");
            return (Criteria) this;
        }

        public Criteria andDnisTextIsNotNull() {
            addCriterion("DNIS_TEXT is not null");
            return (Criteria) this;
        }

        public Criteria andDnisTextEqualTo(String value) {
            addCriterion("DNIS_TEXT =", value, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextNotEqualTo(String value) {
            addCriterion("DNIS_TEXT <>", value, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextGreaterThan(String value) {
            addCriterion("DNIS_TEXT >", value, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextGreaterThanOrEqualTo(String value) {
            addCriterion("DNIS_TEXT >=", value, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextLessThan(String value) {
            addCriterion("DNIS_TEXT <", value, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextLessThanOrEqualTo(String value) {
            addCriterion("DNIS_TEXT <=", value, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextLike(String value) {
            addCriterion("DNIS_TEXT like", value, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextNotLike(String value) {
            addCriterion("DNIS_TEXT not like", value, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextIn(List<String> values) {
            addCriterion("DNIS_TEXT in", values, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextNotIn(List<String> values) {
            addCriterion("DNIS_TEXT not in", values, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextBetween(String value1, String value2) {
            addCriterion("DNIS_TEXT between", value1, value2, "dnisText");
            return (Criteria) this;
        }

        public Criteria andDnisTextNotBetween(String value1, String value2) {
            addCriterion("DNIS_TEXT not between", value1, value2, "dnisText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextIsNull() {
            addCriterion("TALK_TIME_TEXT is null");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextIsNotNull() {
            addCriterion("TALK_TIME_TEXT is not null");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextEqualTo(String value) {
            addCriterion("TALK_TIME_TEXT =", value, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextNotEqualTo(String value) {
            addCriterion("TALK_TIME_TEXT <>", value, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextGreaterThan(String value) {
            addCriterion("TALK_TIME_TEXT >", value, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextGreaterThanOrEqualTo(String value) {
            addCriterion("TALK_TIME_TEXT >=", value, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextLessThan(String value) {
            addCriterion("TALK_TIME_TEXT <", value, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextLessThanOrEqualTo(String value) {
            addCriterion("TALK_TIME_TEXT <=", value, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextLike(String value) {
            addCriterion("TALK_TIME_TEXT like", value, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextNotLike(String value) {
            addCriterion("TALK_TIME_TEXT not like", value, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextIn(List<String> values) {
            addCriterion("TALK_TIME_TEXT in", values, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextNotIn(List<String> values) {
            addCriterion("TALK_TIME_TEXT not in", values, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextBetween(String value1, String value2) {
            addCriterion("TALK_TIME_TEXT between", value1, value2, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextNotBetween(String value1, String value2) {
            addCriterion("TALK_TIME_TEXT not between", value1, value2, "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextIsNull() {
            addCriterion("CURRENT_STATE_TIME_TEXT is null");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextIsNotNull() {
            addCriterion("CURRENT_STATE_TIME_TEXT is not null");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextEqualTo(String value) {
            addCriterion("CURRENT_STATE_TIME_TEXT =", value, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextNotEqualTo(String value) {
            addCriterion("CURRENT_STATE_TIME_TEXT <>", value, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextGreaterThan(String value) {
            addCriterion("CURRENT_STATE_TIME_TEXT >", value, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextGreaterThanOrEqualTo(String value) {
            addCriterion("CURRENT_STATE_TIME_TEXT >=", value, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextLessThan(String value) {
            addCriterion("CURRENT_STATE_TIME_TEXT <", value, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextLessThanOrEqualTo(String value) {
            addCriterion("CURRENT_STATE_TIME_TEXT <=", value, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextLike(String value) {
            addCriterion("CURRENT_STATE_TIME_TEXT like", value, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextNotLike(String value) {
            addCriterion("CURRENT_STATE_TIME_TEXT not like", value, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextIn(List<String> values) {
            addCriterion("CURRENT_STATE_TIME_TEXT in", values, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextNotIn(List<String> values) {
            addCriterion("CURRENT_STATE_TIME_TEXT not in", values, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextBetween(String value1, String value2) {
            addCriterion("CURRENT_STATE_TIME_TEXT between", value1, value2, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextNotBetween(String value1, String value2) {
            addCriterion("CURRENT_STATE_TIME_TEXT not between", value1, value2, "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextIsNull() {
            addCriterion("TALK_COUNT_TEXT is null");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextIsNotNull() {
            addCriterion("TALK_COUNT_TEXT is not null");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextEqualTo(String value) {
            addCriterion("TALK_COUNT_TEXT =", value, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextNotEqualTo(String value) {
            addCriterion("TALK_COUNT_TEXT <>", value, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextGreaterThan(String value) {
            addCriterion("TALK_COUNT_TEXT >", value, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextGreaterThanOrEqualTo(String value) {
            addCriterion("TALK_COUNT_TEXT >=", value, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextLessThan(String value) {
            addCriterion("TALK_COUNT_TEXT <", value, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextLessThanOrEqualTo(String value) {
            addCriterion("TALK_COUNT_TEXT <=", value, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextLike(String value) {
            addCriterion("TALK_COUNT_TEXT like", value, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextNotLike(String value) {
            addCriterion("TALK_COUNT_TEXT not like", value, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextIn(List<String> values) {
            addCriterion("TALK_COUNT_TEXT in", values, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextNotIn(List<String> values) {
            addCriterion("TALK_COUNT_TEXT not in", values, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextBetween(String value1, String value2) {
            addCriterion("TALK_COUNT_TEXT between", value1, value2, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextNotBetween(String value1, String value2) {
            addCriterion("TALK_COUNT_TEXT not between", value1, value2, "talkCountText");
            return (Criteria) this;
        }

        public Criteria andDialFrameIsNull() {
            addCriterion("DIAL_FRAME is null");
            return (Criteria) this;
        }

        public Criteria andDialFrameIsNotNull() {
            addCriterion("DIAL_FRAME is not null");
            return (Criteria) this;
        }

        public Criteria andDialFrameEqualTo(String value) {
            addCriterion("DIAL_FRAME =", value, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameNotEqualTo(String value) {
            addCriterion("DIAL_FRAME <>", value, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameGreaterThan(String value) {
            addCriterion("DIAL_FRAME >", value, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameGreaterThanOrEqualTo(String value) {
            addCriterion("DIAL_FRAME >=", value, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameLessThan(String value) {
            addCriterion("DIAL_FRAME <", value, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameLessThanOrEqualTo(String value) {
            addCriterion("DIAL_FRAME <=", value, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameLike(String value) {
            addCriterion("DIAL_FRAME like", value, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameNotLike(String value) {
            addCriterion("DIAL_FRAME not like", value, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameIn(List<String> values) {
            addCriterion("DIAL_FRAME in", values, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameNotIn(List<String> values) {
            addCriterion("DIAL_FRAME not in", values, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameBetween(String value1, String value2) {
            addCriterion("DIAL_FRAME between", value1, value2, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andDialFrameNotBetween(String value1, String value2) {
            addCriterion("DIAL_FRAME not between", value1, value2, "dialFrame");
            return (Criteria) this;
        }

        public Criteria andVerIsNull() {
            addCriterion("VER is null");
            return (Criteria) this;
        }

        public Criteria andVerIsNotNull() {
            addCriterion("VER is not null");
            return (Criteria) this;
        }

        public Criteria andVerEqualTo(String value) {
            addCriterion("VER =", value, "ver");
            return (Criteria) this;
        }

        public Criteria andVerNotEqualTo(String value) {
            addCriterion("VER <>", value, "ver");
            return (Criteria) this;
        }

        public Criteria andVerGreaterThan(String value) {
            addCriterion("VER >", value, "ver");
            return (Criteria) this;
        }

        public Criteria andVerGreaterThanOrEqualTo(String value) {
            addCriterion("VER >=", value, "ver");
            return (Criteria) this;
        }

        public Criteria andVerLessThan(String value) {
            addCriterion("VER <", value, "ver");
            return (Criteria) this;
        }

        public Criteria andVerLessThanOrEqualTo(String value) {
            addCriterion("VER <=", value, "ver");
            return (Criteria) this;
        }

        public Criteria andVerLike(String value) {
            addCriterion("VER like", value, "ver");
            return (Criteria) this;
        }

        public Criteria andVerNotLike(String value) {
            addCriterion("VER not like", value, "ver");
            return (Criteria) this;
        }

        public Criteria andVerIn(List<String> values) {
            addCriterion("VER in", values, "ver");
            return (Criteria) this;
        }

        public Criteria andVerNotIn(List<String> values) {
            addCriterion("VER not in", values, "ver");
            return (Criteria) this;
        }

        public Criteria andVerBetween(String value1, String value2) {
            addCriterion("VER between", value1, value2, "ver");
            return (Criteria) this;
        }

        public Criteria andVerNotBetween(String value1, String value2) {
            addCriterion("VER not between", value1, value2, "ver");
            return (Criteria) this;
        }

        public Criteria andStopFlagIsNull() {
            addCriterion("STOP_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andStopFlagIsNotNull() {
            addCriterion("STOP_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andStopFlagEqualTo(String value) {
            addCriterion("STOP_FLAG =", value, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagNotEqualTo(String value) {
            addCriterion("STOP_FLAG <>", value, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagGreaterThan(String value) {
            addCriterion("STOP_FLAG >", value, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagGreaterThanOrEqualTo(String value) {
            addCriterion("STOP_FLAG >=", value, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagLessThan(String value) {
            addCriterion("STOP_FLAG <", value, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagLessThanOrEqualTo(String value) {
            addCriterion("STOP_FLAG <=", value, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagLike(String value) {
            addCriterion("STOP_FLAG like", value, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagNotLike(String value) {
            addCriterion("STOP_FLAG not like", value, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagIn(List<String> values) {
            addCriterion("STOP_FLAG in", values, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagNotIn(List<String> values) {
            addCriterion("STOP_FLAG not in", values, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagBetween(String value1, String value2) {
            addCriterion("STOP_FLAG between", value1, value2, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andStopFlagNotBetween(String value1, String value2) {
            addCriterion("STOP_FLAG not between", value1, value2, "stopFlag");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberIsNull() {
            addCriterion("OUTDAIL_NUMBER is null");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberIsNotNull() {
            addCriterion("OUTDAIL_NUMBER is not null");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberEqualTo(String value) {
            addCriterion("OUTDAIL_NUMBER =", value, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberNotEqualTo(String value) {
            addCriterion("OUTDAIL_NUMBER <>", value, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberGreaterThan(String value) {
            addCriterion("OUTDAIL_NUMBER >", value, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberGreaterThanOrEqualTo(String value) {
            addCriterion("OUTDAIL_NUMBER >=", value, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberLessThan(String value) {
            addCriterion("OUTDAIL_NUMBER <", value, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberLessThanOrEqualTo(String value) {
            addCriterion("OUTDAIL_NUMBER <=", value, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberLike(String value) {
            addCriterion("OUTDAIL_NUMBER like", value, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberNotLike(String value) {
            addCriterion("OUTDAIL_NUMBER not like", value, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberIn(List<String> values) {
            addCriterion("OUTDAIL_NUMBER in", values, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberNotIn(List<String> values) {
            addCriterion("OUTDAIL_NUMBER not in", values, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberBetween(String value1, String value2) {
            addCriterion("OUTDAIL_NUMBER between", value1, value2, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberNotBetween(String value1, String value2) {
            addCriterion("OUTDAIL_NUMBER not between", value1, value2, "outdailNumber");
            return (Criteria) this;
        }

        public Criteria andIdLikeInsensitive(String value) {
            addCriterion("upper(ID) like", value.toUpperCase(), "id");
            return (Criteria) this;
        }

        public Criteria andRoleCodeLikeInsensitive(String value) {
            addCriterion("upper(ROLE_CODE) like", value.toUpperCase(), "roleCode");
            return (Criteria) this;
        }

        public Criteria andGuiFlagLikeInsensitive(String value) {
            addCriterion("upper(GUI_FLAG) like", value.toUpperCase(), "guiFlag");
            return (Criteria) this;
        }

        public Criteria andCtiTypeLikeInsensitive(String value) {
            addCriterion("upper(CTI_TYPE) like", value.toUpperCase(), "ctiType");
            return (Criteria) this;
        }

        public Criteria andAgentInfoLikeInsensitive(String value) {
            addCriterion("upper(AGENT_INFO) like", value.toUpperCase(), "agentInfo");
            return (Criteria) this;
        }

        public Criteria andDataTypeLikeInsensitive(String value) {
            addCriterion("upper(DATA_TYPE) like", value.toUpperCase(), "dataType");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodetypeLikeInsensitive(String value) {
            addCriterion("upper(NOT_READY_REASON_CODETYPE) like", value.toUpperCase(), "notReadyReasonCodetype");
            return (Criteria) this;
        }

        public Criteria andNotReadyReasonCodeLikeInsensitive(String value) {
            addCriterion("upper(NOT_READY_REASON_CODE) like", value.toUpperCase(), "notReadyReasonCode");
            return (Criteria) this;
        }

        public Criteria andAgentReadyModeLikeInsensitive(String value) {
            addCriterion("upper(AGENT_READY_MODE) like", value.toUpperCase(), "agentReadyMode");
            return (Criteria) this;
        }

        public Criteria andDialstringOutLikeInsensitive(String value) {
            addCriterion("upper(DIALSTRING_OUT) like", value.toUpperCase(), "dialstringOut");
            return (Criteria) this;
        }

        public Criteria andAcwSwitchLikeInsensitive(String value) {
            addCriterion("upper(ACW_SWITCH) like", value.toUpperCase(), "acwSwitch");
            return (Criteria) this;
        }

        public Criteria andEnvLikeInsensitive(String value) {
            addCriterion("upper(ENV) like", value.toUpperCase(), "env");
            return (Criteria) this;
        }

        public Criteria andSumitEndcodetimeLikeInsensitive(String value) {
            addCriterion("upper(SUMIT_ENDCODETIME) like", value.toUpperCase(), "sumitEndcodetime");
            return (Criteria) this;
        }

        public Criteria andDefaultEndcodeLikeInsensitive(String value) {
            addCriterion("upper(DEFAULT_ENDCODE) like", value.toUpperCase(), "defaultEndcode");
            return (Criteria) this;
        }

        public Criteria andButtonStyleLikeInsensitive(String value) {
            addCriterion("upper(BUTTON_STYLE) like", value.toUpperCase(), "buttonStyle");
            return (Criteria) this;
        }

        public Criteria andButLoginLoginLikeInsensitive(String value) {
            addCriterion("upper(BUT_LOGIN_LOGIN) like", value.toUpperCase(), "butLoginLogin");
            return (Criteria) this;
        }

        public Criteria andButOutboundLikeInsensitive(String value) {
            addCriterion("upper(BUT_OUTBOUND) like", value.toUpperCase(), "butOutbound");
            return (Criteria) this;
        }

        public Criteria andButHangupLikeInsensitive(String value) {
            addCriterion("upper(BUT_HANGUP) like", value.toUpperCase(), "butHangup");
            return (Criteria) this;
        }

        public Criteria andButAnswerLikeInsensitive(String value) {
            addCriterion("upper(BUT_ANSWER) like", value.toUpperCase(), "butAnswer");
            return (Criteria) this;
        }

        public Criteria andButDtmfLikeInsensitive(String value) {
            addCriterion("upper(BUT_DTMF) like", value.toUpperCase(), "butDtmf");
            return (Criteria) this;
        }

        public Criteria andButWorkingStatusOpenLikeInsensitive(String value) {
            addCriterion("upper(BUT_WORKING_STATUS_OPEN) like", value.toUpperCase(), "butWorkingStatusOpen");
            return (Criteria) this;
        }

        public Criteria andButBookLikeInsensitive(String value) {
            addCriterion("upper(BUT_BOOK) like", value.toUpperCase(), "butBook");
            return (Criteria) this;
        }

        public Criteria andButHoldonLikeInsensitive(String value) {
            addCriterion("upper(BUT_HOLDON) like", value.toUpperCase(), "butHoldon");
            return (Criteria) this;
        }

        public Criteria andButTransferLikeInsensitive(String value) {
            addCriterion("upper(BUT_TRANSFER) like", value.toUpperCase(), "butTransfer");
            return (Criteria) this;
        }

        public Criteria andButMeetingLikeInsensitive(String value) {
            addCriterion("upper(BUT_MEETING) like", value.toUpperCase(), "butMeeting");
            return (Criteria) this;
        }

        public Criteria andButAttachjobLikeInsensitive(String value) {
            addCriterion("upper(BUT_ATTACHJOB) like", value.toUpperCase(), "butAttachjob");
            return (Criteria) this;
        }

        public Criteria andButListenLikeInsensitive(String value) {
            addCriterion("upper(BUT_LISTEN) like", value.toUpperCase(), "butListen");
            return (Criteria) this;
        }

        public Criteria andButForceInsertLikeInsensitive(String value) {
            addCriterion("upper(BUT_FORCE_INSERT) like", value.toUpperCase(), "butForceInsert");
            return (Criteria) this;
        }

        public Criteria andButForceBackoutLikeInsensitive(String value) {
            addCriterion("upper(BUT_FORCE_BACKOUT) like", value.toUpperCase(), "butForceBackout");
            return (Criteria) this;
        }

        public Criteria andAniTextLikeInsensitive(String value) {
            addCriterion("upper(ANI_TEXT) like", value.toUpperCase(), "aniText");
            return (Criteria) this;
        }

        public Criteria andDnisTextLikeInsensitive(String value) {
            addCriterion("upper(DNIS_TEXT) like", value.toUpperCase(), "dnisText");
            return (Criteria) this;
        }

        public Criteria andTalkTimeTextLikeInsensitive(String value) {
            addCriterion("upper(TALK_TIME_TEXT) like", value.toUpperCase(), "talkTimeText");
            return (Criteria) this;
        }

        public Criteria andCurrentStateTimeTextLikeInsensitive(String value) {
            addCriterion("upper(CURRENT_STATE_TIME_TEXT) like", value.toUpperCase(), "currentStateTimeText");
            return (Criteria) this;
        }

        public Criteria andTalkCountTextLikeInsensitive(String value) {
            addCriterion("upper(TALK_COUNT_TEXT) like", value.toUpperCase(), "talkCountText");
            return (Criteria) this;
        }

        public Criteria andDialFrameLikeInsensitive(String value) {
            addCriterion("upper(DIAL_FRAME) like", value.toUpperCase(), "dialFrame");
            return (Criteria) this;
        }

        public Criteria andVerLikeInsensitive(String value) {
            addCriterion("upper(VER) like", value.toUpperCase(), "ver");
            return (Criteria) this;
        }

        public Criteria andStopFlagLikeInsensitive(String value) {
            addCriterion("upper(STOP_FLAG) like", value.toUpperCase(), "stopFlag");
            return (Criteria) this;
        }

        public Criteria andOutdailNumberLikeInsensitive(String value) {
            addCriterion("upper(OUTDAIL_NUMBER) like", value.toUpperCase(), "outdailNumber");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}