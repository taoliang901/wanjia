package com.wanjia.issue.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.ht.bo.SysDict;
import com.wanjia.ht.dao.SysDictMapper;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueModel;
import com.wanjia.issue.bo.IssueProcess;
import com.wanjia.issue.dao.IssueMapper;
import com.wanjia.issue.dao.IssueProcessMapper;
import com.wanjia.issue.enums.IsConvey;
import com.wanjia.issue.enums.IssueStatus;

/**
 * This element is automatically generated on 16-7-14 下午2:39, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class IssueServiceImpl implements IssueService {
    @Autowired
    private IssueMapper issueMapper;
    
    @Autowired
    private IssueProcessMapper issueProcessMapper;
    
//    @Autowired
//	private DictionaryService dictionaryService;
    
//	@Autowired
//	private AreaService areaService;
	
	@Autowired
	private SysDictMapper sysDictMapper;

    @Override
    @Transactional(readOnly=true)
    public Issue findById(String id) {
        return (Issue)issueMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<Issue> findWithPagination(int offset, int count) {
        return (List<Issue>)issueMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<Issue> findAll() {
        return (List<Issue>)issueMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<Issue> findByEntity(Issue model) {
        return (List<Issue>)issueMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<Issue> findByEntityWithPagination(Issue model, int offset, int count) {
        return (List<Issue>)issueMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public Issue findOneByEntity(Issue model) {
        return (Issue)issueMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<Issue> findByProperty(String propertyName, String propertyValue) {
        return (List<Issue>)issueMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public Issue findOneByProperty(String propertyName, String propertyValue) {
        return (Issue)issueMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<Issue> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<Issue>)issueMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<Issue> findByProperties(Map<String, Object> map) {
        return (List<Issue>)issueMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(Issue model) {
        return (long)issueMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)issueMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)issueMapper.countByProperties(map);
    }

    @Override
    public void update(Issue model) {
      
        model.setModifyDate(new Date());
        issueMapper.update(model);
    }

    @Override
    public void insert(Issue model) {
    	model.setDelFlag(SysConstant.NOT_DEL_FLAG);
        model.setCreateDate(new Date());
        issueMapper.insert(model);
    }

    @Override
    public void deleteByEntity(Issue model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
       // model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        issueMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.issueMapper.countAll();
    }

    public void insertBatch(List<Issue> list) {
        this.issueMapper.insertBatch(list);
    }

    public void delete(String id) {
        Issue model = new Issue();
        model.setDelFlag(SysConstant.DEL_FLAG);
       // model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.issueMapper.update(model);
    }

	@Override
	public Map<String, List<SysDict>> getDicts(String[] dictCodes) {
		Map<String,List<SysDict>> map = new HashMap<String,List<SysDict>>();
		Map<String,Object> queryParam = new HashMap<String,Object>();
		for(String dictCode : dictCodes){
			queryParam.put("dictCode", dictCode);
			//List<Dictionary> list = dictionaryService.findByProperties(queryParam);
			List<SysDict> list = sysDictMapper.findByProperties(queryParam);
			if(list!=null && !list.isEmpty()) map.put(dictCode, list);
		}
		return map;
	}

	@Override
	public List<Issue> queryLastIssue(Map<String, Object> map) {
		return issueMapper.queryLastIssue(map);
	}
	
	@Override
	public List<Issue> searchUnassignedIBList(){
		List<Issue> list =  issueMapper.searchUnassignedIBList();
		if(list == null){
			list = new ArrayList<Issue>();
		}
		return list;
	}
	
	@Override
	public List<Issue> searchUnassignedNormalOBList(){
		List<Issue> list = issueMapper.searchUnassignedNormalOBList();
		if(list == null){
			list = new ArrayList<Issue>();
		}
		return list;
		
	}
	
	@Override
	public List<Issue> searchUnassignedOTOBList(Map<String,Object> map){
		List<Issue> list = issueMapper.searchUnassignedOTOBList(map);
		if(list == null){
			list = new ArrayList<Issue>();
		}
		return list;
	}
	
	
	@Override
	public List<Issue> searchMyIssueList(Map<String,Object> map){
		return issueMapper.searchMyIssueList(map);
	}
	
	

	@Override
	public List<Issue> getIBList(Map<String,Object> map){
		return issueMapper.getIBList(map);
	}
	
	@Override
	public List<Issue> getNormalOBList(Map<String,Object> map){
		return issueMapper.getNormalOBList(map);
	}
	
	@Override
	public List<Issue> getOTOBList(Map<String,Object> map){
		return issueMapper.getOTOBList(map);
	}
	
	
	@Override
	public Area getArea(String id) {
		Area param = new Area();
		param.setAreaId(id);
		/*JsonResponse<List<Area>> jr = areaService.getCityList(null, param);
		if(JsonResponse.Status.SUCCESS.equals(jr.getStatus())){
			List<Area> area = jr.getResult();
			if(area !=null && !area.isEmpty()){
				return area.get(0); 
			}
		}*/
		return null;
	}

	@Override
	public void createIssue(Issue issue) {
		//插工单表
		issueMapper.insert(issue);
		
		//插流转表
		if(IssueStatus.UNSOLVED.getValue().equals(issue.getStatus())
				&& IsConvey.UNTRANSFER.getValue().equals(issue.getIsConvey())){
			//当不解决并不流转的时候不需要记录流转表
		}else{
			IssueProcess issueProcess = new IssueProcess();
			issueProcess.setId(UUID.randomUUID().toString());
			issueProcess.setIssueId(issue.getId());
			if(IssueStatus.SOLVED.getValue().equals(issue.getStatus())){
				issueProcess.setAssignee(issue.getHandler());
				issueProcess.setAssignDate(issue.getCreateDate());
			}
			issueProcess.setDelFlag(SysConstant.NOT_DEL_FLAG);
			issueProcess.setCreateDate(issue.getCreateDate());
			issueProcess.setCreateUser(issue.getCreateUser());
			issueProcess.setRemark(issue.getRemark());
			issueProcess.setStatus(issue.getStatus());
			issueProcessMapper.insert(issueProcess);
		}
	}

	@Override
	public void updateIssue(Issue issue) {
		//更新工单
		issueMapper.update(issue);
		
		//插流转表
		IssueProcess issueProcess = new IssueProcess();
		issueProcess.setId(UUID.randomUUID().toString());
		issueProcess.setIssueId(issue.getId());
		if(IssueStatus.SOLVED.getValue().equals(issue.getStatus())){
			issueProcess.setAssignee(issue.getHandler());
			issueProcess.setAssignDate(issue.getModifyDate());
		}
		issueProcess.setDelFlag(SysConstant.NOT_DEL_FLAG);
		if(issue.getModifyUser()!=null && !"".equals(issue.getModifyUser())){
			issueProcess.setCreateUser(issue.getModifyUser());
		}else{
			issueProcess.setCreateUser(issue.getCreateUser());
		}
		issueProcess.setCreateDate(issue.getModifyDate());
		issueProcess.setRemark(issue.getRemark());
		issueProcess.setStatus(issue.getStatus());
		issueProcessMapper.insert(issueProcess);
		
	}

	@Override
	public void updateCallinIssue(Issue issue) {
		//插工单表
		issueMapper.update(issue);
		
		//插流转表
		if(IssueStatus.UNSOLVED.getValue().equals(issue.getStatus())
				&& IsConvey.UNTRANSFER.getValue().equals(issue.getIsConvey())){
			//当不解决并不流转的时候不需要记录流转表
		}else{
			IssueProcess issueProcess = new IssueProcess();
			issueProcess.setId(UUID.randomUUID().toString());
			issueProcess.setIssueId(issue.getId());
			if(IssueStatus.SOLVED.getValue().equals(issue.getStatus())){
				issueProcess.setAssignee(issue.getHandler());
				issueProcess.setAssignDate(issue.getModifyDate());
			}
			issueProcess.setDelFlag(SysConstant.NOT_DEL_FLAG);
			issueProcess.setCreateDate(issue.getModifyDate());
			issueProcess.setCreateUser(issue.getModifyUser());
			issueProcess.setRemark(issue.getRemark());
			issueProcess.setStatus(issue.getStatus());
			issueProcessMapper.insert(issueProcess);
		}
		
	}

    @Override
    public List<IssueModel> searchAssignedOBList(Map<String, Object> map) {
        return issueMapper.searchAssignedOBList(map);
    }
    
    @Override
	public List<IssueModel> queryAppointmentIssue(Map<String, Object> map) {
		return issueMapper.queryAppointmentIssue(map);
	}

	@Override
	public Integer updateReceiveIssues(String[] ids,String userCode) {
		StringBuffer buff = new StringBuffer();
		for(String id : ids){
			buff.append(",'").append(id).append("'");
		}
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("userCode", userCode);
		map.put("ids", buff.toString().substring(1));
		map.put("modifyUser", userCode);
		map.put("modifyUser", userCode);
		Date date = new Date();
		map.put("modifyDate", date);
		
		//更新主表
		int i = issueMapper.updateReceiveIssue(map);
		
		//记录操作流水
		if(i>0){
			for(String id : ids){
				IssueProcess issueProcess = new IssueProcess();
				issueProcess.setId(UUID.randomUUID().toString());
				issueProcess.setIssueId(id);
				issueProcess.setAssignee(userCode);
				issueProcess.setAssignDate(date);
				issueProcess.setDelFlag(SysConstant.NOT_DEL_FLAG);
				issueProcess.setCreateDate(date);
				issueProcess.setCreateUser(userCode);
				issueProcess.setStatus(IssueStatus.UNSOLVED.getValue());
				issueProcessMapper.insert(issueProcess);
			}
		}
		
		return i;
	}

	@Override
	public Map<String, Object> findKucun(String cardId) {
		
		return issueMapper.findKucun(cardId);
	}
}