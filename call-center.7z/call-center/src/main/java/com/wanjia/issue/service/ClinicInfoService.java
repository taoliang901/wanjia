package com.wanjia.issue.service;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.ClinicInfo;

/**
 * This element is automatically generated on 16-9-19 ����7:37, do not modify. <br>
 * Service interface
 */
public interface ClinicInfoService extends IBaseService<ClinicInfo, String> {
}