package com.wanjia.issue.service;

import com.wanjia.issue.bo.CtiAppletParam;
import com.wanjia.issue.dao.CtiAppletParamMapper;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-7-20 ����10:06, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class CtiAppletParamServiceImpl implements CtiAppletParamService {
    @Autowired
    private CtiAppletParamMapper ctiAppletParamMapper;

    @Override
    @Transactional(readOnly=true)
    public CtiAppletParam findById(Long id) {
        return (CtiAppletParam)ctiAppletParamMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CtiAppletParam> findWithPagination(int offset, int count) {
        return (List<CtiAppletParam>)ctiAppletParamMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CtiAppletParam> findAll() {
        return (List<CtiAppletParam>)ctiAppletParamMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<CtiAppletParam> findByEntity(CtiAppletParam model) {
        return (List<CtiAppletParam>)ctiAppletParamMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CtiAppletParam> findByEntityWithPagination(CtiAppletParam model, int offset, int count) {
        return (List<CtiAppletParam>)ctiAppletParamMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public CtiAppletParam findOneByEntity(CtiAppletParam model) {
        return (CtiAppletParam)ctiAppletParamMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CtiAppletParam> findByProperty(String propertyName, String propertyValue) {
        return (List<CtiAppletParam>)ctiAppletParamMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public CtiAppletParam findOneByProperty(String propertyName, String propertyValue) {
        return (CtiAppletParam)ctiAppletParamMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CtiAppletParam> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<CtiAppletParam>)ctiAppletParamMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CtiAppletParam> findByProperties(Map<String, Object> map) {
        return (List<CtiAppletParam>)ctiAppletParamMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(CtiAppletParam model) {
        return (long)ctiAppletParamMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)ctiAppletParamMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)ctiAppletParamMapper.countByProperties(map);
    }

    @Override
    public void update(CtiAppletParam model) {
        ctiAppletParamMapper.update(model);
    }

    @Override
    public void insert(CtiAppletParam model) {
        ctiAppletParamMapper.insert(model);
    }

    @Override
    public void deleteByEntity(CtiAppletParam model) {
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        ctiAppletParamMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.ctiAppletParamMapper.countAll();
    }

    public void insertBatch(List<CtiAppletParam> list) {
        this.ctiAppletParamMapper.insertBatch(list);
    }

    public void delete(Long id) {
        CtiAppletParam model = new CtiAppletParam();
        model.setId(String.valueOf(id));
        this.ctiAppletParamMapper.update(model);
    }

	@Override
	public List<CtiAppletParam> findByCtiEmployee(Map<String, Object> map) {
		return ctiAppletParamMapper.findByCtiEmployee(map);
	}
	
	@Override
	public List<CtiAppletParam> checkLoginAccount(Map<String, Object> map){
		return ctiAppletParamMapper.checkLoginAccount(map);	
	}
}