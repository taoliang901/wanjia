package com.wanjia.issue.service;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseService;
import com.wanjia.issue.bo.IssueProcess;
import com.wanjia.issue.bo.IssueProcessView;

/**
 * This element is automatically generated on 16-7-14 下午3:00, do not modify. <br>
 * Service interface
 */
public interface IssueProcessService extends IBaseService<IssueProcess, String> {
	
	public IssueProcess searchProcessByIssueID(String issueID);
	
	public void createAsignee(String asignee,String[] issueId,String createUser);
	
	public void createOBAsignee(String asignee,String[] issueId,String createUser);

	public void createOBAsigneeRandom(String surveyId,String obAsignee,String assignOBNum,String currentUser);
	
	List<IssueProcessView> queryIssueOperateLog(Map<String,Object> map);
}