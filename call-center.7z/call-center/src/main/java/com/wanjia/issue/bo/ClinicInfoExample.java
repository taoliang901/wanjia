package com.wanjia.issue.bo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ClinicInfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ClinicInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdIsNull() {
            addCriterion("CLINIC_REGISTER_ID is null");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdIsNotNull() {
            addCriterion("CLINIC_REGISTER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdEqualTo(String value) {
            addCriterion("CLINIC_REGISTER_ID =", value, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdNotEqualTo(String value) {
            addCriterion("CLINIC_REGISTER_ID <>", value, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdGreaterThan(String value) {
            addCriterion("CLINIC_REGISTER_ID >", value, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_REGISTER_ID >=", value, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdLessThan(String value) {
            addCriterion("CLINIC_REGISTER_ID <", value, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_REGISTER_ID <=", value, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdLike(String value) {
            addCriterion("CLINIC_REGISTER_ID like", value, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdNotLike(String value) {
            addCriterion("CLINIC_REGISTER_ID not like", value, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdIn(List<String> values) {
            addCriterion("CLINIC_REGISTER_ID in", values, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdNotIn(List<String> values) {
            addCriterion("CLINIC_REGISTER_ID not in", values, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdBetween(String value1, String value2) {
            addCriterion("CLINIC_REGISTER_ID between", value1, value2, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdNotBetween(String value1, String value2) {
            addCriterion("CLINIC_REGISTER_ID not between", value1, value2, "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicNameIsNull() {
            addCriterion("CLINIC_NAME is null");
            return (Criteria) this;
        }

        public Criteria andClinicNameIsNotNull() {
            addCriterion("CLINIC_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andClinicNameEqualTo(String value) {
            addCriterion("CLINIC_NAME =", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotEqualTo(String value) {
            addCriterion("CLINIC_NAME <>", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameGreaterThan(String value) {
            addCriterion("CLINIC_NAME >", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_NAME >=", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLessThan(String value) {
            addCriterion("CLINIC_NAME <", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_NAME <=", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLike(String value) {
            addCriterion("CLINIC_NAME like", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotLike(String value) {
            addCriterion("CLINIC_NAME not like", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameIn(List<String> values) {
            addCriterion("CLINIC_NAME in", values, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotIn(List<String> values) {
            addCriterion("CLINIC_NAME not in", values, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameBetween(String value1, String value2) {
            addCriterion("CLINIC_NAME between", value1, value2, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotBetween(String value1, String value2) {
            addCriterion("CLINIC_NAME not between", value1, value2, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathIsNull() {
            addCriterion("CLINIC_LOGO_PATH is null");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathIsNotNull() {
            addCriterion("CLINIC_LOGO_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathEqualTo(String value) {
            addCriterion("CLINIC_LOGO_PATH =", value, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathNotEqualTo(String value) {
            addCriterion("CLINIC_LOGO_PATH <>", value, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathGreaterThan(String value) {
            addCriterion("CLINIC_LOGO_PATH >", value, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_LOGO_PATH >=", value, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathLessThan(String value) {
            addCriterion("CLINIC_LOGO_PATH <", value, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_LOGO_PATH <=", value, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathLike(String value) {
            addCriterion("CLINIC_LOGO_PATH like", value, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathNotLike(String value) {
            addCriterion("CLINIC_LOGO_PATH not like", value, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathIn(List<String> values) {
            addCriterion("CLINIC_LOGO_PATH in", values, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathNotIn(List<String> values) {
            addCriterion("CLINIC_LOGO_PATH not in", values, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathBetween(String value1, String value2) {
            addCriterion("CLINIC_LOGO_PATH between", value1, value2, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathNotBetween(String value1, String value2) {
            addCriterion("CLINIC_LOGO_PATH not between", value1, value2, "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andBankIdIsNull() {
            addCriterion("BANK_ID is null");
            return (Criteria) this;
        }

        public Criteria andBankIdIsNotNull() {
            addCriterion("BANK_ID is not null");
            return (Criteria) this;
        }

        public Criteria andBankIdEqualTo(String value) {
            addCriterion("BANK_ID =", value, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdNotEqualTo(String value) {
            addCriterion("BANK_ID <>", value, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdGreaterThan(String value) {
            addCriterion("BANK_ID >", value, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdGreaterThanOrEqualTo(String value) {
            addCriterion("BANK_ID >=", value, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdLessThan(String value) {
            addCriterion("BANK_ID <", value, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdLessThanOrEqualTo(String value) {
            addCriterion("BANK_ID <=", value, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdLike(String value) {
            addCriterion("BANK_ID like", value, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdNotLike(String value) {
            addCriterion("BANK_ID not like", value, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdIn(List<String> values) {
            addCriterion("BANK_ID in", values, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdNotIn(List<String> values) {
            addCriterion("BANK_ID not in", values, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdBetween(String value1, String value2) {
            addCriterion("BANK_ID between", value1, value2, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankIdNotBetween(String value1, String value2) {
            addCriterion("BANK_ID not between", value1, value2, "bankId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdIsNull() {
            addCriterion("BANK_BRANCH_ID is null");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdIsNotNull() {
            addCriterion("BANK_BRANCH_ID is not null");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdEqualTo(String value) {
            addCriterion("BANK_BRANCH_ID =", value, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdNotEqualTo(String value) {
            addCriterion("BANK_BRANCH_ID <>", value, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdGreaterThan(String value) {
            addCriterion("BANK_BRANCH_ID >", value, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdGreaterThanOrEqualTo(String value) {
            addCriterion("BANK_BRANCH_ID >=", value, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdLessThan(String value) {
            addCriterion("BANK_BRANCH_ID <", value, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdLessThanOrEqualTo(String value) {
            addCriterion("BANK_BRANCH_ID <=", value, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdLike(String value) {
            addCriterion("BANK_BRANCH_ID like", value, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdNotLike(String value) {
            addCriterion("BANK_BRANCH_ID not like", value, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdIn(List<String> values) {
            addCriterion("BANK_BRANCH_ID in", values, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdNotIn(List<String> values) {
            addCriterion("BANK_BRANCH_ID not in", values, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdBetween(String value1, String value2) {
            addCriterion("BANK_BRANCH_ID between", value1, value2, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdNotBetween(String value1, String value2) {
            addCriterion("BANK_BRANCH_ID not between", value1, value2, "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andAccountNoIsNull() {
            addCriterion("ACCOUNT_NO is null");
            return (Criteria) this;
        }

        public Criteria andAccountNoIsNotNull() {
            addCriterion("ACCOUNT_NO is not null");
            return (Criteria) this;
        }

        public Criteria andAccountNoEqualTo(String value) {
            addCriterion("ACCOUNT_NO =", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoNotEqualTo(String value) {
            addCriterion("ACCOUNT_NO <>", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoGreaterThan(String value) {
            addCriterion("ACCOUNT_NO >", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("ACCOUNT_NO >=", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoLessThan(String value) {
            addCriterion("ACCOUNT_NO <", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoLessThanOrEqualTo(String value) {
            addCriterion("ACCOUNT_NO <=", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoLike(String value) {
            addCriterion("ACCOUNT_NO like", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoNotLike(String value) {
            addCriterion("ACCOUNT_NO not like", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoIn(List<String> values) {
            addCriterion("ACCOUNT_NO in", values, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoNotIn(List<String> values) {
            addCriterion("ACCOUNT_NO not in", values, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoBetween(String value1, String value2) {
            addCriterion("ACCOUNT_NO between", value1, value2, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoNotBetween(String value1, String value2) {
            addCriterion("ACCOUNT_NO not between", value1, value2, "accountNo");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceIsNull() {
            addCriterion("IS_MEDICAL_INSURANCE is null");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceIsNotNull() {
            addCriterion("IS_MEDICAL_INSURANCE is not null");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceEqualTo(String value) {
            addCriterion("IS_MEDICAL_INSURANCE =", value, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceNotEqualTo(String value) {
            addCriterion("IS_MEDICAL_INSURANCE <>", value, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceGreaterThan(String value) {
            addCriterion("IS_MEDICAL_INSURANCE >", value, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceGreaterThanOrEqualTo(String value) {
            addCriterion("IS_MEDICAL_INSURANCE >=", value, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceLessThan(String value) {
            addCriterion("IS_MEDICAL_INSURANCE <", value, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceLessThanOrEqualTo(String value) {
            addCriterion("IS_MEDICAL_INSURANCE <=", value, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceLike(String value) {
            addCriterion("IS_MEDICAL_INSURANCE like", value, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceNotLike(String value) {
            addCriterion("IS_MEDICAL_INSURANCE not like", value, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceIn(List<String> values) {
            addCriterion("IS_MEDICAL_INSURANCE in", values, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceNotIn(List<String> values) {
            addCriterion("IS_MEDICAL_INSURANCE not in", values, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceBetween(String value1, String value2) {
            addCriterion("IS_MEDICAL_INSURANCE between", value1, value2, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceNotBetween(String value1, String value2) {
            addCriterion("IS_MEDICAL_INSURANCE not between", value1, value2, "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andMobileIsNull() {
            addCriterion("MOBILE is null");
            return (Criteria) this;
        }

        public Criteria andMobileIsNotNull() {
            addCriterion("MOBILE is not null");
            return (Criteria) this;
        }

        public Criteria andMobileEqualTo(String value) {
            addCriterion("MOBILE =", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileNotEqualTo(String value) {
            addCriterion("MOBILE <>", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileGreaterThan(String value) {
            addCriterion("MOBILE >", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileGreaterThanOrEqualTo(String value) {
            addCriterion("MOBILE >=", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileLessThan(String value) {
            addCriterion("MOBILE <", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileLessThanOrEqualTo(String value) {
            addCriterion("MOBILE <=", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileLike(String value) {
            addCriterion("MOBILE like", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileNotLike(String value) {
            addCriterion("MOBILE not like", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileIn(List<String> values) {
            addCriterion("MOBILE in", values, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileNotIn(List<String> values) {
            addCriterion("MOBILE not in", values, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileBetween(String value1, String value2) {
            addCriterion("MOBILE between", value1, value2, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileNotBetween(String value1, String value2) {
            addCriterion("MOBILE not between", value1, value2, "mobile");
            return (Criteria) this;
        }

        public Criteria andPhoneIsNull() {
            addCriterion("PHONE is null");
            return (Criteria) this;
        }

        public Criteria andPhoneIsNotNull() {
            addCriterion("PHONE is not null");
            return (Criteria) this;
        }

        public Criteria andPhoneEqualTo(String value) {
            addCriterion("PHONE =", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotEqualTo(String value) {
            addCriterion("PHONE <>", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneGreaterThan(String value) {
            addCriterion("PHONE >", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("PHONE >=", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLessThan(String value) {
            addCriterion("PHONE <", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLessThanOrEqualTo(String value) {
            addCriterion("PHONE <=", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLike(String value) {
            addCriterion("PHONE like", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotLike(String value) {
            addCriterion("PHONE not like", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneIn(List<String> values) {
            addCriterion("PHONE in", values, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotIn(List<String> values) {
            addCriterion("PHONE not in", values, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneBetween(String value1, String value2) {
            addCriterion("PHONE between", value1, value2, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotBetween(String value1, String value2) {
            addCriterion("PHONE not between", value1, value2, "phone");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeIsNull() {
            addCriterion("OPENING_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeIsNotNull() {
            addCriterion("OPENING_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEqualTo(String value) {
            addCriterion("OPENING_TIME =", value, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeNotEqualTo(String value) {
            addCriterion("OPENING_TIME <>", value, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeGreaterThan(String value) {
            addCriterion("OPENING_TIME >", value, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeGreaterThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME >=", value, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeLessThan(String value) {
            addCriterion("OPENING_TIME <", value, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeLessThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME <=", value, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeLike(String value) {
            addCriterion("OPENING_TIME like", value, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeNotLike(String value) {
            addCriterion("OPENING_TIME not like", value, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeIn(List<String> values) {
            addCriterion("OPENING_TIME in", values, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeNotIn(List<String> values) {
            addCriterion("OPENING_TIME not in", values, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBetween(String value1, String value2) {
            addCriterion("OPENING_TIME between", value1, value2, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeNotBetween(String value1, String value2) {
            addCriterion("OPENING_TIME not between", value1, value2, "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginIsNull() {
            addCriterion("OPENING_TIME_BEGIN is null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginIsNotNull() {
            addCriterion("OPENING_TIME_BEGIN is not null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginEqualTo(String value) {
            addCriterion("OPENING_TIME_BEGIN =", value, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginNotEqualTo(String value) {
            addCriterion("OPENING_TIME_BEGIN <>", value, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginGreaterThan(String value) {
            addCriterion("OPENING_TIME_BEGIN >", value, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginGreaterThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME_BEGIN >=", value, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginLessThan(String value) {
            addCriterion("OPENING_TIME_BEGIN <", value, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginLessThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME_BEGIN <=", value, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginLike(String value) {
            addCriterion("OPENING_TIME_BEGIN like", value, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginNotLike(String value) {
            addCriterion("OPENING_TIME_BEGIN not like", value, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginIn(List<String> values) {
            addCriterion("OPENING_TIME_BEGIN in", values, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginNotIn(List<String> values) {
            addCriterion("OPENING_TIME_BEGIN not in", values, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginBetween(String value1, String value2) {
            addCriterion("OPENING_TIME_BEGIN between", value1, value2, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginNotBetween(String value1, String value2) {
            addCriterion("OPENING_TIME_BEGIN not between", value1, value2, "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndIsNull() {
            addCriterion("OPENING_TIME_END is null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndIsNotNull() {
            addCriterion("OPENING_TIME_END is not null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndEqualTo(String value) {
            addCriterion("OPENING_TIME_END =", value, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndNotEqualTo(String value) {
            addCriterion("OPENING_TIME_END <>", value, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndGreaterThan(String value) {
            addCriterion("OPENING_TIME_END >", value, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndGreaterThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME_END >=", value, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndLessThan(String value) {
            addCriterion("OPENING_TIME_END <", value, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndLessThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME_END <=", value, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndLike(String value) {
            addCriterion("OPENING_TIME_END like", value, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndNotLike(String value) {
            addCriterion("OPENING_TIME_END not like", value, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndIn(List<String> values) {
            addCriterion("OPENING_TIME_END in", values, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndNotIn(List<String> values) {
            addCriterion("OPENING_TIME_END not in", values, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndBetween(String value1, String value2) {
            addCriterion("OPENING_TIME_END between", value1, value2, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndNotBetween(String value1, String value2) {
            addCriterion("OPENING_TIME_END not between", value1, value2, "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeIsNull() {
            addCriterion("OPENING_TIME_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeIsNotNull() {
            addCriterion("OPENING_TIME_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeEqualTo(String value) {
            addCriterion("OPENING_TIME_TYPE =", value, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeNotEqualTo(String value) {
            addCriterion("OPENING_TIME_TYPE <>", value, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeGreaterThan(String value) {
            addCriterion("OPENING_TIME_TYPE >", value, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeGreaterThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME_TYPE >=", value, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeLessThan(String value) {
            addCriterion("OPENING_TIME_TYPE <", value, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeLessThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME_TYPE <=", value, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeLike(String value) {
            addCriterion("OPENING_TIME_TYPE like", value, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeNotLike(String value) {
            addCriterion("OPENING_TIME_TYPE not like", value, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeIn(List<String> values) {
            addCriterion("OPENING_TIME_TYPE in", values, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeNotIn(List<String> values) {
            addCriterion("OPENING_TIME_TYPE not in", values, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeBetween(String value1, String value2) {
            addCriterion("OPENING_TIME_TYPE between", value1, value2, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeNotBetween(String value1, String value2) {
            addCriterion("OPENING_TIME_TYPE not between", value1, value2, "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherIsNull() {
            addCriterion("OPENING_TIME_OTHER is null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherIsNotNull() {
            addCriterion("OPENING_TIME_OTHER is not null");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherEqualTo(String value) {
            addCriterion("OPENING_TIME_OTHER =", value, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherNotEqualTo(String value) {
            addCriterion("OPENING_TIME_OTHER <>", value, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherGreaterThan(String value) {
            addCriterion("OPENING_TIME_OTHER >", value, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherGreaterThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME_OTHER >=", value, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherLessThan(String value) {
            addCriterion("OPENING_TIME_OTHER <", value, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherLessThanOrEqualTo(String value) {
            addCriterion("OPENING_TIME_OTHER <=", value, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherLike(String value) {
            addCriterion("OPENING_TIME_OTHER like", value, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherNotLike(String value) {
            addCriterion("OPENING_TIME_OTHER not like", value, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherIn(List<String> values) {
            addCriterion("OPENING_TIME_OTHER in", values, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherNotIn(List<String> values) {
            addCriterion("OPENING_TIME_OTHER not in", values, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherBetween(String value1, String value2) {
            addCriterion("OPENING_TIME_OTHER between", value1, value2, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherNotBetween(String value1, String value2) {
            addCriterion("OPENING_TIME_OTHER not between", value1, value2, "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyIsNull() {
            addCriterion("CLINIC_TYPE_PROPERTY is null");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyIsNotNull() {
            addCriterion("CLINIC_TYPE_PROPERTY is not null");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyEqualTo(String value) {
            addCriterion("CLINIC_TYPE_PROPERTY =", value, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyNotEqualTo(String value) {
            addCriterion("CLINIC_TYPE_PROPERTY <>", value, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyGreaterThan(String value) {
            addCriterion("CLINIC_TYPE_PROPERTY >", value, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_TYPE_PROPERTY >=", value, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyLessThan(String value) {
            addCriterion("CLINIC_TYPE_PROPERTY <", value, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_TYPE_PROPERTY <=", value, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyLike(String value) {
            addCriterion("CLINIC_TYPE_PROPERTY like", value, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyNotLike(String value) {
            addCriterion("CLINIC_TYPE_PROPERTY not like", value, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyIn(List<String> values) {
            addCriterion("CLINIC_TYPE_PROPERTY in", values, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyNotIn(List<String> values) {
            addCriterion("CLINIC_TYPE_PROPERTY not in", values, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyBetween(String value1, String value2) {
            addCriterion("CLINIC_TYPE_PROPERTY between", value1, value2, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyNotBetween(String value1, String value2) {
            addCriterion("CLINIC_TYPE_PROPERTY not between", value1, value2, "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsIsNull() {
            addCriterion("CLINIC_TYPE_DEPARTMENTS is null");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsIsNotNull() {
            addCriterion("CLINIC_TYPE_DEPARTMENTS is not null");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsEqualTo(String value) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS =", value, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsNotEqualTo(String value) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS <>", value, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsGreaterThan(String value) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS >", value, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS >=", value, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsLessThan(String value) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS <", value, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS <=", value, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsLike(String value) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS like", value, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsNotLike(String value) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS not like", value, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsIn(List<String> values) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS in", values, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsNotIn(List<String> values) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS not in", values, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsBetween(String value1, String value2) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS between", value1, value2, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsNotBetween(String value1, String value2) {
            addCriterion("CLINIC_TYPE_DEPARTMENTS not between", value1, value2, "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1IsNull() {
            addCriterion("DIAGNOSIS_TYPE_CODE1 is null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1IsNotNull() {
            addCriterion("DIAGNOSIS_TYPE_CODE1 is not null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1EqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 =", value, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1NotEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 <>", value, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1GreaterThan(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 >", value, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1GreaterThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 >=", value, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1LessThan(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 <", value, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1LessThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 <=", value, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1Like(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 like", value, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1NotLike(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 not like", value, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1In(List<String> values) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 in", values, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1NotIn(List<String> values) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 not in", values, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1Between(String value1, String value2) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 between", value1, value2, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1NotBetween(String value1, String value2) {
            addCriterion("DIAGNOSIS_TYPE_CODE1 not between", value1, value2, "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1IsNull() {
            addCriterion("DIAGNOSIS_TYPE_1 is null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1IsNotNull() {
            addCriterion("DIAGNOSIS_TYPE_1 is not null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1EqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_1 =", value, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1NotEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_1 <>", value, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1GreaterThan(String value) {
            addCriterion("DIAGNOSIS_TYPE_1 >", value, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1GreaterThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_1 >=", value, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1LessThan(String value) {
            addCriterion("DIAGNOSIS_TYPE_1 <", value, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1LessThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_1 <=", value, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1Like(String value) {
            addCriterion("DIAGNOSIS_TYPE_1 like", value, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1NotLike(String value) {
            addCriterion("DIAGNOSIS_TYPE_1 not like", value, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1In(List<String> values) {
            addCriterion("DIAGNOSIS_TYPE_1 in", values, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1NotIn(List<String> values) {
            addCriterion("DIAGNOSIS_TYPE_1 not in", values, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1Between(String value1, String value2) {
            addCriterion("DIAGNOSIS_TYPE_1 between", value1, value2, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1NotBetween(String value1, String value2) {
            addCriterion("DIAGNOSIS_TYPE_1 not between", value1, value2, "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2IsNull() {
            addCriterion("DIAGNOSIS_TYPE_CODE2 is null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2IsNotNull() {
            addCriterion("DIAGNOSIS_TYPE_CODE2 is not null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2EqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 =", value, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2NotEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 <>", value, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2GreaterThan(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 >", value, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2GreaterThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 >=", value, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2LessThan(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 <", value, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2LessThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 <=", value, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2Like(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 like", value, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2NotLike(String value) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 not like", value, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2In(List<String> values) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 in", values, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2NotIn(List<String> values) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 not in", values, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2Between(String value1, String value2) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 between", value1, value2, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2NotBetween(String value1, String value2) {
            addCriterion("DIAGNOSIS_TYPE_CODE2 not between", value1, value2, "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2IsNull() {
            addCriterion("DIAGNOSIS_TYPE_2 is null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2IsNotNull() {
            addCriterion("DIAGNOSIS_TYPE_2 is not null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2EqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_2 =", value, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2NotEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_2 <>", value, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2GreaterThan(String value) {
            addCriterion("DIAGNOSIS_TYPE_2 >", value, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2GreaterThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_2 >=", value, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2LessThan(String value) {
            addCriterion("DIAGNOSIS_TYPE_2 <", value, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2LessThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_TYPE_2 <=", value, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2Like(String value) {
            addCriterion("DIAGNOSIS_TYPE_2 like", value, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2NotLike(String value) {
            addCriterion("DIAGNOSIS_TYPE_2 not like", value, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2In(List<String> values) {
            addCriterion("DIAGNOSIS_TYPE_2 in", values, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2NotIn(List<String> values) {
            addCriterion("DIAGNOSIS_TYPE_2 not in", values, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2Between(String value1, String value2) {
            addCriterion("DIAGNOSIS_TYPE_2 between", value1, value2, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2NotBetween(String value1, String value2) {
            addCriterion("DIAGNOSIS_TYPE_2 not between", value1, value2, "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemIsNull() {
            addCriterion("DIAGNOSIS_ITEM is null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemIsNotNull() {
            addCriterion("DIAGNOSIS_ITEM is not null");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemEqualTo(String value) {
            addCriterion("DIAGNOSIS_ITEM =", value, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemNotEqualTo(String value) {
            addCriterion("DIAGNOSIS_ITEM <>", value, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemGreaterThan(String value) {
            addCriterion("DIAGNOSIS_ITEM >", value, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemGreaterThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_ITEM >=", value, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemLessThan(String value) {
            addCriterion("DIAGNOSIS_ITEM <", value, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemLessThanOrEqualTo(String value) {
            addCriterion("DIAGNOSIS_ITEM <=", value, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemLike(String value) {
            addCriterion("DIAGNOSIS_ITEM like", value, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemNotLike(String value) {
            addCriterion("DIAGNOSIS_ITEM not like", value, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemIn(List<String> values) {
            addCriterion("DIAGNOSIS_ITEM in", values, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemNotIn(List<String> values) {
            addCriterion("DIAGNOSIS_ITEM not in", values, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemBetween(String value1, String value2) {
            addCriterion("DIAGNOSIS_ITEM between", value1, value2, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemNotBetween(String value1, String value2) {
            addCriterion("DIAGNOSIS_ITEM not between", value1, value2, "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceIsNull() {
            addCriterion("CLINIC_INTRODUCE is null");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceIsNotNull() {
            addCriterion("CLINIC_INTRODUCE is not null");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceEqualTo(String value) {
            addCriterion("CLINIC_INTRODUCE =", value, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceNotEqualTo(String value) {
            addCriterion("CLINIC_INTRODUCE <>", value, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceGreaterThan(String value) {
            addCriterion("CLINIC_INTRODUCE >", value, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_INTRODUCE >=", value, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceLessThan(String value) {
            addCriterion("CLINIC_INTRODUCE <", value, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_INTRODUCE <=", value, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceLike(String value) {
            addCriterion("CLINIC_INTRODUCE like", value, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceNotLike(String value) {
            addCriterion("CLINIC_INTRODUCE not like", value, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceIn(List<String> values) {
            addCriterion("CLINIC_INTRODUCE in", values, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceNotIn(List<String> values) {
            addCriterion("CLINIC_INTRODUCE not in", values, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceBetween(String value1, String value2) {
            addCriterion("CLINIC_INTRODUCE between", value1, value2, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceNotBetween(String value1, String value2) {
            addCriterion("CLINIC_INTRODUCE not between", value1, value2, "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoIsNull() {
            addCriterion("BUSINESS_LICENSE_NO is null");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoIsNotNull() {
            addCriterion("BUSINESS_LICENSE_NO is not null");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoEqualTo(String value) {
            addCriterion("BUSINESS_LICENSE_NO =", value, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoNotEqualTo(String value) {
            addCriterion("BUSINESS_LICENSE_NO <>", value, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoGreaterThan(String value) {
            addCriterion("BUSINESS_LICENSE_NO >", value, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoGreaterThanOrEqualTo(String value) {
            addCriterion("BUSINESS_LICENSE_NO >=", value, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoLessThan(String value) {
            addCriterion("BUSINESS_LICENSE_NO <", value, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoLessThanOrEqualTo(String value) {
            addCriterion("BUSINESS_LICENSE_NO <=", value, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoLike(String value) {
            addCriterion("BUSINESS_LICENSE_NO like", value, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoNotLike(String value) {
            addCriterion("BUSINESS_LICENSE_NO not like", value, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoIn(List<String> values) {
            addCriterion("BUSINESS_LICENSE_NO in", values, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoNotIn(List<String> values) {
            addCriterion("BUSINESS_LICENSE_NO not in", values, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoBetween(String value1, String value2) {
            addCriterion("BUSINESS_LICENSE_NO between", value1, value2, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoNotBetween(String value1, String value2) {
            addCriterion("BUSINESS_LICENSE_NO not between", value1, value2, "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathIsNull() {
            addCriterion("BUSINESS_LICENSE_PATH is null");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathIsNotNull() {
            addCriterion("BUSINESS_LICENSE_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathEqualTo(String value) {
            addCriterion("BUSINESS_LICENSE_PATH =", value, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathNotEqualTo(String value) {
            addCriterion("BUSINESS_LICENSE_PATH <>", value, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathGreaterThan(String value) {
            addCriterion("BUSINESS_LICENSE_PATH >", value, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathGreaterThanOrEqualTo(String value) {
            addCriterion("BUSINESS_LICENSE_PATH >=", value, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathLessThan(String value) {
            addCriterion("BUSINESS_LICENSE_PATH <", value, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathLessThanOrEqualTo(String value) {
            addCriterion("BUSINESS_LICENSE_PATH <=", value, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathLike(String value) {
            addCriterion("BUSINESS_LICENSE_PATH like", value, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathNotLike(String value) {
            addCriterion("BUSINESS_LICENSE_PATH not like", value, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathIn(List<String> values) {
            addCriterion("BUSINESS_LICENSE_PATH in", values, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathNotIn(List<String> values) {
            addCriterion("BUSINESS_LICENSE_PATH not in", values, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathBetween(String value1, String value2) {
            addCriterion("BUSINESS_LICENSE_PATH between", value1, value2, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathNotBetween(String value1, String value2) {
            addCriterion("BUSINESS_LICENSE_PATH not between", value1, value2, "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoIsNull() {
            addCriterion("PRACTICING_LICENSE_NO is null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoIsNotNull() {
            addCriterion("PRACTICING_LICENSE_NO is not null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_NO =", value, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoNotEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_NO <>", value, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoGreaterThan(String value) {
            addCriterion("PRACTICING_LICENSE_NO >", value, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoGreaterThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_NO >=", value, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoLessThan(String value) {
            addCriterion("PRACTICING_LICENSE_NO <", value, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoLessThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_NO <=", value, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoLike(String value) {
            addCriterion("PRACTICING_LICENSE_NO like", value, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoNotLike(String value) {
            addCriterion("PRACTICING_LICENSE_NO not like", value, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_NO in", values, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoNotIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_NO not in", values, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_NO between", value1, value2, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoNotBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_NO not between", value1, value2, "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathIsNull() {
            addCriterion("PRACTICING_LICENSE_PATH is null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathIsNotNull() {
            addCriterion("PRACTICING_LICENSE_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_PATH =", value, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathNotEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_PATH <>", value, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathGreaterThan(String value) {
            addCriterion("PRACTICING_LICENSE_PATH >", value, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathGreaterThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_PATH >=", value, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathLessThan(String value) {
            addCriterion("PRACTICING_LICENSE_PATH <", value, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathLessThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_PATH <=", value, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathLike(String value) {
            addCriterion("PRACTICING_LICENSE_PATH like", value, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathNotLike(String value) {
            addCriterion("PRACTICING_LICENSE_PATH not like", value, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_PATH in", values, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathNotIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_PATH not in", values, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_PATH between", value1, value2, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathNotBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_PATH not between", value1, value2, "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathIsNull() {
            addCriterion("PRACTICING_LICENSE_F_PATH is null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathIsNotNull() {
            addCriterion("PRACTICING_LICENSE_F_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F_PATH =", value, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathNotEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F_PATH <>", value, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathGreaterThan(String value) {
            addCriterion("PRACTICING_LICENSE_F_PATH >", value, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathGreaterThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F_PATH >=", value, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathLessThan(String value) {
            addCriterion("PRACTICING_LICENSE_F_PATH <", value, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathLessThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F_PATH <=", value, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathLike(String value) {
            addCriterion("PRACTICING_LICENSE_F_PATH like", value, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathNotLike(String value) {
            addCriterion("PRACTICING_LICENSE_F_PATH not like", value, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_F_PATH in", values, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathNotIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_F_PATH not in", values, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_F_PATH between", value1, value2, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathNotBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_F_PATH not between", value1, value2, "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathIsNull() {
            addCriterion("PRACTICING_LICENSE_F2_PATH is null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathIsNotNull() {
            addCriterion("PRACTICING_LICENSE_F2_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F2_PATH =", value, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathNotEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F2_PATH <>", value, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathGreaterThan(String value) {
            addCriterion("PRACTICING_LICENSE_F2_PATH >", value, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathGreaterThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F2_PATH >=", value, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathLessThan(String value) {
            addCriterion("PRACTICING_LICENSE_F2_PATH <", value, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathLessThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F2_PATH <=", value, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathLike(String value) {
            addCriterion("PRACTICING_LICENSE_F2_PATH like", value, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathNotLike(String value) {
            addCriterion("PRACTICING_LICENSE_F2_PATH not like", value, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_F2_PATH in", values, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathNotIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_F2_PATH not in", values, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_F2_PATH between", value1, value2, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathNotBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_F2_PATH not between", value1, value2, "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathIsNull() {
            addCriterion("PRACTICING_LICENSE_F3_PATH is null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathIsNotNull() {
            addCriterion("PRACTICING_LICENSE_F3_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F3_PATH =", value, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathNotEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F3_PATH <>", value, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathGreaterThan(String value) {
            addCriterion("PRACTICING_LICENSE_F3_PATH >", value, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathGreaterThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F3_PATH >=", value, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathLessThan(String value) {
            addCriterion("PRACTICING_LICENSE_F3_PATH <", value, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathLessThanOrEqualTo(String value) {
            addCriterion("PRACTICING_LICENSE_F3_PATH <=", value, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathLike(String value) {
            addCriterion("PRACTICING_LICENSE_F3_PATH like", value, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathNotLike(String value) {
            addCriterion("PRACTICING_LICENSE_F3_PATH not like", value, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_F3_PATH in", values, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathNotIn(List<String> values) {
            addCriterion("PRACTICING_LICENSE_F3_PATH not in", values, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_F3_PATH between", value1, value2, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathNotBetween(String value1, String value2) {
            addCriterion("PRACTICING_LICENSE_F3_PATH not between", value1, value2, "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoIsNull() {
            addCriterion("ORGANIZATION_NO is null");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoIsNotNull() {
            addCriterion("ORGANIZATION_NO is not null");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoEqualTo(String value) {
            addCriterion("ORGANIZATION_NO =", value, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoNotEqualTo(String value) {
            addCriterion("ORGANIZATION_NO <>", value, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoGreaterThan(String value) {
            addCriterion("ORGANIZATION_NO >", value, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoGreaterThanOrEqualTo(String value) {
            addCriterion("ORGANIZATION_NO >=", value, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoLessThan(String value) {
            addCriterion("ORGANIZATION_NO <", value, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoLessThanOrEqualTo(String value) {
            addCriterion("ORGANIZATION_NO <=", value, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoLike(String value) {
            addCriterion("ORGANIZATION_NO like", value, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoNotLike(String value) {
            addCriterion("ORGANIZATION_NO not like", value, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoIn(List<String> values) {
            addCriterion("ORGANIZATION_NO in", values, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoNotIn(List<String> values) {
            addCriterion("ORGANIZATION_NO not in", values, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoBetween(String value1, String value2) {
            addCriterion("ORGANIZATION_NO between", value1, value2, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoNotBetween(String value1, String value2) {
            addCriterion("ORGANIZATION_NO not between", value1, value2, "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathIsNull() {
            addCriterion("ORGANIZATION_PATH is null");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathIsNotNull() {
            addCriterion("ORGANIZATION_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathEqualTo(String value) {
            addCriterion("ORGANIZATION_PATH =", value, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathNotEqualTo(String value) {
            addCriterion("ORGANIZATION_PATH <>", value, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathGreaterThan(String value) {
            addCriterion("ORGANIZATION_PATH >", value, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathGreaterThanOrEqualTo(String value) {
            addCriterion("ORGANIZATION_PATH >=", value, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathLessThan(String value) {
            addCriterion("ORGANIZATION_PATH <", value, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathLessThanOrEqualTo(String value) {
            addCriterion("ORGANIZATION_PATH <=", value, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathLike(String value) {
            addCriterion("ORGANIZATION_PATH like", value, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathNotLike(String value) {
            addCriterion("ORGANIZATION_PATH not like", value, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathIn(List<String> values) {
            addCriterion("ORGANIZATION_PATH in", values, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathNotIn(List<String> values) {
            addCriterion("ORGANIZATION_PATH not in", values, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathBetween(String value1, String value2) {
            addCriterion("ORGANIZATION_PATH between", value1, value2, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathNotBetween(String value1, String value2) {
            addCriterion("ORGANIZATION_PATH not between", value1, value2, "organizationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoIsNull() {
            addCriterion("TAX_REGISTRATION_NO is null");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoIsNotNull() {
            addCriterion("TAX_REGISTRATION_NO is not null");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoEqualTo(String value) {
            addCriterion("TAX_REGISTRATION_NO =", value, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoNotEqualTo(String value) {
            addCriterion("TAX_REGISTRATION_NO <>", value, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoGreaterThan(String value) {
            addCriterion("TAX_REGISTRATION_NO >", value, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoGreaterThanOrEqualTo(String value) {
            addCriterion("TAX_REGISTRATION_NO >=", value, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoLessThan(String value) {
            addCriterion("TAX_REGISTRATION_NO <", value, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoLessThanOrEqualTo(String value) {
            addCriterion("TAX_REGISTRATION_NO <=", value, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoLike(String value) {
            addCriterion("TAX_REGISTRATION_NO like", value, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoNotLike(String value) {
            addCriterion("TAX_REGISTRATION_NO not like", value, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoIn(List<String> values) {
            addCriterion("TAX_REGISTRATION_NO in", values, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoNotIn(List<String> values) {
            addCriterion("TAX_REGISTRATION_NO not in", values, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoBetween(String value1, String value2) {
            addCriterion("TAX_REGISTRATION_NO between", value1, value2, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoNotBetween(String value1, String value2) {
            addCriterion("TAX_REGISTRATION_NO not between", value1, value2, "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathIsNull() {
            addCriterion("TAX_REGISTRATION_PATH is null");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathIsNotNull() {
            addCriterion("TAX_REGISTRATION_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathEqualTo(String value) {
            addCriterion("TAX_REGISTRATION_PATH =", value, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathNotEqualTo(String value) {
            addCriterion("TAX_REGISTRATION_PATH <>", value, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathGreaterThan(String value) {
            addCriterion("TAX_REGISTRATION_PATH >", value, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathGreaterThanOrEqualTo(String value) {
            addCriterion("TAX_REGISTRATION_PATH >=", value, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathLessThan(String value) {
            addCriterion("TAX_REGISTRATION_PATH <", value, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathLessThanOrEqualTo(String value) {
            addCriterion("TAX_REGISTRATION_PATH <=", value, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathLike(String value) {
            addCriterion("TAX_REGISTRATION_PATH like", value, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathNotLike(String value) {
            addCriterion("TAX_REGISTRATION_PATH not like", value, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathIn(List<String> values) {
            addCriterion("TAX_REGISTRATION_PATH in", values, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathNotIn(List<String> values) {
            addCriterion("TAX_REGISTRATION_PATH not in", values, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathBetween(String value1, String value2) {
            addCriterion("TAX_REGISTRATION_PATH between", value1, value2, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathNotBetween(String value1, String value2) {
            addCriterion("TAX_REGISTRATION_PATH not between", value1, value2, "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingIsNull() {
            addCriterion("CIVIL_AFFAIRS_FILING is null");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingIsNotNull() {
            addCriterion("CIVIL_AFFAIRS_FILING is not null");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingEqualTo(String value) {
            addCriterion("CIVIL_AFFAIRS_FILING =", value, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingNotEqualTo(String value) {
            addCriterion("CIVIL_AFFAIRS_FILING <>", value, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingGreaterThan(String value) {
            addCriterion("CIVIL_AFFAIRS_FILING >", value, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingGreaterThanOrEqualTo(String value) {
            addCriterion("CIVIL_AFFAIRS_FILING >=", value, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingLessThan(String value) {
            addCriterion("CIVIL_AFFAIRS_FILING <", value, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingLessThanOrEqualTo(String value) {
            addCriterion("CIVIL_AFFAIRS_FILING <=", value, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingLike(String value) {
            addCriterion("CIVIL_AFFAIRS_FILING like", value, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingNotLike(String value) {
            addCriterion("CIVIL_AFFAIRS_FILING not like", value, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingIn(List<String> values) {
            addCriterion("CIVIL_AFFAIRS_FILING in", values, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingNotIn(List<String> values) {
            addCriterion("CIVIL_AFFAIRS_FILING not in", values, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingBetween(String value1, String value2) {
            addCriterion("CIVIL_AFFAIRS_FILING between", value1, value2, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingNotBetween(String value1, String value2) {
            addCriterion("CIVIL_AFFAIRS_FILING not between", value1, value2, "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathIsNull() {
            addCriterion("CIVIL_AFFAIRS_PATH is null");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathIsNotNull() {
            addCriterion("CIVIL_AFFAIRS_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathEqualTo(String value) {
            addCriterion("CIVIL_AFFAIRS_PATH =", value, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathNotEqualTo(String value) {
            addCriterion("CIVIL_AFFAIRS_PATH <>", value, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathGreaterThan(String value) {
            addCriterion("CIVIL_AFFAIRS_PATH >", value, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathGreaterThanOrEqualTo(String value) {
            addCriterion("CIVIL_AFFAIRS_PATH >=", value, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathLessThan(String value) {
            addCriterion("CIVIL_AFFAIRS_PATH <", value, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathLessThanOrEqualTo(String value) {
            addCriterion("CIVIL_AFFAIRS_PATH <=", value, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathLike(String value) {
            addCriterion("CIVIL_AFFAIRS_PATH like", value, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathNotLike(String value) {
            addCriterion("CIVIL_AFFAIRS_PATH not like", value, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathIn(List<String> values) {
            addCriterion("CIVIL_AFFAIRS_PATH in", values, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathNotIn(List<String> values) {
            addCriterion("CIVIL_AFFAIRS_PATH not in", values, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathBetween(String value1, String value2) {
            addCriterion("CIVIL_AFFAIRS_PATH between", value1, value2, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathNotBetween(String value1, String value2) {
            addCriterion("CIVIL_AFFAIRS_PATH not between", value1, value2, "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoIsNull() {
            addCriterion("RADIATION_DIAGNOSIS_NO is null");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoIsNotNull() {
            addCriterion("RADIATION_DIAGNOSIS_NO is not null");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoEqualTo(String value) {
            addCriterion("RADIATION_DIAGNOSIS_NO =", value, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoNotEqualTo(String value) {
            addCriterion("RADIATION_DIAGNOSIS_NO <>", value, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoGreaterThan(String value) {
            addCriterion("RADIATION_DIAGNOSIS_NO >", value, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoGreaterThanOrEqualTo(String value) {
            addCriterion("RADIATION_DIAGNOSIS_NO >=", value, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoLessThan(String value) {
            addCriterion("RADIATION_DIAGNOSIS_NO <", value, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoLessThanOrEqualTo(String value) {
            addCriterion("RADIATION_DIAGNOSIS_NO <=", value, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoLike(String value) {
            addCriterion("RADIATION_DIAGNOSIS_NO like", value, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoNotLike(String value) {
            addCriterion("RADIATION_DIAGNOSIS_NO not like", value, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoIn(List<String> values) {
            addCriterion("RADIATION_DIAGNOSIS_NO in", values, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoNotIn(List<String> values) {
            addCriterion("RADIATION_DIAGNOSIS_NO not in", values, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoBetween(String value1, String value2) {
            addCriterion("RADIATION_DIAGNOSIS_NO between", value1, value2, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoNotBetween(String value1, String value2) {
            addCriterion("RADIATION_DIAGNOSIS_NO not between", value1, value2, "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathIsNull() {
            addCriterion("RADIATION_DIAGNOSIS_PATH is null");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathIsNotNull() {
            addCriterion("RADIATION_DIAGNOSIS_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathEqualTo(String value) {
            addCriterion("RADIATION_DIAGNOSIS_PATH =", value, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathNotEqualTo(String value) {
            addCriterion("RADIATION_DIAGNOSIS_PATH <>", value, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathGreaterThan(String value) {
            addCriterion("RADIATION_DIAGNOSIS_PATH >", value, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathGreaterThanOrEqualTo(String value) {
            addCriterion("RADIATION_DIAGNOSIS_PATH >=", value, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathLessThan(String value) {
            addCriterion("RADIATION_DIAGNOSIS_PATH <", value, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathLessThanOrEqualTo(String value) {
            addCriterion("RADIATION_DIAGNOSIS_PATH <=", value, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathLike(String value) {
            addCriterion("RADIATION_DIAGNOSIS_PATH like", value, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathNotLike(String value) {
            addCriterion("RADIATION_DIAGNOSIS_PATH not like", value, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathIn(List<String> values) {
            addCriterion("RADIATION_DIAGNOSIS_PATH in", values, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathNotIn(List<String> values) {
            addCriterion("RADIATION_DIAGNOSIS_PATH not in", values, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathBetween(String value1, String value2) {
            addCriterion("RADIATION_DIAGNOSIS_PATH between", value1, value2, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathNotBetween(String value1, String value2) {
            addCriterion("RADIATION_DIAGNOSIS_PATH not between", value1, value2, "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoIsNull() {
            addCriterion("RADIATION_SAFTY_NO is null");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoIsNotNull() {
            addCriterion("RADIATION_SAFTY_NO is not null");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoEqualTo(String value) {
            addCriterion("RADIATION_SAFTY_NO =", value, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoNotEqualTo(String value) {
            addCriterion("RADIATION_SAFTY_NO <>", value, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoGreaterThan(String value) {
            addCriterion("RADIATION_SAFTY_NO >", value, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoGreaterThanOrEqualTo(String value) {
            addCriterion("RADIATION_SAFTY_NO >=", value, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoLessThan(String value) {
            addCriterion("RADIATION_SAFTY_NO <", value, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoLessThanOrEqualTo(String value) {
            addCriterion("RADIATION_SAFTY_NO <=", value, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoLike(String value) {
            addCriterion("RADIATION_SAFTY_NO like", value, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoNotLike(String value) {
            addCriterion("RADIATION_SAFTY_NO not like", value, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoIn(List<String> values) {
            addCriterion("RADIATION_SAFTY_NO in", values, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoNotIn(List<String> values) {
            addCriterion("RADIATION_SAFTY_NO not in", values, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoBetween(String value1, String value2) {
            addCriterion("RADIATION_SAFTY_NO between", value1, value2, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoNotBetween(String value1, String value2) {
            addCriterion("RADIATION_SAFTY_NO not between", value1, value2, "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathIsNull() {
            addCriterion("RADIATION_SAFTY_PATH is null");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathIsNotNull() {
            addCriterion("RADIATION_SAFTY_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathEqualTo(String value) {
            addCriterion("RADIATION_SAFTY_PATH =", value, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathNotEqualTo(String value) {
            addCriterion("RADIATION_SAFTY_PATH <>", value, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathGreaterThan(String value) {
            addCriterion("RADIATION_SAFTY_PATH >", value, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathGreaterThanOrEqualTo(String value) {
            addCriterion("RADIATION_SAFTY_PATH >=", value, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathLessThan(String value) {
            addCriterion("RADIATION_SAFTY_PATH <", value, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathLessThanOrEqualTo(String value) {
            addCriterion("RADIATION_SAFTY_PATH <=", value, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathLike(String value) {
            addCriterion("RADIATION_SAFTY_PATH like", value, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathNotLike(String value) {
            addCriterion("RADIATION_SAFTY_PATH not like", value, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathIn(List<String> values) {
            addCriterion("RADIATION_SAFTY_PATH in", values, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathNotIn(List<String> values) {
            addCriterion("RADIATION_SAFTY_PATH not in", values, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathBetween(String value1, String value2) {
            addCriterion("RADIATION_SAFTY_PATH between", value1, value2, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathNotBetween(String value1, String value2) {
            addCriterion("RADIATION_SAFTY_PATH not between", value1, value2, "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoIsNull() {
            addCriterion("LEGAL_REPRESENTATIVE_NO is null");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoIsNotNull() {
            addCriterion("LEGAL_REPRESENTATIVE_NO is not null");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_NO =", value, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoNotEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_NO <>", value, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoGreaterThan(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_NO >", value, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoGreaterThanOrEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_NO >=", value, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoLessThan(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_NO <", value, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoLessThanOrEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_NO <=", value, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoLike(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_NO like", value, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoNotLike(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_NO not like", value, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoIn(List<String> values) {
            addCriterion("LEGAL_REPRESENTATIVE_NO in", values, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoNotIn(List<String> values) {
            addCriterion("LEGAL_REPRESENTATIVE_NO not in", values, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoBetween(String value1, String value2) {
            addCriterion("LEGAL_REPRESENTATIVE_NO between", value1, value2, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoNotBetween(String value1, String value2) {
            addCriterion("LEGAL_REPRESENTATIVE_NO not between", value1, value2, "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaIsNull() {
            addCriterion("LEGAL_REPRESENTATIVE_IDA is null");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaIsNotNull() {
            addCriterion("LEGAL_REPRESENTATIVE_IDA is not null");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA =", value, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaNotEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA <>", value, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaGreaterThan(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA >", value, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaGreaterThanOrEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA >=", value, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaLessThan(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA <", value, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaLessThanOrEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA <=", value, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaLike(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA like", value, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaNotLike(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA not like", value, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaIn(List<String> values) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA in", values, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaNotIn(List<String> values) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA not in", values, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaBetween(String value1, String value2) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA between", value1, value2, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaNotBetween(String value1, String value2) {
            addCriterion("LEGAL_REPRESENTATIVE_IDA not between", value1, value2, "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbIsNull() {
            addCriterion("LEGAL_REPRESENTATIVE_IDB is null");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbIsNotNull() {
            addCriterion("LEGAL_REPRESENTATIVE_IDB is not null");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB =", value, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbNotEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB <>", value, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbGreaterThan(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB >", value, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbGreaterThanOrEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB >=", value, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbLessThan(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB <", value, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbLessThanOrEqualTo(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB <=", value, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbLike(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB like", value, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbNotLike(String value) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB not like", value, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbIn(List<String> values) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB in", values, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbNotIn(List<String> values) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB not in", values, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbBetween(String value1, String value2) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB between", value1, value2, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbNotBetween(String value1, String value2) {
            addCriterion("LEGAL_REPRESENTATIVE_IDB not between", value1, value2, "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameIsNull() {
            addCriterion("ADMINISTRATOR_NAME is null");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameIsNotNull() {
            addCriterion("ADMINISTRATOR_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameEqualTo(String value) {
            addCriterion("ADMINISTRATOR_NAME =", value, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameNotEqualTo(String value) {
            addCriterion("ADMINISTRATOR_NAME <>", value, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameGreaterThan(String value) {
            addCriterion("ADMINISTRATOR_NAME >", value, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameGreaterThanOrEqualTo(String value) {
            addCriterion("ADMINISTRATOR_NAME >=", value, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameLessThan(String value) {
            addCriterion("ADMINISTRATOR_NAME <", value, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameLessThanOrEqualTo(String value) {
            addCriterion("ADMINISTRATOR_NAME <=", value, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameLike(String value) {
            addCriterion("ADMINISTRATOR_NAME like", value, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameNotLike(String value) {
            addCriterion("ADMINISTRATOR_NAME not like", value, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameIn(List<String> values) {
            addCriterion("ADMINISTRATOR_NAME in", values, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameNotIn(List<String> values) {
            addCriterion("ADMINISTRATOR_NAME not in", values, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameBetween(String value1, String value2) {
            addCriterion("ADMINISTRATOR_NAME between", value1, value2, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameNotBetween(String value1, String value2) {
            addCriterion("ADMINISTRATOR_NAME not between", value1, value2, "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelIsNull() {
            addCriterion("ADMINISTRATOR_TEL is null");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelIsNotNull() {
            addCriterion("ADMINISTRATOR_TEL is not null");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelEqualTo(String value) {
            addCriterion("ADMINISTRATOR_TEL =", value, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelNotEqualTo(String value) {
            addCriterion("ADMINISTRATOR_TEL <>", value, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelGreaterThan(String value) {
            addCriterion("ADMINISTRATOR_TEL >", value, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelGreaterThanOrEqualTo(String value) {
            addCriterion("ADMINISTRATOR_TEL >=", value, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelLessThan(String value) {
            addCriterion("ADMINISTRATOR_TEL <", value, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelLessThanOrEqualTo(String value) {
            addCriterion("ADMINISTRATOR_TEL <=", value, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelLike(String value) {
            addCriterion("ADMINISTRATOR_TEL like", value, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelNotLike(String value) {
            addCriterion("ADMINISTRATOR_TEL not like", value, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelIn(List<String> values) {
            addCriterion("ADMINISTRATOR_TEL in", values, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelNotIn(List<String> values) {
            addCriterion("ADMINISTRATOR_TEL not in", values, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelBetween(String value1, String value2) {
            addCriterion("ADMINISTRATOR_TEL between", value1, value2, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelNotBetween(String value1, String value2) {
            addCriterion("ADMINISTRATOR_TEL not between", value1, value2, "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaIsNull() {
            addCriterion("ADMINISTRATOR_IDA is null");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaIsNotNull() {
            addCriterion("ADMINISTRATOR_IDA is not null");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaEqualTo(String value) {
            addCriterion("ADMINISTRATOR_IDA =", value, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaNotEqualTo(String value) {
            addCriterion("ADMINISTRATOR_IDA <>", value, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaGreaterThan(String value) {
            addCriterion("ADMINISTRATOR_IDA >", value, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaGreaterThanOrEqualTo(String value) {
            addCriterion("ADMINISTRATOR_IDA >=", value, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaLessThan(String value) {
            addCriterion("ADMINISTRATOR_IDA <", value, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaLessThanOrEqualTo(String value) {
            addCriterion("ADMINISTRATOR_IDA <=", value, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaLike(String value) {
            addCriterion("ADMINISTRATOR_IDA like", value, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaNotLike(String value) {
            addCriterion("ADMINISTRATOR_IDA not like", value, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaIn(List<String> values) {
            addCriterion("ADMINISTRATOR_IDA in", values, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaNotIn(List<String> values) {
            addCriterion("ADMINISTRATOR_IDA not in", values, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaBetween(String value1, String value2) {
            addCriterion("ADMINISTRATOR_IDA between", value1, value2, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaNotBetween(String value1, String value2) {
            addCriterion("ADMINISTRATOR_IDA not between", value1, value2, "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbIsNull() {
            addCriterion("ADMINISTRATOR_IDB is null");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbIsNotNull() {
            addCriterion("ADMINISTRATOR_IDB is not null");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbEqualTo(String value) {
            addCriterion("ADMINISTRATOR_IDB =", value, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbNotEqualTo(String value) {
            addCriterion("ADMINISTRATOR_IDB <>", value, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbGreaterThan(String value) {
            addCriterion("ADMINISTRATOR_IDB >", value, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbGreaterThanOrEqualTo(String value) {
            addCriterion("ADMINISTRATOR_IDB >=", value, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbLessThan(String value) {
            addCriterion("ADMINISTRATOR_IDB <", value, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbLessThanOrEqualTo(String value) {
            addCriterion("ADMINISTRATOR_IDB <=", value, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbLike(String value) {
            addCriterion("ADMINISTRATOR_IDB like", value, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbNotLike(String value) {
            addCriterion("ADMINISTRATOR_IDB not like", value, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbIn(List<String> values) {
            addCriterion("ADMINISTRATOR_IDB in", values, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbNotIn(List<String> values) {
            addCriterion("ADMINISTRATOR_IDB not in", values, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbBetween(String value1, String value2) {
            addCriterion("ADMINISTRATOR_IDB between", value1, value2, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbNotBetween(String value1, String value2) {
            addCriterion("ADMINISTRATOR_IDB not between", value1, value2, "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathIsNull() {
            addCriterion("AUTHORIZE_MAG_PATH is null");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathIsNotNull() {
            addCriterion("AUTHORIZE_MAG_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathEqualTo(String value) {
            addCriterion("AUTHORIZE_MAG_PATH =", value, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathNotEqualTo(String value) {
            addCriterion("AUTHORIZE_MAG_PATH <>", value, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathGreaterThan(String value) {
            addCriterion("AUTHORIZE_MAG_PATH >", value, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathGreaterThanOrEqualTo(String value) {
            addCriterion("AUTHORIZE_MAG_PATH >=", value, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathLessThan(String value) {
            addCriterion("AUTHORIZE_MAG_PATH <", value, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathLessThanOrEqualTo(String value) {
            addCriterion("AUTHORIZE_MAG_PATH <=", value, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathLike(String value) {
            addCriterion("AUTHORIZE_MAG_PATH like", value, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathNotLike(String value) {
            addCriterion("AUTHORIZE_MAG_PATH not like", value, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathIn(List<String> values) {
            addCriterion("AUTHORIZE_MAG_PATH in", values, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathNotIn(List<String> values) {
            addCriterion("AUTHORIZE_MAG_PATH not in", values, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathBetween(String value1, String value2) {
            addCriterion("AUTHORIZE_MAG_PATH between", value1, value2, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathNotBetween(String value1, String value2) {
            addCriterion("AUTHORIZE_MAG_PATH not between", value1, value2, "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathIsNull() {
            addCriterion("CLINIC_PHOTO_PATH is null");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathIsNotNull() {
            addCriterion("CLINIC_PHOTO_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathEqualTo(String value) {
            addCriterion("CLINIC_PHOTO_PATH =", value, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathNotEqualTo(String value) {
            addCriterion("CLINIC_PHOTO_PATH <>", value, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathGreaterThan(String value) {
            addCriterion("CLINIC_PHOTO_PATH >", value, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_PHOTO_PATH >=", value, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathLessThan(String value) {
            addCriterion("CLINIC_PHOTO_PATH <", value, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_PHOTO_PATH <=", value, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathLike(String value) {
            addCriterion("CLINIC_PHOTO_PATH like", value, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathNotLike(String value) {
            addCriterion("CLINIC_PHOTO_PATH not like", value, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathIn(List<String> values) {
            addCriterion("CLINIC_PHOTO_PATH in", values, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathNotIn(List<String> values) {
            addCriterion("CLINIC_PHOTO_PATH not in", values, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathBetween(String value1, String value2) {
            addCriterion("CLINIC_PHOTO_PATH between", value1, value2, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathNotBetween(String value1, String value2) {
            addCriterion("CLINIC_PHOTO_PATH not between", value1, value2, "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameIsNull() {
            addCriterion("CLINIC_FACADE_NAME is null");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameIsNotNull() {
            addCriterion("CLINIC_FACADE_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameEqualTo(String value) {
            addCriterion("CLINIC_FACADE_NAME =", value, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameNotEqualTo(String value) {
            addCriterion("CLINIC_FACADE_NAME <>", value, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameGreaterThan(String value) {
            addCriterion("CLINIC_FACADE_NAME >", value, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_FACADE_NAME >=", value, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameLessThan(String value) {
            addCriterion("CLINIC_FACADE_NAME <", value, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_FACADE_NAME <=", value, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameLike(String value) {
            addCriterion("CLINIC_FACADE_NAME like", value, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameNotLike(String value) {
            addCriterion("CLINIC_FACADE_NAME not like", value, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameIn(List<String> values) {
            addCriterion("CLINIC_FACADE_NAME in", values, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameNotIn(List<String> values) {
            addCriterion("CLINIC_FACADE_NAME not in", values, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameBetween(String value1, String value2) {
            addCriterion("CLINIC_FACADE_NAME between", value1, value2, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameNotBetween(String value1, String value2) {
            addCriterion("CLINIC_FACADE_NAME not between", value1, value2, "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameIsNull() {
            addCriterion("CLINIC_WAITING_NAME is null");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameIsNotNull() {
            addCriterion("CLINIC_WAITING_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameEqualTo(String value) {
            addCriterion("CLINIC_WAITING_NAME =", value, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameNotEqualTo(String value) {
            addCriterion("CLINIC_WAITING_NAME <>", value, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameGreaterThan(String value) {
            addCriterion("CLINIC_WAITING_NAME >", value, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_WAITING_NAME >=", value, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameLessThan(String value) {
            addCriterion("CLINIC_WAITING_NAME <", value, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_WAITING_NAME <=", value, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameLike(String value) {
            addCriterion("CLINIC_WAITING_NAME like", value, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameNotLike(String value) {
            addCriterion("CLINIC_WAITING_NAME not like", value, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameIn(List<String> values) {
            addCriterion("CLINIC_WAITING_NAME in", values, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameNotIn(List<String> values) {
            addCriterion("CLINIC_WAITING_NAME not in", values, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameBetween(String value1, String value2) {
            addCriterion("CLINIC_WAITING_NAME between", value1, value2, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameNotBetween(String value1, String value2) {
            addCriterion("CLINIC_WAITING_NAME not between", value1, value2, "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameIsNull() {
            addCriterion("CLINIC_MED_LAB_NAME is null");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameIsNotNull() {
            addCriterion("CLINIC_MED_LAB_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameEqualTo(String value) {
            addCriterion("CLINIC_MED_LAB_NAME =", value, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameNotEqualTo(String value) {
            addCriterion("CLINIC_MED_LAB_NAME <>", value, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameGreaterThan(String value) {
            addCriterion("CLINIC_MED_LAB_NAME >", value, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_MED_LAB_NAME >=", value, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameLessThan(String value) {
            addCriterion("CLINIC_MED_LAB_NAME <", value, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_MED_LAB_NAME <=", value, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameLike(String value) {
            addCriterion("CLINIC_MED_LAB_NAME like", value, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameNotLike(String value) {
            addCriterion("CLINIC_MED_LAB_NAME not like", value, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameIn(List<String> values) {
            addCriterion("CLINIC_MED_LAB_NAME in", values, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameNotIn(List<String> values) {
            addCriterion("CLINIC_MED_LAB_NAME not in", values, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameBetween(String value1, String value2) {
            addCriterion("CLINIC_MED_LAB_NAME between", value1, value2, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameNotBetween(String value1, String value2) {
            addCriterion("CLINIC_MED_LAB_NAME not between", value1, value2, "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameIsNull() {
            addCriterion("CLINIC_OTHER_NAME is null");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameIsNotNull() {
            addCriterion("CLINIC_OTHER_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameEqualTo(String value) {
            addCriterion("CLINIC_OTHER_NAME =", value, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameNotEqualTo(String value) {
            addCriterion("CLINIC_OTHER_NAME <>", value, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameGreaterThan(String value) {
            addCriterion("CLINIC_OTHER_NAME >", value, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_OTHER_NAME >=", value, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameLessThan(String value) {
            addCriterion("CLINIC_OTHER_NAME <", value, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_OTHER_NAME <=", value, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameLike(String value) {
            addCriterion("CLINIC_OTHER_NAME like", value, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameNotLike(String value) {
            addCriterion("CLINIC_OTHER_NAME not like", value, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameIn(List<String> values) {
            addCriterion("CLINIC_OTHER_NAME in", values, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameNotIn(List<String> values) {
            addCriterion("CLINIC_OTHER_NAME not in", values, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameBetween(String value1, String value2) {
            addCriterion("CLINIC_OTHER_NAME between", value1, value2, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameNotBetween(String value1, String value2) {
            addCriterion("CLINIC_OTHER_NAME not between", value1, value2, "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaIsNull() {
            addCriterion("OPERATING_AREA is null");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaIsNotNull() {
            addCriterion("OPERATING_AREA is not null");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaEqualTo(BigDecimal value) {
            addCriterion("OPERATING_AREA =", value, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaNotEqualTo(BigDecimal value) {
            addCriterion("OPERATING_AREA <>", value, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaGreaterThan(BigDecimal value) {
            addCriterion("OPERATING_AREA >", value, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("OPERATING_AREA >=", value, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaLessThan(BigDecimal value) {
            addCriterion("OPERATING_AREA <", value, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaLessThanOrEqualTo(BigDecimal value) {
            addCriterion("OPERATING_AREA <=", value, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaIn(List<BigDecimal> values) {
            addCriterion("OPERATING_AREA in", values, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaNotIn(List<BigDecimal> values) {
            addCriterion("OPERATING_AREA not in", values, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("OPERATING_AREA between", value1, value2, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andOperatingAreaNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("OPERATING_AREA not between", value1, value2, "operatingArea");
            return (Criteria) this;
        }

        public Criteria andAloneRoomIsNull() {
            addCriterion("ALONE_ROOM is null");
            return (Criteria) this;
        }

        public Criteria andAloneRoomIsNotNull() {
            addCriterion("ALONE_ROOM is not null");
            return (Criteria) this;
        }

        public Criteria andAloneRoomEqualTo(Long value) {
            addCriterion("ALONE_ROOM =", value, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomNotEqualTo(Long value) {
            addCriterion("ALONE_ROOM <>", value, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomGreaterThan(Long value) {
            addCriterion("ALONE_ROOM >", value, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomGreaterThanOrEqualTo(Long value) {
            addCriterion("ALONE_ROOM >=", value, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomLessThan(Long value) {
            addCriterion("ALONE_ROOM <", value, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomLessThanOrEqualTo(Long value) {
            addCriterion("ALONE_ROOM <=", value, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomIn(List<Long> values) {
            addCriterion("ALONE_ROOM in", values, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomNotIn(List<Long> values) {
            addCriterion("ALONE_ROOM not in", values, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomBetween(Long value1, Long value2) {
            addCriterion("ALONE_ROOM between", value1, value2, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andAloneRoomNotBetween(Long value1, Long value2) {
            addCriterion("ALONE_ROOM not between", value1, value2, "aloneRoom");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaIsNull() {
            addCriterion("WAITING_AREA is null");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaIsNotNull() {
            addCriterion("WAITING_AREA is not null");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaEqualTo(BigDecimal value) {
            addCriterion("WAITING_AREA =", value, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaNotEqualTo(BigDecimal value) {
            addCriterion("WAITING_AREA <>", value, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaGreaterThan(BigDecimal value) {
            addCriterion("WAITING_AREA >", value, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("WAITING_AREA >=", value, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaLessThan(BigDecimal value) {
            addCriterion("WAITING_AREA <", value, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaLessThanOrEqualTo(BigDecimal value) {
            addCriterion("WAITING_AREA <=", value, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaIn(List<BigDecimal> values) {
            addCriterion("WAITING_AREA in", values, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaNotIn(List<BigDecimal> values) {
            addCriterion("WAITING_AREA not in", values, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("WAITING_AREA between", value1, value2, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andWaitingAreaNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("WAITING_AREA not between", value1, value2, "waitingArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaIsNull() {
            addCriterion("CHILDREN_AREA is null");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaIsNotNull() {
            addCriterion("CHILDREN_AREA is not null");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaEqualTo(BigDecimal value) {
            addCriterion("CHILDREN_AREA =", value, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaNotEqualTo(BigDecimal value) {
            addCriterion("CHILDREN_AREA <>", value, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaGreaterThan(BigDecimal value) {
            addCriterion("CHILDREN_AREA >", value, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("CHILDREN_AREA >=", value, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaLessThan(BigDecimal value) {
            addCriterion("CHILDREN_AREA <", value, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaLessThanOrEqualTo(BigDecimal value) {
            addCriterion("CHILDREN_AREA <=", value, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaIn(List<BigDecimal> values) {
            addCriterion("CHILDREN_AREA in", values, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaNotIn(List<BigDecimal> values) {
            addCriterion("CHILDREN_AREA not in", values, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CHILDREN_AREA between", value1, value2, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andChildrenAreaNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CHILDREN_AREA not between", value1, value2, "childrenArea");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyIsNull() {
            addCriterion("SPECIAL_TECHNOLOGY is null");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyIsNotNull() {
            addCriterion("SPECIAL_TECHNOLOGY is not null");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyEqualTo(String value) {
            addCriterion("SPECIAL_TECHNOLOGY =", value, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyNotEqualTo(String value) {
            addCriterion("SPECIAL_TECHNOLOGY <>", value, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyGreaterThan(String value) {
            addCriterion("SPECIAL_TECHNOLOGY >", value, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyGreaterThanOrEqualTo(String value) {
            addCriterion("SPECIAL_TECHNOLOGY >=", value, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyLessThan(String value) {
            addCriterion("SPECIAL_TECHNOLOGY <", value, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyLessThanOrEqualTo(String value) {
            addCriterion("SPECIAL_TECHNOLOGY <=", value, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyLike(String value) {
            addCriterion("SPECIAL_TECHNOLOGY like", value, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyNotLike(String value) {
            addCriterion("SPECIAL_TECHNOLOGY not like", value, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyIn(List<String> values) {
            addCriterion("SPECIAL_TECHNOLOGY in", values, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyNotIn(List<String> values) {
            addCriterion("SPECIAL_TECHNOLOGY not in", values, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyBetween(String value1, String value2) {
            addCriterion("SPECIAL_TECHNOLOGY between", value1, value2, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyNotBetween(String value1, String value2) {
            addCriterion("SPECIAL_TECHNOLOGY not between", value1, value2, "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonIsNull() {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON is null");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonIsNotNull() {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON is not null");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonEqualTo(Long value) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON =", value, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonNotEqualTo(Long value) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON <>", value, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonGreaterThan(Long value) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON >", value, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonGreaterThanOrEqualTo(Long value) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON >=", value, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonLessThan(Long value) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON <", value, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonLessThanOrEqualTo(Long value) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON <=", value, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonIn(List<Long> values) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON in", values, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonNotIn(List<Long> values) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON not in", values, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonBetween(Long value1, Long value2) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON between", value1, value2, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andAnnualDiagnosisPersonNotBetween(Long value1, Long value2) {
            addCriterion("ANNUAL_DIAGNOSIS_PERSON not between", value1, value2, "annualDiagnosisPerson");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeIsNull() {
            addCriterion("MEDICAL_SERVICE_INCOME is null");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeIsNotNull() {
            addCriterion("MEDICAL_SERVICE_INCOME is not null");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeEqualTo(Long value) {
            addCriterion("MEDICAL_SERVICE_INCOME =", value, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeNotEqualTo(Long value) {
            addCriterion("MEDICAL_SERVICE_INCOME <>", value, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeGreaterThan(Long value) {
            addCriterion("MEDICAL_SERVICE_INCOME >", value, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeGreaterThanOrEqualTo(Long value) {
            addCriterion("MEDICAL_SERVICE_INCOME >=", value, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeLessThan(Long value) {
            addCriterion("MEDICAL_SERVICE_INCOME <", value, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeLessThanOrEqualTo(Long value) {
            addCriterion("MEDICAL_SERVICE_INCOME <=", value, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeIn(List<Long> values) {
            addCriterion("MEDICAL_SERVICE_INCOME in", values, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeNotIn(List<Long> values) {
            addCriterion("MEDICAL_SERVICE_INCOME not in", values, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeBetween(Long value1, Long value2) {
            addCriterion("MEDICAL_SERVICE_INCOME between", value1, value2, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andMedicalServiceIncomeNotBetween(Long value1, Long value2) {
            addCriterion("MEDICAL_SERVICE_INCOME not between", value1, value2, "medicalServiceIncome");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateIsNull() {
            addCriterion("OPERATING_BEGIN_DATE is null");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateIsNotNull() {
            addCriterion("OPERATING_BEGIN_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateEqualTo(String value) {
            addCriterion("OPERATING_BEGIN_DATE =", value, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateNotEqualTo(String value) {
            addCriterion("OPERATING_BEGIN_DATE <>", value, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateGreaterThan(String value) {
            addCriterion("OPERATING_BEGIN_DATE >", value, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateGreaterThanOrEqualTo(String value) {
            addCriterion("OPERATING_BEGIN_DATE >=", value, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateLessThan(String value) {
            addCriterion("OPERATING_BEGIN_DATE <", value, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateLessThanOrEqualTo(String value) {
            addCriterion("OPERATING_BEGIN_DATE <=", value, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateLike(String value) {
            addCriterion("OPERATING_BEGIN_DATE like", value, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateNotLike(String value) {
            addCriterion("OPERATING_BEGIN_DATE not like", value, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateIn(List<String> values) {
            addCriterion("OPERATING_BEGIN_DATE in", values, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateNotIn(List<String> values) {
            addCriterion("OPERATING_BEGIN_DATE not in", values, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateBetween(String value1, String value2) {
            addCriterion("OPERATING_BEGIN_DATE between", value1, value2, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateNotBetween(String value1, String value2) {
            addCriterion("OPERATING_BEGIN_DATE not between", value1, value2, "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceIsNull() {
            addCriterion("SAME_CLINIC_INTRODUCE is null");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceIsNotNull() {
            addCriterion("SAME_CLINIC_INTRODUCE is not null");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceEqualTo(String value) {
            addCriterion("SAME_CLINIC_INTRODUCE =", value, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceNotEqualTo(String value) {
            addCriterion("SAME_CLINIC_INTRODUCE <>", value, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceGreaterThan(String value) {
            addCriterion("SAME_CLINIC_INTRODUCE >", value, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceGreaterThanOrEqualTo(String value) {
            addCriterion("SAME_CLINIC_INTRODUCE >=", value, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceLessThan(String value) {
            addCriterion("SAME_CLINIC_INTRODUCE <", value, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceLessThanOrEqualTo(String value) {
            addCriterion("SAME_CLINIC_INTRODUCE <=", value, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceLike(String value) {
            addCriterion("SAME_CLINIC_INTRODUCE like", value, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceNotLike(String value) {
            addCriterion("SAME_CLINIC_INTRODUCE not like", value, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceIn(List<String> values) {
            addCriterion("SAME_CLINIC_INTRODUCE in", values, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceNotIn(List<String> values) {
            addCriterion("SAME_CLINIC_INTRODUCE not in", values, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceBetween(String value1, String value2) {
            addCriterion("SAME_CLINIC_INTRODUCE between", value1, value2, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceNotBetween(String value1, String value2) {
            addCriterion("SAME_CLINIC_INTRODUCE not between", value1, value2, "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andManagementSystemIsNull() {
            addCriterion("MANAGEMENT_SYSTEM is null");
            return (Criteria) this;
        }

        public Criteria andManagementSystemIsNotNull() {
            addCriterion("MANAGEMENT_SYSTEM is not null");
            return (Criteria) this;
        }

        public Criteria andManagementSystemEqualTo(String value) {
            addCriterion("MANAGEMENT_SYSTEM =", value, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemNotEqualTo(String value) {
            addCriterion("MANAGEMENT_SYSTEM <>", value, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemGreaterThan(String value) {
            addCriterion("MANAGEMENT_SYSTEM >", value, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemGreaterThanOrEqualTo(String value) {
            addCriterion("MANAGEMENT_SYSTEM >=", value, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemLessThan(String value) {
            addCriterion("MANAGEMENT_SYSTEM <", value, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemLessThanOrEqualTo(String value) {
            addCriterion("MANAGEMENT_SYSTEM <=", value, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemLike(String value) {
            addCriterion("MANAGEMENT_SYSTEM like", value, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemNotLike(String value) {
            addCriterion("MANAGEMENT_SYSTEM not like", value, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemIn(List<String> values) {
            addCriterion("MANAGEMENT_SYSTEM in", values, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemNotIn(List<String> values) {
            addCriterion("MANAGEMENT_SYSTEM not in", values, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemBetween(String value1, String value2) {
            addCriterion("MANAGEMENT_SYSTEM between", value1, value2, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andManagementSystemNotBetween(String value1, String value2) {
            addCriterion("MANAGEMENT_SYSTEM not between", value1, value2, "managementSystem");
            return (Criteria) this;
        }

        public Criteria andSystemBrandIsNull() {
            addCriterion("SYSTEM_BRAND is null");
            return (Criteria) this;
        }

        public Criteria andSystemBrandIsNotNull() {
            addCriterion("SYSTEM_BRAND is not null");
            return (Criteria) this;
        }

        public Criteria andSystemBrandEqualTo(String value) {
            addCriterion("SYSTEM_BRAND =", value, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandNotEqualTo(String value) {
            addCriterion("SYSTEM_BRAND <>", value, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandGreaterThan(String value) {
            addCriterion("SYSTEM_BRAND >", value, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandGreaterThanOrEqualTo(String value) {
            addCriterion("SYSTEM_BRAND >=", value, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandLessThan(String value) {
            addCriterion("SYSTEM_BRAND <", value, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandLessThanOrEqualTo(String value) {
            addCriterion("SYSTEM_BRAND <=", value, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandLike(String value) {
            addCriterion("SYSTEM_BRAND like", value, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandNotLike(String value) {
            addCriterion("SYSTEM_BRAND not like", value, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandIn(List<String> values) {
            addCriterion("SYSTEM_BRAND in", values, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandNotIn(List<String> values) {
            addCriterion("SYSTEM_BRAND not in", values, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandBetween(String value1, String value2) {
            addCriterion("SYSTEM_BRAND between", value1, value2, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andSystemBrandNotBetween(String value1, String value2) {
            addCriterion("SYSTEM_BRAND not between", value1, value2, "systemBrand");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityIsNull() {
            addCriterion("HARDWARE_FACILITY is null");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityIsNotNull() {
            addCriterion("HARDWARE_FACILITY is not null");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityEqualTo(String value) {
            addCriterion("HARDWARE_FACILITY =", value, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityNotEqualTo(String value) {
            addCriterion("HARDWARE_FACILITY <>", value, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityGreaterThan(String value) {
            addCriterion("HARDWARE_FACILITY >", value, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityGreaterThanOrEqualTo(String value) {
            addCriterion("HARDWARE_FACILITY >=", value, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityLessThan(String value) {
            addCriterion("HARDWARE_FACILITY <", value, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityLessThanOrEqualTo(String value) {
            addCriterion("HARDWARE_FACILITY <=", value, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityLike(String value) {
            addCriterion("HARDWARE_FACILITY like", value, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityNotLike(String value) {
            addCriterion("HARDWARE_FACILITY not like", value, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityIn(List<String> values) {
            addCriterion("HARDWARE_FACILITY in", values, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityNotIn(List<String> values) {
            addCriterion("HARDWARE_FACILITY not in", values, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityBetween(String value1, String value2) {
            addCriterion("HARDWARE_FACILITY between", value1, value2, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityNotBetween(String value1, String value2) {
            addCriterion("HARDWARE_FACILITY not between", value1, value2, "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyIsNull() {
            addCriterion("OPERATING_DIFFICULTY is null");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyIsNotNull() {
            addCriterion("OPERATING_DIFFICULTY is not null");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyEqualTo(String value) {
            addCriterion("OPERATING_DIFFICULTY =", value, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyNotEqualTo(String value) {
            addCriterion("OPERATING_DIFFICULTY <>", value, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyGreaterThan(String value) {
            addCriterion("OPERATING_DIFFICULTY >", value, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyGreaterThanOrEqualTo(String value) {
            addCriterion("OPERATING_DIFFICULTY >=", value, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyLessThan(String value) {
            addCriterion("OPERATING_DIFFICULTY <", value, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyLessThanOrEqualTo(String value) {
            addCriterion("OPERATING_DIFFICULTY <=", value, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyLike(String value) {
            addCriterion("OPERATING_DIFFICULTY like", value, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyNotLike(String value) {
            addCriterion("OPERATING_DIFFICULTY not like", value, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyIn(List<String> values) {
            addCriterion("OPERATING_DIFFICULTY in", values, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyNotIn(List<String> values) {
            addCriterion("OPERATING_DIFFICULTY not in", values, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyBetween(String value1, String value2) {
            addCriterion("OPERATING_DIFFICULTY between", value1, value2, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyNotBetween(String value1, String value2) {
            addCriterion("OPERATING_DIFFICULTY not between", value1, value2, "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andCheckStatusIsNull() {
            addCriterion("CHECK_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andCheckStatusIsNotNull() {
            addCriterion("CHECK_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andCheckStatusEqualTo(String value) {
            addCriterion("CHECK_STATUS =", value, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusNotEqualTo(String value) {
            addCriterion("CHECK_STATUS <>", value, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusGreaterThan(String value) {
            addCriterion("CHECK_STATUS >", value, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusGreaterThanOrEqualTo(String value) {
            addCriterion("CHECK_STATUS >=", value, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusLessThan(String value) {
            addCriterion("CHECK_STATUS <", value, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusLessThanOrEqualTo(String value) {
            addCriterion("CHECK_STATUS <=", value, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusLike(String value) {
            addCriterion("CHECK_STATUS like", value, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusNotLike(String value) {
            addCriterion("CHECK_STATUS not like", value, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusIn(List<String> values) {
            addCriterion("CHECK_STATUS in", values, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusNotIn(List<String> values) {
            addCriterion("CHECK_STATUS not in", values, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusBetween(String value1, String value2) {
            addCriterion("CHECK_STATUS between", value1, value2, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckStatusNotBetween(String value1, String value2) {
            addCriterion("CHECK_STATUS not between", value1, value2, "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckReasonIsNull() {
            addCriterion("CHECK_REASON is null");
            return (Criteria) this;
        }

        public Criteria andCheckReasonIsNotNull() {
            addCriterion("CHECK_REASON is not null");
            return (Criteria) this;
        }

        public Criteria andCheckReasonEqualTo(String value) {
            addCriterion("CHECK_REASON =", value, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonNotEqualTo(String value) {
            addCriterion("CHECK_REASON <>", value, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonGreaterThan(String value) {
            addCriterion("CHECK_REASON >", value, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonGreaterThanOrEqualTo(String value) {
            addCriterion("CHECK_REASON >=", value, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonLessThan(String value) {
            addCriterion("CHECK_REASON <", value, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonLessThanOrEqualTo(String value) {
            addCriterion("CHECK_REASON <=", value, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonLike(String value) {
            addCriterion("CHECK_REASON like", value, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonNotLike(String value) {
            addCriterion("CHECK_REASON not like", value, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonIn(List<String> values) {
            addCriterion("CHECK_REASON in", values, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonNotIn(List<String> values) {
            addCriterion("CHECK_REASON not in", values, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonBetween(String value1, String value2) {
            addCriterion("CHECK_REASON between", value1, value2, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCheckReasonNotBetween(String value1, String value2) {
            addCriterion("CHECK_REASON not between", value1, value2, "checkReason");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("CREATE_USER is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("CREATE_USER is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("CREATE_USER =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("CREATE_USER <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("CREATE_USER >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("CREATE_USER >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("CREATE_USER <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("CREATE_USER <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("CREATE_USER like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("CREATE_USER not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("CREATE_USER in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("CREATE_USER not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("CREATE_USER between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("CREATE_USER not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("CREATE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("CREATE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("CREATE_DATE =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("CREATE_DATE <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("CREATE_DATE >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("CREATE_DATE <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("CREATE_DATE in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("CREATE_DATE not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNull() {
            addCriterion("MODIFY_USER is null");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNotNull() {
            addCriterion("MODIFY_USER is not null");
            return (Criteria) this;
        }

        public Criteria andModifyUserEqualTo(String value) {
            addCriterion("MODIFY_USER =", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotEqualTo(String value) {
            addCriterion("MODIFY_USER <>", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThan(String value) {
            addCriterion("MODIFY_USER >", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER >=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThan(String value) {
            addCriterion("MODIFY_USER <", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER <=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLike(String value) {
            addCriterion("MODIFY_USER like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotLike(String value) {
            addCriterion("MODIFY_USER not like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserIn(List<String> values) {
            addCriterion("MODIFY_USER in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotIn(List<String> values) {
            addCriterion("MODIFY_USER not in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserBetween(String value1, String value2) {
            addCriterion("MODIFY_USER between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotBetween(String value1, String value2) {
            addCriterion("MODIFY_USER not between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNull() {
            addCriterion("MODIFY_DATE is null");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNotNull() {
            addCriterion("MODIFY_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andModifyDateEqualTo(Date value) {
            addCriterion("MODIFY_DATE =", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotEqualTo(Date value) {
            addCriterion("MODIFY_DATE <>", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThan(Date value) {
            addCriterion("MODIFY_DATE >", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE >=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThan(Date value) {
            addCriterion("MODIFY_DATE <", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE <=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateIn(List<Date> values) {
            addCriterion("MODIFY_DATE in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotIn(List<Date> values) {
            addCriterion("MODIFY_DATE not in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE not between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("DEL_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("DEL_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(String value) {
            addCriterion("DEL_FLAG =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(String value) {
            addCriterion("DEL_FLAG <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(String value) {
            addCriterion("DEL_FLAG >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(String value) {
            addCriterion("DEL_FLAG <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLike(String value) {
            addCriterion("DEL_FLAG like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotLike(String value) {
            addCriterion("DEL_FLAG not like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<String> values) {
            addCriterion("DEL_FLAG in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<String> values) {
            addCriterion("DEL_FLAG not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(String value1, String value2) {
            addCriterion("DEL_FLAG between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(String value1, String value2) {
            addCriterion("DEL_FLAG not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1IsNull() {
            addCriterion("CLINIC_COMPLETE_FLAG1 is null");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1IsNotNull() {
            addCriterion("CLINIC_COMPLETE_FLAG1 is not null");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1EqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG1 =", value, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1NotEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG1 <>", value, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1GreaterThan(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG1 >", value, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1GreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG1 >=", value, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1LessThan(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG1 <", value, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1LessThanOrEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG1 <=", value, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1Like(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG1 like", value, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1NotLike(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG1 not like", value, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1In(List<String> values) {
            addCriterion("CLINIC_COMPLETE_FLAG1 in", values, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1NotIn(List<String> values) {
            addCriterion("CLINIC_COMPLETE_FLAG1 not in", values, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1Between(String value1, String value2) {
            addCriterion("CLINIC_COMPLETE_FLAG1 between", value1, value2, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1NotBetween(String value1, String value2) {
            addCriterion("CLINIC_COMPLETE_FLAG1 not between", value1, value2, "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2IsNull() {
            addCriterion("CLINIC_COMPLETE_FLAG2 is null");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2IsNotNull() {
            addCriterion("CLINIC_COMPLETE_FLAG2 is not null");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2EqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG2 =", value, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2NotEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG2 <>", value, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2GreaterThan(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG2 >", value, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2GreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG2 >=", value, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2LessThan(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG2 <", value, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2LessThanOrEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG2 <=", value, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2Like(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG2 like", value, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2NotLike(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG2 not like", value, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2In(List<String> values) {
            addCriterion("CLINIC_COMPLETE_FLAG2 in", values, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2NotIn(List<String> values) {
            addCriterion("CLINIC_COMPLETE_FLAG2 not in", values, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2Between(String value1, String value2) {
            addCriterion("CLINIC_COMPLETE_FLAG2 between", value1, value2, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2NotBetween(String value1, String value2) {
            addCriterion("CLINIC_COMPLETE_FLAG2 not between", value1, value2, "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3IsNull() {
            addCriterion("CLINIC_COMPLETE_FLAG3 is null");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3IsNotNull() {
            addCriterion("CLINIC_COMPLETE_FLAG3 is not null");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3EqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG3 =", value, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3NotEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG3 <>", value, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3GreaterThan(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG3 >", value, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3GreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG3 >=", value, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3LessThan(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG3 <", value, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3LessThanOrEqualTo(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG3 <=", value, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3Like(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG3 like", value, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3NotLike(String value) {
            addCriterion("CLINIC_COMPLETE_FLAG3 not like", value, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3In(List<String> values) {
            addCriterion("CLINIC_COMPLETE_FLAG3 in", values, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3NotIn(List<String> values) {
            addCriterion("CLINIC_COMPLETE_FLAG3 not in", values, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3Between(String value1, String value2) {
            addCriterion("CLINIC_COMPLETE_FLAG3 between", value1, value2, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3NotBetween(String value1, String value2) {
            addCriterion("CLINIC_COMPLETE_FLAG3 not between", value1, value2, "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andDataResourceIsNull() {
            addCriterion("DATA_RESOURCE is null");
            return (Criteria) this;
        }

        public Criteria andDataResourceIsNotNull() {
            addCriterion("DATA_RESOURCE is not null");
            return (Criteria) this;
        }

        public Criteria andDataResourceEqualTo(String value) {
            addCriterion("DATA_RESOURCE =", value, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceNotEqualTo(String value) {
            addCriterion("DATA_RESOURCE <>", value, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceGreaterThan(String value) {
            addCriterion("DATA_RESOURCE >", value, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_RESOURCE >=", value, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceLessThan(String value) {
            addCriterion("DATA_RESOURCE <", value, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceLessThanOrEqualTo(String value) {
            addCriterion("DATA_RESOURCE <=", value, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceLike(String value) {
            addCriterion("DATA_RESOURCE like", value, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceNotLike(String value) {
            addCriterion("DATA_RESOURCE not like", value, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceIn(List<String> values) {
            addCriterion("DATA_RESOURCE in", values, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceNotIn(List<String> values) {
            addCriterion("DATA_RESOURCE not in", values, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceBetween(String value1, String value2) {
            addCriterion("DATA_RESOURCE between", value1, value2, "dataResource");
            return (Criteria) this;
        }

        public Criteria andDataResourceNotBetween(String value1, String value2) {
            addCriterion("DATA_RESOURCE not between", value1, value2, "dataResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceIsNull() {
            addCriterion("REGISTER_RESOURCE is null");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceIsNotNull() {
            addCriterion("REGISTER_RESOURCE is not null");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceEqualTo(String value) {
            addCriterion("REGISTER_RESOURCE =", value, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceNotEqualTo(String value) {
            addCriterion("REGISTER_RESOURCE <>", value, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceGreaterThan(String value) {
            addCriterion("REGISTER_RESOURCE >", value, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceGreaterThanOrEqualTo(String value) {
            addCriterion("REGISTER_RESOURCE >=", value, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceLessThan(String value) {
            addCriterion("REGISTER_RESOURCE <", value, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceLessThanOrEqualTo(String value) {
            addCriterion("REGISTER_RESOURCE <=", value, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceLike(String value) {
            addCriterion("REGISTER_RESOURCE like", value, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceNotLike(String value) {
            addCriterion("REGISTER_RESOURCE not like", value, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceIn(List<String> values) {
            addCriterion("REGISTER_RESOURCE in", values, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceNotIn(List<String> values) {
            addCriterion("REGISTER_RESOURCE not in", values, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceBetween(String value1, String value2) {
            addCriterion("REGISTER_RESOURCE between", value1, value2, "registerResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceNotBetween(String value1, String value2) {
            addCriterion("REGISTER_RESOURCE not between", value1, value2, "registerResource");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaIsNull() {
            addCriterion("IS_WANJIA is null");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaIsNotNull() {
            addCriterion("IS_WANJIA is not null");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaEqualTo(String value) {
            addCriterion("IS_WANJIA =", value, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaNotEqualTo(String value) {
            addCriterion("IS_WANJIA <>", value, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaGreaterThan(String value) {
            addCriterion("IS_WANJIA >", value, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaGreaterThanOrEqualTo(String value) {
            addCriterion("IS_WANJIA >=", value, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaLessThan(String value) {
            addCriterion("IS_WANJIA <", value, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaLessThanOrEqualTo(String value) {
            addCriterion("IS_WANJIA <=", value, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaLike(String value) {
            addCriterion("IS_WANJIA like", value, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaNotLike(String value) {
            addCriterion("IS_WANJIA not like", value, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaIn(List<String> values) {
            addCriterion("IS_WANJIA in", values, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaNotIn(List<String> values) {
            addCriterion("IS_WANJIA not in", values, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaBetween(String value1, String value2) {
            addCriterion("IS_WANJIA between", value1, value2, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaNotBetween(String value1, String value2) {
            addCriterion("IS_WANJIA not between", value1, value2, "isWanjia");
            return (Criteria) this;
        }

        public Criteria andSubmitDateIsNull() {
            addCriterion("SUBMIT_DATE is null");
            return (Criteria) this;
        }

        public Criteria andSubmitDateIsNotNull() {
            addCriterion("SUBMIT_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andSubmitDateEqualTo(Date value) {
            addCriterion("SUBMIT_DATE =", value, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateNotEqualTo(Date value) {
            addCriterion("SUBMIT_DATE <>", value, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateGreaterThan(Date value) {
            addCriterion("SUBMIT_DATE >", value, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateGreaterThanOrEqualTo(Date value) {
            addCriterion("SUBMIT_DATE >=", value, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateLessThan(Date value) {
            addCriterion("SUBMIT_DATE <", value, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateLessThanOrEqualTo(Date value) {
            addCriterion("SUBMIT_DATE <=", value, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateIn(List<Date> values) {
            addCriterion("SUBMIT_DATE in", values, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateNotIn(List<Date> values) {
            addCriterion("SUBMIT_DATE not in", values, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateBetween(Date value1, Date value2) {
            addCriterion("SUBMIT_DATE between", value1, value2, "submitDate");
            return (Criteria) this;
        }

        public Criteria andSubmitDateNotBetween(Date value1, Date value2) {
            addCriterion("SUBMIT_DATE not between", value1, value2, "submitDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateIsNull() {
            addCriterion("CHECK_DATE is null");
            return (Criteria) this;
        }

        public Criteria andCheckDateIsNotNull() {
            addCriterion("CHECK_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andCheckDateEqualTo(Date value) {
            addCriterion("CHECK_DATE =", value, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateNotEqualTo(Date value) {
            addCriterion("CHECK_DATE <>", value, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateGreaterThan(Date value) {
            addCriterion("CHECK_DATE >", value, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateGreaterThanOrEqualTo(Date value) {
            addCriterion("CHECK_DATE >=", value, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateLessThan(Date value) {
            addCriterion("CHECK_DATE <", value, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateLessThanOrEqualTo(Date value) {
            addCriterion("CHECK_DATE <=", value, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateIn(List<Date> values) {
            addCriterion("CHECK_DATE in", values, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateNotIn(List<Date> values) {
            addCriterion("CHECK_DATE not in", values, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateBetween(Date value1, Date value2) {
            addCriterion("CHECK_DATE between", value1, value2, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckDateNotBetween(Date value1, Date value2) {
            addCriterion("CHECK_DATE not between", value1, value2, "checkDate");
            return (Criteria) this;
        }

        public Criteria andCheckUserIsNull() {
            addCriterion("CHECK_USER is null");
            return (Criteria) this;
        }

        public Criteria andCheckUserIsNotNull() {
            addCriterion("CHECK_USER is not null");
            return (Criteria) this;
        }

        public Criteria andCheckUserEqualTo(String value) {
            addCriterion("CHECK_USER =", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserNotEqualTo(String value) {
            addCriterion("CHECK_USER <>", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserGreaterThan(String value) {
            addCriterion("CHECK_USER >", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserGreaterThanOrEqualTo(String value) {
            addCriterion("CHECK_USER >=", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserLessThan(String value) {
            addCriterion("CHECK_USER <", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserLessThanOrEqualTo(String value) {
            addCriterion("CHECK_USER <=", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserLike(String value) {
            addCriterion("CHECK_USER like", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserNotLike(String value) {
            addCriterion("CHECK_USER not like", value, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserIn(List<String> values) {
            addCriterion("CHECK_USER in", values, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserNotIn(List<String> values) {
            addCriterion("CHECK_USER not in", values, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserBetween(String value1, String value2) {
            addCriterion("CHECK_USER between", value1, value2, "checkUser");
            return (Criteria) this;
        }

        public Criteria andCheckUserNotBetween(String value1, String value2) {
            addCriterion("CHECK_USER not between", value1, value2, "checkUser");
            return (Criteria) this;
        }

        public Criteria andIdLikeInsensitive(String value) {
            addCriterion("upper(ID) like", value.toUpperCase(), "id");
            return (Criteria) this;
        }

        public Criteria andClinicRegisterIdLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_REGISTER_ID) like", value.toUpperCase(), "clinicRegisterId");
            return (Criteria) this;
        }

        public Criteria andClinicNameLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_NAME) like", value.toUpperCase(), "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicLogoPathLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_LOGO_PATH) like", value.toUpperCase(), "clinicLogoPath");
            return (Criteria) this;
        }

        public Criteria andBankIdLikeInsensitive(String value) {
            addCriterion("upper(BANK_ID) like", value.toUpperCase(), "bankId");
            return (Criteria) this;
        }

        public Criteria andBankBranchIdLikeInsensitive(String value) {
            addCriterion("upper(BANK_BRANCH_ID) like", value.toUpperCase(), "bankBranchId");
            return (Criteria) this;
        }

        public Criteria andAccountNoLikeInsensitive(String value) {
            addCriterion("upper(ACCOUNT_NO) like", value.toUpperCase(), "accountNo");
            return (Criteria) this;
        }

        public Criteria andIsMedicalInsuranceLikeInsensitive(String value) {
            addCriterion("upper(IS_MEDICAL_INSURANCE) like", value.toUpperCase(), "isMedicalInsurance");
            return (Criteria) this;
        }

        public Criteria andMobileLikeInsensitive(String value) {
            addCriterion("upper(MOBILE) like", value.toUpperCase(), "mobile");
            return (Criteria) this;
        }

        public Criteria andPhoneLikeInsensitive(String value) {
            addCriterion("upper(PHONE) like", value.toUpperCase(), "phone");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeLikeInsensitive(String value) {
            addCriterion("upper(OPENING_TIME) like", value.toUpperCase(), "openingTime");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeBeginLikeInsensitive(String value) {
            addCriterion("upper(OPENING_TIME_BEGIN) like", value.toUpperCase(), "openingTimeBegin");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeEndLikeInsensitive(String value) {
            addCriterion("upper(OPENING_TIME_END) like", value.toUpperCase(), "openingTimeEnd");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeTypeLikeInsensitive(String value) {
            addCriterion("upper(OPENING_TIME_TYPE) like", value.toUpperCase(), "openingTimeType");
            return (Criteria) this;
        }

        public Criteria andOpeningTimeOtherLikeInsensitive(String value) {
            addCriterion("upper(OPENING_TIME_OTHER) like", value.toUpperCase(), "openingTimeOther");
            return (Criteria) this;
        }

        public Criteria andClinicTypePropertyLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_TYPE_PROPERTY) like", value.toUpperCase(), "clinicTypeProperty");
            return (Criteria) this;
        }

        public Criteria andClinicTypeDepartmentsLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_TYPE_DEPARTMENTS) like", value.toUpperCase(), "clinicTypeDepartments");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode1LikeInsensitive(String value) {
            addCriterion("upper(DIAGNOSIS_TYPE_CODE1) like", value.toUpperCase(), "diagnosisTypeCode1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType1LikeInsensitive(String value) {
            addCriterion("upper(DIAGNOSIS_TYPE_1) like", value.toUpperCase(), "diagnosisType1");
            return (Criteria) this;
        }

        public Criteria andDiagnosisTypeCode2LikeInsensitive(String value) {
            addCriterion("upper(DIAGNOSIS_TYPE_CODE2) like", value.toUpperCase(), "diagnosisTypeCode2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisType2LikeInsensitive(String value) {
            addCriterion("upper(DIAGNOSIS_TYPE_2) like", value.toUpperCase(), "diagnosisType2");
            return (Criteria) this;
        }

        public Criteria andDiagnosisItemLikeInsensitive(String value) {
            addCriterion("upper(DIAGNOSIS_ITEM) like", value.toUpperCase(), "diagnosisItem");
            return (Criteria) this;
        }

        public Criteria andClinicIntroduceLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_INTRODUCE) like", value.toUpperCase(), "clinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andBusinessLicenseNoLikeInsensitive(String value) {
            addCriterion("upper(BUSINESS_LICENSE_NO) like", value.toUpperCase(), "businessLicenseNo");
            return (Criteria) this;
        }

        public Criteria andBusinessLicensePathLikeInsensitive(String value) {
            addCriterion("upper(BUSINESS_LICENSE_PATH) like", value.toUpperCase(), "businessLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseNoLikeInsensitive(String value) {
            addCriterion("upper(PRACTICING_LICENSE_NO) like", value.toUpperCase(), "practicingLicenseNo");
            return (Criteria) this;
        }

        public Criteria andPracticingLicensePathLikeInsensitive(String value) {
            addCriterion("upper(PRACTICING_LICENSE_PATH) like", value.toUpperCase(), "practicingLicensePath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseFPathLikeInsensitive(String value) {
            addCriterion("upper(PRACTICING_LICENSE_F_PATH) like", value.toUpperCase(), "practicingLicenseFPath");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF2PathLikeInsensitive(String value) {
            addCriterion("upper(PRACTICING_LICENSE_F2_PATH) like", value.toUpperCase(), "practicingLicenseF2Path");
            return (Criteria) this;
        }

        public Criteria andPracticingLicenseF3PathLikeInsensitive(String value) {
            addCriterion("upper(PRACTICING_LICENSE_F3_PATH) like", value.toUpperCase(), "practicingLicenseF3Path");
            return (Criteria) this;
        }

        public Criteria andOrganizationNoLikeInsensitive(String value) {
            addCriterion("upper(ORGANIZATION_NO) like", value.toUpperCase(), "organizationNo");
            return (Criteria) this;
        }

        public Criteria andOrganizationPathLikeInsensitive(String value) {
            addCriterion("upper(ORGANIZATION_PATH) like", value.toUpperCase(), "organizationPath");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationNoLikeInsensitive(String value) {
            addCriterion("upper(TAX_REGISTRATION_NO) like", value.toUpperCase(), "taxRegistrationNo");
            return (Criteria) this;
        }

        public Criteria andTaxRegistrationPathLikeInsensitive(String value) {
            addCriterion("upper(TAX_REGISTRATION_PATH) like", value.toUpperCase(), "taxRegistrationPath");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsFilingLikeInsensitive(String value) {
            addCriterion("upper(CIVIL_AFFAIRS_FILING) like", value.toUpperCase(), "civilAffairsFiling");
            return (Criteria) this;
        }

        public Criteria andCivilAffairsPathLikeInsensitive(String value) {
            addCriterion("upper(CIVIL_AFFAIRS_PATH) like", value.toUpperCase(), "civilAffairsPath");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisNoLikeInsensitive(String value) {
            addCriterion("upper(RADIATION_DIAGNOSIS_NO) like", value.toUpperCase(), "radiationDiagnosisNo");
            return (Criteria) this;
        }

        public Criteria andRadiationDiagnosisPathLikeInsensitive(String value) {
            addCriterion("upper(RADIATION_DIAGNOSIS_PATH) like", value.toUpperCase(), "radiationDiagnosisPath");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyNoLikeInsensitive(String value) {
            addCriterion("upper(RADIATION_SAFTY_NO) like", value.toUpperCase(), "radiationSaftyNo");
            return (Criteria) this;
        }

        public Criteria andRadiationSaftyPathLikeInsensitive(String value) {
            addCriterion("upper(RADIATION_SAFTY_PATH) like", value.toUpperCase(), "radiationSaftyPath");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeNoLikeInsensitive(String value) {
            addCriterion("upper(LEGAL_REPRESENTATIVE_NO) like", value.toUpperCase(), "legalRepresentativeNo");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdaLikeInsensitive(String value) {
            addCriterion("upper(LEGAL_REPRESENTATIVE_IDA) like", value.toUpperCase(), "legalRepresentativeIda");
            return (Criteria) this;
        }

        public Criteria andLegalRepresentativeIdbLikeInsensitive(String value) {
            addCriterion("upper(LEGAL_REPRESENTATIVE_IDB) like", value.toUpperCase(), "legalRepresentativeIdb");
            return (Criteria) this;
        }

        public Criteria andAdministratorNameLikeInsensitive(String value) {
            addCriterion("upper(ADMINISTRATOR_NAME) like", value.toUpperCase(), "administratorName");
            return (Criteria) this;
        }

        public Criteria andAdministratorTelLikeInsensitive(String value) {
            addCriterion("upper(ADMINISTRATOR_TEL) like", value.toUpperCase(), "administratorTel");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdaLikeInsensitive(String value) {
            addCriterion("upper(ADMINISTRATOR_IDA) like", value.toUpperCase(), "administratorIda");
            return (Criteria) this;
        }

        public Criteria andAdministratorIdbLikeInsensitive(String value) {
            addCriterion("upper(ADMINISTRATOR_IDB) like", value.toUpperCase(), "administratorIdb");
            return (Criteria) this;
        }

        public Criteria andAuthorizeMagPathLikeInsensitive(String value) {
            addCriterion("upper(AUTHORIZE_MAG_PATH) like", value.toUpperCase(), "authorizeMagPath");
            return (Criteria) this;
        }

        public Criteria andClinicPhotoPathLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_PHOTO_PATH) like", value.toUpperCase(), "clinicPhotoPath");
            return (Criteria) this;
        }

        public Criteria andClinicFacadeNameLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_FACADE_NAME) like", value.toUpperCase(), "clinicFacadeName");
            return (Criteria) this;
        }

        public Criteria andClinicWaitingNameLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_WAITING_NAME) like", value.toUpperCase(), "clinicWaitingName");
            return (Criteria) this;
        }

        public Criteria andClinicMedLabNameLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_MED_LAB_NAME) like", value.toUpperCase(), "clinicMedLabName");
            return (Criteria) this;
        }

        public Criteria andClinicOtherNameLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_OTHER_NAME) like", value.toUpperCase(), "clinicOtherName");
            return (Criteria) this;
        }

        public Criteria andSpecialTechnologyLikeInsensitive(String value) {
            addCriterion("upper(SPECIAL_TECHNOLOGY) like", value.toUpperCase(), "specialTechnology");
            return (Criteria) this;
        }

        public Criteria andOperatingBeginDateLikeInsensitive(String value) {
            addCriterion("upper(OPERATING_BEGIN_DATE) like", value.toUpperCase(), "operatingBeginDate");
            return (Criteria) this;
        }

        public Criteria andSameClinicIntroduceLikeInsensitive(String value) {
            addCriterion("upper(SAME_CLINIC_INTRODUCE) like", value.toUpperCase(), "sameClinicIntroduce");
            return (Criteria) this;
        }

        public Criteria andManagementSystemLikeInsensitive(String value) {
            addCriterion("upper(MANAGEMENT_SYSTEM) like", value.toUpperCase(), "managementSystem");
            return (Criteria) this;
        }

        public Criteria andSystemBrandLikeInsensitive(String value) {
            addCriterion("upper(SYSTEM_BRAND) like", value.toUpperCase(), "systemBrand");
            return (Criteria) this;
        }

        public Criteria andHardwareFacilityLikeInsensitive(String value) {
            addCriterion("upper(HARDWARE_FACILITY) like", value.toUpperCase(), "hardwareFacility");
            return (Criteria) this;
        }

        public Criteria andOperatingDifficultyLikeInsensitive(String value) {
            addCriterion("upper(OPERATING_DIFFICULTY) like", value.toUpperCase(), "operatingDifficulty");
            return (Criteria) this;
        }

        public Criteria andCheckStatusLikeInsensitive(String value) {
            addCriterion("upper(CHECK_STATUS) like", value.toUpperCase(), "checkStatus");
            return (Criteria) this;
        }

        public Criteria andCheckReasonLikeInsensitive(String value) {
            addCriterion("upper(CHECK_REASON) like", value.toUpperCase(), "checkReason");
            return (Criteria) this;
        }

        public Criteria andCreateUserLikeInsensitive(String value) {
            addCriterion("upper(CREATE_USER) like", value.toUpperCase(), "createUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLikeInsensitive(String value) {
            addCriterion("upper(MODIFY_USER) like", value.toUpperCase(), "modifyUser");
            return (Criteria) this;
        }

        public Criteria andDelFlagLikeInsensitive(String value) {
            addCriterion("upper(DEL_FLAG) like", value.toUpperCase(), "delFlag");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag1LikeInsensitive(String value) {
            addCriterion("upper(CLINIC_COMPLETE_FLAG1) like", value.toUpperCase(), "clinicCompleteFlag1");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag2LikeInsensitive(String value) {
            addCriterion("upper(CLINIC_COMPLETE_FLAG2) like", value.toUpperCase(), "clinicCompleteFlag2");
            return (Criteria) this;
        }

        public Criteria andClinicCompleteFlag3LikeInsensitive(String value) {
            addCriterion("upper(CLINIC_COMPLETE_FLAG3) like", value.toUpperCase(), "clinicCompleteFlag3");
            return (Criteria) this;
        }

        public Criteria andDataResourceLikeInsensitive(String value) {
            addCriterion("upper(DATA_RESOURCE) like", value.toUpperCase(), "dataResource");
            return (Criteria) this;
        }

        public Criteria andRegisterResourceLikeInsensitive(String value) {
            addCriterion("upper(REGISTER_RESOURCE) like", value.toUpperCase(), "registerResource");
            return (Criteria) this;
        }

        public Criteria andIsWanjiaLikeInsensitive(String value) {
            addCriterion("upper(IS_WANJIA) like", value.toUpperCase(), "isWanjia");
            return (Criteria) this;
        }

        public Criteria andCheckUserLikeInsensitive(String value) {
            addCriterion("upper(CHECK_USER) like", value.toUpperCase(), "checkUser");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}