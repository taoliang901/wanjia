package com.wanjia.issue.service;

import com.wanjia.issue.dao.IssueOBInfoMapper;
import com.wanjia.issue.bo.IssueOBInfo;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueOBInfoModel;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.issue.dao.IssueMapper;
import com.wanjia.base.consts.SysConstant;
/**
 * This element is automatically generated on 16-8-3 下午8:14, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class IssueOBInfoServiceImpl implements IssueOBInfoService {
   
	
	@Autowired
    private IssueOBInfoMapper issueOBInfoMapper;
    
	@Autowired
    private IssueMapper issueMapper;
	//@Autowired
	//private IssueService issueService;
    
    @Override
    @Transactional(readOnly=true)
    public IssueOBInfo findById(String id) {
        return (IssueOBInfo)issueOBInfoMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBInfo> findWithPagination(int offset, int count) {
        return (List<IssueOBInfo>)issueOBInfoMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBInfo> findAll() {
        return (List<IssueOBInfo>)issueOBInfoMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBInfo> findByEntity(IssueOBInfo model) {
        return (List<IssueOBInfo>)issueOBInfoMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBInfo> findByEntityWithPagination(IssueOBInfo model, int offset, int count) {
        return (List<IssueOBInfo>)issueOBInfoMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueOBInfo findOneByEntity(IssueOBInfo model) {
        return (IssueOBInfo)issueOBInfoMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBInfo> findByProperty(String propertyName, String propertyValue) {
        return (List<IssueOBInfo>)issueOBInfoMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueOBInfo findOneByProperty(String propertyName, String propertyValue) {
        return (IssueOBInfo)issueOBInfoMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBInfo> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<IssueOBInfo>)issueOBInfoMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBInfo> findByProperties(Map<String, Object> map) {
        return (List<IssueOBInfo>)issueOBInfoMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(IssueOBInfo model) {
        return (long)issueOBInfoMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)issueOBInfoMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)issueOBInfoMapper.countByProperties(map);
    }

    @Override
    public void update(IssueOBInfo model) {
     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        issueOBInfoMapper.update(model);
    }

    @Override
    public void insert(IssueOBInfo model) {
     //   model.setCreateUser(ThreadLocalContext.getSystemUserId());
    	model.setDelFlag(SysConstant.NOT_DEL_FLAG);
    	model.setCreateDate(new Date());
        issueOBInfoMapper.insert(model);
    }

    @Override
    public void deleteByEntity(IssueOBInfo model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        issueOBInfoMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.issueOBInfoMapper.countAll();
    }

    public void insertBatch(List<IssueOBInfo> list) {
        this.issueOBInfoMapper.insertBatch(list);
    }

    public void delete(String id) {
        IssueOBInfo model = new IssueOBInfo();
        model.setDelFlag(SysConstant.DEL_FLAG);
    //    model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.issueOBInfoMapper.update(model);
    }
    
    @Override
    public String searchMaxSeq(){
    	return this.issueOBInfoMapper.searchMaxSeq();
    }
    @Override
    public void createUploadIssue(List<Issue> issueList,List<IssueOBInfo> oblist){
    	issueMapper.insertBatch(issueList);
    	
    	insertBatch(oblist);
    	
    }
    @Override
    public List<IssueOBInfoModel> searchUploadInfo(Map<String, Object> map){
    	return this.issueOBInfoMapper.searchUploadInfo(map);
    }
    
    @Override
    public String countUnassignedOBIssueNum(Map<String, Object> map){
    	return this.issueOBInfoMapper.countUnassignedOBIssueNum(map);
    }
    
    @Override
    public List<IssueOBInfo> searchUnassignedOBIssue(Map<String, Object> map){
    	return this.issueOBInfoMapper.searchUnassignedOBIssue(map);
    }
    
    @Override
	public String checkIfExistingOBIssue(Map<String,Object> map){
		return this.issueOBInfoMapper.checkIfExistingOBIssue(map);
	}
}