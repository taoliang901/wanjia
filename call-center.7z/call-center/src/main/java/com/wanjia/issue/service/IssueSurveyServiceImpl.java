package com.wanjia.issue.service;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.issue.bo.IssueSurvey;
import com.wanjia.issue.dao.IssueSurveyMapper;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-8-7 ����9:43, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class IssueSurveyServiceImpl implements IssueSurveyService {
    @Autowired
    private IssueSurveyMapper issueSurveyMapper;

    @Override
    @Transactional(readOnly=true)
    public IssueSurvey findById(String id) {
        return (IssueSurvey)issueSurveyMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueSurvey> findWithPagination(int offset, int count) {
        return (List<IssueSurvey>)issueSurveyMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueSurvey> findAll() {
        return (List<IssueSurvey>)issueSurveyMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueSurvey> findByEntity(IssueSurvey model) {
        return (List<IssueSurvey>)issueSurveyMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueSurvey> findByEntityWithPagination(IssueSurvey model, int offset, int count) {
        return (List<IssueSurvey>)issueSurveyMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueSurvey findOneByEntity(IssueSurvey model) {
        return (IssueSurvey)issueSurveyMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueSurvey> findByProperty(String propertyName, String propertyValue) {
        return (List<IssueSurvey>)issueSurveyMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueSurvey findOneByProperty(String propertyName, String propertyValue) {
        return (IssueSurvey)issueSurveyMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueSurvey> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<IssueSurvey>)issueSurveyMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueSurvey> findByProperties(Map<String, Object> map) {
        return (List<IssueSurvey>)issueSurveyMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(IssueSurvey model) {
        return (long)issueSurveyMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)issueSurveyMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)issueSurveyMapper.countByProperties(map);
    }

    @Override
    public void update(IssueSurvey model) {
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        issueSurveyMapper.update(model);
    }

    @Override
    public void insert(IssueSurvey model) {
//        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        issueSurveyMapper.insert(model);
    }

    @Override
    public void deleteByEntity(IssueSurvey model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        issueSurveyMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.issueSurveyMapper.countAll();
    }

    public void insertBatch(List<IssueSurvey> list) {
        this.issueSurveyMapper.insertBatch(list);
    }

    public void delete(String id) {
        IssueSurvey model = new IssueSurvey();
        model.setDelFlag(SysConstant.DEL_FLAG);
//        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(id);
        this.issueSurveyMapper.update(model);
    }
}