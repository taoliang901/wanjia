package com.wanjia.issue.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.model.EasyUIDataGridModel;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.ht.bo.HtUser;
import com.wanjia.ht.dao.HtUserDao;
import com.wanjia.ht.service.HtUserService;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueProcess;
import com.wanjia.issue.service.IssueOBInfoService;
import com.wanjia.issue.service.IssueProcessService;
import com.wanjia.issue.service.IssueService;
import com.wanjia.knowledge.bo.CcSurvey;
import com.wanjia.knowledge.service.CcSurveyService;
import com.wanjia.utils.StringUtil;

@Controller
public class IssueMgmtController extends BaseController{

	private Logger logger = Logger.getLogger(IssueMgmtController.class);
	
	private final String worksheet_mgmt_page ="worksheet/mgmt"; 
	
	@Autowired
	private IssueService issueService;
	
	@Autowired
	private HtUserService htUserService;
	
	@Autowired
	private IssueProcessService issueProcessService;
	
	@Autowired
	private CcSurveyService ccSurveyService;
	
	@Autowired
	private IssueOBInfoService issueOBInfoService;
	
	
	
	@RequestMapping("worksheet/worksheetMgmt.do")
	public ModelAndView initWorkSheetMgmt(HttpServletRequest request){
		ModelAndView mv = new ModelAndView(worksheet_mgmt_page);
		
		List<Issue> list1 = issueService.searchUnassignedIBList();	
		List<Issue> list2 = issueService.searchUnassignedNormalOBList();
		Map<String,Object> map = new HashMap<String,Object>();
		List<Issue> list3 = issueService.searchUnassignedOTOBList(map);
		
		mv.addObject("num1", list1.size());
		mv.addObject("num2", list2.size());
		mv.addObject("num3", list3.size());
		mv.addObject("queryType", request.getParameter("queryType"));
		return mv;
	}
	
	@RequestMapping("/worksheet/getWorksheetList.do")
	@ResponseBody
	public EasyUIDataGridModel getWorksheetList(HttpServletRequest request){
		EasyUIDataGridModel dg = new EasyUIDataGridModel();

		String pageNumber = request.getParameter("page");
		String pageSize = request.getParameter("rows");
		String queryType = request.getParameter("queryType");
		
		int pageNo = 1;
	 	int pageS= SysConstant.PAGE_SIZE;
	 	if(!StringUtils.isEmpty(pageNumber)){
	 		pageNo = Integer.parseInt(pageNumber);
	 	}
	 	if(!StringUtils.isEmpty(pageSize)){
	 		pageS = Integer.parseInt(pageSize);
	 	}
	 	PageHelper.startPage(pageNo,pageS );//设置分页页号和页码
	 	
	 	List<Issue> list = new ArrayList<Issue>();

	 	if(queryType.equals("icon1")){
	 		list = issueService.searchUnassignedIBList();
		}else if(queryType.equals("icon2")){
			list =  issueService.searchUnassignedNormalOBList();
		}else if(queryType.equals("icon3")){
			Map<String,Object> map = new HashMap<String,Object>();
			if(StringUtils.isNotEmpty(request.getParameter("clinicName"))){
				map.put("clinicName", request.getParameter("clinicName"));
			}
			list =  issueService.searchUnassignedOTOBList(map);
		}
		
		PageInfo page = new PageInfo(list);
	 	dg.setTotal(page.getTotal());
	 	dg.setRows(list);
		return dg;
	}
	
	@RequestMapping("/worksheet/getZXList.do")
	@ResponseBody
	public List<HtUser> getDeptLeaders(HttpServletRequest request){
		
		List<String> list = new ArrayList<String>();
		list.add(SysConstant.ZX_ROLE);
		list.add(SysConstant.ZX_TL_ROLE);
		List<HtUser> result = htUserService.getUserListByRole(list);
		return result;
	}
	
	@RequestMapping("/worksheet/getOBZXList.do")
	@ResponseBody
	public List<HtUser> getOBZZList(HttpServletRequest request){
		
		List<String> list = new ArrayList<String>();
		list.add(SysConstant.ZX_ROLE);
		list.add(SysConstant.ZX_TL_ROLE);
		list.add(SysConstant.ZX_OB_ROLE);
		List<HtUser> result = htUserService.getUserListByRole(list);
		return result;
	}
	
	@RequestMapping("/worksheet/assignIssue.do")
	@ResponseBody
	public JsonResponse<Map<String,Object>> assignIssue(HttpServletRequest request,HttpServletResponse reponse){
		//构造返回值
		JsonResponse<Map<String,Object>> jr = new JsonResponse<Map<String,Object>>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		//获参
		String asignee = request.getParameter("asignee");
		String[] issueId = StringUtil.splitString(request.getParameter("issueId"),",");
		
		//更新工单处理表
		issueProcessService.createAsignee(asignee,issueId,getCurrentUser(request));
		jr.setStatus(JsonResponse.Status.SUCCESS);
		//更新工单数量
	
		List<Issue> list1 = issueService.searchUnassignedIBList();	
		List<Issue> list2 = issueService.searchUnassignedNormalOBList();
		Map<String,Object> paramMap = new HashMap<String,Object>();
		List<Issue> list3 = issueService.searchUnassignedOTOBList(paramMap);
		
		resultMap.put("num1", list1.size());
		resultMap.put("num2", list2.size());
		resultMap.put("num3", list3.size());
		
		jr.setResult(resultMap);
		return jr;
	}
	
	@RequestMapping("/worksheet/assignOBIssue.do")
	@ResponseBody
	public JsonResponse<Map<String,Object>> assignOBIssue(HttpServletRequest request,HttpServletResponse reponse){
		//构造返回值
		JsonResponse<Map<String,Object>> jr = new JsonResponse<Map<String,Object>>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		//获参
		String asignee = request.getParameter("asignee");
		String[] issueId = StringUtil.splitString(request.getParameter("issueId"),",");
		
		//更新工单处理表
		issueProcessService.createOBAsignee(asignee,issueId,getCurrentUser(request));
		jr.setStatus(JsonResponse.Status.SUCCESS);
		
		//更新工单数量
		List<Issue> list1 = issueService.searchUnassignedIBList();	
		List<Issue> list2 = issueService.searchUnassignedNormalOBList();
		Map<String,Object> paramMap = new HashMap<String,Object>();
		List<Issue> list3 = issueService.searchUnassignedOTOBList(paramMap);
		
		resultMap.put("num1", list1.size());
		resultMap.put("num2", list2.size());
		resultMap.put("num3", list3.size());
		
		jr.setResult(resultMap);
		return jr;
	}
	
	
	@RequestMapping("/worksheet/assignOBAsigneeRandom.do")
	@ResponseBody
	public JsonResponse<Map<String,Object>> assignOBAsigneeRandom(HttpServletRequest request,HttpServletResponse reponse){
		//构造返回值
		JsonResponse<Map<String,Object>> jr = new JsonResponse<Map<String,Object>>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		//获参
		String surveyId = request.getParameter("surveyId");
		String obAsignee = request.getParameter("obAsignee");
		String assignOBNum = request.getParameter("assignOBNum");
		
		//存入工单处理表
		issueProcessService.createOBAsigneeRandom(surveyId,obAsignee,assignOBNum,getCurrentUser(request));
		
		
		List<Issue> list1 = issueService.searchUnassignedIBList();	
		List<Issue> list2 = issueService.searchUnassignedNormalOBList();
		Map<String,Object> paramMap = new HashMap<String,Object>();
		List<Issue> list3 = issueService.searchUnassignedOTOBList(paramMap);
		
		resultMap.put("num1", list1.size());
		resultMap.put("num2", list2.size());
		resultMap.put("num3", list3.size());
		jr.setResult(resultMap);
		jr.setStatus(JsonResponse.Status.SUCCESS);
		return jr;
	}	
	
	
	
	@RequestMapping("/worksheet/getSurveyList.do")
	@ResponseBody
	public List<CcSurvey> getSurveyList(HttpServletRequest request){
	
		Map<String , Object> map = new HashMap<String , Object>();
		map.put("surveyStatus", "1");
		map.put("delFlag", SysConstant.NOT_DEL_FLAG);
		List<CcSurvey> list = ccSurveyService.findByProperties(map);
		
		return list;
	}
	
	@RequestMapping("/worksheet/getSurveyIssueNum.do")
	@ResponseBody
	public JsonResponse<String> getSurveyIssueNum(HttpServletRequest reqest){
		JsonResponse<String> jason = new JsonResponse<String>();
		String num = "0";
		String surveyId = reqest.getParameter("surveyId");
		if(StringUtils.isNotEmpty(surveyId)){
			Map<String , Object> map = new HashMap<String , Object>();
			map.put("surveyId", surveyId);
			num = issueOBInfoService.countUnassignedOBIssueNum(map);
		}
		
		logger.info("未分配的工单数" + num);
		jason.setResult(num);
		jason.setStatus(JsonResponse.Status.SUCCESS);
		return jason;
	}
	
	
	
	@RequestMapping("/worksheet/refreshNum.do")
	@ResponseBody
	public JsonResponse<Map<String,Object>> refreshNum(){
		JsonResponse<Map<String,Object>> jason = new JsonResponse<Map<String,Object>>();
		Map<String,Object> map = new HashMap<String,Object>();	
		
		List<Issue> list1 = issueService.searchUnassignedIBList();	
		List<Issue> list2 = issueService.searchUnassignedNormalOBList();
		Map<String,Object> paramMap = new HashMap<String,Object>();
		List<Issue> list3 = issueService.searchUnassignedOTOBList(paramMap);
		
		map.put("num1", list1.size());
		map.put("num2", list2.size());
		map.put("num3", list3.size());
		jason.setResult(map);
		jason.setStatus(JsonResponse.Status.SUCCESS);
		return jason;
	}
}
