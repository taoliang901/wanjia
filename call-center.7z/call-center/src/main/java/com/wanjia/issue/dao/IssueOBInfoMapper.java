package com.wanjia.issue.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseDao;
import com.wanjia.issue.bo.IssueOBInfo;
import com.wanjia.issue.bo.IssueOBInfoModel;

public interface IssueOBInfoMapper extends IBaseDao {
	
	public String searchMaxSeq();

	public List<IssueOBInfoModel> searchUploadInfo(Map<String, Object> map);
	
	public String countUnassignedOBIssueNum(Map<String, Object> map);
	
	public List<IssueOBInfo> searchUnassignedOBIssue(Map<String, Object> map);
	
	public String checkIfExistingOBIssue(Map<String,Object> map);
}