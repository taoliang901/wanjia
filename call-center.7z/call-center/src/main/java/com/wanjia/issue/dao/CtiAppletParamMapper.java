package com.wanjia.issue.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseDao;
import com.wanjia.issue.bo.CtiAppletParam;

public interface CtiAppletParamMapper extends IBaseDao {
	
	List<CtiAppletParam> findByCtiEmployee(Map<String, Object> map);
	
	List<CtiAppletParam> checkLoginAccount(Map<String, Object> map);
}