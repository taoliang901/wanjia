package com.wanjia.issue.service;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueOBInfo;
import com.wanjia.issue.bo.IssueProcess;
import com.wanjia.issue.bo.IssueProcessView;
import com.wanjia.issue.dao.IssueOBInfoMapper;
import com.wanjia.issue.dao.IssueProcessMapper;
import com.wanjia.knowledge.bo.CcSurvey;
import com.wanjia.knowledge.dao.CcSurveyMapper;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-7-14 下午3:00, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class IssueProcessServiceImpl implements IssueProcessService {
	
	@Autowired
	private IssueService issueService;
	
	@Autowired
    private IssueProcessMapper issueProcessMapper;

	@Autowired
	private IssueOBInfoMapper issueOBInfoMapper;
	
	@Autowired
	private CcSurveyMapper ccSurveyMapper;
	
    @Override
    @Transactional(readOnly=true)
    public IssueProcess findById(String id) {
        return (IssueProcess)issueProcessMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueProcess> findWithPagination(int offset, int count) {
        return (List<IssueProcess>)issueProcessMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueProcess> findAll() {
        return (List<IssueProcess>)issueProcessMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueProcess> findByEntity(IssueProcess model) {
        return (List<IssueProcess>)issueProcessMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueProcess> findByEntityWithPagination(IssueProcess model, int offset, int count) {
        return (List<IssueProcess>)issueProcessMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueProcess findOneByEntity(IssueProcess model) {
        return (IssueProcess)issueProcessMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueProcess> findByProperty(String propertyName, String propertyValue) {
        return (List<IssueProcess>)issueProcessMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueProcess findOneByProperty(String propertyName, String propertyValue) {
        return (IssueProcess)issueProcessMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueProcess> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<IssueProcess>)issueProcessMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueProcess> findByProperties(Map<String, Object> map) {
        return (List<IssueProcess>)issueProcessMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(IssueProcess model) {
        return (long)issueProcessMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)issueProcessMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)issueProcessMapper.countByProperties(map);
    }

    @Override
    public void update(IssueProcess model) {
     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        issueProcessMapper.update(model);
    }

    @Override
    public void insert(IssueProcess model) {
      //  model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        issueProcessMapper.insert(model);
    }

    @Override
    public void deleteByEntity(IssueProcess model) {
        model.setDelFlag(SysConstant.DEL_FLAG);
     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        issueProcessMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.issueProcessMapper.countAll();
    }

    public void insertBatch(List<IssueProcess> list) {
        this.issueProcessMapper.insertBatch(list);
    }

    public void delete(Long id) {
        IssueProcess model = new IssueProcess();
        model.setDelFlag(SysConstant.DEL_FLAG);
      //  model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.issueProcessMapper.update(model);
    }

	@Override
	public void delete(String id) {
		
		IssueProcess model = new IssueProcess();
        model.setDelFlag(SysConstant.DEL_FLAG);
       // model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.issueProcessMapper.update(model);
	}
	

	@Override
	public void createAsignee(String asignee,String[] issueId,String createUser){
		for(int k =0; k < issueId.length ; k++){
			IssueProcess issueProcess = searchProcessByIssueID(issueId[k]);
			issueProcess.setAssignee(asignee);
			issueProcess.setAssignDate(new Date());
			issueProcess.setModifyUser(createUser);
			update(issueProcess);
			//更新工单表中handle处理人字段
			Issue issue = issueService.findById(issueId[k]);
			issue.setHandler(asignee);
			issue.setModifyUser(createUser);
			issueService.update(issue);
		}
	}
	

	
	public IssueProcess searchProcessByIssueID(String issueID){
		return this.issueProcessMapper.searchProcessByIssueID(issueID);
	}
	
	@Override
	public void createOBAsignee(String asignee,String[] issueId,String createUser){
		for(int k =0; k < issueId.length ; k++){

			IssueProcess issueProcess = new IssueProcess();
			issueProcess.setId(UUID.randomUUID().toString());
			issueProcess.setIssueId(issueId[k]);
			issueProcess.setAssignee(asignee);
			issueProcess.setStatus("0");
			issueProcess.setAssignDate(new Date());
			issueProcess.setCreateDate(new Date());
			issueProcess.setCreateUser(createUser);
			issueProcess.setDelFlag(SysConstant.NOT_DEL_FLAG);
			issueProcessMapper.insert(issueProcess);
		
			//更新工单表中handle处理人字段
			Issue issue = issueService.findById(issueId[k]);
			issue.setHandler(asignee);
			issue.setModifyUser(createUser);
			issueService.update(issue);
		}

	}

	@Override
	public void createOBAsigneeRandom(String surveyId,String obAsignee,String assignOBNum,String currentUser){
		
		CcSurvey ccSurvey = ccSurveyMapper.findById(surveyId);
		if(ccSurvey != null){
			Map<String,Object> param = new HashMap<String,Object>();
			param.put("surveyId", surveyId);
			List<IssueOBInfo> obIssuelist = issueOBInfoMapper.searchUnassignedOBIssue(param);
			
			int num = Integer.valueOf(assignOBNum);
			//此错误情况，页面已控制数目不能超过未分配数目。
			if(num > obIssuelist.size()){	
				num = obIssuelist.size();
			}
			for(int k =0; k < num ; k++){
				IssueOBInfo model = obIssuelist.get(k);
				IssueProcess issueProcess = new IssueProcess();
				issueProcess.setId(UUID.randomUUID().toString());
				issueProcess.setIssueId(model.getIssueId());
				issueProcess.setAssignee(obAsignee);
				issueProcess.setStatus("0");
				issueProcess.setAssignDate(new Date());
				issueProcess.setCreateDate(new Date());
				issueProcess.setCreateUser(currentUser);
				issueProcess.setDelFlag(SysConstant.NOT_DEL_FLAG);
				issueProcessMapper.insert(issueProcess);
			
				//更新工单表中handle处理人字段
				Issue issue = issueService.findById(model.getIssueId());
				issue.setIssueTopic(ccSurvey.getSurveyName());
				issue.setHandler(obAsignee);
				issue.setModifyUser(currentUser);
				issueService.update(issue);
			}
		}
		
	}

	@Override
	public List<IssueProcessView> queryIssueOperateLog(Map<String, Object> map) {
		return issueProcessMapper.queryIssueOperateLog(map);
	}
}