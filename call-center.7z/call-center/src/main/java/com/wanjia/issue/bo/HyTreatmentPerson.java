package com.wanjia.issue.bo;

import java.io.Serializable;
import java.util.Date;

public class HyTreatmentPerson implements Serializable {
    private static final long serialVersionUID = 1L;

    private String visitId;

    private Long memberId;

    private String visitName;

    private String visitSex;

    private String visitBrithday;

    private String visitIdCardTypeCode;

    private String visitIdCardCode;

    private String visitMobile;

    private String address;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    private String delFlag;

    private String isDefault;

    public String getVisitId() {
        return visitId;
    }

    public void setVisitId(String visitId) {
        this.visitId = visitId;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public String getVisitName() {
        return visitName;
    }

    public void setVisitName(String visitName) {
        this.visitName = visitName;
    }

    public String getVisitSex() {
        return visitSex;
    }

    public void setVisitSex(String visitSex) {
        this.visitSex = visitSex;
    }

    public String getVisitBrithday() {
        return visitBrithday;
    }

    public void setVisitBrithday(String visitBrithday) {
        this.visitBrithday = visitBrithday;
    }

    public String getVisitIdCardTypeCode() {
        return visitIdCardTypeCode;
    }

    public void setVisitIdCardTypeCode(String visitIdCardTypeCode) {
        this.visitIdCardTypeCode = visitIdCardTypeCode;
    }

    public String getVisitIdCardCode() {
        return visitIdCardCode;
    }

    public void setVisitIdCardCode(String visitIdCardCode) {
        this.visitIdCardCode = visitIdCardCode;
    }

    public String getVisitMobile() {
        return visitMobile;
    }

    public void setVisitMobile(String visitMobile) {
        this.visitMobile = visitMobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        HyTreatmentPerson other = (HyTreatmentPerson) that;
        return (this.getVisitId() == null ? other.getVisitId() == null : this.getVisitId().equals(other.getVisitId()))
            && (this.getMemberId() == null ? other.getMemberId() == null : this.getMemberId().equals(other.getMemberId()))
            && (this.getVisitName() == null ? other.getVisitName() == null : this.getVisitName().equals(other.getVisitName()))
            && (this.getVisitSex() == null ? other.getVisitSex() == null : this.getVisitSex().equals(other.getVisitSex()))
            && (this.getVisitBrithday() == null ? other.getVisitBrithday() == null : this.getVisitBrithday().equals(other.getVisitBrithday()))
            && (this.getVisitIdCardTypeCode() == null ? other.getVisitIdCardTypeCode() == null : this.getVisitIdCardTypeCode().equals(other.getVisitIdCardTypeCode()))
            && (this.getVisitIdCardCode() == null ? other.getVisitIdCardCode() == null : this.getVisitIdCardCode().equals(other.getVisitIdCardCode()))
            && (this.getVisitMobile() == null ? other.getVisitMobile() == null : this.getVisitMobile().equals(other.getVisitMobile()))
            && (this.getAddress() == null ? other.getAddress() == null : this.getAddress().equals(other.getAddress()))
            && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser()))
            && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate()))
            && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser()))
            && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getIsDefault() == null ? other.getIsDefault() == null : this.getIsDefault().equals(other.getIsDefault()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getVisitId() == null) ? 0 : getVisitId().hashCode());
        result = prime * result + ((getMemberId() == null) ? 0 : getMemberId().hashCode());
        result = prime * result + ((getVisitName() == null) ? 0 : getVisitName().hashCode());
        result = prime * result + ((getVisitSex() == null) ? 0 : getVisitSex().hashCode());
        result = prime * result + ((getVisitBrithday() == null) ? 0 : getVisitBrithday().hashCode());
        result = prime * result + ((getVisitIdCardTypeCode() == null) ? 0 : getVisitIdCardTypeCode().hashCode());
        result = prime * result + ((getVisitIdCardCode() == null) ? 0 : getVisitIdCardCode().hashCode());
        result = prime * result + ((getVisitMobile() == null) ? 0 : getVisitMobile().hashCode());
        result = prime * result + ((getAddress() == null) ? 0 : getAddress().hashCode());
        result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
        result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
        result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
        result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getIsDefault() == null) ? 0 : getIsDefault().hashCode());
        return result;
    }
}