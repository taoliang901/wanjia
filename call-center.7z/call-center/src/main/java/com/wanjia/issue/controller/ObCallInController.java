package com.wanjia.issue.controller;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.web.BaseController;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.ht.bo.SysAreaCity;
import com.wanjia.ht.bo.SysDict;
import com.wanjia.ht.service.SysAreaCityService;
import com.wanjia.issue.bo.CcIssueType;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueProcessView;
import com.wanjia.issue.controller.CallInController.DictComparator;
import com.wanjia.issue.enums.CallType;
import com.wanjia.issue.enums.IsConvey;
import com.wanjia.issue.enums.IssueStatus;
import com.wanjia.issue.service.CcIssueTypeService;
import com.wanjia.issue.service.IssueProcessService;
import com.wanjia.issue.service.IssueService;

@Controller
@RequestMapping("/issue/")
public class ObCallInController extends BaseController{

	private Logger logger = Logger.getLogger(ObCallInController.class);
	
	@Autowired
	private IssueService issueService;
	@Autowired
	private SysAreaCityService sysAreaCityService;
	@Autowired
	private CcIssueTypeService ccIssueTypeService;
	@Autowired
	private IssueProcessService issueProcessService;
	
	/** 初始化页面url */
	private final String init_page_url = "issue/obCallIn";
	
	/** 数据字典code数组 */
	private static String[] dicts = {"CC_CLIENT_TYPE","CC_ISSUE_TYPE","CC_PROMISE_DAYS"};
	
	/**
	 * 呼出_呼入解决页面初始化
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("obCallIn.do")
	public ModelAndView initObCallIn(HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		
		/** 获取所有省 */
		Map<String,Object> map = new HashMap<String,Object>(2);
		map.put("parentId", "0");
		map.put("delFlag", SysConstant.NOT_DEL_FLAG);
		List<SysAreaCity> provinces = sysAreaCityService.findByProperties(map);
		if(provinces !=null && !provinces.isEmpty()){
			mv.addObject("provinces",provinces);
		}
		
		/** 校验事件id */
		String issueId = request.getParameter("issueId");
		if(StringUtils.isNotBlank(issueId)){
			Issue issue = issueService.findById(issueId);
			if(issue != null){
				mv.addObject("issue",issue);
				String provinceCode = issue.getProvincecode();
				String cityCode = issue.getCitycode();
				
				/** 获取所有市或区 */
				SysAreaCity sac = new SysAreaCity();
				sac.setParentId(provinceCode);
				sac.setDelFlag(SysConstant.NOT_DEL_FLAG);
				List<SysAreaCity> cities = sysAreaCityService.findByEntity(sac);
				if(cities !=null && !cities.isEmpty()){
					mv.addObject("cities",cities);
				}
				
				sac.setParentId(cityCode);
				List<SysAreaCity> districts = sysAreaCityService.findByEntity(sac);
				if(districts !=null && !districts.isEmpty()){
					mv.addObject("districts",districts);
				}
				
				/** 获取事件子类型 */
				CcIssueType model = new CcIssueType();
				model.setParentCode(issue.getIssueType());
				model.setDelFlag(SysConstant.NOT_DEL_FLAG);
				List<CcIssueType> ccIssueTypeList = ccIssueTypeService.findByEntity(model);
				mv.addObject("issueTypeSub",ccIssueTypeList);
			}
		}
		
		/** 获取相关数据字典：事件类型和用户类型 */
		Map<String,List<SysDict>> dictMap = issueService.getDicts(dicts);
		if(dictMap !=null && !dictMap.isEmpty()){
			for(Entry<String,List<SysDict>> dict : dictMap.entrySet()){
				mv.addObject(dict.getKey(),dict.getValue());
			}
			
			List<SysDict> list = dictMap.get("CC_PROMISE_DAYS");
			if(list!=null && !list.isEmpty()){
				Collections.sort(list, new DictComparator()); 
			}
			mv.addObject("CC_PROMISE_DAYS",list);
		}

		/** 打开软电话开关 */
		mv.addObject("ctiSwitch",true);
		
		/** 呼入页面url */
		mv.setViewName(init_page_url);	
		return mv;
	}
	
	/**
	 * 提交坐席工单事件
	 * @param request
	 * @param issue 参数对象
	 * @return
	 */
	@RequestMapping("saveIssue.do")
	@ResponseBody
	public JsonResponse<Void> saveIssue(HttpServletRequest request,Issue issue){
		JsonResponse<Void> response = new JsonResponse<Void>();
		
		/** 校验联系方式 */
		if(!StringUtils.isNotBlank(issue.getPhone())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("联系方式为空！");
			return response;
		}
		
		/** 校验用户类型 */
		if(!StringUtils.isNotBlank(issue.getClientTypeId())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("用户类型为空！");
			return response;
		}
		
		/** 校验地区 */
		if(!StringUtils.isNotBlank(issue.getProvincecode())
				||!StringUtils.isNotBlank(issue.getCitycode())
				||!StringUtils.isNotBlank(issue.getDistrictcode())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("省市区选择不完全！");
			return response;
		}
		
		/** 校验事件类型 */
		if(!StringUtils.isNotBlank(issue.getIssueType())
				||!StringUtils.isNotBlank(issue.getIssueTypeSub())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("事件类型输入不完全！");
			return response;
		}
		
		/** 校验事件标题 */
		if(!StringUtils.isNotBlank(issue.getIssueTopic())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("事件标题为空！");
			return response;
		}
		
		/** 校验事件描述 */
		if(!StringUtils.isNotBlank(issue.getIssueDesc())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("事件描述为空！");
			return response;
		}
		
		/** 校验解决方案 */
		if(IssueStatus.SOLVED.getValue().equals(issue.getStatus())
				&&!StringUtils.isNotBlank(issue.getIssueSolution())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("解决方案为空！");
			return response;
		}
		
		/** 当状态为已解决时，是否流转都为不流转 */
		if(IssueStatus.SOLVED.getValue().equals(issue.getStatus())){
			issue.setIsConvey(IsConvey.UNTRANSFER.getValue());
		}
		
		/** 获取当前用户和时间 */
		String userCode = getCurrentUser(request);
		Date date = new Date();
		
		/** 更新记录 */
		issue.setModifyDate(date);
		issue.setModifyUser(userCode);
		issue.setDelFlag(SysConstant.NOT_DEL_FLAG);
		issue.setHandler(userCode);
		issue.setCallTime(date);
		
		try{
			issueService.updateCallinIssue(issue);
		}catch(Exception e){
			logger.error("呼出_呼入解决页面提交事件异常！提交参数为：" + ToStringBuilder.reflectionToString(issue, ToStringStyle.MULTI_LINE_STYLE));
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("提交异常！");
			return response;
		}
		
		response.setStatus(JsonResponse.Status.SUCCESS);
		return response;
	}
	
	/**
	 * 查询工单操作记录
	 * @param issueId
	 * @return
	 */
	@RequestMapping("queryIssueOperateLog.do")
	@ResponseBody
	public JsonResponse<List<IssueProcessView>> queryIssueProcess(String issueId){ 
		JsonResponse<List<IssueProcessView>> response = new JsonResponse<List<IssueProcessView>>();
		
		/** 校验事件id*/
		if(!StringUtils.isNotBlank(issueId)){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("为获取当前事件id！");
			return response;
		}
		
		try{
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("issueId", issueId);
			map.put("delFlag", SysConstant.NOT_DEL_FLAG);
			List<IssueProcessView> processList = issueProcessService.queryIssueOperateLog(map);
			if(processList!=null && !processList.isEmpty()){
				for(IssueProcessView process : processList){
					String status = process.getStatus();
					String isConvey = process.getIsConvey();
					String callType = process.getCallType();
					if(IssueStatus.SOLVED.getValue().equals(status)){
						process.setStatusName(IssueStatus.SOLVED.getDesc());
						Issue issue = issueService.findById(issueId);
						if(issue!=null&&SysConstant.NOT_DEL_FLAG.equals(issue.getDelFlag())){
							process.setRemark(issue.getIssueSolution());
						}
					} else if (IsConvey.TRANSFER.getValue().equals(isConvey)
							&& IssueStatus.UNSOLVED.getValue().equals(status)
							&& CallType.IN.getValue().equals(callType)) {
						process.setStatusName(IsConvey.TRANSFER.getDesc());
					}else{
						//此处默认为流转，待以后有其他操作方式进行拓展
						process.setStatusName(IsConvey.TRANSFER.getDesc());
					}
					
					Date date = process.getCreateDate();
					if(date !=null){
						SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						String callTime = sdformat.format(date);
						process.setCallTime(callTime);
					}	
				}
			}
			response.setResult(processList);
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			response.setStatus(JsonResponse.Status.ERROR);
			logger.error("根据issueId["+issueId+"]查询工单流转表异常！", e);
		}
		
		return response;
	}
}
