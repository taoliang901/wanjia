package com.wanjia.issue.service;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseService;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.ht.bo.SysDict;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.bo.IssueModel;

/**
 * This element is automatically generated on 16-7-14 下午2:39, do not modify. <br>
 * Service interface
 */
public interface IssueService extends IBaseService<Issue, String> {
	
	/**
	 * 查询地区
	 * @param id
	 * @return
	 */
	Area getArea(String id);
	
	/**
	 * 获取数据字典
	 * @param dictCodes 需要查询的字典code数组
	 * @return
	 */
	Map<String,List<SysDict>> getDicts(String[] dictCodes);
	
	/**
	 * 查询用户最近事件
	 * @param map
	 * @return
	 */
	List<Issue> queryLastIssue(Map<String,Object> map);
	
	/**
	 * 创建工单
	 * @param issue
	 */
	void createIssue(Issue issue);
	
	/**
	 * 更新工单（用于呼出呼入解决）
	 * @param issue
	 */
	void updateCallinIssue(Issue issue);
	
	/**
	 * 更新工单（用于申请流转的功能）
	 * @param issue
	 */
	void updateIssue(Issue issue);
	
	/**
	 * 查询所有未指派呼入工单
	 * @param issue
	 */
	public List<Issue> searchUnassignedIBList();
	
	/**
	 * 查询所有一般未指派呼出工单
	 * @param issue
	 */
	public List<Issue> searchUnassignedNormalOBList();
	
	
	/**
	 * 查询所有预约确认超时未指派呼出工单
	 * @param issue
	 */
	public List<Issue> searchUnassignedOTOBList(Map<String,Object> map);
	
	/**
	 * 查询我的预约超时处理中和一般呼出处理中的工单
	 * @param map
	 * @return
	 */
	public List<IssueModel> searchAssignedOBList(Map<String,Object> map);
	
	List<Issue> searchMyIssueList(Map<String,Object> map);
	
	
	
	public List<Issue> getIBList(Map<String,Object> map);
	
	public List<Issue> getNormalOBList(Map<String,Object> map);
	
	public List<Issue> getOTOBList(Map<String,Object> map);
	
	/**
	 * 查询未被指派的预约超时工单
	 * @param map
	 * @return
	 */
	public List<IssueModel> queryAppointmentIssue(Map<String,Object> map);
	
	/**
	 * 领取工单
	 * @param ids
	 * @param userCode
	 * @return
	 */
	public Integer updateReceiveIssues(String[] ids,String userCode);
	
	/**
	 * 查询库存
	 * @param cardId
	 * @return
	 */
	Map<String,Object> findKucun(String cardId);
}