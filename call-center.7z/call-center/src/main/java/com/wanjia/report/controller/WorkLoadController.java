package com.wanjia.report.controller;

import java.net.URLDecoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.utils.ExcelUtil;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.base.model.EasyUIDataGridModel;
import com.wanjia.base.web.BaseController;
import com.wanjia.issue.bo.Function;
import com.wanjia.issue.bo.Issue;
import com.wanjia.issue.service.IssueProcessService;
import com.wanjia.issue.service.IssueService;


@Controller
public class WorkLoadController extends BaseController{

	private Logger logger = Logger.getLogger(WorkLoadController.class);
	
	private final String workload_page ="worksheet/workload"; 
	
	@Autowired
	private IssueService issueService;

	
	@Autowired
	private IssueProcessService issueProcessService;
	
	
	@RequestMapping("ccreport/workload.do")
	public ModelAndView initWorkSheetMgmt(HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		try{
			String queryType = request.getParameter("queryType");
			mv.setViewName(workload_page);
			if(queryType==null){
				queryType = "1";
			}
			mv.addObject("queryType",queryType);
			
			mv.addObject("issueType",request.getParameter("issueType"));
			mv.addObject("issueStatus",request.getParameter("issueStatus"));
			mv.addObject("asignee",request.getParameter("asignee"));
			mv.addObject("beginDate",request.getParameter("beginDate"));
			mv.addObject("endDate",request.getParameter("endDate"));
			mv.addObject("phone",request.getParameter("phone"));
			
			String clinicName= request.getParameter("clinicName");
			if(StringUtils.isNotEmpty(clinicName)){
				clinicName = URLDecoder.decode(clinicName,"UTF-8");
			}	
			mv.addObject("clinicName",clinicName);
			
			String patientVisitName= request.getParameter("patientVisitName");
			if(StringUtils.isNotEmpty(patientVisitName)){
				patientVisitName = URLDecoder.decode(patientVisitName,"UTF-8");
			}	
			mv.addObject("patientVisitName",patientVisitName);
		}catch(Exception e){
			e.printStackTrace();
		}
	
		return mv;
	}
	
	@RequestMapping("ccreport/getWorkloadList.do")
	@ResponseBody
	public EasyUIDataGridModel getWorkloadList(HttpServletRequest request){
		EasyUIDataGridModel dg = new EasyUIDataGridModel();

		String pageNumber = request.getParameter("page");
		String pageSize = request.getParameter("rows");
		String beginDate = request.getParameter("beginDate");
		String endDate = request.getParameter("endDate");
		String phone = request.getParameter("phone");
		try{
			Map<String , Object> map = new HashMap<String , Object>();

			if(StringUtils.isNotEmpty(request.getParameter("issueType"))){
				map.put("issueType",request.getParameter("issueType"));
			}	
			if(StringUtils.isNotEmpty(request.getParameter("issueStatus"))){
				map.put("issueStatus",request.getParameter("issueStatus"));
			}
			if(StringUtils.isNotEmpty(request.getParameter("asignee"))){
				map.put("asignee",request.getParameter("asignee"));
			}	
			String s_clinicName = request.getParameter("clinicName");
			if(StringUtils.isNotEmpty(s_clinicName)){
				s_clinicName = URLDecoder.decode(s_clinicName,"UTF-8");
				map.put("clinicName",s_clinicName);
			}	
			String patientVisitName = request.getParameter("patientVisitName");
			if(StringUtils.isNotEmpty(patientVisitName)){
				patientVisitName = URLDecoder.decode(patientVisitName,"UTF-8");
				map.put("patientVisitName",patientVisitName);
			}	
			if(StringUtils.isNotEmpty(phone)){
				map.put("phone", phone);
			}
			
			if(StringUtils.isNotEmpty(beginDate)){
				Date beginDates = new SimpleDateFormat("yyyy-MM-dd").parse(beginDate);
				map.put("beginDate", beginDates);
			}
			if(StringUtils.isNotEmpty(endDate)){
				Date endDates = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
				map.put("endDate", endDates);
			}
			
			int pageNo = 1;
		 	int pageS= SysConstant.PAGE_SIZE;
		 	if(!StringUtils.isEmpty(pageNumber)){
		 		pageNo = Integer.parseInt(pageNumber);
		 	}
		 	if(!StringUtils.isEmpty(pageSize)){
		 		pageS = Integer.parseInt(pageSize);
		 	}
		 	PageHelper.startPage(pageNo,pageS );//设置分页页号和页码
		 	List<Issue> list = new ArrayList<Issue>();
		 	if(request.getParameter("queryType").equals("1")){
		 		list = issueService.getIBList(map);
		 	}else if(request.getParameter("queryType").equals("2")){
		 		list = issueService.getNormalOBList(map);
		 	}else if(request.getParameter("queryType").equals("3")){
		 		list = issueService.getOTOBList(map);
		 	}
			
			PageInfo page = new PageInfo(list);
		 	dg.setTotal(page.getTotal());
		 	dg.setRows(list);
		}catch(Exception e){
			e.printStackTrace();
		}
		return dg;
	}
	
	@RequestMapping("/ccreport/exportWorkloadReport.do")
	@Function("excel文件批量导出")
	public void export(HttpServletRequest request, HttpServletResponse response) {
		try {
			String beginDate = request.getParameter("begindate");
			String endDate = request.getParameter("enddate");

			
			Map<String , Object> map = new HashMap<String , Object>();
			if(StringUtils.isNotEmpty(request.getParameter("issueType"))){
				map.put("issueType",request.getParameter("issueType"));
			}	
			if(StringUtils.isNotEmpty(request.getParameter("issueStatus"))){
				map.put("issueStatus",request.getParameter("issueStatus"));
			}
			if(StringUtils.isNotEmpty(request.getParameter("asignee"))){
				map.put("asignee",request.getParameter("asignee"));
			}	
			if(StringUtils.isNotEmpty(request.getParameter("clinicName"))){
				map.put("clinicName",request.getParameter("clinicName"));
			}	
			if(StringUtils.isNotEmpty(request.getParameter("patientVisitName"))){
				map.put("patientVisitName",request.getParameter("patientVisitName"));
			}	
			if(StringUtils.isNotEmpty(beginDate)){
				Date beginDates = new SimpleDateFormat("yyyy-MM-dd").parse(beginDate);
				map.put("beginDate", beginDates);
			}
			if(StringUtils.isNotEmpty(endDate)){
				Date endDates = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
				map.put("endDate", endDates);
			}
			
			Timestamp ts = new Timestamp(System.currentTimeMillis());
			String fileName = ts.toString().replace(" ", "").replace("-", "").replace(":", "").replace(".", "") + ".xls";
			// 第一步，创建一个webbook，对应一个Excel文件
			HSSFWorkbook wb = new HSSFWorkbook();
			
		 	if(request.getParameter("queryType").equals("1")){
		 	//	list = issueService.getIBList(map);
		 		generateIBIssueTemplate(map,wb);
		 	}else if(request.getParameter("queryType").equals("2")){
		 		//list = issueService.getNormalOBList(map);
		 		generateNoramlOBIssueTemplate(map,wb);
		 	}else if(request.getParameter("queryType").equals("3")){
		 	//	list = issueService.getOTOBList(map);
		 		generateOTOBIssueTemplate(map,wb);
		 	}
		 	
	
			String encodedfileName = ExcelUtil.encodeFileNameForDownload(request, fileName);
			response.setContentType("application/ms-excel");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-Control", "max-age=0");
			response.setHeader("Content-Disposition", "attachment;filename=" + encodedfileName);
			wb.write(response.getOutputStream());
			
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("export error!!" + e.getMessage());
		}
	}

	

	private String getIssueStatus(String status) {
		if ("0".equals(status)) {
			return "未解决";
		} else if("1".equals(status)){
			return "已解决";
		}else if("2".equals(status)){
			return "解决中";
		}else if("3".equals(status)){
			return "已关闭";
		}
		return "";
	}
	
	private String getConveyStatus(String isConvey) {
		if ("0".equals(isConvey)) {
			return "不流转";
		} else if("1".equals(isConvey)){
			return "流转";
		}
		return "";
	}
	private String getIssueType(String type) {
		if ("01".equals(type)) {
			return "咨询查询";
		} else if("02".equals(type)){
			return "投诉";
		}else if("03".equals(type)){
			return "一般反馈";
		}
		return "";
	}
	
	private String getApptStatus(String status) {
		if ("0".equals(status)) {
			return "已取消";
		} else if("1".equals(status)){
			return "待确认预约";
		}else if("2".equals(status)){
			return "待就诊";
		}else if("3".equals(status)){
			return "已就诊";
		}else if("4".equals(status)){
			return "已评价";
		}else if("5".equals(status)){
			return "已回复";
		}else if("8".equals(status)){
			return "已过期";
		}else if("9".equals(status)){
			return "已爽约";
		}
		return "";
	}
	
	private void generateIBIssueTemplate(Map<String , Object> map,HSSFWorkbook wb){
		List<Issue> list = issueService.getIBList(map);

		if (CollectionUtils.isNotEmpty(list)) {
			logger.info("the num of exportExcel size is :" + list.size());
			// 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
			HSSFSheet sheet = wb.createSheet("工单记录");
			// 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
			HSSFRow row = sheet.createRow((int) 0);
			// 第四步，创建单元格，并设置值表头 设置表头居中
			HSSFCellStyle style = wb.createCellStyle();
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式
			HSSFCell cell = row.createCell((short) 0);
			//
			
			// 呼入时间
			cell.setCellValue("呼入时间");
			cell.setCellStyle(style);
			cell = row.createCell((short) 1);
			
			cell.setCellValue("事件标题");
			cell.setCellStyle(style);
			cell = row.createCell((short) 2);
			
			cell.setCellValue("用户类型");
			cell.setCellStyle(style);
			cell = row.createCell((short) 3);
			
			cell.setCellValue("用户名称");
			cell.setCellStyle(style);
			cell = row.createCell((short) 4);
			
			cell.setCellValue("联系方式");
			cell.setCellStyle(style);
			cell = row.createCell((short) 5);
			
			cell.setCellValue("省");
			cell.setCellStyle(style);
			cell = row.createCell((short) 6);
			
			cell.setCellValue("市");
			cell.setCellStyle(style);
			cell = row.createCell((short) 7);
			
			cell.setCellValue("区");
			cell.setCellStyle(style);
			cell = row.createCell((short) 8);
			
			cell.setCellValue("一级事件类型");
			cell.setCellStyle(style);
			cell = row.createCell((short) 9);
			
			cell.setCellValue("二级事件类型");
			cell.setCellStyle(style);
			cell = row.createCell((short) 10);
				
			cell.setCellValue("事件描述");
			cell.setCellStyle(style);
			cell = row.createCell((short) 11);
			
			cell.setCellValue("解决方案");
			cell.setCellStyle(style);
			cell = row.createCell((short) 12);
			
			cell.setCellValue("是否解决");
			cell.setCellStyle(style);
			cell = row.createCell((short) 13);
			
			cell.setCellValue("是否流转");
			cell.setCellStyle(style);
			cell = row.createCell((short) 14);
			
			cell.setCellValue("受理人");
			cell.setCellStyle(style);
			cell = row.createCell((short) 15);
			
			cell.setCellValue("最后处理人");
			cell.setCellStyle(style);
			cell = row.createCell((short) 16);
			
			cell.setCellValue("实际解决时间");
			cell.setCellStyle(style);
			cell = row.createCell((short) 17);
			
			// 第五步，写入实体数据 实际应用中这些数据从数据库得到
			for (int i = 0; i < list.size(); i++) {
				row = sheet.createRow((int) i + 1);
				Issue model = list.get(i);
				// 第四步，创建单元格，并设置值
			//	row.createCell((short) 0).setCellValue(i + 1);
				
				cell = row.createCell((short) 0);
				cell.setCellValue(new SimpleDateFormat("yyyy-MM-dd").format(model.getCallTime()));
				row.createCell((short) 1).setCellValue(model.getIssueTopic());
				row.createCell((short) 2).setCellValue(model.getClientType());
				
				row.createCell((short) 3).setCellValue(model.getClientName());
				row.createCell((short) 4).setCellValue(model.getPhone());		
				row.createCell((short) 5).setCellValue(model.getProvince());		
				row.createCell((short) 6).setCellValue(model.getCity());
				row.createCell((short) 7).setCellValue(model.getDistrict());		
				row.createCell((short) 8).setCellValue(getIssueType(model.getIssueType()));			
				row.createCell((short) 9).setCellValue(model.getSubType());
				row.createCell((short) 10).setCellValue(model.getIssueDesc());
				
				row.createCell((short) 11).setCellValue(model.getIssueSolution());
				
				row.createCell((short) 12).setCellValue(getIssueStatus(model.getStatus()));
				
				row.createCell((short) 13).setCellValue(getConveyStatus(model.getIsConvey()));
				
				row.createCell((short) 14).setCellValue(model.getHandler());
				
				row.createCell((short) 15).setCellValue(model.getLast_handler());
				
				cell = row.createCell((short) 16);
				if(model.getHandle_time() != null){
					cell.setCellValue(new SimpleDateFormat("yyyy-MM-dd").format(model.getHandle_time()));
				}
				
			}
			/***
			 * 自动调整列宽
			 */
			sheet.autoSizeColumn((short) 0);
			sheet.autoSizeColumn((short) 1);
			sheet.autoSizeColumn((short) 2);
			sheet.autoSizeColumn((short) 3);
			sheet.autoSizeColumn((short) 4);
			sheet.autoSizeColumn((short) 5);
			sheet.autoSizeColumn((short) 6);
			sheet.autoSizeColumn((short) 7);
			sheet.autoSizeColumn((short) 8);
			sheet.autoSizeColumn((short) 9);
			sheet.autoSizeColumn((short) 10);
			sheet.autoSizeColumn((short) 11);
			sheet.autoSizeColumn((short) 12);
			sheet.autoSizeColumn((short) 13);
			sheet.autoSizeColumn((short) 14);
			sheet.autoSizeColumn((short) 15);
			sheet.autoSizeColumn((short) 16);
		}	
			
	}
	
	
	private void generateNoramlOBIssueTemplate(Map<String , Object> map,HSSFWorkbook wb){
		List<Issue> list = issueService.getNormalOBList(map);
		
		if (CollectionUtils.isNotEmpty(list)) {
			logger.info("the num of exportExcel size is :" + list.size());
			// 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
			HSSFSheet sheet = wb.createSheet("工单记录");
			// 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
			HSSFRow row = sheet.createRow((int) 0);
			// 第四步，创建单元格，并设置值表头 设置表头居中
			HSSFCellStyle style = wb.createCellStyle();
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式
			HSSFCell cell = row.createCell((short) 0);
			//
			
			// 呼入时间
			cell.setCellValue("最新呼出时间");
			cell.setCellStyle(style);
			cell = row.createCell((short) 1);
			
			cell.setCellValue("来源");
			cell.setCellStyle(style);
			cell = row.createCell((short) 2);			

			cell.setCellValue("用户名称");
			cell.setCellStyle(style);
			cell = row.createCell((short) 3);
			
			cell.setCellValue("联系方式");
			cell.setCellStyle(style);
			cell = row.createCell((short) 4);
				
			cell.setCellValue("事件标题");
			cell.setCellStyle(style);
			cell = row.createCell((short) 5);
			
			cell.setCellValue("城市");
			cell.setCellStyle(style);
			cell = row.createCell((short) 6);
			
			cell.setCellValue("诊所名称");
			cell.setCellStyle(style);
			cell = row.createCell((short) 7);
			
			cell.setCellValue("审核状态");
			cell.setCellStyle(style);
			cell = row.createCell((short) 8);
			
			cell.setCellValue("认证状态");
			cell.setCellStyle(style);
			cell = row.createCell((short) 9);
				
			cell.setCellValue("特殊备注");
			cell.setCellStyle(style);
			cell = row.createCell((short) 10);
			
			cell.setCellValue("受理人");
			cell.setCellStyle(style);
			cell = row.createCell((short) 11);
			
			cell.setCellValue("解决状态");
			cell.setCellStyle(style);
			cell = row.createCell((short) 12);
			
			cell.setCellValue("指派状态");
			cell.setCellStyle(style);
			cell = row.createCell((short) 13);
			
			
			// 第五步，写入实体数据 实际应用中这些数据从数据库得到
			for (int i = 0; i < list.size(); i++) {
				row = sheet.createRow((int) i + 1);
				Issue model = list.get(i);
				// 第四步，创建单元格，并设置值
			//	row.createCell((short) 0).setCellValue(i + 1);
				if(model.getCallTime()!=null){
					cell = row.createCell((short) 0);
					cell.setCellValue(new SimpleDateFormat("yyyy-MM-dd").format(model.getCallTime()));
				}		
				row.createCell((short) 1).setCellValue(model.getSource());
				row.createCell((short) 2).setCellValue(model.getClientName());
				row.createCell((short) 3).setCellValue(model.getPhone());
				row.createCell((short) 4).setCellValue(model.getIssueTopic());		
				row.createCell((short) 5).setCellValue(model.getCitycode());		
				row.createCell((short) 6).setCellValue(model.getClinicName());
				row.createCell((short) 7).setCellValue(model.getApproveStatus());		
				row.createCell((short) 8).setCellValue(model.getRzStatus());			
				row.createCell((short) 9).setCellValue(model.getRemark());
				row.createCell((short) 10).setCellValue(model.getHandler());	
				row.createCell((short) 11).setCellValue(getIssueStatus(model.getStatus()));
				row.createCell((short) 12).setCellValue(model.getAssignStatus());
				
				
			}
			/***
			 * 自动调整列宽
			 */
			sheet.autoSizeColumn((short) 0);
			sheet.autoSizeColumn((short) 1);
			sheet.autoSizeColumn((short) 2);
			sheet.autoSizeColumn((short) 3);
			sheet.autoSizeColumn((short) 4);
			sheet.autoSizeColumn((short) 5);
			sheet.autoSizeColumn((short) 6);
			sheet.autoSizeColumn((short) 7);
			sheet.autoSizeColumn((short) 8);
			sheet.autoSizeColumn((short) 9);
			sheet.autoSizeColumn((short) 10);
			sheet.autoSizeColumn((short) 11);
			sheet.autoSizeColumn((short) 12);
		}			
	}
	
	private void generateOTOBIssueTemplate(Map<String , Object> map,HSSFWorkbook wb){
		List<Issue> list = issueService.getOTOBList(map);
		
		if (CollectionUtils.isNotEmpty(list)) {
			logger.info("the num of exportExcel size is :" + list.size());
			// 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
			HSSFSheet sheet = wb.createSheet("工单记录");
			// 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
			HSSFRow row = sheet.createRow((int) 0);
			// 第四步，创建单元格，并设置值表头 设置表头居中
			HSSFCellStyle style = wb.createCellStyle();
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式
			HSSFCell cell = row.createCell((short) 0);
			//
			
			// 呼入时间
			cell.setCellValue("最新呼出时间");
			cell.setCellStyle(style);
			cell = row.createCell((short) 1);
			
			cell.setCellValue("来源");
			cell.setCellStyle(style);
			cell = row.createCell((short) 2);			

			cell.setCellValue("卡号");
			cell.setCellStyle(style);
			cell = row.createCell((short) 3);
			
			cell.setCellValue("产品类型");
			cell.setCellStyle(style);
			cell = row.createCell((short) 4);
				
			cell.setCellValue("产品名称");
			cell.setCellStyle(style);
			cell = row.createCell((short) 5);
			
			cell.setCellValue("事件标题");
			cell.setCellStyle(style);
			cell = row.createCell((short) 6);
			
			cell.setCellValue("诊所名称");
			cell.setCellStyle(style);
			cell = row.createCell((short) 7);
			
			cell.setCellValue("诊所电话");
			cell.setCellStyle(style);
			cell = row.createCell((short) 8);
			
			cell.setCellValue("就诊时间");
			cell.setCellStyle(style);
			cell = row.createCell((short) 9);
				
			cell.setCellValue("预约时间");
			cell.setCellStyle(style);
			cell = row.createCell((short) 10);
			
			cell.setCellValue("就诊人");
			cell.setCellStyle(style);
			cell = row.createCell((short) 11);
			
			cell.setCellValue("服务项目");
			cell.setCellStyle(style);
			cell = row.createCell((short) 12);
			
			cell.setCellValue("预约账户");
			cell.setCellStyle(style);
			cell = row.createCell((short) 13);
			
			cell.setCellValue("受理人");
			cell.setCellStyle(style);
			cell = row.createCell((short) 14);
			
			cell.setCellValue("状态");
			cell.setCellStyle(style);
			cell = row.createCell((short) 15);
			
			cell.setCellValue("解决状态");
			cell.setCellStyle(style);
			cell = row.createCell((short) 16);
			
			// 第五步，写入实体数据 实际应用中这些数据从数据库得到
			for (int i = 0; i < list.size(); i++) {
				row = sheet.createRow((int) i + 1);
				Issue model = list.get(i);
				// 第四步，创建单元格，并设置值
			//	row.createCell((short) 0).setCellValue(i + 1);
				if(model.getCallTime() != null){
					cell = row.createCell((short) 0);
					cell.setCellValue(new SimpleDateFormat("yyyy-MM-dd").format(model.getCallTime()));
				}
				row.createCell((short) 1).setCellValue(model.getSource());
				row.createCell((short) 2).setCellValue(model.getCardNO());
				row.createCell((short) 3).setCellValue(model.getProductTypeName());
				row.createCell((short) 4).setCellValue(model.getHealthProductName());		
				row.createCell((short) 5).setCellValue(model.getIssueTopic());		
				row.createCell((short) 6).setCellValue(model.getClinicName());
				row.createCell((short) 7).setCellValue(model.getPhone());		
				row.createCell((short) 8).setCellValue(model.getScheduleDate());			
				row.createCell((short) 9).setCellValue(model.getApptTime());
				row.createCell((short) 10).setCellValue(model.getPatientName());
				
				row.createCell((short) 11).setCellValue(model.getItemName());	
				row.createCell((short) 12).setCellValue(model.getName());	
				row.createCell((short) 13).setCellValue(model.getHandler());	
				
				row.createCell((short) 14).setCellValue(getApptStatus(model.getApptStatus()));
				row.createCell((short) 15).setCellValue(getIssueStatus(model.getStatus()));
				
				
			}
			/***
			 * 自动调整列宽
			 */
			sheet.autoSizeColumn((short) 0);
			sheet.autoSizeColumn((short) 1);
			sheet.autoSizeColumn((short) 2);
			sheet.autoSizeColumn((short) 3);
			sheet.autoSizeColumn((short) 4);
			sheet.autoSizeColumn((short) 5);
			sheet.autoSizeColumn((short) 6);
			sheet.autoSizeColumn((short) 7);
			sheet.autoSizeColumn((short) 8);
			sheet.autoSizeColumn((short) 9);
			sheet.autoSizeColumn((short) 10);
			sheet.autoSizeColumn((short) 11);
			sheet.autoSizeColumn((short) 12);
			sheet.autoSizeColumn((short) 13);
			sheet.autoSizeColumn((short) 14);
			sheet.autoSizeColumn((short) 15);
		}	
			
	}
}
