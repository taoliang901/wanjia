package com.wanjia.product.service;

import com.wanjia.base.IBaseService;
import com.wanjia.product.bo.PrdType;

/**
 * This element is automatically generated on 16-11-30 下午2:25, do not modify. <br>
 * Service interface
 */
public interface PrdTypeService extends IBaseService<PrdType, String> {
}