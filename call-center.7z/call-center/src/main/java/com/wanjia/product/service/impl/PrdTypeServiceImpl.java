package com.wanjia.product.service.impl;

import com.wanjia.common.utils.ThreadLocalContext;
import com.wanjia.product.bo.PrdType;
import com.wanjia.product.dao.PrdTypeMapper;
import com.wanjia.product.service.PrdTypeService;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-11-30 下午2:25, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class PrdTypeServiceImpl implements PrdTypeService {
    @Autowired
    private PrdTypeMapper prdTypeMapper;

    @Override
    @Transactional(readOnly=true)
    public PrdType findById(String id) {
        return (PrdType)prdTypeMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdType> findWithPagination(int offset, int count) {
        return (List<PrdType>)prdTypeMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdType> findAll() {
        return (List<PrdType>)prdTypeMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdType> findByEntity(PrdType model) {
        return (List<PrdType>)prdTypeMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdType> findByEntityWithPagination(PrdType model, int offset, int count) {
        return (List<PrdType>)prdTypeMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public PrdType findOneByEntity(PrdType model) {
        return (PrdType)prdTypeMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdType> findByProperty(String propertyName, String propertyValue) {
        return (List<PrdType>)prdTypeMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public PrdType findOneByProperty(String propertyName, String propertyValue) {
        return (PrdType)prdTypeMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdType> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<PrdType>)prdTypeMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdType> findByProperties(Map<String, Object> map) {
        return (List<PrdType>)prdTypeMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(PrdType model) {
        return (long)prdTypeMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)prdTypeMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)prdTypeMapper.countByProperties(map);
    }

    @Override
    public void update(PrdType model) {
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        prdTypeMapper.update(model);
    }

    @Override
    public void insert(PrdType model) {
        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        prdTypeMapper.insert(model);
    }

    @Override
    public void deleteByEntity(PrdType model) {
        model.setDelFlag(1);
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        prdTypeMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.prdTypeMapper.countAll();
    }

    public void insertBatch(List<PrdType> list) {
        this.prdTypeMapper.insertBatch(list);
    }

    public void delete(String id) {
        PrdType model = new PrdType();
        model.setDelFlag(1);
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.prdTypeMapper.update(model);
    }
}