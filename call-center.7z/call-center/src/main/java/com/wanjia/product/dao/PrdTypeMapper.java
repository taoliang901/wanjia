package com.wanjia.product.dao;

import com.wanjia.base.IBaseDao;
import com.wanjia.product.bo.PrdType;

public interface PrdTypeMapper extends IBaseDao<PrdType,String> {
}