package com.wanjia.common.utils;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * DAO base interface
 * 
 * @author louis
 * @param <T>
 *            Model
 * @param <ID>
 *            ID
 */
public interface IBaseDao<T, ID extends Serializable> {

	T findById(ID id);

	List<T> findWithPagination(int offset, int count);

	List<T> findAll();

	List<T> findByEntity(T entity);

	List<T> findByEntityWithPagination(T entity, int offset, int count);

	T findOneByEntity(T entity);

	List<T> findByProperty(String propertyName, Object propertyValue);

	T findOneByProperty(String propertyName, Object propertyValue);
	
	List<T> findByPropertyWithPagination(String propertyName, Object propertyValue,int offset, int count);
	
	List<T> findByProperties(Map<String,Object> map);
	
	long countAll();
	
	long countByEntity(T entity);

	long countByProperty(String propertyName, Object propertyValue);

	long countByProperties(Map<String,Object> map);

	void update(T entity);
	
	void insert(T entity);
	
	void insertBatch(List<T> list);

	void deleteById(ID id);

	void deleteByEntity(T entity);

	void deleteByProperty(String propertyName, Object propertyValue);
}
