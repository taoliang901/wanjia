package com.wanjia.common.view;

import javax.servlet.ServletContext;

import org.springframework.web.context.ServletContextAware;


public class ResourcePathExposer implements  ServletContextAware {
    private ServletContext servletContext;
	
    @Override
    public void setServletContext(ServletContext servletContext) {
		this.servletContext=servletContext;
	}
	public ServletContext getServletContext() {
		return servletContext;
	}

	public void init(){
		long resourceVersion = System.currentTimeMillis();
		getServletContext().setAttribute("resourceVersion", resourceVersion);
	}

}
