package com.wanjia.utils;

import java.io.StringWriter;

import com.wanjia.utils.StringUtil;


/**
 * 
 * @author 
 *
 */
public class UnicoddWriter extends StringWriter {

    @Override
    public void write(String str, int off, int len) {
        super.write(StringUtil.toUnicode(str), off, len);
    }

    @Override
    public void write(String str) {
        super.write(StringUtil.toUnicode(str));
    }
}
