package com.wanjia.utils;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.dubbo.common.utils.StringUtils;

public class ExcelUtil {

	public static String encodeFileNameForDownload(HttpServletRequest request, String fileName) throws UnsupportedEncodingException {
		if (request == null || StringUtils.isBlank(fileName)) {
			return fileName;
		}
		String encodedfileName = "";
		// 火狐
		if (request.getHeader("User-Agent").toLowerCase().indexOf("firefox") > 0) {
			encodedfileName = new String(fileName.getBytes("UTF-8"), "ISO8859-1");
		}
		// IE
		else {
			// encodedfileName = java.net.URLEncoder.encode(fileName,
			// "UTF-8");
			encodedfileName = new String(fileName.getBytes("gb2312"), "ISO-8859-1");
		}

		return encodedfileName;
	}
	
}
