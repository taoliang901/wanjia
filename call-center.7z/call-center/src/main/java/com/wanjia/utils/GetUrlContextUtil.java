package com.wanjia.utils;

import org.apache.commons.lang.StringUtils;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
 
public class GetUrlContextUtil {
 
    public static String getString(String urlPath) {
        try {
            if (StringUtils.isEmpty(urlPath)) {
                return "";
            }
            URL url = new URL(urlPath.trim());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            int state = connection.getResponseCode();
            if (state != 200) {
                return "";
            }
            connection.connect();
            InputStream inputStream = connection.getInputStream();
            Reader reader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(reader);
            String str = null;
            StringBuilder sb = new StringBuilder();
            while ((str = bufferedReader.readLine()) != null) {
                sb.append(str);
            }
            reader.close();
            connection.disconnect();
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }
}