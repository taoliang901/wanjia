package com.wanjia.ht.service;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseService;
import com.wanjia.ht.bo.MenuResourceBean;

/**
 * This element is automatically generated on 16-3-3 ����4:12, do not modify. <br>
 * Service interface
 */
public interface MenuResourceBeanService extends IBaseService<MenuResourceBean, String> {
	
	public String findMax(String parentId);
	
	public List<MenuResourceBean> queryMenuResourceBeanByUserCode(String userCode);
	
	public List<MenuResourceBean> queryParentMenuByUserCode(String userCode);
	
	public String findMaxSecondMenu(String parentId);
	
	public int findMaxNumForButton(String parentId);
	
	public void updateMenu(MenuResourceBean menuResourceBean,String user);
	
	public void insertMenuInfo(MenuResourceBean model);
	
	public List<MenuResourceBean> checkButtonAuth(Map<String, Object> map);
	
	public boolean checkUserHasButtonAuth(Map<String, Object> map);
	
	public List<MenuResourceBean> checkHasButtonElement(Map<String, Object> map);
}