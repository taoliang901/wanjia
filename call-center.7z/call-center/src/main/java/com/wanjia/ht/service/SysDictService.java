package com.wanjia.ht.service;

import java.util.List;

import com.wanjia.base.IBaseService;
import com.wanjia.ht.bo.SysDict;

/**
 * This element is automatically generated on 16-3-11 上午9:46, do not modify. <br>
 * Service interface
 */
public interface SysDictService extends IBaseService<SysDict, String> {
	
	public String getDescriptionByDictKey(String dictCode , String dictKey);
	
	public String getDictKeyByDescription(String description);
	
	public void deleteUnusedTypeByCode();
}