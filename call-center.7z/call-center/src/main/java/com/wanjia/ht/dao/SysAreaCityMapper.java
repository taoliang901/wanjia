package com.wanjia.ht.dao;

import com.wanjia.base.IBaseDao;

public interface SysAreaCityMapper extends IBaseDao {
}