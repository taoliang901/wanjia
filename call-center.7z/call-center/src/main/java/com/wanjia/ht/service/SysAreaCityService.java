package com.wanjia.ht.service;

import com.wanjia.base.IBaseService;
import com.wanjia.ht.bo.SysAreaCity;

/**
 * This element is automatically generated on 16-7-23 ����3:17, do not modify. <br>
 * Service interface
 */
public interface SysAreaCityService extends IBaseService<SysAreaCity, Long> {
	
	SysAreaCity getAreaByAreaid(String areaId);
}