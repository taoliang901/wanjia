package com.wanjia.ht.service;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;








import com.wanjia.ht.bo.HtUser;
import com.wanjia.ht.dao.HtUserDao;

@Service("htUserService")
public class HtUserServiceImpl implements HtUserService{

	@Autowired
	private HtUserDao htUserDao;

	public HtUser getHtUserById(String Id) {
		return (HtUser)htUserDao.getHtUserById(Id);
	}
	@Override
    public HtUser getUserByUserCode(String userCode){
    	HtUser userBean = null;
    	Map map = new HashMap();
        map.put("userCode", userCode);
        map.put("delFlag", "0");
        List<HtUser> userList = htUserDao.queryHtUserForList(map);
        if (userList != null && userList.size() > 0) {
        	return userList.get(0);
        }
		return null;
    }

    /**
     * 根据map传入的数据查询用户数据
     * @param param
     * @return
     */
    public List<HtUser> queryHtUserForList(Map param) {
        return htUserDao.queryHtUserForList(param);
    }


	@Override
	public List<HtUser> findByEntity(HtUser entity) {
        return (List<HtUser>) htUserDao.findByEntity(entity);
	}

	@Override
	public List<HtUser> findByProperties(Map<String, Object> map) {
		return (List<HtUser>) htUserDao.findByProperties(map);
	}

	@Override
	public int updateByPrimaryKeySelective(HtUser htUser) {
		htUser.setModifyDate(new Date());
		return htUserDao.updateByPrimaryKeySelective(htUser);
	}

	@Override
	public HtUser findOneByProperties(String propertyName, Object propertyValue) {
		// TODO Auto-generated method stub
		return (HtUser)htUserDao.findByProperties(propertyName, propertyValue);
	}

	@Override
	public long countByProperty(String propertyName, Object propertyValue) {
		// TODO Auto-generated method stub
		return htUserDao.countByProperty(propertyName, propertyValue);
	}

	@Override
	public void insertSelective(HtUser htUser) {
		if(htUser.getStatus()==null){
			htUser.setStatus("1");
		}
		htUser.setCreateDate(new Date());
		htUser.setId(UUID.randomUUID().toString());
		htUserDao.insertSelective(htUser);
	}
	@Override
	public List<HtUser> findByPropertiesForOr(Map<String, Object> map) {
		return htUserDao.findByPropertiesForOr(map);
	}
	
	@Override
	public List<HtUser> getDeptLeaderList(Map<String,Object> param){
		return htUserDao.getDeptLeaderList(param);
	}
	
	@Override
	public List<HtUser> getUserListByRole(List<String> list){
		return htUserDao.getUserListByRole(list);
	}
}
