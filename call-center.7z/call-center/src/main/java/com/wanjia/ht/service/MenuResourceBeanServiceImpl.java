package com.wanjia.ht.service;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.ht.bo.MenuResourceBean;
import com.wanjia.ht.dao.MenuResourceBeanMapper;
import com.wanjia.utils.StringUtil;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-3-3 ����4:12, do not modify. <br>
 * Service implementation class
 */
@Service("menuResourceService")
@Transactional
public class MenuResourceBeanServiceImpl implements MenuResourceBeanService {
    @Autowired
    private MenuResourceBeanMapper menuResourceBeanMapper;

    @Override
    @Transactional(readOnly=true)
    public MenuResourceBean findById(String id) {
        return (MenuResourceBean)menuResourceBeanMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<MenuResourceBean> findWithPagination(int offset, int count) {
        return (List<MenuResourceBean>)menuResourceBeanMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<MenuResourceBean> findAll() {
        return (List<MenuResourceBean>)menuResourceBeanMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<MenuResourceBean> findByEntity(MenuResourceBean model) {
        return (List<MenuResourceBean>)menuResourceBeanMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<MenuResourceBean> findByEntityWithPagination(MenuResourceBean model, int offset, int count) {
        return (List<MenuResourceBean>)menuResourceBeanMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public MenuResourceBean findOneByEntity(MenuResourceBean model) {
        return (MenuResourceBean)menuResourceBeanMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<MenuResourceBean> findByProperty(String propertyName, String propertyValue) {
        return (List<MenuResourceBean>)menuResourceBeanMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public MenuResourceBean findOneByProperty(String propertyName, String propertyValue) {
        return (MenuResourceBean)menuResourceBeanMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<MenuResourceBean> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<MenuResourceBean>)menuResourceBeanMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<MenuResourceBean> findByProperties(Map<String, Object> map) {
    	map.put("delflag", "0");
        return (List<MenuResourceBean>)menuResourceBeanMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(MenuResourceBean model) {
        return (long)menuResourceBeanMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)menuResourceBeanMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)menuResourceBeanMapper.countByProperties(map);
    }

    @Override
    public void update(MenuResourceBean model) {
        model.setModifyDate(new Date());
        menuResourceBeanMapper.update(model);
    }

    @Override
    public void insert(MenuResourceBean model) {
        model.setCreateDate(new Date());
        model.setDelflag("0");
        model.setId(UUID.randomUUID().toString());
        menuResourceBeanMapper.insert(model);
           
    }

    @Override
    public void insertMenuInfo(MenuResourceBean model) {
    	insert(model);
    	 //增加按钮权限控制  By TL 16/05/23
  		if(model.getIconNames() != null && model.getIconNames().length() > 0 ){
  			String[] array_name = model.getIconNames().split(",");
  			int i_num = 0;
  			for(int k=0; k < array_name.length ; k++){
  				i_num++;
  				String menuId = model.getMenuId();
  				model.setMenuId(menuId + "#"+String.valueOf(i_num));
  				model.setParentId(menuId);
  				model.setMenuType(SysConstant.MENU_TYPE_BUTTON);
  				model.setName(array_name[k]);
  				model.setUrl(null);	
  				insert(model);
  			}
  		}
    }
    @Override
    public void deleteByEntity(MenuResourceBean model) {
  //      model.setDelflag("1");
        model.setModifyDate(new Date());
        menuResourceBeanMapper.deleteByEntity(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        menuResourceBeanMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.menuResourceBeanMapper.countAll();
    }

    public void insertBatch(List<MenuResourceBean> list) {
        this.menuResourceBeanMapper.insertBatch(list);
    }

    public void delete(String id) {
        MenuResourceBean model = new MenuResourceBean();
        model.setDelflag("1");
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.menuResourceBeanMapper.update(model);
    }

	@Override
	@Transactional(readOnly=true)
	public String findMax(String parentId) {
		return menuResourceBeanMapper.findMax(parentId);
	}
	
	public List<MenuResourceBean> queryMenuResourceBeanByUserCode(String userCode){
		return menuResourceBeanMapper.queryMenuResourceBeanByUserCode(userCode);
	}
	
	public List<MenuResourceBean> queryParentMenuByUserCode(String userCode){
		return menuResourceBeanMapper.queryParentMenuByUserCode(userCode);
	}

	@Override
	public String findMaxSecondMenu(String parentId) {
		return menuResourceBeanMapper.findMaxSecondMenu(parentId);
	}
	@Override
	public int findMaxNumForButton(String parentId){
		String result = menuResourceBeanMapper.findMaxNumForButton(parentId);
		if(result == null || result.equals("")){
			return 0;
		}
		return Integer.valueOf(result);
	}
	
	@Override
	public void updateMenu(MenuResourceBean menuResourceBean,String user){
		MenuResourceBean oldBean = findById(menuResourceBean.getId());
		//循环更新子菜单syscode属性
		if(oldBean.getSysCode() != null && !oldBean.getSysCode().equals(menuResourceBean.getSysCode())){
			//查询子菜单
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("parentId", oldBean.getMenuId());
			List<MenuResourceBean> childList = findByProperties(map);
			if(childList != null){
				for(MenuResourceBean childBean:childList){
					childBean.setSysCode(menuResourceBean.getSysCode());
					childBean.setModifyUser(user);
					update(childBean);
				}
			}
			
		}
		//更新菜单
		if(StringUtil.notEmpty(menuResourceBean.getParentId()) && !menuResourceBean.getParentId().equals("0")){
			menuResourceBean.setSysCode(oldBean.getSysCode()); //更新前台错误的syscode值
		}
		
		menuResourceBean.setModifyUser(user);
		update(menuResourceBean);
		
		//先清除原先设置 By TL 16/05/23
		MenuResourceBean paramModel = new MenuResourceBean();
		paramModel.setParentId(oldBean.getMenuId());
		paramModel.setMenuType(SysConstant.MENU_TYPE_BUTTON);
		deleteByEntity(paramModel);
		
		//重新设置按钮权限控制  
		if(menuResourceBean.getIconNames() != null && menuResourceBean.getIconNames().length() > 0 ){
			String[] array_name = menuResourceBean.getIconNames().split(",");
			String menuId = menuResourceBean.getMenuId();
			
			int num = findMaxNumForButton(menuId);
		
			for(int k=0; k < array_name.length ; k++){
				if(array_name[k] != null && !array_name[k].equals("")){
					num++;
	  				menuResourceBean.setMenuId(menuId + "#"+ String.valueOf(num));
	  				menuResourceBean.setParentId(menuId);
					menuResourceBean.setMenuType(SysConstant.MENU_TYPE_BUTTON);
					menuResourceBean.setName(array_name[k]);
					menuResourceBean.setUrl(null);
					insert(menuResourceBean);
				}			
			}
		}
		//End 
	}
	
	public List<MenuResourceBean> checkHasButtonElement(Map<String, Object> map){
		return menuResourceBeanMapper.checkHasButtonElement(map);
	}
	
	public List<MenuResourceBean> checkButtonAuth(Map<String, Object> map){
		return menuResourceBeanMapper.checkButtonAuth(map);
	}
	
	public boolean checkUserHasButtonAuth(Map<String, Object> map){
		List<MenuResourceBean> list = checkButtonAuth(map);
		if(list != null && list.size() > 0 ){
			return true;
		}
		return false;
	}
}