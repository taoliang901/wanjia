package com.wanjia.ht.service;

import com.wanjia.ht.bo.SysDict;
import com.wanjia.ht.dao.SysDictMapper;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-3-11 上午9:46, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class SysDictServiceImpl implements SysDictService {
    @Autowired
    private SysDictMapper sysDictMapper;

    @Override
    @Transactional(readOnly=true)
    public SysDict findById(String id) {
        return (SysDict)sysDictMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysDict> findWithPagination(int offset, int count) {
        return (List<SysDict>)sysDictMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysDict> findAll() {
        return (List<SysDict>)sysDictMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysDict> findByEntity(SysDict model) {
        return (List<SysDict>)sysDictMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysDict> findByEntityWithPagination(SysDict model, int offset, int count) {
        return (List<SysDict>)sysDictMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public SysDict findOneByEntity(SysDict model) {
        return (SysDict)sysDictMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysDict> findByProperty(String propertyName, String propertyValue) {
        return (List<SysDict>)sysDictMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public SysDict findOneByProperty(String propertyName, String propertyValue) {
        return (SysDict)sysDictMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysDict> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<SysDict>)sysDictMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysDict> findByProperties(Map<String, Object> map) {
        return (List<SysDict>)sysDictMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(SysDict model) {
        return (long)sysDictMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)sysDictMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)sysDictMapper.countByProperties(map);
    }

    @Override
    public void update(SysDict model) {
        sysDictMapper.update(model);
    }

    @Override
    public void insert(SysDict model) {
        sysDictMapper.insert(model);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.sysDictMapper.countAll();
    }

    public void insertBatch(List<SysDict> list) {
        this.sysDictMapper.insertBatch(list);
    }

	@Override
	public void deleteByEntity(SysDict model) {
		this.sysDictMapper.deleteByEntity(model);
		
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		// TODO Auto-generated method stub
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
	}

	@Override
	public String getDescriptionByDictKey(String dictCode, String dictKey) {
		return sysDictMapper.getDescriptionByDictKey(dictCode, dictKey);
	}

	@Override
	public String getDictKeyByDescription(String description) {
		// TODO Auto-generated method stub
		return sysDictMapper.getDictKeyByDescription(description);
	}

	@Override
	public void deleteUnusedTypeByCode(){
		sysDictMapper.deleteUnusedTypeByCode();
	}
	
}