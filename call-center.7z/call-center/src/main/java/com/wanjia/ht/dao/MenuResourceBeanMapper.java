package com.wanjia.ht.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.base.IBaseDao;
import com.wanjia.ht.bo.MenuResourceBean;

public interface MenuResourceBeanMapper extends IBaseDao<MenuResourceBean,String> {
	
	public String findMax(String parentId);
	
	public List<MenuResourceBean> queryMenuResourceBeanByUserCode(String userCode);
	
	public List<MenuResourceBean> queryParentMenuByUserCode(String userCode);
	
	public String findMaxSecondMenu(String parentId);
	
	public String findMaxNumForButton(String parentId);
	
	public List<MenuResourceBean> checkHasButtonElement(Map<String, Object> map);
	
	public List<MenuResourceBean> checkButtonAuth(Map<String, Object> map);
	
	
}