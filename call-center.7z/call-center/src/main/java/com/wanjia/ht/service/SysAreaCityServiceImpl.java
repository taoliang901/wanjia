package com.wanjia.ht.service;

import com.wanjia.base.consts.SysConstant;
import com.wanjia.ht.bo.SysAreaCity;
import com.wanjia.ht.dao.SysAreaCityMapper;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-7-23 ����3:17, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class SysAreaCityServiceImpl implements SysAreaCityService {
    @Autowired
    private SysAreaCityMapper sysAreaCityMapper;

    @Override
    @Transactional(readOnly=true)
    public SysAreaCity findById(Long id) {
        return (SysAreaCity)sysAreaCityMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysAreaCity> findWithPagination(int offset, int count) {
        return (List<SysAreaCity>)sysAreaCityMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysAreaCity> findAll() {
        return (List<SysAreaCity>)sysAreaCityMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysAreaCity> findByEntity(SysAreaCity model) {
        return (List<SysAreaCity>)sysAreaCityMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysAreaCity> findByEntityWithPagination(SysAreaCity model, int offset, int count) {
        return (List<SysAreaCity>)sysAreaCityMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public SysAreaCity findOneByEntity(SysAreaCity model) {
        return (SysAreaCity)sysAreaCityMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysAreaCity> findByProperty(String propertyName, String propertyValue) {
        return (List<SysAreaCity>)sysAreaCityMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public SysAreaCity findOneByProperty(String propertyName, String propertyValue) {
        return (SysAreaCity)sysAreaCityMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysAreaCity> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<SysAreaCity>)sysAreaCityMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<SysAreaCity> findByProperties(Map<String, Object> map) {
        return (List<SysAreaCity>)sysAreaCityMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(SysAreaCity model) {
        return (long)sysAreaCityMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)sysAreaCityMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)sysAreaCityMapper.countByProperties(map);
    }

    @Override
    public void update(SysAreaCity model) {
        model.setModifyDate(new Date());
        sysAreaCityMapper.update(model);
    }

    @Override
    public void insert(SysAreaCity model) {
        model.setCreateDate(new Date());
        sysAreaCityMapper.insert(model);
    }

    @Override
    public void deleteByEntity(SysAreaCity model) {
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        sysAreaCityMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.sysAreaCityMapper.countAll();
    }

    public void insertBatch(List<SysAreaCity> list) {
        this.sysAreaCityMapper.insertBatch(list);
    }

    public void delete(Long id) {
        SysAreaCity model = new SysAreaCity();
        model.setDelFlag(SysConstant.DEL_FLAG);
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.sysAreaCityMapper.update(model);
    }

	@Override
	public SysAreaCity getAreaByAreaid(String areaId) {
		SysAreaCity area = new SysAreaCity();
		area.setAreaId(areaId);
		area.setDelFlag(SysConstant.NOT_DEL_FLAG);
		return (SysAreaCity) sysAreaCityMapper.findOneByEntity(area);
	}
}