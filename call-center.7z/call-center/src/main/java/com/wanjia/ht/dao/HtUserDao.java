package com.wanjia.ht.dao;

import java.util.List;
import java.util.Map;


import com.wanjia.ht.bo.HtUser;


public interface HtUserDao {

/*	@Override
	public String getIbatisSqlMapNamespace() {
		return "RoleMapper";
	}*/
	
	/**
	 * 根据主键查询
	 * 
	 * @param id
	 * @return
	 */
	public HtUser getHtUserById(String id)  ;

	/**
	 * 根据entity属性查询
	 * 
	 * @param entity
	 * @return
	 */
	public List<HtUser> findByEntity(HtUser entity);
	
    /**
     * 根据多条属性值查询数据
     */
	public List<HtUser> findByProperties(Map<String,Object> map);
	
    /**
     * 根据多条属性值查询数据
     */
	public List<HtUser> findByPropertiesForOr(Map<String,Object> map);
	
    /**
     * 根据属性值查询一条数据
     */
	public HtUser findByProperties(String propertyName, Object propertyValue );
	/**
	 * 根据ID更新
	 * 
	 * @param id
	 * @return
	 */
	public int updateByPrimaryKeySelective(HtUser htUser);

	/**
	 * 插入数据
	 * 
	 * @param entity
	 * @return
	 */
	public int saveHtUser(HtUser entity) ;

	/**
	 * 更新数据
	 * 
	 * @param entity
	 * @return
	 */
	public int updateHtUser(HtUser entity) ;

	/**
	 * 根据id检查是否插入或是更新数据
	 * 
	 * @param entity
	 * @return 0-未save/update，1-save成功，2-update成功
	 * @throws DataAccessException
	 */
	public int saveOrUpdateHTUser(HtUser entity) ;

	/**
	 * 查询
	 * 
	 * @param statementName
	 * @param param
	 * @return
	 */
	public List<HtUser> queryHtUserForList(Map<String, Object> param);
	
	/**
	 * 查询
	 * 
	 * @param propertyName
	 * @param propertyValue
	 * @return
	 */
	long countByProperty(String propertyName, Object propertyValue);
	
	/**
	 * 插入一条数据
	 * 
	 * @param propertyName
	 * @param propertyValue
	 * @return
	 */
	public void insertSelective(HtUser htUser);
/*
	*//**
	 * 分页查询
	 * 
	 * @param statementName
	 * @param page
	 * @param param
	 * @return
	 *//*
	public QueryResult<HtUser> queryHtUserForPage(Map<String, Object> param, Page page);
	*/
	
	public List<HtUser> getDeptLeaderList(Map<String,Object> param);
	
	
	public List<HtUser> getUserListByRole(List<String> list);
}
