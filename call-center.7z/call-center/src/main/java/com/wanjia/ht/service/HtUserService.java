package com.wanjia.ht.service;

import java.util.List;
import java.util.Map;

import com.wanjia.ht.bo.HtUser;

public interface HtUserService {
	
	public HtUser getHtUserById(String Id);
	
	public List<HtUser> findByEntity(HtUser htUser);
	
	public List<HtUser> findByProperties(Map<String,Object> map);
	
	public int updateByPrimaryKeySelective(HtUser htUser);
	
	public HtUser findOneByProperties(String propertyName, Object propertyValue);
	
	public List<HtUser> findByPropertiesForOr(Map<String, Object> map);
	
	public long countByProperty(String propertyName, Object propertyValue);
	
	public void insertSelective(HtUser htUser);
	
    public HtUser getUserByUserCode(String userCode);
    
    public List<HtUser> queryHtUserForList(Map param); 
    
    public List<HtUser> getDeptLeaderList(Map<String,Object> param);
    
    public List<HtUser> getUserListByRole(List<String> list);
}
