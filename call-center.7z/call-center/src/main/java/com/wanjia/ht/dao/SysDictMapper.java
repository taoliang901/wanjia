package com.wanjia.ht.dao;


import com.wanjia.base.IBaseDao;
import com.wanjia.ht.bo.SysDict;

public interface SysDictMapper extends IBaseDao<SysDict,String> {
	
	public String getDescriptionByDictKey(String dictCode , String dictKey);
	
	public String getDictKeyByDescription(String description);
	
	public void deleteUnusedTypeByCode();
	
	public void deleteUnusedSurveyTypeByCode();
}