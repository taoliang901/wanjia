package com.wanjia.ht.dao;

import java.util.List;
import java.util.Map;

import com.wanjia.ht.bo.HtUser;


public class HtUserDaoImpl implements HtUserDao{

	public HtUser getHtUserById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<HtUser> findByEntity(HtUser entity) {
		return null;
	}

	public List<HtUser> findByProperties(Map<String,Object> map) {
		return null;
	}
	
	public int deleteHtUserById(String id) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int saveHtUser(HtUser entity) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateHtUser(HtUser entity) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int saveOrUpdateHTUser(HtUser entity) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<HtUser> queryHtUserForList(Map<String, Object> param) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(HtUser htUser) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public HtUser findByProperties(String propertyName, Object propertyValue) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long countByProperty(String propertyName, Object propertyValue) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void insertSelective(HtUser htUser) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<HtUser> findByPropertiesForOr(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HtUser> getDeptLeaderList(Map<String,Object> param){
		return null;
	}
	
	@Override
	public List<HtUser> getUserListByRole(List<String> list){
		return null;
	}
}
