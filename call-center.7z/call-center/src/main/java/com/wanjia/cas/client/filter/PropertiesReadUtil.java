package com.wanjia.cas.client.filter;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

/**
 * 工具类：读取配置文件（使用静态内部类，用于保证单例）
 */
public class PropertiesReadUtil {

	private static class Nested {
		private static final String filePath = "/nfs/wanjia/settings/callCenter/config.properties";
		private static Properties p;
		static {
			try {
				p = new Properties();
				InputStream is;
				File file = new File(filePath);
				if(file.exists()) {
					is = new FileInputStream(file);
				} else {
					is = PropertiesReadUtil.class.getResourceAsStream("/properties/config.properties");
				}
				p.load(is);
				is.close();
			} catch(Exception e) {
				throw new RuntimeException("加载配置文件失败！");
			}
		}
	}
	public static Properties getInstance() {
		return Nested.p;
	}
	
	/**
	 * 获取全局变量
	 */
	public static String getPropertyVal(String key) {
		Properties p = getInstance();
		String val = p.getProperty(key);
		if(StringUtils.isBlank(val)) {
			val = null;
		}
		return val;
	}



}
