package com.wanjia.base;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/*********************************************************************************
//* Copyright (C) 2015 Pingan Haoche (PAHAOCHE). All Rights Reserved.
//*
//* Filename:      IBaseService.java
//* Revision:      1.0
//* Author:        wangjingjun
//* Created On:    2015年5月7日
//* Modified by:   
//* Modified On:   
//*
//* Description:   <description>
/********************************************************************************/

public interface IBaseService<T, ID extends Serializable> {

    /**
     * 根据主键查询数据
     */
    T findById(ID id);

    /**
     * 查询数据并分页
     */
    List<T> findWithPagination(int offset, int count);

    /**
     * 查询全部
     */
    List<T> findAll();

    /**
     * 根据Entity查询数据
     */
    List<T> findByEntity(T model);

    /**
     * 根据Entity查询数据并分页
     */
    List<T> findByEntityWithPagination(T model, int offset, int count);

    /**
     * 根据Entity查询一条数据
     */
    T findOneByEntity(T model);

    /**
     * 根据属性查询数据
     */
    List<T> findByProperty(String propertyName, String propertyValue);

    /**
     * 根据属性查询一条数据
     */
    T findOneByProperty(String propertyName, String propertyValue);

    /**
     * 根据属性值查询数据并分页
     */
    List<T> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count);

    /**
     * 根据多条属性值查询数据
     */
    List<T> findByProperties(Map<String, Object> map);

    /**
     * 根据Entity计算数据的条数
     */
    long countByEntity(T model);

    /**
     * 根据属性值计算数据的条数
     */
    long countByProperty(String propertyName, String propertyValue);

    /**
     * 根据多条属性值计算数据的条数
     */
    long countByProperties(Map<String, Object> map);

    /**
     * 根据Entity ID更新数据
     */
    void update(T model);

    /**
     * 根据Entity插入数据
     */
    void insert(T model);

    /**
     * 根据Entity批量物理删除数据
     */
    void deleteByEntity(T model);

    /**
     * 根据属性值批量物理删除数据
     */
    void deleteByProperty(String propertyName, String propertyValue);

    /**
     * 计算所有数据的条数
     */
    long countAll();

    /**
     * 批量更新，List最好不要大于1000
     */
    void insertBatch(List<T> list);

    /**
     * 根据ID删除数据
     */
    void delete(ID id);
}
