package com.wanjia.base.web;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wanjia.base.SessionBean;
import com.wanjia.ht.service.MenuResourceBeanService;

public abstract class BaseController {

	private Logger logger = LoggerFactory.getLogger(BaseController.class);
	
    protected static final String DATE_FORMAT           = "yyyy-MM-dd HH:mm:ss";
    protected final static String CHECK_SUCCESS         = "审核通过";
    protected final static String CHECK_NO_SUCCESS      = "审核不通过";
    protected final static String CHECK_ERROR           = "审核失败";
    
    @Resource(name="menuResourceService")
	private MenuResourceBeanService menuResourceService;
    
	public SessionBean getSessionBean(HttpServletRequest request){
		if(null!=request.getSession().getAttribute("sessionBean")){
			SessionBean sessionBean = (SessionBean) request.getSession().getAttribute("sessionBean");
			return sessionBean;
		}
		return null;
	}
	
	public String getCurrentUser(HttpServletRequest request){
		String userCode = (String)request.getSession().getAttribute("userCode");
		return userCode;
	}
	
	public String getCurrentUserName(HttpServletRequest request){
		String userName = (String)request.getSession().getAttribute("userName");
		logger.info("获取userName:"+userName);
		return userName;
	}
	
	public boolean checkUserHasButtonAuth(HttpServletRequest request,Map<String, Object> map){
		
		map.put("userCode", getCurrentUser(request));
		if(request.getRequestURI().startsWith("/")){
			map.put("url", request.getRequestURI().substring(1));
		}else{
			map.put("url", request.getRequestURI());
		}
		if(menuResourceService.checkHasButtonElement(map) == null 
				|| menuResourceService.checkHasButtonElement(map).size() ==0){
			return true;
		}

		return menuResourceService.checkUserHasButtonAuth(map);
	}
}
