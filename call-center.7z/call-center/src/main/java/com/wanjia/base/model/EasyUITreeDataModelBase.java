package com.wanjia.base.model;

import java.util.List;

/**
 * EasyUI树结构模型
 * @author XIONGXING
 *
 */
public class EasyUITreeDataModelBase<T>{

	
	private String id;
	private String text;
	private String state;
	private String iconCls;
	private Boolean checked;
	private T attributes;
	private String sysCode;
	private List<EasyUITreeDataModelBase<T>> children;
	
	public EasyUITreeDataModelBase(String id,String text){
		this.id = id;
		this.text = text;
	}

	public EasyUITreeDataModelBase(String id, String text, T attributes, List<EasyUITreeDataModelBase<T>> children) {
		super();
		this.id = id;
		this.text = text;
		this.attributes = attributes;
		this.children = children;
	}
	
	public EasyUITreeDataModelBase(String id, String text, String state, String iconCls, Boolean checked,  T attributes, List<EasyUITreeDataModelBase<T>> children) {
		super();
		this.id = id;
		this.text = text;
		this.state = state;
		this.iconCls = iconCls;
		this.checked = checked;
		this.attributes = attributes;
		this.children = children;
	}


	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getIconCls() {
		return iconCls;
	}
	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}
	

	public Boolean getChecked() {
		return checked;
	}

	public void setChecked(Boolean checked) {
		this.checked = checked;
	}

	public T getAttributes() {
		return attributes;
	}

	public void setAttributes(T attributes) {
		this.attributes = attributes;
	}

	public List<EasyUITreeDataModelBase<T>> getChildren() {
		return children;
	}

	public void setChildren(List<EasyUITreeDataModelBase<T>> children) {
		this.children = children;
	}

	public String getSysCode() {
		return sysCode;
	}

	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}
	
}

