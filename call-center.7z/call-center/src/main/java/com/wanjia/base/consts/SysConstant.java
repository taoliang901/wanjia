package com.wanjia.base.consts;

/**
 * 存放系统变量
 * @author TaoLiang
 *
 */

public class SysConstant {
	
	// 未登录不拦截
	public static String[] NO_FILTER_PAGES = {
			"/resources/",
			"/login.do",
			"/logout.do",
			"/logout.jsp",
			"/clinic/approval/addCoordinates.do"
	};
		
	public static final String YES = "1";
    public static final String NO  = "0";
	
    public static final String DEL_FLAG                          = "1";
    public static final String NOT_DEL_FLAG                      = "0";
    public static final String ROOT = "0";

    public static final String STATUS_ACTIVE ="1";

    public static final String IB_TYPE = "0"; //呼入
    public static final String OB_TYPE = "1"; //呼出
    /**
	 * 分页页码
	 */
	public static int PAGE_SIZE = 20;
	public static int PAGE_START_NUMBER=1;


	//审核通过诊所环境图片大小
	public static final int IMAGE_WIDTH = 470;//宽度
	public static final int IMAGE_HEIGHT = 315;//高度

	
	public static final String WEBCMS_PROJECT_NAME = "webcms";
	public static final String CALLCENTER_PROJECT_NAME = "callCenter";
	
	public static final String SESSION_OUT_MESSAGE = "您的会话已过期，请重新登录系统！";
	
	public static final String ZX_TL_ROLE = "坐席组长";
	public static final String ZX_ROLE = "坐席专员";
	public static final String ZX_OB_ROLE = "投诉对接人";
	
	//软电话环境配置
	public static final String CTI_ENV_STG = "stg";
	public static final String CTI_ENV_PRD = "prd";
	public static final String CTI_CODEBASE_STG = "CTI_CODEBASE_STG";
	public static final String CTI_CODEBASE_PRD = "CTI_CODEBASE_PRD";
	
	//问题类别
	public static final String QUESTION_TYPE_DICT_CODE = "CC_QUESTION_TYPE";
	
	public static final String QUESTION_TYPE_DICT_NAME = "问题类别";
	
	public static final String QUEST_TYPE_POS = "oldType#0#";
	public static final String QUEST_TYPE_STATUS_POS= "oldType#";
	
	public static final String MENU_TYPE_BUTTON = "1";
	
	//坐席领取工单按钮
	public static final String CC_RECEIVE_BUTTON = "领取工单";	
	public static final String CC_GET_ISSUE_BUTTON = "领取超时预约工单";
	
	public static final String SOURCE_EXPORT = "export";
}
