package com.wanjia.base;

import java.io.Serializable;

public class SessionBean implements Serializable {

	private String userCode;//用户代码
	private String userId;//用户id
	private String name;//用户名称
	
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
