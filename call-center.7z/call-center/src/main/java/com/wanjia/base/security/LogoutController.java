/*
 *  @author 陈雨茂
 * 	@date 2014/03/31
 */
package com.wanjia.base.security;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wanjia.cas.client.filter.PropertiesReadUtil;


@Controller
@RequestMapping(value = "/logout")
public class LogoutController {

    private static final Logger logger = Logger.getLogger(LogoutController.class);

    /**
     * 登出并跳转到页面，现在的登出不再由本地调起，而是由官网跳回该地址，并将service送过来
     * @param res
     * @return ModelAndView
     * 如果异常就BusinessException
     * @throws UnsupportedEncodingException 
     */
    @SuppressWarnings("deprecation")
	@RequestMapping(method = { RequestMethod.POST, RequestMethod.GET })
    public ModelAndView logout(HttpSession session, HttpServletRequest res) throws UnsupportedEncodingException {
        //String address = (String) res.getParameter("service");
    	String client_URL = PropertiesReadUtil.getPropertyVal("CAS_CLIENT_SERVER_URL_NGINX");
        ModelAndView view = new ModelAndView();
        session.invalidate();
        logger.info("==============成功将 session失效！=============");
        String casLogoutUrl = PropertiesReadUtil.getPropertyVal("CAS_URL_NGINX")+"/logout?targetType=wanjiaA&service=";
        if (client_URL == null) {
            view.setViewName("redirect:" + casLogoutUrl);
            return view;
        } else {
        	casLogoutUrl = java.net.URLDecoder.decode(casLogoutUrl);
        	client_URL = java.net.URLDecoder.decode(client_URL);
            view.setViewName("redirect:"+casLogoutUrl + client_URL);
            return view;
        }
    }

}
