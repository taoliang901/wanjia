package com.wanjia.base;

/**
 * 配置软电话组件显示
 * 说明： 0：代表不显示； 1：代表显示；2：代表显示但不可操作（灰显）
 * 
 * @author yangyb 2014-12-11
 *
 */
public class GuiDisplayBean {

    /**
     * 登入、登出
     */
    private String butLogin             = "0";

    /**
     * 外呼功能
     */
    private String butOutbound          = "0";

    /**
     * 挂断功能
     */
    private String butHangup            = "0";

    /**
     * 接听功能
     */
    private String butAnswer            = "0";

    /**
     * 二次呼出功能
     */
    private String butDTMF              = "0";

    /**
     * 示忙、示闲功能
     */
    private String butWorkingStatusOpen = "0";

    /**
     * 话后处理功能
     */
    private String butBook              = "0";

    /**
     * 保持、取消保持功能
     */
    private String butHoldon            = "0";

    /**
     * 转接、完成转接功能
     */
    private String butTransfer          = "0";

    /**
     * 会议、完成会议功能
     */
    private String butMeeting           = "0";

    /**
     * 加入任务功能
     */
    private String butAttachJob         = "0";

    /**
     * 监听、退出监听功能
     */
    private String butListen            = "0";

    /**
     * 强插功能
     */
    private String butForceInsert       = "0";

    /**
     * 强拆功能
     */
    private String butForceBackOut      = "0";

    /**
     * 来电号码显示
     */
    private String aniText              = "0";

    /**
     * 去电号码显示
     */
    private String dnisText             = "0";

    /**
     * 当日通话时长
     */
    private String talkTimeText         = "0";

    /**
     * 当前状态停留时长
     */
//    private String currentStateTimeText = "0";

    /**
     * 当日总通话次数
     */
    private String talkCountText        = "0";

    /**
     * 外呼弹出的拨号框
     */
    private String dialFrame            = "0";

    public GuiDisplayBean() {
    }

    public String getButLogin() {
        return butLogin;
    }

    public void setButLogin(String butLogin) {
        this.butLogin = butLogin;
    }

    public String getButOutbound() {
        return butOutbound;
    }

    public void setButOutbound(String butOutbound) {
        this.butOutbound = butOutbound;
    }

    public String getButHangup() {
        return butHangup;
    }

    public void setButHangup(String butHangup) {
        this.butHangup = butHangup;
    }

    public String getButAnswer() {
        return butAnswer;
    }

    public void setButAnswer(String butAnswer) {
        this.butAnswer = butAnswer;
    }

    public String getButDTMF() {
        return butDTMF;
    }

    public void setButDTMF(String butDTMF) {
        this.butDTMF = butDTMF;
    }

    public String getButWorkingStatusOpen() {
        return butWorkingStatusOpen;
    }

    public void setButWorkingStatusOpen(String butWorkingStatusOpen) {
        this.butWorkingStatusOpen = butWorkingStatusOpen;
    }

    public String getButBook() {
        return butBook;
    }

    public void setButBook(String butBook) {
        this.butBook = butBook;
    }

    public String getButHoldon() {
        return butHoldon;
    }

    public void setButHoldon(String butHoldon) {
        this.butHoldon = butHoldon;
    }

    public String getButTransfer() {
        return butTransfer;
    }

    public void setButTransfer(String butTransfer) {
        this.butTransfer = butTransfer;
    }

    public String getButMeeting() {
        return butMeeting;
    }

    public void setButMeeting(String butMeeting) {
        this.butMeeting = butMeeting;
    }

    public String getButAttachJob() {
        return butAttachJob;
    }

    public void setButAttachJob(String butAttachJob) {
        this.butAttachJob = butAttachJob;
    }

    public String getButListen() {
        return butListen;
    }

    public void setButListen(String butListen) {
        this.butListen = butListen;
    }

    public String getButForceInsert() {
        return butForceInsert;
    }

    public void setButForceInsert(String butForceInsert) {
        this.butForceInsert = butForceInsert;
    }

    public String getButForceBackOut() {
        return butForceBackOut;
    }

    public void setButForceBackOut(String butForceBackOut) {
        this.butForceBackOut = butForceBackOut;
    }

    public String getAniText() {
        return aniText;
    }

    public void setAniText(String aniText) {
        this.aniText = aniText;
    }

    public String getDnisText() {
        return dnisText;
    }

    public void setDnisText(String dnisText) {
        this.dnisText = dnisText;
    }

    public String getTalkTimeText() {
        return talkTimeText;
    }

    public void setTalkTimeText(String talkTimeText) {
        this.talkTimeText = talkTimeText;
    }

//    public String getCurrentStateTimeText() {
//        return currentStateTimeText;
//    }
//
//    public void setCurrentStateTimeText(String currentStateTimeText) {
//        this.currentStateTimeText = currentStateTimeText;
//    }

    public String getTalkCountText() {
        return talkCountText;
    }

    public void setTalkCountText(String talkCountText) {
        this.talkCountText = talkCountText;
    }

    public String getDialFrame() {
        return dialFrame;
    }

    public void setDialFrame(String dialFrame) {
        this.dialFrame = dialFrame;
    }

    public String getGuiDisplay() {
        StringBuffer sb = new StringBuffer();
//        sb.append(butLogin);
//        sb.append(butOutbound);
//        sb.append(butHangup);
//        sb.append(butAnswer);
//        sb.append(butDTMF);
//        sb.append(butWorkingStatusOpen);
//        sb.append(butBook);
//        sb.append(butHoldon);
//        sb.append(butTransfer);
//        sb.append(butMeeting);
//        sb.append(butAttachJob);
//        sb.append(butListen);
//        sb.append(butForceInsert);
//        sb.append(butForceBackOut);
//        sb.append(aniText);
//        sb.append(dnisText);
//        sb.append(talkTimeText);
//        sb.append(currentStateTimeText);
//        sb.append(talkCountText);
//        sb.append(dialFrame);
        return sb.toString();
    }

    public static GuiDisplayBean createGuiDisplayBean(String type) {
        return null;
    }
}
