package com.wanjia.base.web;

import javax.servlet.http.HttpServletRequest;

public class IPAddressUtils {

	  static public String getIpAddr(HttpServletRequest request) {
	        String ip = request.getHeader("X-Forwarded-For");
	        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	            ip = request.getHeader("Proxy-Client-IP");
	        }
	        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	            ip = request.getHeader("WL-Proxy-Client-IP");
	        }
	        if (ip == null) {
	            ip = request.getHeader("HTTP_CLIENT_IP");
	        }
	        if (ip == null) {
	            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
	        }
	        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	            ip = request.getRemoteAddr();
	        }
	        String[] ips = ip.split(",");
	        for (int i = 0 ; i < ips.length ; i++) {
	            if (!"unknown".equalsIgnoreCase(ips[i])) {
	                return ips[i];
	            }
	        }
	        return null;
	    }

}
