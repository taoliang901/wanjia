package com.wanjia.base.model;

import java.util.List;

/**
 * EasyUIdatagrid模型
 * @author XUJIE
 *
 */
public class EasyUIDataGridModel<T> {

	long total;
	List<T> rows;
	public long getTotal() {
		return total;
	}
	public List<T> getRows() {
		return rows;
	}
	public void setTotal(long total) {
		this.total = total;
	}
	public void setRows(List<T> rows) {
		this.rows = rows;
	}
	
}

