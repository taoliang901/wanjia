package com.wanjia.base.model;

import java.util.List;

/**
 * EasyUI树结构模型
 * @author XIONGXING
 *
 */
public class EasyUITreeDataModel<T,M> {

	private String id;
	private String text;
	private String state;
	private String iconCls;
	private String checked;
	private M attributes;
	private List<EasyUITreeDataModel<T,M>> children;
	
	public EasyUITreeDataModel(String id,String text){
		this.id = id;
		this.text = text;
	}

	public EasyUITreeDataModel(String id, String text,
			M attributes,
			List<EasyUITreeDataModel<T,M>> children) {
		super();
		this.id = id;
		this.text = text;
		this.attributes = attributes;
		this.children = children;
	}
	
	public EasyUITreeDataModel(String id, String text, String state,
			String iconCls, String checked, 
			M attributes,
			List<EasyUITreeDataModel<T,M>> children) {
		super();
		this.id = id;
		this.text = text;
		this.state = state;
		this.iconCls = iconCls;
		this.checked = checked;
		this.attributes = attributes;
		this.children = children;
	}


	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getIconCls() {
		return iconCls;
	}
	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}
	public String getChecked() {
		return checked;
	}
	public void setChecked(String checked) {
		this.checked = checked;
	}

	public M getAttributes() {
		return attributes;
	}

	public void setAttributes(M attributes) {
		this.attributes = attributes;
	}

	public List<EasyUITreeDataModel<T, M>> getChildren() {
		return children;
	}

	public void setChildren(List<EasyUITreeDataModel<T, M>> children) {
		this.children = children;
	}
}

