package com.wanjia.base;

public class AppletParamBean {

    public static final String CTITYPE_XQD_PCS        = "XQD-PCS";
    public static final String CTITYPE_XQD_GENESYS    = "XQD-GENESYS";
    public static final String CTITYPE_XQD_HW         = "XQD-HW";
    public static final String CTITYPE_XQD_CCOD       = "XQD-CCOD";
    public static final String CTITYPE_XQD_ASPECT     = "XQD-ASPECT";
    public static final String CTITYPE_XQD_ZX         = "XQD-ZX";
    public static final String CTITYPE_XQD_LCC        = "XQD-LCC";

    public static final String DATATYPE_ITS           = "ITS";
    public static final String DATATYPE_TMR_LIFE      = "TMR-LIFE";
    public static final String DATATYPE_CTS           = "CTS";
    public static final String DATATYPE_10            = "10";
    public static final String DATATYPE_RSTP          = "RSTP";

    private String             id;

    private String             roleCode;

    /**
     * applet存放地址
     */
    private String             codebase;

    /**
     * 界面类型,当值为h时,表示界面上按钮排列方式为水平方式;当值为v时,表示界面上按钮排列方式为方型.
     * 默认值为v，无特殊业务要求可不传
     */
    private String             guiFlag                = null;

    /**
     * 电话平台类型，编码以人管为准。
     * PCS：XQD-PCS
     * Genesys： XQD-GENESYS
     * 华为： XQD-HW
     * CCOD：XQD-CCOD
     * Aspect： XQD-ASPECT
     * 中兴： XQD-ZX
     * LCC： XQD-LCC
     * 所有平台均需要传入
     */
    private String             ctiType                = null;

    /**
     * 坐席的工号、分机号，以分号分隔
     * 所有平台均需要传入
     */
    private String             agentInfo              = null;

    /**
     * 业务系列：新渠道产险(ITS) 新渠道寿险（TMR-LIFE），小消（CTS) 信用卡催收(10) 一体机（RSTP）
     * 所有平台均需要传入
     */
    private String             dataType               = null;

    /**
     * 是否需要设置为notreayd的原因(none：不需要设置not ready原因requested：可以设置not ready原因或者不设置forced：强制必须设置not ready的原因
     * 默认值为：None。genesys平台独有参数，非genesys平台可传空
     */
    private String             notReadyReasonCodeType = null;

    /**
     * notreayd的原因(当NotReadyReasonCodeType为forced时必须传入）
     * 默认值为：None。genesys平台独有参数，非genesys平台可传空
     */
    private String             notReadyReasonCode     = null;

    /**
     * 坐席在完成一通通话后，是手动进入ready模式（点击ready按钮），还是是自动进入ready模式，autoin：自动 manualin：手动
     * 默认为：Manualin 目前支持genesys、华为、CCOD、Aspect平台
     */
    private String             agentReadyMode         = null;

    /**
     * out表示外部拨号规则，与后面的拨号规则用分号隔开。拨号规则表示当拨打的号码不满足内部号码规则时，软电话在外拨号码前前缀。
     * pcs（寿险）和genesys需要传入
     */
    private String             dialStringOut          = null;

    /**
     * true：开启acw按钮 false：关闭acw按钮
     * 默认值为true，目前支持华为、CCOD、Aspect平台；Genesys/PCS平台暂不支持此参数，配置为false。
     */
    private String             acwSwitch              = null;

    /**
     * 部署环境。prd:生产环境 stg：测试环境 
     * 默认值为prd
     */
    private String             env                    = null;

    /**
     * PCS默认自动提交结束代码时间，单位为秒
     * pcs自动外呼使用，默认值为15
     */
    private String             sumitEndCodeTime       = null;

    /**
     * PCS默认的结束代码
     * pcs自动外呼使用，默认值为58
     */
    private String             defaultEndCode         = null;

    /**
     * 配置软电话组件显示
     * 具体使用参见GuiDisplayBean.java
     * 此参数代替restrictedAgent、adminFlag、ButDispMode
     */
    private String             guiDisplayString       = null;

    private GuiDisplayBean     guiDisplay;

    /**
     * 程序版本
     */
    private String             version                = null;

    /**
     * 软电话样式
     * 可不传，通过此参数使新软电话做到兼容旧图片风格。传入“union”,加载旧软电话皮肤；不传加载新的软电话皮肤
     */
    private String             buttonStyle            = null;

    private String             stopFlag;

    /**
     * 外呼前缀数字
     */
    private String             outDailNumber          = null;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getCodebase() {
        return codebase;
    }

    public void setCodebase(String codebase) {
        this.codebase = codebase;
    }

    public AppletParamBean() {
    }

    public String getGuiFlag() {
        return guiFlag;
    }

    public void setGuiFlag(String guiFlag) {
        this.guiFlag = guiFlag;
    }

    public String getCtiType() {
        return ctiType;
    }

    public void setCtiType(String ctiType) {
        this.ctiType = ctiType;
    }

    public String getAgentInfo() {
        return agentInfo;
    }

    public void setAgentInfo(String agentInfo) {
        this.agentInfo = agentInfo;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getNotReadyReasonCodeType() {
        return notReadyReasonCodeType;
    }

    public void setNotReadyReasonCodeType(String notReadyReasonCodeType) {
        this.notReadyReasonCodeType = notReadyReasonCodeType;
    }

    public String getNotReadyReasonCode() {
        return notReadyReasonCode;
    }

    public void setNotReadyReasonCode(String notReadyReasonCode) {
        this.notReadyReasonCode = notReadyReasonCode;
    }

    public String getAgentReadyMode() {
        return agentReadyMode;
    }

    public void setAgentReadyMode(String agentReadyMode) {
        this.agentReadyMode = agentReadyMode;
    }

    public String getDialStringOut() {
        return dialStringOut;
    }

    public void setDialStringOut(String dialStringOut) {
        this.dialStringOut = dialStringOut;
    }

    public String getAcwSwitch() {
        return acwSwitch;
    }

    public void setAcwSwitch(String acwSwitch) {
        this.acwSwitch = acwSwitch;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getSumitEndCodeTime() {
        return sumitEndCodeTime;
    }

    public void setSumitEndCodeTime(String sumitEndCodeTime) {
        this.sumitEndCodeTime = sumitEndCodeTime;
    }

    public String getDefaultEndCode() {
        return defaultEndCode;
    }

    public void setDefaultEndCode(String defaultEndCode) {
        this.defaultEndCode = defaultEndCode;
    }

    public String getGuiDisplayString() {
        return guiDisplayString;
    }

    public void setGuiDisplayString(String guiDisplayString) {
        this.guiDisplayString = guiDisplayString;
    }

    public GuiDisplayBean getGuiDisplay() {
        return guiDisplay;
    }

    public void setGuiDisplay(GuiDisplayBean guiDisplay) {
        this.guiDisplay = guiDisplay;
    }

    public String getButtonStyle() {
        return buttonStyle;
    }

    public void setButtonStyle(String buttonStyle) {
        this.buttonStyle = buttonStyle;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getStopFlag() {
        return stopFlag;
    }

    public void setStopFlag(String stopFlag) {
        this.stopFlag = stopFlag;
    }

    public String getOutDailNumber() {
        return outDailNumber;
    }

    public void setOutDailNumber(String outDailNumber) {
        this.outDailNumber = outDailNumber;
    }

    public static AppletParamBean createInstance() {
        AppletParamBean apBean = new AppletParamBean();
        apBean.setGuiFlag("");
        apBean.setCtiType(CTITYPE_XQD_GENESYS);
        apBean.setAgentInfo("");
        apBean.setDataType("");
        apBean.setNotReadyReasonCodeType("");
        apBean.setNotReadyReasonCode("");
        apBean.setAgentReadyMode("");
        apBean.setDialStringOut("");
        apBean.setAcwSwitch("");
        apBean.setEnv("");
        apBean.setSumitEndCodeTime("");
        apBean.setDefaultEndCode("");
        apBean.setGuiDisplayString("");
        apBean.setVersion("");
        apBean.setButtonStyle("");
        return apBean;
    }
}
