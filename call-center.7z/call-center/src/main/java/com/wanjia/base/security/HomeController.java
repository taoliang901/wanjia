package com.wanjia.base.security;


import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.jasig.cas.client.authentication.AttributePrincipal;
import org.jasig.cas.client.util.AbstractCasFilter;
import org.jasig.cas.client.validation.Assertion;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.wanjia.aas.TreeDataModel;
import com.wanjia.aas.bo.UserMenuBean;
import com.wanjia.aas.service.UserMenuService;
import com.wanjia.base.SessionBean;
import com.wanjia.base.consts.SysConstant;
import com.wanjia.ht.bo.HtUser;
import com.wanjia.ht.service.HtUserService;

@Controller
public class HomeController {

	private static final Logger logger = Logger
			.getLogger(HomeController.class);
	
	@Resource(name="htUserService")
	private HtUserService htUserService;
	


	@Resource(name="aas.userMenuService")
	private UserMenuService userMenuService;
	
	private static final String Home_PageUrl  = "home";

	

	/**
	 * 
	 * @param req
	 * @param res
	 */
	@RequestMapping("login")
	@ResponseBody
	public ModelAndView init(HttpServletRequest req,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView(Home_PageUrl);
	//  Map<String, String> param = new HashMap<String, String>();
	//	String userCode = (String)req.getRemoteUser();	
		// 从session中获取cas相关的用户信息：
		Assertion loginUser = (Assertion)req.getSession().getAttribute(AbstractCasFilter.CONST_CAS_ASSERTION);
		AttributePrincipal ap = loginUser.getPrincipal();
		
		// 登录用户名
		String userName = ap.getName();
		// 其它重要属性
		Map<String, Object> userMap = ap.getAttributes();
		String userCode = (String) userMap.get("userCode");
		
		HtUser userBean = htUserService.getUserByUserCode(userCode);
		// 构建sessionbean ----start
		SessionBean sessionBean = new SessionBean();
		sessionBean.setUserId(userBean.getId());
		sessionBean.setName(userBean.getName());
		sessionBean.setUserCode(userBean.getUserCode());
		req.getSession().setAttribute("sessionBean", sessionBean);
		
		req.getSession().setAttribute("userId", userBean.getId());
		req.getSession().setAttribute("userName", userBean.getName());
		req.getSession().setAttribute("userCode", userBean.getUserCode());
		//构建sessionbean ----end
		logger.info("用户 " +userCode+" 构建session信息");
		return mv;
	}

	@RequestMapping("/getMenuList.do")
	@ResponseBody
	public List<TreeDataModel<UserMenuBean>> getMenuList(HttpServletRequest request,
			HttpServletResponse response){

		String userCode = request.getParameter("userCode");		
		List<TreeDataModel<UserMenuBean>> rootList = userMenuService.getUserList(SysConstant.CALLCENTER_PROJECT_NAME, userCode);
		return rootList;
	}
	

}
