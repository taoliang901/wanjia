 $.extend($.fn.validatebox.defaults.rules, {
        /*必须和某个字段相等*/
        equalTo: { validator: function (value, param) { return $(param[0]).val() == value; }, message: "两次输入不一致"},
       
        notEqualTo: { validator: function (value, param) { return $(param[0]).val() != value; }, message: "不能和用户名一致"},
        
		minLength: {
		    validator: function(value, param){
		        return value.length >= param[0];
		    },
		    message:'长度最少为{0}.'
		},
		
		maxLength: {
		    validator: function(value, param){
		        return value.length <= param[0];
		    },
		    message:'长度不能超过{0}.'
		},
		
		isNumAndChar: {
		    validator: function(value, param){
		        return '/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]$/'.test(value);
		    },
		    message: '必须是字母和数字组合.'
		},
		
//		表单密码验证
		formPassword:{
			validator : function(value, param){
				if($(param[0]).val() == value){
					$.fn.validatebox.defaults.rules.formPassword.message = "不能和用户名一致";
					return false;
				}else if(value.length < param[1] || value.length > param[2]){
					$.fn.validatebox.defaults.rules.formPassword.message = "密码长度必须在"+param[1]+"和"+param[2]+"之间";
					return false;
				}else if(!(/[a-zA-Z]+/.test(value) && /[0-9]+/.test(value))){
					$.fn.validatebox.defaults.rules.formPassword.message = '密码必须由数字和字母组成.';
					return false;
				}else{
					return true;
				}
			}
		},
		
		clinicRegisterPwd:{
			validator : function(value, param){
				if($(param[0]).val() == value){
					$.fn.validatebox.defaults.rules.clinicRegisterPwd.message = "不能和用户名一致";
					return false;
				}else if(value.length < param[1] || value.length > param[2]){
					$.fn.validatebox.defaults.rules.clinicRegisterPwd.message = "密码长度必须在"+param[1]+"和"+param[2]+"之间";
					return false;
				}else if(!(/[a-zA-Z]+/.test(value) && /[0-9]+/ ||/_+/.test(value))){
					$.fn.validatebox.defaults.rules.clinicRegisterPwd.message = '密码必须由数字和字母组成.';
					return false;
				}else{
					return true;
				}
			}
		}
 });
 
 