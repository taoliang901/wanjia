/**
 * 计算机电话集成(Computer Telephony Integration) jQuery 插件
 
	"<div>"
	+ "	<applet codebase='http://localhost/applet/'"
	+ "		code='com.paic.softphone.softphoneui.GuiApplet.class'"
	+ "		name='SoftPhoneApplet' width='100%' height='50' hspace='0'"
	+ "		vspace='0' archive='sp_uiGCC-SOFTPHONE1.36.7.jar,sp_genesys_coreGCC-SOFTPHONE1.36.7.jar'>"
	+ "		<param name='CtiType' value='XQD-GENESYS'>"
	+ "		<param name='GuiFlag' value='h'>"
	+ "		<param name='DataType' value='TMR-LIFE'>"
	+ "		<param name='AgentInfo' value='236265;731027'>"
	+ "		<param name='AcwSwitch' value='false'>"
	+ "		<param name='AgentReadyMode' value='Manualin'>"
	+ "		<param name='env' value='stg'>"
	+ "		<param name='guiDisplay' value='1111111122100011111'>"
	+ "	</applet>" + "</div>";
*/

(function($) {
	/**
	 * CtiApplet 对象
	 */
	var CtiApplet = function(element, options) {
		var $_element = $(element);
		var appletObj = null;
		var ctiObj = this;
		var isLogin = false;
		var employeeId = "";
		var extNumber = "";
		
		var settings = {
			height : null,
			width: null,
			employeeId: '',
			applet: {
				codebase : '',
				ctiType : '',
				guiFlag : 'h',
				agentInfo : '',
				acwSwitch : 'false',
				agentReadyMode : 'ddd',
				env : 'stg',
				archive : 'sp_uiGCC-SOFTPHONE1.36.7.jar,sp_genesys_coreGCC-SOFTPHONE1.36.7.jar',
				guiDisplay : {
					butLogin : '1',
					butOutbound : '1',
					butHangup : '1',
					butAnswer : '1',
					butDTMF : '1',
					butWorkingStatusOpen : '1',
					butBook : '1',
					butHoldon : '1',
					butTransfer : '2',
					butMeeting : '2',
					butAttachJob : '1',
					butListen : '0',
					butForceInsert : '0',
					butForceBackOut : '0',
					aniText : '1',
					dnisText : '1',
					talkTimeText : '1',
					talkCountText : '1',
					dialFrame : '2'
				},
				outDailNumber : ""
			},
			initAppletParams : function() {
				return null;
			}
		};

		//=========================test code ==========================
		var debugWindow = null; 
		function debugOut(content) {
			if (debugWindow)
			debugWindow.document.write("<div><pre>" + content + "</pre></div>");
		}
		
		function createDebugWindow() {
			debugWindow = window.open("/cti/openDebugWindow.do", "debugWindow");
		}
		
		//=========================test code==========================
		
		
		function _init() {
			settings = $.extend(true, settings, options);
			$_element.append(createLoginElement());
		}

		/**
		 * 页面录入 applet 初始信息
		 * @returns
		 */
		function createLoginElement() {
			var divObj = createHtmlElement("div", {"class": "ctiLoginDiv"});
			
			//工号和分机号码置于一个div中
			var divObj1 = createHtmlElement("div", {"class": "ctiInputDiv"});
			divObj.appendChild(divObj1);
			var span2 = createHtmlElement("span", {type: 'text'});
			$(span2).text("工号：");
			divObj1.appendChild(span2);
			divObj1.appendChild(createHtmlElement("input",{type: 'text', id : "ctiEmployeeId"}));
			var span1 = createHtmlElement("span",{type: 'text'});
			$(span1).text("分机号码：");
			divObj1.appendChild(span1);
			divObj1.appendChild(createHtmlElement("input",{type: 'text', id : "ctiExtNumberId"}));
			
			//登录按钮置于一个div中
			var divObj2 = createHtmlElement("div", {"class": "ctiInputDiv"});
			divObj.appendChild(divObj2);
			var ctiLoginBtn = createHtmlElement("input",{type: 'button', value: '登入', id: 'ctiLoginButtonId'});
			divObj2.appendChild(ctiLoginBtn);

			$(ctiLoginBtn).bind({
				click : function(event) { 
					extNumber = $("#ctiExtNumberId", divObj).val();
					employeeId = $("#ctiEmployeeId", divObj).val();
					appletObj = createAppletElement();
					if (appletObj != null) {
						$(divObj).remove();
						$_element.append(appletObj);
						/*createDebugWindow();
						window.focus();
						debugOut("Debug Window");
						debugOut("========== ========== ========== ========== ");*/
					}
				}
			});

			return divObj;
		}

		/**
		 * 初始化 applet 参数
		 * @param extNumber
		 */
		function _initAppletParams() {
			var appletParams = settings.initAppletParams(options);
			if (options.applet != undefined) {
				appletParams = $.extend(true, appletParams != null ? appletParams : {}, options.applet);
			}
			if (appletParams != null) {
				settings.applet = $.extend(true, settings.applet, appletParams);
				if ($.trim(appletParams.version) != "") {
					settings.applet.archive = "sp_ui" + appletParams.version + ".jar,sp_genesys_core" + appletParams.version + ".jar";
				}
//				settings.applet.agentInfo += ";" + extNumber;
				settings.applet.agentInfo = employeeId + ";" + extNumber;
			} else {
				return false;
			}
			return true;
		}

		/**
		 * 在页面上生成 applet 
		 * @param extNumber
		 * @returns
		 */
		function createAppletElement() {
			if (_initAppletParams() == false) {
				return null;
			}
			/*var appletDiv = createHtmlElement("div", {"class": "ctiAppletDiv"});
			// 注销并返回登录
			var backToLoginBtn = createHtmlElement("div", {"class": "ctiBackLoginBtn"});
			$(backToLoginBtn).html("重新<br/>登录");
			appletDiv.appendChild(backToLoginBtn);
			$(backToLoginBtn).bind({
				click:function(event){
					if(!confirm("是否重新登录？")){
						return;
					}
					_logout();
					$(appletDiv).remove();
					$_element.append(createLoginElement());
				}
			});*/
			var obj = createHtmlElement("applet", {
				codebase : settings.applet.codebase,
				height : settings.height,
				width : settings.width,
				code : 'com.paic.softphone.softphoneui.GuiApplet.class',
				name : 'WanjiaSoftPhoneApplet',
				hspace : '0',
				vspace : '0',
				archive : settings.applet.archive,
				style : "z-index:-1; float: left;"
			});
			var guiDisplay = "";
			$.each(settings.applet.guiDisplay, function(n, v){
				guiDisplay += v;
			});
			obj.appendChild(createHtmlElement("param", {name : 'CtiType', value : settings.applet.ctiType}));
			obj.appendChild(createHtmlElement("param", {name : 'GuiFlag', value : settings.applet.guiFlag}));
			obj.appendChild(createHtmlElement("param", {name : 'DataType', value : settings.applet.dataType}));
			obj.appendChild(createHtmlElement("param", {name : 'AgentInfo', value : settings.applet.agentInfo}));
			if (settings.applet.acwSwitch != "") {
				obj.appendChild(createHtmlElement("param", {name : 'AcwSwitch', value : settings.applet.acwSwitch}));
			}
			if (settings.applet.agentReadyMode != "") {
				obj.appendChild(createHtmlElement("param", {name : 'AgentReadyMode', value : settings.applet.agentReadyMode}));
			}
			if (settings.applet.dialStringOut != "") {
				obj.appendChild(createHtmlElement("param", {name : 'DialString_Out', value : settings.applet.dialStringOut}));
			}
			if (settings.applet.notReadyReasonCodeType != "") {
				obj.appendChild(createHtmlElement("param", {name : 'NotReadyReasonCodeType', value : settings.applet.notReadyReasonCodeType}));
			}
			if (settings.applet.notReadyReasonCode != "") {
				obj.appendChild(createHtmlElement("param", {name : 'NotReadyReasonCode', value : settings.applet.notReadyReasonCode}));
			}
			if (settings.applet.sumitEndCodeTime != "") {
				obj.appendChild(createHtmlElement("param", {name : 'SumitEndCodeTime', value : settings.applet.sumitEndCodeTime}));
			}
			if (settings.applet.defaultEndCode != "") {
				obj.appendChild(createHtmlElement("param", {name : 'DefaultEndCode', value : settings.applet.defaultEndCode}));
			}
			if (settings.applet.buttonStyle != "") {
				obj.appendChild(createHtmlElement("param", {name : 'ButtonStyle', value : settings.applet.buttonStyle}));
			}
			obj.appendChild(createHtmlElement("param", {name : 'env', value : settings.applet.env}));
			obj.appendChild(createHtmlElement("param", {name : 'guiDisplay', value : guiDisplay}));
			return obj;
		}

		/**
		 * 生成html元素
		 * @param elementName 元素名称
		 * @param attrs 属性
		 * @returns
		 */
		function createHtmlElement(elementName, attrs) {
			var elementObj = document.createElement(elementName);
			if (attrs != undefined && attrs != null) {
				$.each(attrs, function(n, v) {
					if (v != null) {
						$(elementObj).attr(n, v);
					}
				});
			}
			return elementObj;
		}

		/**
		 * 电话呼入事件
		 * @param callNumber
		 */
		function _callInEvent(callNumber) {
			if (settings.callInEvent) {
				settings.callInEvent(callNumber, ctiObj);
			}
		}

		/**
		 * 电话挂断事件
		 */
		function _releasedEvent() {
			if (settings.releasedEvent) {
				settings.releasedEvent(ctiObj);
			}
		}
		
		/**
		 * 接通电话事件
		 */
		function _establishedEvent() {
			if (settings.establishedEvent) {
				settings.establishedEvent(ctiObj);
			}
		}
		
		/**
		 * 检查控件状态
		 * @returns {String}
		 */
		function _checkCti() {
			if (appletObj == null) {
				return "软电话控件没有运行！";
			}
			if (isLogin == false) {
				return "软电话没有登入！";
			}
			return "";
		}
		
		function _setDialNumber(phonenum) {
			appletObj.TxnProcess("SetDialNumber", phonenum);
		}
		
		function _login() {
			appletObj.TxnProcess("agentLogin", "true;" + employeeId + ";" + extNumber);
		}
		
		function _logout() {
			if (appletObj != null && isLogin == true) {
				appletObj.TxnProcess("agentLogout",null);
			}
		}
		
		/**
		 * 接受 applet 事件，调用对应的事件方法
		 */
		this.outerEvent = function (eventName) {
//			debugOut(eventName);
			if (eventName == "EventRinging") {
				var callNumber = ctiObj.getIncomingCallNumber();
				_callInEvent(callNumber);
			}
			// 接通后挂断
			else if (eventName == "EventReleased") {
				_releasedEvent();
			}
			// 未接通对方挂断
			else if (eventName == "EventAbandoned") {
				_releasedEvent();
			}
			// 软电话签入
			else if (eventName == "EventAgentLogin") {
				isLogin = true;
			}
			// 软电话签出
			else if (eventName == "EventAgentLogout") {
				isLogin = false;
			}
			// 软电话与服务器建立链接
			else if (eventName == "EventLinkConnected") {
				setTimeout(_login, 50);
			}
			// 电话接通
			else if (eventName == "EventEstablished") {
				_establishedEvent();
			}
		};

		// public function
		this.login = function() {
			_login();
		};

		/**
		 * 拨打电话
		 * callNumber 电话号码
		 */
		this.call = function(callNumber, addZero) {
			var checkCti = _checkCti();
			if (checkCti != "") {
				alert(checkCti);
				return false;
			}
			if (!callNumber || $.trim(callNumber) == "") {
				alert("电话号码为空！");
				return false;
			}
			if (addZero == true) {
				callNumber = "0" + callNumber;
			}
			return appletObj.TxnProcess("dialCall", callNumber);
		};

		/**
		 * 弹出拨号窗口
		 * callNumber 电话号码
		 */
		this.callDialog = function(callNumber) {
			appletObj.TxnProcess("popUpDialDialog", callNumber); 
		};

		/**
		 * 接听来电
		 */
		this.answerCall = function() {
			return appletObj.TxnProcess("answerCall", null);
		};

		/**
		 * 获取通话信息
		 */
		this.getCallInfo = function(param) {
			return appletObj.TxnProcess("getCallInfo", param);
		};

		/**
		 * 获取呼入电话号码
		 */
		this.getIncomingCallNumber = function() {
			var callNumber = appletObj.TxnProcess("getCallInfo", "ani");
			if (callNumber && callNumber != "" && callNumber.charAt(0) == '0') {
				callNumber = callNumber.substring(1);
			}
			return callNumber;
		};

		this.setDialNumber = function(phonenum) {
			_setDialNumber(phonenum);
		};
		
		this.logout = function() {
			_logout();
		};
		
		_init();
	};

	/**
	 * 获取 cti jQuery 对象,如果是弹出窗户，从父窗口获取。
	 */
	$.cti = function () {
		if (cti != null) {
			return cti;
		}
		if (window.opener && window.opener.$.cti() != null) {
			return window.opener.$.cti();
		}
		return null;
	};

	CtiApplet.codebase = {
		stg : "http://softphone-stg.paic.com.cn/gccsoftphone/unionAllPhoneFlat/",
		prd : "http://softphone.paic.com.cn/gccsoftphone/unionAllPhoneFlat/"
	};

	$.fn.createCtiApplet = function(options) {
		cti = new CtiApplet(this, options);
	};

	var cti = null;
}(jQuery));

function callByApplet(eventName) {
	$.cti().outerEvent(eventName);
}
