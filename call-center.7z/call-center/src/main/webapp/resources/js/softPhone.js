/**
 * 计算机电话集成(Computer Telephony Integration) jQuery 插件
 
	"<div>"
	+ "	<applet codebase='http://localhost/applet/'"
	+ "		code='com.paic.softphone.softphoneui.GuiApplet.class'"
	+ "		name='SoftPhoneApplet' width='100%' height='50' hspace='0'"
	+ "		vspace='0' archive='sp_uiGCC-SOFTPHONE1.36.7.jar,sp_genesys_coreGCC-SOFTPHONE1.36.7.jar'>"
	+ "		<param name='CtiType' value='XQD-GENESYS'>"
	+ "		<param name='GuiFlag' value='h'>"
	+ "		<param name='DataType' value='TMR-LIFE'>"
	+ "		<param name='AgentInfo' value='236265;731027'>"
	+ "		<param name='AcwSwitch' value='false'>"
	+ "		<param name='AgentReadyMode' value='Manualin'>"
	+ "		<param name='env' value='stg'>"
	+ "		<param name='guiDisplay' value='1111111122100011111'>"
	+ "	</applet>" + "</div>";
*/

function showNumber(){
	var a = $.cti().getCallInfo("ani");
}

	