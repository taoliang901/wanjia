//Date的操作方法
var dateUtil = {

		/**
		 * 1.获取当前时间
		 * @returns
		 */
		getDate : function() {
			return new Date();
		},

		/**
		 * 2.获取时间戳
		 * @param _date: 代表传入的日期
		 * @returns
		 */
		getTime : function(_date) {
			if(_date === undefined) {
				return dateUtil.getDate().valueOf();
			}
			return _date.valueOf();
		},

		/**
		 * 3.根据指定格式获取日期[默认格式为: yyyy-MM-dd HH:mm:ss]
		 * @param _date  : 日期
		 * @param _format: 日期格式
		 */
		getFormatDate : function(_date, _format) {
			if(_format === undefined) {
				_format = "yyyy-MM-dd HH:mm:ss";
			}
			var z = { y:_date.getFullYear(), M:_date.getMonth() + 1, d:_date.getDate(), H:_date.getHours(), m:_date.getMinutes(), s:_date.getSeconds() };
			return _format.replace(/(y+|M+|d+|H+|m+|s+)/g, function(v) {
				return ((v.length > 1 ? "0" : "") + eval('z.'+v.slice(-1))).slice(-(v.length>2?v.length:2));
			});
		},

		/**
		 * 4.时钟函数
		 * @param _clockId: 显示时间的控件的ID
		 * @param _format : 日期格式
		 */
		clock : function(_clockId, _format) {
			var clockId = document.getElementById(_clockId);
			clockId.innerHTML = dateUtil.getFormatDate(new Date(), _format);
			window.setTimeout("dateUtil.clock('" + _clockId + "')", 1000);
		},

		/**
		 * 5.将字符串时间转为Date
		 * @param _dateStr : 字符串时间
		 * @param _format  : 字符串格式[目前支持(yyyy-MM-dd HH:mm:ss)]
		 */
		format : function(_dateStr, _format) {
			_dateStr = Date.parse(_dateStr.replace(/-/g, "/"));
			var _date = new Date(_dateStr);
			return _date;
		},

		/**
		 * 6.比较时间大小[-1: _date1 < _date2 / 0: _date1 = _date2 / 1: _date1 > _date2]
		 * @param _date1
		 * @param _date2
		 * @return
		 */
		compareDate : function(_date1, _date2) {
			var _datetime1 = _date1.getTime();
			var _datetime2 = _date2.getTime();
			if(_datetime1 < _datetime2) {
				return -1;
			}
			else if(_datetime1 === _datetime2) {
				return 0;
			}
			else if(_datetime1 > _datetime2) {
				return 1;
			}
		},

		/**
		 * 7.获取指定时间加上指定的分钟数
		 * @param _date	:	日期
		 * @param _hour	:	加上的分钟
		 * @returns
		 */
		getDateAddMin : function(_date, _min) {
			if(_date === undefined || _date === '') {
				_date = dateUtil.getDate();
			}
			if(_min === undefined || _min === '') {
				_min = 0;
			}
			_date.setMinutes(_date.getMinutes() + _min);
			return _date;
		},

		/**
		 * 8.获取指定时间加上指定的小时数
		 * @param _date	:	日期
		 * @param _hour	:	加上的小时
		 * @returns
		 */
		getDateAddHour : function(_date, _hour) {
			if(_date === undefined || _date === '') {
				_date = dateUtil.getDate();
			}
			if(_hour === undefined || _hour === '') {
				_hour = 0;
			}
			_date.setHours(_date.getHours() + _hour);
			return _date;
		},

		/**
		 * 9.获取指定时间加上指定的月数
		 * @param _date		:	日期
		 * @param _month	:	加上的月数
		 * @returns
		 */
		getDateAddMonth : function(_date, _month) {
			if(_date === undefined || _date === '') {
				_date = dateUtil.getDate();
			}
			if(_month === undefined || _month === '') {
				_month = 0;
			}
			_date.setMonth(_date.getMonth() + _month);
			return _date;
		}
};