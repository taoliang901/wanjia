package com.pahaoche.base.interceptor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.bind.PropertyException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.executor.ErrorContext;
import org.apache.ibatis.executor.ExecutorException;
import org.apache.ibatis.executor.statement.BaseStatementHandler;
import org.apache.ibatis.executor.statement.RoutingStatementHandler;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.mapping.ParameterMode;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.property.PropertyTokenizer;
import org.apache.ibatis.scripting.xmltags.ForEachSqlNode;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.type.TypeHandler;
import org.apache.ibatis.type.TypeHandlerRegistry;

/**
 * 覆盖common目录下的PagePlugin，功能如下： <br>
 * 1、分页（该功能废弃，使用github分页插件）； <br>
 * 2、财务SQL日志输出； <br>
 * 3、SQL执行耗时报警； <br>
 */
@Intercepts({@Signature(type=StatementHandler.class,method="prepare",args={Connection.class})})
public class PagePlugin_for_CW implements Interceptor {
	private static final Log logger = LogFactory.getLog(PagePlugin_for_CW.class) ;
	private static String dialect = "";	//数据库方言
	private static String pageSqlId = ""; //mapper.xml中需要拦截的ID(正则匹配)
	private static long runTimeMax = 0;  //SQL执行耗时报警（单位：毫秒）
	
	public Object intercept(Invocation ivk) throws Throwable {

		long t_start = (new Date()).getTime();	//SQL执行开始时间
		String statementId = "";

		if(ivk.getTarget() instanceof RoutingStatementHandler){
			RoutingStatementHandler statementHandler = (RoutingStatementHandler)ivk.getTarget();
			BaseStatementHandler delegate = (BaseStatementHandler) ReflectHelper.getValueByFieldName(statementHandler, "delegate");
			MappedStatement mappedStatement = (MappedStatement) ReflectHelper.getValueByFieldName(delegate, "mappedStatement");
			// 1、SQL日志打印
			logSql(mappedStatement.getConfiguration(),delegate.getBoundSql());
			statementId = mappedStatement.getId();
			
			// 2、分页
//			if(mappedStatement.getId().matches(pageSqlId)){ //拦截需要分页的SQL
//				BoundSql boundSql = delegate.getBoundSql();
//				Object parameterObject = boundSql.getParameterObject();//分页SQL<select>中parameterType属性对应的实体参数，即Mapper接口中执行分页方法的参数,该参数不得为空
//				if(parameterObject==null){
//					throw new NullPointerException("parameterObject尚未实例化！");
//				}else{
//					Connection connection = (Connection) ivk.getArgs()[0];
//					String sql = boundSql.getSql();
//					String countSql = "select count(0) from (" + sql+ ") tmp_count"; //记录统计
//					PreparedStatement countStmt = connection.prepareStatement(countSql);
//					BoundSql countBS = new BoundSql(mappedStatement.getConfiguration(),countSql,boundSql.getParameterMappings(),parameterObject);
//					setParameters(countStmt,mappedStatement,countBS,parameterObject);
//					ResultSet rs = countStmt.executeQuery();
//					Long count = 0l;
//					if (rs.next()) {
//						count = rs.getLong(1);
//					}
//					rs.close();
//					countStmt.close();
//					Map map = null;
//					if(parameterObject instanceof Map){	//参数就是Page实体
//						 map = (Map) parameterObject;
//						 map.put("totalCount",count );
//					}
//					Class c = Class.forName(dialect);
//					Dialect dialect = (Dialect)c.newInstance();
//					if(map == null) {
//						throw new RuntimeException("分页查询仅支持 map 作为查询条件！");
//					}
//					ReflectHelper.setValueByFieldName(boundSql, "sql", dialect.getLimitString(sql,Integer.valueOf(map.get("offset").toString()) ,Integer.valueOf(map.get("pageSize").toString()) )); //将分页sql语句反射回BoundSql.
//				}
//			}
		}
		Object res = ivk.proceed();

		// 3、SQL执行时间过长报警
		long t_end = (new Date()).getTime();	//SQL执行开始时间
		long t_used = t_end-t_start;
		String warnMsg = "SQL【"+statementId+"】执行共花费了"+t_used+"毫秒。";
		if(runTimeMax>0 && t_used>runTimeMax) {
			logger.error("警告："+warnMsg);
		} else {
			logger.info(warnMsg);
		}

		return res;
	}

	
	/**
	 * 对SQL参数(?)设值,参考org.apache.ibatis.executor.parameter.DefaultParameterHandler
	 * @param ps
	 * @param mappedStatement
	 * @param boundSql
	 * @param parameterObject
	 * @throws SQLException
	 */
	private void setParameters(PreparedStatement ps,MappedStatement mappedStatement,BoundSql boundSql,Object parameterObject) throws SQLException {
		ErrorContext.instance().activity("setting parameters").object(mappedStatement.getParameterMap().getId());
		List<ParameterMapping> parameterMappings = boundSql.getParameterMappings();
		if (parameterMappings != null) {
			Configuration configuration = mappedStatement.getConfiguration();
			TypeHandlerRegistry typeHandlerRegistry = configuration.getTypeHandlerRegistry();
			MetaObject metaObject = parameterObject == null ? null: configuration.newMetaObject(parameterObject);
			for (int i = 0; i < parameterMappings.size(); i++) {
				ParameterMapping parameterMapping = parameterMappings.get(i);
				if (parameterMapping.getMode() != ParameterMode.OUT) {
					Object value;
					String propertyName = parameterMapping.getProperty();
					PropertyTokenizer prop = new PropertyTokenizer(propertyName);
					if (parameterObject == null) {
						value = null;
					} else if (typeHandlerRegistry.hasTypeHandler(parameterObject.getClass())) {
						value = parameterObject;
					} else if (boundSql.hasAdditionalParameter(propertyName)) {
						value = boundSql.getAdditionalParameter(propertyName);
					} else if (propertyName.startsWith(ForEachSqlNode.ITEM_PREFIX)&& boundSql.hasAdditionalParameter(prop.getName())) {
						value = boundSql.getAdditionalParameter(prop.getName());
						if (value != null) {
							value = configuration.newMetaObject(value).getValue(propertyName.substring(prop.getName().length()));
						}
					} else {
						value = metaObject == null ? null : metaObject.getValue(propertyName);
					}
					TypeHandler typeHandler = parameterMapping.getTypeHandler();
					if (typeHandler == null) {
						throw new ExecutorException("There was no TypeHandler found for parameter "+ propertyName + " of statement "+ mappedStatement.getId());
					}
					typeHandler.setParameter(ps, i + 1, value, parameterMapping.getJdbcType());
				}
			}
		}
	}
	
	@SuppressWarnings("rawtypes")
	private void logSql(Configuration conf ,BoundSql boundSql){		
		logger.info("");
		logger.info("boundSql:"+removeBreakingWhitespace(boundSql.getSql()));
		// Junit单元测试时放开，方可在控制台中正常输出SQL
//		System.err.println("");
//		System.err.println("boundSql:"+removeBreakingWhitespace(boundSql.getSql()));
		Object parameterObject = boundSql.getParameterObject();	
		if(parameterObject!=null){
			if(parameterObject instanceof Map){
				String boundParams = "boundParams:";				
				Map map = (Map)parameterObject;				
				Set keySet = map.keySet();
				Iterator iter = keySet.iterator();
				while(iter.hasNext()){
					Object key = iter.next();
					boundParams = boundParams + (String.valueOf(""+key)+"="+String.valueOf(""+map.get(key))+";");
				}
				logger.info(boundParams);
				// Junit单元测试时放开，方可在控制台中正常输出SQL
//				System.err.println(boundParams);
			}else{
				try{
					logger.info("boundParams:"+parameterObject);
					// Junit单元测试时放开，方可在控制台中正常输出SQL
//					System.err.println("boundParams:"+parameterObject);
				}catch(Exception ex){
					//部分类的toString()方法执行有错误，在此作拦截
					logger.error("boundParams class Error:"+parameterObject.getClass());
					// Junit单元测试时放开，方可在控制台中正常输出SQL
//					System.err.println("boundParams class Error:"+parameterObject.getClass());
				}
			}
		}
		logger.info("");
		// Junit单元测试时放开，方可在控制台中正常输出SQL
//		System.err.println("");
	}
	
	private String removeBreakingWhitespace(String original) {
	    StringTokenizer whitespaceStripper = new StringTokenizer(original);
	    StringBuilder builder = new StringBuilder();
	    while (whitespaceStripper.hasMoreTokens()) {
	      builder.append(whitespaceStripper.nextToken());
	      builder.append(" ");
	    }
	    return builder.toString();
	  }
	
	public Object plugin(Object arg0) {
		return Plugin.wrap(arg0, this);
	}

	public void setProperties(Properties p) {
//		dialect = p.getProperty("dialect");
//		if (StringUtils.isBlank(dialect)) {
//			try {
//				throw new PropertyException("dialect property is not found!");
//			} catch (PropertyException e) {
//				logger.info("属性设置异常", e);
//			}
//		}
		pageSqlId = p.getProperty("pageSqlId");
		if (StringUtils.isBlank(pageSqlId)) {
			try {
				throw new PropertyException("pageSqlId property is not found!");
			} catch (PropertyException e) {
				logger.info("属性获取异常", e);
			}
		}

		String runTimeMaxStr = p.getProperty("runTimeMax");
		if (StringUtils.isBlank(runTimeMaxStr)) {
			try {
				throw new PropertyException("runTimeMax property is not found!");
			} catch (PropertyException e) {
				logger.info("属性获取异常", e);
			}
		} else {
			runTimeMax = Long.parseLong(runTimeMaxStr);
		}
		
	}
	
}
