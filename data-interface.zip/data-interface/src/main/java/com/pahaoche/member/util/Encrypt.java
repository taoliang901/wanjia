package com.pahaoche.member.util;

import java.io.UnsupportedEncodingException;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONException;
import org.json.JSONObject;

public class Encrypt {

	public static String encrypt(String input, String key) {
		byte[] crypted = null;
		try {
			SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, skey);
			crypted = cipher.doFinal(input.getBytes());
		} catch (Exception e) {
			System.err.println("encrypt error:" + e);
		}
		return new String(Base64.encodeBase64(crypted));
	}
	
	public static String Base64Encode(String param, String code) {
		byte[] bytes = null;
		try {
			bytes = param.getBytes(code);
		} catch (UnsupportedEncodingException e) {
		}
		String base64 = new String(new Base64().encode(bytes));
		return base64;
	}
	
	public static void main(String[] args) throws JSONException {
//		System.out.println(encrypt("", "1H8Se67XDE234lBm"));
		 JSONObject dataJson = new JSONObject();
	            dataJson.put("appId", "P23000"); //平台编号，车主APP：P190000
	            dataJson.put("screenId", ""); //为空就好，登陆入口标志
	            dataJson.put("servType", "0001"); // 流水号，待生成
	            dataJson.put("seqNo", ""); // 流水号，待生成
	            dataJson.put("backURL", ""); // 回调地址，待确定       
	            dataJson.put("isLogin", "00"); // 新增字段 
	           System.out.println("datajson:" + dataJson.toString());
	           String md5DataStr = Tools.getMD5Str(dataJson.toString()); 
	           System.out.println(Encrypt.encrypt(md5DataStr, "111111"));
	}

}
