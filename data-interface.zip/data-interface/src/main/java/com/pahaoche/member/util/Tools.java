/*
 *  @author 陈雨茂
 * 	@date 2014/03/31
 */
package com.pahaoche.member.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * The Class Tools.
 */
public class Tools {
	
    private static Logger logger = Logger.getLogger(Tools.class);
	/** The Constant charBase. */
	public static final char[] charBase = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
	
	/**
	 * 检测字符串是否不为空(null,"","null").
	 *
	 * @param s the s
	 * @return 不为空则返回true，否则返回false
	 */
	public static boolean notEmpty(String s) {
		return s != null && !"".equals(s) && !"null".equals(s);
	}

	/**
	 * 检测字符串是否为空(null,"","null").
	 *
	 * @param s the s
	 * @return 为空则返回true，不否则返回false
	 */
	public static boolean isEmpty(String s) {
		return s == null || "".equals(s) || "null".equals(s);
	}

	/**
	 * Gets the m d5 str.
	 *
	 * @param pwd the pwd
	 * @return the m d5 str
	 */
	public static String getMD5Str(String pwd) {
		MessageDigest messageDigest = null;
		try {
			messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.reset();
			messageDigest.update(pwd.getBytes("UTF-8"));
		} catch (NoSuchAlgorithmException e) {
			// System.out.println("NoSuchAlgorithmException caught!");
			// logger.info("不支持的算法", e);
		} catch (UnsupportedEncodingException e) {
			// logger.info("不支持的字符",e);
			// e.printStackTrace();
		}
		StringBuffer md5StrBuff = new StringBuffer();

		if(messageDigest!=null){
			byte[] byteArray = messageDigest.digest();
			for (int i = 0; i < byteArray.length; i++) {
				if (Integer.toHexString(0xFF & byteArray[i]).length() == 1)
					md5StrBuff.append("0").append(
							Integer.toHexString(0xFF & byteArray[i]));
				else
					md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));
			}
		}
		return md5StrBuff.toString();
	}

	/**
	 * 获取BASE64编码.
	 *
	 * @param message the message
	 * @return the BAS e64
	 */
	public static String getBASE64(String message) {
		if (message == null)
			return null;
		return (new sun.misc.BASE64Encoder()).encode(message.getBytes());
	}

	/*
	 * public static void smsSender() throws Exception{
	 * 
	 * URL url = new URL("http://message.i-che.net/ReceiveMessageServlet");
	 * URLConnection connection = url.openConnection();
	 * 
	 * connection.setDoOutput(true);
	 * 
	 * OutputStreamWriter out = new OutputStreamWriter(connection
	 * .getOutputStream(), "8859_1"); // md5(self::$key.$data[
	 * 'time'].$data['clientId'].$data['telNum'].$data['message'])
	 * 
	 * String date=new Date().toString(); String
	 * sms=("jinkedaikuanwangdiang123456.2013-02-11.6.18817239226."
	 * +Tools.getBASE64("jlksdjflksjdflk")); String md5=Tools.getMD5Str(sms);
	 * out.write(md5); //post的关键所在！ // remember to clean up out.flush();
	 * out.close();
	 * 
	 * // 一旦发送成功，用以下方法就可以得到服务器的回应： String sCurrentLine; String sTotalString;
	 * sCurrentLine = ""; sTotalString = ""; InputStream l_urlStream;
	 * l_urlStream = connection.getInputStream(); BufferedReader l_reader = new
	 * BufferedReader(new InputStreamReader( l_urlStream)); while ((sCurrentLine
	 * = l_reader.readLine()) != null) { sTotalString += sCurrentLine + "\r\n";
	 * 
	 * } System.out.println(sTotalString); }
	 * 
	 * 
	 * @Test public void testGetBase() throws Exception{ Tools.smsSender(); }
	 */
	
	/**
	 * 据Unicode编码计算字符长度.
	 *
	 * @author Y.K
	 * DATE:2014-2-25
	 * @param s the s
	 * @return the word count
	 */
	public static int getWordCount(String s)
    {
        s = s.replaceAll("[^\\x00-\\xff]", "**");
        int length = s.length();
        return length;
    }

    /**
     * 万里通数据加密规则
     * @param dataJson 原始JSON
     * @param secretKey 密钥
     * @return
     * @throws JSONException
     */
    public static String wltEncrypt(JSONObject dataJson, String secretKey) throws JSONException {
        String md5DataStr = getMD5Str(dataJson.toString()); // 先md5加密一次
        String jiami = Encrypt.encrypt(md5DataStr, secretKey);//测试环境密钥，生产环境待分配

        JSONObject signJson = new JSONObject();
        signJson.put("value", jiami);
        signJson.put("type", "00");

        JSONObject paramJson = new JSONObject();
        paramJson.put("data", dataJson);
        paramJson.put("sign", signJson);

        logger.debug("------------Tools.wltEncrypt------------");
        return Encrypt.Base64Encode(paramJson.toString(), "UTF-8");
    }

    /**
     * 万里通数据加密规则
     * @param dataJson 原始JSON
     * @param secretKey 密钥
     * @return
     * @throws JSONException
     */
    public static String[] wltEncrypt(String dataJson, String secretKey) throws JSONException {
        String[] rtn = new String[2];
        String md5DataStr = getMD5Str(dataJson.toString()); // 先md5加密一次
        String jiami = Encrypt.encrypt(md5DataStr, secretKey);//测试环境密钥，生产环境待分配

        //		JSONObject signJson = new JSONObject();
        //		signJson.put("value", jiami);
        //		signJson.put("type", "00");
        //		
        //		JSONObject paramJson = new JSONObject();
        //		paramJson.put("data", dataJson);
        //		paramJson.put("sign", signJson);

        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"value\":\"").append(jiami).append("\",");
        sb.append("\"type\":\"").append("00").append("\"");
        sb.append("}");

        StringBuilder builder = new StringBuilder();
        builder.append("{");
        builder.append("\"data\":").append(dataJson).append(",");
        builder.append("\"sign\":").append(sb.toString());
        builder.append("}");
        logger.debug("------------Tools.builder------------");
        rtn[0] = builder.toString();
        rtn[1] = Encrypt.Base64Encode(builder.toString(), "UTF-8");
        return rtn;
    }

}
