package com.wanjia.http.pamap.utils;

import java.security.MessageDigest;

import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

public class EncryptUtil {

	private static Logger logger = Logger.getLogger(EncryptUtil.class);

	public static final String KEY_SHA = "SHA";
	public static final String KEY_MD5 = "MD5";

	/**
	 * MAC算法可选以下多种算法
	 * 
	 * <pre>
	 * HmacMD5 
	 * HmacSHA1 
	 * HmacSHA256 
	 * HmacSHA384 
	 * HmacSHA512
	 * </pre>
	 */
	public static final String KEY_MAC = "HmacMD5";

	/**
	 * @Title: decryptBASE64
	 * @Description: BASE64解码
	 * @param srcStr
	 *            源字符串
	 * @return byte[] 解码后的字节数组
	 * @throws Exception
	 *             byte[]
	 */
	public static byte[] decryptBASE64(String srcStr) {
		return Base64.decodeBase64(srcStr);
	}

	/**
	 * @Title: encryptBASE64
	 * @Description: BASE64编码
	 * @param srcBytes
	 *            源字节数组
	 * @return String 编码后的字符串
	 * @throws Exception
	 *             String
	 */
	public static String encryptBASE64(byte[] srcBytes) throws Exception {
		return Base64.encodeBase64String(srcBytes);
	}

	/**
	 * @Title: encryptMD5
	 * @Description: MD5散列
	 * @param data
	 * @return
	 * @throws Exception
	 *             byte[]
	 */
	public static byte[] encryptMD5(byte[] data) throws Exception {
		MessageDigest md5 = MessageDigest.getInstance(KEY_MD5);
		md5.update(data);
		return md5.digest();
	}

	/**
	 * @Title: encryptSHA
	 * @Description: SHA散列
	 * @param data
	 * @return
	 * @throws Exception
	 *             byte[]
	 */
	public static byte[] encryptSHA(byte[] data) throws Exception {
		MessageDigest sha = MessageDigest.getInstance(KEY_SHA);
		sha.update(data);
		return sha.digest();
	}

	/**
	 * @Title: initMacKey
	 * @Description: 初始化HMAC密钥
	 * @return
	 * @throws Exception
	 *             String
	 */
	public static String initMacKey() throws Exception {
		KeyGenerator keyGenerator = KeyGenerator.getInstance(KEY_MAC);
		SecretKey secretKey = keyGenerator.generateKey();
		return encryptBASE64(secretKey.getEncoded());
	}

	/**
	 * 
	 * @Title: encryptHMAC
	 * @Description: HMAC加密
	 * @param data
	 * @param key
	 * @return
	 * @throws Exception
	 *             byte[]
	 */
	public static byte[] encryptHMAC(byte[] data, String key) throws Exception {
		logger.info("【数据长度为：" + data.length + "】，key内容为：" + key);
		logger.info("【base64后的长度为：" + decryptBASE64(key).length + "】");
		SecretKey secretKey = new SecretKeySpec(decryptBASE64(key), KEY_MAC);
		logger.info("【获得的secretKey为：】" + secretKey);
		logger.info("【获得的secretKey的algorithm为：】" + secretKey.getAlgorithm());
		Mac mac = Mac.getInstance(secretKey.getAlgorithm());
		mac.init(secretKey);
		return mac.doFinal(data);
	}
}
