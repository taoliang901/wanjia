package com.wanjia.http.pamap.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;

import com.pahaoche.common.Json2JavaUtil;
import com.pahaoche.common.SendXMLToolBase;
import com.wanjia.http.pamap.model.request.PaMapReqRecord;
import com.wanjia.http.pamap.model.response.PaMapRespBusiData;
import com.wanjia.http.pamap.utils.EncryptUtil;

/**
 * 平安地图同步诊所
 */
public class PaMapClinicTongbuInterface {

	// 日志
	protected static Log log = LogFactory.getLog(PaMapClinicTongbuInterface.class);

	@Resource(name = "sendXMLToolByHTTPSForSingle")
	private SendXMLToolBase sendXMLToolBase;

	/** HTTP实时请求URL, */
	@Value("#{pamapConfig['HTTP_URL']}")
	public String HTTP_URL;

	/** 系统ID */
	@Value("#{pamapConfig['SYS_ID']}")
	public String SYS_ID;

	/** 网点类型 */
	@Value("#{pamapConfig['NETPOIN_TYPE']}")
	public String NETPOIN_TYPE;

	/** 密钥 */
	@Value("#{pamapConfig['SECRET_KEY']}")
	public String SECRET_KEY;

	/**
	 * 异常重试最大次数
	 */
	public final static int FAILED_RETRY_TIME_MAX = 3;

	/**
	 * 同步
	 * 
	 * @param operate:
	 *            同步操作, 1:保存[包括新增和修改],0:删除
	 * @param data:
	 *            json格式的数据字符串
	 * @return
	 * @throws Exception
	 */
	public PaMapRespBusiData doTongbu(String operate, PaMapReqRecord data) throws Exception {
		// ---------------------------------- 1、组装请求参数
		// -----------------------------
		long current = System.currentTimeMillis();

		String dataString = Json2JavaUtil.java2Json(data, 1);
		String sign = EncryptUtil
				.encryptBASE64(EncryptUtil.encryptHMAC((dataString + current).getBytes("utf-8"), SECRET_KEY));
		// 诡异的事情：在签名的最后会出现【\r\n】
		if (sign.endsWith("\r\n")) {
			sign = sign.substring(0, sign.length() - 2);
		}

		log.info("发送给平安地图字符串： " + dataString);
		log.info("签名： " + sign);
		log.info("操作： " + operate);
		// ---------------------------------- 2、发送请求
		// -----------------------------
		String res = null;

		Map<String, String> param = new HashMap<String, String>();
		param.put("sys", SYS_ID);
		param.put("type", NETPOIN_TYPE);
		param.put("operate", operate);
		param.put("tt", current + "");
		param.put("sign", sign);
		param.put("data", dataString);
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		Set<String> keySet = param.keySet();
		for (String one : keySet) {
			params.add(new BasicNameValuePair(one, param.get(one)));
		}
		try {
			HttpClient hc = new DefaultHttpClient();
			hc.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 10000);
			hc.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 30000);
			DefaultHttpRequestRetryHandler dhr = new DefaultHttpRequestRetryHandler(FAILED_RETRY_TIME_MAX, true);
			((DefaultHttpClient) hc).setHttpRequestRetryHandler(dhr);
			HttpPost httppost = new HttpPost(HTTP_URL);
			httppost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
			// 发送请求
			HttpResponse httpresponse = hc.execute(httppost);
			// 获取返回数据
			org.apache.http.HttpEntity entity = httpresponse.getEntity();
			res = EntityUtils.toString(entity);
		} catch (Exception e) {
			String emsg11 = "调用平安地图接口抛出异常（已重试" + FAILED_RETRY_TIME_MAX + "次）：" + res + "：" + e.getMessage();
			log.error(emsg11);
		}
		log.info("平安地图响应字符串： " + res);
		// ---------------------------------- 3、处理响应结果
		// -----------------------------
		if (StringUtils.isBlank(res)) {
			String errMsg = "调用平安地图接口抛出异常：响应结果为空！";
			log.error(errMsg);
			throw new Exception(errMsg);
		}
		PaMapRespBusiData rm = null;
		try {
			rm = (PaMapRespBusiData) Json2JavaUtil.Json2Java(res, PaMapRespBusiData.class);
		} catch (Exception e) {
			String errMsg = "调用平安地图接口抛出异常：解析响应的JSON串失败1！";
			log.error(errMsg, e);
			throw new Exception(errMsg, e);
		}

		return rm;
	}

}
