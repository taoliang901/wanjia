package com.wanjia.dsi.web.clinic.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinic.dao.mapper.ClinicExtMapper;
import com.wanjia.dsi.web.clinic.model.ClinicExt;
import com.wanjia.dsi.web.clinic.service.ClinicExtService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class ClinicExtServiceImpl implements ClinicExtService{

	private Logger logger = Logger.getLogger(ClinicExtServiceImpl.class);
	
		@Autowired
	    private ClinicExtMapper clinicExtMapper;

	    @Override
	    @Transactional(readOnly=true)
	    public ClinicExt findById(String id) {
	        return (ClinicExt)clinicExtMapper.findById(id);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public List<ClinicExt> findWithPagination(int offset, int count) {
	        return (List<ClinicExt>)clinicExtMapper.findWithPagination(offset,count);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public List<ClinicExt> findAll() {
	        return (List<ClinicExt>)clinicExtMapper.findAll();
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public List<ClinicExt> findByEntity(ClinicExt model) {
	        return (List<ClinicExt>)clinicExtMapper.findByEntity(model);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public List<ClinicExt> findByEntityWithPagination(ClinicExt model, int offset, int count) {
	        return (List<ClinicExt>)clinicExtMapper.findByEntityWithPagination(model,offset,count);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public ClinicExt findOneByEntity(ClinicExt model) {
	        return (ClinicExt)clinicExtMapper.findOneByEntity(model);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public List<ClinicExt> findByProperty(String propertyName, String propertyValue) {
	        return (List<ClinicExt>)clinicExtMapper.findByProperty(propertyName,propertyValue);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public ClinicExt findOneByProperty(String propertyName, String propertyValue) {
	        return (ClinicExt)clinicExtMapper.findOneByProperty(propertyName,propertyValue);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public List<ClinicExt> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
	        return (List<ClinicExt>)clinicExtMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public List<ClinicExt> findByProperties(Map<String, Object> map) {
	        return (List<ClinicExt>)clinicExtMapper.findByProperties(map);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public long countByEntity(ClinicExt model) {
	        return (long)clinicExtMapper.countByEntity(model);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public long countByProperty(String propertyName, String propertyValue) {
	        return (long)clinicExtMapper.countByProperty(propertyName,propertyValue);
	    }

	    @Override
	    @Transactional(readOnly=true)
	    public long countByProperties(Map<String, Object> map) {
	        return (long)clinicExtMapper.countByProperties(map);
	    }

	    @Override
	    public void update(ClinicExt model) {
	  //      model.setModifyUser(ThreadLocalContext.getSystemUserId());
	        model.setModifyDate(new Date());
	        clinicExtMapper.update(model);
	    }

	    @Override
	    public void insert(ClinicExt model) {
	    //    model.setCreateUser(ThreadLocalContext.getSystemUserId());
	        model.setCreateDate(new Date());
	        clinicExtMapper.insert(model);
	    }

	    @Override
	    public void deleteByEntity(ClinicExt model) {
	        model.setDelFlag("1");
	     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
	        model.setModifyDate(new Date());
	        this.update(model);
	    }

	    @Override
	    public void deleteByProperty(String propertyName, String propertyValue) {
	        clinicExtMapper.deleteByProperty(propertyName,propertyValue);
	    }

	    @Transactional(readOnly=true)
	    public long countAll() {
	        return this.clinicExtMapper.countAll();
	    }

	    public void insertBatch(List<ClinicExt> list) {
	        this.clinicExtMapper.insertBatch(list);
	    }

	    public void delete(String id) {
	        ClinicExt model = new ClinicExt();
	        model.setDelFlag("1");
	  //      model.setModifyUser(ThreadLocalContext.getSystemUserId());
	        model.setModifyDate(new Date());
	        model.setId(String.valueOf(id));
	        this.clinicExtMapper.update(model);
	    }
	    
	    public JsonResponse<ClinicExt> searchClinicQRCodeByClinicId(String clinicId){
	    	JsonResponse<ClinicExt> jr = new JsonResponse<ClinicExt>();
	    	try{
	    		ClinicExt clinicExt = clinicExtMapper.searchClinicQRCodeByClinicId(clinicId);
	    		jr.setResult(clinicExt);
	    		jr.setStatus(JsonResponse.Status.SUCCESS);
	    	}catch(Exception e){
	    		jr.setStatus(JsonResponse.Status.ERROR);
	    		jr.setErrorMsg("查询诊所二维码出现异常!");
	    		logger.info("searchClinicQRCodeByClinicId 失败---"+e);
	    		e.printStackTrace();
	    	}
	    	
	    	return jr;
	    }
}
