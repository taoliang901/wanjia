package com.wanjia.dsi.web.pamap.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.rpc.RpcException;
import com.pinganwj.clinic.api.ApptService;
import com.pinganwj.clinic.api.domain.appt.ApptConfigReq;
import com.pinganwj.clinic.api.domain.appt.ApptConfigRsp;
import com.pinganwj.clinic.api.domain.appt.DepartmentInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.web.pamap.dao.mapper.ClinicLongitudeLatitudeVOMapper;
import com.wanjia.dsi.web.pamap.model.ClinicLongitudeLatitudeVO;
import com.wanjia.dsi.web.pamap.service.PaMapClinicTongbuService;
import com.wanjia.http.pamap.component.PaMapClinicTongbuInterface;
import com.wanjia.http.pamap.model.request.PaMapReqRecord;
import com.wanjia.http.pamap.model.response.PaMapRespBusiData;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PaMapClinicTongbuServiceImpl extends BaseServiceImpl implements PaMapClinicTongbuService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource(name = "paMapClinicTongbuInterface")
	private PaMapClinicTongbuInterface paMapClinicTongbuInterface;

	@Autowired
	private ClinicLongitudeLatitudeVOMapper clinicLongitudeLatitudeVOMapper;

	@Value("#{serverConstants['imageRoot']}")
	private String imageRoot;

	// 为true诊所都不可预约
	@Value("#{pamapConfig['BOOKING_DISABLED']}")
	private String BOOKING_DISABLED;

	// 为true同步所有的诊所
	@Value("#{pamapConfig['TONGBU_ALL']}")
	private String TONGBU_ALL;

	@Autowired
	private ApptService apptService;

	@Override
	public JsonResponse<Void> doTongbuByDate(String nowDate) {

		if (StringUtils.isBlank(nowDate)) {
			throw new ServiceException(null, "同步日期不能为空！");
		}
		Date start = new Date();
		List<ClinicLongitudeLatitudeVO> clinicList = null;
		int success = 0;
		int failed = 0;
		try {
			if ("true".equals(TONGBU_ALL)) {
				clinicList = clinicLongitudeLatitudeVOMapper.getClinicLongitudeLatitudeList(null);
			} else {
				clinicList = clinicLongitudeLatitudeVOMapper.getClinicLongitudeLatitudeList(nowDate);
			}
			for (int i = 0; i < clinicList.size(); i++) {
				ClinicLongitudeLatitudeVO r = clinicList.get(i);
				String operate = "1"; // 同步操作, 1:保存[包括新增和修改],0:删除
				if ("1".equals(r.getDelFlag()) || !"1".equals(r.getIsView())) {
					operate = "0";
				}
				PaMapReqRecord data = new PaMapReqRecord();
				data.setSyncId(r.getSyncId());
				data.setName(r.getName());
				if (!imageRoot.endsWith("/")) {
					imageRoot = imageRoot + "/";
				}
				if (StringUtils.isNotBlank(r.getIcon())) {
					data.setIcon(imageRoot + r.getIcon());
				} else {
					data.setIcon(imageRoot + "clinic/clinic-logo.png");
				}
				data.setAddress(r.getAddress());
				data.setDetailAddress(r.getDetailAddress());
				// data.setPhoneNumber(r.getPhoneNumber());
				data.setProvinceCode(r.getProvinceCode());
				data.setCityCode(r.getCityCode());
				data.setDistrictCode(r.getDistrictCode());
				data.setLongitude(Double.parseDouble(r.getLongitude()));
				data.setLatitude(Double.parseDouble(r.getLatitude()));
				if ("true".equals(BOOKING_DISABLED)) {
					data.setEnabledBooking("0");
				} else {
					// 获取诊所排班模式
					boolean hasDepartment = hasDepartment(r);
					if ("1".equals(r.getIsBooking()) && hasDepartment) {
						data.setEnabledBooking("1");
					} else {
						data.setEnabledBooking("0");
					}
				}
				// ------------ 填充前三个一级科室 start
				if (StringUtils.isNotBlank(r.getDiagnosisType1())) {
					String s = r.getDiagnosisType1();
					s = s.replace(" ", "");
					String[] ss = s.split("\\|");
					int cnt = ss.length;
					if (cnt > 3) {
						cnt = 3;
					}
					String outS = "";
					for (int j = 0; j < cnt; j++) {
						outS += ss[j] + " ";
					}
					if (StringUtils.isNotBlank(outS)) {
						outS = outS.substring(0, outS.length() - 1);
					}
					data.setServiceList(outS);
				}
				// ------------ 填充前三个一级科室 end

				try {
					PaMapRespBusiData res = paMapClinicTongbuInterface.doTongbu(operate, data);
					if (res == null) {
						logger.error("同步第" + i + "条数据时，失败：响应为空：" + r.getSyncId());
						failed++;
					} else if (!"1000".equals(res.getCode())) {
						logger.error(
								"同步第" + i + "条数据时，失败：响应失败：" + r.getSyncId() + "：" + res.getCode() + res.getMessage());
						failed++;
					} else {
						logger.info("同步第" + i + "条数据成功：" + r.getSyncId());
						success++;
					}
				} catch (Exception e) {
					logger.error("同步第" + i + "条数据时，出现异常：" + r.getSyncId(), e);
					failed++;
				}
			}

		} catch (Exception e) {
			throw new ServiceException(null, "抛出了非预期异常：" + e.getMessage(), e);
		}
		Date end = new Date();
		logger.error("本次共同步了" + clinicList.size() + "条诊所数据，耗时【" + (end.getTime() - start.getTime()) * 1.0 / 60 / 1000
				+ "】分钟，成功" + success + "条，失败" + failed + "条。");

		JsonResponse<Void> result = new JsonResponse<Void>();
		result.setStatus(Status.SUCCESS);
		return result;
	}

	// 是否有排班信息，可预约
	private boolean hasDepartment(ClinicLongitudeLatitudeVO r) {
		boolean hasDepartment = false;
		ApptConfigReq apptConfigReq = new ApptConfigReq();
		ApptConfigRsp apptConfigRsp = new ApptConfigRsp();
		apptConfigReq.setClinicId(r.getSyncId());
		com.pinganwj.clinic.api.domain.JsonResponse<ApptConfigRsp> jr = new com.pinganwj.clinic.api.domain.JsonResponse<ApptConfigRsp>();
		try {
			jr = apptService.getApptConfig(apptConfigReq);
		} catch (RpcException rpcException) {
			logger.warn("apptService + getApptConfig----调用rpc失败！", rpcException);
		} catch (Exception exception) {
			logger.warn("apptService + getApptConfig----调用失败！", exception);
		}

		if (jr != null && jr.getResult() != null) {
			apptConfigRsp = jr.getResult();
		}

		// 有排班信息，即可预约
		List<DepartmentInfo> departmentList = apptConfigRsp.getHaveScheduleDepartmentInfos();
		if (departmentList != null && departmentList.size() > 0) {
			hasDepartment = true;
		}
		return hasDepartment;
	}
}