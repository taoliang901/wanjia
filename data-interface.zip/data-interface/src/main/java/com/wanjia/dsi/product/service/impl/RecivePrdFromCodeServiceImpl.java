package com.wanjia.dsi.product.service.impl;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.CollectionUtils;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.base.message.service.ValidateCodeDubboService;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.common.utils.DateTools;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderDetailMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderDetailServiceMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderMapper;
import com.wanjia.dsi.product.dao.mapper.PrdServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdKucunMapper;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.PrdKucunExample;
import com.wanjia.dsi.product.model.PrdOrder;
import com.wanjia.dsi.product.model.PrdOrderDetail;
import com.wanjia.dsi.product.model.PrdOrderDetailService;
import com.wanjia.dsi.product.model.PrdService;
import com.wanjia.dsi.product.model.PrdServiceExample;
import com.wanjia.dsi.product.service.RecivePrdFromCodeService;
import com.wanjia.dsi.product.service.StockService;
import com.wanjia.dsi.product.vo.VOPrdKucun;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyTreatmentPersonMapper;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class RecivePrdFromCodeServiceImpl implements RecivePrdFromCodeService{
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	private static String CLASS_NAME = RecivePrdFromCodeServiceImpl.class.getName();
	
	@Autowired
	private PrdOrderMapper prdOrderMapper;
	@Autowired
	private PrdOrderDetailMapper prdOrderDetailMapper;
	@Autowired
	private PrdOrderDetailServiceMapper prdOrderDetailServiceMapper;
	@Autowired
	private PrdServiceMapper prdServiceMapper;
	@Autowired
	private PrdKucunMapper prdKucunMapper;
	@Autowired
	private PrdInfoMapper prdInfoMapper;
	@Autowired
	private VOPrdKucunMapper voPrdKucunMapper;

	@Autowired
	private HyTreatmentPersonMapper hyTreatmentPersonMapper;
	
	@Autowired
	private ValidateCodeDubboService validateCodeDubboService;
	@Autowired
	private StockService stockService;
	/**
	 * 校验产品和邀请码是否匹配
	 * @param prdId
	 * @param receiveCode
	 * @return
	 */
	@Override
	public PrdKucun checkPrdIdAndReceiveCode(String prdId,String receiveCode) {
		VOPrdKucun VOPrdKucun = new VOPrdKucun();
		VOPrdKucun.setCouponId(prdId);
		VOPrdKucun.setCheckValue(receiveCode);
		VOPrdKucun.setDelFlag("0"); //没有删除
		VOPrdKucun.setStatus("0");//0：未使用；1：已使用
		List<PrdKucun> prdKucunList = voPrdKucunMapper.checkPrdIdAndReceiveCode(VOPrdKucun);//邀请码和产品匹配,走库存表
		if(prdKucunList != null && prdKucunList.size() >0){
			return prdKucunList.get(0);
		}
		return null;
		/*if(voPrdInfoMapper.checkPrdIdAndReceiveCode(voReciveCode) > 0){//邀请码和产品匹配，走产品表废弃
			return true;
		}
		return false;*/
	}
	/**
	 * 校验是否有库存和是否领取（邀请码在库存表，一个卡号有不同的邀请码的情况不需要查库存量了）废弃
	 * @param prdId
	 * @param receiveCode
	 * @return
	 */
	@Override
	public boolean checkAmount(String prdId) {
		PrdKucun prdKucun = new PrdKucun();
		prdKucun.setId(prdId);
		prdKucun.setDelFlag("0");//没有删除
		prdKucun.setBuyerUserId(null);
		// 有效时间是否需要校验
		if(voPrdKucunMapper.checkAmountAndBuyer(prdKucun) >0 ){//有库存
			return true;
		}
		
		return false;
	}
	
	/**
	 * 校验是否领取
	 * @param prdId
	 * @param receiveCode
	 * @return
	 */
	@Override
	public boolean isNoRecevied(String prdId,String userId) {
		if(userId == null){
			return false;
		}
		PrdKucun prdKucun = new PrdKucun();
		prdKucun.setId(prdId);
		prdKucun.setDelFlag("0");//没有删除
		prdKucun.setBuyerUserId(userId);
		// 有效时间是否需要校验
		if(voPrdKucunMapper.checkAmountAndBuyer(prdKucun) == 0 ){//没有领取
			return true;
		}
		return false;
	}

	@Override
	public synchronized JsonResponse<String> reciveCode(String prdId, long userId, String receiveCode,String receiveChannel) {
		JsonResponse<String> result = new JsonResponse<String>();
		if (StringUtils.isBlank(prdId)) {
			throw new ServiceException(ErrorType.ReciveMismatching.getCode(), ErrorType.ReciveMismatching.getDesc());
		}
		if (StringUtils.isBlank(String.valueOf(userId))) {
			throw new ServiceException(ErrorType.UserIdisNull.getCode(), ErrorType.UserIdisNull.getDesc());
		}
		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		String isNeedReceiveFree = prdInfo.getIsSupportReceiveFree(); // 是否邀请码类型（0是，1否）免费
		String isNeedInviteValue = prdInfo.getIsNeedInviteValue(); // 是否需要邀请码（0是，1否）
		PrdKucun prdKucun = null;
		if (StringUtils.isBlank(receiveCode)) { // 不需要邀请码邀请 接口
			if (!"0".equals(isNeedReceiveFree) || !"1".equals(isNeedInviteValue)) { // 标志是 需要邀请码,并且支持免费领取
				throw new ServiceException(ErrorType.ReciveMismatching.getCode(),
						ErrorType.ReciveMismatching.getDesc());
			}
			if(!isNoRecevied(prdId,String.valueOf(userId))){ //领取过了不能领取
				throw new ServiceException(ErrorType.Recived.getCode(),ErrorType.Recived.getDesc()); 
			}
			// 校验是否有库存，没有直接返回
			if (!checkAmount(prdId)) {
				throw new ServiceException(ErrorType.HaveNoAmount.getCode(), ErrorType.HaveNoAmount.getDesc());
			} else {
				//result = insertOrderDetailService(prdId, userId, null, receiveCode, null);//不要邀请码，库存随机分配
				result = insertOrderDetailService(prdId, userId, null, receiveCode, null,receiveChannel);//不要邀请码，库存随机分配
			}
		} else {// 需要邀请码 接口
			if (StringUtils.isBlank(receiveCode) || !"0".equals(isNeedReceiveFree) || !"0".equals(isNeedInviteValue)) { // 标志是 不需要邀请码
				throw new ServiceException(ErrorType.ReciveMismatching.getCode(),ErrorType.ReciveMismatching.getDesc());
			}
			prdKucun = checkPrdIdAndReceiveCode(prdId, receiveCode);
			// 2. 校验领取码和产品id是否一致和有效，无效直接返回
			if (prdKucun == null) {// 查询库存没有数据说明产品id和邀请码不匹配
				throw new ServiceException(ErrorType.ReciveMismatching.getCode(),ErrorType.ReciveMismatching.getDesc());
			}
			if (StringUtils.isNotBlank(prdKucun.getBuyerUserId())) {// 领取人不为空时说明已经领取过了
				throw new ServiceException(ErrorType.Recived.getCode(), ErrorType.Recived.getDesc());
			}
			//result = insertOrderDetailService(prdId, userId, prdKucun.getId(), receiveCode, null);
			result = insertOrderDetailService(prdId, userId, prdKucun.getId(), receiveCode, null,receiveChannel);
		}
		logger.info(CLASS_NAME + ":reciveCode method end...");
		return result;
	}

	@Override
	public JsonResponse<String> insertOrderDetailService(String prdId, long userId, String kucunId, String receiveCode,
			String treatDate,String receiveChannel) {
        
		PrdOrder prdOrder = new PrdOrder();
		PrdKucun prdKucun = new PrdKucun();
		prdKucun.setCouponId(prdId);
		// 返回结果
		JsonResponse<String> result = new JsonResponse<String>();
		int receive = 0; // 更新库是否成功，0失败；
		
		//认领时，库存id不能确定，随机，需要从卡库存里取随机取一个卡号
		if(StringUtils.isBlank(kucunId)){
			prdKucun.setStatus("0");
			//取第一条库存id
			kucunId = voPrdKucunMapper.getKucunIdByLimitOne(prdKucun);
		}	
		//直接通过卡预约时通过卡号获得库存编号
		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		PrdKucunExample ex = new PrdKucunExample();
		PrdKucunExample.Criteria excr = ex.createCriteria();
		excr.andDelFlagEqualTo("0");
		excr.andIdEqualTo(kucunId);
		excr.andBuyerUserIdIsNull();
		PrdKucun record1 = new PrdKucun();
		record1.setStatus("1");
		record1.setBuyerUserId(String.valueOf(userId));
		record1.setModifyDate(new Date());
		record1.setModifyUser(String.valueOf(userId));
		record1.setValidBeginDate(prdInfo.getPrdBeginDate());
		record1.setValidEndDate(prdInfo.getPrdEndDate());
		record1.setReceiveChannel(receiveChannel);
		record1.setReceiveDate(new Date());
		receive = prdKucunMapper.updateByExampleSelective(record1, ex);
		if(receive == 0){//领取失败
			throw new ServiceException(ErrorType.ReciveFail.getCode(), ErrorType.ReciveFail.getDesc());
		}
		stockService.setStockStatus(prdId, kucunId,"1");// 将redis库存设置成已领取
		//插入订单表
		String orderId = CommonTools.generateUUID();
		prdOrder.setId(orderId);
		prdOrder.setUserId(userId);
		prdOrder.setCreateUser(String.valueOf(userId));
		prdOrder.setCreateDate(new Date());
		prdOrderMapper.insertSelective(prdOrder);
		
		//插入订单明细表,需要冗余产品表信息
		String orderDetailId;
		orderDetailId =  CommonTools.generateUUID();
		PrdOrderDetail  prdOrderDetail = new PrdOrderDetail();
		prdOrderDetail.setId(orderDetailId);
		prdOrderDetail.setOrderId(orderId);
		prdOrderDetail.setKucunId(kucunId);
		prdOrderDetail.setPrdId(prdId);
		CommonTools.setProductInfo(userId, prdInfo, prdOrderDetail);
		prdOrderDetailMapper.insertSelective(prdOrderDetail);
		
		PrdServiceExample ser = new PrdServiceExample();
		PrdServiceExample.Criteria crit = ser.createCriteria();
		crit.andPrdIdEqualTo(prdId);
		List<PrdService> serviceList = prdServiceMapper.selectByExample(ser);
		for(PrdService service : serviceList){
			PrdOrderDetailService prdOrderDetailService = new PrdOrderDetailService();
			prdOrderDetailService.setId(CommonTools.generateUUID());
			prdOrderDetailService.setOrderDetailId(orderDetailId);
			prdOrderDetailService.setPrdId(prdId);
			prdOrderDetailService.setServiceId(service.getServiceId());
			prdOrderDetailService.setServiceCount(service.getServiceCount());
			prdOrderDetailService.setIsUnlimite(service.getIsUnlimite());
			prdOrderDetailService.setDelFlag(service.getDelFlag());
			prdOrderDetailService.setCreateUser(String.valueOf(userId));
			prdOrderDetailService.setCreateDate(new Date());
			prdOrderDetailServiceMapper.insertSelective(prdOrderDetailService);
		}
		
		result.setStatus(Status.SUCCESS);
		result.setResult(kucunId);
		result.setSuccessMsg(ErrorType.ReciveSuccess.getDesc());
		logger.info(CLASS_NAME + ":insertOrderDetailService method end...");
		return result;
	}
	
	public JsonResponse<String> insertOrderDetailService(String prdId, long userId, String kucunId, String receiveCode,
			String treatDate) {
		return insertOrderDetailService(prdId,userId,kucunId,receiveCode,treatDate,null);
	}
	
	@Override
	public JsonResponse<Void> updateCardBookingInfo(String prdId, long userId, String kucunId, String treatDate) {

		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		PrdKucun r = new PrdKucun();
		r.setStatus("1");
		r.setId(kucunId);
		r.setUserId(""+userId);
		// 激活类型的产品放到激活时设置有效期
		r.setValidBeginDate(prdInfo.getPrdBeginDate());
		r.setValidEndDate(prdInfo.getPrdEndDate());
		
		prdKucunMapper.updateByPrimaryKeySelective(r);
		JsonResponse<Void> result = new JsonResponse<Void>();
		result.setStatus(Status.SUCCESS);
		return result;
	}
	
	@Override
	public JsonResponse<String> activeProduct(String userId, String prdId, String activeCode,
			String  visitId,String messageCode,String smsId,String channel) {
		logger.info("激活健康产品" + ":activeProduct method end...");
		logger.info("激活参数 userId："+userId+"--prdId:"+prdId+"---activeCode:"+activeCode+
				"----visitId:"+visitId+"---messageCode:"+messageCode+"----smsId:"+smsId);
		JsonResponse<String> jr = new JsonResponse<String>();

		
		
		//查询prdInfo
		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		//先判断是否是激活产品
		if(null==prdInfo||!"0".equals(prdInfo.getIsValidFrom())){
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("系统繁忙，请稍后");
			logger.info("非激活产品："+prdInfo);
			return jr;
		}
//		//查询就诊人信息是否正确
		//如果是激活产品，并且不支持多人使用时候并且是保险类型才支持绑定就诊人，否则不予绑定
		checkPrdTreatmentperson(prdId, visitId, messageCode, smsId, jr, prdInfo);
		if(Status.ERROR.equals(jr.getStatus())||StringUtils.isNotBlank(jr.getErrorMsg())){
			//
			return jr;
		}
		
		//根据领取码和产品id查询库存信息，看是否匹配
		PrdKucun prdKucun = checkPrdIdAndActiveCode(prdId,activeCode);
		//2. 校验领取码和产品id是否一致和有效，无效直接返回
		if(StringUtils.isBlank(activeCode)||StringUtils.isBlank(prdId) ||prdKucun == null){//查询库存没有数据说明产品id和邀请码不匹配
			throw new ServiceException(ErrorType.ReciveMismatching.getCode(), "激活码有误");
		}
		//领取人不为空时说明已经领取过了
		if(StringUtils.isNotBlank(prdKucun.getBuyerUserId())){
			throw new ServiceException(ErrorType.Recived.getCode(), "激活码有误");
		}
		//如果kucunId非为空的话说明是分发卡

		
		
		//数据都是正确情况下更新库存表信息
		PrdKucunExample ex = new PrdKucunExample();
		PrdKucunExample.Criteria excr = ex.createCriteria();
		excr.andDelFlagEqualTo("0");
		excr.andIdEqualTo(prdKucun.getId());
		//如果是已经购买或者分发产品，buyuserId不为空
//		excr.andBuyerUserIdIsNull();
		PrdKucun record1 = new PrdKucun();
		//设置就诊人需要判断是不是单人使用的
		if(StringUtils.isNotBlank(visitId)){
			record1.setVisitId(visitId);
		}
		//kucunId为空的话才要设置购买人
		record1.setStatus("1");
		record1.setBuyerUserId(String.valueOf(userId));
		record1.setModifyDate(new Date());
		record1.setModifyUser(String.valueOf(userId));
		record1.setActiveChannel(channel);
		Date date = new Date();
		record1.setValidBeginDate(date);
		if("0".equals(prdInfo.getValidValueUnit())){
			record1.setValidEndDate(DateUtils.addYear(date, Integer.parseInt(prdInfo.getValidValue())));
		}else if("1".equals(prdInfo.getValidValueUnit())){
			record1.setValidEndDate(DateUtils.addMonth(date, Integer.parseInt(prdInfo.getValidValue())));
		}else if("2".equals(prdInfo.getValidValueUnit())){
			record1.setValidEndDate(DateUtils.addDay(date, Integer.parseInt(prdInfo.getValidValue())));
		}else{
			record1.setValidEndDate(DateUtils.addHour(date, Integer.parseInt(prdInfo.getValidValue())));
		}
//		record1.setValidBeginDate(new simple);
//		record1.setValidEndDate(prdInfo.getPrdEndDate());
		int receive = prdKucunMapper.updateByExampleSelective(record1, ex);
		if(receive!=1){
			logger.info("更新库存信息失败");
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("激活失败");
			return jr;
		}
		//插入订单表
		PrdOrder prdOrder = new PrdOrder();
		String orderId = CommonTools.generateUUID();
		prdOrder.setId(orderId);
		prdOrder.setUserId(Long.valueOf(userId));
		prdOrder.setCreateUser(String.valueOf(userId));
		prdOrder.setCreateDate(new Date());
		prdOrder.setBuyChannel("3");
		prdOrderMapper.insertSelective(prdOrder);
		
		//插入订单明细表,需要冗余产品表信息
		String orderDetailId;
		orderDetailId =  CommonTools.generateUUID();
		PrdOrderDetail  prdOrderDetail = new PrdOrderDetail();
		prdOrderDetail.setId(orderDetailId);
		prdOrderDetail.setOrderId(orderId);
		prdOrderDetail.setKucunId(prdKucun.getId());
		prdOrderDetail.setPrdId(prdId);
		CommonTools.setProductInfo(Long.valueOf(userId), prdInfo, prdOrderDetail);
		
		prdOrderDetail.setIsSupportBuyOnline(prdInfo.getIsSupportBuyOnline());
		prdOrderDetail.setIsInsurancePrd(prdInfo.getIsInsurancePrd());
		prdOrderDetail.setInsuranceFilename(prdInfo.getInsuranceFilename());
		prdOrderDetail.setInsuranceFilepath(prdInfo.getInsuranceFilepath());
		
		
		prdOrderDetailMapper.insertSelective(prdOrderDetail);
		
		PrdServiceExample ser = new PrdServiceExample();
		PrdServiceExample.Criteria crit = ser.createCriteria();
		crit.andPrdIdEqualTo(prdId);
		List<PrdService> serviceList = prdServiceMapper.selectByExample(ser);
		for(PrdService service : serviceList){
			PrdOrderDetailService prdOrderDetailService = new PrdOrderDetailService();
			prdOrderDetailService.setId(CommonTools.generateUUID());
			prdOrderDetailService.setOrderDetailId(orderDetailId);
			prdOrderDetailService.setPrdId(prdId);
			prdOrderDetailService.setServiceId(service.getServiceId());
			prdOrderDetailService.setServiceCount(service.getServiceCount());
			prdOrderDetailService.setIsUnlimite(service.getIsUnlimite());
			prdOrderDetailService.setDelFlag(service.getDelFlag());
			prdOrderDetailService.setCreateUser(String.valueOf(userId));
			prdOrderDetailService.setCreateDate(new Date());
			prdOrderDetailServiceMapper.insertSelective(prdOrderDetailService);
		}
		
		//消耗库存信息
		//判断是否是线下卡
		
		stockService.setStockStatus(prdId,prdKucun.getId(), "1");
		
		//判断渠道是不是微信 1 网站 2app 3 微信
		if("3".equals(channel)){
			//激活成功通知微信消息
//			@TODO
		}
		//发送短信
		jr.setStatus(Status.SUCCESS);
		jr.setResult(prdKucun.getId());
		jr.setSuccessMsg("激活成功");
		logger.info("激活健康产品" + ":activeProduct method end...");
		
		return jr;
	}
	private void checkPrdTreatmentperson(String prdId, String visitId, String messageCode, String smsId,
			JsonResponse<String> jr, PrdInfo prdInfo) {
		if("0".equals(prdInfo.getIsValidFrom())&&"1".equals(prdInfo.getIsNeedManyUse())&&"0".equals(prdInfo.getIsInsurancePrd())){
			
			if(StringUtils.isNotBlank(visitId)){
				//输入就诊人信息的情况下
				HyTreatmentPerson hyTreatmentPerson = hyTreatmentPersonMapper.selectByPrimaryKey(visitId);
				if(hyTreatmentPerson==null||StringUtils.isBlank(hyTreatmentPerson.getVisitId())){
					jr.setStatus(Status.ERROR);
					jr.setErrorMsg("无此就诊人");
				}else{
					//校验信息
					//@TODO
					//校验码并没有太多用，先注释掉
					if(StringUtils.isNotBlank(smsId)&&StringUtils.isNotBlank(messageCode)){
						JsonResponse<Void> checkCodeResp = validateCodeDubboService.checkCode(hyTreatmentPerson.getVisitMobile(), smsId, messageCode);
						if(null==checkCodeResp||StringUtils.isNotBlank(checkCodeResp.getErrorMsg())){
							logger.error("激活码校验失败：checkCodeResp"+checkCodeResp);
							jr.setErrorMsg(checkCodeResp.getErrorMsg());
							jr.setStatus(Status.ERROR);
						}
					}
					if(StringUtils.isBlank(hyTreatmentPerson.getVisitMobile())||StringUtils.isBlank(hyTreatmentPerson.getParentName())||StringUtils.isBlank(hyTreatmentPerson.getParentRelation())){
						jr.setStatus(Status.ERROR);
						jr.setErrorMsg("就诊人家长信息必须填写，请先修改就诊人信息");
					}
					//校验就诊人年龄是否合法
					try {
						if(!validateTreatmentPerson(prdId, hyTreatmentPerson)){
							throw new ServiceException(null, "就诊人不符合预约服务项目的年龄要求，请更换就诊人");
						}
					} catch (ParseException e) {
						logger.info("激活产品校验就诊人信息失败",e);
						throw new ServiceException(null, "校验就诊人信息失败");
					}
				}
			}else{
				jr.setErrorMsg("请先选择就诊人再激活该产品");
				jr.setStatus(Status.ERROR);
			}
		}
	}
	@Override
	public JsonResponse<String> reciveCode(String prdId, long userId) {
		return reciveCode(prdId,userId,null);
	}
	
	
	
	/**
	 * 校验产品是否在产品服务区间内
	 * @param prdId
	 * @param hyTreatmentPerson
	 * @return
	 * @throws ParseException
	 */
	private boolean validateTreatmentPerson(String prdId,HyTreatmentPerson hyTreatmentPerson) throws ParseException{
		
		PrdServiceExample prdExample = new PrdServiceExample();
		PrdServiceExample.Criteria prdCriteria = prdExample.createCriteria();
		prdCriteria.andPrdIdEqualTo(prdId);
//		prdCriteria.andServiceIdEqualTo(booking.getPrdServiceId());
		prdCriteria.andDelFlagEqualTo(0);
		List<PrdService> prdServiceList = prdServiceMapper.selectByExample(prdExample);
//		PrdService prdService = prdServiceList.get(0);
		// 就诊人年龄小于服务项目年龄范围下限||大于上限，则不能逾越
		if(CollectionUtils.isNotEmpty(prdServiceList)){
			
			for (PrdService prdService : prdServiceList) {
				if(StringUtils.isNotBlank(prdService.getFloorAge())&&StringUtils.isNotBlank(prdService.getTopAge())){
					{
						int age = DateTools.getAge(hyTreatmentPerson.getVisitBrithday());
						if(age<Integer.parseInt(prdService.getFloorAge())||age>Integer.parseInt(prdService.getTopAge())){
							throw new ServiceException(null, "就诊人不符合预约服务项目的年龄要求，请更换就诊人");
						}
					}
				}
			}
			return true;
		
		}
		return false;
	}
	
	
	private PrdKucun checkPrdIdAndActiveCode(String prdId,String receiveCode) {
		VOPrdKucun VOPrdKucun = new VOPrdKucun();
		VOPrdKucun.setCouponId(prdId);
		VOPrdKucun.setDelFlag("0"); //没有删除
		VOPrdKucun.setCheckValue(receiveCode);
		VOPrdKucun.setStatus("1");//激活只有已经购买的和线下卡才能激活，status为1
		
		List<PrdKucun> prdKucunList = voPrdKucunMapper.checkPrdIdAndReceiveCode(VOPrdKucun);//邀请码和产品匹配,走库存表
		if(prdKucunList != null && prdKucunList.size() >0){
			return prdKucunList.get(0);
		}
		return null;
		/*if(voPrdInfoMapper.checkPrdIdAndReceiveCode(voReciveCode) > 0){//邀请码和产品匹配，走产品表废弃
			return true;
		}
		return false;*/
	}
	@Override
	public JsonResponse<String> reciveCode(String prdId, long userId, String receiveCode) {
		return reciveCode(prdId,userId,receiveCode,null);
	}
	@Override
	public JsonResponse<String> activeMyProduct(String userId, String prdId, String kucunId, String visitId,String messageCode,String smsId,String channel) {
		JsonResponse<String> jr = new JsonResponse<String>();
		//校验参数
		if(StringUtils.isBlank(userId)||StringUtils.isBlank(prdId)||StringUtils.isBlank(kucunId)){
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("非法的参数");
			return jr;
		}
		//第二步查询产品信息
		//查询prdInfo
		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		if(prdInfo==null){
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("系统繁忙");
			return jr;
		}
		checkPrdTreatmentperson(prdId, visitId, null, null, jr, prdInfo);
		if(Status.ERROR.equals(jr.getStatus())||StringUtils.isNotBlank(jr.getErrorMsg())){
			//
			return jr;
		}
		//
		//查询库存表信息
		VOPrdKucun voPrdKucun = new VOPrdKucun();
		voPrdKucun.setId(kucunId);
		voPrdKucun.setCouponId(prdId);
//		voPrdKucun.setBuyerUserId(userId);
		voPrdKucun.setStatus("1");
		voPrdKucun.setDelFlag("0");
		List<PrdKucun> kuncunList = voPrdKucunMapper.getKuncunByExamples(voPrdKucun);
		if(null==kuncunList||kuncunList.size()==0){
			logger.info("查无此库存信息");
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("系统繁忙");
			return jr;
		}
		PrdKucun prdKucun = kuncunList.get(0);
		//没问题的话更新库存表，
		//数据都是正确情况下更新库存表信息
		PrdKucunExample ex = new PrdKucunExample();
		PrdKucunExample.Criteria excr = ex.createCriteria();
		excr.andDelFlagEqualTo("0");
		excr.andIdEqualTo(prdKucun.getId());
		//如果是已经购买或者分发产品，buyuserId不为空
//		excr.andBuyerUserIdIsNull();
		PrdKucun record1 = new PrdKucun();
		//设置就诊人需要判断是不是单人使用的
		if(StringUtils.isNotBlank(visitId)){
			record1.setVisitId(visitId);
		}
		//kucunId为空的话才要设置购买人
//		record1.setStatus("1");
//		record1.setBuyerUserId(String.valueOf(userId));
		record1.setModifyDate(new Date());
		record1.setModifyUser(String.valueOf(userId));
		record1.setActiveChannel(channel);
		Date date = new Date();
		record1.setValidBeginDate(date);
		if("0".equals(prdInfo.getValidValueUnit())){
			record1.setValidEndDate(DateUtils.addYear(date, Integer.parseInt(prdInfo.getValidValue())));
		}else if("1".equals(prdInfo.getValidValueUnit())){
			record1.setValidEndDate(DateUtils.addMonth(date, Integer.parseInt(prdInfo.getValidValue())));
		}else if("2".equals(prdInfo.getValidValueUnit())){
			record1.setValidEndDate(DateUtils.addDay(date, Integer.parseInt(prdInfo.getValidValue())));
		}else{
			record1.setValidEndDate(DateUtils.addHour(date, Integer.parseInt(prdInfo.getValidValue())));
		}
//		record1.setValidBeginDate(new simple);
//		record1.setValidEndDate(prdInfo.getPrdEndDate());
		int receive = prdKucunMapper.updateByExampleSelective(record1, ex);
		if(receive!=1){
			logger.info("更新库存信息失败");
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("激活失败");
			return jr;
		}
		
		return jr;
	}
}
