package com.wanjia.dsi.product.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.product.dao.mapper.PrdFrameworkAgreementLogMapper;
import com.wanjia.dsi.product.model.PrdFrameworkAgreementLog;
import com.wanjia.dsi.product.service.PrdFrameworkAgreementLogReadService;




@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class PrdFrameAgreementLogReadServiceImpl implements PrdFrameworkAgreementLogReadService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private PrdFrameworkAgreementLogMapper prdFrameworkAgreementLogMapper;

	@Override
	public JsonResponse<List<PrdFrameworkAgreementLog>> findByEntity(PrdFrameworkAgreementLog agreementLog) {
		JsonResponse<List<PrdFrameworkAgreementLog>> jr = new JsonResponse<List<PrdFrameworkAgreementLog>>();
		try{
			List<PrdFrameworkAgreementLog> list = prdFrameworkAgreementLogMapper.findByEntity(agreementLog);
			jr.setStatus(Status.SUCCESS);
			jr.setResult(list);
		
		}catch(Exception e){
			logger.error("find PrdFrameworkAgreementLog error:",e);
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}


	
	


	
	
}
