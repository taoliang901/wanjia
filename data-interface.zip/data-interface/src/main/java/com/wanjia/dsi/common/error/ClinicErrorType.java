/**
 * 
 */
package com.wanjia.dsi.common.error;

/**
 * 诊所错误类型
 * 
 * @author Kimi
 * 
 */
public enum ClinicErrorType {

	RegisterIdNull("E01001", "用户ID为空"),
	ClinicInfoNull("E01002","此用户无诊所权限"),
	ClinicIdNull("E01003","诊所ID为空"),
	SystemBusy("E02001","系统繁忙"),
	Other("E02099","其它");
	
	private String code;

	private String desc;

	/**
	 * @param code
	 * @param desc
	 */
	private ClinicErrorType(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public static String getExtNameByCode(String code) {
		for (ClinicErrorType e : ClinicErrorType.values()) {
			if (e.getCode().equals(code)) {
				return e.desc;
			}
		}
		return null;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc
	 *            the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

}
