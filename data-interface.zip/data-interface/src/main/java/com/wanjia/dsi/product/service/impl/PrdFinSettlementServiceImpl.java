package com.wanjia.dsi.product.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.common.utils.DateTools;
import com.wanjia.dsi.product.dao.mapper.PrdFinSettlementMapper;
import com.wanjia.dsi.product.model.PrdFinSettlement;
import com.wanjia.dsi.product.service.PrdFinSettlementService;

/**
 * This element is automatically generated on 16-11-10 上午10:49, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdFinSettlementServiceImpl implements PrdFinSettlementService {
	
	private Logger logger = LoggerFactory.getLogger(PrdFinSettlementServiceImpl.class);
	
    @Autowired
    private PrdFinSettlementMapper prdFinSettlementMapper;

    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlement findById(String id) {
        return (PrdFinSettlement)prdFinSettlementMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlement> findWithPagination(int offset, int count) {
        return (List<PrdFinSettlement>)prdFinSettlementMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlement> findAll() {
        return (List<PrdFinSettlement>)prdFinSettlementMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlement> findByEntity(PrdFinSettlement model) {
        return (List<PrdFinSettlement>)prdFinSettlementMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlement> findByEntityWithPagination(PrdFinSettlement model, int offset, int count) {
        return (List<PrdFinSettlement>)prdFinSettlementMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlement findOneByEntity(PrdFinSettlement model) {
        return (PrdFinSettlement)prdFinSettlementMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlement> findByProperty(String propertyName, String propertyValue) {
        return (List<PrdFinSettlement>)prdFinSettlementMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlement findOneByProperty(String propertyName, String propertyValue) {
        return (PrdFinSettlement)prdFinSettlementMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlement> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<PrdFinSettlement>)prdFinSettlementMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlement> findByProperties(Map<String, Object> map) {
        return (List<PrdFinSettlement>)prdFinSettlementMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(PrdFinSettlement model) {
        return (long)prdFinSettlementMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)prdFinSettlementMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)prdFinSettlementMapper.countByProperties(map);
    }

    @Override
    public void update(PrdFinSettlement model) {
   //     model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        prdFinSettlementMapper.update(model);
    }

    @Override
    public void insert(PrdFinSettlement model) {
    //    model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        prdFinSettlementMapper.insert(model);
    }

    @Override
    public void deleteByEntity(PrdFinSettlement model) {
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        prdFinSettlementMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.prdFinSettlementMapper.countAll();
    }

    public void insertBatch(List<PrdFinSettlement> list) {
        this.prdFinSettlementMapper.insertBatch(list);
    }

    public void delete(String id) {
        PrdFinSettlement model = new PrdFinSettlement();
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.prdFinSettlementMapper.update(model);
    }
    
    public void updateSettlementForApproval(){
    	String settleDate = DateTools.getSysDateforBill();
    	logger.info("------更新出账日为" + settleDate + "的账单状态为--02--(待运营审核)");
    	prdFinSettlementMapper.updateSettlementForApproval(settleDate);
    }
}