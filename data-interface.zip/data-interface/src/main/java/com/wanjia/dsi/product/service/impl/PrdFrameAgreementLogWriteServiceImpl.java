package com.wanjia.dsi.product.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.product.dao.mapper.PrdFrameworkAgreementLogMapper;
import com.wanjia.dsi.product.model.PrdFrameworkAgreementLog;
import com.wanjia.dsi.product.service.PrdFrameworkAgreementLogWriteService;




@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class PrdFrameAgreementLogWriteServiceImpl implements PrdFrameworkAgreementLogWriteService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	
	@Autowired
	private PrdFrameworkAgreementLogMapper prdFrameworkAgreementLogMapper;


	@Override
	public void insert(PrdFrameworkAgreementLog entity) {
		prdFrameworkAgreementLogMapper.insert(entity);
		
	}


	@Override
	public void update(PrdFrameworkAgreementLog entity) {
		prdFrameworkAgreementLogMapper.update(entity);
		
	}


	@Override
	public void deleteById(String id) {
		prdFrameworkAgreementLogMapper.deleteById(id);
		
	}


	
	

	
	
}
