package com.wanjia.dsi.web.callCenter.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pinganwj.clinic.api.ProductApptApi;
import com.pinganwj.clinic.api.domain.JsonResponse;
import com.pinganwj.clinic.api.domain.PageInfo;
import com.pinganwj.clinic.api.domain.appt.product.GetProductServiceRecordReq;
import com.pinganwj.clinic.api.domain.appt.product.GetProductServiceRecordRsp;
import com.pinganwj.clinic.api.domain.appt.product.ProductServiceRecord;
import com.wanjia.common.utils.ThreadLocalContext;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.utils.DateTools;
import com.wanjia.dsi.product.model.PrdType;
import com.wanjia.dsi.product.model.ProductKucun;
import com.wanjia.dsi.product.service.ProductKucunService;
import com.wanjia.dsi.product.service.ProductService;
import com.wanjia.dsi.web.callCenter.dao.mapper.IssueMapper;
import com.wanjia.dsi.web.callCenter.dao.mapper.IssueOBInfoMapper;
import com.wanjia.dsi.web.callCenter.dao.mapper.IssueOBProductServiceRecordMapper;
import com.wanjia.dsi.web.callCenter.model.CcSurvey;
import com.wanjia.dsi.web.callCenter.model.Issue;
import com.wanjia.dsi.web.callCenter.model.IssueOBInfo;
import com.wanjia.dsi.web.callCenter.model.IssueOBProductServiceRecord;
import com.wanjia.dsi.web.callCenter.service.CcSurveyService;
import com.wanjia.dsi.web.callCenter.service.IssueOBProductServiceRecordService;
import com.wanjia.dsi.web.clinic.model.Clinic;
import com.wanjia.dsi.web.clinic.model.ClinicInfoApproval;
import com.wanjia.dsi.web.clinic.service.ClinicInfoApprovalService;
import com.wanjia.dsi.web.clinic.service.ClinicService;
import com.wanjia.dsi.web.hyPerson.model.HyUserInfo;
import com.wanjia.dsi.web.hyPerson.service.HyUserInfoService;

/**
 * This element is automatically generated on 16-9-14 下午9:42, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class IssueOBProductServiceRecordServiceImpl implements IssueOBProductServiceRecordService {
	
	private Logger logger = LoggerFactory.getLogger(IssueOBProductServiceRecordServiceImpl.class);


	
    @Autowired
    private IssueOBProductServiceRecordMapper issueOBProductServiceRecordMapper;
    
    @Autowired
    private IssueMapper issueMapper;
    
    @Autowired
    private IssueOBInfoMapper issueOBInfoMapper;

    @Autowired
    private ProductKucunService productKucunService;
    
	@Autowired
	private ProductApptApi productApptApi;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private CcSurveyService ccSurveyService;
	
//	@Autowired
//	private ClinicService clinicService;
	
	@Autowired
	private HyUserInfoService hyUserInfoService;
	
	@Autowired
	private ClinicInfoApprovalService clinicInfoApprovalService;
	
    @Override
    @Transactional(readOnly=true)
    public IssueOBProductServiceRecord findById(Long id) {
        return (IssueOBProductServiceRecord)issueOBProductServiceRecordMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBProductServiceRecord> findWithPagination(int offset, int count) {
        return (List<IssueOBProductServiceRecord>)issueOBProductServiceRecordMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBProductServiceRecord> findAll() {
        return (List<IssueOBProductServiceRecord>)issueOBProductServiceRecordMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBProductServiceRecord> findByEntity(IssueOBProductServiceRecord model) {
        return (List<IssueOBProductServiceRecord>)issueOBProductServiceRecordMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBProductServiceRecord> findByEntityWithPagination(IssueOBProductServiceRecord model, int offset, int count) {
        return (List<IssueOBProductServiceRecord>)issueOBProductServiceRecordMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueOBProductServiceRecord findOneByEntity(IssueOBProductServiceRecord model) {
        return (IssueOBProductServiceRecord)issueOBProductServiceRecordMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBProductServiceRecord> findByProperty(String propertyName, String propertyValue) {
        return (List<IssueOBProductServiceRecord>)issueOBProductServiceRecordMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public IssueOBProductServiceRecord findOneByProperty(String propertyName, String propertyValue) {
        return (IssueOBProductServiceRecord)issueOBProductServiceRecordMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBProductServiceRecord> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<IssueOBProductServiceRecord>)issueOBProductServiceRecordMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<IssueOBProductServiceRecord> findByProperties(Map<String, Object> map) {
        return (List<IssueOBProductServiceRecord>)issueOBProductServiceRecordMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(IssueOBProductServiceRecord model) {
        return (long)issueOBProductServiceRecordMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)issueOBProductServiceRecordMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)issueOBProductServiceRecordMapper.countByProperties(map);
    }

    @Override
    public void update(IssueOBProductServiceRecord model) {
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        issueOBProductServiceRecordMapper.update(model);
    }

    @Override
    public void insert(IssueOBProductServiceRecord model) {
        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        issueOBProductServiceRecordMapper.insert(model);
    }

    @Override
    public void deleteByEntity(IssueOBProductServiceRecord model) {
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        issueOBProductServiceRecordMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.issueOBProductServiceRecordMapper.countAll();
    }

    public void insertBatch(List<IssueOBProductServiceRecord> list) {
        this.issueOBProductServiceRecordMapper.insertBatch(list);
    }

    public void delete(Long id) {
        IssueOBProductServiceRecord model = new IssueOBProductServiceRecord();
        model.setDelFlag("0");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.issueOBProductServiceRecordMapper.update(model);
    }

	@Override
	public List<IssueOBProductServiceRecord> getEntityByApptCode(String apptCode) {
		return (List<IssueOBProductServiceRecord>)issueOBProductServiceRecordMapper.getEntityByApptCode(apptCode);
	}

	@Override
	public void insertAllBatch(List<Issue> issues,
			List<IssueOBInfo> issueOBInfos,
			List<IssueOBProductServiceRecord> issueOBpsrs) {
		try{
			if (issues!=null&&issues.size()>0){
				issueMapper.insertBatch(issues);
			}
			if (issueOBInfos!=null&&issueOBInfos.size()>0){
				issueOBInfoMapper.insertBatch(issueOBInfos);
			}
			if (issueOBpsrs!=null&&issueOBpsrs.size()>0){
				issueOBProductServiceRecordMapper.insertBatch(issueOBpsrs);
			}		
		}catch(Exception e){
			logger.error("insertAllBatch()-----------" + e);
			e.printStackTrace();
		}
	
	}

	@Override
	public List<IssueOBProductServiceRecord> findEntityByParams(
			Map<String, Object> params) {
		
		return issueOBProductServiceRecordMapper.findEntityByParams(params);
	}
	
	/**
	 * 生成评价异常工单
	 * */
	
	public int createIssuesOfLowEvaluation(){
		GetProductServiceRecordReq param = new GetProductServiceRecordReq();
		int count = 0;
		int pageNo = 1;
      //  int pageSize = 20;
        String clincEvaluationStartTime = DateTools.getYesterday() + " 00:00:00";
	//	String clincEvaluationStartTime = DateTools.getFirstDayOfPreMonth() + " 00:00:00";
		String clincEvaluationEndTime = DateTools.getYesterday() + " 24:00:00";
        param.setClincEvaluationStartTime(clincEvaluationStartTime);
        param.setClincEvaluationEndTime(clincEvaluationEndTime);
        param.setClinicScoreMin(new Float(0));
        param.setClinicScoreMax(new Float(3));
        JsonResponse<GetProductServiceRecordRsp> resultJason = productApptApi.getProductServiceRecord(param);
        if(!resultJason.getStatus().equals(JsonResponse.Status.SUCCESS)){
        	logger.info("----接口返回错误或警告状态！----");
        	return 0;
        }
        GetProductServiceRecordRsp jsonResponse = resultJason.getResult();
    	PageInfo pageInfo = jsonResponse.getPageInfo();
    	int totalNum = pageInfo.getTotalRecord();
    	
    	boolean flag = true;
    	List<ProductServiceRecord> list = new ArrayList<ProductServiceRecord>();
    	//分页查询
    	while(flag){
    		com.pinganwj.clinic.api.domain.PageInfo page_Info = new com.pinganwj.clinic.api.domain.PageInfo();
        	page_Info.setPageSize(Consts.PAGE_SIZE);
        	page_Info.setCurrentPage(pageNo);
    	 	param.setPageInfo(page_Info);
    	 	JsonResponse<GetProductServiceRecordRsp> jason = productApptApi.getProductServiceRecord(param);
    	 	if(jason.getStatus().equals(JsonResponse.Status.SUCCESS)){
    	 		List<ProductServiceRecord> iteratorList  = jason.getResult().getProductServiceRecords();
    	 		list.addAll(iteratorList);
    	 	}
    	 	
    		if(Consts.PAGE_SIZE * pageNo >= totalNum ){
    			flag = false;
    		}
    		pageNo++;
    	}
    	logger.info("---------------the size of return list" + list.size());
		Map<String,CcSurvey> prdSuveyMap = new HashMap<String,CcSurvey>();
		try {
			if(list != null){
	    		
	    		for(ProductServiceRecord prdRecord:list){
	    			logger.info("-----------order code----" + prdRecord.getApptOrderCode());
	    			if(StringUtils.isNotEmpty(prdRecord.getProductTypeName())){
	    				if(!prdSuveyMap.containsKey(prdRecord.getProductTypeName())){
		    				PrdType prdType = productService.getPrdTypeByName(prdRecord.getProductTypeName()).getResult();
		    				if(prdType != null){
		    					CcSurvey model = new CcSurvey();
			    				model.setIssueType("02");
			    				model.setDelFlag("0");
			    				model.setPrdTypeId(prdType.getId());
			    				model = ccSurveyService.findOneByEntity(model);
			    				if(model !=null){
			    					prdSuveyMap.put(prdRecord.getProductTypeName(), model);
			    				}
		    				}
		    			}
	    			}
	    			
	    		}
	    		
			}
			List<Issue> issueList = new ArrayList<Issue>();
			List<IssueOBInfo> issueOBInfoList = new ArrayList<IssueOBInfo>();
			List<IssueOBProductServiceRecord> issueOBPrdList = new ArrayList<IssueOBProductServiceRecord>();

			
			String overtimeccSurveyId = "";
			String overTimeccSurveyTopic = "";
			
			for (ProductServiceRecord prdserviceRecord : list) {
				String apptCode = prdserviceRecord.getApptOrderCode();
				if (StringUtils.isEmpty(apptCode)) {
					continue;
				}

				// 如果预约号已存在，则跳过
				Map<String,Object> params = new HashMap<String,Object>();
				params.put("apptCode", prdserviceRecord.getApptOrderCode());
				params.put("overtimeType", "3");
				List<IssueOBProductServiceRecord> iopsrs = findEntityByParams(params);
				
				if (iopsrs != null && iopsrs.size() > 0) {
					logger.info("---------------------------预约号已存在：" + apptCode);
					continue;
				}

				// 往工单表查数据
				Issue issue = new Issue();
				IssueOBInfo issueOBInfo = new IssueOBInfo();
				String issueId = UUID.randomUUID().toString();
				issue.setId(issueId);
				issue.setIssueCode(issueId); // 设置号码
				if (StringUtils.isNotEmpty(prdserviceRecord.getClinicId())) {
					ClinicInfoApproval clinic = clinicInfoApprovalService.findById(prdserviceRecord.getClinicId());
					if (clinic != null) {
						if (StringUtils.isNotEmpty(clinic.getMobile())) {
							issue.setPhone(clinic.getMobile());
						} else if (StringUtils.isNotEmpty(clinic.getPhone())) {
							issue.setPhone(clinic.getPhone());
						} else {
							logger.info("诊所号码为空，预约订单号:"+ prdserviceRecord.getApptOrderCode());
							continue;
						}
					} else {
						logger.info("诊所为空，预约订单号:"+ prdserviceRecord.getApptOrderCode());
						continue;
					}
				} else {
					logger.info("诊所为空，预约订单号:"+ prdserviceRecord.getApptOrderCode());
					continue;
				}
				if (StringUtils.isNotEmpty(prdserviceRecord.getUserId())) {
					HyUserInfo hyUserInfo = hyUserInfoService
							.getHyUserInfoByHyids(Long
									.parseLong(prdserviceRecord.getUserId()));
					if (hyUserInfo != null) {
						issue.setGender(hyUserInfo.getSex());
					}
				}
				
				if(StringUtils.isNotEmpty(prdserviceRecord.getProductTypeName())){
					if(prdSuveyMap.get(prdserviceRecord.getProductTypeName()) != null){
						overtimeccSurveyId = prdSuveyMap.get(prdserviceRecord.getProductTypeName()).getId();
						overTimeccSurveyTopic =prdSuveyMap.get(prdserviceRecord.getProductTypeName()).getSurveyName();
					}
					
				}

				issue.setIssueTopic(overTimeccSurveyTopic);
				issue.setCreateDate(new Date());
				issue.setCreateUser(Consts.QUARTZ);
				issue.setCallType("1");
				issue.setIsConvey("0");
				issue.setStatus("0");
				issue.setDelFlag("0");
				issueList.add(issue);

				// 插入issue_obinfo
				String issueOBInfoId = UUID.randomUUID().toString();
				issueOBInfo.setId(issueOBInfoId);
				issueOBInfo.setIssueId(issueId);
				issueOBInfo.setObType("1");
				
				issueOBInfo.setOvertimeType("3"); // 评价低分
				issueOBInfo.setSurveyId(overtimeccSurveyId);
				issueOBInfo.setClinicName(prdserviceRecord.getClinicName());
				issueOBInfo.setCreateDate(new Date());
				issueOBInfo.setCreateUser(Consts.QUARTZ);
				issueOBInfo.setDelFlag("0");
				issueOBInfoList.add(issueOBInfo);

				// 插入预约超时工单详情表
				IssueOBProductServiceRecord obServiceRecord = new IssueOBProductServiceRecord();
				org.apache.commons.beanutils.BeanUtils.copyProperties(obServiceRecord, prdserviceRecord);
				obServiceRecord.setApptorderCode(prdserviceRecord.getApptOrderCode());		
				obServiceRecord.setId(UUID.randomUUID().toString());
			
				if (StringUtils.isNotEmpty(prdserviceRecord.getCardId())) {
					String cardId = prdserviceRecord.getCardId();
					ProductKucun pk = new ProductKucun();
					pk.setId(cardId);
					ProductKucun newPk = productKucunService.findOneByEntity(pk);
					if (newPk != null) {
						if (newPk.getAllCardNo() != null)
							obServiceRecord.setCardNo(newPk.getAllCardNo());
					}
				}
				if (prdserviceRecord.getPatientVisit() != null) {
					obServiceRecord.setPatientVisitId(prdserviceRecord.getPatientVisit().getId());
					obServiceRecord.setPatientVisitName(prdserviceRecord.getPatientVisit().getName());
					obServiceRecord.setPatientMobile(prdserviceRecord.getPatientVisit().getMobile());
				}
				
				obServiceRecord.setIsClinicApptConfirmOvertime(prdserviceRecord
						.getIsClinicApptConfirmOverTime());
				obServiceRecord.setIsUserTreatmentConfirmOvertime(prdserviceRecord
						.getIsUserTreatmentConfirmOverTime());
				
				obServiceRecord.setCreateDate(new Date());
				obServiceRecord.setCreateUser(Consts.QUARTZ);
				obServiceRecord.setDelFlag("0");
				
				obServiceRecord.setObId(issueOBInfoId);
				issueOBPrdList.add(obServiceRecord);
				count++;
			}

			if (issueList != null && issueList.size() > 0) {
				insertAllBatch(issueList,issueOBInfoList, issueOBPrdList);
			}
			logger.info("createLowEvaluationIssue---------------生成工单数："+ count);
		}catch(Exception e){
			logger.error("Failed to create issues");
			return 0;
		}
		return count;
	}
}