package com.wanjia.dsi.web.activity.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VODiseaseSmryInfoMapper;
import com.wanjia.dsi.web.cms.activity.model.DiseaseSmryInfo;
import com.wanjia.dsi.web.cms.activity.model.VODiseaseSmryInfo;
import com.wanjia.dsi.web.cms.activity.service.DiseaseSmryInfoService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class DiseaseSmryInfoServiceImpl implements DiseaseSmryInfoService {
	@Autowired
	private VODiseaseSmryInfoMapper voDiseaseSmryInfoMapper;

	@Override
	public JsonResponse<PageInfo<DiseaseSmryInfo>> getDiseaseSmryInfo(List<String> infoIdList, String pageSize,
			String pageNo) {
		// 设置分页参数
		if (StringUtils.isBlank(pageNo)) {
			pageNo = "1";
		}
		// 设置分页参数
		if (StringUtils.isBlank(pageSize)) {
			pageSize = "10";
		}
		List<DiseaseSmryInfo> result = voDiseaseSmryInfoMapper.getDiseaseSmryInfo(infoIdList);
		JsonResponse<PageInfo<DiseaseSmryInfo>> respose = new JsonResponse<PageInfo<DiseaseSmryInfo>>();
		// 设置分页页号和页码
		PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));

		PageInfo<DiseaseSmryInfo> page = new PageInfo<DiseaseSmryInfo>(result);// 获得分页信息
		respose.setResult(page);
		return respose;

	}

	@Override
	public JsonResponse<List<String>> getAllDiseaseId(Date beginDate, Date endDate) {
		VODiseaseSmryInfo voDiseaseSmryInfo = new VODiseaseSmryInfo();
		voDiseaseSmryInfo.setBeginDate(beginDate);
		voDiseaseSmryInfo.setEndDate(endDate);
		List<String> result = voDiseaseSmryInfoMapper.getAllDiseaseId(voDiseaseSmryInfo);
		JsonResponse<List<String>> respose = new JsonResponse<List<String>>();
		respose.setResult(result);
		return respose;
	}

}
