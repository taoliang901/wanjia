package com.wanjia.dsi.product.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.product.dao.mapper.FrameAgreementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.dao.mapper.PrdSubAgreementMapper;
import com.wanjia.dsi.product.model.FrameAgreement;
import com.wanjia.dsi.product.model.PrdAgreementClinic;
import com.wanjia.dsi.product.service.FrameAgreementReadService;


@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class FrameAgreementReadServiceImpl implements FrameAgreementReadService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	// 查询产品库存
	@Resource
	private FrameAgreementMapper frameAgreementMapper;

	@Resource
	private PrdAgreementClinicMapper prdAgreementClinicMapper;
	
	@Resource
	private PrdSubAgreementMapper prdSubAgreementMapper;
	
	@Override
	public JsonResponse<FrameAgreement> findById(String Id){
	    FrameAgreement frameAgreement = new FrameAgreement();
	    JsonResponse<FrameAgreement> jr = new JsonResponse<FrameAgreement>();
	    try{
	        frameAgreement = frameAgreementMapper.findById(Id);
	        jr.setResult(frameAgreement);
	        jr.setStatus(Status.SUCCESS);
	    }catch(Exception e){
	    	logger.error("框架合同findById异常：",e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
	    }

	    return jr;
	}
	
	@Override
	public JsonResponse<List<FrameAgreement>> getList(
			FrameAgreement frameAgreement) {
		JsonResponse<List<FrameAgreement>> response = new JsonResponse<List<FrameAgreement>>();
		try{
			List<FrameAgreement> frameAgreements = frameAgreementMapper.findByEntity(frameAgreement);	
			response.setResult(frameAgreements);
		}catch(Exception e){
			logger.error("框架合同获取列表getList异常：",e);
			response.setStatus(Status.ERROR);
			response.setErrorCode(ErrorType.SystemBusy.getCode());
			response.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return response;
	}

	@Override
	public JsonResponse<Map<String,Object>> findOneById(String FrameAgreementId) {
		JsonResponse<Map<String,Object>> jr = new JsonResponse<Map<String,Object>>();
		Map<String,Object> map = new HashMap<String, Object>();
		try{
			FrameAgreement frameAgreement = frameAgreementMapper.findById(FrameAgreementId);
			
			Map<String,Object> clinicMap = new HashMap<String, Object>();
			clinicMap.put("clinicType", frameAgreement.getClinicType());
			clinicMap.put("agreementId",frameAgreement.getId());
			clinicMap.put("delFlag", "0");
			List<PrdAgreementClinic> prdAgreementClinicList = prdAgreementClinicMapper.findByProperties(clinicMap);
			
			map.put("frameAgreement", frameAgreement);
			if(prdAgreementClinicList != null && prdAgreementClinicList.size()>0){
			    map.put("prdAgreementClinic", prdAgreementClinicList.get(0));
			}
			
			Map<String,Object> subMap = new HashMap<String,Object>();
			subMap.put("agreementId", FrameAgreementId);
			subMap.put("delFlag", "0");
			long countSubAgreement = prdSubAgreementMapper.countByProperties(subMap);
			map.put("countSubAgreement", countSubAgreement);
			
			jr.setResult(map);
			jr.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.error("根据ID获取单个框架合同失败,FrameAgreementId="+FrameAgreementId,e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return jr;
	}

	@Override
	public JsonResponse<List<FrameAgreement>> getListWithRange(
			FrameAgreement frameAgreement) {
		
		JsonResponse<List<FrameAgreement>> jr = new JsonResponse<List<FrameAgreement>>();
		try{
			List<FrameAgreement> frameAgreement2 = frameAgreementMapper.findByEntityRange(frameAgreement);
			jr.setResult(frameAgreement2);
			jr.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.error("获取合同列表getListWithRange异常",e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return jr;
	}

	@Override
	public JsonResponse<FrameAgreement> findAgreementDetail(
			FrameAgreement frameAgreement) {
		
		JsonResponse<FrameAgreement> jr = new JsonResponse<FrameAgreement>();
		try{
			FrameAgreement frameAgreement2 = frameAgreementMapper.findAgreementDetail(frameAgreement);
			jr.setResult(frameAgreement2);
			jr.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.error("框架合同明细findAgreementDetail异常：",e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return jr;
	}

	@Override
	public JsonResponse<PageInfo<FrameAgreement>> getListWithRangePage(
			FrameAgreement frameAgreement, int pageNo, int pageSize) {
		JsonResponse<PageInfo<FrameAgreement>> result = new JsonResponse<PageInfo<FrameAgreement>>();
		Map<String, Object> parameterMap = new HashMap<String, Object>();
		List<FrameAgreement> findAll = null;
		try {
			// this.checkParams(pageName,activityTypeName);
			//Map<String, String> pageNoAndPageSize = super.getPageNoAndPageSize(pageNo, pageSize);
			// 设置分页页号和页码
			PageHelper.startPage(pageNo,pageSize);
			//设置查询参数
			
			parameterMap.put("delFlag", "0");
			//查询
			findAll = frameAgreementMapper.findByEntityRange(frameAgreement);
			// 获得分页信息
			PageInfo<FrameAgreement> page = new PageInfo<FrameAgreement>(findAll);
			List<FrameAgreement> activityList = page.getList();
			
			page.setList(activityList);
			
			result.setResult(page);
			result.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("框架合同获取列表getListWithRangePage 异常：",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}

	@Override
	public String checkDuplicateClinicInAgreement(String agreementId,String clinicId,
			Date beginDate, Date endDate) {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("clinicId", clinicId);
		params.put("status", "1");
		String ret = "0";
		List<FrameAgreement> frameAgreementList = frameAgreementMapper.findByClinicId(params);
		for(FrameAgreement f:frameAgreementList){
			//排除当前合同
			if(f.getId().equals(agreementId)){
				continue;
			}
			Date bDate = f.getBeginDate();
			Date eDate = f.getEndDate();
			
			if(bDate.compareTo(beginDate) == 0){
				ret = f.getContractName();
				break;
			}
			if(eDate.compareTo(endDate) == 0){
				ret = f.getContractName();
				break;
			}
			
			if(beginDate.after(bDate)&&beginDate.before(eDate)){
				ret = f.getContractName();
				break;
			}
			
			if(endDate.after(bDate)&&endDate.before(eDate)){
				ret = f.getContractName();
				break;
			}
		}
		return ret;
	}
	
}
