package com.wanjia.dsi.web.cms.page;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.cms.page.dao.mapper.PageInfoMapper;
import com.wanjia.dsi.cms.page.dao.mapper.PageRecommendImgMapper;
import com.wanjia.dsi.cms.page.dao.mapper.PageRecommendInfoMapper;
import com.wanjia.dsi.cms.page.dao.mapper.PageRecommendInfoVoMapper;
import com.wanjia.dsi.cms.page.dao.mapper.PageRecommendRoleMapper;
import com.wanjia.dsi.cms.page.dao.mapper.PageSiteMapper;
import com.wanjia.dsi.cms.page.dao.mapper.PageSiteTypeMapper;
import com.wanjia.dsi.cms.page.model.PageInfo;
import com.wanjia.dsi.cms.page.model.PageInfoExample;
import com.wanjia.dsi.cms.page.model.PageRecommendImg;
import com.wanjia.dsi.cms.page.model.PageRecommendImgExample;
import com.wanjia.dsi.cms.page.model.PageRecommendInfo;
import com.wanjia.dsi.cms.page.model.PageRecommendInfoCriteria;
import com.wanjia.dsi.cms.page.model.PageRecommendInfoExample;
import com.wanjia.dsi.cms.page.model.PageRecommendInfoVo;
import com.wanjia.dsi.cms.page.model.PageRecommendRole;
import com.wanjia.dsi.cms.page.model.PageRecommendRoleExample;
import com.wanjia.dsi.cms.page.model.PageSite;
import com.wanjia.dsi.cms.page.model.PageSiteExample;
import com.wanjia.dsi.cms.page.model.PageSiteType;
import com.wanjia.dsi.cms.page.model.PageSiteTypeExample;
import com.wanjia.dsi.cms.page.service.PageRecommendInfoService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PageRecommendInfoServiceImpl implements PageRecommendInfoService {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private PageRecommendInfoVoMapper pageRecommendInfoVoMapper;
	
	@Autowired
	private PageRecommendInfoMapper pageRecommendInfoMapper;
	
	@Autowired
	private PageRecommendImgMapper pageRecommendImgMapper;
	
	@Autowired
	private PageRecommendRoleMapper pageRecommendRoleMapper;
	
	@Autowired
	private PageInfoMapper pageInfoMapper;
	
	@Autowired
	private PageSiteMapper pageSiteMapper;
	
	@Autowired
	private PageSiteTypeMapper pageSiteTypeMapper;
	
	@Override
	public JsonResponse<List<PageRecommendInfo>> getPageRecommendInfoList(PageRecommendInfoCriteria criteria) {
		JsonResponse<List<PageRecommendInfo>> respose = new JsonResponse<List<PageRecommendInfo>>();
		PageRecommendInfoExample infoExample = new PageRecommendInfoExample();
		List<PageRecommendInfo> infoList = null;
		try {
			com.wanjia.dsi.cms.page.model.PageRecommendInfoExample.Criteria
				infoCriteria = infoExample.createCriteria();
			infoCriteria.andDelFlagEqualTo("0");//未删除
			if(StringUtils.isNotBlank(criteria.getPageKey())){
				infoCriteria.andPageKeyEqualTo(criteria.getPageKey());
			}
			if(StringUtils.isNotBlank(criteria.getSiteKey())){
				infoCriteria.andSiteKeyEqualTo(criteria.getSiteKey());
			}
			if(StringUtils.isNotBlank(criteria.getId())){
				infoCriteria.andIdEqualTo(criteria.getId());
			}
			if(StringUtils.isNotBlank(criteria.getPageId())){
				infoCriteria.andPageIdEqualTo(criteria.getPageId());
			}
			if(StringUtils.isNotBlank(criteria.getSiteId())){
				infoCriteria.andSiteIdEqualTo(criteria.getSiteId());
			}
			if(StringUtils.isNotBlank(criteria.getSiteTypeId())){
				infoCriteria.andSiteTypeIdEqualTo(criteria.getSiteTypeId());
			}
			if(StringUtils.isNotBlank(criteria.getSiteType())){
				infoCriteria.andSiteTypeEqualTo(criteria.getSiteType());
			}
			if(StringUtils.isNotBlank(criteria.getRecordId())){
				infoCriteria.andRecordIdEqualTo(criteria.getRecordId());
			}
			if(StringUtils.isNotBlank(criteria.getStatus())){
				infoCriteria.andStatusEqualTo(criteria.getStatus());
			}
			infoList = pageRecommendInfoMapper.selectByExample(infoExample);
			respose.setResult(infoList);
		}catch (Exception e) {
			logger.error("根据参数模型查询页面推荐数据信息列表异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
	@Override
	public JsonResponse<List<PageRecommendInfoVo>> getPageRecommendInfoVoList(PageRecommendInfoCriteria criteria) {
		JsonResponse<List<PageRecommendInfoVo>> respose = new JsonResponse<List<PageRecommendInfoVo>>();
		List<PageRecommendInfoVo> infoVoList = null;
		try {
			criteria.setDelFlag("0");//未删除
			criteria.setStatus("1");//已启用
			Date nowDateTime = new Date();
			criteria.setNowDateTime(nowDateTime);
			if(StringUtils.isNotBlank(criteria.getRoleKey())){
				// 角色不为空时，只获取当前角色的推荐信息
				infoVoList = pageRecommendInfoVoMapper.selectInfoVoByEntityWithRole(criteria);
			} else {
				// 角色为空时，获取所有推荐信息
				infoVoList = pageRecommendInfoVoMapper.selectInfoVoByEntity(criteria);
			}
			
			for(PageRecommendInfoVo infoVo : infoVoList){
				String recommendId = infoVo.getId();
				criteria.setRecommendId(recommendId);
				
				// 获取图片信息
				if(StringUtils.isBlank(criteria.getPicSizeKey())){
					criteria.setPicSizeKey("default");
				} else {
					Long imgCount = pageRecommendInfoVoMapper.countInfoVoByEntityWithRoleAndImg(criteria);
					if(imgCount == null || imgCount <= 0){
						criteria.setPicSizeKey("default");
					}
				}
				List<PageRecommendImg> imgList = pageRecommendImgMapper.selectByEntityForImg(criteria);
				if(CollectionUtils.isNotEmpty(imgList)){
					infoVo.setPageRecommendImgList(imgList);
				}
				
				// 获取角色信息
				/*List<PageRecommendRole> roleList = pageRecommendRoleMapper.selectByEntityForRole(criteria);
				if(CollectionUtils.isNotEmpty(roleList)){
					infoVo.setPageRecommendRoleList(roleList);
				}*/
			}
			respose.setResult(infoVoList);
		}catch (Exception e) {
			logger.error("根据参数模型查询页面推荐数据及其附属信息列表异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
	@Override
	public JsonResponse<Long> countPageRecommendInfoAllData(Map<String,Object> map) {
		JsonResponse<Long> respose = new JsonResponse<Long>();
		Long countInfo = 0L;
		try {
			map.put("delFlag", "0");
			countInfo = pageRecommendInfoVoMapper.countEntityByPreperties(map);
			respose.setResult(countInfo);
		}catch (Exception e) {
			logger.error("根据参数模型统计所有页面推荐数据及其附属数量异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
	@Override
	public JsonResponse<Void> deletePageRecommendInfoVo(PageRecommendInfoCriteria criteria) {
		JsonResponse<Void> respose = new JsonResponse<Void>();
		String id = criteria.getId();
		try {
			if(StringUtils.isNotBlank(id)){
				PageRecommendInfo recomInfo = new PageRecommendInfo();
				recomInfo.setId(id);
				recomInfo.setDelFlag("1");//已删除
				pageRecommendInfoMapper.updateByPrimaryKeySelective(recomInfo);
				
				PageRecommendImg img = new PageRecommendImg();
				img.setDelFlag("1");//已删除
				PageRecommendImgExample imgExample = new PageRecommendImgExample();
				imgExample.createCriteria().andRecommendIdEqualTo(id);
				pageRecommendImgMapper.updateByExampleSelective(img, imgExample);
				
				PageRecommendRole role = new PageRecommendRole();
				role.setDelFlag("1");//已删除
				PageRecommendRoleExample roleExample = new PageRecommendRoleExample();
				roleExample.createCriteria().andRecommendIdEqualTo(id);
				pageRecommendRoleMapper.updateByExampleSelective(role, roleExample);
			}else{
				logger.error("根据参数ID删除页面推荐数据错误：主键ID参数为空!");
				respose.setStatus(Status.ERROR);
			}
		}catch (Exception e) {
			logger.error("根据参数ID删除页面推荐数据异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
	@Override
	public JsonResponse<List<PageRecommendInfoVo>> getPageRecommendInfoAllList(Map<String,Object> map) {
		JsonResponse<List<PageRecommendInfoVo>> respose = new JsonResponse<List<PageRecommendInfoVo>>();
		List<PageRecommendInfoVo> infoVoList = null;
		try {
			map.put("delFlag", "0");
			infoVoList = pageRecommendInfoVoMapper.selectEntityByPreperties(map);
			
			PageRecommendInfoCriteria criteria = new PageRecommendInfoCriteria();
			criteria.setDelFlag("0");
			String picSizeKey = (String)map.get("picSizeKey");
			if(StringUtils.isNotBlank(picSizeKey)){
				criteria.setPicSizeKey(picSizeKey);
			}
			String roleKey = (String)map.get("roleKey");
			if(StringUtils.isNotBlank(roleKey)){
				criteria.setRoleKey(roleKey);
			}
			for(PageRecommendInfoVo infoVo : infoVoList){
				String recommendId = infoVo.getId();
				criteria.setRecommendId(recommendId);
				List<PageRecommendImg> imgList = pageRecommendImgMapper.selectByEntityForImg(criteria);
				if(CollectionUtils.isNotEmpty(imgList)){
					infoVo.setPageRecommendImgList(imgList);
				}
				List<PageRecommendRole> roleList = pageRecommendRoleMapper.selectByEntityForRole(criteria);
				if(CollectionUtils.isNotEmpty(roleList)){
					infoVo.setPageRecommendRoleList(roleList);
				}
			}
			respose.setResult(infoVoList);
		}catch (Exception e) {
			logger.error("根据参数模型查询所有页面推荐数据及其附属信息异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
	@Override
	public JsonResponse<List<PageRecommendImg>> getPageRecommendImgList(PageRecommendImg model) {
		JsonResponse<List<PageRecommendImg>> respose = new JsonResponse<List<PageRecommendImg>>();
		PageRecommendImgExample imgExample = new PageRecommendImgExample();
		com.wanjia.dsi.cms.page.model.PageRecommendImgExample.Criteria criteria
			= imgExample.createCriteria();
		try {
			criteria.andDelFlagEqualTo("0");
			if(StringUtils.isNotBlank(model.getId())){
				criteria.andIdEqualTo(model.getId());
			}
			if(StringUtils.isNotBlank(model.getRecommendId())){
				criteria.andRecommendIdEqualTo(model.getRecommendId());
			}
			if(StringUtils.isNotBlank(model.getPicSizeKey())){
				criteria.andPicSizeKeyEqualTo(model.getPicSizeKey());
			}
			List<PageRecommendImg> list = pageRecommendImgMapper.selectByExample(imgExample);
			respose.setResult(list);
		}catch (Exception e) {
			logger.error("根据参数模型查询页面推荐数据图片信息列表异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}

	@Override
	public JsonResponse<List<PageRecommendRole>> getPageRecommendRoleList(PageRecommendRole model) {
		JsonResponse<List<PageRecommendRole>> respose = new JsonResponse<List<PageRecommendRole>>();
		PageRecommendRoleExample roleExample = new PageRecommendRoleExample();
		com.wanjia.dsi.cms.page.model.PageRecommendRoleExample.Criteria criteria
			= roleExample.createCriteria();
		try {
			criteria.andDelFlagEqualTo("0");
			if(StringUtils.isNotBlank(model.getId())){
				criteria.andIdEqualTo(model.getId());
			}
			if(StringUtils.isNotBlank(model.getRecommendId())){
				criteria.andRecommendIdEqualTo(model.getRecommendId());
			}
			if(StringUtils.isNotBlank(model.getRoleKey())){
				criteria.andRoleKeyEqualTo(model.getRoleKey());
			}
			List<PageRecommendRole> list = pageRecommendRoleMapper.selectByExample(roleExample);
			respose.setResult(list);
		}catch (Exception e) {
			logger.error("根据参数模型查询页面推荐角色数据信息列表异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}

	@Override
	public JsonResponse<List<PageInfo>> getPageInfoListByParam(PageInfo model) {
		JsonResponse<List<PageInfo>> respose = new JsonResponse<List<PageInfo>>();
		PageInfoExample pageInfoExample = new PageInfoExample();
		com.wanjia.dsi.cms.page.model.PageInfoExample.Criteria criteria 
			= pageInfoExample.createCriteria();
		try {
			criteria.andDelFlagEqualTo("0");
			if(StringUtils.isNotBlank(model.getId())){
				criteria.andIdEqualTo(model.getId());
			}
			if(StringUtils.isNotBlank(model.getPageName())){
				criteria.andPageNameEqualTo(model.getPageName());
			}
			if(StringUtils.isNotBlank(model.getPageKey())){
				criteria.andPageKeyEqualTo(model.getPageKey());
			}
			if(StringUtils.isNotBlank(model.getTerminalType())){
				criteria.andTerminalTypeEqualTo(model.getTerminalType());
			}
			if(StringUtils.isNotBlank(model.getTerminalSubType())){
				criteria.andTerminalSubTypeEqualTo(model.getTerminalSubType());
			}
			if(StringUtils.isNotBlank(model.getDelFlag())){
				criteria.andDelFlagEqualTo(model.getDelFlag());
			}
			List<PageInfo> list = pageInfoMapper.selectByExample(pageInfoExample);
			respose.setResult(list);
		}catch (Exception e) {
			logger.error("根据参数查询CMS配置的页面信息列表异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}

	@Override
	public JsonResponse<List<PageSite>> getPageSiteListByParam(PageSite model) {
		JsonResponse<List<PageSite>> respose = new JsonResponse<List<PageSite>>();
		PageSiteExample pageSiteExample = new PageSiteExample();
		com.wanjia.dsi.cms.page.model.PageSiteExample.Criteria criteria 
			= pageSiteExample.createCriteria();
		try {
			criteria.andDelFlagEqualTo("0");
			if(StringUtils.isNotBlank(model.getId())){
				criteria.andIdEqualTo(model.getId());
			}
			if(StringUtils.isNotBlank(model.getPageId())){
				criteria.andPageIdEqualTo(model.getPageId());
			}
			if(StringUtils.isNotBlank(model.getSiteName())){
				criteria.andSiteNameEqualTo(model.getSiteName());
			}
			if(StringUtils.isNotBlank(model.getSiteKey())){
				criteria.andSiteKeyEqualTo(model.getSiteKey());
			}
			if(StringUtils.isNotBlank(model.getAllowMulti())){
				criteria.andAllowMultiEqualTo(model.getAllowMulti());
			}
			if(StringUtils.isNotBlank(model.getScreenMulti())){
				criteria.andScreenMultiEqualTo(model.getScreenMulti());
			}
			if(StringUtils.isNotBlank(model.getStatus())){
				criteria.andStatusEqualTo(model.getStatus());
			}
			List<PageSite> list = pageSiteMapper.selectByExample(pageSiteExample);
			respose.setResult(list);
		}catch (Exception e) {
			logger.error("根据参数查询页面推荐位数据信息列表异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}

	@Override
	public JsonResponse<List<PageSiteType>> getPageSiteTypeListByParam(PageSiteType model) {
		JsonResponse<List<PageSiteType>> respose = new JsonResponse<List<PageSiteType>>();
		PageSiteTypeExample pageSiteTypeExample = new PageSiteTypeExample();
		try {
			com.wanjia.dsi.cms.page.model.PageSiteTypeExample.Criteria criteria = 
					pageSiteTypeExample.createCriteria();
			criteria.andDelFlagEqualTo("0");
			if(StringUtils.isNotBlank(model.getPageId())){
				criteria.andPageIdEqualTo(model.getPageId());
			}
			if(StringUtils.isNotBlank(model.getSiteId())){
				criteria.andSiteIdEqualTo(model.getSiteId());
			}
			if(StringUtils.isNotBlank(model.getSiteType())){
				criteria.andSiteTypeEqualTo(model.getSiteType());
			}
			if(StringUtils.isNotBlank(model.getStatus())){
				criteria.andStatusEqualTo(model.getStatus());
			}
			List<PageSiteType> list = pageSiteTypeMapper.selectByExample(pageSiteTypeExample);
			respose.setResult(list);
		}catch (Exception e) {
			logger.error("根据参数查询页面推荐类型数据信息列表异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}

	@Override
	public JsonResponse<Void> insertPageRecommendInfo(PageRecommendInfo record) {
		JsonResponse<Void> respose = new JsonResponse<Void>();
		try{
			pageRecommendInfoMapper.insertSelective(record);
		}catch (Exception e) {
			logger.error("添加页面推荐数据信息异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
	@Override
	public JsonResponse<Void> updatePageRecommendInfo(PageRecommendInfo record) {
		JsonResponse<Void> respose = new JsonResponse<Void>();
		try{
			pageRecommendInfoMapper.updateByPrimaryKeySelective(record);
		}catch (Exception e) {
			logger.error("修改页面推荐数据信息异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}

	@Override
	public JsonResponse<Void> insertPageRecommendImg(PageRecommendImg record) {
		JsonResponse<Void> respose = new JsonResponse<Void>();
		try{
			pageRecommendImgMapper.insertSelective(record);
		}catch (Exception e) {
			logger.error("添加页面推荐图片数据信息异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
	@Override
	public JsonResponse<Void> updatePageRecommendImg(PageRecommendImg record) {
		JsonResponse<Void> respose = new JsonResponse<Void>();
		try{
			PageRecommendImgExample example = new PageRecommendImgExample();
			com.wanjia.dsi.cms.page.model.PageRecommendImgExample.Criteria
			criteria = example.createCriteria();
			criteria.andRecommendIdEqualTo(record.getRecommendId());
			criteria.andPicSizeKeyEqualTo(record.getPicSizeKey());
			pageRecommendImgMapper.updateByExampleSelective(record, example);
		}catch (Exception e) {
			logger.error("修改页面推荐图片数据信息异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}

	@Override
	public JsonResponse<Void> insertPageRecommendRole(PageRecommendRole record) {
		JsonResponse<Void> respose = new JsonResponse<Void>();
		try{
			pageRecommendRoleMapper.insertSelective(record);
		}catch (Exception e) {
			logger.error("添加页面推荐角色数据信息异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
	@Override
	public JsonResponse<Void> updatePageRecommendRole(PageRecommendRole record) {
		JsonResponse<Void> respose = new JsonResponse<Void>();
		try{
			pageRecommendRoleMapper.updateByPrimaryKeySelective(record);
		}catch (Exception e) {
			logger.error("修改页面推荐角色数据信息异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}

	@Override
	public JsonResponse<Long> countPageRecommendRole(PageRecommendInfoCriteria record) {
		JsonResponse<Long> respose = new JsonResponse<Long>();
		try{
			record.setDelFlag("0");
			respose.setResult(pageRecommendRoleMapper.countByEntityForRole(record));
		}catch (Exception e) {
			logger.error("统计页面推荐角色数据信息异常",e);
			respose.setStatus(Status.ERROR);
		}
		return respose;
	}
	
}
