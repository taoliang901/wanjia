package com.wanjia.dsi.common.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wanjia.dsi.common.utils.CommonTools;


/*********************************************************************************
//* Copyright (C) 2014 Pingan Haoche (PAHAOCHE). All Rights Reserved.
//*
//* Filename:      IpInterceptor.java
//* Revision:      1.0
//* Author:        黄雷（平安）
//* Created On:    2014年11月18日
//* Modified by:   
//* Modified On:   
//*
//* Description:   对所有的请求都加入IP白名单验证
/********************************************************************************/
public class LoggerInterceptor extends HandlerInterceptorAdapter {
	
    private Logger logger = Logger.getLogger(LoggerInterceptor.class);

    /**
     * 接口被调用日志
     */
    @SuppressWarnings("rawtypes")
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
       // logger.info("[decode request url is:"+CommonTools.getIpAddr(request)+":"+request.getServerPort()+request.getRequestURI()+"?"+CommonTools.getUrlDecode(request.getQueryString()));
        logger.info("[not decode request url is:"+CommonTools.getIpAddr(request)+":"+request.getServerPort()+request.getRequestURI()+"?"+request.getQueryString());
        return true;
    }

    /*
     * @author Hul
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.web.servlet.handler.HandlerInterceptorAdapter#postHandle
     * (javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse, java.lang.Object,
     * org.springframework.web.servlet.ModelAndView)
     */
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }

    /**
     * @param request
     * @param uri
     * @return
     * @throws Exception
     */
    protected ModelAndView prepareModelAndView(HttpServletRequest request, String uri) throws Exception {
        ModelAndView mv = new ModelAndView();
        return mv;
    }
    
    public static void main(String[] args) {
		Boolean boolean1 = new Boolean("no");
		System.out.println(boolean1.booleanValue());
	}
}
