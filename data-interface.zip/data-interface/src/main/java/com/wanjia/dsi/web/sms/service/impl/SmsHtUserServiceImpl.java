package com.wanjia.dsi.web.sms.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.sms.dao.mapper.SmsHtUserMapper;
import com.wanjia.dsi.web.sms.model.HtUser;
import com.wanjia.dsi.web.sms.model.RoleBean;
import com.wanjia.dsi.web.sms.service.SmsHtUserService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class SmsHtUserServiceImpl extends BaseServiceImpl implements SmsHtUserService {
	@Autowired
	private SmsHtUserMapper smsMapper;

	@Override
	public JsonResponse<HtUser> findByMobileAndPassWord(HtUser htUser) {
		JsonResponse<HtUser> jr = new JsonResponse<HtUser>();
		// 判断传递过来的数据是否为空
		if (htUser == null || StringUtils.isEmpty(htUser.getUserCode()) || StringUtils.isEmpty(htUser.getPassword())) {
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.IllegalArgument.getCode());
			jr.setErrorMsg(ErrorType.IllegalArgument.getDesc());
			return jr;
		}
		try {
			HtUser user = smsMapper.findByMobileAndPassWord(htUser);
			// 用户名不为空的话，并且角色是短信查看员情况时候才返回success
			if (null == user) {
				// 为空说明用户名和密码错误
				logger.info("userCode:"+htUser.getUserCode()+"======password:"+htUser.getPassword());
				jr.setStatus(Status.ERROR);
				jr.setErrorCode(ErrorType.UserNameOrPasswordError.getCode());
				jr.setErrorMsg(ErrorType.UserNameOrPasswordError.getDesc());
			} else if (!checkRoleName(user.getRoleList())) {
				jr.setStatus(Status.ERROR);
				jr.setErrorCode(ErrorType.NOTPERMISSION.getCode());
				jr.setErrorMsg(ErrorType.NOTPERMISSION.getDesc());
			} else {
				jr.setStatus(Status.SUCCESS);
				jr.setResult(user);
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("findByMobileAndPassWord" + e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return jr;
	}

	private boolean checkRoleName(List<RoleBean> list) {
		if (list == null || list.size() == 0) {
			return false;
		}
		for (RoleBean r : list) {
			if ("短信查看员".equals(r.getName())||"机构业务员".equals(r.getName())||"机构管理".equals(r.getName())) {
				return true;
			}
		}
		return false;
	}

}
