package com.wanjia.dsi.product.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.product.dao.mapper.VOPrdClinicMapper;
import com.wanjia.dsi.product.service.HyPrdClinicService;
import com.wanjia.dsi.product.vo.VOPrdClinic_SZ;
import com.wanjia.dsi.product.vo.VOPrdEditClinic_SZ;
import com.wanjia.dsi.web.area.model.City;
import com.wanjia.dsi.web.clinic.dao.mapper.ClinicMapper;
import com.wanjia.dsi.web.clinic.model.Clinic;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class HyPrdClinicServiceImpl implements HyPrdClinicService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private VOPrdClinicMapper vOPrdClinicMapper;

	@Resource
	private ClinicMapper clinicMapper;

	@Override
	public JsonResponse<VOPrdClinic_SZ> getClinicByRegisterId(
			String clinicRegisterId) {

		logger.info("HyPrdClinicService--getClinicByRegisterId--调用开始："
				+ clinicRegisterId);
		// 设置返回参数
		JsonResponse<VOPrdClinic_SZ> res = new JsonResponse<VOPrdClinic_SZ>();
		VOPrdClinic_SZ vOPrdClinic_SZ = new VOPrdClinic_SZ();

		// 查询信息
		Map<String, Object> p2 = new HashMap<String, Object>();
		p2.put("delFlag", "0");
		p2.put("clinicRegisterId", clinicRegisterId);
		List<City> cityList = vOPrdClinicMapper.selectCitysByMap(p2);
		List<Clinic> clinicList = vOPrdClinicMapper.selectClinicsByMap(p2);

		// 返回参数
		vOPrdClinic_SZ.setCityList(cityList);
		vOPrdClinic_SZ.setClinicList(clinicList);
		res.setResult(vOPrdClinic_SZ);
		res.setStatus(Status.SUCCESS);
		return res;
	}

	@Override
	public JsonResponse<VOPrdClinic_SZ> getClinicByCityId(
			String clinicRegisterId, String cityId) {
		logger.info("HyPrdClinicService--getClinicByCityId--调用开始："
				+ clinicRegisterId + "--" + cityId);
		// 设置返回参数
		JsonResponse<VOPrdClinic_SZ> res = new JsonResponse<VOPrdClinic_SZ>();
		VOPrdClinic_SZ vOPrdClinic_SZ = new VOPrdClinic_SZ();

		// 查询信息
		Map<String, Object> p2 = new HashMap<String, Object>();
		p2.put("delFlag", "0");
		p2.put("clinicRegisterId", clinicRegisterId);
		p2.put("cityId", cityId);
		List<Clinic> clinicList = vOPrdClinicMapper.selectClinicsByMap(p2);

		// 返回参数
		vOPrdClinic_SZ.setClinicList(clinicList);
		res.setResult(vOPrdClinic_SZ);
		res.setStatus(Status.SUCCESS);
		return res;
	}

	@Override
	public JsonResponse<VOPrdEditClinic_SZ> getClinicByClinicId(
			String clinicRegisterId, String clinicId) {
		logger.info("HyPrdClinicService--getClinicByClinicId--调用开始："
				+ clinicRegisterId + "--" + clinicId);
		// 设置返回参数
		JsonResponse<VOPrdEditClinic_SZ> res = new JsonResponse<VOPrdEditClinic_SZ>();
		VOPrdEditClinic_SZ vOPrdEditClinic_SZ = new VOPrdEditClinic_SZ();

		// 根据诊所ID查询诊所信息
		Clinic clinic = clinicMapper.findClinicById(clinicId);

		// 查询信息
		Map<String, Object> p2 = new HashMap<String, Object>();
		p2.put("delFlag", "0");
		p2.put("clinicRegisterId", clinicRegisterId);
		p2.put("cityId", clinic.getCityCode());
		List<Clinic> clinicList = vOPrdClinicMapper.selectClinicsByMap(p2);

		// 返回参数
		vOPrdEditClinic_SZ.setClinicList(clinicList);
		vOPrdEditClinic_SZ.setCityId(clinic.getCityCode());
		vOPrdEditClinic_SZ.setCityName(clinic.getCity());
		res.setResult(vOPrdEditClinic_SZ);
		res.setStatus(Status.SUCCESS);
		return res;
	}
}
