package com.wanjia.dsi.web.rz.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.web.rz.dao.mapper.RzResultMapper;
import com.wanjia.dsi.web.rz.model.RzResult;
import com.wanjia.dsi.web.rz.service.RzResultService;

/**
 * This element is automatically generated on 16-6-16 上午9:57, do not modify.
 * <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class RzResultServiceImpl implements RzResultService {

	@Autowired
	private RzResultMapper rzResultMapper;

	@Override
	@Transactional(readOnly = true)
	public RzResult findById(String id) {
		return (RzResult) rzResultMapper.findById(id);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RzResult> findWithPagination(int offset, int count) {
		return (List<RzResult>) rzResultMapper.findWithPagination(offset, count);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RzResult> findAll() {
		return (List<RzResult>) rzResultMapper.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public List<RzResult> findByEntity(RzResult model) {
		return (List<RzResult>) rzResultMapper.findByEntity(model);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RzResult> findByEntityWithPagination(RzResult model, int offset, int count) {
		return (List<RzResult>) rzResultMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	@Transactional(readOnly = true)
	public RzResult findOneByEntity(RzResult model) {
		return (RzResult) rzResultMapper.findOneByEntity(model);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RzResult> findByProperty(String propertyName, String propertyValue) {
		return (List<RzResult>) rzResultMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	@Transactional(readOnly = true)
	public RzResult findOneByProperty(String propertyName, String propertyValue) {
		return (RzResult) rzResultMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RzResult> findByPropertyWithPagination(String propertyName, String propertyValue, int offset,
			int count) {
		return (List<RzResult>) rzResultMapper.findByPropertyWithPagination(propertyName, propertyValue, offset, count);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RzResult> findByProperties(Map<String, Object> map) {
		return (List<RzResult>) rzResultMapper.findByProperties(map);
	}

	@Override
	@Transactional(readOnly = true)
	public long countByEntity(RzResult model) {
		return (long) rzResultMapper.countByEntity(model);
	}

	@Override
	@Transactional(readOnly = true)
	public long countByProperty(String propertyName, String propertyValue) {
		return (long) rzResultMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	@Transactional(readOnly = true)
	public long countByProperties(Map<String, Object> map) {
		return (long) rzResultMapper.countByProperties(map);
	}

	@Override
	public void update(RzResult model) {
		model.setModifyDate(new Date());
		rzResultMapper.update(model);
	}

	@Override
	public void insert(RzResult model) {
		model.setCreateDate(new Date());
		rzResultMapper.insert(model);
	}

	@Override
	public void deleteByEntity(RzResult model) {
		model.setDelFlag("1");
		model.setModifyDate(new Date());
		this.update(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		rzResultMapper.deleteByProperty(propertyName, propertyValue);
	}

	@Transactional(readOnly = true)
	public long countAll() {
		return this.rzResultMapper.countAll();
	}

	public void insertBatch(List<RzResult> list) {
		this.rzResultMapper.insertBatch(list);
	}

	public void delete(String id) {
		RzResult model = new RzResult();
		model.setDelFlag("1");
		model.setModifyDate(new Date());
		model.setId(String.valueOf(id));
		this.rzResultMapper.update(model);
	}
}