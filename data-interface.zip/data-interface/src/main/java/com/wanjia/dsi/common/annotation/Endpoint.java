package com.wanjia.dsi.common.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Endpoint {

    Invoker[] invokers() default {};

    String description() default "";

    String value() default "";

    boolean deprecated() default false;

    public enum Invoker {

        网站前台("P01"), 
        网站服務("P01"), 
        财务("P15"), 
        CMS("P03"), 
        内部网关("G02"), 
        会员服务("G03"),
        运营后台("G04"),
        诊所服务("Y10");

        private final String value;

        private Invoker(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }

}
