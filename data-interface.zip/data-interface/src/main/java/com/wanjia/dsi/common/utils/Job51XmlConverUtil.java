package com.wanjia.dsi.common.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

import com.wanjia.common.utils.DateUtils;



public class Job51XmlConverUtil {
	
	private static final String nfsFilePath = "/nfs/wanjia/settings/job51xml/";

	/** 
     * xml to map xml <node><key label="key1">value1</key><key 
     * label="key2">value2</key>......</node> 
     *  
     * @param xml 
     * @return 
     */  
    @SuppressWarnings({ "rawtypes" })
	public static HashMap<String,String> xmltoMapValueByCode(String xmlName) {  
        try { 
        	String xml = "";
        	
        	File file = new File(nfsFilePath + xmlName + ".XML");
        	if (file.exists()) {
        		xml = readFromFile(file);
			} else {
				file = new File("E:\\projects_branches\\data-interface\\src\\main\\resources\\properties\\job51xml\\" + xmlName + ".XML");
				if (file.exists()) {
					xml = readFromFile(file);
				}else{
					return null;
				}
				
			}
        	
        	HashMap<String,String> map = new HashMap<String,String>();  
            Document document = DocumentHelper.parseText(xml);  
            Element nodeElement = document.getRootElement();  
            List node = nodeElement.elements();  
            for (Iterator it = node.iterator(); it.hasNext();) {  
            	Element elm = (Element) it.next();  
                map.put(elm.elementText("CODE"), elm.elementText("VALUE"));  
                elm = null;  
            }  
            node = null;  
            nodeElement = null;  
            document = null;  
            return map;  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
        return null;  
    }
    
    /** 
     * xml to map xml <node><key label="key1">value1</key><key 
     * label="key2">value2</key>......</node> 
     *  
     * @param xml 
     * @return 
     */  
    @SuppressWarnings({ "rawtypes" })
	public static HashMap<String,String> xmltoMapCodeByValue(String xmlName) {  
        try { 
        	String xml = "";
        	
        	File file = new File(nfsFilePath + xmlName + ".XML");
        	if (file.exists()) {
        		xml = readFromFile(file);
			} else {
				file = new File("E:\\projects_branches\\data-interface\\src\\main\\resources\\properties\\job51xml\\" + xmlName + ".XML");
				xml = readFromFile(file);
			}
        	
        	HashMap<String,String> map = new HashMap<String,String>();  
            Document document = DocumentHelper.parseText(xml);  
            Element nodeElement = document.getRootElement();  
            List node = nodeElement.elements();  
            for (Iterator it = node.iterator(); it.hasNext();) {  
            	Element elm = (Element) it.next();  
                map.put(elm.elementText("VALUE"), elm.elementText("CODE"));  
                elm = null;  
            }  
            node = null;  
            nodeElement = null;  
            document = null;  
            return map;  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
        return null;  
    }
    
    @SuppressWarnings("rawtypes")
	public static List<String> getFunTypeList(){
    	List<String> returnList = new ArrayList<String>();
    	
    	try { 
        	String xml = "";
        	
        	File file = new File(nfsFilePath + "DD_FUNTYPE.XML");
        	if (file.exists()) {
        		xml = readFromFile(file);
			} else {
				file = new File("E:\\projects_branches\\data-interface\\src\\main\\resources\\properties\\job51xml\\" + "DD_FUNTYPE.XML");
				xml = readFromFile(file);
			}
        	
            Document document = DocumentHelper.parseText(xml);  
            Element nodeElement = document.getRootElement();  
            List node = nodeElement.elements();  
            for (Iterator it = node.iterator(); it.hasNext();) {  
            	Element elm = (Element) it.next();  
            	returnList.add(elm.elementText("CODE"));
                elm = null;  
            }  
            node = null;  
            nodeElement = null;  
            document = null;  
        } catch (Exception e) {  
            e.printStackTrace();  
        }
    	return returnList;
    }
    
    @SuppressWarnings("resource")
	public static String readFromFile(File src) {
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(
                    src));
            StringBuilder stringBuilder = new StringBuilder();
            String content;
            while((content = bufferedReader.readLine() )!=null){
                stringBuilder.append(content);
            }
            return stringBuilder.toString();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }

    }
    
    
	@SuppressWarnings("unchecked")
	public static HashMap<String,Object> jobDetailXmlToMap(String xmlStr){
		
    	HashMap<String,Object> returnMap = new HashMap<String,Object>(); 
    	
    	List<HashMap<String,String>> experienceList = new ArrayList<HashMap<String,String>>(); 
    	List<HashMap<String,String>> educationList = new ArrayList<HashMap<String,String>>(); 
    	
    	//基本信息
    	returnMap.put("photo", "");  //照片
    	returnMap.put("current_Situation", "");  //求职状态
    	returnMap.put("email", "");  //email
    	returnMap.put("mobile", "");  //联系电话
    	
    	returnMap.put("name", "");  //姓名
    	returnMap.put("gender", "");   //性别
    	returnMap.put("age", "");  //年龄
    	returnMap.put("birthDay", "");  //生日
    	returnMap.put("province", "");  //居住地
    	returnMap.put("workYear", "");  //开始工作时间
    	returnMap.put("workYearNum", "");  //工作经验
    	
    	//个人信息
    	returnMap.put("huKou", "");  //户口
    	returnMap.put("politics", "");  //政治面貌
    	returnMap.put("marriage", "");  //婚姻状况
    	returnMap.put("address", "");  //家庭地址
    	
    	//目前年收入
    	returnMap.put("currentSalary", "");  //当前薪资
    	
    	//求职意向
    	returnMap.put("key", "");  //关键字
    	returnMap.put("excpectSalary", "");  //期望薪资
    	returnMap.put("epectFunc", "");  //目标职能
    	returnMap.put("entryTime", "");  //到岗时间
    	returnMap.put("expectArea", "");  //期望工作地点
    	returnMap.put("expectIndustry", "");  //希望行业
    	returnMap.put("seekType", "");  //工作性质
    	returnMap.put("qualifSummary", "");  //自我评价
    	
    	//工作经历
    	returnMap.put("experienceList", experienceList); 
    	
    	//教育经历
    	returnMap.put("educationList", educationList);
    	
    	//最近工作
    	returnMap.put("positionTitleLatest", "");  //职位
    	returnMap.put("employerName", "");  //公司
    	returnMap.put("industryLatest", "");  //行业
    	returnMap.put("majorLatest", "");  //专业
    	returnMap.put("schoolNameLatest", "");  //学校
    	returnMap.put("degreeLatest", "");  //学历
    	
    	returnMap.put("revisionDate", "");  //简历版本
    	
    	
    	try { 
    		System.out.println(xmlStr);
	    	Document document = DocumentHelper.parseText(xmlStr);  
	        Element root = document.getRootElement();
	        
	        //照片
	        Node attachments = root.selectSingleNode("//Attachments");  
	        if(attachments != null){
	        	List<Element> attachmentList = attachments.selectNodes("Attachment");
	        	if(!attachmentList.isEmpty() && attachmentList.size() > 0){
	        		for(Element attachment : attachmentList){
	        			if(attachment != null && attachment.selectSingleNode("AttachType") != null && attachment.selectSingleNode("AttachType").getText().equals("照片")){
			        		returnMap.put("photo", attachment.selectSingleNode("AttachFile").getText());
			        		break;
			        	}
			        }
		        }
	        }
	        
	        //关键字
	        Node keyWords = root.selectSingleNode("//resumekey");  
	        String key = "";
	        if(keyWords != null){
	        	List<Element> keyList = keyWords.selectNodes("key");
	        	if(!keyList.isEmpty() && keyList.size() > 0){
	        		for(Element keyEle : keyList){
	        			if(keyEle != null){
	        				key += keyEle.getText() + "  ";
			        	}
			        }
		        }
	        }
	        returnMap.put("key", key);
	        
	        //个人信息   姓名、emial、联系电话
	        Node personalDataNode = root.selectSingleNode("//PersonalData");  
	        if(personalDataNode != null){
	        	//姓名
	        	String name = "";
	        	if(personalDataNode.selectObject("Name") != null){
	        		Element nameElement = (Element) personalDataNode.selectObject("Name");
	        		if(StringUtils.isNotBlank(nameElement.elementText("First"))){
	        			name += nameElement.elementText("First");
	        		}
	        		if(StringUtils.isNotBlank(nameElement.elementText("Last"))){
	        			name += nameElement.elementText("Last");
	        		}
	        	}
	        	returnMap.put("name", name);
	        	
	        	//email
	        	String email = "";
		        if(personalDataNode.selectSingleNode("Email") != null){
		        	email = personalDataNode.selectSingleNode("Email").getText();
		        }
		        returnMap.put("email", email);
	        	
	        	//联系电话
	        	String mobile = "";
	        	Node mobilePhoneNode = root.selectSingleNode("//Voice[@class='MobilePhone']");  
	        	if(mobilePhoneNode != null && mobilePhoneNode.selectSingleNode("TelNumber") != null){
	        		mobile = mobilePhoneNode.selectSingleNode("TelNumber").getText();
	        	}
	        	
	        	if(StringUtils.isBlank(mobile)){
	        		Node homePhoneNode = root.selectSingleNode("//Voice[@class='HomePhone']"); 
	        		if(homePhoneNode != null  && mobilePhoneNode.selectSingleNode("TelNumber") != null){
	        			mobile = mobilePhoneNode.selectSingleNode("TelNumber").getText();
	        		}
	        	}
	        	returnMap.put("mobile", mobile);
	        	
	        }
	        
	        //工作经验
	        Node workYearNode = root.selectSingleNode("//WorkYear");  
	        if(workYearNode != null && StringUtils.isNotBlank(workYearNode.getText())){
	        	if(workYearNode.getText().equals("0")){
	        		returnMap.put("workYear", "无工作经验");
	        	}else{
	        		returnMap.put("workYear", workYearNode.getText() + "年开始工作");
	        		
	        		Date now = new Date();
		        	String nowYear = DateUtils.format(now, "yyyy");
		        	if(StringUtils.isNumeric(workYearNode.getText())){
		        		returnMap.put("workYearNum", (Integer.parseInt(nowYear) - Integer.parseInt(workYearNode.getText())) + "");
		        	}
	        	}
	        }
	        
	        //性别
	        Node genderNode = root.selectSingleNode("//Gender");  
	        if(genderNode != null && StringUtils.isNotBlank(genderNode.getText())){
	        	returnMap.put("gender", genderNode.getText());
	        }
	        
	        //简历更新时间
	        String revisionDate = "";
	        Node revisionNode = root.selectSingleNode("//RevisionDate");  
	        if(revisionNode != null){
	        	Node revisionDateNode = revisionNode.selectSingleNode("Date"); 
	        	
	        	if(revisionDateNode != null && revisionDateNode.selectSingleNode("Year") != null){
	        		revisionDate += revisionDateNode.selectSingleNode("Year").getText() + "-";
	        	}
	        	
	        	if(revisionDateNode != null && revisionDateNode.selectSingleNode("Month") != null){
	        		if(revisionDateNode.selectSingleNode("Month").getText().length() == 1){
	        			revisionDate += "0" + revisionDateNode.selectSingleNode("Month").getText() + "-";
	        		}else{
	        			revisionDate += revisionDateNode.selectSingleNode("Month").getText() + "-";
	        		}
	        		
	        	}
	        	
	        	if(revisionDateNode != null && revisionDateNode.selectSingleNode("Day") != null){
	        		if(revisionDateNode.selectSingleNode("Day").getText().length() == 1){
	        			revisionDate += "0" + revisionDateNode.selectSingleNode("Day").getText();
	        		}else{
	        			revisionDate += revisionDateNode.selectSingleNode("Day").getText();
	        		}
	        	}
        	}
	        returnMap.put("revisionDate", revisionDate);
	        
	        
	        //生日
	        String birthDay = "";
	        String birthYear = "";
	        Node birthDayNode = root.selectSingleNode("//BirthDay");  
	        if(birthDayNode != null){
	        	Node birthDayDateNode = birthDayNode.selectSingleNode("Date"); 
	        	
	        	if(birthDayDateNode != null && birthDayDateNode.selectSingleNode("Year") != null){
	        		birthDay += birthDayDateNode.selectSingleNode("Year").getText() + "年";
        			birthYear = birthDayDateNode.selectSingleNode("Year").getText();
	        	}
	        	
	        	if(birthDayDateNode != null && birthDayDateNode.selectSingleNode("Month") != null){
	        		birthDay += birthDayDateNode.selectSingleNode("Month").getText() + "月";
	        	}
	        	
	        	if(birthDayDateNode != null && birthDayDateNode.selectSingleNode("Day") != null){
	        		birthDay += birthDayDateNode.selectSingleNode("Day").getText() + "日";
	        	}
        	}
	        returnMap.put("birthDay", birthDay);
	        
	        //年龄
	        if(StringUtils.isNotBlank(birthYear)){
	        	Date now = new Date();
	        	String nowYear = DateUtils.format(now, "yyyy");
	        	
	        	returnMap.put("age", (Integer.parseInt(nowYear) - Integer.parseInt(birthYear)) + "");
	        }
	        
	        
	        //居住地、家庭地址
	        Node addressNode = root.selectSingleNode("//Address");  
	        if(addressNode != null && addressNode.selectSingleNode("AddressLine") != null){
	        	returnMap.put("address", addressNode.selectSingleNode("AddressLine").getText());
	        }else{
	        	returnMap.put("address", "");
	        }
	        if(addressNode != null && addressNode.selectSingleNode("Province") != null){
	        	returnMap.put("province", addressNode.selectSingleNode("Province").getText());
	        }else{
	        	returnMap.put("province", "");
	        }
	        
	        //户口
	        Node huKouNode = root.selectSingleNode("//HuKou");  
	        if(huKouNode != null && StringUtils.isNotBlank(huKouNode.getText())){
	        	returnMap.put("huKou", huKouNode.getText());
	        }else{
	        	returnMap.put("huKou", "");
	        }
	        
	        //政治面貌
	        Node politicsNode = root.selectSingleNode("//Politics_Status");  
	        if(politicsNode != null && StringUtils.isNotBlank(politicsNode.getText())){
	        	returnMap.put("politics", politicsNode.getText());
	        }else{
	        	returnMap.put("politics", "");
	        }
	    	
	        //婚姻状况
	        Node marriageNode = root.selectSingleNode("//Marriage");  
	        if(marriageNode != null && StringUtils.isNotBlank(marriageNode.getText())){
	        	returnMap.put("marriage", marriageNode.getText());
	        }else{
	        	returnMap.put("marriage", "");
	        }
	        
	        //薪资
	        Node compensationDetailNode = root.selectSingleNode("//CompensationDetail");  
	        if(compensationDetailNode != null){
	        	if(compensationDetailNode.selectObject("Salary") != null){
	        		Element salaryElement = (Element) compensationDetailNode.selectObject("Salary");
	        		if(StringUtils.isNotBlank(salaryElement.elementText("Current")) || StringUtils.isNotBlank(salaryElement.elementText("CurrentInput"))){
	        			String currentSalary = "";
	        			if(StringUtils.isNotBlank(salaryElement.elementText("Current"))){
	        				currentSalary = salaryElement.elementText("Current") + salaryElement.elementText("Currtype");
	        			}else{
	        				currentSalary = salaryElement.elementText("CurrentInput") + salaryElement.elementText("Currtype");
	        			}
	        			if(StringUtils.isNotBlank(salaryElement.elementText("CurrentType"))){
	        				currentSalary += "(" +salaryElement.elementText("CurrentType") + ")";
	        			}
	        			returnMap.put("currentSalary", currentSalary);
	        		}else{
	        			returnMap.put("currentSalary", "暂无");
	        		}
	        		
	        		if(StringUtils.isNotBlank(salaryElement.elementText("Required")) || StringUtils.isNotBlank(salaryElement.elementText("RequiredInput"))){
	        			String excpectSalary = "";
	        			
	        			if(StringUtils.isNotBlank(salaryElement.elementText("RequiredInput"))){
	        				returnMap.put("excpectSalaryMinMax", salaryElement.elementText("RequiredInput"));
	        			}
	        			
	        			if(StringUtils.isNotBlank(salaryElement.elementText("Required"))){
	        				if("面议".equals(salaryElement.elementText("Required"))){
	        					excpectSalary = salaryElement.elementText("Required");
	        				}else{
	        					excpectSalary = salaryElement.elementText("Required") + salaryElement.elementText("Currtype");
	        				}
	        			}else{
	        				excpectSalary = salaryElement.elementText("RequiredInput") + salaryElement.elementText("Currtype");
	        			}
	        			if(StringUtils.isNotBlank(salaryElement.elementText("RequiredType"))){
	        				if(!"面议".equals(salaryElement.elementText("Required"))){
	        					excpectSalary += "(" +salaryElement.elementText("RequiredType") + ")";
	        				}
	        			}
	        			returnMap.put("excpectSalary", excpectSalary);
	        		}else{
	        			returnMap.put("excpectSalary", "面议");
	        		}
	        	}
	        }
	        
	        
	        //最近工作、工作经历
	        Node employmentHistoryNode = root.selectSingleNode("//EmploymentHistory");  
	        if(employmentHistoryNode != null){
	        	List<Element> positionList = employmentHistoryNode.selectNodes("Position");
		        if(!positionList.isEmpty() && positionList.size() > 0){
		        	Element positionLatestElement = positionList.get(0);
		        	//公司
		        	if(positionLatestElement != null && positionLatestElement.selectSingleNode("EmployerName") != null){
		        		returnMap.put("companyLatest", positionLatestElement.selectSingleNode("EmployerName").getText());
		        	}
		        	
		        	//行业
		        	if(positionLatestElement != null && positionLatestElement.selectSingleNode("Industry") != null){
		        		returnMap.put("industryLatest", positionLatestElement.selectSingleNode("Industry").getText());
		        	}
		        	
		        	//职位
		        	if(positionLatestElement != null && positionLatestElement.selectSingleNode("PositionTitle") != null){
		        		returnMap.put("positionTitleLatest", positionLatestElement.selectSingleNode("PositionTitle").getText());
		        	}
		        	
		        	for(Element positionElement : positionList){
		        		HashMap<String,String> position = new HashMap<String,String>();
		        		
		        		//公司
			        	if(positionElement != null && positionElement.selectSingleNode("EmployerName") != null){
			        		position.put("company", positionElement.selectSingleNode("EmployerName").getText());
			        	}
		                
		                //部门
			        	if(positionElement != null && positionElement.selectSingleNode("Department") != null){
			        		position.put("department", positionElement.selectSingleNode("Department").getText());
			        	}
			        	
			        	//职位
			        	if(positionElement != null && positionElement.selectSingleNode("PositionTitle") != null){
			        		position.put("positionTitle", positionElement.selectSingleNode("PositionTitle").getText());
			        	}
			        	
			        	//行业
			        	if(positionElement != null && positionElement.selectSingleNode("Industry") != null){
			        		position.put("industry", positionElement.selectSingleNode("Industry").getText());
			        	}
			        	
			        	//公司性质
			        	if(positionElement != null && positionElement.selectSingleNode("CompanyType") != null){
			        		position.put("companyType", positionElement.selectSingleNode("CompanyType").getText());
			        	}
			        	
			        	//公司规模
			        	if(positionElement != null && positionElement.selectSingleNode("CompanySize") != null){
			        		if(StringUtils.isNotBlank(positionElement.selectSingleNode("CompanySize").getText())){
			        			position.put("companySize", positionElement.selectSingleNode("CompanySize").getText().replace("人", "")+"人");
			        		}
			        	}
			        	
			        	//工作性质
			        	if(positionElement != null && positionElement.selectSingleNode("WorkType") != null){
			        		position.put("workType", positionElement.selectSingleNode("WorkType").getText());
			        	}
			        	
			        	//工作开始时间yyyy/MM,例如2016/7
			        	String startDate = "";
			        	if(positionElement.selectSingleNode("//EffectiveDate//StartDate//Year")!= null){
			        		startDate += positionElement.selectSingleNode("//EffectiveDate//StartDate//Year").getText();
			        	}
			        	
			        	if(positionElement.selectSingleNode("//EffectiveDate//StartDate//Month") != null){
			        		startDate += "/" + positionElement.selectSingleNode("//EffectiveDate//StartDate//Month").getText();
			        	}
			        	
			        	position.put("startDate", startDate);
			        	
			        	//工作结束时间yyyy/MM,例如2016/7
			        	String endDate = "";
			        	if(positionElement.selectSingleNode("//EffectiveDate//EndDate//Year") != null){
			        		endDate += positionElement.selectSingleNode("//EffectiveDate//EndDate//Year").getText();
			        	}
			        	
			        	if(positionElement.selectSingleNode("//EffectiveDate//EndDate//Month") != null){
			        		endDate += "/" + positionElement.selectSingleNode("//EffectiveDate//EndDate//Month").getText();
			        	}
			        	
			        	position.put("endDate", endDate);
			        	

			        	//工作总结
			        	if(positionElement != null && positionElement.selectSingleNode("SummaryText") != null){
			        		position.put("summary", positionElement.selectSingleNode("SummaryText").getText());
			        	}
			        	
			        	experienceList.add(position);
			        	
			        }
		        }
	        }
	        returnMap.put("experienceList", experienceList);
	        
	        //教育经历、教育经历
	        Node educationQualifsNode = root.selectSingleNode("//EducationQualifs");  
	        if(educationQualifsNode != null){
	        	List<Element> schoolOrInstitutionList = educationQualifsNode.selectNodes("SchoolOrInstitution");
		        if(!schoolOrInstitutionList.isEmpty() && schoolOrInstitutionList.size() > 0){
		        	Element schoolOrInstitutionElement = schoolOrInstitutionList.get(0);
		        	//学历
		        	if(schoolOrInstitutionElement != null && schoolOrInstitutionElement.selectSingleNode("EduDegree") != null){
		        		returnMap.put("degreeLatest", schoolOrInstitutionElement.selectSingleNode("EduDegree").getText());
		        		Element eduDegree = (Element) schoolOrInstitutionElement.selectNodes("EduDegree").get(0);
		        		returnMap.put("degreeLatestCode", eduDegree.attributeValue("class"));
		        	}
		        	
		        	//专业
		        	if(schoolOrInstitutionElement != null && schoolOrInstitutionElement.selectSingleNode("EduMajor") != null){
		        		returnMap.put("majorLatest", schoolOrInstitutionElement.selectSingleNode("EduMajor").getText());
		        	}
		        	
		        	//学校
		        	if(schoolOrInstitutionElement != null && schoolOrInstitutionElement.selectSingleNode("SchoolName") != null){
		        		returnMap.put("schoolNameLatest", schoolOrInstitutionElement.selectSingleNode("SchoolName").getText());
		        	}
		        	
		        	for(Element schoolElement : schoolOrInstitutionList){
                        HashMap<String,String> education = new HashMap<String,String>();
                        
                        //是否全日制,学校名称
                        if(schoolElement != null && schoolElement.selectSingleNode("SchoolName") != null){
                        	education.put("schoolName", schoolElement.selectSingleNode("SchoolName").getText());
                        	Element schoolName = (Element) schoolElement.selectSingleNode("SchoolName");
                        	education.put("isfulltime", schoolName.attributeValue("isfulltime"));
    		        	}
                       
                        //学历
    		        	if(schoolElement != null && schoolElement.selectSingleNode("EduDegree") != null){
    		        		education.put("degree", schoolElement.selectSingleNode("EduDegree").getText());
    		        	}
    		        	
    		        	//专业
    		        	if(schoolElement != null && schoolElement.selectSingleNode("EduMajor") != null){
    		        		education.put("major", schoolElement.selectSingleNode("EduMajor").getText());
    		        	}
			        	
			        	//工作开始时间yyyy/MM,例如2016/7
			        	String startDate = "";
			        	if(schoolElement.selectSingleNode("//EffectiveDate//StartDate//Year") != null){
			        		startDate += schoolElement.selectSingleNode("//EffectiveDate//StartDate//Year").getText();
			        	}
			        	
			        	if(schoolElement.selectSingleNode("//EffectiveDate//StartDate//Month") != null){
			        		startDate += "/" + schoolElement.selectSingleNode("//EffectiveDate//StartDate//Month").getText();
			        	}
			        	
			        	education.put("startDate", startDate);
			        	
			        	//工作结束时间yyyy/MM,例如2016/7
			        	String endDate = "";
			        	if(schoolElement.selectSingleNode("//EffectiveDate//EndDate//Year") != null){
			        		endDate += schoolElement.selectSingleNode("//EffectiveDate//EndDate//Year").getText();
			        	}
			        	
			        	if(schoolElement.selectSingleNode("//EffectiveDate//EndDate//Month") != null){
			        		endDate += "/" + schoolElement.selectSingleNode("//EffectiveDate//EndDate//Month").getText();
			        	}
			        	
			        	education.put("endDate", endDate);

			        	//总结
			        	if(schoolElement != null && schoolElement.selectSingleNode("SummaryText") != null){
			        		education.put("summary", schoolElement.selectSingleNode("SummaryText").getText());
			        	}
			        	
			        	educationList.add(education);
		        	}
		        }
	        }
	        returnMap.put("educationList", educationList);
	        
	        //自我评价
	        Node qualifSummaryNode = root.selectSingleNode("//QualifSummary");  
	        if(qualifSummaryNode != null && StringUtils.isNotBlank(qualifSummaryNode.getText())){
	        	returnMap.put("qualifSummary", qualifSummaryNode.getText());
	        }else{
	        	returnMap.put("qualifSummary", "");
	        }
	        
	        //到岗时间
	        Node entryTimeNode = root.selectSingleNode("//EntryTime");  
	        if(entryTimeNode != null && StringUtils.isNotBlank(entryTimeNode.getText())){
	        	returnMap.put("entryTime", entryTimeNode.getText());
	        }else{
	        	returnMap.put("entryTime", "");
	        }
	        
	        //工作性质
	        Node seekTypeNode = root.selectSingleNode("//SeekType");  
	        if(seekTypeNode != null && StringUtils.isNotBlank(seekTypeNode.getText())){
	        	returnMap.put("seekType", seekTypeNode.getText());
	        }else{
	        	returnMap.put("seekType", "");
	        }
	        
	        //希望行业
	        StringBuffer expectIndustry = new StringBuffer("");
	        Node expectIndustrysNode = root.selectSingleNode("//ExpectIndustrys");
	        if(expectIndustrysNode != null){
	        	List<Element> expectIndustryList = expectIndustrysNode.selectNodes("ExpectIndustry");
		        if(!expectIndustryList.isEmpty() && expectIndustryList.size() > 0){
		        	for(int i =0;i<expectIndustryList.size();i++){
		        		if(StringUtils.isNotBlank(expectIndustryList.get(i).getText())){
		        			if(i == expectIndustryList.size()-1){
		        				expectIndustry.append(expectIndustryList.get(i).getText());
		        			}else{
		        				expectIndustry.append(expectIndustryList.get(i).getText() + ",");
		        			}
		        		}
		        	}
		        	returnMap.put("expectIndustry", expectIndustry.toString());
		        }
	        }
	        
	        //期望工作地点
	        StringBuffer expectArea = new StringBuffer("");
	        Node expectAreasNode = root.selectSingleNode("//ExpectAreas");  
	        if(expectAreasNode != null){
	        	List<Element> expectAreaList = expectAreasNode.selectNodes("ExpectArea");
		        if(!expectAreaList.isEmpty() && expectAreaList.size() > 0){
		        	for(int i =0;i<expectAreaList.size();i++){
		        		if(StringUtils.isNotBlank(expectAreaList.get(i).getText())){
		        			if(i == expectAreaList.size()-1){
		        				expectArea.append(expectAreaList.get(i).getText());
		        			}else{
		        				expectArea.append(expectAreaList.get(i).getText() + ",");
		        			}
		        			
		        		}
		        	}
		        	returnMap.put("expectArea", expectArea.toString());
		        }
	        }
	        
            //目标职能
	        StringBuffer epectFunc = new StringBuffer("");
	        Node expectFuncsNode = root.selectSingleNode("//ExpectFuncs");  
	        if(expectFuncsNode != null){
	        	List<Element> expectFuncList = expectFuncsNode.selectNodes("ExpectFunc");
		        if(!expectFuncList.isEmpty() && expectFuncList.size() > 0){
		        	for(int i =0;i<expectFuncList.size();i++){
		        		if(StringUtils.isNotBlank(expectFuncList.get(i).getText())){
		        			if(i == expectFuncList.size()-1){
		        				epectFunc.append(expectFuncList.get(i).getText());
		        			}else{
		        				epectFunc.append(expectFuncList.get(i).getText() + ",");
		        			}
		        			
		        		}
		        	}
		        	returnMap.put("epectFunc", epectFunc.toString());
		        }
	        }
	        
	        //求职状态
	        Node current_SituationNode = root.selectSingleNode("//Current_Situation");  
	        if(current_SituationNode != null && StringUtils.isNotBlank(current_SituationNode.getText())){
	        	returnMap.put("current_Situation", current_SituationNode.getText());
	        }else{
	        	returnMap.put("current_Situation", "");
	        }
	        
        
    	}catch (Exception e) {  
            e.printStackTrace();  
        }  
    	return returnMap;
    }
    
    /**
	 * main 测试方法
	 */
	public static void main(String[] args) {
		String jsonStr = "<msg>221111111111</msg>";
		System.out.println(jsonStr.substring(jsonStr.indexOf("<msg>")+5, jsonStr.indexOf("</msg>")));
		xmltoMapValueByCode("DD_FUNTYPE");
//		System.out.println(Arrays.toString("﻿<?xml".getBytes()));
//		System.out.println(Arrays.toString("﻿﻿<?xml".getBytes()));
//		System.out.println("﻿<?xml".equals("﻿﻿<?xml"));
		System.out.println(jobDetailXmlToMap("<?xml version=\"1.0\" encoding=\"utf-8\"?><Resume id=\"100115\" accountid=\"100115\"><ResumeProlog><RevisionDate><Date><Month>1</Month><Day>21</Day><Year>2014</Year></Date></RevisionDate><CompensationDetail><Salary><Current class=\"04\" typeclass=\"01\">4-5万</Current><Currtype class=\"01\">人民币</Currtype><Required class=\"00\">面议</Required></Salary></CompensationDetail></ResumeProlog><ResumeBody><PersonalData><Name></Name><Address><AddressLine><![CDATA[上海市老沪闵路790弄10号601室]]></AddressLine><Province class=\"020000\">上海</Province><PostalCode>200237</PostalCode><Country class=\"001\">中国大陆</Country></Address><Voice class=\"HomePhone\"></Voice><Voice class=\"FirmPhone\"></Voice><Voice class=\"MobilePhone\"></Voice><Pager><IntlCode>086</IntlCode><AreaCode/><TelNumber/><Extension/></Pager><Email><![CDATA[olive.test@51job.com]]></Email><ProfileStatus>1</ProfileStatus></PersonalData><eHireSection><Gender class=\"0\">男</Gender><HomePage><![CDATA[]]></HomePage><ID><IdType class=\"0\">身份证</IdType><IdCard><![CDATA[310112197709036437]]></IdCard></ID><BirthDay><Date><Month>9</Month><Day>3</Day><Year>1977</Year></Date></BirthDay><HuKou class=\"020000\">上海</HuKou><WorkYear class=\"6\">5-7年</WorkYear><TopMajor class=\"0503\">工业设计</TopMajor><TopDegree class=\"6\">本科</TopDegree><GroupFlag><HighGroup class=\"1\">高级</HighGroup><ITGroup class=\"1\">I.T.</ITGroup><StudentGroup class=\"0\"/></GroupFlag><Objective><EntryTime class=\"\"/><SeekType class=\"0\">全职</SeekType><ExpectAreas/><ExpectIndustrys/><ExpectFuncs><ExpectFunc class=\"0303\">市场/营销/拓展主管</ExpectFunc><ExpectFunc class=\"0302\">市场/营销/拓展经理</ExpectFunc><ExpectFunc class=\"0336\">市场企划经理/主管</ExpectFunc><ExpectFunc class=\"0306\">产品/品牌经理</ExpectFunc><ExpectFunc class=\"2606\">项目经理</ExpectFunc></ExpectFuncs><CompanyTypes/></Objective><VideoUrl/><ALITALKID><![CDATA[]]></ALITALKID><QQID><![CDATA[]]></QQID><Current_Situation class=\"3\">观望有好的机会再考虑</Current_Situation><Stature/><Marriage class=\"\"/><TopIndustry class=\"\"/><TopFuncType class=\"\"/><IsMBA class=\"\"/><AddType class=\"0\"/><usertags><StartDate><Date><Month/><Day/><Year/></Date></StartDate><EndDate><Date><Month/><Day/><Year/></Date></EndDate></usertags><resumekey><![CDATA[]]></resumekey><mp_verifystatus>3</mp_verifystatus><idcard_verifystatus>3</idcard_verifystatus><topdegree_verifystatus>3</topdegree_verifystatus><spokenShowStatus effective=\"0\">2</spokenShowStatus><designShowStatus effective=\"0\">2</designShowStatus><OpenStatus>0</OpenStatus><Politics_Status class=\"\"/></eHireSection><StructuredResume><EmploymentHistory><Position class=\"6365447\"><EmployerName><![CDATA[上海福禧达通信设备有限公司]]></EmployerName><Department><![CDATA[市场部]]></Department><PositionTitle class=\"0303\" extra=\"0\"><![CDATA[市场/营销/拓展主管]]></PositionTitle><Industry class=\"04\">贸易/进出口</Industry><CompanyType class=\"06\">民营公司</CompanyType><CompanySize class=\"\"/><IsOverseas class=\"\"/><Overseas class=\"\"/><EffectiveDate><StartDate><Date><Month>3</Month><Day>1</Day><Year>2003</Year></Date></StartDate><EndDate><Date><Month>4</Month><Day>1</Day><Year>2004</Year></Date></EndDate></EffectiveDate><ExcecutiveNeed><ReportBoss><![CDATA[CEO]]></ReportBoss><ReportPersonNumber><![CDATA[1]]></ReportPersonNumber><LeaveReason><![CDATA[公司被解散]]></LeaveReason><Reference><![CDATA[]]></Reference><Score><![CDATA[策划了成都“萌动青春——XELIBRI新产品上市推广”大型路演活动]]></Score></ExcecutiveNeed><SummaryText><![CDATA[1]&#x20;公司曾在全国范围内代理了京瓷、松下、XELIBRI、迪比特、中桥VK、大显等手机品牌；2]&#x20;负责公司代理产品的终端促销、推广活动的策划、管理，以及礼品、宣传物料的管理等工作；3]&#x20;负责公司促销员的管理工作，包括招聘、培训、工作考核、奖惩办法的指定以及与终端门店如永乐、星际通的沟通等，及时处理促销员所遇到的各种问题；4]&#x20;配合西门子公司的XELIBRI上市计划，策划了成都“萌动青春――XELIBRI新产品上市推广”大型路演活动，方案获西门子通过，后因双方合作失败最终没有实施。]]></SummaryText></Position><Position class=\"3000328\"><EmployerName><![CDATA[上海奥韦士国际贸易有限公司]]></EmployerName><Department><![CDATA[市场策划部]]></Department><PositionTitle class=\"0304\" extra=\"0\"><![CDATA[市场/营销/拓展专员]]></PositionTitle><Industry class=\"04\">贸易/进出口</Industry><CompanyType class=\"06\">民营公司</CompanyType><CompanySize class=\"\"/><IsOverseas class=\"\"/><Overseas class=\"\"/><EffectiveDate><StartDate><Date><Month>9</Month><Day>1</Day><Year>2001</Year></Date></StartDate><EndDate><Date><Month>9</Month><Day>1</Day><Year>2002</Year></Date></EndDate></EffectiveDate><ExcecutiveNeed><ReportBoss><![CDATA[]]></ReportBoss><ReportPersonNumber><![CDATA[]]></ReportPersonNumber><LeaveReason><![CDATA[考研；公司内部人事关系复杂，公司发展空间小，也不利于个人发展。]]></LeaveReason><Reference><![CDATA[]]></Reference><Score><![CDATA[主办参加了2002年4月21－24日在上海国际展览中心举办的第十届上海国际陶瓷、化工建材、装饰材料博览会]]></Score></ExcecutiveNeed><SummaryText><![CDATA[1]&#x20;公司是国际著名化工建材品牌德高(DAVCO)在上海地区的总代理；2]&#x20;整合市场信息，分析终端用户的消费趋向和竞争产品的性能特点，组织、策划德高（DAVCO）系列产品的促销、展览展示活动；主办参加了2002年4月21－24日在上海国际展览中心举办的第十届上海国际陶瓷、化工建材、装饰材料博览会；3]&#x20;负责零售终端德高品牌形象的宣传与管理、产品资料的制作等工作。]]></SummaryText></Position><Position class=\"32047\"><EmployerName><![CDATA[上海天赐实业（集团）有限公司]]></EmployerName><Department><![CDATA[营业管理部]]></Department><PositionTitle class=\"0329\" extra=\"1\"><![CDATA[市场助理]]></PositionTitle><Industry class=\"01\">计算机软件</Industry><CompanyType class=\"06\">民营公司</CompanyType><CompanySize class=\"\"/><IsOverseas class=\"\"/><Overseas class=\"\"/><EffectiveDate><StartDate><Date><Month>7</Month><Day>1</Day><Year>2000</Year></Date></StartDate><EndDate><Date><Month>7</Month><Day>1</Day><Year>2001</Year></Date></EndDate></EffectiveDate><ExcecutiveNeed><ReportBoss><![CDATA[]]></ReportBoss><ReportPersonNumber><![CDATA[]]></ReportPersonNumber><LeaveReason><![CDATA[个人原因]]></LeaveReason><Reference><![CDATA[]]></Reference><Score><![CDATA[2001年参与策划了四方股票机在上海市第十一届人民代表大会第四次会议的展销活动]]></Score></ExcecutiveNeed><SummaryText><![CDATA[1]&#x20;公司主营通信服务、房地产、物业管理等业务，所属四方寻呼是中国最大的股票信息服务台之一；2]&#x20;设计调查问卷，制作调研计划，分析竞争对手营销策略，策划并落实媒体宣传计划（报纸、电视电台、户外灯箱、出租车广告等），如《新民晚报》、《服务导报》、教育台绿叶剧场、巴士出租等；3]&#x20;统一负责终端专卖店、加盟店的公司形象宣传和管理，参与公司展览、促销活动的策划及部分设计工作，2001年参与策划了四方股票机在上海市第十一届人民代表大会第四次会议的展销活动。]]></SummaryText></Position></EmploymentHistory><EducationQualifs><SchoolOrInstitution class=\"764326\"><SchoolName isfulltime=\"\" is211=\"\" is985=\"\"><![CDATA[上海交通大学]]></SchoolName><extra_verifystatus/><top_verifystatus/><istopdegree/><isextradegree/><IsOverseas class=\"\"/><Overseas class=\"\"/><IsMBA class=\"\"/><EduDegree class=\"6\">本科</EduDegree><EduMajor class=\"0503\" extra=\"0\"><![CDATA[工业设计]]></EduMajor><EffectiveDate><StartDate><Date><Month>9</Month><Day>1</Day><Year>1996</Year></Date></StartDate><EndDate><Date><Month>7</Month><Day>1</Day><Year>2000</Year></Date></EndDate></EffectiveDate><SummaryText><![CDATA[工业设计专业有一下三个研究方向:产品造型设计、视觉传达设计、环境艺术设计。]]></SummaryText></SchoolOrInstitution><SchoolOrInstitution class=\"48391\"><SchoolName isfulltime=\"\" is211=\"\" is985=\"\"><![CDATA[山东省定陶一中]]></SchoolName><extra_verifystatus/><top_verifystatus/><istopdegree/><isextradegree/><IsOverseas class=\"\"/><Overseas class=\"\"/><IsMBA class=\"\"/><EduDegree class=\"2\">高中</EduDegree><EduMajor class=\"\" extra=\"0\"><![CDATA[]]></EduMajor><EffectiveDate><StartDate><Date><Month>8</Month><Day>1</Day><Year>1993</Year></Date></StartDate><EndDate><Date><Month>7</Month><Day>1</Day><Year>1996</Year></Date></EndDate></EffectiveDate><SummaryText><![CDATA[理科]]></SummaryText></SchoolOrInstitution></EducationQualifs><ForeignLanguageQualifs><ForeignLanguage class=\"1\"><LanguageName class=\"01\">英语</LanguageName><LanguageLevel class=\"2\">良好</LanguageLevel><LanguageLSAbility class=\"\"/><LanguageRWAbility class=\"\"/></ForeignLanguage><ENLevel class=\"\"/><TOEFL/><GRE/><GMAT/><IELTS/><TOEIC/><JPLevel class=\"\"/></ForeignLanguageQualifs><CertificationQualifs><Certification class=\"109112\"><EffectiveDate><Date><Date><Month>9</Month><Day>1</Day><Year>1998</Year></Date></Date></EffectiveDate><CertificationTitle class=\"0108\"><![CDATA[大学英语四级]]></CertificationTitle><Score><![CDATA[]]></Score><verifystatus/></Certification></CertificationQualifs><QualifSummary><![CDATA[1]&#x20;组织、操作能力强，有良好的思维创造能力；2]&#x20;人品好，诚恳稳重，工作上严谨踏实，具有团队精神；3]&#x20;结构化的思维，注重方法和逻辑，有较强的分析问题、解决问题的能力；4]&#x20;兴趣广泛，爱好阅读、篆刻、音乐、体育运动（篮球、羽毛球等）。]]></QualifSummary><SummaryText/></StructuredResume></ResumeBody></Resume>"));
	}
}
