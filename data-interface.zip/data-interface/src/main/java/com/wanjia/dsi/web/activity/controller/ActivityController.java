/**   
* @Title: ActivityController.java 
* @Package com.wanjia.dsi.web.banner.controller 
* @Description: TODO(用一句话描述该文件做什么) 
* @author CHENKANG560  
* @date 2016年3月1日 下午3:32:07 
* @version V1.0   
*/
package com.wanjia.dsi.web.activity.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wanjia.dsi.web.activity.model.Activity;
import com.wanjia.dsi.web.activity.model.CmsPageConfig;
import com.wanjia.dsi.web.activity.service.ActivityService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.controller.BaseWebController;
import com.wanjia.dsi.common.annotation.Endpoint;
import com.wanjia.dsi.common.annotation.Name;
import com.wanjia.dsi.common.annotation.Endpoint.Invoker;

/** 
* @ClassName: ActivityController 
* @Description: TODO(这里用一句话描述这个类的作用) 
* @author Chenkang
 * @date 2016年3月1日 下午3:32:07
 * 
 */
@Controller
public class ActivityController extends BaseWebController {

	@Autowired
	private ActivityService activityService;

	
	/***
	 * test updateSpecialStatus
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/activity/updateSpecialStatus.do")
	@ResponseBody
	public JsonResponse updateSpecialStatus(HttpServletRequest request,HttpServletResponse response) {
		return activityService.updateSpecialStatus();
	}
	
	/***
	 * 
	 * @Title: getActivityListBy @Description:
	 * TODO(这里用一句话描述这个方法的作用) @param @return 设定文件 @return
	 * JsonResponse<List<Activity>> 返回类型 @throws
	 */
	@RequestMapping(value = "/activity/getActivityListByPageInfo.do")
	@ResponseBody
	@Endpoint(invokers = { Invoker.内部网关, Invoker.网站前台 }, description = "根据pageConfigId，得到Activity列表")
	public JsonResponse<PageInfo<Activity>> getActivityListByPageInfo(
			@RequestParam(required = false, value = "pageConfigId") @Name(value = "页面配置id") String pageConfigId,
			@RequestParam(required = false, value = "pageNo", defaultValue = "1") @Name(value = "页码") String pageNo,
			@RequestParam(required = false, value = "pageSize", defaultValue = "100000") @Name(value = "每页个数") String pageSize) {
		return activityService.getActivityListByPageInfo(null,pageConfigId, pageNo, pageSize);
	}
	
	@RequestMapping(value = "/activity/getActivityById.do")
	@ResponseBody
	@Endpoint(invokers = { Invoker.内部网关, Invoker.网站前台 }, description = "根据activityId，得到Activity列表")
	public JsonResponse<Activity> getActivityById(
			@RequestParam(required = true, value = "activityId") @Name(value = "activityId") String activityId) {
		return activityService.getActivityListById(null,activityId);
	}
	
	@RequestMapping(value = "/activity/getCmsPageInfo.do")
	@ResponseBody
	@Endpoint(invokers = { Invoker.内部网关, Invoker.网站前台 }, description = "根据pageConfigId，pageId，activityTypeId得到Activity列表")
	public JsonResponse<List<CmsPageConfig>> getCmsPageInfo(
			@RequestParam(required = false, value = "pageConfigId") @Name(value = "pageConfigId") String pageConfigId,
			@RequestParam(required = false, value = "pageId") @Name(value = "pageId") String pageId,
			@RequestParam(required = false, value = "activityTypeId") @Name(value = "activityTypeId") String activityTypeId) {
		return activityService.getCmsPageInfoListById(null,pageConfigId,pageId,activityTypeId);
	}
	
	
	
	@RequestMapping(value = "/activity/getInformationListForApp.do")
	@ResponseBody
	@Endpoint(invokers = { Invoker.内部网关, Invoker.网站前台 }, description = "根据pageConfigId，pageId，activityTypeId得到Activity列表")
	public JsonResponse getInformationListForApp() {
		return activityService.getInformationListForApp(null,null);
	}
	
	@RequestMapping(value = "/activity/getWzSpecialList.do")
	@ResponseBody
	@Endpoint(invokers = { Invoker.内部网关, Invoker.网站前台 }, description = "根据pageConfigId，pageId，activityTypeId得到Activity列表")
	public JsonResponse getWzSpecialList() {
		return activityService.getWzSpecialList(null);
	}
	
	
	

}
