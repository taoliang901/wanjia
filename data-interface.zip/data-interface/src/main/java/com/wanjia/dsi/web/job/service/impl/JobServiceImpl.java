package com.wanjia.dsi.web.job.service.impl;


import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.job.dao.mapper.JobMapper;
import com.wanjia.dsi.web.job.model.ClinicSearch;
import com.wanjia.dsi.web.job.model.JobSearch;
import com.wanjia.dsi.web.job.service.JobService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class JobServiceImpl extends BaseServiceImpl implements JobService {

	private Logger logger = Logger.getLogger(JobServiceImpl.class);

	@Autowired
	private JobMapper jobMapper;

	@Override
	public JsonResponse<PageInfo<JobSearch>> getJobSearchList(String requestId, JobSearch jobSearch) {
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getJobSearchList method start...");
		
		JsonResponse<PageInfo<JobSearch>> result = new JsonResponse<PageInfo<JobSearch>>();
		try {
			int pageNo = 1;
			int PageSize = 10000;
			if(!StringUtils.isBlank(jobSearch.getPageNo())){
				pageNo = Integer.parseInt(jobSearch.getPageNo());
			}
			if(!StringUtils.isBlank(jobSearch.getPageSize())){
				PageSize = Integer.parseInt(jobSearch.getPageSize());
			}
			
			PageHelper.startPage(pageNo, PageSize);
			
			if(!StringUtils.isBlank(jobSearch.getSorts())){
				if(jobSearch.getSorts().equals("refreshDate:desc")){
					jobSearch.setSorts("cj.REFRESH_TIME DESC,cia.PHONE DESC");
				}
				if(jobSearch.getSorts().equals("hotPercent:desc")){
					jobSearch.setSorts("st.RECORD_COUNT DESC,cj.REFRESH_TIME DESC,cia.PHONE DESC");
				}
			}
			if(!StringUtils.isBlank(jobSearch.getAreaIds())){
				jobSearch.setAreaIdStrs(jobSearch.getAreaIds().split(","));
			}
			List<JobSearch> jobList = jobMapper.getJobSearchList(jobSearch);
			PageInfo<JobSearch> pageInfo = new PageInfo<JobSearch>(jobList);
			result.setResult(pageInfo);
		} catch (Exception e) {
			logger.error("requestId:" + requestId + "," + this.getClass().getName()+"========"+e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getJobSearchList method end...");
		return result;
	}

	@Override
	public JsonResponse<PageInfo<ClinicSearch>> getClinicSearchList(String requestId, ClinicSearch clinicSearch) {
        logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getClinicSearchList method start...");
        JsonResponse<PageInfo<ClinicSearch>> result = new JsonResponse<PageInfo<ClinicSearch>>();
		try {
			int pageNo = 1;
			int PageSize = 10000;
			if(!StringUtils.isBlank(clinicSearch.getPageNo())){
				pageNo = Integer.parseInt(clinicSearch.getPageNo());
			}
			if(!StringUtils.isBlank(clinicSearch.getPageSize())){
				PageSize = Integer.parseInt(clinicSearch.getPageSize());
			}
			
			PageHelper.startPage(pageNo, PageSize);
			
			if(!StringUtils.isBlank(clinicSearch.getSorts())){
				if(clinicSearch.getSorts().equals("jobCount:desc")){
					clinicSearch.setSorts("st.CVRECORD_CONUT DESC,cia.PHONE DESC");
				}
				if(clinicSearch.getSorts().equals("hotPercent:desc")){
					clinicSearch.setSorts("st.JOB_HOT_PERCENT DESC,cia.PHONE DESC");
				}
			}
			if(!StringUtils.isBlank(clinicSearch.getAreaId())){
				clinicSearch.setAreaIdStrs(clinicSearch.getAreaId().split(","));
			}
			List<ClinicSearch> jobList = jobMapper.getClinicSearchList(clinicSearch);
			PageInfo<ClinicSearch> pageInfo = new PageInfo<ClinicSearch>(jobList);
			result.setResult(pageInfo);
		} catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getClinicSearchList method end...");
		return result;
	}

	@Override
	public JsonResponse<JobSearch> getJobSearchDetailById(String requestId, String jobId) {
        logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getJobSearchDetailById method start...");
        JsonResponse<JobSearch> result = new JsonResponse<JobSearch>();
        try {
        	JobSearch jobSearch = new JobSearch();
        	jobSearch.setId(jobId);
			List<JobSearch> jobList = jobMapper.getJobSearchList(jobSearch);
			if(jobList != null && jobList.size() > 0){
				result.setResult(jobList.get(0));
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getJobSearchDetailById method end...");
		return result;
	}

	@Override
	public JsonResponse<ClinicSearch> getClinicSearchDetailById(String requestId, String clinicId) {
        logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getClinicSearchDetailById method start...");
        JsonResponse<ClinicSearch> result = new JsonResponse<ClinicSearch>();
        try {
        	ClinicSearch clinicSearch = new ClinicSearch();
        	clinicSearch.setId(clinicId);
			List<ClinicSearch> clinicList = jobMapper.getClinicSearchList(clinicSearch);
			if(clinicList != null && clinicList.size() > 0){
				result.setResult(clinicList.get(0));
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getClinicSearchDetailById method end...");
		return result;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public JsonResponse updateClinicJobStatic() {
		logger.info("requestId:" + "定时任务" + "," + this.getClass().getName() + ":updateClinicJobStatic method start...");
		
		JsonResponse result = new JsonResponse();
		try {
			jobMapper.insertClinicStatic();
			jobMapper.updateClinicCvcount();
			jobMapper.updateClinicJobcount();
			jobMapper.updateClinicHotPercent();
			
			jobMapper.insertJobStatic();
			jobMapper.updateJobRecordCount();
		}catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + "定时任务" + "," + this.getClass().getName() + ":updateClinicJobStatic method end...");
		return null;
	}
	
}
