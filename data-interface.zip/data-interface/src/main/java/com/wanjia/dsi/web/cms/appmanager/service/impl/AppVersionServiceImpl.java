package com.wanjia.dsi.web.cms.appmanager.service.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.cms.appmanager.dao.mapper.AppVersionMapper;
import com.wanjia.dsi.web.cms.appmanager.model.AppVersion;
import com.wanjia.dsi.web.cms.appmanager.model.AppVersionExample;
import com.wanjia.dsi.web.cms.appmanager.service.AppVersionService;
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class AppVersionServiceImpl implements AppVersionService{
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	AppVersionMapper appVersionMapper;
	
	@Override
	public JsonResponse<AppVersion> getAppVersion(AppVersion appVersion) {
		JsonResponse<AppVersion> response = new JsonResponse<AppVersion>();
		String appNameCode = appVersion.getAppNameCode();
		String releasePlatform = appVersion.getReleasePlatform();
		String appChannelCode = appVersion.getAppChannelCode();
		logger.info("AppVersionServiceImpl->getAppVersionList,appNameCode: "
		+ appNameCode + ",releasePlatform: " + releasePlatform + ",appChannelCode:" + appChannelCode);
		if(StringUtils.isBlank(appChannelCode)){
			if("01".equals(releasePlatform)){//android默认官网 
				appChannelCode ="normal";
			}else{// ios默认appstore
				appChannelCode ="appstore";
			}
		}
		try{
		AppVersionExample example = new AppVersionExample();
		AppVersionExample.Criteria cri = example.createCriteria();
		cri.andDelFlagEqualTo("0");
		cri.andIsNewEqualTo("1");
		if(StringUtils.isNotBlank(appNameCode)){
			cri.andAppNameCodeEqualTo(appNameCode);
		}
		if (StringUtils.isNotBlank(releasePlatform)) {
			cri.andReleasePlatformEqualTo(releasePlatform);
		}
		if (StringUtils.isNotBlank(appChannelCode)) {
			cri.andAppChannelCodeEqualTo(appChannelCode);
		}
		List<AppVersion> result = appVersionMapper.selectByExample(example);
		if(result != null && result.size()>0){
			AppVersion version = result.get(0);
			String updateNotes = version.getUpdateNotes();
			if(StringUtils.isNotBlank(updateNotes)){
				version.setUpdateNotes(updateNotes.replaceAll("<br>", "\n"));
			}
			response.setResult(version);
		}
		response.setStatus(Status.SUCCESS);
		}catch(Exception e){
			logger.error("AppVersionServiceImpl->getAppVersion:" + e.toString());
			response.setStatus(Status.ERROR);
			response.setErrorCode(ErrorType.SystemBusy.getCode());
			response.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return response;
	}

}
