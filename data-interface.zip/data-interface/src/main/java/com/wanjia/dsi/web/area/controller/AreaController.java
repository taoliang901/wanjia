/**   
* @Title: AreaController.java 
* @Package com.wanjia.dsi.web.area.controller 
* @Description: TODO(用一句话描述该文件做什么) 
* @author CHENKANG560  
* @date 2016年3月1日 下午6:47:16 
* @version V1.0   
*/
package com.wanjia.dsi.web.area.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.esotericsoftware.minlog.Log;
import com.wanjia.dsi.base.controller.BaseWebController;
import com.wanjia.dsi.common.annotation.Endpoint;
import com.wanjia.dsi.common.annotation.Endpoint.Invoker;
import com.wanjia.dsi.common.annotation.Name;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.area.service.AreaService;

/**
 * @ClassName: AreaController
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author Chenkang
 * @date 2016年3月1日 下午6:47:16
 * 
 */
@Controller
public class AreaController extends BaseWebController {

	

	@Autowired
	private AreaService areaService;

	/***
	 * 
	 * @Title: getCityByIpOnTaobao @Description:
	 * TODO(这里用一句话描述这个方法的作用) @param @param ip @param @return @param @throws
	 * Exception 设定文件 @return JsonResponse<List<Area>> 返回类型 @throws
	 */
	@RequestMapping(value = "/area/getCityByIpOnTaobao.do")
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台 }, description = "根据ip,得到城市信息")
	public JsonResponse<Area> getCityByIpOnTaobao(
			@RequestParam(required = false, value = "ip") @Name(value = "ip") String ip) throws Exception {
		return areaService.getCityByIpOnTaobao(null,ip);

	}

	/**
	 * @throws Exception *
	 * 
	 * @Title: getCityByIpOnTaobao @Description:
	 * TODO(这里用一句话描述这个方法的作用) @param @param ip @param @return @param @throws
	 * Exception 设定文件 @return JsonResponse<List<Area>> 返回类型 @throws
	 */
	@RequestMapping(value = "/area/getCityList.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台, Invoker.会员服务 }, description = "得到城市信息")
	public JsonResponse getCityList(@RequestBody Area area)
			throws Exception {
		
		return areaService.getCityList(null,area);
	}

	/**
	 * @throws Exception
	 * *
	 * 
	 * @Title: getCityByIpOnTaobao @Description:
	 *         TODO(这里用一句话描述这个方法的作用) @param @param
	 *         ip @param @return @param @throws Exception 设定文件 @return
	 *         JsonResponse<List<Area>> 返回类型 @throws
	 */
	@RequestMapping(value = "/area/getCmsCityList.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台 }, description = "服务开通城市维护 ")
	public JsonResponse getCmsCityList(@RequestParam(required = false, value = "pageNo", defaultValue = "1") @Name(value = "页码") String pageNo,
			@RequestParam(required = false, value = "pageSize", defaultValue = "10") @Name(value = "每页个数") String pageSize) throws Exception {
		
		return areaService.getCmsCityList(null,new Area(),pageNo,pageSize);
	}
	
	
	@RequestMapping(value = "/area/queryAreaList.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	@Endpoint(invokers = { Invoker.诊所服务 }, description = "得到省市区信息 ")
	public JsonResponse<List<Area>> queryAreaList() throws Exception {
		
		return areaService.queryAreaList(null);
	}
	
	@RequestMapping(value = "/area/queryAreaList1.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	@Endpoint(invokers = { Invoker.诊所服务 }, description = "得到省市区信息 ")
	public JsonResponse queryAreaList1() throws Exception {
		
		return areaService.getAreaListForGateway();
	}
	
	
	

	

}
