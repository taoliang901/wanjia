package com.wanjia.dsi.web.clinictalent.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.ValidationException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.clinictalent.mapper.ClinicTalentCvMapper;
import com.wanjia.dsi.web.clinictalent.mapper.ClinicTalentJobMapper;
import com.wanjia.dsi.web.clinictalent.model.TalentCvRecordSearchApp;
import com.wanjia.dsi.web.clinictalent.model.TalentCvSearchApp;
import com.wanjia.dsi.web.clinictalent.model.TalentJobSearchApp;
import com.wanjia.dsi.web.clinictalent.service.TalentJobService;
import com.wanjia.dsi.web.job.model.TalentJob;
import com.wanjia.dsi.web.job.model.TalentJobRecord;
import com.wanjia.dsi.web.job.model.TalentJobWithBLOBs;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class TalentJobServiceImpl implements TalentJobService{

	private Logger logger = Logger.getLogger(TalentJobServiceImpl.class);
	
	@Autowired
	private ClinicTalentJobMapper talentJobDao;
	
	@Autowired
	private ClinicTalentCvMapper talentCvDao;
	
	@Value("#{serverConstants['cvPrefix']}")
	private String cvPrefix;
	
	@Override
	public JsonResponse<PageInfo<TalentJobSearchApp>> getTalentJobListByStatus(Map<String, Object> conditions) {
		
		logger.info(this.getClass().getName() + ":getTalentJobListByStatus method start...");
		
		JsonResponse<PageInfo<TalentJobSearchApp>> result = new JsonResponse<PageInfo<TalentJobSearchApp>>();
		try {
			int pageNo = 1;
			int PageSize = 100;
			
			if(!StringUtils.isBlank((String) conditions.get("pageNo"))){
				pageNo = Integer.parseInt((String) conditions.get("pageNo"));
			}
			if(!StringUtils.isBlank((String) conditions.get("pageSize"))){
				PageSize = Integer.parseInt((String) conditions.get("pageSize"));
			}
			
			PageHelper.startPage(pageNo, PageSize);
			
			List<TalentJobSearchApp>  listApp = talentJobDao.getTalentJobList(conditions);
			PageInfo<TalentJobSearchApp> pageInfo = new PageInfo<TalentJobSearchApp>(listApp);
			result.setResult(pageInfo);
			result.setStatus(Status.SUCCESS);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("getTalentJobListByStatus method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info(this.getClass().getName() + ":getTalentJobListByStatus method end...");
		return result;
	}

	public JsonResponse<PageInfo<TalentCvRecordSearchApp>> getTalentCvRecordListByStatus(Map<String, Object> conditions) {
		
		logger.info(this.getClass().getName() + ":getTalentCvRecordListByStatus method start...");
		
		JsonResponse<PageInfo<TalentCvRecordSearchApp>> result = new JsonResponse<PageInfo<TalentCvRecordSearchApp>>();
		try {
			int pageNo = 1;
			int PageSize = 100;
			
			if(!StringUtils.isBlank((String) conditions.get("pageNo"))){
				pageNo = Integer.parseInt((String) conditions.get("pageNo"));
			}
			if(!StringUtils.isBlank((String) conditions.get("pageSize"))){
				PageSize = Integer.parseInt((String) conditions.get("pageSize"));
			}
			
			PageHelper.startPage(pageNo, PageSize);
			
			List<TalentCvRecordSearchApp>  listApp = talentCvDao.getTalentCvRecordListByStatus(conditions);
			PageInfo<TalentCvRecordSearchApp> pageInfo = new PageInfo<TalentCvRecordSearchApp>(listApp);
			result.setResult(pageInfo);
			result.setStatus(Status.SUCCESS);
			
		} catch (Exception e) {
			logger.info("getTalentCvRecordListByStatus method exception:" + e);
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info(this.getClass().getName() + ":getTalentCvRecordListByStatus method end...");
		return result;
	}

	public JsonResponse<TalentJobWithBLOBs> getTalentJobByPk(String pkey) {
		logger.info(this.getClass().getName() + ":getTalentJobByPk method end...");
		
		JsonResponse<TalentJobWithBLOBs> result = new JsonResponse<TalentJobWithBLOBs>();
		try {
			TalentJobWithBLOBs talentJobWithBLOBs = this.talentJobDao.selectByPrimaryKey(pkey);
			result.setResult(talentJobWithBLOBs);
			result.setStatus(Status.SUCCESS);
		
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("getTalentJobByPk method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info(this.getClass().getName() + ":getTalentJobByPk method end...");
		return result;
	}

	public JsonResponse<TalentJobRecord> getTalentJobRecordByPk(String pkey) {
		
		logger.info(this.getClass().getName() + ":getTalentJobRecordByPk method end...");
		
		JsonResponse<TalentJobRecord> result = new JsonResponse<TalentJobRecord>();
		try {
			TalentJobRecord talentJobRecord = this.talentCvDao.selectByPrimaryKey(pkey);
			result.setResult(talentJobRecord);
			result.setStatus(Status.SUCCESS);
		
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("getTalentJobRecordByPk method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info(this.getClass().getName() + ":getTalentJobRecordByPk method end...");
		return result;
	}

	public JsonResponse<String> updateByPrimaryKey(TalentJobRecord talentJobRecord) {
		logger.info(this.getClass().getName() + ":updateByPrimaryKey method start...");
		JsonResponse<String> result = new JsonResponse<String>();
		
		try {
			this.talentCvDao.updateByPrimaryKey(talentJobRecord);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("updateByPrimaryKey method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		logger.info(this.getClass().getName() + ":updateByPrimaryKey method end...");
		return result;
		
	}

	public JsonResponse<String> updateByPrimaryKeySelective(TalentJobRecord talentJobRecord) {
		logger.info(this.getClass().getName() + ":updateByPrimaryKeySelective method start...");
		
		JsonResponse<String> result = new JsonResponse<String>();
		
		try {
			this.talentCvDao.updateByPrimaryKeySelective(talentJobRecord);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("updateByPrimaryKeySelective method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		logger.info(this.getClass().getName() + ":updateByPrimaryKeySelective method end...");
		return result;
		
		
	}

	@Override
	public JsonResponse<String> updateTalentJobByPrimaryKey(TalentJobWithBLOBs talentJob) {
		logger.info(this.getClass().getName() + ":updateTalentJobByPrimaryKey method start...");
		
		JsonResponse<String> result = new JsonResponse<String>();
		
		try {
			this.talentJobDao.updateTalentJobByPrimaryKey(talentJob);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("updateTalentJobByPrimaryKey method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		logger.info(this.getClass().getName() + ":updateTalentJobByPrimaryKey method end...");
		return result;
	}

	@Override
	public JsonResponse<String> updateTalentJobByPrimaryKeySelective(TalentJobWithBLOBs talentJob) {
		logger.info(this.getClass().getName() + ":updateTalentJobByPrimaryKeySelective method start...");
		
		JsonResponse<String> result = new JsonResponse<String>();
		
		try {
			this.talentJobDao.updateTalentJobByPrimaryKeySelective(talentJob);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("updateTalentJobByPrimaryKeySelective method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		logger.info(this.getClass().getName() + ":updateTalentJobByPrimaryKeySelective method end...");
		return result;
	}

	@Override
	public JsonResponse<PageInfo<TalentCvSearchApp>> getTalentCvListByConditions(Map<String, Object> conditions) {
		logger.info(this.getClass().getName() + ":getTalentCvListByConditions method start...");
		
		JsonResponse<PageInfo<TalentCvSearchApp>> result = new JsonResponse<PageInfo<TalentCvSearchApp>>();
		try {
			int pageNo = 1;
			int PageSize = 100;
			
			if(!StringUtils.isBlank((String) conditions.get("pageNo"))){
				pageNo = Integer.parseInt((String) conditions.get("pageNo"));
			}
			if(!StringUtils.isBlank((String) conditions.get("pageSize"))){
				PageSize = Integer.parseInt((String) conditions.get("pageSize"));
			}
			
			PageHelper.startPage(pageNo, PageSize);
			
			List<TalentCvSearchApp>  listApp = talentCvDao.getTalentCvListByConditions(conditions);
			PageInfo<TalentCvSearchApp> pageInfo = new PageInfo<TalentCvSearchApp>(listApp);
			result.setResult(pageInfo);
			result.setStatus(Status.SUCCESS);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("getTalentCvListByConditions method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info(this.getClass().getName() + ":getTalentCvListByConditions method end...");
		return result;
	}

	@Override
	public JsonResponse<Map<String,Object>> getTalentCvInfoById(String id) {
		logger.info(this.getClass().getName() + ":getTalentCvInfoById method start...");
		
		JsonResponse<Map<String,Object>> result = new JsonResponse<Map<String,Object>>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			Map<String,Object> conditions = new HashMap<String,Object>();
			conditions.put("id", id);
			List<TalentCvSearchApp>  cvList = talentCvDao.getTalentCvListByConditions(conditions);
			if(cvList == null || cvList.size() == 0){
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.ResponseNullMessage.getCode());
				result.setErrorMsg(ErrorType.ResponseNullMessage.getDesc());
				return result;
			}
			TalentCvSearchApp cvBo = cvList.get(0);
			
			//将读取到的pdf文件流放入结果map
			getPdfStream(resultMap, cvBo);
			//获取用户手机号
			resultMap.put("memberPhone", cvBo.getMemberPhone());
			
			result.setResult(resultMap);
			return result;
			
			
		}catch (ValidationException ve){
			ve.printStackTrace();
			logger.info("getTalentCvInfoById method exception:" + ve);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ve.getErrorCode());
			result.setErrorMsg(ve.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("getTalentCvInfoById method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		logger.info(this.getClass().getName() + ":getTalentCvInfoById method end...");
		return result;
	}

	private void getPdfStream(Map<String, Object> resultMap, TalentCvSearchApp cvBo)
			throws ValidationException, FileNotFoundException, IOException {
		String pdfPath = cvBo.getPdfPath();
		if(StringUtils.isNotBlank(pdfPath)){
			cvBo.setPdfPath(cvPrefix + pdfPath);
		}else{
			throw new ValidationException(ErrorType.GetDataError.getDesc(), ErrorType.GetDataError.getCode());
		}
		
		logger.info("pdf path ==============>" + cvBo.getPdfPath());
		File file =new File(cvBo.getPdfPath());
//		File file =new File("E:\\201603\\30\\cv_1467256546929.pdf");
		logger.info("pdf path ==============>" + file.getPath());
		byte[] bytes = FileUtils.readFileToByteArray(file);
		resultMap.put("pdfStream", bytes);
	}

	@Override
	public JsonResponse<List<TalentJobWithBLOBs>> getTalentJobListByClinicId(Map<String, String> conditions) {
		JsonResponse<List<TalentJobWithBLOBs>> result = new JsonResponse<List<TalentJobWithBLOBs>>();
		List<TalentJobWithBLOBs> resultList = new ArrayList<TalentJobWithBLOBs>();
		try {
			if(StringUtils.isBlank(conditions.get("clinicId"))){
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg(ErrorType.SystemBusy.getDesc());
				return result;
			}
			
			resultList = talentJobDao.getTalentJobListByClinicId(conditions);
		}catch (Exception e) {
			e.printStackTrace();
			logger.info("getTalentJobListByClinicId method exception:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		if(!resultList.isEmpty()){
			result.setResult(resultList);
		}
		return result;
	}
	
}
