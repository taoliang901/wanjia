package com.wanjia.dsi.web.raffle.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.web.raffle.dao.mapper.RaffleUserIncomMapper;
import com.wanjia.dsi.web.raffle.dao.mapper.RaffleUserIncomVOMapper;
import com.wanjia.dsi.web.raffle.model.RaffleUserIncom;
import com.wanjia.dsi.web.raffle.service.RaffleUserIncomService;

/**
 * This element is automatically generated on 16-7-25 上午11:38, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class RaffleUserIncomServiceImpl implements RaffleUserIncomService {
	
    @Autowired
    private RaffleUserIncomMapper raffleUserIncomMapper;

    @Autowired
    private RaffleUserIncomVOMapper raffleUserIncomVOMapper;
    
    @Override
    @Transactional(readOnly=true)
    public RaffleUserIncom findById(String id) {
        return (RaffleUserIncom)raffleUserIncomMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleUserIncom> findWithPagination(int offset, int count) {
        return (List<RaffleUserIncom>)raffleUserIncomMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleUserIncom> findAll() {
        return (List<RaffleUserIncom>)raffleUserIncomMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleUserIncom> findByEntity(RaffleUserIncom model) {
        return (List<RaffleUserIncom>)raffleUserIncomMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleUserIncom> findByEntityWithPagination(RaffleUserIncom model, int offset, int count) {
        return (List<RaffleUserIncom>)raffleUserIncomMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public RaffleUserIncom findOneByEntity(RaffleUserIncom model) {
        return (RaffleUserIncom)raffleUserIncomMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleUserIncom> findByProperty(String propertyName, String propertyValue) {
        return (List<RaffleUserIncom>)raffleUserIncomMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public RaffleUserIncom findOneByProperty(String propertyName, String propertyValue) {
        return (RaffleUserIncom)raffleUserIncomMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleUserIncom> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<RaffleUserIncom>)raffleUserIncomMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleUserIncom> findByProperties(Map<String, Object> map) {
        return (List<RaffleUserIncom>)raffleUserIncomMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(RaffleUserIncom model) {
        return (long)raffleUserIncomMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)raffleUserIncomMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)raffleUserIncomMapper.countByProperties(map);
    }

    @Override
    public void update(RaffleUserIncom model) {
        model.setModifyDate(new Date());
        raffleUserIncomMapper.update(model);
    }

    @Override
    public void insert(RaffleUserIncom model) {
        model.setCreateDate(new Date());
        raffleUserIncomMapper.insert(model);
    }

    @Override
    public void deleteByEntity(RaffleUserIncom model) {
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        raffleUserIncomMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.raffleUserIncomMapper.countAll();
    }

    public void insertBatch(List<RaffleUserIncom> list) {
        this.raffleUserIncomMapper.insertBatch(list);
    }

    public void delete(String id) {
        RaffleUserIncom model = new RaffleUserIncom();
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.raffleUserIncomMapper.update(model);
    }

	@Override
	public List<RaffleUserIncom> findValidIncomByUserId(Map<String, Object> map) {
		return this.raffleUserIncomVOMapper.findValidIncomByUserId(map);
	}
}