package com.wanjia.dsi.common.interceptors;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.exceptions.ServiceException;

/**
 * AOP切面：对service层抛出的异常进行处理，返回JsonResponse
 */
public class ServiceExceptionAspect {

	// logger
    protected static Logger logger = Logger.getLogger(ServiceExceptionAspect.class);

	@SuppressWarnings("rawtypes")
	public Object roundExecute(ProceedingJoinPoint jp) throws Throwable {

		MethodSignature methodSignature = (MethodSignature) jp.getSignature();
		Method method = methodSignature.getMethod();
		try {

			return jp.proceed();
		} catch(Throwable ex) {
	    	//判断异常是否为service层级异常，如果是则返回JsonResponse
			if(ex instanceof ServiceException) {
				ServiceException serviceEx = (ServiceException) ex;
				logger.error("【warn】["+method.getDeclaringClass().getName()+"."+method.getName()+"]抛出了【service类型】异常：[" + serviceEx.getErrorCode() + "：" + serviceEx.getErrorMsg() + "]", ex);
				JsonResponse res = new JsonResponse();
				res.setStatus(Status.ERROR);
				res.setErrorCode(serviceEx.getErrorCode());
				res.setErrorMsg(serviceEx.getErrorMsg());
				return res;
			} else {
				logger.error("["+method.getDeclaringClass().getName()+"."+method.getName()+"]抛出了其它异常", ex);
				throw ex;
			}
		}
    }
}
