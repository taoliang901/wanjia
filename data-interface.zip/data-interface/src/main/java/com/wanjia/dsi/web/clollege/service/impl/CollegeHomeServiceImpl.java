package com.wanjia.dsi.web.clollege.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.college.dao.mapper.CeCourseReleasedMapper;
import com.wanjia.dsi.web.college.model.CeCourseReleased;
import com.wanjia.dsi.web.college.service.CollegeHomeService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class CollegeHomeServiceImpl extends BaseServiceImpl implements CollegeHomeService {
	@Autowired
	private CeCourseReleasedMapper ceCourseReleasedMapper;

	@Override
	public JsonResponse<List<CeCourseReleased>> findCeCourseByType(Integer typeId, Integer pageSize) {
		JsonResponse<List<CeCourseReleased>> jr = new JsonResponse<List<CeCourseReleased>>();
		try {
			PageHelper.startPage(1, pageSize);
			List<CeCourseReleased> list = ceCourseReleasedMapper.findAllCeCourseReleasedByType(typeId);
			PageInfo<CeCourseReleased> pageinfo = new PageInfo<CeCourseReleased>(list);
			jr.setResult(pageinfo.getList());
			jr.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("findCeCourseByType:" + e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return jr;
	}

	@Override
	public JsonResponse<Map<Integer, List<CeCourseReleased>>> findCecourseByTypeIds(Integer[] typeIds,
			Integer pageSize) {
		JsonResponse<Map<Integer, List<CeCourseReleased>>> jr = new JsonResponse<Map<Integer, List<CeCourseReleased>>>();
		// 保证插入有序
		Map<Integer, List<CeCourseReleased>> map = new LinkedHashMap<Integer, List<CeCourseReleased>>();
		if (null == typeIds || typeIds.length == 0) {
			logger.error("玩家学院首页显示传递的typeId为空");
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		} else {
			try {
				for (Integer typeId : typeIds) {
					PageHelper.startPage(1, pageSize);
					List<CeCourseReleased> list = ceCourseReleasedMapper.findAllCeCourseReleasedByType(typeId);
					PageInfo<CeCourseReleased> pageInfo = new PageInfo<CeCourseReleased>(list);
					map.put(typeId, pageInfo.getList());
				}
				jr.setResult(map);
				jr.setStatus(Status.SUCCESS);
				jr.setResult(map);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("findCecourseByTypeIds" + e);
				jr.setStatus(Status.ERROR);
				jr.setErrorCode(ErrorType.SystemBusy.getCode());
				jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
			}
		}
		return jr;
	}

	@Override
	public JsonResponse<List<CeCourseReleased>> findCeCourseByLabel(String labelId, Integer pageSize) {
		JsonResponse<List<CeCourseReleased>> jresp = new JsonResponse<List<CeCourseReleased>>();
		if (pageSize >= 20) {
			jresp.setErrorMsg("条数超限!");
		}
		List<CeCourseReleased> result = ceCourseReleasedMapper.findCeCourseByLabel(labelId, pageSize);
		jresp.setResult(result);
		return jresp;
	}

}
