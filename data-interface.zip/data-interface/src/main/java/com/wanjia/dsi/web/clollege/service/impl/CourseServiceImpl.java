package com.wanjia.dsi.web.clollege.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esotericsoftware.minlog.Log;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.college.dao.mapper.CourseMapper;
import com.wanjia.dsi.web.college.model.Course;
import com.wanjia.dsi.web.college.service.CourseService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseMapper courseMapper;

	@Override
	public JsonResponse<List<Course>> getCourseList(Course course) {
		JsonResponse<List<Course>> result = new JsonResponse<List<Course>>();
		try {
			if (!CommonTools.notNullAndEmpty(course)) {
				course = new Course();
			}
			course.setDelFlag(0);
			result.setResult(courseMapper.getCourseList(course));

		} catch (Exception e) {
			// TODO: handle exception
			Log.error("getCourseList" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}
}
