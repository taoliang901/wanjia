package com.wanjia.dsi.web.cms.activity.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.StringUtils;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.cms.activity.dao.mapper.CmsActivityMapper;
import com.wanjia.dsi.web.cms.activity.model.CmsActivity;
import com.wanjia.dsi.web.cms.activity.service.CmsActivityService;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * This element is automatically generated on 16-3-2 下午4:37, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class CmsActivityServiceImpl implements CmsActivityService {
	protected final Logger logger = LoggerFactory.getLogger(CmsActivityServiceImpl.class);
	
	@Autowired
	private CmsActivityMapper cmsActivityMapper;

	@Override
	public JsonResponse<List<CmsActivity>> findByPageConfigId(String pageConfigId,String imagetype) {
		JsonResponse<List<CmsActivity>> result = new JsonResponse<List<CmsActivity>>();
		try {
			logger.info("参数pageConfigId："+pageConfigId + ",imagetype: " + imagetype);
			List<CmsActivity> cmsActivityList = cmsActivityMapper.findByPageConfigId(pageConfigId);
			for(CmsActivity cmsActivity:cmsActivityList){//通过分辨率取对应图像
				String activityImageLocation = cmsActivity.getActivityImageLocation();
				JSONArray array = new JSONArray();
				if(!StringUtils.isEmpty(activityImageLocation) && activityImageLocation.startsWith("[")){
					array = JSONArray.fromObject(activityImageLocation);
					boolean isExist = false;				
					for(int i = 0; i < array.size(); i++){
						JSONObject obj = array.getJSONObject(i);
						if(CommonTools.notNullAndEmpty(imagetype)){
						if(imagetype.equals(obj.get("type").toString())){
							isExist = true;
							cmsActivity.setActivityImageLocation(obj.get("url").toString());
							break;
						}
						}
					}
					if(!isExist || CommonTools.nullOrEmpty(imagetype)){//不存在或者分辨率为空时取default
						for(int i = 0; i < array.size(); i++){
							JSONObject obj = array.getJSONObject(i);
							if("default".equals(obj.get("type").toString())){
								cmsActivity.setActivityImageLocation(obj.get("url").toString());
								break;
							}
						}
					}
				}	
			}
			result.setResult(cmsActivityList);
			result.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("CmsActivityServiceImpl->findByPageConfigId->error:" + e.toString());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("CmsActivityServiceImpl->findByPageConfigId->" +result.getStatus());
		return result;
	}

}