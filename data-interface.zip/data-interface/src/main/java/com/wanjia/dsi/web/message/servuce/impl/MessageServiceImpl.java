package com.wanjia.dsi.web.message.servuce.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.pinganwj.clinic.api.ClinicApiService;
import com.pinganwj.clinic.api.domain.clinic.EmployeeInnerInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.mongodb.Pagination;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.message.MessageConsts;
import com.wanjia.dsi.web.message.model.MessageBO;
import com.wanjia.dsi.web.message.model.VOMessage;
import com.wanjia.dsi.web.message.repository.MessageRepository;
import com.wanjia.dsi.web.message.service.MessageService;
import com.wanjia.message.service.MessageBusinessService;
import com.wanjia.message.service.MessageProducerService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class MessageServiceImpl implements MessageService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private MessageRepository messageRepository;

	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private MessageBusinessService messageBusinessService;
	
	@Autowired
	private MessageProducerService messageProducerService;
	
	@Autowired
	private ClinicApiService clinicApiService;

	
	
	@Value("#{serverConstants['memberRoot']}")
	private String memberRoot;
	
	@Value("#{serverConstants['ylptHost']}")
	private String ylptHost;

	@Override
	public JsonResponse<Void> updateMessageStatus(MessageBO message) {

		JsonResponse<Void> result = new JsonResponse<Void>();
		try {
			if (message != null) {
				Query query = new Query();
				Update update = new Update();
				String id = message.getId();
				if (StringUtils.isNotBlank(id)) {
					query.addCriteria(Criteria.where("_id").in(new ArrayList<String>(Arrays.asList(id.split(",")))));
				}

				update.set("isRead", "1");
				messageRepository.updateMany(query, update, MessageBO.class);
				result.setStatus(Status.SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}

	@Override
	public JsonResponse<Pagination<MessageBO>> findMessage(MessageBO messageBo, int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		JsonResponse<Pagination<MessageBO>> result = new JsonResponse<Pagination<MessageBO>>();
		try {
			if (messageBo != null) {
				Query query = new Query();

				String acceptRoleId = messageBo.getAcceptRoleId();

				String messageTypeId = messageBo.getMessageTypeId();
				String isShow = messageBo.getIsShow();
				if (StringUtils.isNotBlank(acceptRoleId)) {
					// acceptRoleId.split(",");
					query.addCriteria(Criteria.where("acceptRoleId").in(acceptRoleId.split(",")));
				}
				if (StringUtils.isNotBlank(isShow)) {
					query.addCriteria(Criteria.where("isShow").is(isShow));
				}

				if (StringUtils.isNotBlank(messageTypeId)) {
					query.addCriteria(Criteria.where("messageTypeId").is(messageTypeId));
				}
				// receiverId
				String receiverId = messageBo.getReceiverId();
				if (StringUtils.isNotBlank(receiverId)) {
					query.addCriteria(Criteria.where("receiverId").is(receiverId));
				}
				// status
				String status = messageBo.getStatus();
				if (StringUtils.isNotBlank(status)) {
					query.addCriteria(Criteria.where("status").is(status));
				}

				// isRead
				String isRead = messageBo.getIsRead();
				if (StringUtils.isNotBlank(isRead)) {
					query.addCriteria(Criteria.where("isRead").is(isRead));
				}
				String delFlag = messageBo.getDelFlag();
				if (StringUtils.isNotBlank(delFlag)) {
					query.addCriteria(Criteria.where("delFlag").is(delFlag));
				}
				String channel = messageBo.getChannel();
				if (StringUtils.isNotBlank(channel)) {
					query.addCriteria(Criteria.where("channel").is(channel));
				}
				String clinicId = messageBo.getClinicId();
				if (StringUtils.isNotBlank(clinicId)) {
					//query.addCriteria(Criteria.where("clinicId").is(clinicId));
					Criteria criteriaClinicId = new Criteria();  
					criteriaClinicId.orOperator(Criteria.where("clinicId").is(clinicId),Criteria.where("clinicId").is(null),Criteria.where("clinicId").is(""));   
					query.addCriteria(criteriaClinicId);
				}
				Date publishBeginDate = messageBo.getPublishBeginDate();
				Date publishEndDate = messageBo.getPublishEndDate();

				if (publishBeginDate == null) {
					publishBeginDate = CommonTools.stringToDate("2000-01-01 00:00:00");
				}
				if (publishEndDate == null) {
					publishEndDate = CommonTools.stringToDate("2099-12-31 23:59:59");
				}
				query.addCriteria(Criteria.where("publishDate").gte(publishBeginDate).lte(publishEndDate));

				result.setResult(messageRepository.getPage(pageNo == 0 ? 1 : pageNo, pageSize == 0 ? 10 : pageSize,
						query, new Sort(Direction.DESC, "publishDate"), MessageBO.class));
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<List<MessageBO>> findMessageNoPage(MessageBO messageBo, int beginNo, int endNo) {
		// TODO Auto-generated method stub
		JsonResponse<List<MessageBO>> result = new JsonResponse<List<MessageBO>>();
		try {
			if (messageBo != null) {
				Query query = new Query();

				String acceptRoleId = messageBo.getAcceptRoleId();

				String messageTypeId = messageBo.getMessageTypeId();
				String isShow = messageBo.getIsShow();
				if (StringUtils.isNotBlank(acceptRoleId)) {
					// acceptRoleId.split(",");
					query.addCriteria(Criteria.where("acceptRoleId").in(acceptRoleId.split(",")));
				}
				if (StringUtils.isNotBlank(isShow)) {
					query.addCriteria(Criteria.where("isShow").is(isShow));
				}

				if (StringUtils.isNotBlank(messageTypeId)) {
					query.addCriteria(Criteria.where("messageTypeId").is(messageTypeId));
				}
				// receiverId
				String receiverId = messageBo.getReceiverId();
				if (StringUtils.isNotBlank(receiverId)) {
					query.addCriteria(Criteria.where("receiverId").is(receiverId));
				}
				// status
				String status = messageBo.getStatus();
				if (StringUtils.isNotBlank(status)) {
					query.addCriteria(Criteria.where("status").is(status));
				}

				// isRead
				String isRead = messageBo.getIsRead();
				if (StringUtils.isNotBlank(isRead)) {
					query.addCriteria(Criteria.where("isRead").is(isRead));
				}
				String delFlag = messageBo.getDelFlag();
				if (StringUtils.isNotBlank(delFlag)) {
					query.addCriteria(Criteria.where("delFlag").is(delFlag));
				}
				String channel = messageBo.getChannel();
				if (StringUtils.isNotBlank(channel)) {
					query.addCriteria(Criteria.where("channel").is(channel));
				}
				String clinicId = messageBo.getClinicId();
				if (StringUtils.isNotBlank(clinicId)) {
					//query.addCriteria(Criteria.where("clinicId").is(clinicId));
					Criteria criteriaClinicId = new Criteria();  
					criteriaClinicId.orOperator(Criteria.where("clinicId").is(clinicId),Criteria.where("clinicId").is(null),Criteria.where("clinicId").is(""));  
					query.addCriteria(criteriaClinicId);
				}
				Date publishBeginDate = messageBo.getPublishBeginDate();
				Date publishEndDate = messageBo.getPublishEndDate();

				if (publishBeginDate == null) {
					publishBeginDate = CommonTools.stringToDate("2000-01-01 00:00:00");
				}
				if (publishEndDate == null) {
					publishEndDate = CommonTools.stringToDate("2099-12-31 23:59:59");
				}
				query.addCriteria(Criteria.where("publishDate").gte(publishBeginDate).lte(publishEndDate));
				Sort sort = new Sort(Direction.DESC, "publishDate");
				query.with(sort);
				query.limit(endNo - beginNo);
				query.skip(beginNo);
				/*
				 * result.setResult(messageRepository.getPage(pageNo == 0 ? 1 :
				 * pageNo, pageSize == 0 ? 10 : pageSize, query, new
				 * Sort(Direction.DESC, "publishDate"), MessageBO.class));
				 */
				result.setResult(messageRepository.find(query, MessageBO.class));

			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<Pagination<MessageBO>> findMessageWithoutType(MessageBO messageBo, int pageNo, int pageSize) {
		JsonResponse<Pagination<MessageBO>> result = new JsonResponse<Pagination<MessageBO>>();
		try {
			if (messageBo != null) {
				Query query = new Query();

				String acceptRoleId = messageBo.getAcceptRoleId();

				String messageTypeId = messageBo.getMessageTypeId();
				String isShow = messageBo.getIsShow();
				if (StringUtils.isNotBlank(acceptRoleId)) {
					query.addCriteria(Criteria.where("acceptRoleId").is(acceptRoleId));
				}
				if (StringUtils.isNotBlank(isShow)) {
					query.addCriteria(Criteria.where("isShow").is(isShow));
				}
				// 把非系统类型的查询出来
				if (StringUtils.isNotBlank(messageTypeId)) {
					query.addCriteria(Criteria.where("messageTypeId").ne(messageTypeId));
				}
				// receiverId
				String receiverId = messageBo.getReceiverId();
				if (StringUtils.isNotBlank(receiverId)) {
					query.addCriteria(Criteria.where("receiverId").is(receiverId));
				}

				// status
				String status = messageBo.getStatus();
				if (StringUtils.isNotBlank(status)) {
					query.addCriteria(Criteria.where("status").is(status));
				}

				// isRead
				String isRead = messageBo.getIsRead();
				if (StringUtils.isNotBlank(isRead)) {
					query.addCriteria(Criteria.where("isRead").is(isRead));
				}
				String clinicId = messageBo.getClinicId();
				if (StringUtils.isNotBlank(clinicId)) {
					//query.addCriteria(Criteria.where("clinicId").is(clinicId));
					Criteria criteriaClinicId = new Criteria();  
					criteriaClinicId.orOperator(Criteria.where("clinicId").is(clinicId),Criteria.where("clinicId").is(null),Criteria.where("clinicId").is(""));  
					query.addCriteria(criteriaClinicId);
				}
				Date publishBeginDate = messageBo.getPublishBeginDate();
				Date publishEndDate = messageBo.getPublishEndDate();

				if (publishBeginDate == null) {
					publishBeginDate = CommonTools.stringToDate("2000-01-01 00:00:00");
				}
				if (publishEndDate == null) {
					publishEndDate = CommonTools.stringToDate("2099-12-31 23:59:59");
				}
				query.addCriteria(Criteria.where("publishDate").gte(publishBeginDate).lte(publishEndDate));

				result.setResult(messageRepository.getPage(pageNo == 0 ? 1 : pageNo, pageSize == 0 ? 10 : pageSize,
						query, new Sort(Direction.DESC, "publishDate"), MessageBO.class));
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	// 诊所收到消息：客户**已预约就诊：*年*月*日**时间**科/服务，请2小时内确认接诊，若无法承接服务，请与客户协商处理，查看>
	@Override
	public JsonResponse<Void> patientBooking(String bookingId, String uid, String patientName, String bookingTime,
			String clinicId, String serviceName) {
		logger.info("创建patientBooking消息开始", clinicId);
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			/*MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			String[] times = splitTime(bookingTime);

			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_BOOKING,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], serviceName },
					null));
			logger.info("创建patientBooking消息插入开始", clinicId);
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			messageBO.setId(uid + "_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_BOOKING_APP,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], serviceName },
					null));
			messageBO.setJumpType("JUMP_02");
			messageBO.setJumpParam("{\"moduleId\":\"09\"}");
			messageRepository.insert(messageBO, MessageBO.class);
			logger.info("创建patientBooking消息插入结束", clinicId);*/
			
			//获取内部员工casUuids
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_YYGL);
			jsonResponse = this.messageBusinessService.patientBooking(bookingId, uid, patientName, bookingTime, clinicId, serviceName, memberIds);
			
		} catch (Exception e) {
			logger.error("创建patientBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}

		return jsonResponse;
	}

	// 诊所收到消息：客户**已预约就诊：*年*月*日**时间**科/服务，请2小时内确认接诊，若无法承接服务，请与客户协商处理，查看>
	@Override
	public JsonResponse<Void> patientBookingNormal(String bookingId, String uid, String patientName, String bookingTime,
			String clinicId, String serviceName) {
		logger.info("创建patientBooking消息开始", clinicId);
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			/*MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			// String[] times = splitTime(bookingTime);

			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_BOOKING_NORMAL,
					new String[] { patientName, bookingTime, serviceName }, null));
			logger.info("创建patientBooking消息插入开始", clinicId);
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			messageBO.setId(uid + "_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_BOOKING_NORMAL_APP,
					new String[] { patientName, bookingTime, serviceName }, null));
			messageBO.setJumpType("JUMP_02");
			messageBO.setJumpParam("{\"moduleId\":\"09\"}");
			messageRepository.insert(messageBO, MessageBO.class);
			logger.info("创建patientBooking消息插入结束", clinicId);*/
			
			
			//获取内部员工casUuids
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_YYGL);
			jsonResponse = this.messageBusinessService.patientBookingNormal(bookingId, uid, patientName, bookingTime, clinicId, serviceName, memberIds);
		} catch (Exception e) {
			logger.error("创建patientBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}

		return jsonResponse;
	}

	// 客户收到消息：您好！恭喜您预约成功：*年*月*日**时间**诊所**科/服务，请准时前往，查看>
	// 诊所收到消息：客户**已成功预约就诊：*年*月*日**时间**科/服务，请安排人员准时接待，查看>
	@Override
	public JsonResponse<Void> clinicConfirmBooking(String bookingId, String uid, String patientName, String bookingTime,
			String clinicId, String clinicName, String serviceName, String memberId) {
		return clinicConfirmBooking(bookingId, uid, patientName, bookingTime, clinicId, clinicName, serviceName,
				memberId, null, null);
	}

	// 客户收到消息：您好！恭喜您预约成功：*年*月*日**时间**诊所**科/服务，请准时前往，查看>
	// 诊所收到消息：客户**已成功预约就诊：*年*月*日**时间**科/服务，请安排人员准时接待，查看>
	@Override
	public JsonResponse<Void> clinicConfirmBookingNormal(String bookingId, String uid, String patientName,
			String bookingTime, String clinicId, String clinicName, String serviceName, String memberId) {
		return clinicConfirmBookingNormal(bookingId, uid, patientName, bookingTime, clinicId, clinicName, serviceName,
				memberId, null, null);
	}

	// 客户收到消息：您好！恭喜您预约成功：*年*月*日**时间**诊所**科/服务，，诊所地址：xxxx，就诊码：xxxx，请准时前往，如有疑问请随时联系客服4001028120，查看>
	// 诊所收到消息：客户**已成功预约就诊：*年*月*日**时间**科/服务，请安排人员准时接待，查看>
	@Override
	public JsonResponse<Void> clinicConfirmBooking(String bookingId, String uid, String patientName, String bookingTime,
			String clinicId, String clinicName, String serviceName, String memberId, String clinicAddress,
			String consultationCode) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			/*MessageBO messageBO = new MessageBO();

			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);

			String[] times = splitTime(bookingTime);
			// 接受者角色为诊所
			messageBO.setId(uid + "-0");
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], clinicName,
							serviceName },
					null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			messageBO.setId(uid + "-0_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO
					.setContent(messageSource.getMessage(
							MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_APP, new String[] { patientName,
									times[0], times[1], times[2], times[3] + ":" + times[4], clinicName, serviceName },
							null));
			messageBO.setJumpType("JUMP_02");
			messageBO.setJumpParam("{\"moduleId\":\"09\"}");
			messageRepository.insert(messageBO, MessageBO.class);

			// 接受者角色为客户
			messageBO.setId(uid + "-1");
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING, null, null));
			messageBO
					.setContent(
							messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT,
									new String[] { times[0], times[1], times[2], times[3] + ":" + times[4], clinicName,
											serviceName, bookingId, clinicAddress, consultationCode, memberRoot },
									null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			// messageBO.setId(uid + "-1_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO.setReceiverId(memberId);
			// messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING,
			// null, null));
			// messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_APP,
			// new String[] { times[0], times[1], times[2], times[3] + ":" +
			// times[4], clinicName, serviceName,
			// bookingId, clinicAddress, consultationCode },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
			logger.info("创建clinicConfirmBooking消息成功" + uid);*/
			
			//获取内部员工casUuids
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_YYGL);
			jsonResponse = this.messageBusinessService.clinicConfirmBooking(bookingId, uid, patientName, bookingTime, clinicId, clinicName, serviceName, memberId, clinicAddress, consultationCode, memberIds);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 客户收到消息：您好！恭喜您预约成功：*年*月*日**时间**诊所**科/服务，，诊所地址：xxxx，就诊码：xxxx，请准时前往，如有疑问请随时联系客服4001028120，查看>
	// 诊所收到消息：客户**已成功预约就诊：*年*月*日**时间**科/服务，请安排人员准时接待，查看>
	@Override
	public JsonResponse<Void> clinicConfirmBookingNormal(String bookingId, String uid, String patientName,
			String bookingTime, String clinicId, String clinicName, String serviceName, String memberId,
			String clinicAddress, String consultationCode) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			/*MessageBO messageBO = new MessageBO();

			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);

			// String[] times = splitTime(bookingTime);
			// 接受者角色为诊所
			messageBO.setId(uid + "-0");
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_NORMAL,
					new String[] { patientName, bookingTime, clinicName, serviceName }, null));
			messageBO.setJumpType("JUMP_02");
			messageBO.setJumpParam("{\"moduleId\":\"09\"}");
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			// messageBO.setId(uid + "-0_BD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			// messageBO
			// .setContent(messageSource.getMessage(
			// MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_APP, new
			// String[] { patientName,
			// times[0], times[1], times[2], times[3] + ":" + times[4],
			// clinicName, serviceName },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);

			// 接受者角色为客户
			messageBO.setId(uid + "-1");
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING, null, null));
			messageBO
					.setContent(messageSource.getMessage(
							MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_NORMAL, new String[] { bookingTime,
									clinicName, serviceName, bookingId, clinicAddress, consultationCode, memberRoot },
							null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			// messageBO.setId(uid + "-1_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO.setReceiverId(memberId);
			// messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING,
			// null, null));
			// messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_APP,
			// new String[] { times[0], times[1], times[2], times[3] + ":" +
			// times[4], clinicName, serviceName,
			// bookingId, clinicAddress, consultationCode },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
			logger.info("创建clinicConfirmBooking消息成功" + uid);*/
			
			
			//获取内部员工casUuids
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_YYGL);
			jsonResponse = this.messageBusinessService.clinicConfirmBookingNormal(bookingId, uid, patientName, bookingTime, clinicId, clinicName, serviceName, memberId, clinicAddress, consultationCode, memberIds);

		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 诊所收到消息：客户**已取消预约就诊：*年*月*日**时间**科/服务，查看>
	@Override
	public JsonResponse<Void> patientCancelBooking(String bookingId, String uid, String patientName, String bookingTime,
			String clinicId, String serviceName) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			/*MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_PATIENT_CANCEL_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_CANCEL_BOOKING,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], serviceName },
					null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			messageBO.setId(uid + "_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_CANCEL_BOOKING_APP,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], serviceName },
					null));
			messageBO.setJumpType("JUMP_02");
			messageBO.setJumpParam("{\"moduleId\":\"09\"}");
			messageRepository.insert(messageBO, MessageBO.class);*/
			
			logger.info("------------------------- patientCancelBooking start -------------------------");
			//获取内部员工casUuids
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_YYGL);
			
			jsonResponse = this.messageBusinessService.patientCancelBooking(bookingId, uid, patientName, bookingTime, clinicId, serviceName,memberIds);
			
			logger.info("------------------------- patientCancelBooking end -------------------------");
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 诊所收到消息：客户**已取消预约就诊：*年*月*日**时间**科/服务，查看>
	@Override
	public JsonResponse<Void> patientCancelBookingNormal(String bookingId, String uid, String patientName,
			String bookingTime, String clinicId, String serviceName) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
/*			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			// String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_PATIENT_CANCEL_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_CANCEL_BOOKING_NORMAL,
					new String[] { patientName, bookingTime, serviceName }, null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			messageBO.setId(uid + "_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_CANCEL_BOOKING_NORMAL_APP,
					new String[] { patientName, bookingTime, serviceName }, null));
			// messageBO.setJumpType("JUMP_02");
			// messageBO.setJumpParam("{\"moduleId\":\"09\"}");
			messageRepository.insert(messageBO, MessageBO.class);*/
			
			logger.info("------------------------- patientCancelBookingNormal start -------------------------");
			logger.info("bookingId =" + bookingId + "  uid =" + uid + " patientName =" + patientName + " bookingTime =" + bookingTime + " clinicId =" + clinicId+ " serviceName=" + serviceName );
			//获取内部员工casUuids
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_YYGL);
			jsonResponse = messageBusinessService.patientCancelBookingNormal(bookingId, uid, patientName, bookingTime, clinicId, serviceName,memberIds);
			logger.info("------------------------- patientCancelBookingNormal end -------------------------");
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 客户收到消息：您好！您所提交的就诊预约申请：*年*月*日**时间**诊所/服务，因**原因诊所已取消，如有疑问请随时联系客服4001028120，查看>
	@Override
	public JsonResponse<Void> clinicCancelBooking(String bookingId, String uid, String clinicName, String bookingTime,
			String serviceName, String reason, String memberId) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CANCEL_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CANCEL_BOOKING,
					new String[] { times[0], times[1], times[2], times[3] + ":" + times[4], serviceName, reason,
							bookingId, memberRoot },
					null));
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			// messageBO.setId(uid + "_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO
			// .setContent(
			// messageSource.getMessage(
			// MessageConsts.CONTENT_CLINIC_CANCEL_BOOKING_APP, new String[] {
			// times[0], times[1],
			// times[2], times[3] + ":" + times[4], serviceName, reason,
			// bookingId },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 客户收到消息：您好！您所提交的就诊预约申请：*年*月*日**时间**诊所/服务，因**原因诊所已取消，如有疑问请随时联系客服4001028120，查看>
	@Override
	public JsonResponse<Void> clinicCancelBookingNormal(String bookingId, String uid, String clinicName,
			String bookingTime, String serviceName, String reason, String memberId) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			// String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CANCEL_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CANCEL_BOOKING_NORMAL,
					new String[] { bookingTime, serviceName, reason, bookingId, memberRoot }, null));
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			// messageBO.setId(uid + "_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO
			// .setContent(
			// messageSource.getMessage(
			// MessageConsts.CONTENT_CLINIC_CANCEL_BOOKING_APP, new String[] {
			// times[0], times[1],
			// times[2], times[3] + ":" + times[4], serviceName, reason,
			// bookingId },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 诊所收到消息：客户**已确认此次就诊：*年*月*日**时间**科/服务，请尽快确认，查看>
	@Override
	public JsonResponse<Void> patientConfirmConsultation(String bookingId, String uid, String patientName,
			String bookingTime, String clinicId, String serviceName) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_PATIENT_CONFIRM_CONSULTATION, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_CONFIRM_CONSULTATION,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], serviceName },
					null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			messageBO.setId(uid + "_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_CONFIRM_CONSULTATION_APP,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], serviceName },
					null));
			messageBO.setJumpType("JUMP_02");
			messageBO.setJumpParam("{\"moduleId\":\"09\"}");
			messageRepository.insert(messageBO, MessageBO.class);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 诊所收到消息：客户**已确认此次就诊：*年*月*日**时间**科/服务，请尽快确认，查看>
	@Override
	public JsonResponse<Void> patientConfirmConsultationNormal(String bookingId, String uid, String patientName,
			String bookingTime, String clinicId, String serviceName) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			// String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_PATIENT_CONFIRM_CONSULTATION, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_CONFIRM_CONSULTATION_NORMAL,
					new String[] { patientName, bookingTime, serviceName }, null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			messageBO.setId(uid + "_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_CONFIRM_CONSULTATION_NORMAL_APP,
					new String[] { patientName, bookingTime, serviceName }, null));
			// messageBO.setJumpType("JUMP_02");
			// messageBO.setJumpParam("{\"moduleId\":\"09\"}");
			messageRepository.insert(messageBO, MessageBO.class);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 客户收到消息：您好！您此次的就诊记录：*年*月*日**时间**诊所**科/服务，诊所已确认，请您确认此次就诊/服务已完成，如超过1天仍未确认系统将默认自动确认，查看>
	@Override
	public JsonResponse<Void> clinicConfirmConsultation(String bookingId, String uid, String clinicName,
			String bookingTime, String serviceName, String memberId) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_CONSULTATION, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_CONSULTATION,
					new String[] { times[0], times[1], times[2], times[3] + ":" + times[4], clinicName, serviceName,
							bookingId, memberRoot },
					null));
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			// messageBO.setId(uid + "_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_CONSULTATION_APP,
			// new String[] { times[0], times[1], times[2], times[3] + ":" +
			// times[4], clinicName, serviceName,
			// bookingId },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 客户收到消息：您好！您此次的就诊记录：*年*月*日**时间**诊所**科/服务，诊所已确认，请您确认此次就诊/服务已完成，如超过1天仍未确认系统将默认自动确认，查看>
	@Override
	public JsonResponse<Void> clinicConfirmConsultationNormal(String bookingId, String uid, String clinicName,
			String bookingTime, String serviceName, String memberId) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			// String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_CONSULTATION, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_CONSULTATION_NORMAL,
					new String[] { bookingTime, clinicName, serviceName, bookingId, memberRoot }, null));
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			// messageBO.setId(uid + "_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_CONSULTATION_APP,
			// new String[] { times[0], times[1], times[2], times[3] + ":" +
			// times[4], clinicName, serviceName,
			// bookingId },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 诊所收到消息：客户**已对此次诊疗服务：*年*月*日**时间**科/服务作出评价，查看>
	@Override
	public JsonResponse<Void> patientRated(String bookingId, String uid, String patientName, String bookingTime,
			String clinicId, String serviceName) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			/*MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_PATIENT_RATED, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_RATED,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], serviceName },
					null));
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			messageBO.setId(uid + "_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO.setJumpType("JUMP_02");
			messageBO.setJumpParam("{\"moduleId\":\"08\"}");
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_RATED_APP,
					new String[] { patientName, times[0], times[1], times[2], times[3] + ":" + times[4], serviceName },
					null));
			messageRepository.insert(messageBO, MessageBO.class);*/
			
			//获取内部员工casUuids
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_MYDGL);
			
			jsonResponse = this.messageBusinessService.patientRated(bookingId, uid, patientName, bookingTime, clinicId, serviceName,memberIds);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 诊所收到消息：客户**已对此次诊疗服务：*年*月*日**时间**科/服务作出评价，查看>
	@Override
	public JsonResponse<Void> patientRatedNormal(String bookingId, String uid, String patientName, String bookingTime,
			String clinicId, String serviceName) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			/*MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			// String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_PATIENT_RATED, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_RATED_NORMAL,
					new String[] { patientName, bookingTime, serviceName }, null));
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			messageBO.setId(uid + "_BD");
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			messageBO.setJumpType("JUMP_02");
			messageBO.setJumpParam("{\"moduleId\":\"08\"}");
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_PATIENT_RATED_NORMAL_APP,
					new String[] { patientName, bookingTime, serviceName }, null));
			messageRepository.insert(messageBO, MessageBO.class);*/
			
			//获取内部员工casUuids
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_MYDGL);
			jsonResponse = this.messageBusinessService.patientRatedNormal(bookingId, uid, patientName, bookingTime, clinicId, serviceName,memberIds);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 客户收到消息：您好！您针对*年*月*日**时间**诊所**科/服务所提交的就诊评价，诊所已回复，查看>
	@Override
	public JsonResponse<Void> clinicReplyRated(String bookingId, String uid, String clinicName, String bookingTime,
			String serviceName, String memberId) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_REPLY_RATED, null, null));
			messageBO
					.setContent(
							messageSource.getMessage(
									MessageConsts.CONTENT_CLINIC_REPLY_RATED, new String[] { times[0], times[1],
											times[2], times[3] + ":" + times[4], clinicName, serviceName, bookingId },
									null));
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			// messageBO.setId(uid + "_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_REPLY_RATED_APP,
			// new String[] { times[0], times[1], times[2], times[3] + ":" +
			// times[4], clinicName, serviceName,
			// bookingId, memberRoot },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	// 客户收到消息：您好！您针对*年*月*日**时间**诊所**科/服务所提交的就诊评价，诊所已回复，查看>
	@Override
	public JsonResponse<Void> clinicReplyRatedNormal(String bookingId, String uid, String clinicName,
			String bookingTime, String serviceName, String memberId) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);

			// String[] times = splitTime(bookingTime);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_REPLY_RATED, null, null));
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_REPLY_RATED_NORMAL,
					new String[] { bookingTime, clinicName, serviceName, bookingId }, null));
			messageRepository.insert(messageBO, MessageBO.class);

			// app消息
			// messageBO.setId(uid + "_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_REPLY_RATED_APP,
			// new String[] { times[0], times[1], times[2], times[3] + ":" +
			// times[4], clinicName, serviceName,
			// bookingId, memberRoot },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBooking消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	private static String[] splitTime(String bookingTime) {
		String[] dateTime = StringUtils.split(bookingTime, " ");
		String[] date = StringUtils.split(dateTime[0], "-");
		String[] time = StringUtils.split(dateTime[1], ":");
		return (String[]) ArrayUtils.addAll(date, time);
	}

	public static void main(String[] args) {
		String times = "2016-08-01 15:00";
		String[] strs = MessageServiceImpl.splitTime(times);
		System.out.println(strs[0] + "|" + strs[1] + "|" + strs[2] + "|" + strs[3] + "|" + strs[4]);
	}

	@Override
	public JsonResponse<String> testFindMessage() {
		JsonResponse<String> resp = new JsonResponse<String>();
		resp.setResult("wxwxwxe");
		return resp;
	}

	@Override
	public JsonResponse<Void> clinicUpgradeAccount(String receiverId, String uid) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());

			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);

			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);

			messageBO.setTemplateId(MessageConsts.UPGRADE_ACCOUNT_TEMPLATE_ID);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(receiverId);
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setTopic(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_UPGRADE_ACCOUNT, null, null));
			messageRepository.insert(messageBO, MessageBO.class);

			jsonResponse.setStatus(JsonResponse.Status.SUCCESS);
			logger.info("创建诊所申请升级总账户的站内消息成功------" + uid);
		} catch (Exception e) {
			logger.error("创建诊所申请升级总账户的站内消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	@Override
	public JsonResponse<Void> clinicAssociatedAccount(String receiverId, String uid, String clinicName) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setId(uid);
			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());

			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);

			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);

			messageBO.setTemplateId(MessageConsts.ASSOC_ACCOUNT_TEMPLATE_ID);
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(receiverId);
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setTopic(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setContent(messageSource.getMessage(MessageConsts.CONTENT_CLINIC_ASSOCIATED_ACCOUNT,
					new String[] { clinicName }, null));
			messageRepository.insert(messageBO, MessageBO.class);

			jsonResponse.setStatus(JsonResponse.Status.SUCCESS);
			logger.info("创建诊所申请关联总账户的站内消息成功------" + uid);
		} catch (Exception e) {
			logger.error("创建诊所申请关联总账户的站内消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	/**
	 * 查询最新消息记录
	 * 
	 * @param messageBo
	 * @return
	 */
	public MessageBO findRecentMessage(MessageBO messageBo) {
		MessageBO result = new MessageBO();
		try {
			if (messageBo != null) {
				Query query = new Query();
				String acceptRoleId = messageBo.getAcceptRoleId(); //
				String messageTypeId = messageBo.getMessageTypeId();
				String isShow = messageBo.getIsShow();
				String channel = messageBo.getChannel();
				if (StringUtils.isNotBlank(acceptRoleId)) {
					// query.addCriteria(Criteria.where("acceptRoleId").is(acceptRoleId));
					query.addCriteria(Criteria.where("acceptRoleId").in(acceptRoleId.split(",")));
				}
				if (StringUtils.isNotBlank(isShow)) {
					query.addCriteria(Criteria.where("isShow").is(isShow));
				}
				if (StringUtils.isNotBlank(messageTypeId)) {
					query.addCriteria(Criteria.where("messageTypeId").is(messageTypeId));
				}
				// 把非系统类型的查询出来
				/*
				 * if (StringUtils.isNotBlank(messageTypeId)) {
				 * query.addCriteria(Criteria.where("messageTypeId").ne(
				 * messageTypeId)); }
				 */
				// receiverId
				String receiverId = messageBo.getReceiverId();
				if (StringUtils.isNotBlank(receiverId)) {
					query.addCriteria(Criteria.where("receiverId").is(receiverId)); // casUUID
				}
				// status
				String status = messageBo.getStatus();
				if (StringUtils.isNotBlank(status)) {
					query.addCriteria(Criteria.where("status").is(status));
				}
				// isRead
				String isRead = messageBo.getIsRead();
				if (StringUtils.isNotBlank(isRead)) {
					query.addCriteria(Criteria.where("isRead").is(isRead));
				}

				if (StringUtils.isNotBlank(channel)) {
					query.addCriteria(Criteria.where("channel").is(channel));
				}
				String clinicId = messageBo.getClinicId();
				if (StringUtils.isNotBlank(clinicId)) {
					//query.addCriteria(Criteria.where("clinicId").is(clinicId));
					Criteria criteriaClinicId = new Criteria();  
					criteriaClinicId.orOperator(Criteria.where("clinicId").is(clinicId),Criteria.where("clinicId").is(null),Criteria.where("clinicId").is(""));   
					query.addCriteria(criteriaClinicId);
				}
				query.addCriteria(Criteria.where("delFlag").is("0"));
				Sort sort = new Sort(Direction.DESC, "publishDate");
				query.with(sort);
				List<MessageBO> messageList = messageRepository.find(query, MessageBO.class);
				if (messageList != null && messageList.size() > 0) {
					result = messageList.get(0);
				}
			}
		} catch (Exception e) {
			logger.error("MessageProducerServiceImpl->findRecentMessage:" + e.toString());
		}
		return result;
	}

	/*
	 * @Override public JsonResponse<List<VOMessage>>
	 * findRecentMessageAndUnreadTotal(MessageBO messageBo){
	 * JsonResponse<List<VOMessage>> result = new
	 * JsonResponse<List<VOMessage>>(); try {
	 * messageBo.setIsRead("0");//查询总数需要未读 List<VOMessage> vomessageCountList =
	 * messageRepository.getCountByType(messageBo); List<VOMessage> list = new
	 * ArrayList<VOMessage>(); String receiverId = messageBo.getReceiverId();
	 * String acceptRoleId = messageBo.getAcceptRoleId(); String messageTypeId =
	 * "1"; messageBo.setReceiverId(receiverId);
	 * messageBo.setAcceptRoleId(acceptRoleId);
	 * messageBo.setMessageTypeId(messageTypeId); messageBo.setIsRead(null);
	 * //查询最新消息不需要看未读已读标志 MessageBO recentMessage1 =
	 * findRecentMessage(messageBo); messageTypeId = "2";
	 * messageBo.setMessageTypeId(messageTypeId); MessageBO recentMessage2 =
	 * findRecentMessage(messageBo); messageTypeId = "3";
	 * messageBo.setMessageTypeId(messageTypeId); MessageBO recentMessage3 =
	 * findRecentMessage(messageBo);
	 * list.add(unionUreadTotal(vomessageCountList, recentMessage1));
	 * list.add(unionUreadTotal(vomessageCountList, recentMessage2));
	 * list.add(unionUreadTotal(vomessageCountList, recentMessage3));
	 * result.setResult(list); result.setStatus(Status.SUCCESS); } catch
	 * (Exception e) { logger.error(
	 * "MessageProducerServiceImpl->findRecentMessageAndUnreadTotal:" +
	 * e.toString()); e.printStackTrace(); result.setStatus(Status.ERROR);
	 * result.setErrorCode(ErrorType.SystemBusy.getCode());
	 * result.setErrorMsg(ErrorType.SystemBusy.getDesc()); } return result; }
	 */

	/*
	 * public VOMessage unionUreadTotal(List<VOMessage> vomessageCountList,
	 * MessageBO recentMessage) { VOMessage voTemp = new VOMessage();
	 * voTemp.setId(recentMessage.getId());
	 * voTemp.setMessageType(recentMessage.getMessageType());
	 * voTemp.setMessageTypeId(recentMessage.getMessageTypeId());
	 * voTemp.setAcceptRole(recentMessage.getAcceptRole());
	 * voTemp.setAcceptRoleId(recentMessage.getAcceptRoleId());
	 * voTemp.setChannel(recentMessage.getChannel());
	 * voTemp.setCitycode(recentMessage.getCitycode());
	 * voTemp.setContent(recentMessage.getContent());
	 * voTemp.setImgPath(recentMessage.getImgPath());
	 * voTemp.setIsPush(recentMessage.getIsPush());
	 * voTemp.setIsSendNow(recentMessage.getIsSendNow());
	 * voTemp.setIsShow(recentMessage.getIsShow());
	 * voTemp.setLink(recentMessage.getLink());
	 * voTemp.setPublishBeginDate(recentMessage.getPublishBeginDate());
	 * voTemp.setPublishDate(recentMessage.getPublishDate());
	 * voTemp.setPublishEndDate(recentMessage.getPublishEndDate());
	 * voTemp.setReceiverId(recentMessage.getReceiverId());
	 * voTemp.setScope(recentMessage.getScope());
	 * voTemp.setSendTime(recentMessage.getSendTime());
	 * voTemp.setStatus(recentMessage.getStatus());
	 * voTemp.setTemplateId(recentMessage.getTemplateId());
	 * voTemp.setTopic(recentMessage.getTopic());
	 * voTemp.setIsRead(recentMessage.getIsRead());
	 * voTemp.setIsShow(recentMessage.getIsShow());
	 * 
	 * for (VOMessage vo : vomessageCountList) {// 将各个类型的最新数据和总条数合并 String
	 * receiverId = vo.getReceiverId(); String acceptRoleId =
	 * vo.getAcceptRoleId(); String messageTypeId = vo.getMessageTypeId(); if
	 * (messageTypeId.equals(recentMessage.getMessageTypeId()) &&
	 * receiverId.equals(recentMessage.getReceiverId()) &&
	 * acceptRoleId.equals(recentMessage.getAcceptRoleId())) {
	 * voTemp.setUnReadTotal(vo.getUnReadTotal()); } } if
	 * (CommonTools.nullOrEmpty(voTemp.getUnReadTotal())) {
	 * voTemp.setUnReadTotal(0); } return voTemp; }
	 */

	@Override
	public JsonResponse<Boolean> setBatchMessageByOneField(String messageTypeId, String receiverId, String acceptRoleId,
			List<String> idList, String updateKey, String updateValue) {
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		try {
			Query query = new Query();
			if (StringUtils.isNotBlank(acceptRoleId)) {
				// query.addCriteria(Criteria.where("acceptRoleId").is(acceptRoleId));
				query.addCriteria(Criteria.where("acceptRoleId").in(acceptRoleId.split(",")));
			}
			if (StringUtils.isNotBlank(messageTypeId)) {
				query.addCriteria(Criteria.where("messageTypeId").is(messageTypeId));
			}
			if (StringUtils.isNotBlank(receiverId)) {
				query.addCriteria(Criteria.where("receiverId").is(receiverId)); // casUUID
			}
			query.addCriteria(Criteria.where("delFlag").is("0"));
			if (idList != null && idList.size() > 0) {
				query.addCriteria(Criteria.where("_id").in(idList));
			}
			Update update = new Update();
			update.set(updateKey, updateValue);// 更新
			update.set("modifyDate", new Date());
			messageRepository.updateMany(query, update, MessageBO.class);
			result.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("deleteBatchMessage Exception================>" + e);
			result.setStatus(JsonResponse.Status.ERROR);
			result.setErrorCode(ErrorType.DatabaseExecuteException.getCode());
			result.setErrorMsg(ErrorType.DatabaseExecuteException.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<Long> getMessageCount(MessageBO messageBo) {
		JsonResponse<Long> result = new JsonResponse<Long>();
		Query query = new Query();
		if (StringUtils.isNotBlank(messageBo.getReceiverId())) {
			query.addCriteria(Criteria.where("receiverId").is(messageBo.getReceiverId())); // casUUID
		}
		if (StringUtils.isNotBlank(messageBo.getAcceptRoleId())) {
			// query.addCriteria(Criteria.where("acceptRoleId").is(messageBo.getAcceptRoleId()));
			query.addCriteria(Criteria.where("acceptRoleId").in(messageBo.getAcceptRoleId().split(",")));
		}
		if (StringUtils.isNotBlank(messageBo.getMessageTypeId())) {
			query.addCriteria(Criteria.where("messageTypeId").is(messageBo.getMessageTypeId()));
		}
		if (StringUtils.isNotBlank(messageBo.getChannel())) {
			query.addCriteria(Criteria.where("channel").is(messageBo.getChannel()));
		}
		if (StringUtils.isNotBlank(messageBo.getClinicId())) {
			query.addCriteria(Criteria.where("clinicId").is(messageBo.getClinicId()));
		}
		query.addCriteria(Criteria.where("delFlag").is("0"));
		query.addCriteria(Criteria.where("isRead").is("0"));
		query.addCriteria(Criteria.where("status").is("1"));// 查已发布消息
		long count = messageRepository.findCount(query, MessageBO.class);
		result.setResult(count);
		return result;
	}

	/**
	 * 
	 * @param messageBo
	 * @param messageTypes
	 *            消息类型
	 * @return
	 */
	public Map<String, VOMessage> getRecentMessageByType(MessageBO messageBo, List<String> messageTypes) {
		Map<String, VOMessage> messageMap = new HashMap<String, VOMessage>(); // messageTypeId，MessageBO
		for (int i = 0; i < messageTypes.size(); i++) {
			messageBo.setMessageTypeId(messageTypes.get(i));
			MessageBO bo = findRecentMessage(messageBo);
			if (bo != null && bo.getId() != null) {
				VOMessage recentMessage = new VOMessage();
				recentMessage.setId(bo.getId());
				recentMessage.setMessageType(bo.getMessageType());
				recentMessage.setMessageTypeId(bo.getMessageTypeId());
				recentMessage.setAcceptRole(bo.getAcceptRole());
				recentMessage.setAcceptRoleId(bo.getAcceptRoleId());
				recentMessage.setChannel(bo.getChannel());
				recentMessage.setCitycode(bo.getCitycode());
				recentMessage.setContent(bo.getContent());
				recentMessage.setImgPath(bo.getImgPath());
				recentMessage.setIsPush(bo.getIsPush());
				recentMessage.setIsSendNow(bo.getIsSendNow());
				recentMessage.setIsShow(bo.getIsShow());
				recentMessage.setLink(bo.getLink());
				recentMessage.setPublishBeginDate(bo.getPublishBeginDate());
				recentMessage.setPublishDate(bo.getPublishDate());
				recentMessage.setPublishEndDate(bo.getPublishEndDate());
				recentMessage.setReceiverId(bo.getReceiverId());
				recentMessage.setScope(bo.getScope());
				recentMessage.setSendTime(bo.getSendTime());
				recentMessage.setStatus(bo.getStatus());
				recentMessage.setTemplateId(bo.getTemplateId());
				recentMessage.setTopic(bo.getTopic());
				recentMessage.setIsRead(bo.getIsRead());
				recentMessage.setIsShow(bo.getIsShow());
				recentMessage.setUnReadTotal(0);// 默认为0
				messageMap.put(bo.getMessageTypeId(), recentMessage);
			}
		}
		return messageMap;
	}

	/**
	 * 将每个类型的消息未读数和最新一条数据汇总
	 * 
	 * @param vomessageCountList
	 *            每个消息类型对应的未读总数
	 * @param recentMessage
	 *            每个消息类型最新一条数据
	 * @return
	 */
	public List<VOMessage> unionUreadTotal(List<VOMessage> vomessageCountList, Map<String, VOMessage> recentMessage) {
		List<VOMessage> voMessageList = new ArrayList<VOMessage>();
		for (VOMessage vo : vomessageCountList) {// 将各个类型的最新数据和总条数合并
			if (recentMessage.containsKey(vo.getMessageTypeId())) {// 消息类型有未读肯定有最新消息，故不会出现有未读消息没有最新消息
				recentMessage.get(vo.getMessageTypeId()).setUnReadTotal(vo.getUnReadTotal());
			}
		}
		// 将已经将未读数据放到list中
		for (VOMessage vo : recentMessage.values()) {
			voMessageList.add(vo);
		}
		return voMessageList;
	}

	@Override
	public JsonResponse<List<VOMessage>> findRecentMessageAndUnreadTotal(MessageBO messageBo) {
		JsonResponse<List<VOMessage>> result = new JsonResponse<List<VOMessage>>();
		try {
			messageBo.setIsRead("0");// 查询总数需要未读
			List<VOMessage> vomessageCountList = messageRepository.getCountByType(messageBo);
			messageBo.setIsRead(null);// 查询总最新消息，可以不是未读
			List<String> messageTypes = messageRepository.getMessageTypes(messageBo);
			Map<String, VOMessage> recentMessage = getRecentMessageByType(messageBo, messageTypes);
			List<VOMessage> recentMessageAndUnreadTotal = unionUreadTotal(vomessageCountList, recentMessage);
			result.setResult(recentMessageAndUnreadTotal);
			result.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("MessageProducerServiceImpl->findRecentMessageAndUnreadTotal:" + e.toString());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<Void> clinicConfirmBookingForupdate(String bookingId, String uid, String patientName,
			String bookingTime, String clinicId, String clinicName, String serviceName, String memberId,
			String clinicAddress, String consultationCode) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setLink(ylptHost + "?displaymenu=order_management");

			String[] times = splitTime(bookingTime);
			// 接受者角色为诊所
			messageBO.setId(uid + "-0");
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING, null, null));
			messageBO
					.setContent(messageSource.getMessage(
							MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_FORUPDATE, new String[] { patientName,
									times[0], times[1], times[2], times[3] + ":" + times[4], clinicName, serviceName },
							null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			// messageBO.setId(uid + "-0_BD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			// messageBO.setContent(messageSource.getMessage(
			// MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_APP_FORUPDATE,
			// new String[] { patientName,
			// times[0], times[1], times[2], times[3] + ":" + times[4],
			// clinicName, serviceName },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);

			// 接受者角色为客户
			messageBO.setId(uid + "-1");
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING, null, null));
			messageBO
					.setContent(
							messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_FORUPDATE,
									new String[] { times[0], times[1], times[2], times[3] + ":" + times[4], clinicName,
											serviceName, bookingId, clinicAddress, consultationCode, memberRoot },
									null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			// messageBO.setId(uid + "-1_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO.setReceiverId(memberId);
			// messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING,
			// null, null));
			// messageBO
			// .setContent(
			// messageSource
			// .getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_APP_FORUPDATE,
			// new String[] { times[0], times[1], times[2], times[3] + ":" +
			// times[4],
			// clinicName, serviceName, bookingId, clinicAddress,
			// consultationCode },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
			logger.info("创建clinicConfirmBookingForupdate消息成功" + uid);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBookingForupdate消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	@Override
	public JsonResponse<Void> clinicConfirmBookingForupdateNormal(String bookingId, String uid, String patientName,
			String bookingTime, String clinicId, String clinicName, String serviceName, String memberId,
			String clinicAddress, String consultationCode) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			MessageBO messageBO = new MessageBO();

			messageBO.setCreateDate(new Date());
			messageBO.setModifyDate(new Date());
			messageBO.setPublishDate(new Date());
			messageBO.setMessageType(MessageConsts.BOOKING_MESSAGE_TYPE);
			messageBO.setMessageTypeId(MessageConsts.BOOKING_MESSAGE_TYPE_ID);
			messageBO.setIsShow(MessageConsts.IS_SHOW_YES);
			messageBO.setIsRead(MessageConsts.IS_READ_UN);
			messageBO.setStatus(MessageConsts.STATUS);
			messageBO.setDelFlag(MessageConsts.DEL_FLAG);
			messageBO.setCitycode(MessageConsts.CITY_CODE_ALL);
			messageBO.setTemplateId(MessageConsts.TEMPLATE_ID);
			messageBO.setCreateUser(MessageConsts.USER);
			messageBO.setModifyUser(MessageConsts.USER);
			messageBO.setLink(ylptHost + "?displaymenu=order_management");

			// String[] times = splitTime(bookingTime);
			// 接受者角色为诊所
			messageBO.setId(uid + "-0");
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_CLINIC_VALUE);
			messageBO.setReceiverId(clinicId);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING, null, null));
			messageBO.setContent(
					messageSource.getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_FORUPDATE_NORMAL,
							new String[] { patientName, bookingTime, clinicName, serviceName }, null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			// messageBO.setId(uid + "-0_BD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_BD);
			// messageBO.setContent(messageSource.getMessage(
			// MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_APP_FORUPDATE,
			// new String[] { patientName,
			// times[0], times[1], times[2], times[3] + ":" + times[4],
			// clinicName, serviceName },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);

			// 接受者角色为客户
			messageBO.setId(uid + "-1");
			messageBO.setAcceptRoleId(MessageConsts.SYS_ROLE_PATIENT_VALUE);
			messageBO.setReceiverId(memberId);
			messageBO.setChannel(MessageConsts.CHANNEL_TYPE_WZ);
			messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING, null, null));
			messageBO.setContent(messageSource.getMessage(
					MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_FORUPDATE_NORMAL, new String[] { bookingTime,
							clinicName, serviceName, bookingId, clinicAddress, consultationCode, memberRoot },
					null));
			messageRepository.insert(messageBO, MessageBO.class);
			// app消息
			// messageBO.setId(uid + "-1_CD");
			// messageBO.setChannel(MessageConsts.CHANNEL_TYPE_CD);
			// messageBO.setReceiverId(memberId);
			// messageBO.setTopic(messageSource.getMessage(MessageConsts.TOPIC_CLINIC_CONFIRM_BOOKING,
			// null, null));
			// messageBO
			// .setContent(
			// messageSource
			// .getMessage(MessageConsts.CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_APP_FORUPDATE,
			// new String[] { times[0], times[1], times[2], times[3] + ":" +
			// times[4],
			// clinicName, serviceName, bookingId, clinicAddress,
			// consultationCode },
			// null));
			// messageRepository.insert(messageBO, MessageBO.class);
			logger.info("创建clinicConfirmBookingForupdate消息成功" + uid);
		} catch (Exception e) {
			logger.error("创建clinicConfirmBookingForupdate消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
		}
		return jsonResponse;
	}

	
	@Override
	public JsonResponse<String> sendMessageToUserAndUnderling(Map<String, Object> params) {
		JsonResponse<String> ret  = new JsonResponse<String>();
		ret.setStatus(JsonResponse.Status.SUCCESS);
		ret = this.messageProducerService.sendMessageToUser(params);
		if(!JsonResponse.Status.SUCCESS.equals(ret.getStatus())){
			return ret;
		}
		
		logger.info("sendMessageToUserAndUnderling------------------> start");
		String receiveIdType = (String) params.get("receiveIdType");
		if(Consts.IS_CLINIC_ID.equals(receiveIdType)){//传入的clinicId时
			List<String> casUuidsCon = (List<String>)params.get("casUuids");
			List<String> receiveIds = new ArrayList<String>();
			for (String clinicId : casUuidsCon) {
				//每次循环开始，清空接收人list
				receiveIds.clear();
				
				//固定参数：casUuid类型，内部员工
				params.put("receiveIdType", Consts.IS_CASUU_ID);
				params.put("acceptRoleId",Consts.SYS_ROLE_ADMIN_VALUE);
				
				com.pinganwj.clinic.api.domain.JsonResponse<List<EmployeeInnerInfo>> employeesJson = this.clinicApiService.getInnerEmployeeByClinicId(clinicId);
				StringBuilder idsBuilder = new StringBuilder();
				if(Status.SUCCESS.getValue().equals(employeesJson.getStatus().getValue())){
					List<EmployeeInnerInfo> employees =  employeesJson.getResult();
					for (EmployeeInnerInfo employee : employees) {
						if(employee.getUserId() != null && StringUtils.isNotBlank(employee.getUserId())){
							receiveIds.add(employee.getUserId());
							//为log打印准备的变量
							idsBuilder.append(employee.getUserId() + ",");
						}
					}
					
					//循环覆盖接受人id和关联的clinicId，并且循环发送
					logger.info("member's ids ---------->" + idsBuilder.toString());
					if(receiveIds.size()>0 ){
						params.put("casUuids",receiveIds);
						params.put("clinicId", clinicId);
						ret = this.messageProducerService.sendMessageToUser(params);
					}
				}else{
					logger.info("sendMessageToUserAndUnderling's exception---------------------->"+employeesJson.getErrorMsg());
					ret.setErrorMsg(employeesJson.getErrorMsg());
					ret.setErrorCode(employeesJson.getErrorCode());
					ret.setStatus(JsonResponse.Status.ERROR);
					return ret;
				}
			}
		}
		return ret;
	}
	
	
	/**
	 * 根据clinicId获取诊所内部员工
	 * @param clinicId
	 * @return
	 */
	private List<String> getMemberIds(String clinicId,String sourceCodes){
		List<String> receiveIds = new ArrayList<String>();
//		com.pinganwj.clinic.api.domain.JsonResponse<List<EmployeeInnerInfo>> employeesJson = this.clinicApiService.getInnerEmployeeByResourceCode(clinicId,sourceCodes);
		StringBuilder idsBuilder = new StringBuilder();
//		if(Status.SUCCESS.getValue().equals(employeesJson.getStatus().getValue())){
//			List<EmployeeInnerInfo> employees =  employeesJson.getResult();
//			for (EmployeeInnerInfo employee : employees) {
//				if(employee.getUserId() != null && StringUtils.isNotBlank(employee.getUserId())){
//					receiveIds.add(employee.getUserId());
//					//为log打印准备的变量
//					idsBuilder.append(employee.getUserId() + ",");
//				}
//			}
//			
//			//循环覆盖接受人id和关联的clinicId，并且循环发送
//		}
		logger.info("member's ids ---------->" + idsBuilder.toString());
		return receiveIds;
	}

	@Override
	public JsonResponse<Void> medicinesStockLimitWarning(String clinicId, String medicineName, String limitStock,
			String curStock,String isMany) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			logger.info("------------------------- medicinesStockLimitWarning start -------------------------");
			
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_KCGL);
			this.messageBusinessService.medicinesStockLimitWarning(clinicId, medicineName, limitStock, curStock, memberIds,isMany);
			logger.info("------------------------- medicinesStockLimitWarning end -------------------------");
		} catch (Exception e) {
			logger.error("创建medicinesStockLimitWarning消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
			jsonResponse.setErrorMsg("发送库存下限预警消息异常！");
		}
		return jsonResponse;
	}

	@Override
	public JsonResponse<Void> medicinesStockMaxWarning(String clinicId, String medicineName, String maxStock,
			String curStock,String isMany) {
		JsonResponse<Void> jsonResponse = new JsonResponse<Void>();
		try {
			logger.info("------------------------- medicinesStockMaxWarning start -------------------------");
			
			List<String> memberIds = this.getMemberIds(clinicId,MessageConsts.MESSAGE_MODULE_SOURCE_CODE_KCGL);
			this.messageBusinessService.medicinesStockLimitWarning(clinicId, medicineName, maxStock, curStock, memberIds,isMany);
			logger.info("------------------------- medicinesStockMaxWarning end -------------------------");
		} catch (Exception e) {
			logger.error("创建medicinesStockLimitWarning消息失败", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
			jsonResponse.setErrorMsg("发送库存上限预警消息异常！");
		}
		return jsonResponse;
	}


}
