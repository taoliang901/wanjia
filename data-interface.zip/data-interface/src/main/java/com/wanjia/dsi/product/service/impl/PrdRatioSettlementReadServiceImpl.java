package com.wanjia.dsi.product.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.product.dao.mapper.PrdRatioSettlementMapper;
import com.wanjia.dsi.product.model.PrdFrameworkAgreementLog;
import com.wanjia.dsi.product.model.PrdRatioSettlement;
import com.wanjia.dsi.product.service.PrdRatioSettlementReadService;


@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class PrdRatioSettlementReadServiceImpl implements PrdRatioSettlementReadService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private PrdRatioSettlementMapper prdRatioSettlementMapper;

	@Override
	public JsonResponse<List<PrdRatioSettlement>> findByEntity(PrdRatioSettlement ratio) {
		JsonResponse<List<PrdRatioSettlement>> jr = new JsonResponse<List<PrdRatioSettlement>>();
		try{
			List<PrdRatioSettlement> list = prdRatioSettlementMapper.findByEntity(ratio);
			jr.setStatus(Status.SUCCESS);
			jr.setResult(list);
		
		}catch(Exception e){
			logger.error("find prdRatioSettlement error:",e);
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}

	
}
