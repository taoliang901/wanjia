package com.wanjia.dsi.web.job.service.impl;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esotericsoftware.minlog.Log;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pahaoche.common.DateUtil;
import com.pahaoche.hy.util.RandomUtil;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.kafka.KafkaSyncProducer;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.base.invoker.ResumeFromSource;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.job.dao.mapper.HyJobRecordMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvEducationMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvEducationVoMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvExperienceMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvExperienceVoMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvVoMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentJobRecordMapper;
import com.wanjia.dsi.web.job.model.HyJobRecord;
import com.wanjia.dsi.web.job.model.TalentCv;
import com.wanjia.dsi.web.job.model.TalentCvDetail;
import com.wanjia.dsi.web.job.model.TalentCvEducation;
import com.wanjia.dsi.web.job.model.TalentCvEducationExample;
import com.wanjia.dsi.web.job.model.TalentCvExperience;
import com.wanjia.dsi.web.job.model.TalentCvExperienceExample;
import com.wanjia.dsi.web.job.model.TalentCvVo;
import com.wanjia.dsi.web.job.model.TalentJobRecord;
import com.wanjia.dsi.web.job.service.CvService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CvServiceImpl extends BaseServiceImpl implements CvService {

	private Logger logger = Logger.getLogger(CvServiceImpl.class);

	@Autowired
	private TalentCvMapper cvMapper;
	
	@Autowired
	private TalentCvVoMapper talentCvVoMapper;
	
	@Autowired
	private TalentCvExperienceMapper cvExpMapper;
	
	@Autowired
	private TalentCvExperienceVoMapper talentCvExperienceVoMapper;
	
	@Autowired
	private TalentCvEducationVoMapper talentCvEducationVoMapper;
	
	@Autowired
	private TalentCvEducationMapper cvEduMapper;

	@Autowired
	private HyJobRecordMapper hyJobRecordMapper;
	
	@Autowired
	private TalentJobRecordMapper talentJobRecordMapper;

	/**
	 * kafka消息生产者（貌似非同步，不会同步地进行PDF文件转换，不能知晓转换结果）
	 */
	@Resource
	private KafkaSyncProducer kafkaSyncProducer;

	@Value("#{kafkaProps['p.topic.office2pdf']}")
	private String P_TOPIC_DOC2PDF;

	@Value("#{hyCasConfig['wj_cvFilePath']}")
	private String WJ_CV_FILEPATH;

	/**
	 * 查询简历&&简历为空，则新增简历
	 * 
	 * @param request
	 * @param reponse
	 * @return
	 */
	@Override
	public JsonResponse<List<TalentCvVo>> getCvList(String requestId, Map<String, Object> param) {
		// 返回结果
		JsonResponse<List<TalentCvVo>> result = new JsonResponse<List<TalentCvVo>>();
		try {
			// 查询
			List<TalentCvVo> cvs = hyJobRecordMapper.selectCvByMap(param);

			// 如果没有简历则新增一个
			if(CollectionUtils.isEmpty(cvs)){
				TalentCvVo talentCvVo = new TalentCvVo();
				talentCvVo.setId(UUID.randomUUID().toString());
				// 设置简历编号
				talentCvVo.setCvShowId("WJRC"+DateUtil.date2String(new Date(), "yyMMdd")+RandomUtil.random(6).toString());
				talentCvVo.setMemberId(Long.valueOf(param.get("memberId").toString()));
				// 首次创建默认为未创建0，完善信息以后设置为审核通过
				talentCvVo.setStatus("0");
				talentCvVo.setDeliveryType("1");
				talentCvVo.setOpenStatus("0");
				talentCvVo.setFromSource(ResumeFromSource.Wanjia.getDesc());
				talentCvVo.setReleaseTime(new Date());
				talentCvVo.setRefreshTime(new Date());
				talentCvVo.setCreateDate(new Date());
				talentCvVo.setCreateUser(param.get("memberId").toString());
				cvMapper.insertSelective(talentCvVo);
				cvs.add(talentCvVo);
			}
			// 结果返回
			result.setStatus(Status.SUCCESS);
			result.setResult(cvs);
		} catch (Exception e) {
			logger.error("查询简历信息失败:" + e);
			throw new ServiceException(ErrorType.SystemBusy.getCode(), ErrorType.SystemBusy.getDesc(), e);
		}
		return result;
	}

	/**
	 * 新增OR更新简历
	 * 
	 * @param request
	 * @param reponse
	 * @return
	 */
	@Override
	public JsonResponse<Long> modifyCv(String requestId, TalentCv talentCv) {
		// 返回结果
		JsonResponse<Long> result = new JsonResponse<Long>();
				
		talentCv.setModifyUser(talentCv.getMemberId().toString());
		talentCv.setModifyDate(new Date());
		// 更新简历
		cvMapper.updateByPrimaryKeySelective(talentCv);
		result.setStatus(Status.SUCCESS);
		
		if(StringUtils.isNotBlank(talentCv.getCvPath())&&StringUtils.isNotBlank(talentCv.getPdfPath()))
		{
			//doc 转 pdf
			doc2pdf(WJ_CV_FILEPATH + File.separator + talentCv.getCvPath(), WJ_CV_FILEPATH + File.separator + talentCv.getPdfPath());
		}
		
		// 更新简历状态
		modifyCvStatus(talentCv.getId());
		return result;
	}

	/**
	 * doc 转 pdf
	 * 
	 * @注1：	文件名不能为中文
	 */
	public void doc2pdf(String cvPath, String pdfPath) {

		if(StringUtils.endsWithIgnoreCase(cvPath, ".ppt") || StringUtils.endsWithIgnoreCase(cvPath, ".doc")) {
			if(StringUtils.endsWithIgnoreCase(pdfPath, ".pdf")) {
				try {
					String json = "{\"officeFilePath\":\""+cvPath+"\", \"pdfFilePath\":\""+pdfPath+"\"}";
					boolean flag =  kafkaSyncProducer.producerByString(P_TOPIC_DOC2PDF, json);
					if(flag){
						logger.info("转PDF成功：" + pdfPath);
					} else {
						throw new ServiceException(null, "doc转pdf失败，请稍后重试！");
					}
				} catch(Exception e) {
					throw new ServiceException(null, "doc转pdf时出现未知异常，请稍后重试！", e);
				}
			} else {
				throw new ServiceException(null, "目标文件支持.pdf格式的文件");
			}
		} else if (!StringUtils.endsWithIgnoreCase(cvPath, ".pdf")){
			throw new ServiceException(null, "源文件只支持.doc 或者.ppt格式的文件");
		}
	}

	/**
	 * 删除简历
	 * 
	 * @param request
	 * @param reponse
	 * @return
	 */
	@Override
	public JsonResponse<Boolean> delCv(String requestId, String id) {
		// 返回结果
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		try {
			// 设置参数
			TalentCv cv = new TalentCv();
			cv.setId(id);
			cv.setDelFlag("1");
			cv.setModifyDate(new Date());
			// 删除简历
			cvMapper.updateByPrimaryKeySelective(cv);
			result.setStatus(Status.SUCCESS);
			result.setResult(true);
		} catch (Exception e) {
			logger.error("删除简历信息失败:" + e);
			throw new ServiceException(ErrorType.SystemBusy.getCode(), ErrorType.SystemBusy.getDesc(), e);
		}
		return result;
	}

	@Override
	public JsonResponse<PageInfo<HyJobRecord>> getHyJobRecordList(
			String requestId, String pageNo, String pageSize, String status,
			String cvId) {
		// 设置返回参数
		JsonResponse<PageInfo<HyJobRecord>> result = new JsonResponse<PageInfo<HyJobRecord>>();
		
		// 设置查询参数
		HyJobRecord jobRecord = new HyJobRecord();
		if (CommonTools.notNullAndEmpty(status)) {
			jobRecord.setStatus(status);
		}
		if (CommonTools.notNullAndEmpty(cvId)) {
			jobRecord.setTalentCvId(cvId);
		}
		jobRecord.setDelFlag(0);
		
		// 查询
		try {
			PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));// 设置分页页号和页码
			List<HyJobRecord> list = hyJobRecordMapper.getHyJobRecordList(jobRecord);
			PageInfo<HyJobRecord> page = new PageInfo<HyJobRecord>(list);// 获得分页信息
			result.setResult(page);

		} catch (Exception e) {
			logger.error("查询投递信息失败:" + e);
			throw new ServiceException(ErrorType.SystemBusy.getCode(), ErrorType.SystemBusy.getDesc(), e);
		}

		return result;
	}

	@Override
	public JsonResponse<PageInfo<HyJobRecord>> getClinicViewList(
			String requestId, String pageNo, String pageSize, String cvId) {
		// 设置返回参数
		JsonResponse<PageInfo<HyJobRecord>> result = new JsonResponse<PageInfo<HyJobRecord>>();
		
		// 设置查询参数
		HyJobRecord jobRecord = new HyJobRecord();
		if (CommonTools.notNullAndEmpty(cvId)) {
			jobRecord.setTalentCvId(cvId);
		}
		jobRecord.setDelFlag(0);
		
		// 查询
		try {
			PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));// 设置分页页号和页码
			List<HyJobRecord> list = hyJobRecordMapper.getClinicViewList(jobRecord);
			PageInfo<HyJobRecord> page = new PageInfo<HyJobRecord>(list);// 获得分页信息
			result.setResult(page);

		} catch (Exception e) {
			logger.error("查询简历查看信息失败:" + e);
			throw new ServiceException(ErrorType.SystemBusy.getCode(), ErrorType.SystemBusy.getDesc(), e);
		}

		return result;
	}
	
	/**
	 * 删除投递信息
	 * 
	 * @param request
	 * @param reponse
	 * @return
	 */
	@Override
	public JsonResponse<Boolean> editJobRecord(String requestId, TalentJobRecord talentJobRecord) {
		// 返回结果
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		try {
			// 修改就诊人
			talentJobRecord.setModifyDate(new Date());
			talentJobRecordMapper.updateByPrimaryKeySelective(talentJobRecord);
			result.setStatus(Status.SUCCESS);
			result.setResult(true);
		} catch (Exception e) {
			logger.error("删除投递信息失败:" + e);
			throw new ServiceException(ErrorType.SystemBusy.getCode(), ErrorType.SystemBusy.getDesc(), e);
		}
		return result;
	}

	@Override
	public JsonResponse<Void> modifyCvStatus(String cvId) {
		// 查询简历信息
		TalentCv talentCv = cvMapper.selectByPrimaryKey(cvId);
		
		// 是否可以审核通过
		boolean canPass = false;
		// 简历类型为在线简历
		if("1".equals(talentCv.getDeliveryType()))
		{
			// 查询工作经历和教育经历
			TalentCvExperienceExample expExample = new TalentCvExperienceExample();
			TalentCvExperienceExample.Criteria expCriteria = expExample.createCriteria();
			expCriteria.andCvIdEqualTo(cvId);
			expCriteria.andDelFlagEqualTo("0");
			List<TalentCvExperience> exps = cvExpMapper.selectByExample(expExample);
			
			TalentCvEducationExample example = new TalentCvEducationExample();
			TalentCvEducationExample.Criteria criteria = example.createCriteria();
			criteria.andCvIdEqualTo(cvId);
			criteria.andDelFlagEqualTo("0");
			List<TalentCvEducation> edus = cvEduMapper.selectByExample(example);
			
			// 资料已完整，更新简历状态为已审核通过3
			if(StringUtils.isNotBlank(talentCv.getName())&&CollectionUtils.isNotEmpty(exps)&&CollectionUtils.isNotEmpty(edus))
			{
				canPass = true;
			}
		// 简历类型为附件简历	
		}else{
			// 资料已完整，更新简历状态为已审核通过3
			if(StringUtils.isNotBlank(talentCv.getName())&&StringUtils.isNotBlank(talentCv.getCvPath()))
			{
				canPass = true;
			}
		}
		if(canPass){
			// 设置为审核通过
			talentCv.setStatus("3");
		}else{
			// 设置为未创建
			talentCv.setStatus("0");
		}
		talentCv.setModifyDate(new Date());
		talentCv.setModifyUser(talentCv.getCreateUser());
		cvMapper.updateByPrimaryKeySelective(talentCv);
		return null;
	}

	@Override
	public JsonResponse<TalentCvDetail> getCvDetailById(String requestId, String cvId) {
		JsonResponse<TalentCvDetail> result = new JsonResponse<TalentCvDetail>();
		
		if(StringUtils.isBlank(cvId)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.IllegalArgument.getCode());
			result.setErrorMsg("cvId必传参数");
		}
		
		try {
			TalentCvDetail detail = new TalentCvDetail();
			
			TalentCv talentCv = cvMapper.selectByPrimaryKey(cvId);
			if(talentCv != null && StringUtils.isNotBlank(talentCv.getId())){
				detail.setTalentCvBasic(talentCv);
			}
			
			if(detail != null && StringUtils.isNotBlank(detail.getTalentCvBasic().getId())){
				//教育经历列表
				TalentCvEducationExample example = new TalentCvEducationExample();
				TalentCvEducationExample.Criteria criteria = example.createCriteria();
				if(StringUtils.isNotEmpty(cvId)){
					criteria.andCvIdEqualTo(cvId);
				}
				criteria.andDelFlagEqualTo("0");
				List<TalentCvEducation> edus = cvEduMapper.selectByExample(example);
				
				//工作经验列表
				TalentCvExperienceExample expExample = new TalentCvExperienceExample();
				TalentCvExperienceExample.Criteria expCriteria = expExample.createCriteria();
				if(StringUtils.isNotEmpty(cvId)){
					expCriteria.andCvIdEqualTo(cvId);
				}
				expCriteria.andDelFlagEqualTo("0");
				List<TalentCvExperience> exps = cvExpMapper.selectByExample(expExample);
				
				detail.setEducationList(edus);
				detail.setExperienceList(exps);
				
				result.setResult(detail);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Log.error(e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return result;
	}

	@Override
	public JsonResponse<List<HyJobRecord>> getHyJobRecordList(String requestId, String status, String cvId) {
		// 设置返回参数
		JsonResponse<List<HyJobRecord>> result = new JsonResponse<List<HyJobRecord>>();
		
		// 设置查询参数
		HyJobRecord jobRecord = new HyJobRecord();
		if (CommonTools.notNullAndEmpty(status)) {
			jobRecord.setStatus(status);
		}
		if (CommonTools.notNullAndEmpty(cvId)) {
			jobRecord.setTalentCvId(cvId);
		}
		jobRecord.setDelFlag(0);
		List<HyJobRecord> list = hyJobRecordMapper.getHyJobRecordList(jobRecord);
		result.setResult(list);
		return result;
	}

	@Override
	public JsonResponse<TalentCvDetail> getCvDetailTransDictById(String requestId, String cvId) {
		JsonResponse<TalentCvDetail> result = new JsonResponse<TalentCvDetail>();
		
		if(StringUtils.isBlank(cvId)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.IllegalArgument.getCode());
			result.setErrorMsg("cvId必传参数");
		}
		
		try {
			TalentCvDetail detail = new TalentCvDetail();
			
			TalentCv talentCv = talentCvVoMapper.selectTransCvByPrimaryKey(cvId);
			if(talentCv != null && StringUtils.isNotBlank(talentCv.getId())){
				detail.setTalentCvBasic(talentCv);
			}
			
			if(detail != null && StringUtils.isNotBlank(detail.getTalentCvBasic().getId())){
				//教育经历列表
				TalentCvEducationExample example = new TalentCvEducationExample();
				TalentCvEducationExample.Criteria criteria = example.createCriteria();
				if(StringUtils.isNotEmpty(cvId)){
					criteria.andCvIdEqualTo(cvId);
				}
				criteria.andDelFlagEqualTo("0");
				example.setOrderByClause("tce.SCHOOL_END_TIME DESC");
				List<TalentCvEducation> edus = talentCvEducationVoMapper.selectTransDictByExample(example);
				
				//工作经验列表
				TalentCvExperienceExample expExample = new TalentCvExperienceExample();
				TalentCvExperienceExample.Criteria expCriteria = expExample.createCriteria();
				if(StringUtils.isNotEmpty(cvId)){
					expCriteria.andCvIdEqualTo(cvId);
				}
				expCriteria.andDelFlagEqualTo("0");
				expExample.setOrderByClause("tce.WORKING_START_TIME DESC");
				List<TalentCvExperience> exps = talentCvExperienceVoMapper.selectTransDictByExample(expExample);
				
				detail.setEducationList(edus);
				detail.setExperienceList(exps);
				
				result.setResult(detail);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return result;
	}
}
