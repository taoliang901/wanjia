package com.wanjia.dsi.web.cms.activity.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.mongodb.impl.MongoDbRepositoryImpl;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.cms.activity.model.MyCollectionBO;
import com.wanjia.dsi.web.cms.activity.model.MyCollectionStatisticsBO;
import com.wanjia.dsi.web.cms.activity.model.VOMyCollection;

@Repository
public class MyCollectionRepository extends MongoDbRepositoryImpl<MyCollectionBO> {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private MyCollectionStatisticsRepository statisticsRepository;

	/**
	 * 获取我的收藏
	 * 
	 * @param userId 
	 * @param type 资讯：A，药品：M ，疾病：D
	 * @param infoId  资讯:activityId;药品:medCode;疾病：diseaseId;
	 * @return
	 */
	public List<String> getInfoIdListMongo(String userId, String type, String infoId) {
		List<String> result = new ArrayList<String>();
		logger.info("MyCollectionRepository->getMyConnectionListMongo->userId:" + userId);
		try {
			List<DBObject> pipeline = new ArrayList<DBObject>();
			// 记录过滤条件
			String matchStr = null;
			if (StringUtils.isBlank(infoId)) {
				matchStr = "{$match:{userId:\"" + userId + "\",type: \"" + type + "\"}}";
			} else {
				matchStr = "{$match:{userId:\"" + userId + "\",type: \"" + type + "\",infoId: \"" + infoId +  "\"}}";
			}
			DBObject match = (DBObject) JSON.parse(matchStr);
			pipeline.add(match);
			// 获取数据
			DBCollection conn = mongoTemplate.getCollection("myCollectionBO");
			AggregationOutput output = conn.aggregate(pipeline);
			for (Iterator<DBObject> it = output.results().iterator(); it.hasNext();) {
				BasicDBObject dbo = (BasicDBObject) it.next();
				result.add(dbo.getString("infoId"));
			}
		} catch (Exception e) {
			logger.error(e.toString());
		}
		return result;
	}
	
	/**
	 * 获得收藏量
	 * @param type 资讯：A，药品：M ，疾病：D
	 * @param infoId  资讯:activityId;药品:medCode;疾病：diseaseId;
	 * @return
	 */
	public List<VOMyCollection> getCollectionStatistic(String type, String infoId) {
		List<VOMyCollection> result = new ArrayList<VOMyCollection>();
		logger.info("MyCollectionRepository->getCollectionStatistic->type:" + type + ",infoId:" + infoId);
		try {
			List<DBObject> pipeline = new ArrayList<DBObject>();
			// 记录过滤条件
			String matchStr = null;
			if(StringUtils.isBlank(infoId)){
				matchStr = "{$match:{type:\"" + type + "\"}}";
			}else{
				matchStr = "{$match:{infoId:\"" + infoId + "\",type: \"" + type + "\"}}";
			}
			DBObject match = (DBObject) JSON.parse(matchStr);
			pipeline.add(match);
			// 分组条件
			String groupStr = "{$group:{_id: {'infoId':'$infoId'}, statistic:{$sum:1}}}";
			DBObject group = (DBObject) JSON.parse(groupStr);
			pipeline.add(group);
			// 获取数据
			DBCollection conn = mongoTemplate.getCollection("myCollectionBO");
			AggregationOutput output = conn.aggregate(pipeline);
			for (Iterator<DBObject> it = output.results().iterator(); it.hasNext();) {
				BasicDBObject dbo = (BasicDBObject) it.next();
				 BasicDBObject keyValus = (BasicDBObject) dbo.get("_id");
				 VOMyCollection voMyCollection = new VOMyCollection();
				 voMyCollection.setInfoId(keyValus.getString("infoId"));
				 String statistic = dbo.getString("statistic");
				 if(statistic == null || "".equals(statistic)){
					 voMyCollection.setCollectionStatistic(0);
				 }else{
					 voMyCollection.setCollectionStatistic(Long.parseLong(statistic));
				 }
				result.add(voMyCollection);
			}
		} catch (Exception e) {
			logger.error("MyCollectionRepository->getCollectionStatistic" + e.toString());
		}
		return result;
	}
	

	public String syncMycollectionStatistc(String dateStr,String type) {
		logger.info("MessageBORepository->syncMycollectionStatistc start type:" + type + ",dateStr:" + dateStr);
		String result = null;
		try {
			List<DBObject> pipeline = new ArrayList<DBObject>();
			String matchStr = null;
			String groupStr = null;
			if(dateStr != null && dateStr.length() >0){
				String[] strArray = DateUtils.getMonthBeginAndEndTimeStr(dateStr);
				// 记录过滤条件
				matchStr = "{$match:{collectionDate: {$gte: \"" + strArray[0] + "\", $lte:\"" +  strArray[1] + "\"},{type:\"" + type + "\"}}}";
				DBObject match = (DBObject) JSON.parse(matchStr);
				pipeline.add(match);
			}else{
				matchStr = "{$match:{type:\"" + type + "\"}}";
			}
			DBObject match = (DBObject) JSON.parse(matchStr);
			pipeline.add(match);
			// 分组条件
			groupStr = "{$group:{_id: {'infoId':'$infoId','type':'$type'}, realCountNum:{$sum:1}}}";
			DBObject group = (DBObject) JSON.parse(groupStr);
			pipeline.add(group);
			// 获取数据
			DBCollection conn = mongoTemplate.getCollection("myCollectionBO");
			AggregationOutput output = conn.aggregate(pipeline);
			int count = 0;
			for (Iterator<DBObject> it = output.results().iterator(); it.hasNext();) {
				BasicDBObject dbo = (BasicDBObject) it.next();
				BasicDBObject keyValus = (BasicDBObject) dbo.get("_id");
				MyCollectionStatisticsBO myCollectionStatisticsBO = new MyCollectionStatisticsBO();
				String infoId = keyValus.getString("infoId");
				//String type = keyValus.getString("type");
				String realCountNum = dbo.getString("realCountNum");
				// 判断是否已经统计过
				boolean statis = statisticsRepository.exists(
						new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type))),
						MyCollectionStatisticsBO.class);
				if (statis) {// mongodb有数据直接更新总收藏量和实际收藏量，随机收藏量保持不变
					Query query = new Query(
							Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
					List<MyCollectionStatisticsBO> list = statisticsRepository.find(query,
							MyCollectionStatisticsBO.class);
					long randomNum = list.get(0).getRandomNum();
					Update update = new Update();
					update.set("countNum", (randomNum + Long.parseLong(realCountNum)));
					update.set("realCountNum", Long.parseLong(realCountNum));
					statisticsRepository.updateFirst(query, MyCollectionStatisticsBO.class, update);
				} else {
					int randomNum = CommonTools.getRandIntRange(300, 500);
					long countNum = Long.parseLong(realCountNum) + randomNum;
					myCollectionStatisticsBO.setInfoId(infoId);
					myCollectionStatisticsBO.setType(type);
					myCollectionStatisticsBO.setRealCountNum(Long.parseLong(realCountNum));
					myCollectionStatisticsBO.setRandomNum(randomNum);
					myCollectionStatisticsBO.setCountNum(countNum);
					statisticsRepository.insert(myCollectionStatisticsBO, MyCollectionStatisticsBO.class);
				}
				count = count + 1;
			}
			if(output.results() != null){
				result = "日期：" + dateStr + "所在月份更新" + count + "条数据";
			}else{
				result = "日期：" + dateStr + "所在月份更新0条数据";
			}
			logger.info("MessageBORepository->syncMycollectionStatistc end type:" + type + ",dateStr:" + dateStr);
		} catch (Exception e) {
			logger.error("MessageBORepository->syncMycollectionStatistc:" + e.toString());
			e.printStackTrace();
		}
		
		return result;
	}
	
	
}
