package com.wanjia.dsi.web.message.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import com.wanjia.dsi.base.mongodb.impl.MongoDbRepositoryImpl;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.message.model.MessageBO;
import com.wanjia.dsi.web.message.model.VOMessage;

@Repository
public class MessageRepository extends MongoDbRepositoryImpl<MessageBO> {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private MongoTemplate mongoTemplate;
	/**
	 * 通过消息类别分组统计未读消息数目
	 * @param messageBo
	 * @return
	 */
	public List<VOMessage> getCountByType(MessageBO messageBo) {
		List<VOMessage> result = new ArrayList<VOMessage>();
		 String delFlag = "0";
		 String isRead = "0";
		 String status = "1";
		 String receiverId = messageBo.getReceiverId();
		 String acceptRoleId = messageBo.getAcceptRoleId();
		 String channel = messageBo.getChannel();
		 String clinicId = messageBo.getClinicId();
		if(CommonTools.notNullAndEmpty(messageBo.getDelFlag())){
			delFlag = messageBo.getDelFlag();
		}
		if(CommonTools.notNullAndEmpty(messageBo.getIsRead())){
			isRead = messageBo.getIsRead();
		}
		if(CommonTools.notNullAndEmpty(messageBo.getStatus())){
			status = messageBo.getStatus();
		}
		try {
			List<DBObject> pipeline = new ArrayList<DBObject>();
			// 记录过滤条件
			String matchStr = null;
			String groupStr = null;
			if(CommonTools.notNullAndEmpty(clinicId)){
				/*matchStr = "{$match:{delFlag:\"" + delFlag + "\",isRead: \"" + isRead 
						+ "\",receiverId: \"" + receiverId + "\",acceptRoleId: \"" + acceptRoleId + "\",channel: \"" + channel 
						+ "\",clinicId: \"" + clinicId + "\",status: \"" + status +"\"}}";*/
				matchStr = "{$match:{delFlag:\"" + delFlag + "\",isRead: \"" + isRead 
						+ "\",receiverId: \"" + receiverId + "\",acceptRoleId: \"" + acceptRoleId + "\",channel: \"" + channel 
						 + "\",status: \"" + status +"\",$or:[{clinicId:\"" + clinicId +"\"},{clinicId:\"" + "" + "\"},{clinicId:null}]" + "}}";
			}else{
				matchStr = "{$match:{delFlag:\"" + delFlag + "\",isRead: \"" + isRead 
						+ "\",receiverId: \"" + receiverId + "\",acceptRoleId: \"" + acceptRoleId + "\",channel: \"" + channel 
						+ "\",status: \"" + status +"\"}}";
			}
			DBObject match = (DBObject) JSON.parse(matchStr);
			pipeline.add(match);
			// 分组条件
			groupStr = "{$group:{_id: {'messageTypeId':'$messageTypeId','receiverId':'$receiverId'}, countNum:{$sum:1}}}";
			DBObject group = (DBObject) JSON.parse(groupStr);
			pipeline.add(group);
	
			// 获取数据
			DBCollection conn = mongoTemplate.getCollection("messageBO");
			AggregationOutput output = conn.aggregate(pipeline);
			for (Iterator<DBObject> it = output.results().iterator(); it.hasNext();) {
				BasicDBObject dbo = (BasicDBObject) it.next();
				BasicDBObject keyValus = (BasicDBObject) dbo.get("_id");
				VOMessage voMessage = new VOMessage();
				String messageTypeId = keyValus.getString("messageTypeId");
				String unReadTotal = dbo.getString("countNum");
				if(CommonTools.nullOrEmpty(unReadTotal)){
					unReadTotal = "0";
				}
				voMessage.setReceiverId(receiverId);
				voMessage.setMessageTypeId(messageTypeId);
				voMessage.setAcceptRoleId(acceptRoleId);
				voMessage.setUnReadTotal(Integer.parseInt(unReadTotal));
				result.add(voMessage);
			}
		} catch (Exception e) {
			logger.error("MessageBORepository->getCountByType:" + e.toString());
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 查询消息类别代码
	 * @param messageBo
	 * @return
	 */
	public List<String> getMessageTypes(MessageBO messageBo) {
		List<String> result = new ArrayList<String>();
		String receiverId = messageBo.getReceiverId();
		String acceptRoleId = messageBo.getAcceptRoleId();
		String channel = messageBo.getChannel();
		String clinicId = messageBo.getClinicId();
		try {
			if (messageBo != null) {
				Query query = new Query();
				if (StringUtils.isNotBlank(acceptRoleId)) {
					query.addCriteria(Criteria.where("acceptRoleId").in(acceptRoleId.split(",")));
				}
				if (StringUtils.isNotBlank(receiverId)) {
					query.addCriteria(Criteria.where("receiverId").is(receiverId));
				}
				if (StringUtils.isNotBlank(channel)) {
					query.addCriteria(Criteria.where("channel").is(channel));
				}
				if (StringUtils.isNotBlank(clinicId)) {
					//query.addCriteria(Criteria.where("clinicId").is(clinicId));
					Criteria criteriaClinicId = new Criteria();  
					criteriaClinicId.orOperator(Criteria.where("clinicId").is(clinicId),Criteria.where("clinicId").is(null),Criteria.where("clinicId").is(""));  
					query.addCriteria(criteriaClinicId);
				}
				// 获取数据
				DBCollection conn = mongoTemplate.getCollection("messageBO");
				result = conn.distinct("messageTypeId", query.getQueryObject());
			}
		} catch (Exception e) {
			logger.error("MessageBORepository->getMessageTypes:" + e.toString());
			e.printStackTrace();
		}
		return result;
	}
}
