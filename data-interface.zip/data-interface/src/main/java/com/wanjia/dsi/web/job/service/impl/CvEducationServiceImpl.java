package com.wanjia.dsi.web.job.service.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvEducationMapper;
import com.wanjia.dsi.web.job.model.TalentCvEducation;
import com.wanjia.dsi.web.job.model.TalentCvEducationExample;
import com.wanjia.dsi.web.job.service.CvEducationService;
import com.wanjia.dsi.web.job.service.CvService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CvEducationServiceImpl implements CvEducationService {

	@Autowired
	private TalentCvEducationMapper mapper;
	
	@Autowired
	private CvService cvService;

	@Override
	public JsonResponse<List<TalentCvEducation>> getCvEducationList(String cvId,String eduId) {
		// 返回值
		JsonResponse<List<TalentCvEducation>> jr = new JsonResponse<List<TalentCvEducation>>();
		
		// 查询数据
		TalentCvEducationExample example = new TalentCvEducationExample();
		TalentCvEducationExample.Criteria criteria = example.createCriteria();
		if(StringUtils.isNotEmpty(cvId)){
			criteria.andCvIdEqualTo(cvId);
		}
		if(StringUtils.isNotEmpty(eduId)){
			criteria.andIdEqualTo(eduId);
		}
		criteria.andDelFlagEqualTo("0");
		example.setOrderByClause("SCHOOL_START_TIME DESC");
		List<TalentCvEducation> exps = mapper.selectByExample(example);
		jr.setResult(exps);
		jr.setStatus(Status.SUCCESS);
		return jr;
	}

	@Override
	public JsonResponse<Void> modifyCvEducation(TalentCvEducation cvEducation) {
		// 返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		cvEducation.setModifyDate(new Date());
		mapper.updateByPrimaryKeySelective(cvEducation);
		
		// 更新简历状态
		cvService.modifyCvStatus(cvEducation.getCvId());
		jr.setStatus(Status.SUCCESS);
		return jr;
	}

	@Override
	public JsonResponse<Void> addCvEducation(TalentCvEducation cvEducation) {
		// 返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		cvEducation.setId(UUID.randomUUID().toString());
		cvEducation.setDelFlag("0");
		cvEducation.setCreateDate(new Date());
		cvEducation.setCreateUser(cvEducation.getCvId());
		mapper.insertSelective(cvEducation);
		
		// 更新简历状态
		cvService.modifyCvStatus(cvEducation.getCvId());
		jr.setStatus(Status.SUCCESS);
		return jr;
	}
}
