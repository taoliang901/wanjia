package com.wanjia.dsi.product.service.impl;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.MailUtils;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.common.utils.ValidateUtils;
import com.wanjia.dsi.product.dao.mapper.PrdBookingMapper;
import com.wanjia.dsi.product.dao.mapper.PrdBookingVisitMapper;
import com.wanjia.dsi.product.dao.mapper.PrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdBooking2Mapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdBookingMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdBookingVisitMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdClinicMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdOrderDetailServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdServiceMapper;
import com.wanjia.dsi.product.model.PrdBooking;
import com.wanjia.dsi.product.model.PrdBookingVisit;
import com.wanjia.dsi.product.model.PrdBookingVisitExample;
import com.wanjia.dsi.product.model.VOPrdOrderDetailService;
import com.wanjia.dsi.product.service.CouponService;
import com.wanjia.dsi.product.vo.VOPrdBooking;
import com.wanjia.dsi.product.vo.VOPrdClinic;
import com.wanjia.dsi.product.vo.VOPrdKucun;
import com.wanjia.dsi.product.vo.VOPrdService;
import com.wanjia.dsi.product.vo.VOPrdValid;
import com.wanjia.dsi.web.clinic.dao.mapper.ClinicRegisterVOMapper;
import com.wanjia.dsi.web.clinic.model.ClinicInfo;
import com.wanjia.dsi.web.hyPerson.dao.mapper.VOClcInfoApprovalMapper;
import com.wanjia.dsi.web.hyPerson.model.ClinicRegisterVO;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;
import com.wanjia.dsi.web.hyPerson.vo.VOClcInfoApproval;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CouponServiceImpl extends BaseServiceImpl implements CouponService {

	protected Logger logger = Logger.getLogger(CouponServiceImpl.class);

	@Resource
	private VOPrdBooking2Mapper vOPrdBooking2Mapper;
	
	@Resource
	private PrdKucunMapper prdKucunMapper;

	@Resource
	private VOPrdKucunMapper vOPrdKucunMapper;

	@Resource
	private PrdBookingMapper prdBookingMapper;

	@Resource
	private VOPrdBookingMapper vOPrdBookingMapper;

	@Resource
	private PrdBookingVisitMapper prdBookingVisitMapper;

	@Resource
	private VOPrdClinicMapper vOPrdClinicMapper;
	
	@Resource
    private VOPrdBookingVisitMapper vOPrdBookingVisitMapper;
	
	@Resource
    private ClinicRegisterVOMapper clinicRegisterVOMapper;
	
	@Resource
	private VOPrdServiceMapper vOPrdServiceMapper;
	
	@Resource
	private VOPrdOrderDetailServiceMapper vOPrdOrderDetailServiceMapper;
	
	@Resource
	private VOClcInfoApprovalMapper vOClcInfoApprovalMapper;
	
	@Autowired
    private MailUtils mailUtils;
	
	@Value("#{hyCasConfig['mail_address']}")
	private String mail_address;
	 
	/** 体验券有效期为2年 */
	public static final int ENABLED_YEAR = 2;

	@Override
	public JsonResponse<VOPrdBooking> getBookingById(String id) {
		if(StringUtils.isBlank(id)) {
			throw new ServiceException(null, "【预约ID】不能为空！");
		}
		VOPrdBooking order = vOPrdBookingMapper.selectByPrimaryKey(id);

		JsonResponse<VOPrdBooking> res = new JsonResponse<VOPrdBooking>();
		res.setStatus(Status.SUCCESS);
		res.setResult(order);
		return res;
	}

	@Override
	public JsonResponse<VOPrdKucun> checkCardNoPwd(String cardNo, String cardPassword, String prdKucunId, String flag) {

		JsonResponse<VOPrdKucun> res = new JsonResponse<VOPrdKucun>();
		// 1、校验卡号、密码 or 卡ID
		VOPrdKucun kucun = null;
		if(StringUtils.isBlank(flag)) {
			throw new ServiceException(null, "【新增查看标志位】不能为空！");
		}
		if("1".equals(flag)) {
			if(StringUtils.isBlank(cardNo)) {
				throw new ServiceException(null, "【卡号】不能为空！");
			}
			if(StringUtils.isBlank(cardPassword)) {
				throw new ServiceException(null, "【密码】不能为空！");
			}
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("delFlag", "0");
			param.put("cardNo", cardNo);
			try {
				param.put("cardPasswordMd5", CommonTools.md5(cardPassword));
			} catch (NoSuchAlgorithmException e) {
				throw new ServiceException(null, "对密码MD5加密异常！");
			}
			List<VOPrdKucun> couponList = vOPrdKucunMapper.selectByMap(param);
			if(couponList==null || couponList.size()==0) {
				throw new ServiceException(null, "信息有误");
			}
			if(couponList.size() > 1) {
				throw new ServiceException(null, "根据【卡号或密码】查到多张卡，请与系统管理员系统！");
			}
			kucun = couponList.get(0);
		} else {
			if(StringUtils.isBlank(prdKucunId)) {
				throw new ServiceException(null, "【卡库存Id】不能为空！");
			}
			kucun = vOPrdKucunMapper.selectByPrimaryKey(prdKucunId);
			if(kucun == null) {
				throw new ServiceException(null, "信息有误");
			}
		}
		// 2、新增编辑预约时，需判断卡是否有效（最初预约记录后推N年，或固定写死有效期）
		//    新增编辑预约时，需判断卡对应产品是否上线
		// 卡是否有效
		Date end = kucun.getValidEndDate();
		Date now = new Date();
		if(end != null) {
			String endStr = CommonTools.dateToString(end, "yyyy-MM-dd");
			String nowStr = CommonTools.dateToString(now, "yyyy-MM-dd");
			if(nowStr.compareTo(endStr) > 0) {
				throw new ServiceException(null, "卡已过期");
			}
		}
		// 卡对应产品是否上线（先冗余表，再产品表）
		if(kucun.getCouponDetailStatus() != null) {
			if(!"0".equals(kucun.getCouponDetailStatus())) {
				throw new ServiceException(null, "该产品【"+kucun.getCouponName()+"】未上线");
			}
		} else {
			if(!"0".equals(kucun.getCouponStatus())) {
				throw new ServiceException(null, "该产品【"+kucun.getCouponName()+"】未上线");
			}
		}

		res.setStatus(Status.SUCCESS);
		res.setResult(kucun);
		return res;
	}

	@Override
	public JsonResponse<VOPrdKucun> fillData(VOPrdKucun kucun,
			String flag, String bookingId) {

		JsonResponse<VOPrdKucun> res = new JsonResponse<VOPrdKucun>();
		if(kucun == null) {
			throw new ServiceException(null, "【detail】不能为空！");
		}
		if(StringUtils.isBlank(flag)) {
			throw new ServiceException(null, "【新增标志位】不能为空！");
		}
		if(("2".equals(flag) || "3".equals(flag)) && StringUtils.isBlank(bookingId)) {
			throw new ServiceException(null, "编辑时【预约单号】不能为空！");
		}
		// 1、查询该产品对应的可选的【诊所总账户、城市、诊所】列表
		Map<String, Object> p2 = new HashMap<String, Object>();
		p2.put("delFlag", "0");
		p2.put("couponId", kucun.getCouponId());
		p2.put("orderByClause", "CONVERT(parentAccountName USING GBK) ASC, CONVERT(city USING GBK) ASC, CONVERT(district USING GBK) ASC, CONVERT(clinicName USING GBK) ASC, id");
		List<VOPrdClinic> clinicList = vOPrdClinicMapper.selectByMap(p2);
		List<VOPrdClinic> cityList = new ArrayList<VOPrdClinic>();
		List<VOPrdClinic> districtList = new ArrayList<VOPrdClinic>();
		List<VOPrdClinic> parentAccountList = new ArrayList<VOPrdClinic>();
		if(clinicList != null) {
			String parentAccount_pre = "";	//parentAccountId
			String cityId_pre = "";			//parentAccountId_cityCode
			String districtId_pre = "";		//parentAccountId_cityCode_districtCode
			for(int i=0; i<clinicList.size(); i++) {
				VOPrdClinic clinicVo = clinicList.get(i);
				if(!parentAccount_pre.equals(clinicVo.getParentAccountId())) {
					parentAccountList.add(clinicVo);
					parentAccount_pre = clinicVo.getParentAccountId();
				}
				if(!cityId_pre.equals(clinicVo.getParentAccountId() + "_" + clinicVo.getCityCode())) {
					cityList.add(clinicVo);
					cityId_pre = clinicVo.getParentAccountId() + "_" + clinicVo.getCityCode();
				}
				if(!districtId_pre.equals(clinicVo.getParentAccountId() + "_" + clinicVo.getCityCode() + "_" + clinicVo.getDistrictCode())) {
					districtList.add(clinicVo);
					districtId_pre = clinicVo.getParentAccountId() + "_" + clinicVo.getCityCode() + "_" + clinicVo.getDistrictCode();
				}
			}
		}
		//kucun.setParentAccountList(parentAccountList);
		//kucun.setCityList(cityList);
		//kucun.setDistrictList(districtList);
		//kucun.setClinicList(clinicList);
		
		// 2、填充【服务项目】列表
		//    A、卡号密码预约&& 第一次
		if(StringUtils.isBlank(kucun.getBuyerUserId())) {
			Map<String, Object> p3 = new HashMap<String, Object>();
			p3.put("delFlag", "0");
			p3.put("prdId", kucun.getCouponId());
			List<VOPrdService> prdServiceList = vOPrdServiceMapper.selectByMap(p3);
			//kucun.setPrdServiceList(prdServiceList);
		}
		//    B、其它：验证码预约 || （卡号密码预约 && 非第一次）：根据卡ID获取唯一【订单明细】，对应的服务项目列表
		//    后期显示的产品数据和对应的服务项目数据为，用户第一次预约时的产品数据和对应的服务项目数据。
		else {
			Map<String, Object> p3 = new HashMap<String, Object>();
			p3.put("delFlag", "0");
			p3.put("kucunId", kucun.getId());
			List<VOPrdOrderDetailService> prdOrderServiceList = vOPrdOrderDetailServiceMapper.selectByMap(p3);
			if(prdOrderServiceList!=null && prdOrderServiceList.size()>0) {
				List<VOPrdService> prdServiceList = new ArrayList<VOPrdService>();
				String orderDetailId = prdOrderServiceList.get(0).getOrderDetailId();	// 唯一订单明细
				for(int i=0; i<prdOrderServiceList.size(); i++) {
					VOPrdOrderDetailService item = prdOrderServiceList.get(i);
					if(!orderDetailId.equals(item.getOrderDetailId())) {
						throw new ServiceException(null, "某卡ID对应了多个订单明细："+item.getKucunId());
					}
					VOPrdService p = new VOPrdService();
					p.setServiceId(item.getServiceId());
					p.setServiceName(item.getServiceName());
					p.setServiceCount(item.getServiceCount());
					p.setIsUnlimite(item.getIsUnlimite());
					prdServiceList.add(p);
				}
				//kucun.setPrdServiceList(prdServiceList);
			}
		}

		res.setStatus(Status.SUCCESS);
		res.setResult(kucun);
		return res;
	}

	@Override
	public JsonResponse<PageInfo<VOPrdBooking>> findBookingList(String userId,String pageNo,String pageSize) {
		// 设置返回参数
		JsonResponse<PageInfo<VOPrdBooking>> result = new JsonResponse<PageInfo<VOPrdBooking>>();
		
		// 查询 TODO 将被废弃
//		try {
//			PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));// 设置分页页号和页码
//			Map<String, Object> param = new HashMap<String, Object>();
//			param.put("memberId", userId);
//			// 查询已预约和已就诊的预约记录(不要已取消的)
//			List<String> statusList = new ArrayList<String>();
//			statusList.add("0");
//			statusList.add("1");
//			param.put("statusList", statusList);
//			List<VOPrdBooking> list = vOPrdBooking2Mapper.getCouponOrderList(param);
//			PageInfo<VOPrdBooking> page = new PageInfo<VOPrdBooking>(list);// 获得分页信息
//			result.setResult(page);
//
//		} catch (Exception e) {
//			logger.error("根据Id查询产品预约信息失败：", e);
//			throw new ServiceException(ErrorType.SystemBusy.getCode(), ErrorType.SystemBusy.getDesc(), e);
//		}

		return result;
	}

	@Override
	public JsonResponse<String> findExpiryDate(String userId) {
		// 返回结果
		JsonResponse<String> result = new JsonResponse<String>();
		VOPrdValid validVO = vOPrdBooking2Mapper.findExpiryDate(userId);
		
		if(validVO==null)
		{
			// 结果返回
			result.setStatus(Status.SUCCESS);
			result.setResult(null);
			return result;
		}
		
		// 得到预约开始时间
		String beginDate = CommonTools.dateToString(validVO.getValidBeginDate(), "yyyy.MM.dd");
		
		// 得到预约结束时间
		String endDate=CommonTools.dateToString(validVO.getValidEndDate(), "yyyy.MM.dd");
		
		// 结果返回
		result.setStatus(Status.SUCCESS);
		result.setResult(beginDate + "-" + endDate);
		return result;
	}

	@Override
	public JsonResponse<VOClcInfoApproval> getClinicByID(String clinicId) {
		JsonResponse<VOClcInfoApproval> result = new JsonResponse<VOClcInfoApproval>();
		VOClcInfoApproval clinic = vOClcInfoApprovalMapper.selectByPrimaryKey(clinicId);
		result.setStatus(Status.SUCCESS);
		result.setResult(clinic);
		return result;
	}

	@Override
	public JsonResponse<Void> checkDataBeforeBooking(VOPrdBooking order, String userId) {

		JsonResponse<Void> result = new JsonResponse<Void>();

		// 1、检验参数有效性
        if(StringUtils.isBlank(order.getPrdKucunId())) {
			throw new ServiceException(null, "产品库存ID不能为空!");
        }
        if(StringUtils.isBlank(order.getClinicId())) {
			throw new ServiceException(null, "诊所ID不能为空!");
        }
        if(StringUtils.isBlank(order.getTreatDate())) {
			throw new ServiceException(null, "就诊时间不可为空!");
        }
        if(CollectionUtils.isEmpty(order.getVisitList())) {
			throw new ServiceException(null, "就诊人列表不可为空!");
        }
        if(StringUtils.isBlank(order.getCouponId())) {
			throw new ServiceException(null, "产品ID不能为空!");
        }
        if(StringUtils.isBlank(order.getCouponName())) {
			throw new ServiceException(null, "产品名称不能为空!");
        }
        if(StringUtils.isBlank(order.getUseFrequence())) {
			throw new ServiceException(null, "是否一次性使用不能为空!");
        }
		if(!"0".equals(order.getUseFrequence())){
	        if(StringUtils.isBlank(order.getPrdServiceId())) {
				throw new ServiceException(null, "服务项目ID不能为空!");
	        }
	        if(StringUtils.isBlank(order.getServiceName())) {
				throw new ServiceException(null, "服务项目名称不能为空!");
	        }
		}
        if(order.getVisitList().size() != 1)	// 08.11版本暂时只能选择一个就诊人
        {
			throw new ServiceException(null, "暂时只能预约1个就诊人！");
        }
        for(int i=0; i<order.getVisitList().size(); i++) {
        	HyTreatmentPerson item = order.getVisitList().get(i);
    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitName(), 48)) {
    			throw new ServiceException(null, "【就诊人名称】超过"+48+"个字节<br/>");
    		}
    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitIdCardTypeCode(), 10)) {
    			throw new ServiceException(null, "【证件类型】超过"+10+"个字节<br/>");
    		}
    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitIdCardCode(), 48)) {
    			throw new ServiceException(null, "【证件号码】超过"+48+"个字节<br/>");
    		}
    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitMobile(), 48)) {
    			throw new ServiceException(null, "【手机号】超过"+32+"个字节<br/>");
    		}
        }
        
        
        
        
        
        
        
        return result;
	}

//	@Override
//	public JsonResponse<Void> saveBooking(VOPrdBooking order,
//			String userId,String userName) {
//
//		// 返回结果
//		JsonResponse<Void> result = new JsonResponse<Void>();
//				
//		// 检验参数有效性
//		// 体验劵库存ID不能为空
//        if(StringUtils.isEmpty(order.getPrdKucunId()))
//        {
//			throw new ServiceException(null, "体验劵库存ID不能为空!");
//        }
//        // 诊所ID不能为空
//        if(StringUtils.isEmpty(order.getClinicId()))
//        {
//			throw new ServiceException(null, "诊所ID不能为空!");
//        }
//        // 就诊时间不可为空
//        if(StringUtils.isEmpty(order.getTreatDate()))
//        {
//			throw new ServiceException(null, "就诊时间不可为空!");
//        }
//        // 就诊人列表不可为空
//        if(CollectionUtils.isEmpty(order.getVisitList()))
//        {
//			throw new ServiceException(null, "就诊人列表不可为空!");
//        }
//        // 08.11版本暂时只能选择一个就诊人
//        if(order.getVisitList().size() != 1)
//        {
//			throw new ServiceException(null, "暂时只能预约1个就诊人！");
//        }
//        for(int i=0; i<order.getVisitList().size(); i++) {
//        	HyTreatmentPerson item = order.getVisitList().get(i);
//    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitName(), 48)) {
//    			throw new ServiceException(null, "【就诊人名称】超过"+48+"个字节<br/>");
//    		}
//    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitIdCardTypeCode(), 10)) {
//    			throw new ServiceException(null, "【证件类型】超过"+10+"个字节<br/>");
//    		}
//    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitIdCardCode(), 48)) {
//    			throw new ServiceException(null, "【证件号码】超过"+48+"个字节<br/>");
//    		}
//    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitMobile(), 48)) {
//    			throw new ServiceException(null, "【手机号】超过"+32+"个字节<br/>");
//    		}
//        }
//
//        
//        // 若该卡存在已就诊的记录,则新预约订单的诊所需与旧订单相同
//		Map<String, Object> param = new HashMap<String, Object>();
//		param.put("delFlag", "0");
//		param.put("prdKucunId", order.getPrdKucunId());
//		param.put("status", "1");
//		List<VOPrdBooking> couponOrders = vOPrdBookingMapper.selectByMap(param);
//		if(CollectionUtils.isNotEmpty(couponOrders))
//		{
//			VOPrdBooking couponOrder = couponOrders.get(0);
//			if(!couponOrder.getClinicId().equals(order.getClinicId()))
//			{
//				throw new ServiceException(null, "不可更换就诊诊所!");
//			}
//		}
//			
//		// 判断是新增还是编辑订单
//		if(StringUtils.isBlank(order.getOrderId()))
//		{	
//			// 新增订单
//			try {
//				// 同一天,同一就诊人不可预约多次
//				// 获取当天,此卡号预约过的就诊人列表
//				VOPrdBooking orderVo = new VOPrdBooking();
//				orderVo.setPrdKucunId(order.getPrdKucunId());
//				orderVo.setTreatDate(order.getTreatDate());
//				List<PrdBookingVisit> visits = vOPrdBookingVisitMapper.selectByOrder(orderVo);
//				// 获取本次预约的就诊人列表
//				List<HyTreatmentPerson> visitList = order.getVisitList();
//				for(HyTreatmentPerson item:visitList)
//				{
//					for (PrdBookingVisit item1 : visits) {
//						if(item.getVisitId()==item1.getVisitId())
//						{
//							throw new ServiceException(null, "【"+item.getVisitName()+"】该时间已有预约!");
//						}
//					}
//				}
//				
//				// 插入预约订单表和预约订单就诊人表
//				insertOrder(order, userId);
//			} catch (Exception e) {
//				throw new ServiceException(null, "插入产品预约表或者就诊人表失败!", e);
//			}
//		}
//		else{
//			// 编辑订单
//			// 取消原有订单
//			PrdBooking updateOrder = new PrdBooking();
//			updateOrder.setOrderId(order.getOrderId());
//			updateOrder.setStatus("2");
//			updateOrder.setModifyDate(new Date());
//			// 会员取消
//			updateOrder.setModifyUserFlag("C");
//			updateOrder.setModifyUser(userName);
//			try {
//				prdBookingMapper.updateByPrimaryKeySelective(updateOrder);
//			} catch (Exception e) {
//				throw new ServiceException(null, "更新产品预约订单表失败!", e);
//			}
//			
//			// 插入预约订单表和预约订单就诊人表
//			try {
//				insertOrder(order, userId);
//			} catch (Exception e) {
//				throw new ServiceException(null, "插入产品预约表或者就诊人表失败!", e);
//			}
//		}
//        
//		// 如果卡为首次预约,插入卡的有效时间字段
//		PrdKucun couponDetail = prdKucunMapper.selectByPrimaryKey(order.getPrdKucunId());
//		couponDetail.setValidBeginDate(CommonTools.stringToDate(order.getTreatDate(), "yyyy-MM-dd"));
//		couponDetail.setValidEndDate(CommonTools.markDate(CommonTools.stringToDate(order.getTreatDate(), "yyyy-MM-dd"), Calendar.YEAR, 2));
//		prdKucunMapper.updateByPrimaryKeySelective(couponDetail);
//		
//		result.setStatus(Status.SUCCESS);
//		return result;
//	}
//
//	// 插入预约订单表和预约订单就诊人表
//	private void insertOrder(VOPrdBooking order, String userId) {
//		String bookingId = CommonTools.generateUUID();
//		order.setOrderId(bookingId);
//		order.setMemberId(Long.parseLong(userId));
//		order.setOrderTime(new Date());
//		order.setStatus("0");
//		order.setCreateUser(userId);
//		order.setCreateDate(new Date());
//		order.setDelFlag("0");
//		prdBookingMapper.insertSelective(order);
//		
//		// 插入预约就诊人表
//		List<HyTreatmentPerson> visitList = order.getVisitList();
//		for(HyTreatmentPerson item:visitList)
//		{
//			PrdBookingVisit visit = new PrdBookingVisit();
//			visit.setOrderVisitId(CommonTools.generateUUID());
//			visit.setOrderId(bookingId);
//			visit.setVisitId(item.getVisitId());
//			visit.setVisitName(item.getVisitName());
//			visit.setVisitIdCardTypeCode(item.getVisitIdCardTypeCode());
//			visit.setVisitIdCardCode(item.getVisitIdCardCode());
//			visit.setVisitMobile(item.getVisitMobile());
//			visit.setCreateUser(userId);
//			visit.setCreateDate(new Date());
//			visit.setDelFlag("0");
//			prdBookingVisitMapper.insertSelective(visit);
//		}
//	}

	@Override
	public JsonResponse<Void> hyCouponSendMail() {
		// 返回结果
		JsonResponse<Void> result = new JsonResponse<Void>();

		// 查询存在未发送邮件订单的所有诊所
		List<String> statusList = new ArrayList<String>();
		statusList.add("0");
		statusList.add("2");
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("statusList", statusList);
		param.put("mailStatus", "0");
		List<VOPrdClinic> clinics = vOPrdBooking2Mapper.findMailClinics(param);
		
		// 遍历诊所发送邮件
		for (VOPrdClinic item : clinics) {
			// 根据诊所ID查询总账户邮箱和总账户名称
			ClinicInfo clinicInfo = new ClinicInfo();
			clinicInfo.setId(item.getClinicId());
			List<ClinicRegisterVO> clinicRegisters = clinicRegisterVOMapper
					.getClinicRegisterList(clinicInfo);
			if (CollectionUtils.isEmpty(clinicRegisters)) {
				logger.error("产品预约发送邮件时,无法查到对应的诊所注册信息!" +item.getClinicId());
				mailUtils.sendMail(mail_address, "产品预约异常",
						"产品预约发送邮件时,无法查到对应的诊所注册信息!");
				continue;
			}
			if(StringUtils.isBlank(clinicRegisters.get(0).getEmail()))
			{
				logger.error("产品预约发送邮件时,无法查到对应的诊所注册邮箱信息!" +item.getClinicId());
				mailUtils.sendMail(mail_address, "产品预约异常",
						"产品预约发送邮件时,无法查到对应的诊所注册邮箱信息!");
				continue;
			}
			
			// 查询已预约状态的订单,发送邮件
			List<String> statusListFor1 = new ArrayList<String>();
			statusListFor1.add("0");
			Map<String, Object> paramFor1 = new HashMap<String, Object>();
			paramFor1.put("statusList", statusListFor1);
			paramFor1.put("mailStatus", "0");
			paramFor1.put("clinicId", item.getClinicId());
			List<VOPrdBooking> couponListFor1 = vOPrdBooking2Mapper.getCouponOrderList(paramFor1);
			
			// 查询已取消状态的订单,发送邮件
			List<String> statusListFor2 = new ArrayList<String>();
			statusListFor2.add("2");
			Map<String, Object> paramFor2 = new HashMap<String, Object>();
			paramFor2.put("statusList", statusListFor2);
			paramFor2.put("mailStatus", "0");
			paramFor2.put("clinicId", item.getClinicId());
			List<VOPrdBooking> couponListFor2 = vOPrdBooking2Mapper.getCouponOrderList(paramFor2);
			
			// 目标邮件地址/邮件标题/邮件内容
			if(CollectionUtils.isNotEmpty(couponListFor1))
			{
				boolean mailResFor1 = mailUtils.sendMail(clinicRegisters.get(0).getEmail(), "平安万家", getHtml(couponListFor1,null,clinicRegisters.get(0).getEnterpriseFullName()).toString());
				// 发送成功,遍历订单,更新邮件发送状态（可优化,批量更新）
				if(mailResFor1)
				{
					for(VOPrdBooking orderVo : couponListFor1)
					{
						PrdBooking updateOrder = new PrdBooking();
						updateOrder.setOrderId(orderVo.getOrderId());
						updateOrder.setMailStatus("1");
						prdBookingMapper.updateByPrimaryKeySelective(updateOrder);
					}
				}
				else{
					logger.error("邮件发送失败!" + item.getClinicId());
				}
			}
			
			if(CollectionUtils.isNotEmpty(couponListFor2))
			{
				boolean mailResFor2 = mailUtils.sendMail(clinicRegisters.get(0).getEmail(), "平安万家", getHtml(null,couponListFor2,clinicRegisters.get(0).getEnterpriseFullName()).toString());
				if(mailResFor2)
				{
					for(VOPrdBooking orderVo : couponListFor2)
					{
						PrdBooking updateOrder = new PrdBooking();
						updateOrder.setOrderId(orderVo.getOrderId());
						updateOrder.setMailStatus("1");
						prdBookingMapper.updateByPrimaryKeySelective(updateOrder);
					}
				}
				else{
					logger.error("邮件发送失败!" + item.getClinicId());
				}
			}
		}
		result.setStatus(Status.SUCCESS);
		return result;
	}
	
	// 获取邮件发送HTML
	private StringBuffer getHtml(List<VOPrdBooking> orderListFor1,List<VOPrdBooking> orderListFor2,String fullName) {	
		StringBuffer html = new StringBuffer();
		html.append(
		"<!DOCTYPE html>"+
		"<html style='overflow-y:scroll;'>"+
		"<head>"+
		"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
		"<title>万家诊所</title>"+
		"<base target='_blank' />"+
		"<meta name='Keywords' content='关键字' />"+
		"<meta name='Description' content='描述文字' />"+
		"<style>"+
		"html {overflow-y:scroll;}"+
		"body {margin:0; padding:0; font:14px,Arial,sans-serif;background: #f8f8f8;color:#333;/*overflow:hidden;*/}"+
		"div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,form,fieldset,input,textarea,blockquote,p{padding:0; margin:0;}"+
		"table{border-collapse:collapse;width:100%;}"+
		"table,td,tr,th{font-size:12px;}"+
		".mainbody{width:1200px;margin:0 auto;}"+
		"body{background: #f8f8f8;font-size: 14px;font-family: arial,microsoft yahei,verdana, simsun;}"+
		".email1{width: 935px;margin-bottom: 90px;}"+
		".email1 table{width: 933px;}"+
		".emailbox {padding-top: 56px;padding: 56px 40px  0 80px;}"+
		".emailbox p{line-height: 26px;}"+
		".emailbox .tcon{text-indent: 2em;}"+
		".emailbox table{margin-top: 25px;margin-bottom: 20px;}"+
		".emailbox table td,.emailbox table th{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;}"+
		".emailbox table td{background: #fff;}"+
		".emailbox a{color: #1a70cb;text-decoration: underline;}"+
		"</style>"+
		"</head>"+
		"<body>"+ 
		  "<div class='warpper'>"+
		   "<div class='mainbody clr'>");
		
	   	  if(CollectionUtils.isNotEmpty(orderListFor1))
	   	  {
	   		html.append(
		     "<div class='emailbox email1'>"+
		          "<p>尊敬的"+fullName+"：</p>"+
		          "<p class='tcon' >截至目前，共有"+orderListFor1.size()+"位“家庭口腔养护尊享套餐卡”客户通过万家官网预约你们的服务，详细名单如下，请优先联系安排，谢谢！</p>"+
		          "<table style='border-collapse:collapse;width:100%;margin-top: 25px;margin-bottom: 20px;'>"+
		              "<tr style='font-size:12px;'>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>预约日期</th>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>就诊人,联系方式</th>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>拟就诊时间</th>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>拟前往门店</th>"+
		              "</tr>");
	   		 
		              for(VOPrdBooking item : orderListFor1)
		              {
		            	// 根据订单ID查询就诊人列表
		  				PrdBookingVisitExample example = new PrdBookingVisitExample();
		  				PrdBookingVisitExample.Criteria criteria = example.createCriteria();
		  				criteria.andOrderIdEqualTo(item.getOrderId());
		  				List<PrdBookingVisit> persons = prdBookingVisitMapper.selectByExample(example);
		            	  html.append(
		            	  "<tr style='font-size:12px;'>"+
				              "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>"+CommonTools.dateToString(item.getOrderTime(), "yyyy.MM.dd")+"</td>"+
			                  "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>");
							  for (PrdBookingVisit person : persons) {
								  html.append(person.getVisitName() + "," + person.getVisitMobile() + "<br>");
							  }
				              html.append("</td>"+
			                  "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>"+item.getTreatDate()+" "+item.getTreatTime()+"</td>"+
			                  "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>"+item.getClinicName()+"</td>"+
			              "</tr>");
		              }
     
		              html.append("</table>"+
		          "<p>您可登陆万家官网－诊所中心（<a href='http://clinic.pinganwj.com'>http://clinic.pinganwj.com</a>）确认客户就诊状态。</p>"+
		     "</div>");
	   	  }
	   	  
	   	  if(CollectionUtils.isNotEmpty(orderListFor2))
	   	  {
	   		html.append("<div class='emailbox '>"+
		          "<p>尊敬的"+fullName+"：</p>"+
		          "<p class='tcon' >截至目前，共有"+orderListFor2.size()+"位“家庭口腔养护尊享套餐卡”客户取消预约，详细名单如下。</p>"+
		          "<table style='border-collapse:collapse;width:100%;margin-top: 25px;margin-bottom: 20px;'>"+
		              "<tr style='font-size:12px;'>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>预约日期</th>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>就诊人,联系方式</th>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>拟就诊时间</th>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>拟前往门店</th>"+
		                  "<th style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;font-size:12px;'>取消时间</th>"+
		              "</tr>");
		              for(VOPrdBooking item : orderListFor2)
		              {
		            	  // 根据订单ID查询就诊人列表
			  			  PrdBookingVisitExample example = new PrdBookingVisitExample();
			  			  PrdBookingVisitExample.Criteria criteria = example.createCriteria();
			  			  criteria.andOrderIdEqualTo(item.getOrderId());
			  			  List<PrdBookingVisit> persons = prdBookingVisitMapper.selectByExample(example);
		            	  html.append("<tr style='font-size:12px;'>"+
			                  "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>"+CommonTools.dateToString(item.getOrderTime(), "yyyy.MM.dd")+"</td>"+
			                  "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>");
							   for (PrdBookingVisit person : persons) {
								   html.append(person.getVisitName() + "," + person.getVisitMobile() + "<br>");
							   }
				               html.append("</td>"+
			                  "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>"+item.getTreatDate()+" "+item.getTreatTime()+"</td>"+
			                  "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>"+item.getClinicName()+"</td>"+
			                  "<td style='{height: 38px;line-height: 30px;color: #666;text-align: center;border:1px #ddd solid;background: #fff;font-size:12px;'>"+CommonTools.dateToString(item.getModifyDate(),"yyyy.MM.dd HH:mm")+"</td>"+
			              "</tr>");
		              }
		              html.append("</table>"+
		          "<p>您可登陆万家官网－诊所中心（<a href='http://clinic.pinganwj.com'>http://clinic.pinganwj.com</a>）确认客户就诊状态。</p>"+
		     "</div>");
	   	  }
	   	  
	   	html.append("</div>"+"</div>"+"</body>"+"</html>");
		return html;
	}
}
