package com.wanjia.dsi.common.utils;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wanjia.common.redis.cache.JedisCache;
import com.wanjia.dsi.common.constant.Consts;

import redis.clients.jedis.JedisPubSub;

@Component
public class CommonJedis {
	@Autowired
	private JedisCache jedisCache;

	@Value("#{jedisConfig['redisSwitch']}")
	private String redisSwitch;

	@Value("#{serverConstants['redisPrefix']}")
	private String redisPrefix;

	@Value("#{jedisConfig['expirationTime']}")
	private String expirationTime;

	public void putObject(String key, Object object) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			jedisCache.putObject(redisPrefix + key, object);
		}
	}

	public void putHashObject(String key, String field, String value) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			//jedisCache.putHashObject(redisPrefix + key, field, value);
		}
	}

	public void putHashMapObjects(String key, Map<String, String> map) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			//jedisCache.putHashMapObjects(redisPrefix + key, map);
		}
	}

	public void putObject(String key, Object object, int expirationInSeconds) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			jedisCache.putObject(redisPrefix + key, object, expirationInSeconds);
		}
	}

	public void putZsetObject(String key, Double score, String member) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
		//	jedisCache.putZsetObject(redisPrefix + key, score, member);
		}
	}

	public Double getZsetObject(String key, String member) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return null;//jedisCache.getZsetScore(redisPrefix + key, member);
		} else {
			return null;
		}
	}

	public Integer getZsetObjectWithInt(String key, String member) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return null;//jedisCache.getZsetScoreWithInt(redisPrefix + key, member);
		} else {
			return null;
		}
	}

	public Map<String, Double> getZsetObjects(String key, String... member) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return null;//jedisCache.getZsetScores(redisPrefix + key, member);
		} else {
			return null;
		}
	}

	public Map<String, Integer> getZsetObjectsWithInt(String key, String... member) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return null;//jedisCache.getZsetScoresWithInt(redisPrefix + key, member);
		} else {
			return null;
		}
	}

	public Map<String, Double> getRemZsetMembersByScoresRange(String key, Double min, Double max) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return null; //jedisCache.getRemZsetMembersByScoresRange(redisPrefix + key, min, max);
		} else {
			return null;
		}
	}

	public Object getObject(String key) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return jedisCache.getObject(redisPrefix + key);
		} else {
			return null;
		}
	}

	public Map<String, Object> getObjects(String... propertykeys) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			String[] keys = new String[propertykeys.length];
			for (int i = 0; i < propertykeys.length; i++) {
				keys[i] = redisPrefix + propertykeys[i];
			}
			return null;// jedisCache.getObjects(keys);
		} else {
			return null;
		}
	}

	public Map<String, String> getRemHashField(String key) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return null;//jedisCache.getRemHashField(redisPrefix + key);
		} else {
			return null;
		}
	}

	public Map<String, String> getHashObject(String key) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return null;// jedisCache.getHashObject(redisPrefix + key);
		} else {
			return null;
		}
	}

	public Map<String, Map<String, String>> getHashObjects(String... propertykeys) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			String keys[] = new String[propertykeys.length];
			for (int i = 0; i < propertykeys.length; i++) {
				String propertykey = propertykeys[i];
				keys[i] = redisPrefix + propertykey;
			}
			return null;//jedisCache.getHashObjects(keys);
		} else {
			return null;
		}
	}

	public void removeHashObject(String key, String... fields) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
		//	jedisCache.removeHashObjectFields(redisPrefix + key, fields);
		}
	}

	public void removeZsetMembers(String key, String... members) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			//jedisCache.removeZsetMember(redisPrefix + key, members);
		}
	}

	public boolean exists(String key) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return jedisCache.exists(redisPrefix + key);
		} else {
			return false;
		}
	}

	public long expire(String key, int expirationInSeconds) {
		if (Consts.CACHE_SWITCH_ON.equals(redisSwitch)) {
			return jedisCache.expire(redisPrefix + key, expirationInSeconds);
		} else {
			return 0L;
		}
	}

	// --------------不判断缓存开关--------------

	public void addObject(String key, Object object) {
		jedisCache.putObject(redisPrefix + key, object);
	}

	public void addObjectNoPrefix(String key, Object object) {
		jedisCache.putObject(key, object);
	}

	public void addObject(String key, Object object, int expirationInSeconds) {
		jedisCache.putObject(redisPrefix + key, object, expirationInSeconds);
	}

	public Object getObjectByCache(String key) {
		return jedisCache.getObject(redisPrefix + key);
	}

	public Object getObjectNoPrefixByCache(String key) {
		// return jedisCache.getObject(key);
		return null;
	}

	public void removeObject(String key) {
		jedisCache.removeObject(redisPrefix + key);
	}

	public void removeObjectNoPrefix(String key) {
		// jedisCache.removeObject(key);
	}

	public void removeObjectByPrefix(String prefix) {
		Set<String> keys = jedisCache.keys(redisPrefix + prefix + "*");
		for (Iterator<String> iter = keys.iterator(); iter.hasNext();) {
			jedisCache.removeObject(iter.next());
		}

	}

	/**
	 * @return the redisPrefix
	 */
	public String getRedisPrefix() {
		return redisPrefix;
	}

	/**
	 * @param redisPrefix
	 *            the redisPrefix to set
	 */
	public void setRedisPrefix(String redisPrefix) {
		this.redisPrefix = redisPrefix;
	}

	public void psubscribe(JedisPubSub jedisPubSub, String[] patterns) {
	//	jedisCache.psubscribe(jedisPubSub, patterns);
	}

	public void publish(String channel, String message) {
	//	jedisCache.publish(channel, message);
	}
}
