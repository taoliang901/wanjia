package com.wanjia.dsi.web.cms.activity.service.impl;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.integral.service.UserIntegralLogService;
import com.wanjia.dsi.integral.util.IntegralConst;
import com.wanjia.dsi.integral.util.IntegralEvent;
import com.wanjia.dsi.web.cms.activity.model.InfomationClickBO;
import com.wanjia.dsi.web.cms.activity.model.InfomationStatistcBO;
import com.wanjia.dsi.web.cms.activity.model.MyCollectionStatisticsBO;
import com.wanjia.dsi.web.cms.activity.repository.InfomationClickRepository;
import com.wanjia.dsi.web.cms.activity.repository.InfomationStatistcRepository;
import com.wanjia.dsi.web.cms.activity.service.InfomationService;
@Service
@com.alibaba.dubbo.config.annotation.Service
public class InfomationServiceImpl implements InfomationService{
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	InfomationStatistcRepository repositoryStatis;
	@Autowired
	InfomationClickRepository repositoryClick;
	@Autowired
	private UserIntegralLogService userIntegralLogService;
	
	@Override
	public JsonResponse<Void> insertOrUpdateInfomation(InfomationClickBO infomationClickBO) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		InfomationStatistcBO infomationStatistcBO = new InfomationStatistcBO();
		infomationStatistcBO.setInfoId(infomationClickBO.getInfoId());
		infomationStatistcBO.setType(infomationClickBO.getType());
		try {
			String infoId = infomationClickBO.getInfoId();
			String type = infomationClickBO.getType();
			logger.info("InfomationServiceImpl->insertOrUpdateInfomation,infoId:" + infoId + ",type:" + type);
			if (StringUtils.isNotBlank(infoId) && StringUtils.isNotBlank(type)) {
				Date now = new Date();
				infomationClickBO.setClickTime(now);
				infomationClickBO.setClickDate(DateUtils.format(now, DateUtils.DATE_FORMAT_TYPE3));

				Query query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
				//判断是否已经统计过
				boolean b = repositoryStatis.exists(query, InfomationStatistcBO.class);
				if(b){//mongodb已经有该条数据，访问量加1
					Update update = new Update();
					update.inc("countNum", 1);//总阅读量加1
					update.inc("realCountNum", 1);//实际阅读量加1
					repositoryStatis.updateFirst(query, InfomationStatistcBO.class, update);
				}else{//没有需要插入新数据\
					int randomNum = CommonTools.getRandIntRange(3000, 5000);  
					infomationStatistcBO.setRandomNum(randomNum);//初始化随机访问量
					infomationStatistcBO.setRealCountNum(1); //实际访问量
					infomationStatistcBO.setCountNum(randomNum + 1); //访问量=随机量+实际访问量
					repositoryStatis.insert(infomationStatistcBO, InfomationStatistcBO.class);
				}
				//插入到明细表
				repositoryClick.insert(infomationClickBO, InfomationClickBO.class);
				result.setStatus(Status.SUCCESS);
				if (!StringUtils.isEmpty(infomationClickBO.getUserId())) {
					try {
						// 阅读，插入积分记录
						userIntegralLogService.insert(infomationClickBO.getUserId(), IntegralEvent.READER,
								IntegralConst.TABLE_NAME_INFOMATION_STATISTC, infoId, null,
								infomationClickBO.getClientType());
					} catch (Exception ex) {
						logger.error("阅读成功，插入积分记录异常" + ex);
					}
				}
			} else {
				logger.error("InfomationServiceImpl->insertOrUpdateInfomation: infoId or type is null");
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.IllegalArgument.getCode());
				result.setErrorMsg(ErrorType.IllegalArgument.getDesc());
			}
		} catch (Exception e) {
			logger.error("InfomationServiceImpl->insertOrUpdateInfomation,infoId:" + infomationClickBO.getInfoId());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<List<InfomationStatistcBO>> getInfomationStatistic(String type,List<String> infoIds) {
		JsonResponse<List<InfomationStatistcBO>> result = new JsonResponse<List<InfomationStatistcBO>>();
		logger.info("InfomationServiceImpl->getInfomationStatistic start ,type:" + type);
		try{
				for(String infoId:infoIds){
					Query query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
					//判断是否已经统计过
					boolean b = repositoryStatis.exists(query, InfomationStatistcBO.class);
					if(!b){//mongodb没有该条数据，生成统计记录
						int randomNum = CommonTools.getRandIntRange(3000, 5000);  
						InfomationStatistcBO infomationStatistcBO = new InfomationStatistcBO();
						infomationStatistcBO.setInfoId(infoId);
						infomationStatistcBO.setType(type);
						infomationStatistcBO.setRandomNum(randomNum);//初始化随机访问量
						infomationStatistcBO.setRealCountNum(0); //实际访问量
						infomationStatistcBO.setCountNum(randomNum); //访问量=随机量+实际访问量
						repositoryStatis.insert(infomationStatistcBO, InfomationStatistcBO.class);
					}
				}
			
			    Query query;
				if(infoIds != null && infoIds.size() >0){
					//query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
					query = new Query(Criteria.where("infoId").in(infoIds).andOperator(Criteria.where("type").is(type)));
				}else{
					query = new Query(Criteria.where("type").is(type));
				}
				List<InfomationStatistcBO> infomationList = repositoryStatis.find(query, InfomationStatistcBO.class);
				//PageInfo<InfomationStatistcBO> page = new PageInfo<InfomationStatistcBO>(infomationList);
				result.setResult(infomationList);
				result.setStatus(Status.SUCCESS);	
				logger.info("InfomationServiceImpl->getInfomationStatistic end ");
		}catch(Exception e){
			logger.error("InfomationServiceImpl->getInfomationStatistic  " + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	/*@Override
	public JsonResponse<String> syncInfomationClick(String dateStr, String type) {
		JsonResponse<String> jr = new JsonResponse<String>();
		String result = repositoryClick.syncInfomationClick(dateStr, type);
		jr.setResult(result);
		return jr;
	}*/

	@Override
	public synchronized JsonResponse<String> syncInfomationStatistc(String dateStr, String type) {
		JsonResponse<String> jr = new JsonResponse<String>();
		String result = repositoryClick.syncInfomationStatistc(dateStr, type);
		jr.setResult(result);
		return jr;
	}
	@Override
	public synchronized JsonResponse<String> initInfomationStatistic(String type,List<String> infoIds) {
		JsonResponse<String> result = new JsonResponse<String>();
		if(infoIds  == null || infoIds.size() < 0){
			result.setResult("id列表为空，不需要同步！");
			result.setStatus(Status.SUCCESS);	
			return result;
		}
		logger.info("InfomationServiceImpl->initInfomationStatistic start ,type:" + type + ",infoIdsSize:" + infoIds.size());
		ExecutorService exe = null;
		try{
			int size = infoIds.size(); // 总条数
			int thNum = 4; // 启动最大线程数
			int everyTimeExeNum = 1000; // 每次最多执行条数
			int maxDeal = 10000; // 单线程启动最大条数
			int num = size / everyTimeExeNum; // 需要执行批数
			int residueEvery = size % everyTimeExeNum; // 总数除每次执行数目的余数
			if (residueEvery > 0) {// 整除有余数时，要加1次出来
				num = num + 1;
			}
			if (size > maxDeal) {// 大于10000，就启动多线程
				if (num <= thNum) {// 总批数小于等于启动线程数，启动线程数按照总批数
					exe = Executors.newFixedThreadPool(num);
					for (int i = 0; i < num; i++) {
						int beginIndex = i * everyTimeExeNum;
						int endTmp = i * everyTimeExeNum + everyTimeExeNum - 1;
						if (i == num - 1) {// 最后一批，需要取最后余数
							endTmp = i * everyTimeExeNum + residueEvery - 1;
						}
						int endIndex = endTmp;
						exe.execute(new Runnable() {
							@Override
							public void run() {
								insertInfomationStatistics(type, infoIds, beginIndex, endIndex);
							}
						});
					}
					exe.shutdown();
					while (true) {
						if (exe.isTerminated()) {
							logger.info("InfomationServiceImpl->initInfomationStatistic end,Executors  isTerminated");
							break;
						}
						Thread.sleep(10000);
					}
				} else {// 总批数大于启动线程数，启动线程数按照最大启动
					exe = Executors.newFixedThreadPool(thNum);
					for (int th = 0; th < num; th++) {
						int beginIndex = th * everyTimeExeNum;
						int endTmp = th * everyTimeExeNum + everyTimeExeNum - 1;
						if (th == num - 1) {// 最后一批，需要取最后余数
							endTmp = th * everyTimeExeNum + residueEvery - 1;
						}
						int endIndex = endTmp;
						exe.execute(new Runnable() {
							@Override
							public void run() {
								insertInfomationStatistics(type, infoIds, beginIndex, endIndex);
							}
						});
					}
					exe.shutdown();
					while (true) {
						if (exe.isTerminated()) {
							logger.info("InfomationServiceImpl->initInfomationStatistic end,Executors  isTerminated");
							break;
						}
						Thread.sleep(10000);
					}
				}
			} else {// 小于10000直接插入，不用多线程
				insertInfomationStatistics(type, infoIds, 0, size - 1);
			}
				result.setStatus(Status.SUCCESS);
				result.setResult("初始化阅读量成功，总条数:" + size);
				infoIds.clear();
				logger.info("InfomationServiceImpl->initInfomationStatistic end,type:" + type + ",infoIdsSize:" + infoIds.size());
		}catch(Exception e){
			logger.error("InfomationServiceImpl->initInfomationStatistic end " + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}finally {
			if (exe != null) {
				exe.shutdown();
			}
			logger.info("InfomationServiceImpl->initInfomationStatistic finally ExecutorService:"  + exe);
		}
		return result;
	}
	
	/**
	 * 插入数据到我的收藏统计表
	 * @param infoIds  各个类型统计id 必填
	 * @param type 类型 ；资讯：A，药品：M ，疾病：D  必填 
	 * @param beginIndex infoIds的开始索引
	 * @param endIndex   infoIds的结束索引
	 */
	public void insertInfomationStatistics(String type,List<String> infoIds,int beginIndex,int endIndex){
		for(int k=beginIndex;k<=endIndex;k++){
			String infoId = infoIds.get(k);
			Query query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
			//判断是否已经统计过
			boolean statis = repositoryStatis.exists(query, InfomationStatistcBO.class);
			if(!statis){//不是第一次被收藏。需要保存到统计表
				if(StringUtils.isNotBlank(infoId)){
					// 保存阅读量统计
					int randomNum = CommonTools.getRandIntRange(3000, 5000);  
					InfomationStatistcBO infomationStatistcBO = new InfomationStatistcBO();
					infomationStatistcBO.setInfoId(infoId);
					infomationStatistcBO.setType(type);
					infomationStatistcBO.setRandomNum(randomNum);//初始化随机访问量
					infomationStatistcBO.setRealCountNum(0); //实际访问量
					infomationStatistcBO.setCountNum(randomNum); //访问量=随机量+实际访问量
					repositoryStatis.insert(infomationStatistcBO, InfomationStatistcBO.class);
				}
			}
		}
	}
}
