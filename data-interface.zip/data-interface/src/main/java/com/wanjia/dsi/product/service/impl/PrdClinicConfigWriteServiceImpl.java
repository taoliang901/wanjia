package com.wanjia.dsi.product.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.product.dao.mapper.PrdClinicConfigMapper;
import com.wanjia.dsi.product.model.PrdClinicConfig;
import com.wanjia.dsi.product.service.PrdClinicConfigWriteService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdClinicConfigWriteServiceImpl  implements PrdClinicConfigWriteService {

	protected Logger logger = Logger.getLogger(PrdClinicConfigWriteServiceImpl.class);

	@Autowired 
	private PrdClinicConfigMapper prdClinicConfigMapper;
	
	@Override
	public void insert(PrdClinicConfig pcc) {
		prdClinicConfigMapper.insert(pcc);
	}

	@Override
	public void insertBatch(List<PrdClinicConfig> pccList) {
		prdClinicConfigMapper.insertBatch(pccList);
	}

	@Override
	public void update(PrdClinicConfig pcc) {
		prdClinicConfigMapper.updateByPrimaryKeySelective(pcc);
	}

	@Override
	public void deleteByProductId(String productId) {
		prdClinicConfigMapper.deleteByProductId(productId);
	}

	
}
