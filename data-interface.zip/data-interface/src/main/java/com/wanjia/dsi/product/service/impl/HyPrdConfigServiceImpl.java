package com.wanjia.dsi.product.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pinganwj.clinic.api.ApptService;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.product.dao.mapper.HyPrdConfigMapper;
import com.wanjia.dsi.product.model.HyPrdConfig;
import com.wanjia.dsi.product.model.HyPrdConfigExample;
import com.wanjia.dsi.product.service.HyPrdConfigService;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyClinicInfoMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyClinicRegisterMapper;
import com.wanjia.dsi.web.hyPerson.model.HyClinicInfo;
import com.wanjia.dsi.web.hyPerson.model.HyClinicRegister;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class HyPrdConfigServiceImpl implements HyPrdConfigService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private HyPrdConfigMapper hyPrdConfigMapper;
	
	@Autowired
	private HyClinicInfoMapper clinicInfoMapper;
    
    @Autowired
	private HyClinicRegisterMapper clinicRegisterMapper;
    
    @Value("#{hyCasConfig['BAIBO_ACCOUNT_ID']}")
	private String BAIBO_ACCOUNT_ID;
    
    @Value("#{hyCasConfig['BAIBO_TIME']}")
	private String BAIBO_TIME;

    // 深圳预约接口
 	@Autowired
 	private ApptService apptService;
 	
	@Override
	public JsonResponse<HyPrdConfig> getPrdConfig(String configCode) {
		// 返回参数
		JsonResponse<HyPrdConfig> res = new JsonResponse<HyPrdConfig>();

		// 数据校验
		if (StringUtils.isBlank(configCode)) {
			throw new ServiceException("ERROR1", "【配置编码】不能为空！");
		}

		// 查询配置项
		HyPrdConfigExample example = new HyPrdConfigExample();
		HyPrdConfigExample.Criteria criteria = example.createCriteria();
		criteria.andConfigCodeEqualTo(configCode);
		List<HyPrdConfig> hyPrdConfigList = hyPrdConfigMapper
				.selectByExample(example);
		if (CollectionUtils.isEmpty(hyPrdConfigList)) {
			throw new ServiceException("ERROR1", "查询到的配置项为空！");
		}

		// 数据返回
		HyPrdConfig hyPrdConfig = hyPrdConfigList.get(0);
		res.setResult(hyPrdConfig);
		res.setStatus(Status.SUCCESS);
		return res;
	}

	@Override
	public JsonResponse<HyPrdConfig> getPrdConfig(String configCode,String clinicId) {
		// 返回参数
		JsonResponse<HyPrdConfig> res = new JsonResponse<HyPrdConfig>();
		HyPrdConfig hyPrdConfig = new HyPrdConfig();
		
		// 数据校验
		if (StringUtils.isBlank(configCode)) {
			throw new ServiceException("ERROR1", "【配置编码】不能为空！");
		}

		// 根据诊所ID查询总账户ID
		String parentId = new String();
		if(StringUtils.isNotBlank(clinicId)){
			HyClinicInfo hyClinicInfo = clinicInfoMapper.selectByPrimaryKey(clinicId);
			if(hyClinicInfo!=null){
				HyClinicRegister register = clinicRegisterMapper.selectByPrimaryKey(hyClinicInfo.getClinicRegisterId());
				parentId = register.getParentAccountId();
			}
		}
		
		// 为单体诊所或者连锁诊所不为拜博齿科，走数据库配置
		if(StringUtils.isBlank(parentId)||BAIBO_ACCOUNT_ID.indexOf(parentId)==-1)
		{
			// 查询配置项
			HyPrdConfigExample example = new HyPrdConfigExample();
			HyPrdConfigExample.Criteria criteria = example.createCriteria();
			criteria.andConfigCodeEqualTo(configCode);
			List<HyPrdConfig> hyPrdConfigList = hyPrdConfigMapper
					.selectByExample(example);
			if (CollectionUtils.isEmpty(hyPrdConfigList)) {
				throw new ServiceException("ERROR1", "查询到的配置项为空！");
			}
			hyPrdConfig=hyPrdConfigList.get(0);
		}
		// 为拜博齿科，单独走配置文件配置
		else{
			hyPrdConfig.setConfigData(BAIBO_TIME);
		}
		res.setResult(hyPrdConfig);
		res.setStatus(Status.SUCCESS);
		return res;
	}

	@Override
	public JsonResponse<HyPrdConfig> getPrdConfigByClinic(String configCode,
			String clinicId) {
		// 返回参数
		JsonResponse<HyPrdConfig> res = new JsonResponse<HyPrdConfig>();
		HyPrdConfig hyPrdConfig = new HyPrdConfig();
		
		// 数据校验
		if (StringUtils.isBlank(configCode)) {
			throw new ServiceException("ERROR1", "【配置编码】不能为空！");
		}

		// 根据诊所ID查询总账户ID
		String parentId = new String();
		if(StringUtils.isNotBlank(clinicId)){
			HyClinicInfo hyClinicInfo = clinicInfoMapper.selectByPrimaryKey(clinicId);
			if(hyClinicInfo!=null){
				HyClinicRegister register = clinicRegisterMapper.selectByPrimaryKey(hyClinicInfo.getClinicRegisterId());
				parentId = register.getParentAccountId();
			}
		}
		
		// 为单体诊所或者连锁诊所不为拜博齿科，走数据库配置
		if(StringUtils.isBlank(parentId)||BAIBO_ACCOUNT_ID.indexOf(parentId)==-1)
		{
			// 查询配置项
			HyPrdConfigExample example = new HyPrdConfigExample();
			HyPrdConfigExample.Criteria criteria = example.createCriteria();
			criteria.andConfigCodeEqualTo(configCode);
			List<HyPrdConfig> hyPrdConfigList = hyPrdConfigMapper
					.selectByExample(example);
			if (CollectionUtils.isEmpty(hyPrdConfigList)) {
				throw new ServiceException("ERROR1", "查询到的配置项为空！");
			}
			hyPrdConfig=hyPrdConfigList.get(0);
		}
		// 为拜博齿科，单独走配置文件配置
		else{
			hyPrdConfig.setConfigData(BAIBO_TIME);
		}
		
	/*	// 如果诊所存在配置，则优先使用诊所配置
		com.pinganwj.clinic.api.domain.JsonResponse<Map<String, Integer>> apptResult = apptService.getApptMinAndMaxDayConfig(clinicId);
		if(!"SUCCESS".equals(apptResult.getStatus().toString())){
			throw new ServiceException("ERROR1", "根据诊所ID调用深圳接口失败！");
		}
		if(apptResult.getResult()!=null){
			Map<String, Integer> result = apptResult.getResult();
			if(result.get("APPT_MIN_DAY")!=null){
				String minDay = result.get("APPT_MIN_DAY").toString();
				hyPrdConfig.setConfigData(String.valueOf(Integer.parseInt(minDay)*24));
			}
		}*/
		res.setResult(hyPrdConfig);
		res.setStatus(Status.SUCCESS);
		return res;
	}
}
