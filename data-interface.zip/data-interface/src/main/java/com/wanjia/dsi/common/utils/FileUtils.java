package com.wanjia.dsi.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

public class FileUtils {

	/**
	 * 文件移动
	 * 
	 * @param oldPath
	 * @param targetPath
	 * @param targetFileName
	 * @return
	 */
	public static boolean moveToFile(String oldPath, String targetPath, String targetFileName) {
		try {
			File oldFile = new File(oldPath);
			File newFile = new File(targetPath);
			if (!newFile.exists()) {
				newFile.mkdirs();
			}
			File fnew = new File(newFile + "/" + targetFileName);
			if(fnew.exists()) {
				fnew.delete();
			}
			org.apache.commons.io.FileUtils.copyFile(oldFile, fnew);
			return true;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void copy(File src, File dest) {
		try {
			FileInputStream fis = new FileInputStream(src);
			mkParentDirs(dest);
			FileOutputStream fos = new FileOutputStream(dest);
			copy(fis, fos);
			fos.close();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void copy(InputStream src, OutputStream dest) {
		try {
			byte[] tmp = new byte[1024];
			int len = -1;
			while ((len = src.read(tmp)) != -1)
				dest.write(tmp, 0, len);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static void copy(byte[] src, byte[] dest) {
		System.arraycopy(src, 0, dest, 0, dest.length);
	}

	public static void write(File file, String content) {
		try {
			FileOutputStream fos = new FileOutputStream(file);
			write(fos, content);
			fos.close();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void write(OutputStream os, String content) {
		try {
			os.write(content.getBytes("UTF-8"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static void write(OutputStream os, byte[] content) {
		try {
			os.write(content);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static byte[] readAsBytes(InputStream is) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			copy(is, bos);

			bos.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return bos.toByteArray();
	}

	public static String readAsString(InputStream is) {
		try {
			String rs = new String(readAsBytes(is), "UTF-8");
			return rs;
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}

	public static void mkParentDirs(File file) {
		File parent = file.getParentFile();
		if (!parent.exists())
			parent.mkdirs();
	}

	public static void mkdir(String file) {
		File f = new File(file);
		if (!f.exists())
			f.mkdirs();
	}

	/**
	 * 删除文件
	 * 
	 * @param filePath
	 */
	public static void deleteFile(String filePath) {
		File file = new File(filePath);
		// 路径为文件且不为空则进行删除
		if (file.isFile() && file.exists()) {
			System.out.println("deleteFile:" + filePath);
			file.delete();
		}
	}
}
