package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.mongodb.Pagination;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.product.dao.mapper.CouponMapper;
import com.wanjia.dsi.product.dao.mapper.HealthProduceServiceMapper;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdTypeMapper;
import com.wanjia.dsi.product.dao.mapper.PrdTypeVOMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdKucunMapper;
import com.wanjia.dsi.product.model.HealthProduceService;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdInfoBO;
import com.wanjia.dsi.product.model.PrdInventory;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.PrdType;
import com.wanjia.dsi.product.model.ProductInfo;
import com.wanjia.dsi.product.model.VOPrdInfo;
import com.wanjia.dsi.product.model.VOPrdInfoBO;
import com.wanjia.dsi.product.repository.PrdInfoRepository;
import com.wanjia.dsi.product.service.ProductService;
import com.wanjia.dsi.product.service.StockService;
import com.wanjia.dsi.product.vo.VOPrdKucun;
import com.wanjia.dsi.web.area.dao.mapper.AreaMapper;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.hyPerson.dao.mapper.VOHyTreatmentPersonMapper;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;
import com.wanjia.dsi.web.hyPerson.model.VOHyTreatmentPerson;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	private StockService stockService;

	@Autowired
	private CouponMapper couponMapper;
	@Autowired
	private AreaMapper areaMapper;
	@Autowired
	private PrdTypeVOMapper prdTypeVOMapper;
	@Autowired
	private PrdTypeMapper prdTypeMapper;

	@Autowired
	private HealthProduceServiceMapper healthProduceServiceMapper;

	@Autowired
	private VOPrdInfoMapper voPrdInfoMapper;
	@Autowired
	private VOPrdKucunMapper voPrdKucunMapper;
	
	@Autowired
	private VOHyTreatmentPersonMapper voHyTreatmentPersonMapper;
	@Autowired
	PrdInfoRepository repository;
	@Autowired
	PrdInfoMapper prdInfoMapper;
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Override
	public JsonResponse<PageInfo<ProductInfo>> getContractList(ProductInfo coupon) {
		// TODO Auto-generated method stub

		logger.info("~~~~~~~~~~~~~getContractList start ~~~~~~~~~~~ ");

		JsonResponse<PageInfo<ProductInfo>> response = new JsonResponse<PageInfo<ProductInfo>>();

		try {

			// 设置分页信息
			PageHelper.startPage(coupon.getPageNo() == 0 ? 1 : coupon.getPageNo(),
					coupon.getPageSize() == 0 ? 10 : coupon.getPageSize());
			coupon.setDelFlag(0);
			// 返回结果
			response.setResult(new PageInfo<ProductInfo>(couponMapper.getContractList(coupon)));

		} catch (Exception e) {
			logger.error("error ", e);
		}

		logger.info("~~~~~~~~~~~~~getContractList end ~~~~~~~~~~~ ");

		return response;
	}

	@Override
	public JsonResponse<ProductInfo> findCouponDetail(ProductInfo copon) {
		JsonResponse<ProductInfo> response = new JsonResponse<ProductInfo>();
		StringBuilder clinicIdsb = new StringBuilder();
		StringBuilder clinicNamesb = new StringBuilder();
		try {

			ProductInfo productInfo = (ProductInfo) couponMapper.findOneByEntity(copon);
			// 设置诊所名字和id
			List<ProductInfo> clinicName = couponMapper.getClinicName(copon);
			if (CollectionUtils.isNotEmpty(clinicName)) {
				for (int a = 0; a < clinicName.size(); a++) {
					// 设置诊所名字和id
					if (clinicName.get(a) != null) {
						if (a == clinicName.size() - 1) {
							clinicNamesb.append(clinicName.get(a).getClinicName());
							clinicIdsb.append(clinicName.get(a).getClinicId());
						} else {
							clinicNamesb.append(clinicName.get(a).getClinicName()).append(",");
							clinicIdsb.append(clinicName.get(a).getClinicId()).append(",");
						}
					}
				}
			}
			// 设置诊所名字和id
			productInfo.setClinicName(clinicNamesb.toString());
			// 设置诊所名字和id
			productInfo.setClinicId(clinicIdsb.toString());

			// 服务项目
			HealthProduceService hps = new HealthProduceService();
			hps.setPrdId(copon.getId());
			// 服务项目
			productInfo.setHps(healthProduceServiceMapper.findHealthProduceServiceInfo(hps));
			//设置城市
			productInfo.setCity(convertCity(productInfo.getCity()));
			//设置库存信息
			
			
			response.setResult(productInfo);

		} catch (Exception e) {
			logger.error("error", e);
		}

		return response;
	}

	@Override
	public JsonResponse<List<PrdInventory>> listPrdInventoryByPrdIds(List<String> prdIds) {
		JsonResponse<List<PrdInventory>> jresp = new JsonResponse<List<PrdInventory>>();
		jresp.setResult(healthProduceServiceMapper.listPrdInventoryByPrdIds(prdIds));
		return jresp;
	}

	@Override
	public JsonResponse<ProductInfo> getProduceInfo(ProductInfo productInfo) {
		logger.info("~~~~~~~~~~~~~getContractList start ~~~~~~~~~~~ ");

		JsonResponse<ProductInfo> response = new JsonResponse<ProductInfo>();

		try {
			if (CommonTools.notNullAndEmpty(productInfo)) {
				if (StringUtils.isNotBlank(productInfo.getId())) {

					List<ProductInfo> list = couponMapper.findByEntity(productInfo);
					if(list != null && list.size() > 0){
						ProductInfo produceInfo = list.get(0);
						// 设置省份和市
						produceInfo.setProvince(convertProvince(produceInfo.getProvince()));
						produceInfo.setCity(convertCity(produceInfo.getCity()));
						// 设置服务项目
						HealthProduceService hps = new HealthProduceService();
						hps.setPrdId(productInfo.getId());
						produceInfo.setHps(healthProduceServiceMapper.findHealthProduceServiceInfo(hps));

						//设置库存总数和已使用数
						JsonResponse<Map<String, Integer>> stockNumsJr = stockService.getStockTotalNumber(produceInfo.getId());
						JsonResponse<Map<String, Integer>> usedNumsJr = stockService.getStockUsedNumber(produceInfo.getId());
						
						if(stockNumsJr != null && stockNumsJr.getResult() != null){
							if(stockNumsJr.getResult().containsKey(produceInfo.getId())){
								produceInfo.setTotal(stockNumsJr.getResult().get(produceInfo.getId()));
							}else{
								produceInfo.setTotal(0);
							}
						}
						if(usedNumsJr != null && usedNumsJr.getResult() != null){
							if(usedNumsJr.getResult().containsKey(produceInfo.getId())){
								produceInfo.setUsedTotal(usedNumsJr.getResult().get(produceInfo.getId()));
							}else{
								produceInfo.setUsedTotal(0);
							}
						}
						
						
						response.setResult(produceInfo);
					}
				}
			}

		} catch (Exception e) {
			logger.error("getContractList error ", e);
		}

		logger.info("~~~~~~~~~~~~~getContractList end ~~~~~~~~~~~ ");

		return response;
	}

	@Override
	public JsonResponse<PageInfo<ProductInfo>> getProduceList(ProductInfo productInfo) {
		logger.info("~~~~~~~~~~~~~getContractList start ~~~~~~~~~~~ ");

		JsonResponse<PageInfo<ProductInfo>> response = new JsonResponse<PageInfo<ProductInfo>>();

		try {
			// 设置分页信息
			PageHelper.startPage(productInfo.getPageNo() == 0 ? 1 : productInfo.getPageNo(),
					productInfo.getPageSize() == 0 ? 10 : productInfo.getPageSize());
			// 查询
			List<ProductInfo> produceList = couponMapper.getProduceList(productInfo);

			if(null!=produceList){
				
				String[] prdIds = new String[produceList.size()];
				
				for(int i=0;i<produceList.size();i++){
					ProductInfo productInfo2 = produceList.get(i);
					productInfo2.setProvince(convertProvince(productInfo2.getProvince()));
					productInfo2.setCity(convertCity(productInfo2.getCity()));
					// 设置省份和市信息
					productInfo2.setProvince(convertProvince(productInfo2.getProvince()));
					productInfo2.setCity(convertCity(productInfo2.getCity()));
					//设置排序信息
//					productInfo2.setOrder(productInfo.getOrder());
//					productInfo2.setSort(productInfo.getSort());
					prdIds[i] = productInfo2.getId();
					
				}
				JsonResponse<Map<String, Integer>> stockNumsJr = stockService.getStockTotalNumber(prdIds);
				JsonResponse<Map<String, Integer>> usedNumsJr = stockService.getStockUsedNumber(prdIds);
				
				for (int i=0;i<produceList.size();i++) {
					// 设置库存总数和已使用数
					ProductInfo productInfo2 = produceList.get(i);
					if(stockNumsJr != null && stockNumsJr.getResult() != null){
						if(stockNumsJr.getResult().containsKey(productInfo2.getId())){
							productInfo2.setTotal(stockNumsJr.getResult().get(productInfo2.getId()));
						}else{
							productInfo2.setTotal(0);
						}
					}
					if(usedNumsJr != null && usedNumsJr.getResult() != null){
						if(usedNumsJr.getResult().containsKey(productInfo2.getId())){
							productInfo2.setUsedTotal(usedNumsJr.getResult().get(productInfo2.getId()));
						}else{
							productInfo2.setUsedTotal(0);
						}
					}
				}
				
				
				
			}
			response.setResult(new PageInfo<ProductInfo>(produceList));

		} catch (Exception e) {
			logger.error("getContractList error ", e);
		}

		logger.info("~~~~~~~~~~~~~getContractList end ~~~~~~~~~~~ ");

		return response;
	}

	@Override
	public JsonResponse<PageInfo<ProductInfo>> getOnlineProduceInfo(Map<String, Object> map, int pageSize,
			int pageNum) {
		logger.info("~~~~~~~~~~~~~getOnlineProduceInfo start ~~~~~~~~~~~ ");

		JsonResponse<PageInfo<ProductInfo>> response = new JsonResponse<PageInfo<ProductInfo>>();

		try {
			// 设置分页信息
			PageHelper.startPage(pageNum, pageSize);
			// 获取在线的产品列表
			List<ProductInfo> produceList = couponMapper.getOnlineProduceInfo(map);

			for (ProductInfo productInfo : produceList) {
				// 设置省份和市信息
				productInfo.setProvince(convertProvince(productInfo.getProvince()));
				productInfo.setCity(convertCity(productInfo.getCity()));
			}

			response.setResult(new PageInfo<ProductInfo>(produceList));

		} catch (Exception e) {
			logger.error("getOnlineProduceInfo error ", e);
			e.printStackTrace();
		}

		logger.info("~~~~~~~~~~~~~getOnlineProduceInfo end ~~~~~~~~~~~ ");

		return response;
	}

	@Override
	public JsonResponse<List<ProductInfo>> getOnlineProduceInfo(Map<String, Object> map) {
		logger.info("~~~~~~~~~~~~~getOnlineProduceInfo start ~~~~~~~~~~~ ");

		JsonResponse<List<ProductInfo>> response = new JsonResponse<List<ProductInfo>>();

		try {
			// 获取在线的产品列表
			List<ProductInfo> produceList = couponMapper.getOnlineProduceInfo(map);
			response.setResult(produceList);
		} catch (Exception e) {
			logger.error("getOnlineProduceInfo error ", e);
			e.printStackTrace();
		}

		logger.info("~~~~~~~~~~~~~getOnlineProduceInfo end ~~~~~~~~~~~ ");

		return response;
	}

	/**************
	 * 省code转换为名称
	 * 
	 * @param province
	 * @return
	 */
	private String convertProvince(String province) {
		logger.info("~~~~~~~ province ~~~~~~~" + province);
		StringBuilder provinceBuilder = new StringBuilder("");
		List<String> provinceString = new ArrayList<String>();
		if (StringUtils.isNotBlank(province)) {
			String[] split = province.split("\\|");
			for (int i = 0; i < split.length; i++) {
				if (StringUtils.isNotBlank(split[i])) {
					if ("0".equals(split[i])) {
						provinceBuilder.append("全国");
						break;
					} else {
						// 查出所有的省份信息
						provinceString.add(split[i]);
					}
				}
			}

			if (CollectionUtils.isNotEmpty(provinceString)) {
				// id 转成 name
				List<Area> gainAreaList = areaMapper.gainAreaList(provinceString);
				if (CollectionUtils.isNotEmpty(gainAreaList)) {
					for (int i = 0; i < gainAreaList.size(); i++) {
						if (i == gainAreaList.size() - 1) {
							provinceBuilder.append(gainAreaList.get(i).getName());
						} else {
							provinceBuilder.append(gainAreaList.get(i).getName()).append(",");
						}
					}
				}
			}
		}
		return provinceBuilder.toString();
	}

	/**************
	 * 市code转换为名称
	 * 
	 * @param city
	 * @return
	 */
	private String convertCity(String city) {
		logger.info("~~~~~~~ city ~~~~~~~" + city);
		StringBuilder cityBuilder = new StringBuilder("");
		List<String> cityString = new ArrayList<String>();
		if (StringUtils.isNotBlank(city)) {
			String[] split = city.split("\\|");

			for (int i = 0; i < split.length; i++) {
				if (StringUtils.isNotBlank(split[i])) {
					if ("0".equals(split[i])) {
						cityBuilder.append("全国");
						break;
					} else {
						// 查出所有的省份信息
						cityString.add(split[i]);
					}
				}
			}

			if (CollectionUtils.isNotEmpty(cityString)) {
				// 蒋id转换成名字
				List<Area> gainAreaList = areaMapper.gainAreaList(cityString);
				if (CollectionUtils.isNotEmpty(gainAreaList)) {
					// 按照，拼接
					for (int i = 0; i < gainAreaList.size(); i++) {
						if (i == gainAreaList.size() - 1) {
							cityBuilder.append(gainAreaList.get(i).getName());
						} else {
							cityBuilder.append(gainAreaList.get(i).getName()).append(",");
						}
					}
				}
			}
		}

		return cityBuilder.toString();
	}

	@Override
	public JsonResponse<List<PrdType>> getOnlineProduceTypeList(Map<String, Object> map) {
		logger.info("~~~~~~~~~~~~~getOnlineProduceTypeList start ~~~~~~~~~~~ ");

		JsonResponse<List<PrdType>> response = new JsonResponse<List<PrdType>>();

		try {
			// 获取在线的产品列表
			List<PrdType> produceTypeList = prdTypeMapper.getOnlineProduceTypeList(map);
			response.setResult(produceTypeList);
		} catch (Exception e) {
			logger.error("getOnlineProduceTypeList error ", e);
			e.printStackTrace();
		}

		logger.info("~~~~~~~~~~~~~getOnlineProduceTypeList end ~~~~~~~~~~~ ");

		return response;
	}

	@Override
	public JsonResponse<PageInfo<ProductInfo>> getOnlineProduceInfoForList(Map<String, Object> map, int pageSize,
			int pageNum) {
		logger.info("~~~~~~~~~~~~~getOnlineProduceInfoForList start ~~~~~~~~~~~ ");

		JsonResponse<PageInfo<ProductInfo>> response = new JsonResponse<PageInfo<ProductInfo>>();

		try {
			// 设置分页信息
			PageHelper.startPage(pageNum, pageSize);
			// 获取在线的产品列表
			List<ProductInfo> produceList = couponMapper.getOnlineProduceInfoForList(map);

			if(produceList != null && produceList.size()>0){
				String[] prdIds = new String[produceList.size()];
				for (int i=0;i<produceList.size();i++) {
					// 设置省份和市信息
					ProductInfo productInfo = produceList.get(i);
					productInfo.setProvince(convertProvince(productInfo.getProvince()));
					productInfo.setCity(convertCity(productInfo.getCity()));
					prdIds[i] = productInfo.getId();
				}
				
				JsonResponse<Map<String, Integer>> stockNumsJr = stockService.getStockTotalNumber(prdIds);
				JsonResponse<Map<String, Integer>> usedNumsJr = stockService.getStockUsedNumber(prdIds);
				
				for (int i=0;i<produceList.size();i++) {
					// 设置库存总数和已使用数
					ProductInfo productInfo = produceList.get(i);
					if(stockNumsJr != null && stockNumsJr.getResult() != null){
						if(stockNumsJr.getResult().containsKey(productInfo.getId())){
							productInfo.setTotal(stockNumsJr.getResult().get(productInfo.getId()));
						}else{
							productInfo.setTotal(0);
						}
					}
					if(usedNumsJr != null && usedNumsJr.getResult() != null){
						if(usedNumsJr.getResult().containsKey(productInfo.getId())){
							productInfo.setUsedTotal(usedNumsJr.getResult().get(productInfo.getId()));
						}else{
							productInfo.setUsedTotal(0);
						}
					}
				}
			}

			response.setResult(new PageInfo<ProductInfo>(produceList));

		} catch (Exception e) {
			logger.error("getOnlineProduceInfo error ", e);
			e.printStackTrace();
		}

		logger.info("~~~~~~~~~~~~~getOnlineProduceInfoForList end ~~~~~~~~~~~ ");

		return response;
	}

	@Override
	public JsonResponse<PrdType> getPrdTypeByName(String prdTypeName) {
		JsonResponse<PrdType> jr = new JsonResponse<PrdType>();
		try{
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("prdTypeName", prdTypeName);
			PrdType prdType = prdTypeMapper.getPrdTypeByName(map);
			jr.setResult(prdType);
			jr.setStatus(Status.SUCCESS);
		}catch(Exception e){
			logger.error("getPrdTypeIdByName error:",e);
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}

	@Override
	public JsonResponse<VOPrdInfo> getPrdInfoServiceById(String id,String visitId) {
		JsonResponse<VOPrdInfo> response = new JsonResponse<VOPrdInfo>();
		try {
			VOPrdInfo result = voPrdInfoMapper.getPrdInfoServiceById(id);
			//根据就诊人id查询userId
			List<String> userIds = voPrdInfoMapper.getUserIdsByVisitId(visitId);
			if(userIds != null && userIds.size() >0){
				VOPrdKucun voPrdKucun = new VOPrdKucun();
				voPrdKucun.setCouponId(id);
				voPrdKucun.setUserIds(userIds);
				//根据产品id和userid查询库存id
				List<PrdKucun> prdKucunList = voPrdKucunMapper.getKucunIdsByUserIds(voPrdKucun);
				result.setPrdKucunList(prdKucunList);
			}
			response.setResult(result);
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("getPrdInfoServiceById error:", e);
			response.setStatus(Status.ERROR);
		}
		return response;
	}

	@Override
	public JsonResponse<PageInfo<HyTreatmentPerson>> getTreatmentPersonByPrdId(String prdId, String mobile, int pageNo,int pageSize) {
		JsonResponse<PageInfo<HyTreatmentPerson>> response = new JsonResponse<PageInfo<HyTreatmentPerson>>();
		try {
			PageHelper.startPage(pageNo, pageSize);
			PageInfo<HyTreatmentPerson> page = new PageInfo<HyTreatmentPerson>();
			VOHyTreatmentPerson vo = new VOHyTreatmentPerson();
			vo.setPrdId(prdId);
			vo.setVisitMobile(mobile);
			// 通过电话查询对应的userId就诊人或者用户对应的就诊人
			List<String> userIds = voHyTreatmentPersonMapper.getUserIdByMobile(mobile);
			if (userIds != null && userIds.size() > 0) {
				// 通过产品id和过滤后的就诊人对应的用户查询就诊人
				vo.setMemberIdList(userIds);
				userIds = voHyTreatmentPersonMapper.getUserIdByPrdId(vo);
			}
			if (userIds != null && userIds.size() > 0) {
				vo.setMemberIdList(userIds);
				// 通过就诊人电话和用户id查询就诊人
				List<HyTreatmentPerson> personList = voHyTreatmentPersonMapper.getTreatmentPersonByUserId(vo);
				page = new PageInfo<HyTreatmentPerson>(personList);// 获得分页信息
			}
			response.setResult(page);
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("getTreatmentPersonByPrdId error:", e);
			response.setStatus(Status.ERROR);
		}
		return response;
	}

	@Override
	public JsonResponse<Void> insertPrdInfoBO(PrdInfoBO prdInfoBO) {
		JsonResponse<Void> response = new JsonResponse<Void>();
		try {
			if (prdInfoBO == null || StringUtils.isBlank(prdInfoBO.getPrdId())) {
				logger.error("insertPrdInfoBo error:报错产品数据到mongodb，产品id为空！");
				response.setStatus(Status.ERROR);
				response.setErrorMsg("保存产品数据到mongodb，产品id为空！");
				return response;
			}
			prdInfoBO.setDelFlag(0);
			Query query = new Query(Criteria.where("prdId").is(prdInfoBO.getPrdId()));
			if (repository.exists(query, PrdInfoBO.class)) {
				updatePrdInfoBO(prdInfoBO);
			} else {
				repository.insert(prdInfoBO, PrdInfoBO.class);
			}
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("insertPrdInfoBo error:", e);
			response.setStatus(Status.ERROR);
			response.setErrorMsg("插入产品数据到mongodb错误！");
		}

		return response;
	}

	@Override
	public JsonResponse<Void> updatePrdInfoBO(PrdInfoBO prdInfoBO) {
		JsonResponse<Void> response = new JsonResponse<Void>();
		try {
			if (prdInfoBO == null || StringUtils.isBlank(prdInfoBO.getPrdId())) {
				logger.error("updatePrdInfoBo error:更新产品数据到mongodb，产品id为空！");
				response.setStatus(Status.ERROR);
				response.setErrorMsg("更新产品数据到mongodb，产品id为空！");
				return response;
			}
			Query query = new Query(Criteria.where("prdId").is(prdInfoBO.getPrdId()));
			Update update = new Update();
			if (prdInfoBO.getActivationDeadline() != null) {
				update.set("activationDeadline", prdInfoBO.getActivationDeadline());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getActiveOperation())) {
				update.set("activeOperation", prdInfoBO.getActiveOperation());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getActiveUnit())) {
				update.set("activeUnit", prdInfoBO.getActiveUnit());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getActiveValue())) {
				update.set("activeValue", prdInfoBO.getActiveValue());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getBookUpperLimit())) {
				update.set("bookUpperLimit", prdInfoBO.getBookUpperLimit());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getCity())) {
				update.set("city", prdInfoBO.getCity());
				update.set("cityName", convertCity(prdInfoBO.getCity()));
			}
			if (StringUtils.isNotBlank(prdInfoBO.getCouponName())) {
				update.set("couponName", prdInfoBO.getCouponName());
			}
			if (prdInfoBO.getCouponNo() != null) {
				update.set("couponNo", prdInfoBO.getCouponNo());
			}
			if (prdInfoBO.getCouponStock() != null) {
				update.set("couponStock", prdInfoBO.getCouponStock());
			}
			if (prdInfoBO.getDelFlag() != null) {
				update.set("delFlag", prdInfoBO.getDelFlag());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getFreeUseUnit())) {
				update.set("freeUseUnit", prdInfoBO.getFreeUseUnit());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getFreeUseValue())) {
				update.set("freeUseValue", prdInfoBO.getFreeUseValue());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsFreeUse())) {
				update.set("isFreeUse", prdInfoBO.getIsFreeUse());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsFrontShow())) {
				update.set("isFrontShow", prdInfoBO.getIsFrontShow());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsHolidayOn())) {
				update.set("isHolidayOn", prdInfoBO.getIsHolidayOn());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsNeedInviteValue())) {
				update.set("isNeedInviteValue", prdInfoBO.getIsNeedInviteValue());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsNeedManyBook())) {
				update.set("isNeedManyBook", prdInfoBO.getIsNeedManyBook());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsNeedManyUse())) {
				update.set("isNeedManyUse", prdInfoBO.getIsNeedManyUse());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsNeedPassword())) {
				update.set("isNeedPassword", prdInfoBO.getIsNeedPassword());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsSupportBuyOnline())) {
				update.set("isSupportBuyOnline", prdInfoBO.getIsSupportBuyOnline());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsSupportKfyy())) {
				update.set("isSupportKfyy", prdInfoBO.getIsSupportKfyy());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsSupportReceiveFree())) {
				update.set("isSupportReceiveFree", prdInfoBO.getIsSupportReceiveFree());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsValidFrom())) {
				update.set("isValidFrom", prdInfoBO.getIsValidFrom());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getIsWeekendOn())) {
				update.set("isWeekendOn", prdInfoBO.getIsWeekendOn());
			}
			if (prdInfoBO.getMarketPrice() != null) {
				update.set("marketPrice", prdInfoBO.getMarketPrice());
			}
			if (prdInfoBO.getOnlineDate() != null) {
				update.set("onlineDate", prdInfoBO.getOnlineDate());
			}
			if (prdInfoBO.getUsedPrdStock() != null) {
				update.set("usedPrdStock", prdInfoBO.getUsedPrdStock());
			}
			if (prdInfoBO.getPrdBeginDate() != null) {
				update.set("prdBeginDate", prdInfoBO.getPrdBeginDate());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPrdChannel())) {
				update.set("prdChannel", prdInfoBO.getPrdChannel());
			}
			if (prdInfoBO.getPrdEndDate() != null) {
				update.set("prdEndDate", prdInfoBO.getPrdEndDate());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPrdListPhoto())) {
				update.set("prdListPhoto", prdInfoBO.getPrdListPhoto());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPrdPhoto())) {
				update.set("prdPhoto", prdInfoBO.getPrdPhoto());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPrdPrice())) {
				update.set("prdPrice", prdInfoBO.getPrdPrice());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPrdPriceUnit())) {
				update.set("prdPriceUnit", prdInfoBO.getPrdPriceUnit());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPrdSupply())) {
				update.set("prdSupply", prdInfoBO.getPrdSupply());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPrdTypeName())) {
				update.set("prdTypeName", prdInfoBO.getPrdTypeName());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPropaganda())) {
				update.set("propaganda", prdInfoBO.getPropaganda());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getProvince())) {
				update.set("province", prdInfoBO.getProvince());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getRegisterOperation())) {
				update.set("registerOperation", prdInfoBO.getRegisterOperation());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getRegisterUnit())) {
				update.set("registerUnit", prdInfoBO.getRegisterUnit());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getRegisterValue())) {
				update.set("registerValue", prdInfoBO.getRegisterValue());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getStatus())) {
				update.set("status", prdInfoBO.getStatus());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getUpperLimit())) {
				update.set("upperLimit", prdInfoBO.getUpperLimit());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getUseBeginTime())) {
				update.set("useBeginTime", prdInfoBO.getUseBeginTime());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getUseEndTime())) {
				update.set("useEndTime", prdInfoBO.getUseEndTime());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getUseFrequence())) {
				update.set("useFrequence", prdInfoBO.getUseFrequence());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getValidValue())) {
				update.set("validValue", prdInfoBO.getValidValue());
			}
			if (StringUtils.isNotBlank(prdInfoBO.getValidValueUnit())) {
				update.set("validValueUnit", prdInfoBO.getValidValueUnit());
			}
			if (prdInfoBO.getCouponStock() != null) {
				update.set("couponStock", prdInfoBO.getCouponStock());//更新总库存
			}
			if (prdInfoBO.getUsedPrdStock() != null) {
				update.set("usedPrdStock", prdInfoBO.getUsedPrdStock());// 更新已使用库存
			}
			if (StringUtils.isNotBlank(prdInfoBO.getPlatformFlag())) {
				update.set("platformFlag", prdInfoBO.getPlatformFlag());
			}
			if (prdInfoBO.getOrderNum() != null) {
				update.set("orderNum", prdInfoBO.getOrderNum());// 更新产品排序号
			}else{
				update.set("orderNum", 999999999);
			}
			if(prdInfoBO.getPrdTypeSeq() != null){
				update.set("prdTypeSeq", prdInfoBO.getPrdTypeSeq());// 更新产品排序号
			}else{
				update.set("prdTypeSeq", 999999999);
			}
			repository.updateFirst(query, PrdInfoBO.class, update);
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("insertPrdInfoBo error:", e);
			response.setStatus(Status.ERROR);
			response.setErrorMsg("更新产品数据到mongodb错误！");
		}
		return response;
	}

	@Override
	public JsonResponse<Pagination<PrdInfoBO>> findPrdInfoBO(VOPrdInfoBO voPrdInfoBO) {
		JsonResponse<Pagination<PrdInfoBO>> response = new JsonResponse<Pagination<PrdInfoBO>>();
		int pageNo = voPrdInfoBO.getPageNo();
		int pageSize = voPrdInfoBO.getPageSize();
		try{
		Query query = new Query();
		voPrdInfoBO.setDelFlag(0);
		if (StringUtils.isNotBlank(voPrdInfoBO.getPrdId())) {
			query.addCriteria(Criteria.where("prdId").is(voPrdInfoBO.getPrdId()));
		}
		
		if (voPrdInfoBO.getActivationDeadline() != null) {
			query.addCriteria(Criteria.where("activationDeadline").lte(voPrdInfoBO.getActivationDeadline()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getActiveOperation())) {
			query.addCriteria(Criteria.where("activeOperation").is(voPrdInfoBO.getActiveOperation()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getActiveUnit())) {
			query.addCriteria(Criteria.where("activeUnit").is(voPrdInfoBO.getActiveUnit()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getActiveValue())) {
			query.addCriteria(Criteria.where("activeValue").is(voPrdInfoBO.getActiveValue()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getBookUpperLimit())) {
			query.addCriteria(Criteria.where("bookUpperLimit").is(voPrdInfoBO.getBookUpperLimit()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getCity())) {
			query.addCriteria(Criteria.where("city").regex(voPrdInfoBO.getCity())); //like
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getCityName())) {
			query.addCriteria(Criteria.where("cityName").regex(voPrdInfoBO.getCityName())); //like
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getCouponName())) {
			query.addCriteria(Criteria.where("couponName").regex(voPrdInfoBO.getCouponName()));
		}
		if (voPrdInfoBO.getCouponNo() != null) {
			query.addCriteria(Criteria.where("couponNo").is(voPrdInfoBO.getCouponNo()));
		}
		if (voPrdInfoBO.getCouponStock() != null) {
			query.addCriteria(Criteria.where("couponStock").is(voPrdInfoBO.getCouponStock()));
		}
		if (voPrdInfoBO.getDelFlag() != null) {
			query.addCriteria(Criteria.where("delFlag").is(voPrdInfoBO.getDelFlag()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getFreeUseUnit())) {
			query.addCriteria(Criteria.where("freeUseUnit").is(voPrdInfoBO.getFreeUseUnit()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getFreeUseValue())) {
			query.addCriteria(Criteria.where("freeUseValue").is(voPrdInfoBO.getFreeUseValue()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsFreeUse())) {
			query.addCriteria(Criteria.where("isFreeUse").is(voPrdInfoBO.getIsFreeUse()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsFrontShow())) {
			query.addCriteria(Criteria.where("isFrontShow").is(voPrdInfoBO.getIsFrontShow()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsHolidayOn())) {
			query.addCriteria(Criteria.where("isHolidayOn").is(voPrdInfoBO.getIsHolidayOn()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsNeedInviteValue())) {
			query.addCriteria(Criteria.where("isNeedInviteValue").is(voPrdInfoBO.getIsNeedInviteValue()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsNeedManyBook())) {
			query.addCriteria(Criteria.where("isNeedManyBook").is(voPrdInfoBO.getIsNeedManyBook()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsNeedManyUse())) {
			query.addCriteria(Criteria.where("isNeedManyUse").is(voPrdInfoBO.getIsNeedManyUse()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsNeedPassword())) {
			query.addCriteria(Criteria.where("isNeedPassword").is(voPrdInfoBO.getIsNeedPassword()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsSupportBuyOnline())) {
			query.addCriteria(Criteria.where("isSupportBuyOnline").is(voPrdInfoBO.getIsSupportBuyOnline()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsSupportKfyy())) {
			query.addCriteria(Criteria.where("isSupportKfyy").is(voPrdInfoBO.getIsSupportKfyy()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsSupportReceiveFree())) {
			query.addCriteria(Criteria.where("isSupportReceiveFree").is(voPrdInfoBO.getIsSupportReceiveFree()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsValidFrom())) {
			query.addCriteria(Criteria.where("isValidFrom").is(voPrdInfoBO.getIsValidFrom()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getIsWeekendOn())) {
			query.addCriteria(Criteria.where("isWeekendOn").is(voPrdInfoBO.getIsWeekendOn()));
		}
		
		if (voPrdInfoBO.getOnlineDate() != null) {
			query.addCriteria(Criteria.where("onlineDate").is(voPrdInfoBO.getOnlineDate()));
		}
		
		if (voPrdInfoBO.getUsedPrdStock() != null) {
			query.addCriteria(Criteria.where("usedPrdStock").is(voPrdInfoBO.getUsedPrdStock()));
		}
		
		if (StringUtils.isNotBlank(voPrdInfoBO.getPrdChannel())) {
			query.addCriteria(Criteria.where("prdChannel").is(voPrdInfoBO.getPrdChannel()));
		}
		
		if (voPrdInfoBO.getPrdBeginDate() != null) {
			query.addCriteria(Criteria.where("prdBeginDate").gte(voPrdInfoBO.getPrdBeginDate()));
		}
		if (voPrdInfoBO.getPrdEndDate() != null) {
			query.addCriteria(Criteria.where("prdEndDate").lte(voPrdInfoBO.getPrdEndDate()));
		}
		
		if (StringUtils.isNotBlank(voPrdInfoBO.getPrdListPhoto())) {
			query.addCriteria(Criteria.where("prdListPhoto").is(voPrdInfoBO.getPrdListPhoto()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getPrdPhoto())) {
			query.addCriteria(Criteria.where("prdPhoto").is(voPrdInfoBO.getPrdPhoto()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getPrdPrice())) {
			query.addCriteria(Criteria.where("prdPrice").is(voPrdInfoBO.getPrdPrice()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getPrdPriceUnit())) {
			query.addCriteria(Criteria.where("prdPriceUnit").is(voPrdInfoBO.getPrdPriceUnit()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getPrdSupply())) {
			query.addCriteria(Criteria.where("prdSupply").is(voPrdInfoBO.getPrdSupply()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getPrdTypeName())) {
			query.addCriteria(Criteria.where("prdTypeName").regex(voPrdInfoBO.getPrdTypeName()));//like
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getPropaganda())) {
			query.addCriteria(Criteria.where("propaganda").is(voPrdInfoBO.getPropaganda()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getProvince())) {
			query.addCriteria(Criteria.where("province").regex(voPrdInfoBO.getProvince())); //like
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getRegisterOperation())) {
			query.addCriteria(Criteria.where("registerOperation").is(voPrdInfoBO.getRegisterOperation()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getRegisterUnit())) {
			query.addCriteria(Criteria.where("registerUnit").is(voPrdInfoBO.getRegisterUnit()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getRegisterValue())) {
			query.addCriteria(Criteria.where("registerValue").is(voPrdInfoBO.getRegisterValue()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getStatus())) {
			query.addCriteria(Criteria.where("status").is(voPrdInfoBO.getStatus()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getUpperLimit())) {
			query.addCriteria(Criteria.where("upperLimit").is(voPrdInfoBO.getUpperLimit()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getUseBeginTime())) {
			query.addCriteria(Criteria.where("useBeginTime").is(voPrdInfoBO.getUseBeginTime()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getUseEndTime())) {
			query.addCriteria(Criteria.where("useEndTime").is(voPrdInfoBO.getUseEndTime()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getUseFrequence())) {
			query.addCriteria(Criteria.where("useFrequence").is(voPrdInfoBO.getUseFrequence()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getValidValue())) {
			query.addCriteria(Criteria.where("validValue").is(voPrdInfoBO.getValidValue()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getValidValueUnit())) {
			query.addCriteria(Criteria.where("validValueUnit").is(voPrdInfoBO.getValidValueUnit()));
		}
		if (StringUtils.isNotBlank(voPrdInfoBO.getPlatformFlag())) {
			query.addCriteria(Criteria.where("platformFlag").is(voPrdInfoBO.getPlatformFlag()));
		}
		/*if(StringUtils.isBlank(voPrdInfoBO.getOrderValue())){
			voPrdInfoBO.setOrderValue("ASC");
		}
		if(StringUtils.isBlank(voPrdInfoBO.getOrderField())){
			voPrdInfoBO.setOrderField("prdTypeSeq");
		}*/
		Sort sort ;
			if (StringUtils.isBlank(voPrdInfoBO.getOrderField())) {// 不传排序，默认按照类型、产品排序
				List<Order> orderList = new ArrayList<Order>();
				Order orderprdTypeSeq = new Order(Direction.ASC, "prdTypeSeq");
				Order orderOrderNum = new Order(Direction.ASC, "orderNum");
				orderList.add(orderprdTypeSeq);
				orderList.add(orderOrderNum);
				sort = new Sort(orderList);
			} else {
				if ("DESC".equals(voPrdInfoBO.getOrderValue())) {
					sort = new Sort(Direction.DESC, voPrdInfoBO.getOrderField());
				} else {
					sort = new Sort(Direction.ASC, voPrdInfoBO.getOrderField());
				}
			}
		response.setResult(repository.getPage(pageNo == 0 ? 1 : pageNo, pageSize == 0 ? 10 : pageSize,
				query, sort, PrdInfoBO.class));
		response.setStatus(Status.SUCCESS);
	} catch (Exception e) {
		logger.error("findPrdInfoBO error:", e);
		response.setStatus(Status.ERROR);
		response.setErrorMsg("从mongodb查询产品数据错误！");
	}
		return response;
	}

	@Override
	public JsonResponse<Void> insertPrdInfoBOByPrdId(String prdId,String prdStock,String usedPrdStock) {
		JsonResponse<Void> response = new JsonResponse<Void>();
		try{
		PrdInfoBO prdInfoBO = new PrdInfoBO();
		//PrdInfo voPrdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		VOPrdInfo voPrdInfo = voPrdInfoMapper.getPrdInfoSeqByIdMongo(prdId);
	    if(voPrdInfo != null){
	    	prdInfoBO.setPrdId(voPrdInfo.getId());
	    	prdInfoBO.setActivationDeadline(voPrdInfo.getActivationDeadline());
	    	prdInfoBO.setActiveOperation(voPrdInfo.getActiveOperation());
	    	prdInfoBO.setActiveUnit(voPrdInfo.getActiveUnit());
	    	prdInfoBO.setActiveValue(voPrdInfo.getActiveValue());
	    	prdInfoBO.setBookUpperLimit(voPrdInfo.getBookUpperLimit());
	    	prdInfoBO.setCity(voPrdInfo.getCity());
	    	prdInfoBO.setCouponName(voPrdInfo.getCouponName());
	    	prdInfoBO.setCouponNo(voPrdInfo.getCouponNo());
	    	prdInfoBO.setCouponStock(voPrdInfo.getCouponStock());
	    	prdInfoBO.setDelFlag(voPrdInfo.getDelFlag());
	    	prdInfoBO.setFreeUseUnit(voPrdInfo.getFreeUseUnit());
	    	prdInfoBO.setFreeUseValue(voPrdInfo.getFreeUseValue());
	    	prdInfoBO.setIsFreeUse(voPrdInfo.getIsFreeUse());
	    	prdInfoBO.setIsFrontShow(voPrdInfo.getIsFrontShow());
	    	prdInfoBO.setIsHolidayOn(voPrdInfo.getIsHolidayOn());
	    	prdInfoBO.setIsNeedInviteValue(voPrdInfo.getIsNeedInviteValue());
	    	prdInfoBO.setIsNeedManyBook(voPrdInfo.getIsNeedManyBook());
	    	prdInfoBO.setIsNeedManyUse(voPrdInfo.getIsNeedManyUse());
	    	prdInfoBO.setIsNeedPassword(voPrdInfo.getIsNeedPassword());
	    	prdInfoBO.setIsSupportBuyOnline(voPrdInfo.getIsSupportBuyOnline());
	    	prdInfoBO.setIsSupportKfyy(voPrdInfo.getIsSupportKfyy());
	    	prdInfoBO.setIsSupportReceiveFree(voPrdInfo.getIsSupportReceiveFree());
	    	prdInfoBO.setIsValidFrom(voPrdInfo.getIsValidFrom());
	    	prdInfoBO.setIsWeekendOn(voPrdInfo.getIsWeekendOn());
	    	if(StringUtils.isNotBlank(voPrdInfo.getMarketPrice())){
	    		prdInfoBO.setMarketPrice(Double.valueOf(voPrdInfo.getMarketPrice()));
	    	}
	    	prdInfoBO.setOnlineDate(voPrdInfo.getOnlineDate());
	    	prdInfoBO.setPrdChannel(voPrdInfo.getPrdChannel());
	    	prdInfoBO.setPrdBeginDate(voPrdInfo.getPrdBeginDate());
	    	prdInfoBO.setPrdEndDate(voPrdInfo.getPrdEndDate());
	    	prdInfoBO.setPrdListPhoto(voPrdInfo.getPrdListPhoto());
	    	prdInfoBO.setPrdPhoto(voPrdInfo.getPrdPhoto());
	    	prdInfoBO.setPrdPrice(voPrdInfo.getPrdPrice());
	    	prdInfoBO.setPrdPriceUnit(voPrdInfo.getPrdPriceUnit());
			prdInfoBO.setPrdSupply(voPrdInfo.getPrdSupply());
			prdInfoBO.setPrdTypeName(voPrdInfo.getPrdTypeName());
			prdInfoBO.setPropaganda(voPrdInfo.getPropaganda());
			prdInfoBO.setProvince(voPrdInfo.getProvince());
			prdInfoBO.setRegisterOperation(voPrdInfo.getRegisterOperation());
			prdInfoBO.setRegisterUnit(voPrdInfo.getRegisterUnit());
			prdInfoBO.setRegisterValue(voPrdInfo.getRegisterValue());
			prdInfoBO.setStatus(voPrdInfo.getStatus());
			prdInfoBO.setUpperLimit(voPrdInfo.getUpperLimit());
			prdInfoBO.setUseBeginTime(voPrdInfo.getUseBeginTime());
			prdInfoBO.setUseEndTime(voPrdInfo.getUseEndTime());
			prdInfoBO.setUseFrequence(voPrdInfo.getUseFrequence());
			prdInfoBO.setValidValue(voPrdInfo.getValidValue());
			prdInfoBO.setValidValueUnit(voPrdInfo.getValidValueUnit());
			prdInfoBO.setCityName(convertCity(voPrdInfo.getCity()));
			prdInfoBO.setPlatformFlag(voPrdInfo.getPlatformFlag());
			if(StringUtils.isNotBlank(usedPrdStock)){
				prdInfoBO.setUsedPrdStock(Integer.parseInt(usedPrdStock)); // 更新已使用库存
			}
			if(StringUtils.isNotBlank(prdStock)){
				prdInfoBO.setCouponStock(Integer.parseInt(prdStock));  //更新总库存
			}
			if(voPrdInfo.getOrderNum() != null){
				prdInfoBO.setOrderNum(voPrdInfo.getOrderNum());
			}else{
				prdInfoBO.setOrderNum(999999999);
			}
			if(voPrdInfo.getPrdTypeSeq() != null){
				prdInfoBO.setPrdTypeSeq(voPrdInfo.getPrdTypeSeq());
			}else{
				prdInfoBO.setPrdTypeSeq(999999999);
			}
			insertPrdInfoBO(prdInfoBO);
	    }
	    response.setStatus(Status.SUCCESS);
	} catch (Exception e) {
		logger.error("insertPrdInfoBOByPrdId error:", e);
		response.setStatus(Status.ERROR);
		response.setErrorMsg("保存产品数据到mongodb错误！");
	}
		return response;
	}

	@Override
	public JsonResponse<Void> insertPrdInfoBOByList(List<PrdInfoBO> prdInfoBOList) {
		JsonResponse<Void> response = new JsonResponse<Void>();
		try {
			for (PrdInfoBO prdInfoBO : prdInfoBOList) {
				String prdId = prdInfoBO.getPrdId();
				String prdStock = String.valueOf(prdInfoBO.getCouponStock());
				String usedPrdStock = String.valueOf(prdInfoBO.getUsedPrdStock());
				insertPrdInfoBOByPrdId(prdId, prdStock, usedPrdStock);
			}
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("insertPrdInfoBOByList error:", e);
			response.setStatus(Status.ERROR);
			response.setErrorMsg("批量保存产品数据到mongodb错误！");
		}
		return response;
	}
	
}
