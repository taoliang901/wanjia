package com.wanjia.dsi.common.constant;

/***
 * 
 * @ClassName: Consts
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author Chenkang
 * @date 2016年3月7日 上午11:27:48
 *
 */
public class Consts {

	/**
	 * 使用redis
	 */
	public static final String CACHE_SWITCH_ON = "1";

	/**
	 * 不使用redis
	 */
	public static final String CACHE_SWITCH_OFF = "0";
	// SYS_DICT_GENDER
	public static final String SYS_DICT_GENDER = "SYS_DICT_GENDER";

	public static String DPT_ROOT = "0";

	public static final String LIST_IN_HOME_PAGE = "LIST_IN_HOME_PAGE";

	public static final String QUERY_AREA_LIST = "QUERY_AREA_LIST";

	public static final String QUERY_AREA_LIST_JAPAN = "QUERY_AREA_LIST_JAPAN";

	public static final String QUERY_AREA_LIST_SINGAPORE = "QUERY_AREA_LIST_SINGAPORE";

	public static final String GET_DEPARTMENT_LIST_INREDIS = "GET_DEPARTMENT_LIST_INREDIS";

	public static final String GET_BANK_LIST = "GET_BANK_LIST";

	public static final String GET_AREA_LIST_FOR_GATEWAY = "GET_AREA_LIST_FOR_GATEWAY";

	public static final String FIND_DEPARTMENT_BY_PARENTIDS = "FIND_DEPARTMENT_BY_PARENTIDS_";

	public static final String All_Department_List = "All_Department_List";

	public static final String GETMAPLIST = "GETMAPLIST";

	// 已删除
	public static final String DEL_FLAG = "1";

	// 未删除
	public static final String NOT_DEL_FLAG = "0";

	// 积分管理
	public static final int AWARD_CODE = 1;// 单次奖励
	public static final int PER_AWARD_CODE = 2;// 按次奖励
	public static final int REDUCE_CODE = 3;// 单次扣除

	/**
	 * 申请关联状态
	 */
	public static final String APPLY_STATUS_ZSDQR = "01";// 诊所待确认
	public static final String APPLY_STATUS_YSDQR = "11";// 医生待确认

	// 诊所账户类型：0、连锁诊所总公司，1、普通/子诊所，2、分公司
	public static final String ACCOUNT_TYPE_F = "0";
	public static final String ACCOUNT_TYPE_C = "1";
	public static final String ACCOUNT_TYPE_B = "2";

	/**
	 * 医生列表操作标示
	 */
	public static final String CLINIC_DOCTOR_PRO_FLAG_AGREE = "agree"; // 同意关联
	public static final String CLINIC_DOCTOR_PRO_FLAG_CANCELCONN = "cancelConn"; // 取消关联
	public static final String CLINIC_DOCTOR_PRO_FLAG_REAPPLY = "reApply"; // 重新申请关联/申请关联
	public static final String CLINIC_DOCTOR_PRO_FLAG_CANCELAPPLY = "cancelApply"; // 取消申请
	public static final String CLINIC_DOCTOR_PRO_FLAG_REFUSE = "refuse"; // 取消申请

	public static final String STRING_ZERO = "0";// 字符串0
	public static final String STRING_ONE = "1";// 字符串1
	public static final String STRING_TWO = "2";// 字符串2
	public static final String STRING_THREE = "3";// 字符串3
	public static final String STRING_FOUR = "4";// 字符串4
	public static final String STRING_BLANK = "";// 空字符串

	/**
	 * 医生信息是否展示该诊所（0：展示，1：不展示）
	 * 
	 */
	public static final String CLINIC_IS_SHOW = "0";
	public static final String CLINIC_IS_NOT_SHOW = "1";

	/**
	 * 医生信息是否优先展示该诊所（0：优先展示，1：不优先展示）
	 * 
	 */
	public static final String CLINIC_IS_PRIORITY_SHOW = "0";
	public static final String CLINIC_IS_NOT_PRIORITY_SHOW = "1";

	/**
	 * 消息标题
	 */
	// public static final String MESSAGE_TOPIC_ZSGL = "诊所关联";
	// public static final String MESSAGE_TOPIC_YSSQGL = "医生申请关联";
	// public static final String MESSAGE_TOPIC_ZSQXGL = "诊所取消申请关联";
	// public static final String MESSAGE_TOPIC_ZSJJGL = "诊所拒绝申请关联";

	public static final String SUCCESS = "success"; // 返回前端状态成功

	public static final String FAILURE = "failure"; // 返回前端状态失败

	/**
	 * 0:会员id类型 1：casUuid类型 2：clinicId类型
	 */
	public static String IS_CLINIC_ID = "2";
	public static String IS_CASUU_ID = "1";
	public static String IS_HY_ID = "0";

	/**
	 * 发布渠道类型： 1:微信,2：B端APP,3:C端APP,4:网站
	 */
	public static final String CHANNEL_TYPE_WX = "1";
	public static final String CHANNEL_TYPE_BD = "2";
	public static final String CHANNEL_TYPE_CD = "3";
	public static final String CHANNEL_TYPE_WZ = "4";

	public static final String SYS_ROLE_PATIENT_VALUE = "1"; // 1
	public static final String SYS_ROLE_DOCTOR_VALUE = "2"; // 2
	public static final String SYS_ROLE_CLINIC_VALUE = "3"; // 3
	public static final String SYS_ROLE_ADMIN_VALUE = "4"; // 4
	public static final String SYS_ROLE_NURSE_VALUE = "5"; // 5

	/**
	 * 1：B端 2：C端 3:B端和C端 4：pc端（PC端定点消息用，app不传）
	 */
	public static final String APP_MESSAGE_TYPE_B = "1"; // B端
	public static final String APP_MESSAGE_TYPE_C = "2"; // C端
	public static final String APP_MESSAGE_TYPE_BC = "3"; // BC端
	public static final String APP_MESSAGE_TYPE_PC = "4"; // PC端

	/**
	 * 1.推送 0.不推送
	 */
	public static final String IS_PUSH = "1"; // 推送
	public static final String IS_NOT_PUSH = "0"; // 不推送

	/**
	 * TYPE_SYSTEM_INFORM("1","系统消息"), TYPE_BUSINESS_INFORM("2","业务消息"),
	 * TYPE_ACTIVITY_INFORM("3","活动消息");
	 */
	public static final String TYPE_SYSTEM_INFORM = "1"; // 系统消息
	public static final String TYPE_BUSINESS_INFORM = "2"; // 业务消息
	public static final String TYPE_ACTIVITY_INFORM = "3"; // 活动消息

	/**
	 * 诊所关联医生状态
	 */
	public static final String CLINIC_DOCTOR_STATUS_DQR = "01"; // 待确认
	public static final String CLINIC_DOCTOR_STATUS_YTY = "02"; // 已同意
	public static final String CLINIC_DOCTOR_STATUS_YJJ = "03"; // 已拒绝
	public static final String CLINIC_DOCTOR_STATUS_YSDQR = "11"; // 医生待确认
	public static final String CLINIC_DOCTOR_STATUS_YSYTY = "12";// 医生已同意
	public static final String CLINIC_DOCTOR_STATUS_YSYJJ = "13";// 医生已拒绝
	public static final String CLINIC_DOCTOR_STATUS_YQXGL = "90"; // 已取消关联
	public static final String CLINIC_DOCTOR_STATUS_QXSQ = "91"; // 已取消申请

	/**
	 * 医生资质审核状态
	 */
	public static final String CLINIC_DOCTOR_CHECK_STATUS_WTJ = "00"; // 未提交
	public static final String CLINIC_DOCTOR_CHECK_STATUS_DSH = "01"; // 待审核
	public static final String CLINIC_DOCTOR_CHECK_STATUS_CSTG = "02"; // 初审通过
	public static final String CLINIC_DOCTOR_CHECK_STATUS_CSTH = "03"; // 初审退回
	public static final String CLINIC_DOCTOR_CHECK_STATUS_FSTG = "12"; // 复审通过
	public static final String CLINIC_DOCTOR_CHECK_STATUS_FSTH = "13"; // 复审退回

	/**
	 * 医生提交来源
	 */
	public static final String CLINIC_DOCTOR_SUBMIT_SOURCE_HY = "0";// 会员提交
	public static final String CLINIC_DOCTOR_SUBMIT_SOURCE_ZS = "1";// 诊所提交
	/**
	 * 医生关联来源
	 */
	public static final String CLINIC_DOCTOR_RESOURCE_ZSXZ = "0"; // 诊所新增
	public static final String CLINIC_DOCTOR_RESOURCE_ZSSQGL = "1"; // 诊所申请关联
	public static final String CLINIC_DOCTOR_RESOURCE_ESSQGL = "2"; // 医生申请关联

	/**
	 * 会员类型
	 */
	public static final String HY_TYPE_PTHY = "1"; // 普通会员
	public static final String HY_TYPE_ES = "2"; // 医生
	public static final String HY_TYPE_ZSGLY = "3"; // 诊所管理员

	/**
	 * 跳转类型参数 跳转H5 - JUMP_01，跳转模块 - JUMP_02，跳转查看详细 - JUMP_03
	 */
	public static final String JUMP_TYPE_H5 = "JUMP_01"; // B端
	public static final String JUMP_TYPE_MODEL = "JUMP_02"; // C端
	public static final String JUMP_TYPE_DETAIL = "JUMP_03"; // BC端

	public static final String SYSTEM = "system";

	public static final String WJ_TITLE = "PRD_WJ_INVOICE_TITLE";
	public static final String JKX_TITLE = "PRD_INVOICE_TITLE";
	public static final String WJ_INVOICE_TITLE_CODE = "PAWJ";
	/**
	 * dubbo接口异常信息
	 *
	 */
	public static final String DUBBO_EXCEPTION_NOSUCCESS = "查询结果失败！";

	// 1 连锁诊所
	public static final String CLINIC_HEADER = "1";
	// 2 单体诊所
	public static final String SINGLE_CLINIC = "2";

	/**
	 * 获取图片缓存路径
	 */
	public static String getPicTempPath(String id) {
		return "/clinic/temp/doctor/" + id.substring(0, 1) + "/" + id + "/license/";
	}

	public static final String PRD_STOCK_PREFIX = ".stock.";

	public static final String PRD_STOCK_UNUSED_PREFIX = ".stock.unused.";
	
	public static final String PRD_STOCK_FULL_NO_PREFIX = ".stock.fullno.";

	public static final String PRD_TOTAL_STOCK_PREFIX = ".stock.total.";

	public static final String PRD_TOTAL_STOCK_ZSET_PREFIX = ".stock.total.zset.";

	public static final String PRD_TOTAL_STOCK_ZSET_USED_PREFIX = ".stock.total.zset.used.";

	public static final String PRD_TOTAL_STOCK_ZSET_UNUSED_PREFIX = ".stock.total.zset.unused.";

	public static final String PRD_TOTAL_STOCK_ZSET_ONLINE_PREFIX = ".stock.total.online.zet";

	public static final String PRD_TOTAL_STOCK_ZSET_ONLINE_USED_PREFIX = ".stock.total.online.used.zet";

	public static final String PRD_TOTAL_STOCK_ZSET_OFFLINE_PREFIX = ".stock.total.offline.zet";

	public static final String PRD_TOTAL_STOCK_ZSET_OFFLINE_USED_PREFIX = ".stock.total.offline.used.zet";

	public static final String PRD_PAYMENT_ZET = ".payment.zset.";

	public static final String PRD_PAYMENT_CANCEL = ".payment.cancel.";

	public static final String QUARTZ = "quartz";

	/**
	 * 分页页码
	 */
	public static final int PAGE_SIZE = 10000;

	/*
	 * public static void main(String args[]){ String aa = "";
	 * if(StringUtils.isNotEmpty(aa)){ System.out.println("aaa"); }else{
	 * System.out.println("bbb"); } }
	 */

}
