/**   
* @Title: ActivityController.java 
* @Package com.wanjia.dsi.web.banner.controller 
* @Description: TODO(用一句话描述该文件做什么) 
* @author CHENKANG560  
* @date 2016年3月1日 下午3:32:07 
* @version V1.0   
*/
package com.wanjia.dsi.web.job.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.controller.BaseWebController;
import com.wanjia.dsi.web.job.model.ClinicSearch;
import com.wanjia.dsi.web.job.model.JobSearch;
import com.wanjia.dsi.web.job.model.TalentJobHot;
import com.wanjia.dsi.web.job.model.TalentJobRecord;
import com.wanjia.dsi.web.job.service.TalentJobHotService;
import com.wanjia.dsi.web.job.service.TalentJobRecordService;
import com.wanjia.dsi.web.job.service.JobService;

/** 
* @ClassName: ActivityController 
* @Description: TODO(这里用一句话描述这个类的作用) 
* @author Chenkang
 * @date 2016年3月1日 下午3:32:07
 * 
 */
@Controller
public class JobTestController extends BaseWebController {

	@Autowired
	private JobService jobService;
	
	@Autowired
	private TalentJobHotService clinicJobHotService;
	
	@Autowired
	private TalentJobRecordService talentJobRecordService;

	@RequestMapping(value = "/job/getAllClinicJobHotList.do")
	@ResponseBody
	public JsonResponse<List<TalentJobHot>> getAllClinicJobHotList(HttpServletRequest request,HttpServletResponse response) {
		TalentJobHot clinicJobHot = new TalentJobHot();
		return clinicJobHotService.getAllClinicJobHotList("web", clinicJobHot);
	}
	
	
	@RequestMapping(value = "/job/getJobSearchList.do")
	@ResponseBody
	public JsonResponse<PageInfo<JobSearch>> getJobSearchList(HttpServletRequest request,HttpServletResponse response) {
		JobSearch jobSearch = new JobSearch();
		jobSearch.setPageNo("1");
		jobSearch.setPageSize("10");
		jobSearch.setSorts("hotPercent:desc");
		return jobService.getJobSearchList("web", jobSearch);
	}
	
	@RequestMapping(value = "/job/getClinicSearchList.do")
	@ResponseBody
	public JsonResponse<PageInfo<ClinicSearch>> getClinicSearchList(HttpServletRequest request,HttpServletResponse response) {
		ClinicSearch clinicSearch = new ClinicSearch();
		clinicSearch.setPageNo("2");
		clinicSearch.setPageSize("10");
		return jobService.getClinicSearchList("web", clinicSearch);
	}
	
	@RequestMapping(value = "/job/getJobSearchDetailById.do")
	@ResponseBody
	public JsonResponse<JobSearch> getJobSearchDetailById(HttpServletRequest request,HttpServletResponse response) {
		String jobId = request.getParameter("id");
		return jobService.getJobSearchDetailById("web", jobId);
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/job/updateClinicJobStatic.do")
	@ResponseBody
	public JsonResponse updateClinicJobStatic(HttpServletRequest request,HttpServletResponse response) {
		return jobService.updateClinicJobStatic();
	}
	
	@RequestMapping(value = "/job/getJobRecordList.do")
	@ResponseBody
	public JsonResponse<List<TalentJobRecord>> getJobRecordList(HttpServletRequest request,HttpServletResponse response) {
		String userId = "70";
		String[] jobIdList = {"1","2","3"};
		return talentJobRecordService.getJobRecordList("", userId, jobIdList);
	}
	

}
