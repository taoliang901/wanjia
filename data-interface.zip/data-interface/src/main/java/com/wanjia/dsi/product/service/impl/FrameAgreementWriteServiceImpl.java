package com.wanjia.dsi.product.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.product.dao.mapper.FrameAgreementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdSubAgreementMapper;
import com.wanjia.dsi.product.model.FrameAgreement;
import com.wanjia.dsi.product.service.FrameAgreementWriteService;




@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class FrameAgreementWriteServiceImpl implements FrameAgreementWriteService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	// 查询产品库存
	@Resource
	private FrameAgreementMapper frameAgreementMapper;

	@Resource
	private PrdAgreementClinicMapper prdAgreementClinicMapper;
	
	@Resource
	private PrdSubAgreementMapper prdSubAgreementMapper;
	
	@Resource
	private PrdAgreementPrdinfoMapper prdAgreementPrdinfoMapper;
	

	@Override
	public void insert(FrameAgreement frameAgreement) {
		frameAgreementMapper.insert(frameAgreement);
		
	}

	@Override
	public void update(FrameAgreement frameAgreement) {
		// TODO Auto-generated method stub
		frameAgreementMapper.update(frameAgreement);
	}

	@Override
	public void deleteById(String id) {
		frameAgreementMapper.deleteById(id);
		
	}

	@Override
	public void deleteFrameAndSub(String id) {
		//框架合同
		FrameAgreement frameAgreement = new FrameAgreement();
		frameAgreement.setId(id);
		frameAgreement.setDelFlag("1");
		frameAgreementMapper.update(frameAgreement);
		//合同诊所关联表
		/*PrdAgreementClinic pc = new PrdAgreementClinic();
		pc.setAgreementId(id);
		pc.setDelFlag("1");*/
		prdAgreementClinicMapper.deleteByAgreementId(id);
		//子合同
		/*PrdSubAgreement psa = new PrdSubAgreement();
		psa.setAgreementId(id);
		psa.setDelFlag("1");*/
		prdSubAgreementMapper.deleteByAgreementId(id);
		//附属合同产品表
		/*PrdAgreementPrdinfo prd = new PrdAgreementPrdinfo();
		prd.setAgreementId(id);
		prd.setDelFlag("1");*/
		prdAgreementPrdinfoMapper.deleteByAgreementId(id);
		
		
	}

	@Override
	public void updateFrameAndSub(FrameAgreement entity) {
		//更新框架合同
		frameAgreementMapper.update(entity);
		//更新子合同状态
		if("2".equals(entity.getStatus())){
			Map<String,Object> params = new HashMap<String,Object>();
			params.put("status", "2");
			params.put("agreementId", entity.getId());
			prdSubAgreementMapper.updateStatusByframeAgreementId(params);
		}
		
	}

	/*@Override
	public void updateFrameAndSubAuto(FrameAgreement entity) {
		//更新框架合同
		frameAgreementMapper.updateAuto(entity);
		//更新子合同状态
		if("2".equals(entity.getStatus())){
			Map<String,Object> params = new HashMap<String,Object>();
			params.put("status", "2");
			params.put("agreementId", entity.getId());
			prdSubAgreementMapper.updateStatusByframeAgreementId(params);
		}
	}*/

	


	
	
}
