package com.wanjia.dsi.web.raffle.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.web.raffle.dao.mapper.RaffleTypeMapper;
import com.wanjia.dsi.web.raffle.model.RaffleType;
import com.wanjia.dsi.web.raffle.service.RaffleTypeService;

/**
 * This element is automatically generated on 16-7-25 上午11:37, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class RaffleTypeServiceImpl implements RaffleTypeService {
	
    @Autowired
    private RaffleTypeMapper raffleTypeMapper;

    @Override
    @Transactional(readOnly=true)
    public RaffleType findById(String id) {
        return (RaffleType)raffleTypeMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleType> findWithPagination(int offset, int count) {
        return (List<RaffleType>)raffleTypeMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleType> findAll() {
        return (List<RaffleType>)raffleTypeMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleType> findByEntity(RaffleType model) {
        return (List<RaffleType>)raffleTypeMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleType> findByEntityWithPagination(RaffleType model, int offset, int count) {
        return (List<RaffleType>)raffleTypeMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public RaffleType findOneByEntity(RaffleType model) {
        return (RaffleType)raffleTypeMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleType> findByProperty(String propertyName, String propertyValue) {
        return (List<RaffleType>)raffleTypeMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public RaffleType findOneByProperty(String propertyName, String propertyValue) {
        return (RaffleType)raffleTypeMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleType> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<RaffleType>)raffleTypeMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleType> findByProperties(Map<String, Object> map) {
        return (List<RaffleType>)raffleTypeMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(RaffleType model) {
        return (long)raffleTypeMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)raffleTypeMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)raffleTypeMapper.countByProperties(map);
    }

    @Override
    public void update(RaffleType model) {
        model.setModifyDate(new Date());
        raffleTypeMapper.update(model);
    }

    @Override
    public void insert(RaffleType model) {
        model.setCreateDate(new Date());
        raffleTypeMapper.insert(model);
    }

    @Override
    public void deleteByEntity(RaffleType model) {
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        raffleTypeMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.raffleTypeMapper.countAll();
    }

    public void insertBatch(List<RaffleType> list) {
        this.raffleTypeMapper.insertBatch(list);
    }

    public void delete(String id) {
        RaffleType model = new RaffleType();
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.raffleTypeMapper.update(model);
    }
}