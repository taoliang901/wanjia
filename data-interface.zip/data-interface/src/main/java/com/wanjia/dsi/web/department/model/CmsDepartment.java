package com.wanjia.dsi.web.department.model;

import java.io.Serializable;
import java.util.Date;

public class CmsDepartment implements Serializable {
    private static final long serialVersionUID = 1L;

    private String cmsDepartmentId;

    private Long publishGroupId;

    private String departmentId;

    private String departmentName;

    private String departmentCode;

    private String departmentDescription;

    private String parentId;

    private Integer publishFlag;

    private Date publishDate;

    private Integer delFlag;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    private Integer orderbyNum;

    private String originalParentId;

    public String getCmsDepartmentId() {
        return cmsDepartmentId;
    }

    public void setCmsDepartmentId(String cmsDepartmentId) {
        this.cmsDepartmentId = cmsDepartmentId;
    }

    public Long getPublishGroupId() {
        return publishGroupId;
    }

    public void setPublishGroupId(Long publishGroupId) {
        this.publishGroupId = publishGroupId;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    public String getDepartmentDescription() {
        return departmentDescription;
    }

    public void setDepartmentDescription(String departmentDescription) {
        this.departmentDescription = departmentDescription;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Integer getPublishFlag() {
        return publishFlag;
    }

    public void setPublishFlag(Integer publishFlag) {
        this.publishFlag = publishFlag;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public Integer getOrderbyNum() {
        return orderbyNum;
    }

    public void setOrderbyNum(Integer orderbyNum) {
        this.orderbyNum = orderbyNum;
    }

    public String getOriginalParentId() {
        return originalParentId;
    }

    public void setOriginalParentId(String originalParentId) {
        this.originalParentId = originalParentId;
    }

   
}