package com.wanjia.dsi.common.interceptors;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;


/*********************************************************************************
//* Copyright (C) 2014 Pingan Haoche (PAHAOCHE). All Rights Reserved.
//*
//* Filename:      IpInterceptor.java
//* Revision:      1.0
//* Author:        黄雷（平安）
//* Created On:    2014年11月18日
//* Modified by:   
//* Modified On:   
//*
//* Description:   对内部请求加入请求来源验证
/********************************************************************************/
public class ParamInterceptor extends HandlerInterceptorAdapter {
	
	public static final String PARAM_APP_SRC="appSrc";

    private Logger logger = Logger.getLogger(ParamInterceptor.class);
    public static final String IPFILTERFLG = "ipFilterFlg";

    /**
     * 验证appSrc参数
     */
  /*  @SuppressWarnings("rawtypes")
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //TODO 
    	String appSrc = request.getParameter(PARAM_APP_SRC);
    	if(null==appSrc){
    		Enumeration<?> headerNames = request.getHeaderNames();
            while(headerNames.hasMoreElements()) {
                String headerName = (String)headerNames.nextElement();
                if(null != headerName && headerName.equals(PARAM_APP_SRC)){
                	appSrc = request.getHeaders(headerName).nextElement();
                	break;
                }
                //同一个请求头名可能出现多次
                
                Enumeration<?> values = request.getHeaders(headerName);
                while(values.hasMoreElements()) {
                    System.out.println(headerName + ":" + (String)values.nextElement() + "<br>");
                }
            }
    	}
        if(StringUtils.isBlank(appSrc)){
        	logger.info("[paramepter missing]");
        	JsonResponse jsonResponse = new JsonResponse();
        	jsonResponse.setErrorCode(ReturnCode.E_2001);
        	jsonResponse.setErrorMsg(ReturnMessage.E_2001_DEFAULT_MSG);
        	ObjectMapper mapper = new ObjectMapper();
        	response.setContentType("text/html;charset="+Consts.UTF_8);
        	response.getWriter().write(mapper.writeValueAsString(jsonResponse));
    		response.getWriter().close();
        	return false;
        }
        return true;
    }
*/
    /*
     * @author Hul
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.web.servlet.handler.HandlerInterceptorAdapter#postHandle
     * (javax.servlet.http.HttpServletRequest,
     * javax.servlet.http.HttpServletResponse, java.lang.Object,
     * org.springframework.web.servlet.ModelAndView)
     */
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }

    /**
     * @param request
     * @param uri
     * @return
     * @throws Exception
     */
    protected ModelAndView prepareModelAndView(HttpServletRequest request, String uri) throws Exception {
        ModelAndView mv = new ModelAndView();
        return mv;
    }

}
