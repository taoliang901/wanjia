package com.wanjia.dsi.web.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.pahaoche.member.util.Tools;

/**
 * 盐值生成器
 * @author qianxin510
 *
 */
public class SaltfigureGenerator {

	/**
	 * openid AES加密盐值生成器
	 * @param openid
	 * @return
	 */
	public static String getAESSaltfigureForOpenid(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String now = sdf.format(new Date());
		return Tools.getMD5Str(now.hashCode()+now);
	}
}
