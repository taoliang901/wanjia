package com.wanjia.dsi.web.home.model;

import java.util.List;

public class InterfaceInfo {

    private String interfaceName;
    private String interfaceUrl;
    private String interfaceParams;
    private String interfaceRequiredParams;
    private int interfaceCount;
    private List<String> interfaceParamList;
	private boolean interfaceDeprecated = false;
    private boolean interfaceEndpoint = false;   

	public int getInterfaceCount() {
		return interfaceCount;
	}

	public void setInterfaceCount(int interfaceCount) {
		this.interfaceCount = interfaceCount;
	}

	public boolean isInterfaceEndpoint() {
		return interfaceEndpoint;
	}

	public void setInterfaceEndpoint(boolean interfaceEndpoint) {
		this.interfaceEndpoint = interfaceEndpoint;
	}

	public boolean isInterfaceDeprecated() {
		return interfaceDeprecated;
	}

	public void setInterfaceDeprecated(boolean interfaceDeprecated) {
		this.interfaceDeprecated = interfaceDeprecated;
	}

	public String getInterfaceRequiredParams() {
		return interfaceRequiredParams;
	}

	public void setInterfaceRequiredParams(String interfaceRequiredParams) {
		this.interfaceRequiredParams = interfaceRequiredParams;
	}

	public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getInterfaceUrl() {
        return interfaceUrl;
    }

    public void setInterfaceUrl(String interfaceUrl) {
        this.interfaceUrl = interfaceUrl;
    }

    public String getInterfaceParams() {
        return interfaceParams;
    }

    public void setInterfaceParams(String interfaceParams) {
        this.interfaceParams = interfaceParams;
    }

	public List<String> getInterfaceParamList() {
		return interfaceParamList;
	}

	public void setInterfaceParamList(List<String> interfaceParamList) {
		this.interfaceParamList = interfaceParamList;
	}

}
