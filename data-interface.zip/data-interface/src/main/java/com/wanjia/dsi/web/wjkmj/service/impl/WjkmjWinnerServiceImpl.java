package com.wanjia.dsi.web.wjkmj.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanjia.dsi.web.wjkmj.dao.mapper.WjkmjWinnerVOMapper;
import com.wanjia.dsi.web.wjkmj.model.WjkmjWinner;
import com.wanjia.dsi.web.wjkmj.service.WjkmjWinnerService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class WjkmjWinnerServiceImpl implements WjkmjWinnerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private WjkmjWinnerVOMapper wjkmjWinnerVOMapper;

	@Override
	public List<WjkmjWinner> findByNameOrAddress(String clinicId, String filterValue, String rankLevel, Integer limit, Integer offset) {

		// 从MYSQL中获取所有报名的诊所以及诊所前一天的投票记录
		Map<String, Object> map = new HashMap<String, Object>();
		if (StringUtils.isNotBlank(clinicId)) {
			map.put("clinicId", clinicId);
		}
		if (StringUtils.isNotBlank(filterValue)) {
			map.put("filterValue", filterValue);
		}
		if (StringUtils.isNotBlank(rankLevel)) {
			map.put("rankLevel", rankLevel);
		}

		if (limit != null) {
			map.put("limit", limit.intValue());
			map.put("offset", offset == null ? 0 : offset);
		}

		return this.wjkmjWinnerVOMapper.findByNameOrAddress(map);
	}
}
