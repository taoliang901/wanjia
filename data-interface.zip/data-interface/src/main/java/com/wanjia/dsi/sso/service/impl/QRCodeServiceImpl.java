package com.wanjia.dsi.sso.service.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.sso.service.QRCodeService;
import com.wanjia.dsi.sso.util.QRCodeErrorCode;
import com.wanjia.dsi.web.hyPerson.dao.mapper.CasUserMapper;
import com.wanjia.dsi.web.hyPerson.model.CasUser;
import com.wanjia.dsi.web.hyPerson.model.CasUserExample;
import com.wanjia.dsi.web.hyPerson.model.CasUserRoleExample;

/**
 * 二维码扫描登录接口
 * 
 * @author LUOXIAOJUN640
 *
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class QRCodeServiceImpl implements QRCodeService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Value("#{kafkaProps['p.topic.qrcode']}")
	private String P_TOPIC_QRCODE;

	@Autowired
	private CommonJedis commonJedis;

	@Autowired
	private CasUserMapper casUserMapper;

	/**
	 * 
	 * 生产登录二维码，并写入输出流
	 * 
	 * @param redisKey
	 *            二维码在redis中的key
	 * @param timeOut
	 *            二维码超时时间
	 * @return
	 */
	public JsonResponse<String> generateLoginQRCode(String redisKey, int timeOut) {
		JsonResponse<String> jr = new JsonResponse<String>();

		if (StringUtils.isEmpty(redisKey)) {
			jr.setStatus(JsonResponse.Status.ERROR);
			jr.setErrorCode(QRCodeErrorCode.INVALID_PARA);
			jr.setErrorMsg("参数【redisKey】不能为空！");
			return jr;
		}

		// 缓存的redisKey至redis中,用于扫描时登录校验
		commonJedis.addObject(redisKey, "init", timeOut + 30);

		return jr;
	}

	/**
	 * 二维码串的key与用户CAS_ID建立关联，并返回用户信息
	 * 
	 * @param redisKey
	 *            二维码在redis中的key
	 * @param casUuid
	 *            登录用户的casUuid
	 * @return
	 */
	public JsonResponse<Void> bindCasUser(String redisKey, String casUuid) {
		JsonResponse<Void> jr = new JsonResponse<Void>();

		if (StringUtils.isEmpty(redisKey)) {
			jr.setStatus(JsonResponse.Status.ERROR);
			jr.setErrorCode(QRCodeErrorCode.INVALID_PARA);
			jr.setErrorMsg("参数【redisKey】不能为空！");
			return jr;
		}

		if (StringUtils.isEmpty(casUuid)) {
			jr.setStatus(JsonResponse.Status.ERROR);
			jr.setErrorCode(QRCodeErrorCode.INVALID_PARA);
			jr.setErrorMsg("参数【casUuid】不能为空！");
			return jr;
		}

		if (commonJedis.exists(redisKey)) {
			// 查询当前casUuid是否有效
			CasUserExample example = new CasUserExample();
			CasUserExample.Criteria criteria = example.createCriteria();
			criteria.andIdEqualTo(casUuid);
			criteria.andDelFlagEqualTo("0");
			List<CasUser> userList = casUserMapper.selectByExample(example);
			if (userList != null && userList.size() == 1) {
				// 还未过期、更新redis中缓存、同时超时时间设置为60秒，并发送登录通知
				commonJedis.putObject(redisKey, casUuid, 120);

				// 发送登录通知
				// 暂时修改为轮询 LUOXIAOJUN640 2016.10.12
				// boolean result = kafkaSyncProducer.producerByString(P_TOPIC_QRCODE, redisKey);
				// if (!result) {
				// 	jr.setStatus(JsonResponse.Status.ERROR);
				// 	jr.setErrorCode(QRCodeErrorCode.QRCODE_LOGIN_NOTICE_FAILED);
				// 	jr.setErrorMsg("绑定成功，消息发送失败【" + redisKey + "】");
				// 	return jr;
				// }
			} else {
				jr.setStatus(JsonResponse.Status.ERROR);
				jr.setErrorCode(QRCodeErrorCode.INVALID_PARA);
				jr.setErrorMsg("参数【casUuid】非法！");
				return jr;
			}
		} else {
			// 已过期
			jr.setStatus(JsonResponse.Status.ERROR);
			jr.setErrorCode(QRCodeErrorCode.QRCODE_EXPIRED);
			jr.setErrorMsg("二维码【" + redisKey + "】已过期！");
		}

		return jr;

	}

	/**
	 * 通过二维码登录
	 * 
	 * @param redisKey
	 *            二维码在redis中的key
	 * @return
	 */
	public JsonResponse<CasUser> loginByQRcode(String redisKey) {
		JsonResponse<CasUser> jr = new JsonResponse<CasUser>();

		if (StringUtils.isEmpty(redisKey)) {
			jr.setStatus(JsonResponse.Status.ERROR);
			jr.setErrorCode(QRCodeErrorCode.INVALID_PARA);
			jr.setErrorMsg("参数【redisKey】不能为空！");
			return jr;
		}

		Object obj = commonJedis.getObject(redisKey);
		if (obj == null) {
			// 已过期
			jr.setStatus(JsonResponse.Status.ERROR);
			jr.setErrorCode(QRCodeErrorCode.QRCODE_EXPIRED);
			jr.setErrorMsg("二维码【" + redisKey + "】已过期！");
			return jr;
		} else {
			CasUserExample example = new CasUserExample();
			CasUserExample.Criteria criteria = example.createCriteria();
			criteria.andIdEqualTo(obj.toString());
			criteria.andDelFlagEqualTo("0");

			List<CasUser> userList = casUserMapper.selectByExample(example);
			if (userList != null && userList.size() == 1) {
				CasUser user = userList.get(0);
				if (user.getStatus() != null && user.getStatus().equals("1")) {
					// 用户有效，获取用户角色列表
					CasUserRoleExample casUserRoleExample = new CasUserRoleExample();
					CasUserRoleExample.Criteria roleCriteria = casUserRoleExample.createCriteria();
					roleCriteria.andUserIdEqualTo(user.getId());
					roleCriteria.andDelFlagEqualTo("0");

					// 用户有效，返回用户信息
					jr.setResult(user);
				} else {
					// 无效的用户ID
					jr.setStatus(JsonResponse.Status.ERROR);
					jr.setErrorCode(QRCodeErrorCode.QRCODE_LOGIN_INVALID_CASUUID);
					jr.setErrorMsg("无效的用户ID[" + obj.toString() + "]！");
					return jr;
				}
			} else {
				// 无效的用户ID
				jr.setStatus(JsonResponse.Status.ERROR);
				jr.setErrorCode(QRCodeErrorCode.QRCODE_LOGIN_INVALID_CASUUID);
				jr.setErrorMsg("无效的用户ID[" + obj.toString() + "]！");
				return jr;
			}
		}

		return jr;
	}
}
