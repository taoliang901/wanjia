package com.wanjia.dsi.web.area.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.web.area.dao.mapper.AreaJapanMapper;
import com.wanjia.dsi.web.area.dao.mapper.AreaSingaporeMapper;
import com.wanjia.dsi.web.area.model.AreaJapan;
import com.wanjia.dsi.web.area.model.AreaSingapore;
import com.wanjia.dsi.web.area.service.AreaForeignService;

/**
 * This element is automatically generated on 16-10-21, do not modify.
 * <br>
 * Service implementation class
 */
@Service
@SuppressWarnings("unchecked")
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class AreaForeignServiceImpl implements AreaForeignService {
	
	@Autowired
	private AreaJapanMapper areaJapanMapper;
	
	@Autowired
	private AreaSingaporeMapper areaSingaporeMapper;

	@Value("#{jedisConfig['expirationTime']}")
	private int expirationTime;

	@Autowired
	private CommonJedis commonJedis;
	
	@Override
	public JsonResponse<List<AreaJapan>> getAllAreaListForJapan() {
		// TODO Auto-generated method stub
		JsonResponse<List<AreaJapan>> result = new JsonResponse<List<AreaJapan>>();

		List<AreaJapan> queryAreaList = new ArrayList<AreaJapan>();

		try {
			//如果在缓存里
			if (commonJedis.exists(Consts.QUERY_AREA_LIST_JAPAN)) {
				queryAreaList = (List<AreaJapan>) commonJedis.getObject(Consts.QUERY_AREA_LIST_JAPAN);
				//如果不存在缓存里
			} else {
				//数据库查询
				queryAreaList = areaJapanMapper.queryAllAreaList();
				//放到缓存
				commonJedis.putObject(Consts.QUERY_AREA_LIST_JAPAN, queryAreaList, expirationTime);
			}
			result.setResult(queryAreaList);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<List<AreaSingapore>> getAllAreaListForSingapore() {
		// TODO Auto-generated method stub
		JsonResponse<List<AreaSingapore>> result = new JsonResponse<List<AreaSingapore>>();

		List<AreaSingapore> queryAreaList = new ArrayList<AreaSingapore>();

		try {
			//如果在缓存里
			if (commonJedis.exists(Consts.QUERY_AREA_LIST_SINGAPORE)) {
				queryAreaList = (List<AreaSingapore>) commonJedis.getObject(Consts.QUERY_AREA_LIST_SINGAPORE);
				//如果不存在缓存里
			} else {
				//数据库查询
				queryAreaList = areaSingaporeMapper.findAllAreaList();
				//放到缓存
				commonJedis.putObject(Consts.QUERY_AREA_LIST_SINGAPORE, queryAreaList, expirationTime);
			}
			result.setResult(queryAreaList);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}


}