package com.wanjia.dsi.product.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.ThreadLocalContext;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.common.utils.StringUtil;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.ProductKucunMapper;
import com.wanjia.dsi.product.model.PrdAgreementPrdinfo;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdInfoExample;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.ProductKucun;
import com.wanjia.dsi.product.service.ProductKucunService;

/**
 * This element is automatically generated on 16-9-21 下午4:20, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class ProductKucunServiceImpl implements ProductKucunService {
    
	private Logger logger = LoggerFactory.getLogger(ProductKucunServiceImpl.class);
	
	@Autowired
    private ProductKucunMapper productKucunMapper;

	@Autowired
	private PrdAgreementPrdinfoMapper prdAgreementPrdinfoMapper;
	
	@Autowired
	private PrdInfoMapper prdInfoMapper;
	
	@Autowired
	private CommonJedis commonJedis;
	
	private final String TOP_CARD_NO="TOP_CARD_NO_%s";
	
	private final int topCardNo = 999999;
	
    @Override
    @Transactional(readOnly=true)
    public ProductKucun findById(Long id) {
        return (ProductKucun)productKucunMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ProductKucun> findWithPagination(int offset, int count) {
        return (List<ProductKucun>)productKucunMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ProductKucun> findAll() {
        return (List<ProductKucun>)productKucunMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<ProductKucun> findByEntity(ProductKucun model) {
        return (List<ProductKucun>)productKucunMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ProductKucun> findByEntityWithPagination(ProductKucun model, int offset, int count) {
        return (List<ProductKucun>)productKucunMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public ProductKucun findOneByEntity(ProductKucun model) {
        return (ProductKucun)productKucunMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ProductKucun> findByProperty(String propertyName, String propertyValue) {
        return (List<ProductKucun>)productKucunMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public ProductKucun findOneByProperty(String propertyName, String propertyValue) {
        return (ProductKucun)productKucunMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ProductKucun> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<ProductKucun>)productKucunMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<ProductKucun> findByProperties(Map<String, Object> map) {
        return (List<ProductKucun>)productKucunMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(ProductKucun model) {
        return (long)productKucunMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)productKucunMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)productKucunMapper.countByProperties(map);
    }

    @Override
    public void update(ProductKucun model) {
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        productKucunMapper.update(model);
    }

    @Override
    public void insert(ProductKucun model) {
        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        productKucunMapper.insert(model);
    }

    @Override
    public void deleteByEntity(ProductKucun model) {
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        productKucunMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.productKucunMapper.countAll();
    }

    public void insertBatch(List<ProductKucun> list) {
        this.productKucunMapper.insertBatch(list);
    }

    public void delete(Long id) {
        ProductKucun model = new ProductKucun();
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.productKucunMapper.update(model);
    }
    
    /**
     * Added by TL 2017-01-17
     * */
    @Override
    public void updateCardBalance(String clinicId,String prdId,String scheduleDate,String cardId){
    	logger.info("-----updateCardBalance-----"+clinicId);
    	logger.info("-----updateCardBalance-----"+prdId);
    	logger.info("-----updateCardBalance-----"+scheduleDate);
    	Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("clinicId", clinicId);
		paramMap.put("prdId", prdId);
		paramMap.put("scheduleDate", scheduleDate);
		PrdAgreementPrdinfo prdModel = new PrdAgreementPrdinfo();
		try{
			prdModel = prdAgreementPrdinfoMapper.searchPrdPriceByParams(paramMap);
			if(prdModel != null){
				ProductKucun productKucun = new ProductKucun();
				productKucun.setId(cardId);
				productKucun.setBalance(prdModel.getPrice());
				
				productKucun.setModifyDate(new Date());
				productKucun.setModifyUser("data-interface");
				productKucunMapper.update(productKucun);
				logger.info("-----update Card Balance ==="+prdModel.getPrice());
				logger.error("-----update Card Balance successful--"+cardId);
			}else{
				logger.error("-----Didn't find contract--");
			}
			
		}catch(Exception e){
			logger.error("-----updateCardBalance----Error-");
			e.printStackTrace();
		}
    }

	@Override
	public JsonResponse<Void> addPrdKuCunNumById(String prdId, String couponNo, String onlineYear, String createUser,
			int addNum, String type) {
		JsonResponse<Void> res = new JsonResponse<Void>();
		
		Random random = new Random();
		int minPW = 10000000;
		int maxPW = 99999999;
		int minIV = 1000;
		int maxIV = 9999;
		
		String pw = "";
		String uuid = "";
		String cardNo = "";
		String allCardNo = "";
		String checkValue = "";
		
		String redisCacheKey = String.format(TOP_CARD_NO, onlineYear.substring(2));
		try{
			String currTopCardNo = productKucunMapper.getTopCardByYear(onlineYear.substring(2));
			if (currTopCardNo == null){
				currTopCardNo = "000000";
			}else{
				currTopCardNo = currTopCardNo.substring(2);
			}
			if(null != commonJedis){
				//jedisCache.removeObject(redisCacheKey);
	            if(commonJedis.exists(redisCacheKey)){
	            	res.setStatus(Status.ERROR);
	            	res.setErrorMsg("其他人员正在生成卡号，请稍后再试！");
	            	return res;
	             
	            }else{
	            	commonJedis.putObject(redisCacheKey, currTopCardNo);
	            	            
	            }
	        }
		
			
			for(int i = 0;i<addNum;i++){
				if (Integer.valueOf(currTopCardNo)+i+1 >= topCardNo){
					res.setStatus(Status.ERROR);
					res.setErrorMsg("已达系统库存上限，请联系管理员！");
					return res;
				}else{
					cardNo = StringUtil.formatStr(String.valueOf(Integer.valueOf(currTopCardNo)+i+1), 6);
					allCardNo = onlineYear.substring(2)+StringUtil.formatStr(String.valueOf(Integer.valueOf(currTopCardNo)+i+1), 6);
				}
				PrdKucun couponDetail = new PrdKucun();
				uuid = UUID.randomUUID().toString();
			    couponNo = getFormatNumber(Long.parseLong(couponNo));

				if("1".equals(type)){
					//有密码，无邀请码
			        int s = random.nextInt(maxPW)%(maxPW-minPW+1) + minPW;
			        pw = String.valueOf(s);
					couponDetail.setCardPassword(pw);
					couponDetail.setCardPasswordMd5(CommonTools.md5(pw));
					
				}else if("2".equals(type)){
					//无密码，有邀请码
			        int s = random.nextInt(maxPW)%(maxPW-minPW+1) + minPW;
			        checkValue = String.valueOf(s);
					couponDetail.setCheckValue(checkValue);
					
				}else if("3".equals(type)){
					//有密码，有邀请码
					int s = random.nextInt(maxPW)%(maxPW-minPW+1) + minPW;
					pw = String.valueOf(s);
					couponDetail.setCardPassword(pw);
					couponDetail.setCardPasswordMd5(CommonTools.md5(pw));
					
					int cv = random.nextInt(maxPW)%(maxPW-minPW+1) + minPW;
					checkValue = String.valueOf(cv);
					couponDetail.setCheckValue(checkValue);
				}
				
				couponDetail.setId(uuid);
				couponDetail.setCouponId(prdId);
				couponDetail.setCardNo(cardNo);
				couponDetail.setAllCardNo(allCardNo);
				
				PrdInfoExample prdInfoExample = new PrdInfoExample();
				prdInfoExample.createCriteria().andIdEqualTo(prdId);
				List<PrdInfo> prdInfoList = prdInfoMapper.selectByExample(prdInfoExample);
				if (CollectionUtils.isNotEmpty(prdInfoList)){
					PrdInfo coupon = prdInfoList.get(0);
					couponDetail.setBalance(coupon.getSettlementValue());
					/*if ("0".equals(coupon.getIsValidFrom())){
						//未激活
						couponDetail.setStatus("2");
					}else{
						//未使用
						couponDetail.setStatus("0");
					}*/
				}
				//未使用
				couponDetail.setStatus("0");
				
				Date date = new Date();
				couponDetail.setCreateDate(date);
				
				couponDetail.setCreateUser(createUser);
				couponDetail.setDelFlag("0");
				productKucunMapper.insert(couponDetail);
				
				//更新缓存内最新的库存
				PrdKucun coupon1 = new PrdKucun();
				coupon1.setCouponId(prdId);
				coupon1.setDelFlag("0");
				long count = productKucunMapper.countByEntity(coupon1);
				
				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_USED_PREFIX, new Double(count), prdId);				
				res.setStatus(Status.SUCCESS);			
			}
			
		}catch(Exception e){
			res.setStatus(Status.ERROR);
			res.setErrorMsg("生成库存失败!");
			logger.error("生成库存失败",e);
		}finally{			
			commonJedis.removeObject(redisCacheKey);
		}

		return res;
		
	}
	
	private static String getFormatNumber(long number){
        String result = "";
        if(number<10){
            result = "0000"+String.valueOf(number);
        }
        else if(number<100&&number>=10){
            result = "000"+String.valueOf(number);
        }
        else if(number<1000&&number>=100){
            result = "00"+String.valueOf(number);
        }
        else if(number<10000&&number>=1000){
            result = "0"+String.valueOf(number);
        }
        else{
            result = String.valueOf(number);
        }
        
        return result;
    }
}