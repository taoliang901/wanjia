package com.wanjia.dsi.web.home.model;

import java.util.ArrayList;
import java.util.List;

public class FlexGridQueryResult<T> {

    /** 结果数据 **/
    private List<T> rows = new ArrayList<T>();
    /** 数据总量 **/
    private long    total;

    /** 每页的记录数量 **/
    private long    page;

    /** 当前的页号 **/
    private long    rp;

    public long getPage() {
        return page;
    }

    public void setPage(long page) {
        this.page = page;
    }

    public long getRp() {
        return rp;
    }

    public void setRp(long rp) {
        this.rp = rp;
    }

    public List<T> getRows() {
        return rows;
    }

    public void setRows(List<T> rows) {
        this.rows = rows;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

}
