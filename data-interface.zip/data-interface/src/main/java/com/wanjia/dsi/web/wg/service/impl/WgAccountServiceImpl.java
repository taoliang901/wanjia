package com.wanjia.dsi.web.wg.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.wg.dao.mapper.WgAccountMapper;
import com.wanjia.dsi.web.wg.model.WgAccount;
import com.wanjia.dsi.web.wg.model.WgResourceAddr;
import com.wanjia.dsi.web.wg.service.WgAccountService;

/**
 * 网关鉴权服务类
 * @author XIONGXING
 *
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class WgAccountServiceImpl implements WgAccountService{

	Logger logger = Logger.getLogger(WgAccountServiceImpl.class);
	@Resource
	private WgAccountMapper wgAccountMapper;
	
	@Override
	public JsonResponse<WgAccount> findWgAccount(String accountId, String authKey) {
		JsonResponse<WgAccount> jresp = new JsonResponse<WgAccount>();
		//校验非空
		if(StringUtils.isBlank(accountId) || StringUtils.isBlank(authKey)){
			jresp.setErrorCode(ErrorType.IllegalArgument.getCode());
			jresp.setErrorMsg(ErrorType.IllegalArgument.getDesc());
			return jresp;
		}
		//查库
		WgAccount record = new WgAccount();
		record.setAccountId(accountId);
		record.setAuthKey(authKey);
		WgAccount wgAccount = wgAccountMapper.findWgAccount(record);
		//校验非空
		if(null == wgAccount){
			jresp.setErrorCode(ErrorType.AuthenticationFailure.getCode());
			jresp.setErrorMsg(ErrorType.AuthenticationFailure.getDesc());
			return jresp;
		}
		//查权限资源
		List<WgResourceAddr> wgResourceAddrList = wgAccountMapper.findWgResourceAddrList(accountId);
		if(wgResourceAddrList.size()==0){
			jresp.setErrorCode(ErrorType.NOTPERMISSION.getCode());
			jresp.setErrorMsg(ErrorType.NOTPERMISSION.getDesc());
			return jresp;
		}
		wgAccount.setWgResourceAddrList(wgResourceAddrList);
		jresp.setResult(wgAccount);
		return jresp;
	}

}
