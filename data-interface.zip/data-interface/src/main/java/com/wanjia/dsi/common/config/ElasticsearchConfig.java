package com.wanjia.dsi.common.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;

import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.Assert;

@Configuration
public class ElasticsearchConfig implements ApplicationContextAware {

	private ApplicationContext applicationContext;

	@Resource
	private Properties elasticsearchProps;

	@Resource
	private Properties serverConstants;

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	/*
	 * @Value("#{elasticsearchProps['server102.cluster.name']}") private String
	 * clusterName;
	 */

	@Bean
	public Client elasticsearchClient() {
		// return
		// NodeBuilder.nodeBuilder().settings(buildNodeSettings()).node().client();

		// String activeProfile =
		// applicationContext.getEnvironment().getActiveProfiles()[0];
		// Assert.hasText(activeProfile);
		String address = elasticsearchProps.getProperty("elasticsearch.server");
		Assert.hasText(address);
		String[] serverList = address.split(",");
		Assert.noNullElements(serverList);

		TransportClient esClient = new TransportClient(buildNodeSettings());

		for (String server : serverList) {
			String[] hostPort = server.split(":");
			esClient.addTransportAddress(new InetSocketTransportAddress(hostPort[0], Integer.parseInt(hostPort[1])));
		}

		return esClient;
	}

	private Settings buildNodeSettings(String activeProfile) {
		Map<String, String> settings = new HashMap<String, String>();
		Set<Object> keySet = elasticsearchProps.keySet();
		for (Object key : keySet) {
			if (key.toString().startsWith(activeProfile)) {
				String settingKey = key.toString()
						.substring(key.toString().indexOf(activeProfile) + activeProfile.length() + 1);
				settings.put(settingKey, elasticsearchProps.get(key).toString());
			}
		}

		ImmutableSettings.Builder builder = ImmutableSettings.settingsBuilder().put("cluster.name", "pawanjia_es")
				.put(settings);
		return builder.build();
	}

	private Settings buildNodeSettings() {
		Map<String, String> settings = new HashMap<String, String>();
		Set<Object> keySet = elasticsearchProps.keySet();
		for (Object key : keySet) {
			settings.put(key.toString(), elasticsearchProps.get(key).toString());
		}

		ImmutableSettings.Builder builder = ImmutableSettings.settingsBuilder().put(settings);
		return builder.build();
	}

}