package com.wanjia.dsi.web.callCenter.service.impl;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.web.callCenter.dao.mapper.IssueMapper;
import com.wanjia.dsi.web.callCenter.dao.mapper.IssueOBInfoMapper;
import com.wanjia.dsi.web.callCenter.model.Issue;
import com.wanjia.dsi.web.callCenter.model.IssueOBInfo;
import com.wanjia.dsi.web.callCenter.service.IssueOBInfoService;



/**
 * This element is automatically generated on 16-8-3 下午8:14, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class IssueOBInfoServiceImpl extends BaseServiceImpl implements IssueOBInfoService {
   
	
	@Autowired
    private IssueOBInfoMapper issueOBInfoMapper;
    
	@Autowired
    private IssueMapper issueMapper;
	
    
    @Override
    public void createUploadIssueForPrd(List<Issue> issueList,List<IssueOBInfo> oblist){
    	issueMapper.insertBatch(issueList);
    	
    	insertBatch(oblist);
    	
    }


	@Override
	public IssueOBInfo findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<IssueOBInfo> findWithPagination(int offset, int count) {
		
		return issueOBInfoMapper.findWithPagination(offset, count);
	}


	@Override
	public List<IssueOBInfo> findAll() {
		
		return issueOBInfoMapper.findAll();
	}


	@Override
	public List<IssueOBInfo> findByEntity(IssueOBInfo model) {
		
		return issueOBInfoMapper.findByEntity(model);
	}


	@Override
	public List<IssueOBInfo> findByEntityWithPagination(IssueOBInfo model,
			int offset, int count) {
		
		return issueOBInfoMapper.findByEntityWithPagination(model, offset, count);
	}


	@Override
	public IssueOBInfo findOneByEntity(IssueOBInfo model) {
		
		return (IssueOBInfo) issueOBInfoMapper.findOneByEntity(model);
	}


	@Override
	public List<IssueOBInfo> findByProperty(String propertyName,
			String propertyValue) {
		
		return issueOBInfoMapper.findByProperty(propertyName,propertyValue);
	}


	@Override
	public IssueOBInfo findOneByProperty(String propertyName,
			String propertyValue) {
		
		return (IssueOBInfo) issueOBInfoMapper.findOneByProperty(propertyName, propertyValue);
	}


	@Override
	public List<IssueOBInfo> findByPropertyWithPagination(String propertyName,
			String propertyValue, int offset, int count) {
		
		return issueOBInfoMapper.findByPropertyWithPagination(propertyName, propertyValue, offset, count);
	}


	@Override
	public List<IssueOBInfo> findByProperties(Map<String, Object> map) {
		
		return issueOBInfoMapper.findByProperties(map);
	}


	@Override
	public long countByEntity(IssueOBInfo model) {
		
		return issueOBInfoMapper.countByEntity(model);
	}


	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		
		return issueOBInfoMapper.countByProperty(propertyName, propertyValue);
	}


	@Override
	public long countByProperties(Map<String, Object> map) {
		
		return issueOBInfoMapper.countByProperties(map);
	}


	@Override
	public void update(IssueOBInfo model) {
		issueOBInfoMapper.update(model);
	}


	@Override
	public void insert(IssueOBInfo model) {
		issueOBInfoMapper.insert(model);
	}


	@Override
	public void deleteByEntity(IssueOBInfo model) {
		issueOBInfoMapper.deleteByEntity(model);
		
	}


	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		issueOBInfoMapper.deleteByProperty(propertyName, propertyValue);
		
	}


	@Override
	public long countAll() {
		return issueOBInfoMapper.countAll();
	}


	@Override
	public void insertBatch(List<IssueOBInfo> list) {
		issueOBInfoMapper.insertBatch(list);
		
	}


	@Override
	public void delete(String id) {
		issueOBInfoMapper.deleteById(id);
		
	}
   
}