/**
 * 
 */
package com.wanjia.dsi.common.error;

/**
 * 网站服务错误类型
 * 
 * @author Chenkang
 * 
 */
public enum ErrorType {

	IllegalArgument("E001",	"参数不合法"),
	RepeatSubmit("E002","重复提交"),
	TransActionNotExist("E003","交易不存在"),
	BusinessLogicError("E004","业务逻辑错误"),
	DatabaseExecuteException("E005","数据库执行异常"),
	InternalInterfaceInteraction("E006","内部接口交互异常"),
	AccountInformationNotExist("E007","账户信息不存在"),
	AuthenticationFailure("E008","认证失败"),
	MustPassParameter("E009","必传参数"),
	ExpiredData("E010","过期数据"),
	SystemError("E011","系统错误"),
	RunTimeException("E012","运行期异常"),
	UserNameOrPasswordError("E013","用户名或密码错误"),
	Timeout("E014","登陆超时请重新登陆"),
	BackgroundDataFailure("E015","后台数据较验失败"),
	DataTransmissionException("E016","数据传输异常"),
	SystemBusy("E017","系统繁忙"),
	AccountLoggedOtherTerminal("E018","该账号已在别外终端登录"),
	ResponseNullMessage("E019","返回值为空"),
	GetDataError("E020","获取数据失败"),
	MobilePatternError("E021","手机号码格式不正确！"),
	CodeGetError("E022","获取验证码失败，请从新再试！"),
	CodeGetTooMuch("E023","验证码获取次数过多，请稍后再试！"),
	ObjectIsNull("E024","所传对象为空！"),
	IdIsNull("E025","所传对象主键为空！"),
	NOTPERMISSION("E026", "无权限访问"),
	CHECKCODEERROR("E027", "验证码错误"),
	ReciveMismatching("E028","邀请码有误，请重新输入！"),
	ReciveFail("E029","领取失败！"),
	HaveNoAmount("E030","已领完！"),
	ReciveSuccess("E031","领取成功！"),
	Recived("E032","已领取，不能再领取了！"),
	NoRecive("E033","该产品不能领取，请选择其他产品！"),
	UserIdisNull("E034","用户id不能为空！"),
	NotEnoughPrdKucun("E035","库存不足"),
	Other("E099","其它");
	
	private String code;

	private String desc;

	/**
	 * @param code
	 * @param desc
	 */
	private ErrorType(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public static String getExtNameByCode(String code) {
		for (ErrorType e : ErrorType.values()) {
			if (e.getCode().equals(code)) {
				return e.desc;
			}
		}
		return null;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc
	 *            the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

}
