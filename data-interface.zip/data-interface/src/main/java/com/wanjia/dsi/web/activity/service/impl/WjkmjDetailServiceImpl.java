package com.wanjia.dsi.web.activity.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.web.activity.dao.mapper.WjkmjDetailMapper;
import com.wanjia.dsi.web.activity.model.WjkmjDetail;
import com.wanjia.dsi.web.activity.service.WjkmjDetailService;

/**
 * This element is automatically generated on 16-3-1 ����3:16, do not modify.
 * <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class WjkmjDetailServiceImpl extends BaseServiceImpl implements WjkmjDetailService {

	@Autowired
	private WjkmjDetailMapper wjkmjDetailMapper;

	@Override
	public WjkmjDetail findById(String id) {
		return (WjkmjDetail) this.wjkmjDetailMapper.findById(id);
	}

	@Override
	public List<WjkmjDetail> findWithPagination(int offset, int count) {
		return (List<WjkmjDetail>) this.wjkmjDetailMapper.findWithPagination(offset, count);
	}

	@Override
	public List<WjkmjDetail> findAll() {
		return (List<WjkmjDetail>) this.wjkmjDetailMapper.findAll();
	}

	@Override
	public List<WjkmjDetail> findByEntity(WjkmjDetail model) {
		return this.wjkmjDetailMapper.findByEntity(model);
	}

	@Override
	public List<WjkmjDetail> findByEntityWithPagination(WjkmjDetail model, int offset, int count) {
		return this.wjkmjDetailMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	public WjkmjDetail findOneByEntity(WjkmjDetail model) {
		return (WjkmjDetail) this.wjkmjDetailMapper.findOneByEntity(model);
	}

	@Override
	public List<WjkmjDetail> findByProperty(String propertyName, String propertyValue) {
		return this.wjkmjDetailMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	public WjkmjDetail findOneByProperty(String propertyName, String propertyValue) {
		return (WjkmjDetail) this.wjkmjDetailMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	public List<WjkmjDetail> findByPropertyWithPagination(String propertyName, String propertyValue, int offset,
			int count) {
		return this.wjkmjDetailMapper.findByPropertyWithPagination(propertyName, propertyValue, offset, count);
	}

	@Override
	public List<WjkmjDetail> findByProperties(Map<String, Object> map) {
		return this.wjkmjDetailMapper.findByProperties(map);
	}

	@Override
	public long countByEntity(WjkmjDetail model) {
		return this.wjkmjDetailMapper.countByEntity(model);
	}

	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		return this.wjkmjDetailMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	public long countByProperties(Map<String, Object> map) {
		return this.wjkmjDetailMapper.countByProperties(map);
	}

	@Override
	public void update(WjkmjDetail model) {
		this.wjkmjDetailMapper.update(model);
	}

	@Override
	public void insert(WjkmjDetail model) {
		this.wjkmjDetailMapper.insert(model);
	}

	@Override
	public void deleteByEntity(WjkmjDetail model) {
		this.wjkmjDetailMapper.deleteByEntity(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		this.wjkmjDetailMapper.deleteByProperty(propertyName, propertyValue);
	}

	@Override
	public long countAll() {
		return this.wjkmjDetailMapper.countAll();
	}

	@Override
	public void insertBatch(List<WjkmjDetail> list) {
		this.wjkmjDetailMapper.insertBatch(list);
	}

	@Override
	public void delete(String id) {
		this.wjkmjDetailMapper.deleteById(id);
	}
}