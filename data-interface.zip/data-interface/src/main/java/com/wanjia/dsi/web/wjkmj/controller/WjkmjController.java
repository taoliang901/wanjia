package com.wanjia.dsi.web.wjkmj.controller;

import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.controller.BaseWebController;
import com.wanjia.dsi.base.invoker.Invoker;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.activity.model.WjkmjDetail;
import com.wanjia.dsi.web.activity.service.WjkmjDetailService;
import com.wanjia.dsi.web.wjkmj.model.WjkmjDayCount;
import com.wanjia.dsi.web.wjkmj.model.WjkmjDiaryBO;
import com.wanjia.dsi.web.wjkmj.service.WjkmjService;

@Controller
@RequestMapping(value = "/wjkmj", method = { RequestMethod.POST, RequestMethod.GET })
public class WjkmjController extends BaseWebController {

	// 日志类
	private static final Logger logger = Logger.getLogger(WjkmjController.class);

	@Autowired
	private WjkmjService wjkmjService;

	@Autowired
	private WjkmjDetailService wjkmjDetailService;

	// 添加投票测试，多线程变量
	private volatile int clinicIndex, ipIndex;

	private Lock lock = new ReentrantLock();

	@RequestMapping("/clinic/getList")
	@ResponseBody
	public JsonResponse<PageInfo<WjkmjDayCount>> getList(HttpServletRequest request, HttpServletResponse response) {
		logger.info("==============获取开幕节诊所列表===================");

		// 根据日期获取当前投票参与活动的诊所
		Date voteDate = new Date();
		String ip = "10.101.10.10";

		JsonResponse<PageInfo<WjkmjDayCount>> data = wjkmjService.getWjkmjDayCountShowList(Invoker.web.getValue(), new WjkmjDayCount(),
				voteDate, ip, "twd.CREATE_DATE asc", 50, 1);
		
		
		wjkmjService.getWjkmjDayCountShowList(Invoker.web.getValue(), voteDate, ip, null, "twd.CREATE_DATE asc", "10");

		logger.info("==============获取开幕节诊所列表 END ===================");
		Date nowDate = new Date();
		logger.info("============== 获取开幕节诊所列表 Cost ===================" + (nowDate.getTime() - voteDate.getTime()));

		return data;
	}

	@RequestMapping("/voteTest")
	@ResponseBody
	public JsonResponse<Void> voteTest(HttpServletRequest request, HttpServletResponse response) {
		logger.info("==============对万家开幕节投票===================");

		JsonResponse<Void> data = new JsonResponse<Void>();

		ArrayBlockingQueue<Runnable> queue = new ArrayBlockingQueue<Runnable>(70000);

		ThreadPoolExecutor threadPool = new ThreadPoolExecutor(30, 30, 30, TimeUnit.SECONDS, queue,
				new ThreadPoolExecutor.DiscardOldestPolicy());

		// 根据日期获取当前投票参与活动的诊所
		final Date voteDate = new Date();
		final String voteDateFmt = DateUtils.format(voteDate, DateUtils.DATE_FORMAT_TYPE3);
		
		clinicIndex = 1;
		ipIndex = 2;
		for (int i = 2; i < 254; i++) {
			for (int j = 2; j < 254; j++) {
				threadPool.execute(new Runnable() {
					public void run() {

						int ip3 = ipIndex / 254;
						int ip4 = ipIndex % 254;

						String ip = "10.101." + ip3 + "." + ip4;
						String clinicId = "cdd2ba07-3735-45e7-b662-4699a1a" + clinicIndex;
						if (clinicIndex >= 1000) {
							clinicIndex = 1;
						}

						lock.lock();
						ipIndex++;
						clinicIndex++;
						lock.unlock();

						WjkmjDiaryBO wjkmjDiaryBO = new WjkmjDiaryBO();
						wjkmjDiaryBO.setClinicId(clinicId);
						wjkmjDiaryBO.setClinicName("开幕节测试诊所" + clinicIndex);
						wjkmjDiaryBO.setVoteDate(voteDate);
						wjkmjDiaryBO.setVoteDateOfDay(voteDateFmt);
						wjkmjDiaryBO.setUserIp(ip);

						wjkmjService.insertWjkmjDiaryBO(Invoker.web.getValue(), wjkmjDiaryBO);
					}
				});
			}
		}

		return data;
	}

	@RequestMapping("/addWjkmjClinicTest")
	@ResponseBody
	public JsonResponse<Void> addWjkmjClinicTest(HttpServletRequest request, HttpServletResponse response) {
		logger.info("==============添加开幕节参与诊所===================");

		for (int j = 1; j <= 1000; j++) {

			WjkmjDetail detail = new WjkmjDetail();
			detail.setId(CommonTools.generateUUID());

			String clinicId = "cdd2ba07-3735-45e7-b662-4699a1a" + j;
			detail.setClinicId(clinicId);

			String clinicName = "开幕节测试诊所" + j;
			detail.setClinicName(clinicName);
			detail.setCreateDate(new Date());
			detail.setCreateUser("System_BB");
			detail.setDelFlag("1");

			wjkmjDetailService.insert(detail);
		}

		return new JsonResponse<Void>();
	}

	@RequestMapping("/updateByDailyTest")
	@ResponseBody
	public JsonResponse<Void> updateByDaily(HttpServletRequest request, HttpServletResponse response) {
		logger.info("==============从MongoDB中获取当天记录并存入MYSQL===================");

		Date voteDate = new Date();
		String voteDateFmt = request.getParameter("voteDate");
		if (voteDateFmt != null) {
			try {
				voteDate = DateUtils.parse(voteDateFmt, DateUtils.DATE_FORMAT_TYPE3);
			} catch (Exception ex) {
				// Ignore
				voteDate = new Date();
			}
		}

		JsonResponse<Void> data = wjkmjService.updateWjkmjToday(Invoker.web.getValue(), voteDate);
		return data;
	}
}
