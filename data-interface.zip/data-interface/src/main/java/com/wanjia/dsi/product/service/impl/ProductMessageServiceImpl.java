package com.wanjia.dsi.product.service.impl;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pinganwj.clinic.api.ApptService;
import com.pinganwj.clinic.api.ProductApptApi;
import com.pinganwj.clinic.api.domain.appt.ApptRecordInfo;
import com.pinganwj.clinic.api.domain.appt.ApptRecordQueryReq;
import com.pinganwj.clinic.api.domain.appt.ApptRecordQueryRsp;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderDetailMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderDetailServiceMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderMapper;
import com.wanjia.dsi.product.dao.mapper.PrdServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdClinicMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdOrderDetailServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdServiceMapper;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.PrdKucunExample;
import com.wanjia.dsi.product.model.PrdOrder;
import com.wanjia.dsi.product.model.PrdOrderDetail;
import com.wanjia.dsi.product.model.PrdOrderDetailService;
import com.wanjia.dsi.product.model.PrdService;
import com.wanjia.dsi.product.model.PrdServiceExample;
import com.wanjia.dsi.product.model.VOMyProductDetail;
import com.wanjia.dsi.product.service.MyProductDetailService;
import com.wanjia.dsi.product.service.ProductMessageService;
import com.wanjia.dsi.product.service.RecivePrdFromCodeService;
import com.wanjia.dsi.product.service.StockService;
import com.wanjia.dsi.product.vo.VOClinicParentInfo;
import com.wanjia.dsi.product.vo.VOPrdAllClinics;
import com.wanjia.dsi.product.vo.VOPrdClinic;
import com.wanjia.dsi.product.vo.VOPrdKucun;
import com.wanjia.dsi.product.vo.VOPrdService;
import com.wanjia.dsi.web.clinic.dao.mapper.VOClinicMapper;
import com.wanjia.dsi.web.clinic.model.Clinic;
import com.wanjia.dsi.web.clinic.model.VOClinicProduct;
import com.wanjia.dsi.web.clinic.model.VoClinic;
import com.wanjia.dsi.web.clinic.service.ClinicService;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyClinicInfoMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyClinicRegisterMapper;
import com.wanjia.dsi.web.hyPerson.model.HyClinicInfo;
import com.wanjia.dsi.web.hyPerson.model.HyClinicRegister;

/**
 * 产品信息service
 * 
 * @author FANGYUNLONG278
 *
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class ProductMessageServiceImpl implements ProductMessageService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	// 查询产品信息
//	@Resource
//	private CouponMapper couponMapper;

	// 查询产品库存
	@Resource
	private VOPrdKucunMapper vOPrdKucunMapper;

	// 查询产品诊所
	@Resource
	private VOPrdClinicMapper vOPrdClinicMapper;

	// 产品服务项目查询
	@Resource
	private VOPrdServiceMapper vOPrdServiceMapper;

	// 产品冗余服务项目查询
	@Resource
	private VOPrdOrderDetailServiceMapper vOPrdOrderDetailServiceMapper;

	// 国才接口
	@Autowired
	private RecivePrdFromCodeService recivePrdFromCodeService;

	// 小乐接口
	@Autowired
	private MyProductDetailService myProductDetailService;

	// 深圳预约接口
	@Autowired
	private ApptService apptService;

	// 库存查询接口（自动生成）
	@Autowired
	private PrdKucunMapper prdKucunMapper;

	// 产品查询接口（自动生成）
	@Autowired
	private PrdInfoMapper prdInfoMapper;

	// 产品订单接口（自动生成）
	@Autowired
	private PrdOrderMapper prdOrderMapper;

	// 产品订单冗余接口（自动生成）
	@Autowired
	private PrdOrderDetailMapper prdOrderDetailMapper;

	// 产品订单服务接口（自动生成）
	@Autowired
	private PrdServiceMapper prdServiceMapper;

	// 产品订单服务冗余接口（自动生成）
	@Autowired
	private PrdOrderDetailServiceMapper prdOrderDetailServiceMapper;

	// 产品信息接口（自动生成）
	@Autowired
	private HyClinicInfoMapper clinicInfoMapper;
	
	// 产品注册信息接口（自动生成）
	@Autowired
	private HyClinicRegisterMapper clinicRegisterMapper;
		
	@Autowired
	private ClinicService clinicService;
	
	@Autowired
	private VOClinicMapper voClinicMapper;
	
	// 深圳产品接口
	@Autowired
	private ProductApptApi productApptApi;
	
	@Autowired
	private  VOPrdInfoMapper voPrdInfoMapper;
	
	@Autowired
	private StockService stockService;
	
	@Override
	public JsonResponse<VOPrdKucun> findKucunbyMsg(String cardNo, String cardPassword, String prdKucunId, String flag) {

		JsonResponse<VOPrdKucun> res = new JsonResponse<VOPrdKucun>();
		// 1、校验卡号、密码 or 卡ID
		VOPrdKucun kucun = null;
		if (StringUtils.isBlank(flag)) {
			throw new ServiceException(null, "【新增标志位】不能为空！");
		}
		if ("1".equals(flag)) {
			if (StringUtils.isBlank(cardNo)) {
				throw new ServiceException(null, "【卡号】不能为空！");
			}
			if (StringUtils.isBlank(cardPassword)) {
				throw new ServiceException(null, "【密码】不能为空！");
			}
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("delFlag", "0");
			param.put("cardNo", cardNo);
			try {
				param.put("cardPasswordMd5", CommonTools.md5(cardPassword));
			} catch (NoSuchAlgorithmException e) {
				throw new ServiceException(null, "对密码MD5加密异常！");
			}
			List<VOPrdKucun> couponList = vOPrdKucunMapper.selectByMap(param);
			if (couponList == null || couponList.size() == 0) {
				throw new ServiceException(null, "信息有误");
			}
			if (couponList.size() > 1) {
				throw new ServiceException(null, "根据【卡号或密码】查到多张卡，请与系统管理员系统！");
			}
			kucun = couponList.get(0);
		} else {
			if (StringUtils.isBlank(prdKucunId)) {
				throw new ServiceException(null, "【卡库存Id】不能为空！");
			}
			kucun = vOPrdKucunMapper.selectByPrimaryKey(prdKucunId);
			if (kucun == null) {
				throw new ServiceException(null, "信息有误");
			}
		}
		// 卡是否有效
		checkCardValid(kucun);
		res.setStatus(Status.SUCCESS);
		res.setResult(kucun);
		return res;
	}

	// 需判断卡是否有效（最初预约记录后推N年，或固定写死有效期）
	// 需判断卡对应产品是否上线
	// 卡是否有效
	private void checkCardValid(VOPrdKucun kucun) {
		Date end = kucun.getValidEndDate();
		Date now = new Date();
		if (end != null) {
			String endStr = CommonTools.dateToString(end, "yyyy-MM-dd");
			String nowStr = CommonTools.dateToString(now, "yyyy-MM-dd");
			if (nowStr.compareTo(endStr) > 0) {
				throw new ServiceException(null, "卡已过期");
			}
		}
		// 卡对应产品是否上线（先冗余表，再产品表）
		if (kucun.getCouponDetailStatus() != null) {
			if (!"0".equals(kucun.getCouponDetailStatus())) {
				throw new ServiceException(null, "该产品【" + kucun.getCouponName() + "】未上线");
			}
		} else {
			if (!"0".equals(kucun.getCouponStatus())) {
				throw new ServiceException(null, "该产品【" + kucun.getCouponName() + "】未上线");
			}
		}
	}

	@Override
	public JsonResponse<VOPrdAllClinics> findClinicsByProduct(String couponId,String userId,String kucunId,String excludeApptOrderCode,String prdServiceId) {
		// 返回值
		JsonResponse<VOPrdAllClinics> res = new JsonResponse<VOPrdAllClinics>();
		VOPrdAllClinics vOPrdAllClinics = new VOPrdAllClinics();

		// 1、查询该产品对应的可选的【诊所总账户、城市、诊所】列表
		Map<String, Object> p2 = new HashMap<String, Object>();
		p2.put("delFlag", "0");
		p2.put("couponId", couponId);
		p2.put("orderByClause",
				"CONVERT(parentAccountName USING GBK) ASC, CONVERT(city USING GBK) ASC, CONVERT(district USING GBK) ASC, CONVERT(clinicName USING GBK) ASC, id");
		List<VOPrdClinic> clinicList =  null;
		List<String> clinicIdList = getClinicId(couponId);  //得到合同和产品对应的诊所id
		List<String> clinicIdListAfter = new ArrayList<String>();
		
		// 根据绑定诊所重新过滤诊所ID
		if(StringUtils.isNotBlank(prdServiceId)){
			clinicIdListAfter = filterClinicId(couponId, clinicIdList, clinicIdListAfter, kucunId, userId,excludeApptOrderCode,prdServiceId);
//		}else{
//			clinicIdListAfter = filterClinicIdForGateway(couponId, clinicIdList, clinicIdListAfter, kucunId, userId, excludeApptOrderCode);
		}
				
		if(clinicIdListAfter != null && clinicIdListAfter.size() >0){
			clinicList = vOPrdClinicMapper.getCLinicAdressById(clinicIdListAfter); //通过诊所id查询诊所信息和地址
		}
		List<VOPrdClinic> cityList = new ArrayList<VOPrdClinic>();
		List<VOPrdClinic> districtList = new ArrayList<VOPrdClinic>();
		List<VOPrdClinic> parentAccountList = new ArrayList<VOPrdClinic>();
		if (clinicList != null) {
			String parentAccount_pre = ""; // parentAccountId
			String cityId_pre = ""; // parentAccountId_cityCode
			String districtId_pre = ""; // parentAccountId_cityCode_districtCode
			for (int i = 0; i < clinicList.size(); i++) {
				VOPrdClinic clinicVo = clinicList.get(i);
				if (!parentAccount_pre.equals(clinicVo.getParentAccountId())) {
					parentAccountList.add(clinicVo);
					parentAccount_pre = clinicVo.getParentAccountId();
				}
				if (!cityId_pre.equals(clinicVo.getParentAccountId() + "_" + clinicVo.getCityCode())) {
					cityList.add(clinicVo);
					cityId_pre = clinicVo.getParentAccountId() + "_" + clinicVo.getCityCode();
				}
				if (!districtId_pre.equals(clinicVo.getParentAccountId() + "_" + clinicVo.getCityCode() + "_"
						+ clinicVo.getDistrictCode())) {
					districtList.add(clinicVo);
					districtId_pre = clinicVo.getParentAccountId() + "_" + clinicVo.getCityCode() + "_"
							+ clinicVo.getDistrictCode();
				}
			}
		}
		
		vOPrdAllClinics.setParentAccountList(parentAccountList);
		vOPrdAllClinics.setCityList(cityList);
		vOPrdAllClinics.setDistrictList(districtList);
		vOPrdAllClinics.setClinicList(clinicList);

		res.setStatus(Status.SUCCESS);
		res.setResult(vOPrdAllClinics);
		return res;
	}
	
	@Override
	public JsonResponse<List<VOPrdService>> findPrdServiceList(String couponId) {
		// 返回值
		JsonResponse<List<VOPrdService>> res = new JsonResponse<List<VOPrdService>>();
		List<VOPrdService> prdServiceList = new ArrayList<VOPrdService>();

		// 填充【服务项目】列表
		Map<String, Object> p3 = new HashMap<String, Object>();
		p3.put("delFlag", "0");
		p3.put("prdId", couponId);
		prdServiceList = vOPrdServiceMapper.selectByMap(p3);
		res.setStatus(Status.SUCCESS);
		res.setResult(prdServiceList);
		return res;
	}

	@Override
	public JsonResponse<Set<String>> findHyUsers(String kucunId) {
		// 返回值
		JsonResponse<Set<String>> res = new JsonResponse<Set<String>>();
		Set<String> bookedMemberIdList = new HashSet<String>();

		ApptRecordQueryReq req5 = new ApptRecordQueryReq();
		req5.setCardId(kucunId);
		req5.setApptStatus("1,2,3,4,5,8,9");
		logger.info("ProductMessageService.findHyUsers开始" + kucunId);
		com.pinganwj.clinic.api.domain.JsonResponse<ApptRecordQueryRsp> queryResult = apptService.getApptRecord(req5);
		if (!"SUCCESS".equals(queryResult.getStatus().toString())) {
			logger.error("调用dubbo接口失败：apptService.getApptRecord()");
			throw new ServiceException(null, queryResult.getErrorMsg());
		}
		ApptRecordQueryRsp rsp = queryResult.getResult();
		logger.info("ProductMessageService.findHyUsers成功");
		List<ApptRecordInfo> orders_visited = rsp.getApptRecords();
		if (orders_visited != null && orders_visited.size() > 0) {

			for (int i = 0; i < orders_visited.size(); i++) {
				ApptRecordInfo item = orders_visited.get(i);
				bookedMemberIdList.add(item.getUserId());
			}
		}
		res.setStatus(Status.SUCCESS);
		res.setResult(bookedMemberIdList);
		return res;
	}

	@Override
	public JsonResponse<String> receiveProduct(String couponId, String userId) {
		// 返回结果
		JsonResponse<String> result = new JsonResponse<String>();

		// 查询产品信息
		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(couponId);
		// 验证码产品才允许抽奖领取
		if ("0".equals(prdInfo.getIsSupportReceiveFree())) {
			// 查询未使用的库存信息
			PrdKucunExample kucunExample = new PrdKucunExample();
			PrdKucunExample.Criteria kucunCriteria = kucunExample.createCriteria();
			kucunCriteria.andCouponIdEqualTo(couponId);
			kucunCriteria.andDelFlagEqualTo("0");
			kucunCriteria.andBuyerUserIdIsNull();
			kucunCriteria.andStatusEqualTo("0");
			List<PrdKucun> prdKucunList = prdKucunMapper.selectByExample(kucunExample);
			if (CollectionUtils.isEmpty(prdKucunList)) {
				throw new ServiceException("ERROR", "产品库存资源已使用完。");
			}
			PrdKucun prdKucun = prdKucunList.get(0);

			// 更新库存信息(第一次预约才会按照配置更新有效期，暂存产品的有效期)
			prdKucun.setStatus("1");
			prdKucun.setBuyerUserId(userId);
			prdKucun.setModifyDate(new Date());
			prdKucun.setModifyUser(String.valueOf(userId));
			prdKucun.setValidBeginDate(prdInfo.getPrdBeginDate());
			prdKucun.setValidEndDate(prdInfo.getPrdEndDate());
			prdKucunMapper.updateByPrimaryKeySelective(prdKucun);

			// 则插入订单表，订单产品冗余表，订单产品服务表
			PrdOrder prdOrder = new PrdOrder();
			String orderId = CommonTools.generateUUID();
			prdOrder.setId(orderId);
			prdOrder.setUserId(Long.valueOf(userId));
			prdOrder.setCreateUser(userId);
			prdOrder.setCreateDate(new Date());
			prdOrderMapper.insertSelective(prdOrder);

			// 插入订单明细表,需要冗余产品表信息
			String orderDetailId;
			orderDetailId = CommonTools.generateUUID();
			PrdOrderDetail prdOrderDetail = new PrdOrderDetail();
			prdOrderDetail.setId(orderDetailId);
			prdOrderDetail.setOrderId(orderId);
			prdOrderDetail.setKucunId(prdKucun.getId());
			prdOrderDetail.setPrdId(couponId);
			CommonTools.setProductInfo(Long.valueOf(userId), prdInfo, prdOrderDetail);
			prdOrderDetailMapper.insertSelective(prdOrderDetail);

			PrdServiceExample ser = new PrdServiceExample();
			PrdServiceExample.Criteria crit = ser.createCriteria();
			crit.andPrdIdEqualTo(couponId);
			List<PrdService> serviceList = prdServiceMapper.selectByExample(ser);
			// 循环中写数据库
			for (PrdService service : serviceList) {
				PrdOrderDetailService prdOrderDetailService = new PrdOrderDetailService();
				prdOrderDetailService.setId(CommonTools.generateUUID());
				prdOrderDetailService.setOrderDetailId(orderDetailId);
				prdOrderDetailService.setPrdId(couponId);
				prdOrderDetailService.setServiceId(service.getServiceId());
				prdOrderDetailService.setServiceCount(service.getServiceCount());
				prdOrderDetailService.setIsUnlimite(service.getIsUnlimite());
				prdOrderDetailService.setDelFlag(service.getDelFlag());
				prdOrderDetailService.setCreateUser(String.valueOf(userId));
				prdOrderDetailService.setCreateDate(new Date());
				prdOrderDetailServiceMapper.insertSelective(prdOrderDetailService);
			}
			result.setResult(prdKucun.getId());
		} else {
			throw new ServiceException("ERROR", "线下产品不能抽奖领取。");
		}

		result.setStatus(Status.SUCCESS);
		return result;
	}
	
	@Override
	public JsonResponse<Map<String, String>> getProductState(String userId, String prdId) {
		Map<String, String> returnMap = new HashMap<String, String>();
		returnMap.put("loginFlag", "");// 登录标志，如未登录则必须先登录
		returnMap.put("yqmFlag", "");// 是否需要输入邀请码（true：需要输入；false：不需要输入）
		returnMap.put("bookBtnName", "");// 按钮名称：激活、领取、预约
		returnMap.put("bookBtnMsg", "");// 点击提示信息，如有提示信息则不跳转
		returnMap.put("kucunId", "");// 库存id
		returnMap.put("activiteFlag", "");// 是否可以激活,过了激活截止时间activationDeadline，则激活按钮点击失效
		returnMap.put("buyBtnName", "");//是否支持在线购买
		returnMap.put("buyBtnMsg", "");//在线购买提示信息 (如有信息点击需要提示)
		
		String notbeginFlag = "";// 未开始标志
		String hasEndFlag = "";// 已结束标志
		PrdInfo produceInfo = new PrdInfo();
		JsonResponse<Map<String, String>> jr = new JsonResponse<Map<String, String>>();
		if (StringUtils.isBlank(prdId)) {
			jr.setStatus(JsonResponse.Status.ERROR);
			jr.setErrorMsg("参数错误!");
			return jr;
		} else {
			
			produceInfo = prdInfoMapper.selectByPrimaryKey(prdId);
			
			//设置库存总数和已使用数
			JsonResponse<Map<String, Integer>> stockNumsJr = stockService.getStockTotalNumber(produceInfo.getId());
			JsonResponse<Map<String, Integer>> usedNumsJr = stockService.getStockUsedNumber(produceInfo.getId());
			
			int totalKucun = 0;
			int leftKucun = 0;
			if(stockNumsJr != null && stockNumsJr.getResult() != null){
				if(stockNumsJr.getResult().containsKey(produceInfo.getId())){
					totalKucun = stockNumsJr.getResult().get(produceInfo.getId());
				}
			}
			if(usedNumsJr != null && usedNumsJr.getResult() != null){
				if(usedNumsJr.getResult().containsKey(produceInfo.getId())){
					leftKucun = totalKucun - usedNumsJr.getResult().get(produceInfo.getId());
				}
			}
			
			if(totalKucun == 0 || leftKucun <= 0){
				returnMap.put("buyBtnMsg", "产品已售完");// 无库存
			}
			
			if (produceInfo == null || produceInfo.getId() == null) {
				jr.setStatus(JsonResponse.Status.ERROR);
				jr.setErrorMsg("无相关产品!");
				return jr;
			} else {
				if (StringUtils.isBlank(userId)) {
					// 未登录
					returnMap.put("loginFlag", "false");
				}else{
					// 已登录
					returnMap.put("loginFlag", "true");
				}
				
				if (produceInfo != null && produceInfo.getIsSupportBuyOnline() != null && "0".equals(produceInfo.getIsSupportBuyOnline())) {//是否支持在线购买（0是，1否）
					
					//1.在线购买产品
					returnMap.put("buyBtnName", "购买");
					
					if(produceInfo != null && produceInfo.getIsValidFrom() != null && "0".equals(produceInfo.getIsValidFrom())) {//是否需要激活；自激活起 0-是，1-否
						
						//1.1 在线购买产品，激活类型
						if (produceInfo.getActivationDeadline() != null 
								&& DateUtils.format(produceInfo.getActivationDeadline(), "yyyy-MM-dd").compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) < 0) {
							returnMap.put("activiteFlag", "false");
							returnMap.put("bookBtnMsg", "抱歉，该产品已过激活截止日期（"+DateUtils.format(produceInfo.getActivationDeadline(), "yyyy-MM-dd")+"），无法激活");
						}
						
						if(produceInfo.getIsSupportReceiveFree() != null && "1".equals(produceInfo.getIsSupportReceiveFree())){// 是否支持免费领取（0是，1否）
							
							//1.1.1 “是否支持免费领取”选否，则该产品只能在线购买，前端按钮仅显示“立即购买”，已购买的产品点击激活自动激活，激活后产品直接进行预约
							returnMap.put("bookBtnName", "");
							
						}else if(produceInfo.getIsSupportReceiveFree() != null && "0".equals(produceInfo.getIsSupportReceiveFree())){
							
							//1.1.2 “是否支持免费领取”选是，则该产品还支持在线激活，前端按钮显示“立即购买”和“立即激活”，已购买的产品点击激活自动激活，点击“立即激活”按钮需输入激活码后激活
							returnMap.put("bookBtnName", "激活");
						}
						
					}else if(produceInfo != null && produceInfo.getIsValidFrom() != null && "1".equals(produceInfo.getIsValidFrom())){
						
						//1.2 在线购买产品，非激活类型
						if (produceInfo.getPrdBeginDate() != null
								&& DateUtils.format(produceInfo.getPrdBeginDate(), "yyyy-MM-dd")
										.compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) > 0) {
							notbeginFlag = "true";
						}
						if (produceInfo.getPrdEndDate() != null
								&& DateUtils.format(produceInfo.getPrdEndDate(), "yyyy-MM-dd")
										.compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) < 0) {
							hasEndFlag = "true";
						}
						
						//预约操作受开始时间限制
						if(StringUtils.isNotBlank(notbeginFlag) && "true".equals(notbeginFlag)){
							returnMap.put("bookBtnMsg", "产品未开始");
						}
						if(StringUtils.isNotBlank(hasEndFlag) && "true".equals(hasEndFlag)){
							returnMap.put("buyBtnMsg", "产品已到期");
							returnMap.put("bookBtnMsg", "产品已到期");
						}
						
						if((produceInfo.getIsSupportReceiveFree() != null && "1".equals(produceInfo.getIsSupportReceiveFree()))
								&& (produceInfo.getIsNeedPassword() != null && "1".equals(produceInfo.getIsNeedPassword()))){
							//1.2.1 “是否支持免费领取”选否，”预约是否需要卡号密码“选”否“，则该产品只能在线购买，前端按钮仅显示“立即购买”，购买后可直接进行预约
							returnMap.put("bookBtnName", "");
							
							
						}else if((produceInfo.getIsSupportReceiveFree() != null && "1".equals(produceInfo.getIsSupportReceiveFree()))
								&& (produceInfo.getIsNeedPassword() != null && "0".equals(produceInfo.getIsNeedPassword()))){
							//1.2.2 “是否支持免费领取”选否，”预约是否需要卡号密码“选是
							returnMap.put("bookBtnName", "预约");
							
						}else if(produceInfo != null && (produceInfo.getIsSupportReceiveFree() != null && "0".equals(produceInfo.getIsSupportReceiveFree()))){
							//1.2.3 “是否支持免费领取”选是
							returnMap.put("bookBtnName", "领取");
							
							// 无库存
							if(totalKucun == 0 || leftKucun <= 0){
								returnMap.put("bookBtnMsg", "产品已领完");
							}
							//预约操作受开始时间限制
							else if(StringUtils.isNotBlank(hasEndFlag) && "true".equals(hasEndFlag)){
								returnMap.put("bookBtnMsg", "产品已到期");
							}
							//预约操作受开始时间限制
							else if(StringUtils.isNotBlank(notbeginFlag) && "true".equals(notbeginFlag)){
								returnMap.put("bookBtnMsg", "产品未开始");
							}
							//已领取,可以直接预约
							else if (!recivePrdFromCodeService.isNoRecevied(prdId, String.valueOf(userId))) {
								returnMap.put("bookBtnName", "预约");
								PrdKucun prdKucun = new PrdKucun();
								prdKucun.setCouponId(prdId);
								prdKucun.setBuyerUserId(userId);
								prdKucun.setDelFlag("0");
								if("1".equals(produceInfo.getIsValidFrom())){
									prdKucun.setStatus("1");
								}
								String kucunId = vOPrdKucunMapper.getKucunIdByBuyerAndPrdId(prdKucun);
								returnMap.put("kucunId", vOPrdKucunMapper.getKucunIdByBuyerAndPrdId(prdKucun));
								// 判断服务次数是否使用完毕
								JsonResponse<VOMyProductDetail> jrMyprd = myProductDetailService.findMyPrdOrderDetail(prdId,
										userId, kucunId, "");
								if (jrMyprd != null && jrMyprd.getResult() != null) {
									// 已过期、使用完毕、已下线
									if (jrMyprd.getResult().getProductState().equals("使用完毕")) {
										returnMap.put("bookBtnMsg", "产品已使用完毕");
									} 
								}
							}
						}
					}
				}else{
					//2.非在线购买产品
					if(produceInfo != null && produceInfo.getIsValidFrom() != null && "1".equals(produceInfo.getIsValidFrom())) {//是否需要激活；自激活起 0-是，1-否
						
						//2.1非在线购买产品，非激活类型
						if (produceInfo.getPrdBeginDate() != null
								&& DateUtils.format(produceInfo.getPrdBeginDate(), "yyyy-MM-dd")
										.compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) > 0) {
							notbeginFlag = "true";
						}
						if (produceInfo.getPrdEndDate() != null
								&& DateUtils.format(produceInfo.getPrdEndDate(), "yyyy-MM-dd")
										.compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) < 0) {
							hasEndFlag = "true";
						}
						
						//预约操作受开始时间限制
						if(StringUtils.isNotBlank(notbeginFlag) && "true".equals(notbeginFlag)){
							returnMap.put("bookBtnMsg", "产品未开始");
						}
						if(StringUtils.isNotBlank(hasEndFlag) && "true".equals(hasEndFlag)){
							returnMap.put("bookBtnMsg", "产品已到期");
						}
						
						if(produceInfo != null && (produceInfo.getIsSupportReceiveFree() != null && "0".equals(produceInfo.getIsSupportReceiveFree()))){
							//2.1.1 ”是否支持免费领取“选择”是“，前端产品按钮为”立即领取“
							returnMap.put("bookBtnName", "领取");
							
							//领取、预约等操作都受结束时间限制
							if(StringUtils.isNotBlank(notbeginFlag) && "true".equals(notbeginFlag)){
								returnMap.put("bookBtnMsg", "产品未开始");
							}
							//领取、预约等操作都受开始时间限制
							else if(StringUtils.isNotBlank(hasEndFlag) && "true".equals(hasEndFlag)){
								returnMap.put("bookBtnMsg", "产品已到期");
							}
							// 无库存
							else if(totalKucun == 0 || leftKucun <= 0){
								returnMap.put("bookBtnMsg", "产品已领完");
							}
							//已领取,可以直接预约
							else if (!recivePrdFromCodeService.isNoRecevied(prdId, String.valueOf(userId))) {
								returnMap.put("bookBtnName", "预约");
								PrdKucun prdKucun = new PrdKucun();
								prdKucun.setCouponId(prdId);
								prdKucun.setBuyerUserId(userId);
								prdKucun.setDelFlag("0");
								if("1".equals(produceInfo.getIsValidFrom())){
									prdKucun.setStatus("1");
								}
								String kucunId = vOPrdKucunMapper.getKucunIdByBuyerAndPrdId(prdKucun);
								returnMap.put("kucunId", vOPrdKucunMapper.getKucunIdByBuyerAndPrdId(prdKucun));
								// 判断服务次数是否使用完毕
								JsonResponse<VOMyProductDetail> jrMyprd = myProductDetailService.findMyPrdOrderDetail(prdId,
										userId, kucunId, "");
								if (jrMyprd != null && jrMyprd.getResult() != null) {
									// 已过期、使用完毕、已下线
									if (jrMyprd.getResult().getProductState().equals("使用完毕")) {
										returnMap.put("bookBtnMsg", "产品已使用完毕");
									} 
								}
							}
							//未领取
							else{
								if(produceInfo.getIsNeedInviteValue() != null && "1".equals(produceInfo.getIsNeedInviteValue())){
									//”领取是否需要邀请码“选择”否“，自动生成库存时不生成邀请码，且领取时不需要输入邀请码，领完为止，领取后按钮变为”立即预约“，可直接预约
									returnMap.put("yqmFlag", "true");
								}
							}
							
						}else if(produceInfo != null && (produceInfo.getIsSupportReceiveFree() != null && "1".equals(produceInfo.getIsSupportReceiveFree()))){
							//2.1.2 ”是否支持免费领取“选择”否“，前端产品按钮为”立即预约“，自动生成库存时每个卡号对应一个密码，预约时需输入卡号密码验证
							returnMap.put("bookBtnName", "预约");
							// 无库存
							if(totalKucun == 0 || leftKucun <= 0){
								returnMap.put("bookBtnMsg", "产品已领完");
							}
						}
					}else if(produceInfo != null && produceInfo.getIsValidFrom() != null && "0".equals(produceInfo.getIsValidFrom())){
						//2.2非在线购买产品，非激活类型; 则前端产品按钮为”立即激活，自动生成库存时每个卡号对应一个邀请码（激活码），激活时需输入激活码验证，验证通过后按钮变为”立即预约“，可直接预约
						if(produceInfo.getActivationDeadline() != null 
								&& DateUtils.format(produceInfo.getActivationDeadline(), "yyyy-MM-dd").compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) < 0) {
							returnMap.put("activiteFlag", "false");
							returnMap.put("bookBtnMsg", "抱歉，该产品已过激活截止日期（"+DateUtils.format(produceInfo.getActivationDeadline(), "yyyy-MM-dd")+"），无法激活");
						}
						returnMap.put("bookBtnName", "激活");
					}
				}
			}
		}
		jr.setResult(returnMap);
		return jr;
	}

//	@Override
//	public JsonResponse<Map<String, String>> getProductState(String userId, String prdId) {
//		Map<String, String> returnMap = new HashMap<String, String>();
//		returnMap.put("loginFlag", "");// 登录标志，如未登录则必须先登录
//		returnMap.put("prdReciveType", "");// 产品领取类型(邀请码yqm和账号密码zhmm)
//		returnMap.put("yqmFlag", "");// 是否需要输入邀请码（true：需要输入；false：不需要输入）
//		returnMap.put("bookBtnName", "");// 按钮名称
//		returnMap.put("bookBtnMsg", "");// 点击提示信息，如有提示信息则不跳转
//		returnMap.put("kucunId", "");// 库存id
//		returnMap.put("needActivited", "");// 是否需要激活
//		returnMap.put("activiteFlag", "");// 是否可以激活,过了激活截止时间activationDeadline，则激活按钮点击失效
//		returnMap.put("buyBtnName", "");//是否支持在线购买
//		returnMap.put("buyBtnMsg", "");//在线购买提示信息 (如有信息点击需要提示)
//		
//		String prdReciveType = "";// 产品领取类型(邀请码yqm和账号密码zhmm)
//		String notbeginFlag = "";// 未开始标志
//		String hasEndFlag = "";// 已结束标志
//		boolean needActivited = false; //是否需要激活
////		ProductInfo produceInfo = new ProductInfo();
//		PrdInfo produceInfo = new PrdInfo();
//		JsonResponse<Map<String, String>> jr = new JsonResponse<Map<String, String>>();
//		if (StringUtils.isBlank(prdId)) {
//			jr.setStatus(JsonResponse.Status.ERROR);
//			jr.setErrorMsg("参数错误!");
//			return jr;
//		} else {
//			// 获取产品信息
////			ProductInfo product = new ProductInfo();
////			product.setStatus("0");
////			product.setId(prdId);
////			produceInfo = couponMapper.getProduceInfo(product);
//			
//			
//			produceInfo = prdInfoMapper.selectByPrimaryKey(prdId);
//			
//			if (produceInfo == null || produceInfo.getId() == null) {
//				jr.setStatus(JsonResponse.Status.ERROR);
//				jr.setErrorMsg("无相关产品!");
//				return jr;
//			} else {
//				if (produceInfo != null && produceInfo.getIsSupportBuyOnline() != null && "0".equals(produceInfo.getIsSupportBuyOnline())) {// 是否支持在线购买（0是，1否）
//					returnMap.put("buyBtnName", "购买");
//				}
//				
//				if (produceInfo != null && produceInfo.getIsSupportReceiveFree() != null
//						&& "0".equals(produceInfo.getIsSupportReceiveFree())) {// 是否支持免费领取（0是，1否）
//					prdReciveType = "yqm";// 邀请码
//					returnMap.put("prdReciveType", "yqm");
//				} else {
//					prdReciveType = "zhmm";// 账号密码
//					returnMap.put("prdReciveType", "zhmm");
//				}
//				if (produceInfo != null && produceInfo.getIsValidFrom() != null
//						&& "1".equals(produceInfo.getIsValidFrom())) {//是否需要激活；自激活起 0-是，1-否
//					if (produceInfo.getPrdBeginDate() != null
//							&& DateUtils.format(produceInfo.getPrdBeginDate(), "yyyy-MM-dd")
//									.compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) > 0) {
//						notbeginFlag = "true";
//					}
//					if (produceInfo.getPrdEndDate() != null
//							&& DateUtils.format(produceInfo.getPrdEndDate(), "yyyy-MM-dd")
//									.compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) < 0) {
//						hasEndFlag = "true";
//					}
//				}else if(produceInfo != null && produceInfo.getIsValidFrom() != null
//						&& "0".equals(produceInfo.getIsValidFrom())){  // 需要激活的产品
//					needActivited = true;
//				}
//			}
//		}
//
//		if (StringUtils.isBlank(userId)) {
//			// 未登录
//			returnMap.put("loginFlag", "false");
//			if (StringUtils.isNotBlank(prdReciveType) && prdReciveType.equals("yqm")) {
//				returnMap.put("bookBtnName", "领取");
//				// 邀请领取产品
//				if (StringUtils.isNotBlank(hasEndFlag) && hasEndFlag.equals("true")) {
//					// 已结束,则不能继续领取
//					returnMap.put("bookBtnMsg", "产品已到期");
//					returnMap.put("buyBtnMsg", "产品已到期");
//				}else if(needActivited){// 需要激活
//					returnMap.put("bookBtnName", "激活");
//					returnMap.put("needActivited", "true");
//					returnMap.put("bookBtnMsg", "");
//					
//					if (produceInfo.getActivationDeadline() != null
//							&& DateUtils.format(produceInfo.getActivationDeadline(), "yyyy-MM-dd")
//									.compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) < 0) {
//						returnMap.put("activiteFlag", "false");
//						returnMap.put("bookBtnMsg", "抱歉，该产品已过激活截止日期（"+DateUtils.format(produceInfo.getActivationDeadline(), "yyyy-MM-dd")+"），无法激活");
//					}else{
//						returnMap.put("activiteFlag", "true");
//					}
//					
//				}else{
//					returnMap.put("needActivited", "false");
//				}
//			} else {
//				// 账号密码预约产品
//				returnMap.put("bookBtnName", "预约");
//				if (StringUtils.isNotBlank(hasEndFlag) && hasEndFlag.equals("true")) {
//					// 已结束，不可继续预约
//					returnMap.put("bookBtnMsg", "产品已到期");
//					returnMap.put("buyBtnMsg", "产品已到期");
//				} else if (StringUtils.isNotBlank(notbeginFlag) && notbeginFlag.equals("true")) {
//					// 未开始，不可预约
//					returnMap.put("bookBtnMsg", "预约未开始");
//				}
//			}
//		} else {
//			// 已登录
//			returnMap.put("loginFlag", "true");
//			
//			//先判断是否是激活产品
//			if(needActivited){// 需要激活
//				returnMap.put("bookBtnName", "激活");
//				returnMap.put("needActivited", "true");
//				returnMap.put("bookBtnMsg", "");
//				
//				if (produceInfo.getActivationDeadline() != null
//						&& DateUtils.format(produceInfo.getActivationDeadline(), "yyyy-MM-dd")
//								.compareTo(DateUtils.format(new Date(), "yyyy-MM-dd")) < 0) {
//					returnMap.put("activiteFlag", "false");
//					returnMap.put("bookBtnMsg", "抱歉，该产品已过激活截止日期（"+DateUtils.format(produceInfo.getActivationDeadline(), "yyyy-MM-dd")+"），无法激活");
//				}else{
//					returnMap.put("activiteFlag", "true");
//				}
//			}else{
//				returnMap.put("needActivited", "false");
//				
//				//如果是邀请码领取产品
//				if (StringUtils.isNotBlank(prdReciveType) && prdReciveType.equals("yqm")) {
//					// 邀请码类型产品
//					// 校验是否已经领取过
//					if (recivePrdFromCodeService.isNoRecevied(prdId, String.valueOf(userId))) {
//						// 未领取
//						returnMap.put("bookBtnName", "领取");
//						if (StringUtils.isNotBlank(hasEndFlag) && hasEndFlag.equals("true")) {
//							// 已结束,则不能继续领取
//							returnMap.put("bookBtnMsg", "产品已到期");
//							returnMap.put("buyBtnMsg", "产品已到期");
//						} else {
//							// 校验是否有库存
//							if (!recivePrdFromCodeService.checkAmount(prdId)) {
//								returnMap.put("bookBtnMsg", "产品已领完");// 无库存
//								returnMap.put("buyBtnMsg", "产品已售完");// 无库存
//							} else {
//								logger.info(produceInfo.getIsSupportReceiveFree());
//								if (StringUtils.isNotBlank(produceInfo.getIsNeedInviteValue()) &&"0".equals(produceInfo.getIsNeedInviteValue())) {// 是否需要邀请码（0是，1否）
//									returnMap.put("yqmFlag", "true");
//								} else {
//									returnMap.put("yqmFlag", "false");
//								}
//							}
//						}
//					} else {
//						
//						// 已领取
//						returnMap.put("bookBtnName", "预约");
//						if (StringUtils.isNotBlank(hasEndFlag) && hasEndFlag.equals("true")) {
//							// 已结束，不可继续预约
//							returnMap.put("bookBtnMsg", "产品已到期");
//							returnMap.put("buyBtnMsg", "产品已到期");
//						} else if (StringUtils.isNotBlank(notbeginFlag) && notbeginFlag.equals("true")) {
//							// 未开始，不可预约
//							returnMap.put("bookBtnMsg", "预约未开始");
//						} else {
//							PrdKucun prdKucun = new PrdKucun();
//							prdKucun.setCouponId(prdId);
//							prdKucun.setBuyerUserId(userId);
//							prdKucun.setDelFlag("0");
//							if("1".equals(produceInfo.getIsValidFrom())){
//								prdKucun.setStatus("1");
//							}
//							String kucunId = vOPrdKucunMapper.getKucunIdByBuyerAndPrdId(prdKucun);
//							returnMap.put("kucunId", vOPrdKucunMapper.getKucunIdByBuyerAndPrdId(prdKucun));
//							// 判断服务次数是否使用完毕
//							JsonResponse<VOMyProductDetail> jrMyprd = myProductDetailService.findMyPrdOrderDetail(prdId,
//									userId, kucunId, "");
//							if (jrMyprd != null && jrMyprd.getResult() != null) {
//								// 已过期、使用完毕、已下线
//								if (jrMyprd.getResult().getProductState().equals("已过期")) {
//									returnMap.put("bookBtnMsg", "产品已到期");
//									returnMap.put("buyBtnMsg", "产品已到期");
//								} else if (jrMyprd.getResult().getProductState().equals("使用完毕")) {
//									returnMap.put("bookBtnMsg", "产品已使用完毕");
//								} else if (jrMyprd.getResult().getProductState().equals("已下线")) {
//									returnMap.put("bookBtnMsg", "产品已下线");
//									returnMap.put("buyBtnMsg", "产品已下线");
//								}
//							}
//						}
//					}
//				} else {
//					// 非邀请码类型产品，即账号密码类型产品
//					returnMap.put("bookBtnName", "预约");
//					if (StringUtils.isNotBlank(hasEndFlag) && hasEndFlag.equals("true")) {
//						// 已结束，不可继续预约
//						returnMap.put("bookBtnMsg", "产品已到期");
//						returnMap.put("buyBtnMsg", "产品已到期");
//					} else if (StringUtils.isNotBlank(notbeginFlag) && notbeginFlag.equals("true")) {
//						// 未开始，不可预约
//						returnMap.put("bookBtnMsg", "预约未开始");
//					}
//				}
//			}
//			
//			
//		}
//		jr.setResult(returnMap);
//		return jr;
//	}

//	@Override
//	public JsonResponse<PageInfo<VoClinic>> getVoClinicByProId(VOClinicProduct voClinicProduct) {
//		JsonResponse<PageInfo<VoClinic>> result = new JsonResponse<PageInfo<VoClinic>>();
//		JsonResponse<PageInfo<Clinic>> jr = new JsonResponse<PageInfo<Clinic>>();
//		try {
//			jr = clinicService.getClinicByProId(voClinicProduct);
//		} catch (Exception e) {
//			logger.error("通过产品id查询服务诊所信息失败", e);
//			result.setStatus(Status.ERROR);
//			result.setErrorMsg("查询服务诊所信息失败");
//			return result;
//		}
//
//		try {
//			BeanUtils.copyProperties(result, jr);
//		} catch (IllegalAccessException | InvocationTargetException e) {
//			logger.error("复制信息" + jr + "到" + result + "失败");
//			result.setStatus(Status.ERROR);
//			result.setErrorMsg("系统繁忙");
//			return result;
//		}
//		if (null != jr && null != jr.getResult() && null != jr.getResult().getList()) {
//			List<VoClinic> list = setVoClinic(jr.getResult().getList());
//			PageInfo<Clinic> pageInfo = jr.getResult();
//			PageInfo<VoClinic> newPageInfo = new PageInfo<VoClinic>();
//			newPageInfo.setPageNum(pageInfo.getPageNum());
//			newPageInfo.setTotal(pageInfo.getTotal());
//			newPageInfo.setPages(pageInfo.getPages());
//			newPageInfo.setList(list);
//			result.setResult(newPageInfo);
//		}
//		return result;
//	}

//	private List<VoClinic> setVoClinic(List<Clinic> list) {
//		List<VoClinic> newList = new ArrayList<VoClinic>();
//		if (list != null) {
//			for (Clinic clinic : list) {
//				VoClinic v = new VoClinic();
//				try {
//					BeanUtils.copyProperties(v, clinic);
//					
//					if(StringUtils.isNotBlank(v.getClinicFacadeName())){
//						v.setClinicFacadeName(v.getClinicFacadeName().replace("clinic/", "clinicApproval/"));;
//						
//					}
//					newList.add(v);
//				} catch (Exception e) {
//					logger.error("复制查询诊所信息失败", e);
//				}
//			}
//		}
//		return newList;
//	}
	@Override
	public List<String> getClinicId(String prdId) {
		List<String> clinicIdList = vOPrdClinicMapper.getCLinicIdByPrdClinic(prdId);
		List<String> agreementClinic = vOPrdClinicMapper.getCLinicIdByAgreement(prdId); // 通过合同的产品查询clinicId
		// 通过合同查询已经过期的诊所 或者未生效的
		List<String> outOfDateClinicIds = vOPrdClinicMapper.getCLinicIdByAgreementOutDate(prdId); 
		if (outOfDateClinicIds == null || outOfDateClinicIds.size() < 1) {
			clinicIdList.addAll(agreementClinic);
			return clinicIdList;
		}
		if (clinicIdList == null) {
			clinicIdList = new ArrayList<String>();
		}
		clinicIdList.addAll(agreementClinic);
		HashSet h = new HashSet(clinicIdList); // 删除list中重复数据
		clinicIdList.clear();
		clinicIdList.addAll(h);
		for (String c : outOfDateClinicIds) {
			if (clinicIdList.contains(c)) {
				clinicIdList.remove(c);
			}
		}
		return clinicIdList;
	}

	@Override
	public JsonResponse<PageInfo<VoClinic>> getPrdClinicByProId(VOClinicProduct voClinicProduct,String kucunId) {
		JsonResponse<PageInfo<VoClinic>> result = new JsonResponse<PageInfo<VoClinic>>();
		JsonResponse<PageInfo<Clinic>> jr = new JsonResponse<PageInfo<Clinic>>();
		logger.info("M站===============根据产品id查询健康产品开始============");
		List<String> clinicIds = getClinicId(voClinicProduct.getPrdId());
		List<String> clinicIdListAfter = new ArrayList<String>();
		//过滤诊所
		if(StringUtils.isNotBlank(kucunId)&&StringUtils.isNotBlank(voClinicProduct.getUserId())){
			filterClinicId(voClinicProduct.getPrdId(), clinicIds, clinicIdListAfter, kucunId, voClinicProduct.getUserId(), voClinicProduct.getBookingId(), voClinicProduct.getServiceId());
			//			filterClinicIdForGateway(voClinicProduct.getPrdId(), clinicIds, clinicIdListAfter,kucunId , voClinicProduct.getUserId(),null);
			if(clinicIdListAfter==null||clinicIdListAfter.size()==0){
			}else{
				//不为空，转换
				clinicIds = clinicIdListAfter;
			}
		}
//		if(null==clinicIds){
//			logger.info("根据产品id："+voClinicProduct.getPrdId()+"没有查询到框架合同诊所");
//			result.setStatus(Status.ERROR);
//			result.setErrorMsg("没有查到相关诊所");
//			return result;
//		}
//		filterClinicId(couponId, serviceTypeId, clinicIdList, clinicIdListAfter);
		if(clinicIds==null||clinicIds.size()==0){
			clinicIds=null;
		}
		List<VoClinic> clinicList = null;
//		List<Clinic> clinicList = null;
		PageHelper.startPage(Integer.parseInt(voClinicProduct.getPageNo()), Integer.parseInt(voClinicProduct.getPageSize()));
		//总账号为空的话
		if(StringUtils.isBlank(voClinicProduct.getTotalRegisterId())){
			clinicList = voClinicMapper.findPrdClinicByClinicIds(voClinicProduct, clinicIds);
		}else{
			clinicList = voClinicMapper.findPrdClinicByClinicIdsAndTotalAccount(voClinicProduct, clinicIds);
		}
		String mLatitude = voClinicProduct.getMobilephoneLatitude();
		String mLongitude = voClinicProduct.getMobilephoneLongitude();
		if(StringUtils.isNotBlank(mLongitude)&&StringUtils.isNotBlank(mLatitude)){
//			
//			//通过手机经纬度和诊所经纬度计算公里数
//			for(Clinic clinic:clinicList){
//				String cLatitude = clinic.getLatitude();
//				String cLongitude = clinic.getLongitude();
//				if(StringUtils.isNotEmpty(mLatitude) && StringUtils.isNotEmpty(mLongitude)
//						&& StringUtils.isNotEmpty(cLatitude) && StringUtils.isNotEmpty(cLongitude)){
//					double distance = CommonTools.distance(Double.parseDouble(mLatitude), Double.parseDouble(mLongitude),
//							Double.parseDouble(cLatitude), Double.parseDouble(cLongitude));
//					logger.info("格式化前的 distance is:"+distance);
//					clinic.setDistance(String.valueOf(distance));
//				}
//			}
//			//通过距离排序
//			Collections.sort(clinicList);
//			//Collections.reverse(clinicList);
//			//距离转换成米和千米
//			for (Clinic clinic : clinicList) {
//				if (clinic.getDistance() != null) {
//					double distance = Double.valueOf(clinic.getDistance());
//					int m = (int) distance;
//					double km = new BigDecimal(distance).divide(new BigDecimal(1000)).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
//					// 设置距离 距离小于1000 显示m
//					if (m <= 1000) {
//						clinic.setDistance(String.valueOf(m + "m"));
//						logger.info("格式化后的 distance is:" + m);
//						// 设置距离 距离大于1000 显示km
//					} else {
//						clinic.setDistance(String.valueOf(km + "km"));
//						logger.info("格式化后的 distance is:" + km);
//					}
//				}
//			}
			//通过手机经纬度和诊所经纬度计算公里数
			for(VoClinic clinic:clinicList){
				String cLatitude = clinic.getLatitude();
				String cLongitude = clinic.getLongitude();
				if(StringUtils.isNotEmpty(mLatitude) && StringUtils.isNotEmpty(mLongitude)
						&& StringUtils.isNotEmpty(cLatitude) && StringUtils.isNotEmpty(cLongitude)){
					double distance = CommonTools.distance(Double.parseDouble(mLatitude), Double.parseDouble(mLongitude),
							Double.parseDouble(cLatitude), Double.parseDouble(cLongitude));
					logger.info("格式化前的 distance is:"+distance);
					clinic.setDistance(String.valueOf(distance));
				}
			}
			//通过距离排序
			Collections.sort(clinicList);
			//Collections.reverse(clinicList);
		
		}
		//距离转换成米和千米
		for (VoClinic clinic : clinicList) {
			if(StringUtils.isNotBlank(clinic.getClinicFacadeName())){
				clinic.setClinicFacadeName(clinic.getClinicFacadeName().replace("clinic/", "clinicApproval/"));
			}
			
			if (StringUtils.isNotBlank(clinic.getDistance())) {
				double distance = Double.valueOf(clinic.getDistance());
				int m = (int) distance;
				double km = new BigDecimal(distance).divide(new BigDecimal(1000)).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				// 设置距离 距离小于1000 显示m
				if (m <= 1000) {
					clinic.setDistance(String.valueOf(m + "m"));
					logger.info("格式化后的 distance is:" + m);
					// 设置距离 距离大于1000 显示km
				} else {
					clinic.setDistance(String.valueOf(km + "km"));
					logger.info("格式化后的 distance is:" + km);
				}
			}
		}
		result.setResult(new PageInfo<VoClinic>(clinicList));
//		PageInfo<Clinic> page = new PageInfo<Clinic>(clinicList);// 获得分页信息
//
//		jr.setResult(page);
//		try {
//			BeanUtils.copyProperties(result, jr);
//		} catch (IllegalAccessException | InvocationTargetException e) {
//			logger.error("复制信息" + jr + "到" + result + "失败");
//			result.setStatus(Status.ERROR);
//			result.setErrorMsg("系统繁忙");
//			return result;
//		}
//		if (null != jr && null != jr.getResult() && null != jr.getResult().getList()) {
//			List<VoClinic> list = setVoClinic(jr.getResult().getList());
//			PageInfo<Clinic> pageInfo = jr.getResult();
//			PageInfo<VoClinic> newPageInfo = new PageInfo<VoClinic>();
//			newPageInfo.setPageNum(pageInfo.getPageNum());
//			newPageInfo.setTotal(pageInfo.getTotal());
//			newPageInfo.setPages(pageInfo.getPages());
//			newPageInfo.setList(list);
//			result.setResult(newPageInfo);
//		}
		return result;
	}

	@Override
	public JsonResponse<Integer> getPrdClinicNumbersByProId(String prdId) {
		JsonResponse<Integer> jr = new JsonResponse<Integer>();
		if(StringUtils.isBlank(prdId)){
			logger.info("未传入健康产品id");
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("请先选择一个健康产品");
			return jr;
		}
		List<String> clinicIds = getClinicId(prdId);
		if(clinicIds==null||clinicIds.size()==0){
			clinicIds=null;
		}
//		if(null==clinicIds){
//			logger.info("根据产品id："+prdId+"没有查询到框架合同诊所");
//			jr.setStatus(Status.ERROR);
//			jr.setErrorMsg("没有查到相关诊所");
//			return jr;
//		}
		//查询诊所数量
		Integer count = vOPrdClinicMapper.getPrdClinicNumbersByProId(clinicIds);
		logger.info("健康产品id为："+prdId+"的服务诊所数量为"+count);
		jr.setResult(count);
		return jr;
	}
	
	// 根据绑定诊所重新过滤诊所ID
	private List<String> filterClinicId(String couponId, List<String> clinicIdList, List<String> clinicIdListAfter,String kucunId,String userId,String excludeApptOrderCode,String prdServiceId) {
		if(StringUtils.isNotBlank(couponId)&&CollectionUtils.isNotEmpty(clinicIdList)&&StringUtils.isNotBlank(kucunId)&&StringUtils.isNotBlank(prdServiceId))
		{
			PrdServiceExample prdExample1 = new PrdServiceExample();
			PrdServiceExample.Criteria prdCriteria1 = prdExample1.createCriteria();
			prdCriteria1.andPrdIdEqualTo(couponId);
			prdCriteria1.andServiceIdEqualTo(prdServiceId);
			prdCriteria1.andDelFlagEqualTo(0);
			List<PrdService> prdServiceList1 = prdServiceMapper.selectByExample(prdExample1);
			// 为绑定诊所的服务项目
			if(prdServiceList1!=null&&prdServiceList1.size()>0&&"0".equals(prdServiceList1.get(0).getIsBandClinic()))
			{
				PrdServiceExample prdExample = new PrdServiceExample();
				PrdServiceExample.Criteria prdCriteria = prdExample.createCriteria();
				prdCriteria.andPrdIdEqualTo(couponId);
				prdCriteria.andIsBandClinicEqualTo("0");
				prdCriteria.andDelFlagEqualTo(0);
				List<PrdService> prdServiceList = prdServiceMapper.selectByExample(prdExample);
				// 为绑定诊所的服务项目
				if(CollectionUtils.isNotEmpty(prdServiceList))
				{
					List<String> healthProductItemIds = new ArrayList<String>();
					for(PrdService item : prdServiceList){
						healthProductItemIds.add(item.getServiceId());
					}
					// 调用深圳接口查询该服务已提交预约的诊所ID
					com.pinganwj.clinic.api.domain.JsonResponse<List<String>> clinicIdResult = productApptApi.getClinicIds(kucunId, userId, healthProductItemIds, "1,2,3,4,5,8,9",excludeApptOrderCode);
					List<String> clinicIds = clinicIdResult.getResult();
					if(CollectionUtils.isNotEmpty(clinicIds))
					{
						String clinicId = clinicIds.get(0);
						//判断诊所为单体诊所还是连锁诊所
						HyClinicInfo hyClinicInfo = clinicInfoMapper.selectByPrimaryKey(clinicId);
						if(hyClinicInfo!=null){
							HyClinicRegister register = clinicRegisterMapper.selectByPrimaryKey(hyClinicInfo.getClinicRegisterId());
							String parentId = register.getParentAccountId();
							// 为单体诊所
							if(StringUtils.isBlank(parentId)){
								clinicIdListAfter.add(clinicId);
							// 为连锁诊所
							}else{
								List<VOClinicParentInfo> parentInfos = vOPrdClinicMapper.getClinicParentInfo(clinicIdList);
								for(VOClinicParentInfo info:parentInfos)
								{
									if(parentId.equals(info.getParentAccountId()))
									{
										clinicIdListAfter.add(info.getClinicId());
									}
								}
							}
						}
					}
				}
			}
		}
		//clinicIdListAfter为空，没有筛选出诊所
		if(CollectionUtils.isEmpty(clinicIdListAfter)){
			clinicIdListAfter = clinicIdList;
		}
		return clinicIdListAfter;
	}
	
	
	
	
	@Override
	public JsonResponse<PageInfo<PrdInfo>> findProductsByClinicId(String clinicId, int pageNo, int pageSize) {
		// 返回值
		JsonResponse<PageInfo<PrdInfo>> res = new JsonResponse<PageInfo<PrdInfo>>();
		try {
			List<String> prdIdList = getPrdId(clinicId); // 得到合同和产品对应的诊所id
			List<PrdInfo> prdInfoList = null;
			PageHelper.startPage(pageNo, pageSize);
			PageInfo<PrdInfo> page = new PageInfo<PrdInfo>();
			if (prdIdList != null && prdIdList.size() > 0) {
				prdInfoList = voPrdInfoMapper.getPrdInfoByIdList(prdIdList);
			}
			page = new PageInfo<PrdInfo>(prdInfoList);// 获得分页信息
			res.setStatus(Status.SUCCESS);
			res.setResult(page);
		} catch (Exception e) {
			logger.error("findProductsByClinicId error:", e);
			res.setStatus(Status.ERROR);
		}
		return res;
	}
	@Override
	public List<String> getPrdId(String clinicId) {
		List<String> clinicIdList = vOPrdClinicMapper.getPrdIdByClinicId(clinicId);
		List<String> agreementClinic = vOPrdClinicMapper.getPrdIdByAgreement(clinicId); // 通过合同的产品查询clinicId
		// 通过合同查询已经过期的诊所 或者未生效的
		List<String> outOfDateClinicIds = vOPrdClinicMapper.getPrdIdByAgreementOutDate(clinicId); 
		if (outOfDateClinicIds == null || outOfDateClinicIds.size() < 1) {
			clinicIdList.addAll(agreementClinic);
			return clinicIdList;
		}
		if (clinicIdList == null) {
			clinicIdList = new ArrayList<String>();
		}
		clinicIdList.addAll(agreementClinic);
		HashSet h = new HashSet(clinicIdList); // 删除list中重复数据
		clinicIdList.clear();
		clinicIdList.addAll(h);
		for (String c : outOfDateClinicIds) {
			if (clinicIdList.contains(c)) {
				clinicIdList.remove(c);
			}
		}
		return clinicIdList;
	}
}
