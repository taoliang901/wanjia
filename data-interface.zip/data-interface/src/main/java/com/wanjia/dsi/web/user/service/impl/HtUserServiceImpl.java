package com.wanjia.dsi.web.user.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.user.dao.mapper.HtUserMapper;
import com.wanjia.dsi.web.user.model.HtUser;
import com.wanjia.dsi.web.user.service.HtUserService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class HtUserServiceImpl extends BaseServiceImpl implements HtUserService {

	@Autowired
	private HtUserMapper htUserMapper;

	public HtUserServiceImpl() {
	}

	@Override
	public JsonResponse<List<HtUser>> getUserListByAreaId(String areaId) {
		JsonResponse<List<HtUser>> result = new JsonResponse<List<HtUser>>();
		try {
			this.pringLog("areaId is:" + areaId);
			if (StringUtils.isNotBlank(areaId)) {
				HtUser user = new HtUser();
				user.setAreaId(areaId);
				user.setJob("02");
				result.setResult(htUserMapper.getUserListByAreaId(user));
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<HtUser> getByUserCode(String userCode) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("userCode", userCode);
		map.put("delFlag", 0);

		JsonResponse<HtUser> response = new JsonResponse<HtUser>();
		List<HtUser> user = htUserMapper.findByProperties(map);
		if (user != null && user.size() > 0) {
			response.setResult(user.get(0));
		}

		return response;
	}

	@Override
	public void insert(HtUser htUser) {
		this.htUserMapper.insert(htUser);
	}

	@Override
	public void update(HtUser htUser) {
		this.htUserMapper.update(htUser);
	}
}
