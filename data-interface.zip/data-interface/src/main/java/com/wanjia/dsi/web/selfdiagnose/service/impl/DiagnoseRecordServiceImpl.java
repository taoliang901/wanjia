package com.wanjia.dsi.web.selfdiagnose.service.impl;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.mongodb.Pagination;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.selfdiagnose.model.DiagnoseRecordBO;
import com.wanjia.dsi.web.selfdiagnose.repository.DiagnoseRecordRepository;
import com.wanjia.dsi.web.selfdiagnose.service.DiagnoseRecordService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class DiagnoseRecordServiceImpl implements DiagnoseRecordService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private DiagnoseRecordRepository diagnoseRecordRepository;
	
	@Override
	public JsonResponse<Pagination<DiagnoseRecordBO>> findDiagnoseRecord(DiagnoseRecordBO recordBo,int pageNo,int pageSize) {
		// TODO Auto-generated method stub
		JsonResponse<Pagination<DiagnoseRecordBO>> result = new JsonResponse<Pagination<DiagnoseRecordBO>>();
		try {
			if (recordBo != null) {
				// 设置查询参数
				Query query = new Query();
				
				// 获取就诊记录ID
				String id = recordBo.getId();

				// 获取会员ID
				String memberId = recordBo.getMemberId();
				
				// 设置查询参数
				if (StringUtils.isNotBlank(id)) {
					query.addCriteria(Criteria.where("id").is(id));
				}
				if (StringUtils.isNotBlank(memberId)) {
					query.addCriteria(Criteria.where("memberId").is(memberId));
				}
				query.addCriteria(Criteria.where("delFlag").is("0"));
				result.setResult(diagnoseRecordRepository.getPage(pageNo == 0 ? 1 : pageNo, pageSize == 0 ? 10 : pageSize, query, new Sort(Direction.DESC, "createDate"), DiagnoseRecordBO.class));
			}
		} catch (Exception e) {
			logger.error("error:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;

	}
	
	// 插入自诊记录(暂用于造数据)
	@Override
	public JsonResponse insertDiagnoseRecord(DiagnoseRecordBO recordBo) {

		JsonResponse result = new JsonResponse();

		try {
			if (recordBo != null) {
				diagnoseRecordRepository.insert(recordBo, DiagnoseRecordBO.class);
				result.setStatus(Status.SUCCESS);
			}
		} catch (Exception e) {
			logger.error("error:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}
	
	// 删除自诊记录
	@Override
	public JsonResponse deleteDiagnoseRecordById(String id) {

		JsonResponse result = new JsonResponse();

		try {
			if (!StringUtils.isEmpty(id)) {
				diagnoseRecordRepository.deleteById(id, DiagnoseRecordBO.class);
				result.setStatus(Status.SUCCESS);
			}
		} catch (Exception e) {
			logger.error("error:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<DiagnoseRecordBO> findDiagnoseRecordById(String id) {
		JsonResponse<DiagnoseRecordBO> result = new JsonResponse<DiagnoseRecordBO>();

		try {
			if (!StringUtils.isEmpty(id)) {
				result.setResult(diagnoseRecordRepository.findById(id, DiagnoseRecordBO.class));
				result.setStatus(Status.SUCCESS);
			}
		} catch (Exception e) {
			logger.error("error:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
}
