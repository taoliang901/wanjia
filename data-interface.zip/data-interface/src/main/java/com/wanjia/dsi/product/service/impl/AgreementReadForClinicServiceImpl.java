package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.product.dao.mapper.FrameAgreementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdSubAgreementMapper;
import com.wanjia.dsi.product.model.FrameAgreement;
import com.wanjia.dsi.product.model.PrdAgreementClinic;
import com.wanjia.dsi.product.model.PrdAgreementPrdFullInfo;
import com.wanjia.dsi.product.service.AgreementReadForClinicService;
import com.wanjia.dsi.product.vo.VOPrdSubAgreementForClinic;

@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class AgreementReadForClinicServiceImpl implements AgreementReadForClinicService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private FrameAgreementMapper frameAgreementMapper;
	
	@Resource
	private PrdSubAgreementMapper prdSubAgreementMapper;
	
	@Resource
	private PrdAgreementClinicMapper prdAgreementClinicMapper;
	
	@Resource
	private PrdAgreementPrdinfoMapper prdAgreementPrdinfoMapper;
	
	@Override
	public JsonResponse<List<FrameAgreement>> getFrameAgreementInfoByNo(Map<String, Object> map) {
		JsonResponse<List<FrameAgreement>> response = new JsonResponse<List<FrameAgreement>>();
		try{
			List<FrameAgreement> frameAgreements = frameAgreementMapper.findAgreementInfoForClinic(map);
			response.setResult(frameAgreements);
		}catch(Exception e){
			logger.error("获取框架合同信息异常：",e);
			response.setStatus(Status.ERROR);
			response.setErrorCode(ErrorType.SystemBusy.getCode());
			response.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return response;
	}

	@Override
	public JsonResponse<List<VOPrdSubAgreementForClinic>> getSubAgreementInfoByNos(Map<String, Object> map) {
		JsonResponse<List<VOPrdSubAgreementForClinic>> response = new JsonResponse<List<VOPrdSubAgreementForClinic>>();
		try{
			List<VOPrdSubAgreementForClinic> subAgreementList = new ArrayList<VOPrdSubAgreementForClinic>();
			List<VOPrdSubAgreementForClinic> subAgreements = prdSubAgreementMapper.findSubAgreementInfoForClinic(map);
			if(CollectionUtils.isNotEmpty(subAgreements)){
				Map<String, Object> map1 = new HashMap<String, Object>();
				for(VOPrdSubAgreementForClinic vo : subAgreements){
					String id = vo.getId();
					map1.put("subAgreementId", id);
					map1.put("delFlag", "0");
					List<PrdAgreementClinic> clinicInfoList = prdAgreementClinicMapper.findByProperties(map1);
					vo.setClinicInfoList(clinicInfoList);
					List<PrdAgreementPrdFullInfo> prdInfoList = prdAgreementPrdinfoMapper.findByPropertiesWithFullInfo(map1);
					vo.setPrdInfoList(prdInfoList);
					subAgreementList.add(vo);
				}
			}
			response.setResult(subAgreementList);
		}catch(Exception e){
			logger.error("获取附属合同列表信息异常：",e);
			response.setStatus(Status.ERROR);
			response.setErrorCode(ErrorType.SystemBusy.getCode());
			response.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return response;
	}

}
