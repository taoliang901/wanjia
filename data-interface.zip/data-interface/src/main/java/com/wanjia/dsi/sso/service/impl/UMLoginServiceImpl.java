package com.wanjia.dsi.sso.service.impl;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.security.PublicKey;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.kafka.MD5;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.member.dao.mapper.HyUserLoginCheckMapper;
import com.wanjia.dsi.member.model.HyUserLoginCheck;
import com.wanjia.dsi.sso.service.UMLoginService;
import com.wanjia.dsi.sso.util.RSA2;
import com.wanjia.dsi.web.hyPerson.dao.mapper.CasUserMapper;
import com.wanjia.dsi.web.hyPerson.model.CasUser;
import com.wanjia.dsi.web.hyPerson.model.CasUserExample;
import com.wanjia.dsi.web.user.dao.mapper.HtUserLoginCheckMapper;
import com.wanjia.dsi.web.user.dao.mapper.HtUserMapper;
import com.wanjia.dsi.web.user.model.HtUser;
import com.wanjia.dsi.web.user.model.HtUserLoginCheck;

/**
 * UM业务处理层：与登陆有关的业务逻辑单元
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class UMLoginServiceImpl implements UMLoginService {

	// 日志
	private static Log logger = LogFactory.getLog(UMLoginServiceImpl.class);
	private static String API_PINGAN_ACCESS_TOKEN_KEY = "api_pingan_access_token";
	private static String GET_ACCESS_TOKEN_URL = "/oauth/oauth2/access_token";
	private static String UM_AUTHENTICATE_URL = "/open/um_search/authenticate.do";

	// api.pingan.com.cn
	@Value("#{serverConstants['api.pingan.home.url']}")
	private String apiHomeUrl;
	// 应用ID
	@Value("#{serverConstants['api.pingan.client.id']}")
	private String clientId;
	// 应用密码
	@Value("#{serverConstants['api.pingan.client.secret']}")
	private String clientSecret;
	// 应用认证方式
	@Value("#{serverConstants['api.pingan.client.grant.type']}")
	private String grantType;
	@Value("#{serverConstants['um.rsa.modulus']}")
	private String modulus;
	@Value("#{serverConstants['um.ras.exponent']}")
	private String exponent;

	@Autowired
	private HtUserMapper htUserMappper;

	@Autowired
	private CasUserMapper casUserMapper;

	@Autowired
	private HyUserLoginCheckMapper hyUserLoginCheckMapper;

	@Autowired
	private HtUserLoginCheckMapper htUserLoginCheckMapper;

	@Autowired
	private CommonJedis commonJedis;

	@Override
	public JsonResponse<Void> login(String userId, String password, String loginType) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		try {

			String xml = invoke(userId, password);
			SAXReader saxReader = new SAXReader();
			Document document = saxReader.read(new ByteArrayInputStream(xml.getBytes()));

			Element retData = (Element) document.selectSingleNode("/UMClientResponse/data");
			Element retCode = (Element) document.selectSingleNode("/UMClientResponse/returnCode");
			
			// 13002:非法的access_token
			// 13012:已失效的access_token
			if ("13002".equals(retCode.getStringValue()) || "13012".equals(retCode.getStringValue())) {
				// 清空access_token，并重新认证
				commonJedis.removeObject(API_PINGAN_ACCESS_TOKEN_KEY);
				xml = invoke(userId, password);
				saxReader = new SAXReader();
				document = saxReader.read(new ByteArrayInputStream(xml.getBytes()));

				retData = (Element) document.selectSingleNode("/UMClientResponse/data");
				retCode = (Element) document.selectSingleNode("/UMClientResponse/returnCode");
			}

			String code = retCode.getStringValue();
			String data = retData.getStringValue();
			logger.info("um login by userId and password " + userId + "," + MD5.getMD5Str(password) + "," + code + "," + data);
			// 返回的data前为0000000000表示认证失败
			if ("0".equals(code) && !data.startsWith("0000000000")) {
				if ("A".equals(loginType)) {
					// A端用户认证成功，检测用户是否存在，如果不存在，侧创建用户
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("userCode", userId);
					map.put("delFlag", 0);
					List<HtUser> list = htUserMappper.findByProperties(map);
					if (list == null || list.size() == 0) {
						// 用户不存在，创建用户
						HtUser htUser = new HtUser();
						htUser.setId(UUID.randomUUID().toString());
						htUser.setUserCode(userId);
						htUser.setName(userId);
						htUser.setPassword(MD5.getMD5Str(password));
						htUser.setEmail(userId + "@pingan.com.cn");
						htUser.setPwdInitFlag("user");
						htUser.setStatus("1");
						htUser.setDelFlag("0");
						htUser.setCreateDate(new Date());
						htUser.setCreateUser("um-login");
						htUser.setModifyDate(new Date());
						htUser.setModifyUser("um-login");
						htUserMappper.insert(htUser);
					} else {
						// 用户已存在，更新用户密码
						HtUser htUser = list.get(0);
						htUser.setPassword(MD5.getMD5Str(password));
						htUser.setDelFlag("0");
						htUser.setModifyDate(new Date());
						htUser.setModifyUser("um-login");
						htUserMappper.update(htUser);

						// A端密码错误次数清0
						HtUserLoginCheck hyUserLoginCheck = htUserLoginCheckMapper.selectByPrimaryKey(htUser.getId());
						if (hyUserLoginCheck != null) {
							hyUserLoginCheck.setMemberId(htUser.getId());
							hyUserLoginCheck.setCheckFailNum(0L);
							hyUserLoginCheck.setUpdateDate(new Date());
							htUserLoginCheckMapper.updateByPrimaryKeySelective(hyUserLoginCheck);
						}
					}
				} else {
					// C端密码错误次数清0
					CasUserExample example = new CasUserExample();
					CasUserExample.Criteria criteria = example.createCriteria();
					criteria.andLoginNameEqualTo(userId);
					criteria.andDelFlagEqualTo("0");
					List<CasUser> list = casUserMapper.selectByExample(example);
					if (list != null && list.size() > 0) {
						HyUserLoginCheck hyUserLoginCheck = hyUserLoginCheckMapper.selectByPrimaryKey(list.get(0).getId());
						if (hyUserLoginCheck != null) {
							hyUserLoginCheck.setMemberId(hyUserLoginCheck.getMemberId());
							hyUserLoginCheck.setCheckFailNum(0L);
							hyUserLoginCheck.setUpdateDate(new Date());
							hyUserLoginCheckMapper.updateByPrimaryKeySelective(hyUserLoginCheck);
						}
					}
				}
			} else {
				result.setStatus(JsonResponse.Status.ERROR);
				result.setErrorCode("umAuthFailed");
				result.setErrorMsg("用户名或密码不正确！");
			}
		} catch (Exception e) {
			logger.error("umLoginServiceImpl抛出异常：" + e.getMessage(), e);
			result.setStatus(JsonResponse.Status.ERROR);
			result.setErrorCode("error");
			result.setErrorMsg("系统繁忙，请稍后再试！");
		}

		return result;
	}

	private String invoke(String userId, String password) throws Exception {
		// 获取accessToken
		long timeMillis = System.currentTimeMillis();
		String accessToken = getAccessToken();

		PublicKey pubKey = RSA2.genPublicKey(modulus, exponent);
		// 时间\n\nUM账号\n密码
		String orgData = timeMillis + "\n\n" + userId + "\n" + password;
		String ciphertext = RSA2.encrypt(pubKey, orgData);

		RestTemplate restTemplate = new RestTemplate();
		StringBuffer url = new StringBuffer();
		url.append(apiHomeUrl + UM_AUTHENTICATE_URL);
		url.append("?access_token=" + accessToken);
		url.append("&request_id=" + timeMillis);
		url.append("&ciphertext=" + ciphertext);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(new MediaType("application", "json", Charset.forName("UTF-8")));

		HttpEntity<String> requestEntity = new HttpEntity<String>(StringUtils.EMPTY, headers);
		ResponseEntity<String> exchange = restTemplate.exchange(url.toString(), HttpMethod.POST, requestEntity,
				String.class);
		return exchange.getBody();
	}

	private String getAccessToken() {
		Object obj = commonJedis.getObject(API_PINGAN_ACCESS_TOKEN_KEY);
		if (obj == null) {
			RestTemplate restTemplate = new RestTemplate();
			StringBuffer url = new StringBuffer();
			url.append(apiHomeUrl + GET_ACCESS_TOKEN_URL);
			url.append("?client_id=" + clientId);
			url.append("&grant_type=" + grantType);
			url.append("&client_secret=" + clientSecret);
			String tokenResult = restTemplate.getForObject(url.toString(), String.class);
			JSONObject result = JSON.parseObject(tokenResult);

			String token = result.getJSONObject("data").getString("access_token");
			logger.info("get new access token from api.pingan.com.cn " + token);

			commonJedis.putObject(API_PINGAN_ACCESS_TOKEN_KEY, token, 360);
			return token;
		} else {
			return obj.toString();
		}
	}
}
