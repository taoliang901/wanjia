package com.wanjia.dsi.web.area.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.web.area.dao.mapper.ProvinceAndCityMapper;
import com.wanjia.dsi.web.area.model.ProvinceAndCity;
import com.wanjia.dsi.web.area.service.ProvinceAndCityService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class ProvinceAndCityServiceImpl implements ProvinceAndCityService {
	@Autowired
	private ProvinceAndCityMapper provinceAndCityMapper;

	private static final Logger logger = LoggerFactory.getLogger(ProvinceAndCityServiceImpl.class);

	@Override
	public JsonResponse<List<ProvinceAndCity>> getProvinceAndCitys() {
		JsonResponse<List<ProvinceAndCity>> jr = new JsonResponse<List<ProvinceAndCity>>();
		try {
			List<ProvinceAndCity> list = provinceAndCityMapper.getProvinceAndCitys();
			jr.setResult(list);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ProvinceAndCityServiceImpl --- getProvinceAndCitys", e);
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}

	@Override
	public JsonResponse<List<ProvinceAndCity>> getProvinceAndCityAndDistrict() {
		JsonResponse<List<ProvinceAndCity>> jr = new JsonResponse<List<ProvinceAndCity>>();
		try {
			List<ProvinceAndCity> list = provinceAndCityMapper.getProvinceAndCityAndDistrict();
			//logger.info("district:"+list.get(0).getchildren().get(0).getChildren());
			jr.setResult(list);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ProvinceAndCityServiceImpl --- getProvinceAndCityAndDistrict", e);
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}

}
