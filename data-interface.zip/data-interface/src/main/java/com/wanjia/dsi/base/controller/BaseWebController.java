package com.wanjia.dsi.base.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.dictionary.model.Dictionary;
import com.wanjia.dsi.web.doctor.model.Doctor;



/**
 * Created by liuyao on 2014/9/9.
 */

public class BaseWebController {

	/*@Autowired
	private MessageSource messageSource;

	@Resource
	private Properties applicationConstantsProps;

	

	public Properties getAppConstants() {
		return applicationConstantsProps;
	}*/

	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	
	@Autowired
	private RestTemplate  restTemplate;
	
	
	
	/**
	 * Handle exception
	 * 
	 * @param exception
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	/*@ExceptionHandler(Exception.class)
	protected void handleException(Exception exception,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.error("", exception);
		if (RequestUtils.isJsonRequest(request)) {
			if (exception instanceof AppException) {
				request.setAttribute("errorCode", ReturnCode.E_2001);
				request.setAttribute("exceptionDetails", exception.getMessage());
			} else {
				request.setAttribute("errorCode", ReturnCode.E_1001);
				request.setAttribute("exceptionDetails", ReturnMessage.E_DEFAULE_MSG);
			}
			RequestUtils.forward(request, response, "/system/handleJsonException");
//			handleJsonException(request);
		} else {
			RequestUtils.forward(request, response, "/system/error/500");

			// Forward to 500.jsp to display the exception
			// throw new Exception(exception);
		}

	}
*/
	/**
	 * 判空
	 * @param params
	 * @throws Exception
	 */
	protected void checkParams(String... params) throws Exception {
		if (params != null) {
			for (String param : params) {
				if (StringUtils.isBlank(param)) {
					throw new Exception(ErrorType.MustPassParameter.getDesc());
				}
			}
		}
	}
	
	/**
	 * 判空
	 * @param params
	 * @throws Exception
	 */
	protected void checkParamsContains(String regex,String... params) throws Exception {
		if (params != null) {
			for (String param : params) {
				if (StringUtils.isBlank(param)) {
					if(param.contains(regex)){
						throw new Exception(ErrorType.IllegalArgument.getDesc());
					}
					
				}
			}
		}
	}
	
	
	
	
	
	
	
	/**
	 * 判断数字
	 * @param params
	 * @throws Exception
	 */
	protected void checkParamsInteger(String... params) throws Exception {
		if (params != null) {
			for (String param : params) {
				if (StringUtils.isNotBlank(param)) {
					if (!StringUtils.isNumeric(param)) {
						throw new Exception(ErrorType.IllegalArgument.getDesc());
					}
				}
			}
		}
	}
	
	/**
	 * 从请求参数设置pageNo
	 * @param pageNo
	 * @return
	 */
	protected int getPageNo(String pageNo) {
		int targetPageNo = 1;
		if (pageNo != null) {
			if (StringUtils.isNumeric(pageNo) && !pageNo.startsWith("0")) {
				targetPageNo = Integer.parseInt(pageNo);
			}
		}
		return targetPageNo;
	}
	
	public int getOffset(int pageNo,int pageSize){
		return pageNo>1?(pageNo-1)*pageSize:0;
	}
	
	
	public <T> PageInfo getPageInfo(int pageNo,int pageSize,List<T> list){
		PageHelper.startPage(pageNo, pageSize);//设置分页页号和页码
		PageInfo<T> page = new PageInfo<T>(list);//获得分页信息
		return page;
	}
	
	
	
	
	
	
	
	
	/**
	 * 从请求参数设置pageSize
	 * @param pageSize
	 * @return
	 */
	/*protected int getPageSize(String pageSize) {
		int targetPageSize = PageCons.PAGET_SIZE;
		if (pageSize != null) {
			if (StringUtils.isNumeric(pageSize) && !pageSize.startsWith("0")) {
				targetPageSize = Integer.parseInt(pageSize);
			}
		}
		return targetPageSize;
	}*/
	
	
	public String getCityByIpOnTaobao(String ip, String debugSwitch, String getCityListFromTabao) {

		String city = "";
		try {

			if (debugSwitch != null && "1".equals(debugSwitch)) {
				Properties prop = System.getProperties();
				// 设置http访问要使用的代理服务器的地址
				prop.setProperty("http.proxyHost", "10.37.84.115");
				// 设置http访问要使用的代理服务器的端口
				prop.setProperty("http.proxyPort", "8080");
			}

			city = restTemplate.getForObject(getCityListFromTabao + "?ip=" + ip, String.class);
			
		} catch (RestClientException e1) {
			logger.error(e1.getMessage());
		} finally {
			if (debugSwitch != null && "1".equals(debugSwitch)) {
				System.getProperties().clear();
			}

		}
		return city;
	}
	
	
	
	public void pringLog(Object object){
		logger.info(object.toString());
	}
	
	
	public <T> Object getT(String object,Class<T> t){
		T parseObject = null;
		try {
			 parseObject = JSONObject.parseObject(object, t);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return parseObject;
	}
	
	
	
	
	
	
	
	
	
	
	
}
