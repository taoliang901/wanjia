package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.CollectionUtils;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderDetailMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderDetailServiceMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderMapper;
import com.wanjia.dsi.product.dao.mapper.PrdServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdOrderDetailMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdOrderDetailServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdOrderMapper;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.PrdKucunExample;
import com.wanjia.dsi.product.model.PrdOrder;
import com.wanjia.dsi.product.model.PrdOrderDetail;
import com.wanjia.dsi.product.model.PrdOrderDetailExample;
import com.wanjia.dsi.product.model.PrdOrderDetailService;
import com.wanjia.dsi.product.model.PrdOrderDetailServiceExample;
import com.wanjia.dsi.product.model.PrdOrderExample;
import com.wanjia.dsi.product.model.PrdService;
import com.wanjia.dsi.product.model.PrdServiceExample;
import com.wanjia.dsi.product.model.VOPrdOrderBO;
import com.wanjia.dsi.product.repository.PrdOrderBORepository;
import com.wanjia.dsi.product.service.PrdTradeService;
import com.wanjia.dsi.product.service.StockService;
@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class PrdTradeServiceImpl implements PrdTradeService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	
	@Autowired
	private VOPrdOrderMapper vOPrdOrderMapper;
	
	@Autowired
	private PrdInfoMapper prdInfoMapper;
	
	@Autowired
	private VOPrdOrderDetailMapper vOPrdOrderDetailMapper;
	
	@Autowired
	private PrdKucunMapper prdKucunMapper;

	@Autowired
	private PrdOrderMapper prdOrderMapper;
	
	@Autowired
	private PrdOrderDetailMapper prdOrderDetailMapper;
	
	@Autowired
	private StockService stockService;
	
	@Autowired
	private PrdServiceMapper prdServiceMapper;
	
	
	@Autowired
	private PrdOrderDetailServiceMapper prdOrderDetailServiceMapper;
	
	@Autowired
	private VOPrdOrderDetailServiceMapper voPrdOrderDetailServiceMapper;
	
	@Autowired
	private PrdOrderBORepository prdOrderBORepository;
	
	@Override
	public JsonResponse<Map<String,String>> addPrdToUser(String userId, String prdId, String batchCode,int number,String buychannel) {
		logger.info("开始锁定库存===============");
		logger.info("参数：userId:"+userId+"---prdId:"+prdId+"---batchCode:"+batchCode+"----number:"+number+"------buychannel:"+buychannel);
		//购买成功后向用户分配产品
		JsonResponse<Map<String,String>>jr = new JsonResponse<Map<String,String>>();
		
		//从缓存中查询，先看产品是否有足够库存
		JsonResponse<Integer> jr1 = selectRemaindedPrdKucun(prdId);
		
		if(null==jr1||jr1.getResult()<number){
			logger.info("库存余额为："+jr1.getResult());
			throw new ServiceException(ErrorType.NotEnoughPrdKucun.getCode(), ErrorType.NotEnoughPrdKucun.getDesc());
		}
		Map<String, Map<String, String>> stocks =new HashMap<String, Map<String, String>>();
		
		//消耗redis库存
		JsonResponse<Map<String, String>> freeStockResp = stockService.getFreeStock(prdId, number);
		if(null==freeStockResp||freeStockResp.getResult()==null){
			throw new ServiceException(ErrorType.Other.getCode(), "锁定库存失败");
		}
		//把库存表的设置为消耗
		stocks.put(prdId, freeStockResp.getResult());
		
		stockService.setStockStatusBatch(stocks);
		
		Map<String, String> stockMap = freeStockResp.getResult();
		//kucunIds
		StringBuffer sb1 = new StringBuffer();
		//allcardNos
		StringBuffer sb2 = new StringBuffer();
		Set<String> set = stockMap.keySet();
		
		for (String kucunId : set) {
			sb1.append(kucunId+",");
			sb2.append(stockMap.get(kucunId)+",");
		}
		//redis和mongodb消耗库存
		Map<String,String> reslut = new HashMap<String,String>();
		reslut.put("kucunIds", new String(sb1));
		reslut.put("allCardNos", new String(sb2));
		jr.setResult(reslut);
		logger.info("结束锁定库存===========");
		return jr;
	}

	@Override
	public JsonResponse<Integer> selectRemaindedPrdKucun(String prdId) {
		JsonResponse<Integer> jr = new JsonResponse<Integer>();
		JsonResponse<Map<String, Integer>> jr1 = stockService.getStockTotalNumber(prdId);
		JsonResponse<Map<String, Integer>> jr2 = stockService.getStockUsedNumber(prdId);
		if(null!=jr1&&null!=jr2){
			Map<String, Integer> result1 = jr1.getResult();
			Map<String, Integer> result2 = jr2.getResult();
			if(result1!=null&&result2!=null){
				jr.setResult(result1.get(prdId)-result2.get(prdId));
			}
		}
		return jr;
	}

	

	@Override
	public JsonResponse<Void> delUserPrd(List<String> prdKucunIds,List<String> allCardNos,String userId) {
		//取消订单，只需要删除redis和mongodb的数据
		logger.info("取消订单开始,userId:"+userId+"-----prdKucunIds:"+prdKucunIds);
		JsonResponse<Void> jr = new JsonResponse<Void>();
		if(CollectionUtils.isEmpty(prdKucunIds)||CollectionUtils.isEmpty(allCardNos)||prdKucunIds.size()!=allCardNos.size()){
			throw new ServiceException(ErrorType.Other.getCode(),"kucunid和完整卡号必须匹配");
		}
		PrdKucun prdKucun = prdKucunMapper.selectByPrimaryKey(prdKucunIds.get(0));
		HashMap<String, String> stocks = new HashMap<String, String>();
		for(int i=0;i<prdKucunIds.size();i++){
			stocks.put(prdKucunIds.get(i), allCardNos.get(i));
		}
		//释放已经消耗的kucun
		stockService.restoreStock(prdKucun.getCouponId(), stocks);
		logger.info("删除用户订单表数据结束");
		return jr;
	}

	@Override
	public JsonResponse<Void> addPrdOrderToUser(List<String> prdKucunIds, String userId, String prdId) {
		//付完款后才会实际上进行库存的消耗
		JsonResponse<Void> jr = new JsonResponse<Void>();
		
		if(prdKucunIds==null||prdKucunIds.size()==0){
			throw new ServiceException(ErrorType.ObjectIsNull.getCode(), "卡号不得为空");
		}
		PrdKucun prdKucun = prdKucunMapper.selectByPrimaryKey(prdKucunIds.get(0));
		if(prdKucun==null){
			throw new ServiceException(ErrorType.ObjectIsNull.getCode(), "库存信息为空");
		}
		//设置产品id说
		prdId= prdKucun.getCouponId();
		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		if(prdInfo==null){
			throw new ServiceException(ErrorType.Other.getCode(), "无该产品");
		}
		PrdKucunExample example = new PrdKucunExample();
		PrdKucunExample.Criteria criteria = example.createCriteria();
		criteria.andIdIn(prdKucunIds);
		//未删除
		criteria.andDelFlagEqualTo("0");
		//未消耗
		criteria.andStatusEqualTo("0");
		//没有所属人
		PrdKucun record = new PrdKucun();
		//不再设置购买人
//		record.setBuyerUserId(userId);
		record.setStatus("1");
		record.setModifyDate(new Date());
		record.setModifyUser(String.valueOf(userId));
		record.setBuyChannel("3");
		if(!"0".equals(prdInfo.getIsValidFrom())){
			record.setValidBeginDate(prdInfo.getPrdBeginDate());
			record.setValidEndDate(prdInfo.getPrdEndDate());
		}
		int count1 = prdKucunMapper.updateByExampleSelective(record,example);
		//生成通知消耗掉kucun信息
		if(count1!=prdKucunIds.size()){
			logger.error("库存表更新数量和购买数量不匹配,库存表更新数量为："+count1);
			throw new ServiceException(ErrorType.Other.getCode(), "库存表更新数量和购买数量不匹配");
		}
		
		//执行插入订单操作
		List<PrdOrder> orderList = new ArrayList<PrdOrder>();
		//mogondb中记录信息
		
		List<VOPrdOrderBO> list = new ArrayList<VOPrdOrderBO>();
		for(int i=0;i<prdKucunIds.size();i++){
			PrdOrder prdOrder = new PrdOrder();
			String orderId = CommonTools.generateUUID();
			prdOrder.setId(orderId);
			//TODO 设置buychannel
			prdOrder.setBuyChannel("4");
			prdOrder.setUserId(Long.valueOf(userId));
			prdOrder.setCreateUser(userId);
			prdOrder.setCreateDate(new Date());
			orderList.add(prdOrder);
			
			VOPrdOrderBO voPrdOrderBO = new VOPrdOrderBO();
			//
			voPrdOrderBO.setOrderId(orderId);
			voPrdOrderBO.setCreateUser(userId);
			voPrdOrderBO.setCreateDate(new Date());
			//设置标志  1 新创建 2 转增 3 删除
			voPrdOrderBO.setStatus("1");
			
			list.add(voPrdOrderBO);
		}
		int count2 = vOPrdOrderMapper.insertPrdOrderList(orderList);
		if(count2!=orderList.size()){
			throw new ServiceException(ErrorType.Other.getCode(), "订单表插入数据和购买数量不匹配");
		}
		logger.info("订单表插入数据成功");
		//第二步 插入订单详细表
		
		List<PrdOrderDetail> orderDetailList = new ArrayList<PrdOrderDetail>();
		for(int i=0;i<prdKucunIds.size();i++){
			String orderDetailId;
			orderDetailId =  CommonTools.generateUUID();
			PrdOrderDetail  prdOrderDetail = new PrdOrderDetail();
			prdOrderDetail.setId(orderDetailId);
			prdOrderDetail.setOrderId(orderList.get(i).getId());
			prdOrderDetail.setKucunId(prdKucunIds.get(i));
			prdOrderDetail.setPrdId(prdInfo.getId());
			// 设置产品字段
			CommonTools.setProductInfo(Long.valueOf(userId), prdInfo, prdOrderDetail);
			
			
			prdOrderDetail.setIsSupportBuyOnline(prdInfo.getIsSupportBuyOnline());
			prdOrderDetail.setIsInsurancePrd(prdInfo.getIsInsurancePrd());
			prdOrderDetail.setInsuranceFilename(prdInfo.getInsuranceFilename());
			prdOrderDetail.setInsuranceFilepath(prdInfo.getInsuranceFilepath());
			orderDetailList.add(prdOrderDetail);
		}
		int count3 = vOPrdOrderDetailMapper.insertPrdOrderDetailList(orderDetailList);
		if(count3!=count1){
			throw new ServiceException(ErrorType.Other.getCode(), "订单详情表插入数据和导入人数量不匹配");
		}
		logger.info("prdorderdetai表插入数据成功");
		//第三步插入订单服务详情记录表
		//订单服务详细表新增
		PrdServiceExample ser = new PrdServiceExample();
		PrdServiceExample.Criteria crit = ser.createCriteria();
		crit.andPrdIdEqualTo(prdInfo.getId());
		List<PrdService> serviceList = prdServiceMapper.selectByExample(ser);
		if(CollectionUtils.isEmpty(serviceList)){
			throw new ServiceException(ErrorType.Other.getCode(), "产品服务项目不得为空");
		}
		List<PrdOrderDetailService> prdOrderServiceList = new ArrayList<PrdOrderDetailService>();
	
		for(int i=0;i<prdKucunIds.size();i++){
			for(PrdService service : serviceList){
				PrdOrderDetailService prdOrderDetailService = new PrdOrderDetailService();
				prdOrderDetailService.setId(CommonTools.generateUUID());
				prdOrderDetailService.setOrderDetailId(orderDetailList.get(i).getId());
				prdOrderDetailService.setPrdId(prdId);
				prdOrderDetailService.setServiceId(service.getServiceId());
				prdOrderDetailService.setServiceCount(service.getServiceCount());
				prdOrderDetailService.setIsUnlimite(service.getIsUnlimite());
				prdOrderDetailService.setDelFlag(service.getDelFlag());
				prdOrderDetailService.setCreateUser(userId);
				prdOrderDetailService.setCreateDate(new Date());
				prdOrderServiceList.add(prdOrderDetailService);
			}
			//批量插入详情表
		}
		int count4 = voPrdOrderDetailServiceMapper.insertPrdOrderDetailServiceBatch(prdOrderServiceList);
		//判断
		if(count4!=prdKucunIds.size()*serviceList.size()){
			throw new ServiceException(ErrorType.Other.getCode(), "订单服务详情表插入为0");
		}
		logger.info("prdorderdetailservice表插入数据成功");
		

		//mongo中插入数据
		prdOrderBORepository.insertBatch(list,VOPrdOrderBO.class);
		logger.info("mogondb中插入订单记录信息成功");
		
		logger.info("结束插入订单数据--------------------");
		
		return jr;
	}
	
	//未来退货时候需要执行的代码，删除订单详细表和订单表数据
	@Override
	public JsonResponse<Void> delUserPrdOrder(List<String> prdKucunIds, String userId){
		logger.info("开始取消订单数据--------------------");
		JsonResponse<Void> jr = new JsonResponse<Void>();
		if(CollectionUtils.isEmpty(prdKucunIds)){
			throw new ServiceException(ErrorType.Other.getCode(), "库存不能为空");
		}

		
		
		PrdKucunExample example = new PrdKucunExample();
		PrdKucunExample.Criteria criteria = example.createCriteria();
		//设置库存id的集合
		criteria.andIdIn(prdKucunIds);
		//释放库存
		List<PrdKucun> listPrdKucun = prdKucunMapper.selectByExample(example);
		//查询到的订单数目
		if(listPrdKucun==null||listPrdKucun.size()!=prdKucunIds.size()){
			throw new ServiceException(ErrorType.Other.getCode(), "查询的库存表数目和kucunId集合数目不匹配，查询到的数目为："+listPrdKucun.size());
		}
		HashMap<String, String> stocks = new HashMap<String, String>();
		for(int i=0;i<listPrdKucun.size();i++){
			stocks.put(listPrdKucun.get(i).getId(), listPrdKucun.get(i).getAllCardNo());
		}
		//释放已经消耗的kucun
		stockService.restoreStock(listPrdKucun.get(0).getCouponId(), stocks);
		
		
		//取消库存表数据
		PrdKucun record = new PrdKucun();
		PrdKucun prdKucun = listPrdKucun.get(0);
		//批量更新库存表	
		record.setBuyerUserId("");
		record.setStatus("0");
		record.setModifyDate(new Date());
		record.setModifyUser("");
		record.setBuyChannel("");
		//更新prdkucun设置状态为未消耗
		int count1 = prdKucunMapper.updateByExampleSelective(record, example);
		if(count1!=prdKucunIds.size()){
			throw new ServiceException(ErrorType.Other.getCode(), "更新库存表的数目和kucunIds数目不匹配，更新到的数目为："+count1);
		}
		//
		logger.info("释放数据库库存数据成功");
		//释放 redis库存
		String[] str = new String[prdKucunIds .size()]; 
		//回复库存，删除已经消耗掉的库存
		stockService.delStockStatus(prdKucun.getCouponId(), prdKucunIds.toArray(str));
		logger.info("释放redis库存数据成功");
		//然后删除订单表数据
		PrdOrderDetailExample example2 = new PrdOrderDetailExample();
		PrdOrderDetailExample.Criteria criteria2 = example2.createCriteria();
		criteria2.andKucunIdIn(prdKucunIds);
		//先查询出订单详细表数据
		List<PrdOrderDetail> prdorderList = prdOrderDetailMapper.selectByExample(example2);
		if(prdorderList==null||prdorderList.size()!=prdorderList.size()){
			throw new ServiceException(ErrorType.Other.getCode(), "订单详细表的数目和kucunIds数目不匹配，更新到的数目为："+prdorderList.size());
		}
		PrdOrderDetail record2 = new PrdOrderDetail();
		record2.setDelFlag("1");
		//删除订单详细表数据，逻辑删除
		int count2 = prdOrderDetailMapper.updateByExampleSelective(record2 , example2);
		if(count2!=prdKucunIds.size()){
			throw new ServiceException(ErrorType.Other.getCode(), "更新订单详细表的数目和kucunIds数目不匹配，更新到的数目为："+count2);
		}
		
		logger.info("逻辑删除订单详细表数据成功");
		
		PrdOrder record3 = new PrdOrder();
		PrdOrderExample example3 = new PrdOrderExample();
		PrdOrderExample.Criteria criteria3 = example3.createCriteria();
		//取出所有的订单id
		List<String> orderIds = new ArrayList<String>();
		//mongodb记录日志
		List<VOPrdOrderBO> list = new ArrayList<VOPrdOrderBO>();
		
		for (PrdOrderDetail prdOrderDetail : prdorderList) {
			orderIds.add(prdOrderDetail.getOrderId());
			VOPrdOrderBO voPrdOrderBO = new VOPrdOrderBO();
			//
			voPrdOrderBO.setOrderId(prdOrderDetail.getOrderId());
			voPrdOrderBO.setCreateUser(userId);
			voPrdOrderBO.setCreateDate(new Date());
			//设置标志  1 新创建 2 转增
			voPrdOrderBO.setStatus("1");
			
			list.add(voPrdOrderBO);
		}
		criteria3.andIdIn(orderIds);
		//设置订单删除标志
		record3.setDelFlag("1");
		//删除订单表的数据，逻辑删除
		//prdOrderMapper.updateByExampleSelective(record1, example1);啥
		int count3 = prdOrderMapper.updateByExampleSelective(record3, example3);
		if(count3!=count2){
			throw new ServiceException(ErrorType.Other.getCode(), "更新订单表的数目和kucunIds数目不匹配，更新到的数目为："+count3);
		}
		
		logger.info("逻辑删除订单表数据成功");
		PrdOrderDetailService record4 = new PrdOrderDetailService();
		PrdOrderDetailServiceExample example4 = new PrdOrderDetailServiceExample();
		PrdOrderDetailServiceExample.Criteria criteria4 = example4.createCriteria();
		criteria4.andOrderDetailIdIn(orderIds);
		record4.setDelFlag(1);
		//再把订单服务详情表数据逻辑删除
		prdOrderDetailServiceMapper.updateByExampleSelective(record4, example4);
		
		logger.info("逻辑删除订单服务详细表数据成功");
		
		//向mongo里面取消数据
		prdOrderBORepository.insertBatch(list, VOPrdOrderBO.class);
		
		logger.info("向mongodb中插入删除订单记录成功");
		
		logger.info("取消订单结束-----------");
		
		
		return jr;
	}

	@Override
	public JsonResponse<Void> addPrdToUsers(List<PrdKucun> prdKucuns, List<String> userIds) {
		JsonResponse<Void> jr = new JsonResponse<Void>();
		if(CollectionUtils.isEmpty(prdKucuns)||CollectionUtils.isEmpty(userIds)||userIds.size()!=prdKucuns.size()){
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("参数非法，导入的库存数量和用户数量不匹配");
			return jr;
		}
		
		
		insertPrdOrderToDB(prdKucuns, userIds, null);
		return jr;
	}
	
	/**
	 * 插入订单信息到数据库
	 * @param prdKucunIds
	 * @param userIds
	 * @param prdId
	 */
	private void insertPrdOrderToDB(List<PrdKucun> prdKucuns,List<String> userIds,String prdId){
		//为空或者不匹配都不允许插入
		logger.info("开始插入订单数据--------------------");
		if(CollectionUtils.isEmpty(prdKucuns)||CollectionUtils.isEmpty(userIds)||prdKucuns.size()!=userIds.size()){
			throw new ServiceException(ErrorType.Other.getCode(), "库存数量必须和用户数量匹配");
		}
		//prdInfo的hashmap
		HashMap<String,PrdInfo> infoMap = new HashMap<String,PrdInfo>();
		//如果没有传健康产品id，去查询到相关的产品id
		
		//执行插入订单操作
		List<PrdOrder> orderList = new ArrayList<PrdOrder>();
		//mogondb中记录信息
		
		List<VOPrdOrderBO> list = new ArrayList<VOPrdOrderBO>();
		for(int i=0;i<prdKucuns.size();i++){
			PrdOrder prdOrder = new PrdOrder();
			String orderId = CommonTools.generateUUID();
			prdOrder.setId(orderId);
			//TODO 设置buychannel
			//暂设6为批量导入类型
			prdOrder.setBuyChannel("6");
			prdOrder.setUserId(Long.valueOf(userIds.get(i)));
			prdOrder.setCreateUser(userIds.get(i));
			prdOrder.setCreateDate(new Date());
			orderList.add(prdOrder);
			
			VOPrdOrderBO voPrdOrderBO = new VOPrdOrderBO();
			//
			voPrdOrderBO.setOrderId(orderId);
			voPrdOrderBO.setCreateUser(userIds.get(i));
			voPrdOrderBO.setCreateDate(new Date());
			//设置标志  1 新创建 2 转增 3 删除
			voPrdOrderBO.setStatus("1");
			
			list.add(voPrdOrderBO);
		}
		int count1 = vOPrdOrderMapper.insertPrdOrderList(orderList);
		if(count1!=orderList.size()){
			throw new ServiceException(ErrorType.Other.getCode(), "订单表插入数据和购买数量不匹配");
		}
		logger.info("订单表插入数据成功");
		//第二步 插入订单详细表
		//查询该产品产品信息
		List<PrdOrderDetail> orderDetailList = new ArrayList<PrdOrderDetail>();
		for(int i=0;i<prdKucuns.size();i++){
			//去查询hashmap里面有没有产品id的信息
			PrdInfo prdInfo = infoMap.get(prdKucuns.get(i).getId());
			if(prdInfo==null){
				prdInfo=prdInfoMapper.selectByPrimaryKey(prdKucuns.get(i).getCouponId());
				infoMap.put(prdKucuns.get(i).getCouponId(), prdInfo);
			}
			String orderDetailId;
			orderDetailId =  CommonTools.generateUUID();
			PrdOrderDetail  prdOrderDetail = new PrdOrderDetail();
			prdOrderDetail.setId(orderDetailId);
			prdOrderDetail.setOrderId(orderList.get(i).getId());
			prdOrderDetail.setKucunId(prdKucuns.get(i).getId());
			prdOrderDetail.setPrdId(prdInfo.getId());
			CommonTools.setProductInfo(Long.valueOf(userIds.get(i)), prdInfo, prdOrderDetail);
//			prdOrderDetail.set
			prdOrderDetail.setIsSupportBuyOnline(prdInfo.getIsSupportBuyOnline());
			prdOrderDetail.setIsInsurancePrd(prdInfo.getIsInsurancePrd());
			prdOrderDetail.setInsuranceFilename(prdInfo.getInsuranceFilename());
			prdOrderDetail.setInsuranceFilepath(prdInfo.getInsuranceFilepath());
			
			orderDetailList.add(prdOrderDetail);
		}
		int count2 = vOPrdOrderDetailMapper.insertPrdOrderDetailList(orderDetailList);
		if(count2!=count1){
			throw new ServiceException(ErrorType.Other.getCode(), "订单详情表插入数据和导入人数量不匹配");
		}
		logger.info("prdorderdetai表插入数据成功");
		//第三步插入订单服务详情记录表
		//订单服务详细表新增
		HashMap<String,List<PrdService>> prdServiceMap = new HashMap<String,List<PrdService>>();
		
		
		
		List<PrdOrderDetailService> prdOrderServiceList = new ArrayList<PrdOrderDetailService>();
	
		for(int i=0;i<prdKucuns.size();i++){
			List<PrdService> serviceList = prdServiceMap.get(prdKucuns.get(i).getCouponId());
			if(CollectionUtils.isEmpty(serviceList)){
				//把未出现过的设置进去
				PrdServiceExample ser = new PrdServiceExample();
				PrdServiceExample.Criteria crit = ser.createCriteria();
				crit.andPrdIdEqualTo(prdKucuns.get(i).getCouponId());
				serviceList = prdServiceMapper.selectByExample(ser);
				prdServiceMap.put(prdKucuns.get(i).getCouponId(), serviceList);
			}	
			for(PrdService service : serviceList){
				PrdOrderDetailService prdOrderDetailService = new PrdOrderDetailService();
				prdOrderDetailService.setId(CommonTools.generateUUID());
				prdOrderDetailService.setOrderDetailId(orderDetailList.get(i).getId());
//				prdOrderDetailService.setOrderDetailId(orderList.get(i).getId());
				prdOrderDetailService.setPrdId(orderDetailList.get(i).getPrdId());
				prdOrderDetailService.setServiceId(service.getServiceId());
				prdOrderDetailService.setServiceCount(service.getServiceCount());
				prdOrderDetailService.setIsUnlimite(service.getIsUnlimite());
				prdOrderDetailService.setDelFlag(service.getDelFlag());
				prdOrderDetailService.setCreateUser(String.valueOf(userIds.get(i)));
				prdOrderDetailService.setCreateDate(new Date());
				prdOrderServiceList.add(prdOrderDetailService);
			}
			//批量插入详情表
		}
		int count3 = voPrdOrderDetailServiceMapper.insertPrdOrderDetailServiceBatch(prdOrderServiceList);
		logger.info("插入的服务数目为："+count3);
		logger.info("prdorderdetailservice表插入数据成功");
		
		//mongo中插入数据
		prdOrderBORepository.insertBatch(list,VOPrdOrderBO.class);
		logger.info("mogondb中插入订单记录信息成功");
		
		logger.info("结束插入订单数据--------------------");
	}
	
}
