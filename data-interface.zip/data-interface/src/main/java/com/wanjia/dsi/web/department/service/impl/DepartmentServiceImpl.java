package com.wanjia.dsi.web.department.service.impl;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.esotericsoftware.minlog.Log;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.web.department.dao.mapper.DepartmentMapper;
import com.wanjia.dsi.web.department.model.Department;
import com.wanjia.dsi.web.department.model.DepartmentTree;
import com.wanjia.dsi.web.department.service.DepartmentService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-3-2 下午2:07, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class DepartmentServiceImpl extends BaseServiceImpl implements DepartmentService {
	@Autowired
	private DepartmentMapper departmentMapper;

	
	@Autowired
	private CommonJedis commonJedis;

	@Value("#{jedisConfig['expirationTime']}")
	private int expirationTime;
	
	@Override
	public JsonResponse<List<Department>> findDepartmentByIds(String requestId,List<String> ids) {
		// 返回结果
		JsonResponse<List<Department>> result = new JsonResponse<List<Department>>();
		try {
			List<Department> departments = departmentMapper.findDepartmentByIds(ids);
			// 结果返回
			result.setStatus(Status.SUCCESS);
			result.setResult(departments);
		} catch (Exception e) {
			logger.info("根据Id列表查询科目信息失败:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
	
	@Override
	public Department findById(Long id) {
		return (Department) departmentMapper.findById(id);
	}

	@Override
	public List<Department> findWithPagination(int offset, int count) {
		return (List<Department>) departmentMapper.findWithPagination(offset, count);
	}

	@Override
	public List<Department> findAll() {
		return (List<Department>) departmentMapper.findAll();
	}

	@Override
	public List<Department> findByEntity(Department model) {
		return (List<Department>) departmentMapper.findByEntity(model);
	}

	@Override
	public List<Department> findByEntityWithPagination(Department model, int offset, int count) {
		return (List<Department>) departmentMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	public Department findOneByEntity(Department model) {
		return (Department) departmentMapper.findOneByEntity(model);
	}

	@Override
	public List<Department> findByProperty(String propertyName, String propertyValue) {
		return (List<Department>) departmentMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	public Department findOneByProperty(String propertyName, String propertyValue) {
		return (Department) departmentMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	public List<Department> findByPropertyWithPagination(String propertyName, String propertyValue, int offset,
			int count) {
		return (List<Department>) departmentMapper.findByPropertyWithPagination(propertyName, propertyValue, offset,
				count);
	}

	@Override
	public List<Department> findByProperties(Map<String, Object> map) {
		return (List<Department>) departmentMapper.findByProperties(map);
	}

	@Override
	public long countByEntity(Department model) {
		return (long) departmentMapper.countByEntity(model);
	}

	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		return (long) departmentMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	public long countByProperties(Map<String, Object> map) {
		return (long) departmentMapper.countByProperties(map);
	}

	@Override
	public void update(Department model) {
		departmentMapper.update(model);
	}

	@Override
	public void insert(Department model) {
		departmentMapper.insert(model);
	}

	@Override
	public void deleteByEntity(Department model) {
		departmentMapper.deleteByEntity(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		departmentMapper.deleteByProperty(propertyName, propertyValue);
	}

	public long countAll() {
		return this.departmentMapper.countAll();
	}

	public void insertBatch(List<Department> list) {
		this.departmentMapper.insertBatch(list);
	}

	public void delete(Long id) {
		this.departmentMapper.deleteById(id);
	}

	/*
	 * <p>Title: getDepartmentList</p> <p>Description: </p>
	 * 
	 * @param department
	 * 
	 * @return
	 * 
	 * @see
	 * com.wanjia.dsi.web.department.service.DepartmentService#getDepartmentList
	 * (com.wanjia.dsi.web.department.model.Department)
	 */
	@Override
	public List<Department> getDepartmentList(String requestId,Department department) {
		// TODO Auto-generated method stub
		return this.departmentMapper.getDepartmentList(department);
	}

	@Override
	public JsonResponse<PageInfo<Department>> getDepartmentList(String requestId,String pageNo, String pageSize) {
		JsonResponse<PageInfo<Department>> result = new JsonResponse<PageInfo<Department>>();
		Department department = new Department();
		try {
			department.setDelFlag("0");
			// 设置分页页号和页码
			PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));
			//查询数据库
			List<Department> findByEntity = departmentMapper.findByEntity(department);
			// 获得分页信息
			PageInfo<Department> page = new PageInfo<Department>(findByEntity);
			result.setResult(page);

		} catch (Exception e) {
			// Log.error(e.getMessage());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<PageInfo<Department>> getDepartmentList(String requestId,String pageNo, String pageSize, String departmentId,
			String departmentName, String departmentCode, String departmentDescription, String parentId) {
		// TODO Auto-generated method stub
		JsonResponse<PageInfo<Department>> result = new JsonResponse<PageInfo<Department>>();
		Department department = new Department();
		try {
			//校验和设置参数      start
			department.setDelFlag("0");
			if (StringUtils.isNotBlank(departmentId)) {
				department.setDepartmentId(departmentId);
			}
			if (StringUtils.isNotBlank(departmentName)) {
				department.setDepartmentName(departmentName);
			}
			if (StringUtils.isNotBlank(departmentCode)) {
				department.setDepartmentCode(departmentCode);
			}
			if (StringUtils.isNotBlank(departmentDescription)) {
				department.setDepartmentDescription(departmentDescription);
			}
			if (StringUtils.isNotBlank(parentId)) {
				department.setParentId(parentId);
			}
			
			if(!StringUtils.isNotBlank(pageNo)){
				pageNo = "1";
			}
			if(!StringUtils.isNotBlank(pageSize)){
				pageSize = "10000";
			}
			//校验和设置参数      end
			
			
			// 设置分页页号和页码
			PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));
			//查询数据
			List<Department> findByEntity = departmentMapper.findByEntity(department);
			// 获得分页信息
			PageInfo<Department> page = new PageInfo<Department>(findByEntity);
			result.setResult(page);

		} catch (Exception e) {
			// Log.error(e.getMessage());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<PageInfo<Department>> getDepartmentListInRedis(String requestId,String pageNo, String pageSize, String departmentId,
			String departmentName, String departmentCode, String departmentDescription, String parentId) {
		// TODO Auto-generated method stub
		JsonResponse<PageInfo<Department>> result = new JsonResponse<PageInfo<Department>>();
		Department department = new Department();
		try {
			department.setDelFlag("0");
			/*if (StringUtils.isNotBlank(departmentId)) {
				department.setDepartmentId(departmentId);
			}
			if (StringUtils.isNotBlank(departmentName)) {
				department.setDepartmentName(departmentName);
			}
			if (StringUtils.isNotBlank(departmentCode)) {
				department.setDepartmentCode(departmentCode);
			}
			if (StringUtils.isNotBlank(departmentDescription)) {
				department.setDepartmentDescription(departmentDescription);
			}*/
			/*if (StringUtils.isNotBlank(parentId)) {
				//if ("0".equals(parentId)) {
					department.setParentId(parentId);
					
				//}
			}else{
				department.setParentId("0");
			}*/
			//校验和设置参数      
			if (StringUtils.isBlank(parentId)) {
				parentId = "0";
			}
			department.setParentId(parentId);
			//是否在redis
			if (!commonJedis.exists(Consts.GET_DEPARTMENT_LIST_INREDIS+"_"+parentId)) {
				this.pringLog("dictCode.not exists");
				//PageHelper.startPage(pageNo, pageSize);// 设置分页页号和页码
				//不在 数据库查找
				List<Department> findByEntity = departmentMapper.findByEntity(department);
				// 获得分页信息
				PageInfo<Department> page = new PageInfo<Department>(findByEntity);
				//放redis
				commonJedis.addObject(Consts.GET_DEPARTMENT_LIST_INREDIS+"_"+parentId, page, expirationTime);
				result.setResult(page);
			} else {
				//redis有
				this.pringLog("dictCode exists");
				//redis取
				PageInfo<Department> page = (PageInfo<Department>)commonJedis.getObject(Consts.GET_DEPARTMENT_LIST_INREDIS+"_"+parentId);
				result.setResult(page);
			}

		} catch (Exception e) {
			// Log.error(e.getMessage());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
	
	@Override
	public JsonResponse<List<Department>> findInCmsDepartMent(String requestId,String cmsDepartmentId, String publishGroupId, String departmentId,
			String departmentName, String departmentCode, String parentId) {
		// TODO Auto-generated method stub
		JsonResponse<List<Department>> result = new JsonResponse<List<Department>>();
		Department cmsDepartment = new Department();
		try {
			/*if(StringUtils.isNotBlank(cmsDepartmentId)){
				map.put("cmsDepartmentId", cmsDepartmentId);
			}
			if(StringUtils.isNotBlank(publishGroupId)){
				map.put("publishGroupId", publishGroupId);
			}
			if(StringUtils.isNotBlank(departmentId)){
				map.put("departmentId", departmentId);
			}
			if(StringUtils.isNotBlank(departmentName)){
				map.put("departmentName", departmentName);
			}
			if(StringUtils.isNotBlank(departmentCode)){
				map.put("departmentCode", departmentCode);
			}*/
			//设置参数
			if(StringUtils.isNotBlank(parentId)){
				cmsDepartment.setParentId(parentId);
			}
			cmsDepartment.setDelFlag("0");
			//查询并返回数据
			result.setResult(departmentMapper.findInCmsDepartMent(cmsDepartment));
		} catch (Exception e) {
			// Log.error(e.getMessage());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return result;
	}
	
	
	
	@Override
	public JsonResponse<List<DepartmentTree>> findDepartmentByParentIds(List<String> parentIds,List<String> parentNames) {
		JsonResponse<List<DepartmentTree>> result = new JsonResponse<List<DepartmentTree>>();
		try {
			result.setResult(this.getList(parentIds,parentNames));
		} catch (Exception e) {
			// Log.error(e.getMessage());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return result;
	}
	@SuppressWarnings("unchecked")
	private List<DepartmentTree> getList(List<String> parentIds,List<String> parentNames){
		List<DepartmentTree> tree = new ArrayList<DepartmentTree>();
		List<Department> findByEntity =null;
		if(CollectionUtils.isNotEmpty(parentIds)&&CollectionUtils.isNotEmpty(parentNames)){
			for(int i=0;i<parentIds.size();i++){
				DepartmentTree t = new DepartmentTree();
				findByEntity = new ArrayList<Department>();
				//是否在redis
				if(commonJedis.exists(Consts.FIND_DEPARTMENT_BY_PARENTIDS+parentIds.get(i))){
					//在
					findByEntity = (List<Department>)commonJedis.getObject(Consts.FIND_DEPARTMENT_BY_PARENTIDS+parentIds.get(i));
				}else{
					//是否在redis
					//不在，从数据库查并放redis
					findByEntity = this.getList(parentIds.get(i), parentNames.get(i));
					commonJedis.addObject(Consts.FIND_DEPARTMENT_BY_PARENTIDS+parentIds.get(i), findByEntity, expirationTime);
				}
				//设置字段信息
				if(CollectionUtils.isNotEmpty(findByEntity)){
					t.setId(parentIds.get(i));
					t.setName(parentNames.get(i));
					t.setList(findByEntity);
					tree.add(t);
				}
			}
		}
		return tree;
		
	}
	@SuppressWarnings("unchecked")
	public List<Department> getList(String id,String name){
		Department  department = new Department();
		department.setParentId(id);
		department.setDelFlag("0");
		List<Department> findByEntity = departmentMapper.findByEntity(department);
		/*if(CollectionUtils.isNotEmpty(findByEntity)){
			for (Department department2 : findByEntity) {
				department2.setParentId(id);
				if(StringUtils.isNotBlank(name)){
					department2.setParentName(name);
				}
			}
		}*/
		return findByEntity;
	}
	
	
	@Override
	public String getDiagnosisType(String code) {
		// TODO Auto-generated method stub
		Map<String, Department> diagnosisType = this.getDiagnosisType();
		
		StringBuilder builder = new StringBuilder();
		if(StringUtils.isNotBlank(code)){
			
			
			String[] split = code.split("\\|");
			
			for(int i =0;i<split.length;i++){
				Department department = diagnosisType.get(split[i]);
				if(department !=null){
					String name = department.getDepartmentName();
					if(StringUtils.isNotBlank(name)){
						if(i==(split.length-1)){
							builder.append(name);
						}else{
							builder.append(name).append(",");
						}
					}
				}
				
				
				
				
				
			}
			
			
			
		}else{
			Log.warn("not qualify");
		}
		return builder.toString();
	}
	
	
	private Map<String, Department> getDiagnosisType() {

		if (commonJedis.exists(Consts.All_Department_List)) {
			return (Map<String, Department>) commonJedis.getObject(Consts.All_Department_List);
		} else {
			List<Department> findAll = departmentMapper.findAll();
			Map<String, Department> result = new HashMap<String, Department>();
			for (Department department : findAll) {
				result.put(department.getDepartmentId(), department);
			}
			commonJedis.putObject(Consts.All_Department_List, result,expirationTime);
			return result;
		}

	}

	@Override
	public JsonResponse<List<Department>> getDepartmentListByTime(
			Date beginDate, Date endDate) {
		JsonResponse<List<Department>> result = new JsonResponse<List<Department>>();
		Map map = new HashMap<String, Object>();
		map.put("beginDate", beginDate);
		map.put("endDate", endDate);
		try {
			result.setResult(departmentMapper.getDepartmentListbByTime(map));
		} catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}