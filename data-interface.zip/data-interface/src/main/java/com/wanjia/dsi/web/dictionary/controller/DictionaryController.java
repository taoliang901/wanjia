
package com.wanjia.dsi.web.dictionary.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esotericsoftware.minlog.Log;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.controller.BaseWebController;
import com.wanjia.dsi.common.annotation.Endpoint;
import com.wanjia.dsi.common.annotation.Endpoint.Invoker;
import com.wanjia.dsi.common.annotation.Name;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.dictionary.model.Dictionary;
import com.wanjia.dsi.web.dictionary.service.DictionaryService;

/***
 * 
 * @ClassName: DictionaryController
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author Chenkang
 * @date 2016年3月2日 下午1:38:14
 *
 */
@Controller
public class DictionaryController extends BaseWebController {

	@Autowired
	private DictionaryService dictionaryService;


	/***
	 * 
	 * @Title: updateRedis @Description: TODO(这里用一句话描述这个方法的作用) @param @param
	 *         dictCode @param @return @param @throws Exception 设定文件 @return
	 *         JsonResponse<Boolean> 返回类型 @throws
	 */
	@RequestMapping(value = "/dictionary/updateRedis.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台, Invoker.诊所服务 }, description = "根据字段code，更新redis信息")
	public JsonResponse<Boolean> updateRedis(
			@RequestParam(required = true, value = "dictCode") @Name(value = "dictCode") String dictCode)
					throws Exception {
		return dictionaryService.updateRedis(null,dictCode);

	}

	/***
	 * 
	 * @Title: getDictionaryList @Description:
	 *         TODO(这里用一句话描述这个方法的作用) @param @param
	 *         dictCode @param @return @param @throws Exception 设定文件 @return
	 *         JsonResponse<List<Dictionary>> 返回类型 @throws
	 */
	@RequestMapping(value = "/dictionary/getDictionaryList.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台, Invoker.诊所服务 }, description = "得到字典信息，放缓存")
	public JsonResponse<Map<String, Object>> getDictionaryList(
			@RequestParam(required = true, value = "dictCode") @Name(value = "dictCode") String dictCode)
					throws Exception {
		return dictionaryService.getDictionaryList(null,dictCode);

	}

}
