package com.wanjia.dsi.product.service.impl;

//import com.wanjia.hy.service.HyUserService;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.pinganwj.clinic.api.ProductApptApi;
import com.pinganwj.clinic.api.domain.PageInfo;
import com.pinganwj.clinic.api.domain.appt.product.GetProductServiceRecordReq;
import com.pinganwj.clinic.api.domain.appt.product.GetProductServiceRecordRsp;
import com.pinganwj.clinic.api.domain.appt.product.ProductServiceRecord;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.StringUtils;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.common.utils.DateTools;
import com.wanjia.dsi.product.dao.mapper.CouponMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdFinSettlementDetailMapper;
import com.wanjia.dsi.product.dao.mapper.PrdFinSettlementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdRatioSettlementMapper;
import com.wanjia.dsi.product.model.PrdAgreementClinic;
import com.wanjia.dsi.product.model.PrdAgreementPrdinfo;
import com.wanjia.dsi.product.model.PrdFinSettlement;
import com.wanjia.dsi.product.model.PrdFinSettlementDetail;
import com.wanjia.dsi.product.model.PrdRatioSettlement;
import com.wanjia.dsi.product.model.ProductInfo;
import com.wanjia.dsi.product.model.SettleStatus;
import com.wanjia.dsi.product.service.PrdFinSettlementDetailService;
import com.wanjia.dsi.product.vo.VOPrdFinSettlementDetailForClinic;
import com.wanjia.dsi.product.vo.VOPrdFinSettlementDetailGroupForClinic;
import com.wanjia.dsi.web.clinic.dao.mapper.AddressInfoMapper;
import com.wanjia.dsi.web.clinic.dao.mapper.ClinicHeadquartersMapper;
import com.wanjia.dsi.web.clinic.model.AddressInfo;
import com.wanjia.dsi.web.clinic.model.ClinicHeadquarters;
import com.wanjia.dsi.web.dictionary.dao.mapper.DictionaryMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyUserMapper;
import com.wanjia.dsi.web.hyPerson.model.HyUser;
import com.wanjia.dsi.web.sms.dao.mapper.SmsHtUserMapper;
import com.wanjia.dsi.web.sms.model.HtUser;

/**
 * This element is automatically generated on 16-11-10 下午1:40, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdFinSettlementDetailServiceImpl implements PrdFinSettlementDetailService {
	
	private Logger logger = LoggerFactory.getLogger(PrdFinSettlementDetailServiceImpl.class);

	
	@Autowired
    private PrdFinSettlementDetailMapper prdFinSettlementDetailMapper;

	@Autowired
	private PrdFinSettlementMapper prdFinSettlementMapper;
	
	@Autowired
	private PrdAgreementPrdinfoMapper prdAgreementPrdinfoMapper;
	
	@Autowired
	private PrdAgreementClinicMapper prdAgreementClinicMapper;
	
	@Autowired
	private ProductApptApi productApptApi;
	
	@Autowired
	private HyUserMapper hyUserMapper;
	
	@Autowired
	private PrdInfoMapper prdInfoMapper;
	
	@Autowired
	private DictionaryMapper dictionaryMapper;
	
	@Autowired
	private AddressInfoMapper addressInfoMapper;
	
	@Autowired
	private ClinicHeadquartersMapper clinicHeadquartersMapper;
	
	@Autowired
	private SmsHtUserMapper smsHtUserMapper;
	
	@Autowired
	private CouponMapper couponMapper;
	
	@Autowired
	private PrdRatioSettlementMapper prdRatioSettlementMapper;
	
    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlementDetail findById(String id) {
        return (PrdFinSettlementDetail)prdFinSettlementDetailMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementDetail> findWithPagination(int offset, int count) {
        return (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementDetail> findAll() {
        return (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementDetail> findByEntity(PrdFinSettlementDetail model) {
        return (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementDetail> findByEntityWithPagination(PrdFinSettlementDetail model, int offset, int count) {
        return (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlementDetail findOneByEntity(PrdFinSettlementDetail model) {
        return (PrdFinSettlementDetail)prdFinSettlementDetailMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementDetail> findByProperty(String propertyName, String propertyValue) {
        return (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlementDetail findOneByProperty(String propertyName, String propertyValue) {
        return (PrdFinSettlementDetail)prdFinSettlementDetailMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementDetail> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementDetail> findByProperties(Map<String, Object> map) {
        return (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(PrdFinSettlementDetail model) {
        return (long)prdFinSettlementDetailMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)prdFinSettlementDetailMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)prdFinSettlementDetailMapper.countByProperties(map);
    }

    @Override
    public void update(PrdFinSettlementDetail model) {
     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        prdFinSettlementDetailMapper.update(model);
    }

    @Override
    public void insert(PrdFinSettlementDetail model) {
    //    model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        prdFinSettlementDetailMapper.insert(model);
    }

    @Override
    public void deleteByEntity(PrdFinSettlementDetail model) {
        model.setDelFlag("1");
     //   model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        prdFinSettlementDetailMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.prdFinSettlementDetailMapper.countAll();
    }

    public void insertBatch(List<PrdFinSettlementDetail> list) {
        this.prdFinSettlementDetailMapper.insertBatch(list);
    }

    public void delete(String id) {
        PrdFinSettlementDetail model = new PrdFinSettlementDetail();
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.prdFinSettlementDetailMapper.update(model);
    }
    
    public List<ClinicHeadquarters> searchHeaderListByClinicId(Collection set){
    	

    	List<ClinicHeadquarters> list = clinicHeadquartersMapper.searchHeaderListByClinicId(set);
//    	for(int k=0; k < list.size();k++){
//		ClinicHeadquarters model = list.get(k);
//		System.out.println("----------"+model.getEnterpriseFullName());
//	}
    	return list;

    }
    
    
    /**
     * 1.从深圳接口获取上个月服务列表
     * 2.插入上个月账单明细记录
     * */
    public int createMonthlyBill(){
    	logger.info("-------------Start---CreateMonthlyBill---------------");
		int resultNum = 0;
    	int pageNo = 1;
        
    	GetProductServiceRecordReq param = new GetProductServiceRecordReq();
    	param.setClinicTreatmentConfirmStartTime(DateTools.get1stDayOfPreMonthBySecond());
    	param.setClinicTreatmentConfirmEndTime(DateTools.getEndDayOfPreMonthBySecond());
    	param.setIsNeedCountTreatmentSequence(true);
    	//对应已就诊，已评价，已回复三种状态
    	param.setApptStatus("3,4,5");
    	com.pinganwj.clinic.api.domain.JsonResponse<GetProductServiceRecordRsp> resultJason = productApptApi.getProductServiceRecord(param);
    	if(!resultJason.getStatus().equals(com.pinganwj.clinic.api.domain.JsonResponse.Status.SUCCESS)){
    		logger.info("---接口返回非成功状态!----");
    		return resultNum;
    	}
    	GetProductServiceRecordRsp jsonResponse = resultJason.getResult();
    	PageInfo pageInfo = jsonResponse.getPageInfo();
    	int totalNum = pageInfo.getTotalRecord();

    	boolean flag = true;
    	List<ProductServiceRecord> list = new ArrayList<ProductServiceRecord>();
    	//分页查询
    	while(flag){
    		com.pinganwj.clinic.api.domain.PageInfo page_Info = new com.pinganwj.clinic.api.domain.PageInfo();
        	page_Info.setPageSize(Consts.PAGE_SIZE);
        	page_Info.setCurrentPage(pageNo);
    	 	param.setPageInfo(page_Info);
    	 	com.pinganwj.clinic.api.domain.JsonResponse<GetProductServiceRecordRsp> jason= productApptApi.getProductServiceRecord(param);
    	 	if(jason.getStatus().equals(com.pinganwj.clinic.api.domain.JsonResponse.Status.SUCCESS)){
    	 		List<ProductServiceRecord> iteratorList = jason.getResult().getProductServiceRecords();
        	 	list.addAll(iteratorList);
    	 	}
    		if(Consts.PAGE_SIZE * pageNo >= totalNum ){
    			flag = false;
    		}
    		pageNo++;
    	}
    
    	if(list !=null){
    		logger.info( "服务记录返回接口调用完毕----"+list.size());
    		Collection clinicSet = new HashSet();
    		Collection cUserSet = new HashSet();
    		Collection agentUserSet = new HashSet();
    		Collection prdIdSet = new HashSet();
    		for(ProductServiceRecord prdRecord:list){
    			logger.info("-----------order code----" + prdRecord.getApptOrderCode());
    			clinicSet.add(prdRecord.getClinicId());
    			if(prdRecord.getUserId()!=null){
    				cUserSet.add(prdRecord.getUserId());
    			}
    			if(prdRecord.getAgentUserId()!=null){
    				agentUserSet.add(prdRecord.getAgentUserId());
    			}
    			prdIdSet.add(prdRecord.getHealthProductId());
    		}
    		List<ClinicHeadquarters> quarterList = new ArrayList<ClinicHeadquarters>();
    		if(clinicSet.size() > 0){
    			quarterList = clinicHeadquartersMapper.searchHeaderListByClinicId(clinicSet);
    		}	
    		List<HyUser> cUserAccountList = new ArrayList<HyUser>();
    		if(cUserSet.size() > 0 ){
    			cUserAccountList = hyUserMapper.getBookingAccountListByUserId(cUserSet);
    		}
    		List<HtUser> htUserList = new ArrayList<HtUser>();
    		if(agentUserSet.size() > 0){
    			htUserList = smsHtUserMapper.searchHtUserListByid(agentUserSet);
    		}
    		List<ProductInfo> prdList = couponMapper.getProductListByPrdIds(prdIdSet);
    		
    		
        	List<PrdFinSettlementDetail> detailList = new ArrayList<PrdFinSettlementDetail>();
        	for(int i = 0;i<list.size();i++){
        		ProductServiceRecord record = list.get(i);
        		PrdFinSettlementDetail prdFinSettlementDetail = new PrdFinSettlementDetail();
        		prdFinSettlementDetail.setId(UUID.randomUUID().toString());
        		prdFinSettlementDetail.setClinicId(record.getClinicId());
        		String prdId = record.getHealthProductId();
        		
        		//根据诊所ID ,产品ID找合同
        		Map<String,Object> paramMap = new HashMap<String,Object>();
        		paramMap.put("clinicId", record.getClinicId());
        		paramMap.put("prdId", prdId);
        		String first_scheduleDate = getScheduleDate(prdId,record.getPatientVisit().getId(),record.getTreatmentSequence());
        		if(StringUtils.isNotEmpty(first_scheduleDate)){
        			paramMap.put("scheduleDate", first_scheduleDate);// 根据这张卡的第一次就诊时间查询合同，和服务价格
        		}else{
        			first_scheduleDate = record.getScheduleDate();
        			paramMap.put("scheduleDate", first_scheduleDate);//当前就诊时间
        		}
        		PrdAgreementPrdinfo prdModel = new PrdAgreementPrdinfo();
        		try{
        			prdModel = prdAgreementPrdinfoMapper.searchPrdPriceByParams(paramMap);
        		}catch(Exception e){
        			e.printStackTrace();
        			logger.info("-------i-----"+i);
        			logger.info("-------就诊日期-----"+first_scheduleDate);
        			logger.info("-------诊所日期-----"+record.getClinicId());
        			logger.info("-------产品ID-----"+prdId);
        			continue;
        		}
        		

        		if(prdModel != null && checkIsSingleClinic(prdModel.getAgreementId())){
        			//合同乙方为单体诊所，则不需要赋值registerId
        		}else{
        			for(ClinicHeadquarters clinicHeadquarters : quarterList){
            			if(clinicHeadquarters.getClinicId().equals(record.getClinicId())){
            				//连锁诊所
            				prdFinSettlementDetail.setClinicRegisterId(clinicHeadquarters.getClinicRegisterId());
            				break;
            			}
            		}
        		}
        		String policyNo = record.getPatientVisit().getVisitInsuranceOrderNumber();		
        		prdFinSettlementDetail.setPrdId(prdId);
        		prdFinSettlementDetail.setPrdName(record.getHealthProductName());
        		prdFinSettlementDetail.setCardId(record.getCardId());
        		prdFinSettlementDetail.setInsuranceCompany(record.getPatientVisit().getVisitInsuranceCompany());
        		prdFinSettlementDetail.setPolicyNo(policyNo);

        		for(ProductInfo productInfoModel: prdList){
        			if(productInfoModel.getId().equals(prdId)){
        				//找到对应产品记录
        				if(productInfoModel.getPrdChannel().contains("万家医疗")){
        					prdFinSettlementDetail.setInvoiceTitle("01");
        				}else{
        					//口腔保健产品 保单号可能为空
        					if(policyNo !=null && policyNo.length() >=5 ){
        						String prefix_policy = policyNo.substring(0, 5);  
            					prdFinSettlementDetail.setInvoiceTitle(prefix_policy);
        					}	
        				}	
        				break;
        			}
        		}
        		//C 端预约账户
        		if(record.getApptOptUserType()!=null && record.getApptOptUserType() ==0){
        			if(cUserAccountList != null){
        				for(HyUser hyUser : cUserAccountList){
            				if(String.valueOf(hyUser.getId()).equals(record.getUserId())){
//            					String userAccount = hyUserMapper.getLoginNameByUserId(record.getUserId());             		
            					prdFinSettlementDetail.setBookingAccount(hyUser.getLoginName());
            					break;
            				}
            			}
        			}	
        		}else if(record.getApptOptUserType()!=null && record.getApptOptUserType()==2){
        			//A 端预约账户
        			if(htUserList!=null){
        				for(HtUser htUser : htUserList){
        					if(htUser.getUserCode().equals(record.getAgentUserId())){
        						//	prdFinSettlementDetail.setBookingAccount(record.getAgentUserId());
        						prdFinSettlementDetail.setBookingAccount(htUser.getName());
        						break;
        					}
        				}
        			}	
        		}
        		prdFinSettlementDetail.setPatient(record.getPatientVisit().getName());
        		prdFinSettlementDetail.setOrderCode(record.getApptOrderCode());
        		prdFinSettlementDetail.setScheduleDate(record.getScheduleDate());
        		prdFinSettlementDetail.setConfirmScheduleDate(record.getClinicTreatmentConfirmTime());
        		prdFinSettlementDetail.setPrdItem(record.getHealthProductItemName());
        		prdFinSettlementDetail.setTreatmentSequence(record.getTreatmentSequence());
        		if(prdModel != null){//按合同
        			//按比例结算
        			if(prdModel.getSettleType().equals("02")){ //按比例结算
        				if(StringUtils.isNotEmpty(record.getTreatmentSequence())){
        					if(checkIsLastTime(record.getTreatmentSequence(),prdId,prdModel.getSubAgreementId())){
        						BigDecimal price = getLastTimePrice(true,prdModel.getPrice(),prdId,prdModel.getSubAgreementId());
        						prdFinSettlementDetail.setExpense(String.valueOf(price));
                        		prdFinSettlementDetail.setActualExpense(String.valueOf(price));
        					}else{
        						PrdRatioSettlement prdRatioSettlement = getRatePrice(prdId,prdModel.getSubAgreementId(),record.getTreatmentSequence());
            					BigDecimal price = new BigDecimal(prdRatioSettlement.getRatio()).divide(new BigDecimal(100)).multiply(new BigDecimal(prdModel.getPrice()));
            					prdFinSettlementDetail.setExpense(String.valueOf(price.setScale(2,BigDecimal.ROUND_HALF_UP)));
                        		prdFinSettlementDetail.setActualExpense(String.valueOf(price.setScale(2,BigDecimal.ROUND_HALF_UP)));
        					}
        				}	
        					
    				}else{ //其它结算方式
            			prdFinSettlementDetail.setExpense(prdModel.getPrice());
                		prdFinSettlementDetail.setActualExpense(prdModel.getPrice());
        			}
        			prdFinSettlementDetail.setAdditExpense("0");
           // 		prdFinSettlementDetail.setPlatformFee(prdModel.getServicePrice());
            		prdFinSettlementDetail.setInitSettleDate(DateTools.getCurrMonthForBill()+"."+prdModel.getSettleDate());
            		prdFinSettlementDetail.setSettleDate(DateTools.getCurrMonthForBill()+"."+prdModel.getSettleDate());
        		}else{
        			for(ProductInfo productInfo : prdList){ //按产品
        				if(productInfo.getId().equals(prdId)){
        					if(StringUtils.isNotEmpty(productInfo.getSettlementValue()) && StringUtils.isNotEmpty(productInfo.getSettlementDay())){
        						if(productInfo.getSettlementMethod().equals("5")){//按比例结算
        							if(StringUtils.isNotEmpty(record.getTreatmentSequence())){
        								if(checkIsLastTime(record.getTreatmentSequence(),prdId,null)){
        	        						BigDecimal price = getLastTimePrice(false,productInfo.getSettlementValue(),prdId,null);
        	        						prdFinSettlementDetail.setExpense(String.valueOf(price));
        	                        		prdFinSettlementDetail.setActualExpense(String.valueOf(price));
        	        					}else{
        	        						PrdRatioSettlement prdRatioSettlement = getRatePriceFromPrd(prdId,record.getTreatmentSequence());
            								if(prdRatioSettlement != null){
            									BigDecimal price = new BigDecimal(prdRatioSettlement.getRatio()).divide(new BigDecimal(100)).multiply(new BigDecimal(productInfo.getSettlementValue()));
                								prdFinSettlementDetail.setExpense(String.valueOf(price.setScale(2,BigDecimal.ROUND_HALF_UP)));
                        						prdFinSettlementDetail.setActualExpense(String.valueOf(price.setScale(2,BigDecimal.ROUND_HALF_UP)));
            								}else{
            									//产品规则里选了分比例结算，但是所有服务项目配置为不结算，此时返回对象为空
            									prdFinSettlementDetail.setExpense(String.valueOf(BigDecimal.ZERO));
            									prdFinSettlementDetail.setActualExpense(String.valueOf(BigDecimal.ZERO));
            								}
        	        						
        	        					}
        								
        							}
        						}else{ //其它结算方式
        							prdFinSettlementDetail.setExpense(productInfo.getSettlementValue());
            						prdFinSettlementDetail.setActualExpense(productInfo.getSettlementValue());
        						}
        						prdFinSettlementDetail.setAdditExpense("0");		
//                    			if(StringUtils.isNotEmpty(productInfo.getServerPrice())){
//                    				prdFinSettlementDetail.setPlatformFee(productInfo.getServerPrice());
//                    			}else{
//                    				prdFinSettlementDetail.setPlatformFee("0");
//                    			}
                    			prdFinSettlementDetail.setInitSettleDate(DateTools.getCurrMonthForBill()+"."+productInfo.getSettlementDay());
                        		prdFinSettlementDetail.setSettleDate(DateTools.getCurrMonthForBill()+"."+productInfo.getSettlementDay());
                        		break;
        					}	
        				}	
        			}
        			logger.info("clinicId==="+record.getClinicId() + "prdId==="+prdId);
        		}
        		for(ProductInfo productInfo : prdList){ //按产品
    				if(productInfo.getId().equals(prdId)){
    					if(StringUtils.isNotEmpty(productInfo.getServerPrice())){
            				prdFinSettlementDetail.setPlatformFee(productInfo.getServerPrice());
            			}else{
            				prdFinSettlementDetail.setPlatformFee("0");
            			}
    					break;
    				}
    			}
        		prdFinSettlementDetail.setStatus("01"); // 有效
        		prdFinSettlementDetail.setCreateDate(new Date());
        		prdFinSettlementDetail.setCreateUser(Consts.SYSTEM);
        		prdFinSettlementDetail.setModifyDate(new Date());
        		prdFinSettlementDetail.setModifyUser(Consts.SYSTEM);
        		prdFinSettlementDetail.setDelFlag("0");
        		prdFinSettlementDetail.setTempFlag("0");
        		detailList.add(prdFinSettlementDetail);
        	}
        	if(detailList.size() > 0){
        		prdFinSettlementDetailMapper.insertBatch(detailList);
                
        		createMonthlySettlement();
        		resultNum = detailList.size();
        	}
        	
    	}// list !=null
    	return resultNum;
    }
    
    /**
     * 生成月度账单
     * */
    public void createMonthlySettlement(){
    	Map<String,Object> settleMap = new HashMap<String,Object>();
    	settleMap.put("beginDate", DateTools.getFirstDayOfCurrMonth());
    	settleMap.put("endDate",DateTools.getLastDayOfCurrMonth());
    	List<PrdFinSettlementDetail> resultList = prdFinSettlementDetailMapper.searchMonthlySettlement(settleMap);
    	
    	if(resultList != null ){
    		int size = resultList.size();
    		
    		PrdFinSettlement settlement;
        	int serviceNum = 0;
        	String settlement_pk = UUID.randomUUID().toString();
        	BigDecimal expense = BigDecimal.ZERO;
        	BigDecimal platformFee = BigDecimal.ZERO;
        	if(size == 1){
        		PrdFinSettlementDetail model = resultList.get(0);
    			settlement = new PrdFinSettlement();
				settlement.setId(settlement_pk);
				if(StringUtils.isNotEmpty(model.getClinicRegisterId())){
					//连锁诊所   clinic 字段为空
					settlement.setClinicId(null);
					settlement.setClinicType(Consts.CLINIC_HEADER);
				}else{
					//单体诊所
					settlement.setClinicId(model.getClinicId()); 
					settlement.setClinicCity(getCityCodeByClinicId(model.getClinicId()));
					settlement.setClinicType(Consts.SINGLE_CLINIC);
				}
				settlement.setServiceNum("1");
				settlement.setTotalExpense(model.getExpense());
				settlement.setPlatformFee(model.getPlatformFee());
				settlement.setSettleDate(model.getSettleDate());
				//创建账单
				createSettlement(settlement); 
				
				model.setSettleId(settlement_pk);
        		model.setModifyDate(new Date());
        		model.setModifyUser(Consts.SYSTEM);
        		prdFinSettlementDetailMapper.update(model);
        		
    		}else if (size > 1){
    			for(int k=0; k < size; k++){
            		PrdFinSettlementDetail model = resultList.get(k);
            		if(model.getExpense() != null){
            			expense = expense.add(new BigDecimal(model.getExpense()));
            		}
            		if(model.getPlatformFee() !=null){
            			platformFee = platformFee.add(new BigDecimal(model.getPlatformFee()));
            		}
            		
            		serviceNum ++;		
             		if(k > 0){
            			PrdFinSettlementDetail pre_model = resultList.get(k-1);	
            			if(!isSameSettlement(model,pre_model) || !CommonTools.compareContent(model.getSettleDate(),pre_model.getSettleDate())
            		     || k == size-1) {		
            				settlement = new PrdFinSettlement();
            				
            				settlement.setId(settlement_pk);
            				if(StringUtils.isNotEmpty(pre_model.getClinicRegisterId())){
            					//连锁诊所   clinic 字段为空
            					settlement.setClinicId(null);
            					settlement.setClinicType(Consts.CLINIC_HEADER);
            					settlement.setClinicRegisterId(pre_model.getClinicRegisterId());
            				}else{
            					//单体诊所
            					settlement.setClinicId(pre_model.getClinicId()); 
            					settlement.setClinicCity(getCityCodeByClinicId(pre_model.getClinicId()));
            					settlement.setClinicType(Consts.SINGLE_CLINIC);
            				}
            				if(k < size-1){
            					settlement.setServiceNum(String.valueOf(serviceNum-1));
            					BigDecimal tmp_expense = BigDecimal.ZERO;
            					if(model.getExpense() == null){
            						
            					}else{
            						tmp_expense = new BigDecimal(model.getExpense());
            					}
            					
                				settlement.setTotalExpense(String.valueOf(expense.subtract(tmp_expense)));
                				
                				BigDecimal tmp_platform = BigDecimal.ZERO;
                				if(model.getPlatformFee() == null){
                					
                				}else{
                					tmp_platform = new BigDecimal(model.getPlatformFee());
                				}
                				settlement.setPlatformFee(String.valueOf(platformFee.subtract(tmp_platform)));
                				
                				settlement.setSettleDate(pre_model.getSettleDate());
                				createSettlement(settlement);  //save
                				
            				}else if (isSameSettlement(model,pre_model) && CommonTools.compareContent(model.getSettleDate(),pre_model.getSettleDate())
            						&& k == size-1){
            					settlement.setServiceNum(String.valueOf(serviceNum));
                				settlement.setTotalExpense(String.valueOf(expense));
                				settlement.setPlatformFee(String.valueOf(platformFee));
                				
                				settlement.setSettleDate(pre_model.getSettleDate());
                				createSettlement(settlement);  //save
            				}else if ((!isSameSettlement(model,pre_model) || !CommonTools.compareContent(model.getSettleDate(),pre_model.getSettleDate())) && k == size-1){
            					settlement.setServiceNum(String.valueOf(serviceNum-1));
            					BigDecimal pre_expense = expense.subtract(new BigDecimal(model.getExpense()));
                				settlement.setTotalExpense(String.valueOf(pre_expense));
                				
                				BigDecimal pre_platformFee = platformFee.subtract(new BigDecimal(model.getPlatformFee()));
                				settlement.setPlatformFee(String.valueOf(pre_platformFee));
                				
                				settlement.setSettleDate(pre_model.getSettleDate());
                				createSettlement(settlement);  //save
                				
                				//add by TL 11-24
                				//再插入最后一条
                				settlement_pk = UUID.randomUUID().toString();
                				PrdFinSettlement last_settlement = new PrdFinSettlement();
                				last_settlement.setId(settlement_pk);
                				if(StringUtils.isNotEmpty(model.getClinicRegisterId())){
                					//连锁诊所   clinic 字段为空
                					last_settlement.setClinicId(null);
                					last_settlement.setClinicType(Consts.CLINIC_HEADER);
                					last_settlement.setClinicRegisterId(model.getClinicRegisterId());
                				}else{
                					//单体诊所
                					last_settlement.setClinicId(model.getClinicId()); 
                					last_settlement.setClinicCity(getCityCodeByClinicId(model.getClinicId()));
                					last_settlement.setClinicType(Consts.SINGLE_CLINIC);
                				}
                				//
            					last_settlement.setServiceNum("1");
            					last_settlement.setTotalExpense(model.getExpense());
                				last_settlement.setPlatformFee(String.valueOf(model.getPlatformFee()));
            					last_settlement.setSettleDate(model.getSettleDate());
                				createSettlement(last_settlement);  //save
            				}		
            				
            				if(k < size-1){
                				settlement_pk = UUID.randomUUID().toString();
            				}
            				expense = model.getExpense() == null ? BigDecimal.ZERO : new BigDecimal(model.getExpense());
            				platformFee = model.getPlatformFee()==null? BigDecimal.ZERO : new BigDecimal(model.getPlatformFee());
            				serviceNum = 1;
            			}
            		}
            		model.setSettleId(settlement_pk);
            		model.setModifyDate(new Date());
            		model.setModifyUser(Consts.SYSTEM);
            		prdFinSettlementDetailMapper.update(model);
    			}	
        	
        	}
    	}
    
    }

    /**
     *优化的方法 还未经测试
     * */
//    public boolean createMonthlySettlementBackUP(){
//    	Map<String,Object> settleMap = new HashMap<String,Object>();
//    	settleMap.put("beginDate", DateTools.getFirstDayOfPreMonth());
//    	settleMap.put("endDate",DateTools.getLastDayOfPreMonth());
//    	List<PrdFinSettlementDetail> resultList = prdFinSettlementDetailMapper.searchMonthlySettlement(settleMap);
//    	
//    	if(resultList == null ){
//    		return false;	
//    	}else{
//    		int size = resultList.size();
//    		PrdFinSettlement settlement;
//        	int serviceNum = 0;
//        	String settlement_pk = UUID.randomUUID().toString();
//        	BigDecimal expense = BigDecimal.ZERO;
//        	BigDecimal platformFee = BigDecimal.ZERO;
//        	
//			for(int k=0; k < size; k++){
//        		PrdFinSettlementDetail model = resultList.get(k);
//        		
//        		if(model.getExpense() != null){
//        			expense = expense.add(new BigDecimal(model.getExpense()));
//        		}
//        		if(model.getPlatformFee() !=null){
//        			platformFee = platformFee.add(new BigDecimal(model.getPlatformFee()));
//        		}
//        		serviceNum ++;	
//        		PrdFinSettlementDetail next_detail = resultList.get(k+1);	
//        		
//    			if(!isSameSettlement(model,next_detail) || !CommonTools.compareContent(model.getSettleDate(),next_detail.getSettleDate()) ) {		
//    				settlement = new PrdFinSettlement();
//    				settlement.setId(settlement_pk);
//    				if(StringUtils.isNotEmpty(model.getClinicRegisterId())){
//    					//连锁诊所   clinic 字段为空
//    					settlement.setClinicId(null);
//    					settlement.setClinicType(Consts.CLINIC_HEADER);
//    					settlement.setClinicRegisterId(model.getClinicRegisterId());
//    				}else{
//    					//单体诊所
//    					settlement.setClinicId(model.getClinicId()); 
//    					settlement.setClinicCity(getCityCodeByClinicId(model.getClinicId()));
//    					settlement.setClinicType(Consts.SINGLE_CLINIC);
//    				}
//    				settlement.setServiceNum(String.valueOf(serviceNum));
//    				settlement.setTotalExpense(String.valueOf(expense));
//    				settlement.setPlatformFee(String.valueOf(platformFee));
//    				
//    				settlement.setSettleDate(model.getSettleDate());
//    				createSettlement(settlement);  //save
//    				
//    				if(k < size-1){
//        				settlement_pk = UUID.randomUUID().toString();
//    				}
//    				expense = BigDecimal.ZERO;
//    				platformFee = BigDecimal.ZERO;
//    				serviceNum = 0;
//    			}
//        		
//        		model.setSettleId(settlement_pk);
//        		model.setModifyDate(new Date());
//        		model.setModifyUser(Consts.SYSTEM);
//        		prdFinSettlementDetailMapper.update(model);
//			}	
//        	
//    		return true;
//    	}
//    	
//    }
    
	private void createSettlement(PrdFinSettlement settlement){
		settlement.setSettleMonth(DateTools.getPreMonthForBill());
		settlement.setStatus(SettleStatus.NoAccount.getValue());
		settlement.setCreateDate(new Date());
		settlement.setModifyDate(new Date());
		settlement.setCreateUser(Consts.SYSTEM);
		settlement.setModifyUser(Consts.SYSTEM);
		settlement.setDelFlag("0");	
		prdFinSettlementMapper.insert(settlement); 
	}
    
	
	private Boolean isSameSettlement(PrdFinSettlementDetail model , PrdFinSettlementDetail pre_model){
		//flag == true 代表是一个诊所
		Boolean flag = false;
		//是同一个单体诊所
		if(StringUtils.isEmpty(model.getClinicRegisterId()) && StringUtils.isEmpty(pre_model.getClinicRegisterId()) ){
			if(model.getClinicId().equals(pre_model.getClinicId())){
				flag = true;
			}
		}
		//是同一个连锁诊所
		if(model.getClinicRegisterId()!=null && pre_model.getClinicRegisterId()!=null
				&&model.getClinicRegisterId().equals(pre_model.getClinicRegisterId())
				){
			flag = true;
		}

		return flag;
	}
   
	private String getCityCodeByClinicId(String clinicId){
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("foreignId", clinicId);
		param.put("foreignType", "01");
		AddressInfo addressInfo = addressInfoMapper.selectByClinicId(param);
		if(addressInfo != null){
			return addressInfo.getCityCode();
		}
		return "";
	} 
    
	@Override
	public JsonResponse<List<VOPrdFinSettlementDetailGroupForClinic>> getPrdFinSettlementDetailGroup(Map<String, Object> map) {
		JsonResponse<List<VOPrdFinSettlementDetailGroupForClinic>> response = new JsonResponse<List<VOPrdFinSettlementDetailGroupForClinic>>();
		try{
			List<VOPrdFinSettlementDetailGroupForClinic> settlementDetailGroupList = prdFinSettlementDetailMapper.searchMonthlySettlementDetailGroup(map);
			List<VOPrdFinSettlementDetailForClinic> settlementDetailForClinicList = null;
			if(CollectionUtils.isNotEmpty(settlementDetailGroupList)){
				for(VOPrdFinSettlementDetailGroupForClinic group : settlementDetailGroupList){
					map.put("prdChannel", group.getPrdChannel());
					if(StringUtils.isNotBlank(group.getPolicyNoPrefix())){
						map.put("policyNoPrefix", group.getPolicyNoPrefix());
					}else if(map.containsKey("policyNoPrefix")){
						map.remove("policyNoPrefix");
					}
					
					settlementDetailForClinicList = prdFinSettlementDetailMapper.searchMonthlySettlementDetailForGroup(map);
					if(CollectionUtils.isNotEmpty(settlementDetailForClinicList)){
						group.setPrdFinSettlementDetailForClinicList(settlementDetailForClinicList);
						group.setSubClinicRejectDesc(settlementDetailForClinicList.get(0).getRejectDesc());
					}
				}
				response.setResult(settlementDetailGroupList);
			}
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	} 
	
	@Override
	public JsonResponse<List<VOPrdFinSettlementDetailGroupForClinic>> getPrdFinSettlementDetailChainGroup(Map<String, Object> map) {
		JsonResponse<List<VOPrdFinSettlementDetailGroupForClinic>> response = new JsonResponse<List<VOPrdFinSettlementDetailGroupForClinic>>();
		try{
			List<VOPrdFinSettlementDetailGroupForClinic> settlementDetailGroupList = prdFinSettlementDetailMapper.searchMonthlySettlementDetailChainGroup(map);
			List<VOPrdFinSettlementDetailForClinic> settlementDetailForClinicList = null;
			if(CollectionUtils.isNotEmpty(settlementDetailGroupList)){
				for(VOPrdFinSettlementDetailGroupForClinic group : settlementDetailGroupList){
					map.put("prdChannel", group.getPrdChannel());
					if(StringUtils.isNotBlank(group.getPolicyNoPrefix())){
						map.put("policyNoPrefix", group.getPolicyNoPrefix());
					}else if(map.containsKey("policyNoPrefix")){
						map.remove("policyNoPrefix");
					}
					
					settlementDetailForClinicList = prdFinSettlementDetailMapper.searchMonthlySettlementDetailForChainGroup(map);
					if(CollectionUtils.isNotEmpty(settlementDetailForClinicList)){
						group.setPrdFinSettlementDetailForClinicList(settlementDetailForClinicList);
						group.setSubClinicRejectDesc(settlementDetailForClinicList.get(0).getRejectDesc());
					}
				}
				response.setResult(settlementDetailGroupList);
			}
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	} 
	
	
	/**
	 * 根据框架合同号判断乙方是连锁诊所还是单体诊所
	 * 
	 * 
	 * */
	
	public boolean checkIsSingleClinic(String agreementId){
		boolean flag = false;
		if(agreementId == null){
			return false;
		}
		PrdAgreementClinic agreement_Clinic = new PrdAgreementClinic();
		agreement_Clinic.setAgreementId(agreementId);
    	agreement_Clinic = prdAgreementClinicMapper.searchFrameAgreementClinicType(agreement_Clinic);
		if(agreement_Clinic != null && agreement_Clinic.getClinicType().equals("2")){
			flag = true;
		}
		return flag;
	}
	
	/**
	 * 根据服务sequence,从产品规则查询按比例结算价格
	 * */
	
	public PrdRatioSettlement getRatePriceFromPrd(String prdId,String sequence){
		PrdRatioSettlement prdRatioModel = new PrdRatioSettlement();
		prdRatioModel.setProductId(prdId);
		prdRatioModel.setSourceFlag("0"); //找产品创建设置的比例
		int sequence_temp = Integer.valueOf(sequence)-1;
		prdRatioModel.setSequence(String.valueOf(sequence_temp));
		prdRatioModel.setDelFlag("0");
		prdRatioModel = prdRatioSettlementMapper.findOneByEntity(prdRatioModel);
		return prdRatioModel;
	}
	
	/**
	 * 按次数比例结算时 ,根据服务sequence查询价格
	 * */
	
	public PrdRatioSettlement getRatePrice(String prdId,String subAgreementId,String sequence){
		PrdRatioSettlement prdRatioModel = new PrdRatioSettlement();
		prdRatioModel.setProductId(prdId);
		prdRatioModel.setSourceFlag("1"); //优先找合同设置的比例
		prdRatioModel.setSubAgreementId(subAgreementId); 
		int sequence_temp = Integer.valueOf(sequence)-1;
		prdRatioModel.setSequence(String.valueOf(sequence_temp));
		prdRatioModel.setDelFlag("0");
		PrdRatioSettlement model = prdRatioSettlementMapper.findOneByEntity(prdRatioModel);
		
		if(model == null){
			prdRatioModel.setSubAgreementId(null); //清空合同号
			prdRatioModel.setSourceFlag("0"); //找产品创建设置的比例
			model = prdRatioSettlementMapper.findOneByEntity(prdRatioModel);
		}
		return model;
 	}
	
	
	/**
	 * 是否是最后次消费记录
	 * 
	 * currSeq : 当前是第几次就诊
	 * prdId : 产品ID
	 * subAgreementId : 附属合同ID
	 * */
	public boolean checkIsLastTime(String currSeq,String prdId,String subAgreementId){
		boolean flag = false;
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("prdId", prdId);
		if(StringUtils.isNotEmpty(subAgreementId)){
			map.put("subAgreementId", subAgreementId);
			map.put("sourceFlag", "1");
		}else{
			map.put("sourceFlag", "0");
		}
		String num = prdRatioSettlementMapper.getMaxNumOfPrd(map);
		if(StringUtils.isEmpty(num)){
			return false;
		}
		//DB里seq从0开始计数
		int num_temp= Integer.valueOf(num)+1;
		if(currSeq.equals(num_temp)){
			return true;
		}
		return flag;
	}
	
	/**
	 * 按比例结算计算最后一次消费价格
	 * 
	 * isAgreementRule ： true 查找合同中价格 false查找产品配置中价格
	 * prd_price : 产品总价
	 * prdId : 产品ID
	 * subAgreementId : 附属合同ID
	 * */
	public BigDecimal getLastTimePrice(boolean isAgreementRule,String prd_price,String prdId,String subAgreementId){
		BigDecimal b_prd_price = new BigDecimal(prd_price);
		BigDecimal b_last_price = BigDecimal.ZERO;
		BigDecimal b_temp_price = BigDecimal.ZERO;
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("prdId", prdId);
		if(isAgreementRule){
			map.put("sourceFlag", "1");
			map.put("subAgreementId", subAgreementId);
		}else{
			map.put("sourceFlag", "0");
		}
		map.put("delFlag", "0");
		List<PrdRatioSettlement> list = prdRatioSettlementMapper.searchPriceRatioByParams(map);
		if(list != null){
			for(int i=0; i<list.size()-1 ; i++){ // 剔除最后一次价格
				PrdRatioSettlement model = list.get(i);
				BigDecimal price = new BigDecimal(model.getRatio()).divide(new BigDecimal(100)).multiply(b_prd_price).setScale(2,BigDecimal.ROUND_HALF_UP);
				b_temp_price = b_temp_price.add(price);
			}
		}
		//总价 - 除最后一次所有次数价格累计数 =最后次服务价格。避免直接乘法四舍五入后的计算误差。
		b_last_price = b_prd_price.subtract(b_temp_price);
		return b_last_price;
	}
	
	
	@Override
	public JsonResponse<PrdFinSettlementDetail> getSettlementDetailLastPrice(Map<String, Object> map) {
		JsonResponse<PrdFinSettlementDetail> response = new JsonResponse<PrdFinSettlementDetail>();
		try{
			PrdFinSettlementDetail detail = prdFinSettlementDetailMapper.getTotalPriceByPrdid(map);
			BigDecimal actualExpense = new BigDecimal(detail.getActualExpense());
			BigDecimal prdPrice = new BigDecimal(map.get("prdPrice")+"");
			actualExpense = prdPrice.subtract(actualExpense);
			detail.setActualExpense(actualExpense+"");
			response.setStatus(JsonResponse.Status.SUCCESS);
			response.setResult(detail);
		}catch(Exception e){
			response.setStatus(JsonResponse.Status.ERROR);
			logger.error("根据产品id统计实际费用总和异常",e);
		}
		return response;
	}

	@Override
	public String getScheduleDate(String prdId, String patientVisitId, String serviceNum) {
		if(StringUtils.isEmpty(serviceNum)){
			return null;
		}
		GetProductServiceRecordReq param = new GetProductServiceRecordReq();
		param.setHealthProductId(prdId);
		param.setVisitId(patientVisitId);
		param.setIsNeedCountTreatmentSequence(true);
		int pageNo = 1;
        int pageSize= 10000;
	 	PageHelper.startPage(pageNo,pageSize);
	 	com.pinganwj.clinic.api.domain.PageInfo pageInfo = new com.pinganwj.clinic.api.domain.PageInfo();
	 	pageInfo.setPageSize(pageSize);
	 	pageInfo.setCurrentPage(pageNo);
	 	param.setPageInfo(pageInfo);
	 	GetProductServiceRecordRsp jsonResponse = productApptApi.getProductServiceRecord(param).getResult();
	 	List<ProductServiceRecord> list = jsonResponse.getProductServiceRecords();
	 	if(list!=null && !list.isEmpty()){
	 		for(ProductServiceRecord psr : list){
	 			if(serviceNum.equals(psr.getTreatmentSequence())){
	 				return psr.getScheduleDate();
	 			}
	 		}
	 	}
	 	
	 	return null;
	}


}