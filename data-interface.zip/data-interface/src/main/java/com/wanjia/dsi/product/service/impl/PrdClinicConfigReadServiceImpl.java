package com.wanjia.dsi.product.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.product.dao.mapper.PrdClinicConfigMapper;
import com.wanjia.dsi.product.model.PrdClinicConfig;
import com.wanjia.dsi.product.service.PrdClinicConfigReadService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdClinicConfigReadServiceImpl  implements PrdClinicConfigReadService {

	protected Logger logger = Logger.getLogger(PrdClinicConfigReadServiceImpl.class);
	
	@Autowired 
	private PrdClinicConfigMapper prdClinicConfigMapper;

	@Override
	public JsonResponse<PrdClinicConfig> findById(String id) {
		JsonResponse<PrdClinicConfig> jr = new JsonResponse<PrdClinicConfig>();
		try{
			PrdClinicConfig pcc = prdClinicConfigMapper.selectByPrimaryKey(id);
			jr.setResult(pcc);
			jr.setStatus(Status.SUCCESS);
		}catch(Exception e){
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}

	@Override
	public JsonResponse<List<PrdClinicConfig>> findByProperties(Map<String,Object> map) {
		JsonResponse<List<PrdClinicConfig>> jr = new JsonResponse<List<PrdClinicConfig>>();
		try{
			List<PrdClinicConfig> pccs = prdClinicConfigMapper.findByProperties(map);
			jr.setResult(pccs);
			jr.setStatus(Status.SUCCESS);
		}catch(Exception e){
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}

	
}
