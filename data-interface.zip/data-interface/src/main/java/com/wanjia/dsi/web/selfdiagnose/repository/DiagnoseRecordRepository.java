package com.wanjia.dsi.web.selfdiagnose.repository;

import org.springframework.stereotype.Repository;
import com.wanjia.dsi.base.mongodb.impl.MongoDbRepositoryImpl;
import com.wanjia.dsi.web.selfdiagnose.model.DiagnoseRecordBO;

@Repository
public class DiagnoseRecordRepository extends MongoDbRepositoryImpl<DiagnoseRecordBO> {

}
