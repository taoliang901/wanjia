package com.wanjia.dsi.common.utils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.wanjia.common.json.JsonResponse;

public class RestTemplateUtil {

	// 日志类
	private static final Logger logger = Logger.getLogger(RestTemplateUtil.class);
	//@Autowired
	private static RestTemplate restTemplate = new RestTemplate() ;

	
	public static final String url = "http://api.map.baidu.com/geocoder?output=json&key=E4805d16520de693a3fe707cdc962045http://api.map.baidu.com/geocoder?address=上海市浦东新区港澳路481号&output=json&key=E4805d16520de693a3fe707cdc962045&address=";
	
	
	
	
	@SuppressWarnings({ "finally", "rawtypes" })
	public static JsonResponse<?> getList(String url) {
		JsonResponse jr = new JsonResponse();
		try {
			logger.info(url);
			jr = restTemplate.getForObject(url, JsonResponse.class);
		} catch (RestClientException e) {
			jr.setErrorCode("1002");
			logger.error(e.getMessage());
		} finally {
			return jr;
		}
	}

	@SuppressWarnings({ "finally", "unchecked" })
	public static Map<String, Object> getMap(String url) {
		Map<String, Object> jr = new HashMap<String, Object>();
		try {
			logger.info(url);
			jr = restTemplate.getForObject(url, HashMap.class);
		} catch (RestClientException e) {
			logger.error(e.getMessage());
		} finally {
			return jr;
		}
	}

	@SuppressWarnings("finally")
	public static String getByHttpURLConnection(String urlStr) {
		String returnString = "";
		URL url = null;
		HttpURLConnection connection = null;
		try {
			url = new URL(urlStr);
			connection = (HttpURLConnection) url.openConnection();// 新建连接实例
			connection.setConnectTimeout(20000);// 设置连接超时时间，单位毫秒
			connection.setReadTimeout(20000);// 设置读取数据超时时间，单位毫秒
			connection.setDoOutput(true);// 是否打开输出流 true|false
			connection.setDoInput(true);// 是否打开输入流true|false
			connection.setRequestMethod("GET");// 提交方法POST|GET
			connection.setUseCaches(false);// 是否缓存true|false
			connection.connect();// 打开连接端口
			DataOutputStream out = new DataOutputStream(connection.getOutputStream());// 打开输出流往对端服务器写数据
			out.flush();// 刷新
			out.close();// 关闭输出流
			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));// 往对端写完数据对端服务器返回数据
			// ,以BufferedReader流来读取
			StringBuffer buffer = new StringBuffer();
			String line = "";
			while ((line = reader.readLine()) != null) {
				buffer.append(line);
			}
			reader.close();
			returnString = buffer.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.disconnect();// 关闭连接
			}
//			logger.info("returnString+" + returnString);
			return returnString;
		}
	}
	
	@SuppressWarnings("finally")
	public static String getXmlByHttpURLConnection(String urlStr) {
		String returnString = "";
		URL url = null;
		HttpURLConnection connection = null;
		try {
			url = new URL(urlStr);
			connection = (HttpURLConnection) url.openConnection();// 新建连接实例
			
			connection.setRequestProperty("Content-type", "text/xml");  
			connection.setConnectTimeout(20000);// 设置连接超时时间，单位毫秒
			connection.setReadTimeout(20000);// 设置读取数据超时时间，单位毫秒
			connection.setDoOutput(true);// 是否打开输出流 true|false
			connection.setDoInput(true);// 是否打开输入流true|false
			connection.setRequestMethod("GET");// 提交方法POST|GET
			connection.setUseCaches(false);// 是否缓存true|false
			connection.connect();// 打开连接端口
			DataOutputStream out = new DataOutputStream(connection.getOutputStream());// 打开输出流往对端服务器写数据
			out.flush();// 刷新
			out.close();// 关闭输出流
			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));// 往对端写完数据对端服务器返回数据
			// ,以BufferedReader流来读取
			StringBuffer buffer = new StringBuffer();
			String line = "";
			while ((line = reader.readLine()) != null) {
				buffer.append(line);
			}
			reader.close();
			returnString = buffer.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.disconnect();// 关闭连接
			}
//			logger.info("returnString+" + returnString);
			return returnString;
		}
	}
	
	@SuppressWarnings("finally")
	public static String postByHttpURLConnection(String urlStr,String param) {
		String returnString = "";
		URL url = null;
		HttpURLConnection connection = null;
		try {
			url = new URL(urlStr);
			connection = (HttpURLConnection) url.openConnection();// 新建连接实例
			connection.setConnectTimeout(20000);// 设置连接超时时间，单位毫秒
			connection.setReadTimeout(20000);// 设置读取数据超时时间，单位毫秒
			connection.setDoOutput(true);// 是否打开输出流 true|false
			connection.setDoInput(true);// 是否打开输入流true|false
			connection.setRequestMethod("POST");// 提交方法POST|GET
			connection.setUseCaches(false);// 是否缓存true|false
			connection.connect();// 打开连接端口
			DataOutputStream out = new DataOutputStream(connection.getOutputStream());// 打开输出流往对端服务器写数据
//			out.writeBytes(param);  
			out.write(param.getBytes());
			out.flush();// 刷新
			out.close();// 关闭输出流
			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));// 往对端写完数据对端服务器返回数据
			// ,以BufferedReader流来读取
			StringBuffer buffer = new StringBuffer();
			String line = "";
			while ((line = reader.readLine()) != null) {
				buffer.append(line);
			}
			reader.close();
			returnString = buffer.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.disconnect();// 关闭连接
			}
//			logger.info("returnString+" + returnString);
			return returnString;
		}
	}

	/**
	 * 简单GET请求
	 * 
	 * @param url
	 *            http请求需包含请求参数eg. XX.do?param=
	 * @param cls
	 *            期望输出对象类型
	 * @return
	 */
	public static <T> T getForObject(String url, Class<T> cls) {
		T obj = null;
		try {
			obj = (T) restTemplate.getForObject(url, cls);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return obj;
	}

	
	@SuppressWarnings("rawtypes")
	public static Map getAdressInfo(String address){
		
		JSONObject forObject = JSONObject.parseObject(getForObject(url+address, String.class));
		Map<String,String> map = new HashMap<String,String>();
		String status = forObject.getString("status");
		try{
			if("OK".equalsIgnoreCase(status)){
				String lng = forObject.getJSONObject("result").getJSONObject("location").getString("lng");
				String lat = forObject.getJSONObject("result").getJSONObject("location").getString("lat");
				map.put("lng", lng);
				map.put("lat", lat);
				
			}
		}catch(Exception e){
			e.printStackTrace();
			
		}
		
		
		
		/*"status":"OK",
	    "result":{
	        "location":{
	            "lng":121.629905,
	            "lat":31.321544
	        },
	        "precise":1,
	        "confidence":80,
	        "level":"\u9053\u8def"
	    }*/
		
		
		
		
		
		
		
		return map;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
		
		//http://api.map.baidu.com/geocoder?address=上海市浦东新区港澳路481号&output=json&key=E4805d16520de693a3fe707cdc962045http://api.map.baidu.com/geocoder?address=上海市浦东新区港澳路481号&output=json&key=E4805d16520de693a3fe707cdc962045
		String address = "上海市青浦新桥路786号";
		//System.out.println(getForObject(url+address,String.class));
		System.out.println(getAdressInfo(address));
		
		
	}
	
	
	
	
	/**
	 * GET请求 返回复杂对象 new ParameterizedTypeReference<T>() {}
	 * 
	 * @param url
	 *            http请求需包含请求参数eg. XX.do?param={0}
	 * @param cls
	 *            期望输出对象类型
	 * @param uriVariables
	 *            具体参数
	 * @return
	 */
	public static <T> T getForObject(String url, ParameterizedTypeReference<T> responseType, Object... uriVariables) {
		T obj = null;
		try {
			ResponseEntity<T> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, responseType, uriVariables);
			obj = responseEntity.getBody();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return obj;
	}

	/**
	 * 简单POST请求
	 * 
	 * @param url
	 *            http请求
	 * @param request
	 *            请求对象
	 * @param responseType
	 *            期望输出对象类型
	 * @return
	 */
	public static <T> T postForObject(String url, Object request, Class<T> responseType) {
		T obj = null;
		try {
			obj = (T) restTemplate.postForObject(url, request, responseType);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return obj;
	}
	
	
	 private static void printLog(String url, Object requestParams, Object resultObject) {
	        if (StringUtils.isNotBlank(url)) {
	            logger.info(MessageFormat.format("{0}{1}", "++++++++++Request: ", url));
	        }
	        try {
	            ObjectMapper om = new ObjectMapper();
	            if (requestParams != null) {
	                logger.info(MessageFormat.format("{0}{1}", "++++++++++Request Parameters: ", om.writeValueAsString(requestParams)));
	            }
	        }
	        catch (JsonProcessingException e) {
	            logger.error(e);
	        }
	    }

	    /**
	     * @param url
	     * @param responseType
	     * @param urlVariables
	     * @return
	     * @throws RestClientException
	     */
	    public static <T> T get(String url, ParameterizedTypeReference<T> responseType, Object... urlVariables) throws RestClientException {
	        try {
	            printLog(MessageFormat.format(url, urlVariables), null, null);
	            ResponseEntity<T> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, responseType, urlVariables);
	            printLog(null, null, responseEntity.getBody());
	            return responseEntity.getBody();
	        }
	        catch (HttpClientErrorException e) {
	            int statusCode = e.getStatusCode().value();
	            if (HttpStatus.NOT_FOUND.value() == statusCode) {
	                logger.error("++++++++++Response: 请求的url或端口号有误，statusCode  " + statusCode);
	            }
	            return null;
	        }
	    }

	    /**
	     * 
	     * @param url
	     * @param responseType
	     * @param headers
	     * @param urlVariables
	     * @return
	     * @throws RestClientException
	     */
	    public static <T> T get(String url, ParameterizedTypeReference<T> responseType, HttpHeaders headers, Object... urlVariables) throws RestClientException {
	        try {
	            printLog(MessageFormat.format(url, urlVariables), null, null);
	            HttpEntity<Object> requestEntity = new HttpEntity<Object>(headers);
	            ResponseEntity<T> responseEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity, responseType, urlVariables);
	            printLog(null, null, responseEntity.getBody());
	            return responseEntity.getBody();
	        }
	        catch (HttpClientErrorException e) {
	            int statusCode = e.getStatusCode().value();
	            if (HttpStatus.NOT_FOUND.value() == statusCode) {
	                logger.error("++++++++++Response: 请求的url或端口号有误，statusCode  " + statusCode);
	            }
	            return null;
	        }
	    }

	    /**
	     * @param url
	     * @param responseType
	     * @param requestObject
	     * @return
	     * @throws RestClientException
	     */
	    public static <T> T post(String url, ParameterizedTypeReference<T> responseType, Object requestObject) throws RestClientException {
	        try {
	            printLog(url, requestObject, null);
	            HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestObject);
	            ResponseEntity<T> responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, responseType);
	            printLog(null, null, responseEntity.getBody());
	            return responseEntity.getBody();
	        }
	        catch (HttpClientErrorException e) {
	            int statusCode = e.getStatusCode().value();
	            if (HttpStatus.NOT_FOUND.value() == statusCode) {
	                logger.error(e);
	            }
	            return null;
	        }
	    }

	    /**
	     * 
	     * @param url
	     * @param responseType
	     * @param requestObject
	     * @param headers
	     * @return
	     * @throws RestClientException
	     */
	    public <T> T post(String url, ParameterizedTypeReference<T> responseType, Object requestObject, HttpHeaders headers) throws RestClientException {
	        try {
	            printLog(url, requestObject, null);
	            HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestObject, headers);
	            ResponseEntity<T> responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, responseType);
	            printLog(null, null, responseEntity.getBody());
	            return responseEntity.getBody();
	        }
	        catch (HttpClientErrorException e) {
	            int statusCode = e.getStatusCode().value();
	            if (HttpStatus.NOT_FOUND.value() == statusCode) {
	                logger.error("++++++++++Response: 请求的url或端口号有误，statusCode  " + statusCode);
	            }
	            return null;
	        }
	    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
