package com.wanjia.dsi.web.activity.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VOLocalMedicineMapper;
import com.wanjia.dsi.web.cms.activity.model.LocalMedicine;
import com.wanjia.dsi.web.cms.activity.model.VOLocalMedicine;
import com.wanjia.dsi.web.cms.activity.service.LocalMedicineService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class LocalMedicineServiceImpl implements LocalMedicineService {
	@Autowired
	private VOLocalMedicineMapper voLocalMedicineMapper;

	@Override
	public JsonResponse<PageInfo<LocalMedicine>> getLocalMedicine(List<String> infoIdList, String pageSize,
			String pageNo) {
		// 设置分页参数
		if (StringUtils.isBlank(pageNo)) {
			pageNo = "1";
		}
		// 设置分页参数
		if (StringUtils.isBlank(pageSize)) {
			pageSize = "10";
		}
		List<LocalMedicine> result = voLocalMedicineMapper.getLocalMedicine(infoIdList);
		JsonResponse<PageInfo<LocalMedicine>> respose = new JsonResponse<PageInfo<LocalMedicine>>();
		// 设置分页页号和页码
		PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));

		PageInfo<LocalMedicine> page = new PageInfo<LocalMedicine>(result);// 获得分页信息
		respose.setResult(page);

		return respose;
	}

	@Override
	public JsonResponse<List<String>> getAllMedicineId(Date beginDate, Date endDate) {
		VOLocalMedicine voLocalMedicine = new VOLocalMedicine();
		voLocalMedicine.setBeginDate(beginDate);
		voLocalMedicine.setEndDate(endDate);
		List<String> result = voLocalMedicineMapper.getAllMedicineId(voLocalMedicine);
		JsonResponse<List<String>> respose = new JsonResponse<List<String>>();
		respose.setResult(result);
		return respose;
	}

}
