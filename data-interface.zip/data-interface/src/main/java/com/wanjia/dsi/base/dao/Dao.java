package com.wanjia.dsi.base.dao;

import java.io.Serializable;
import java.util.List;
import org.springframework.dao.DataAccessException;

/**
 * 
 * 
 * @author jiangyue
 *
 * @param <E>
 * @param <PK>
 */
public interface Dao <E,PK extends Serializable>{

	
	/**
	 * 删除数据
	 * @param statementName
	 * @param entity
	 * @return
	 * @throws DataAccessException
	 */
	public int deleteObject(String statementName,E entity) throws DataAccessException ;
	
	/**
	 * 插入数据
	 * @param statementName
	 * @param entity
	 * @return
	 * @throws DataAccessException
	 */
	public int saveObject(String statementName,E entity) throws DataAccessException;
	
	/**
	 * 更新数据
	 * @param statementName
	 * @param entity
	 * @return
	 * @throws DataAccessException
	 */
	public int updateObject(String statementName,E entity) throws DataAccessException;

	/**
	 * 查询返回一条数据
	 * @param statementName
	 * @param param
	 * @return
	 */
	public E queryForObject(String statementName, Object param);
	
	/**
	 * 查询返回数据集合
	 * @param statementName
	 * @param param
	 * @return
	 */
	public List<E> queryForList(String statementName, Object param);
	
//	/**
//	 * 分页查询
//	 * @param statementName
//	 * @param page
//	 * @param param
//	 * @return
//	 */
//	public QueryResult<E> queryForPage(Page<E> page,Map param);
//	
//	/**
//	 * 分页查询
//	 * 指定statementName
//	 * @param statementName
//	 * @param page
//	 * @param param
//	 * @return
//	 */
//	public QueryResult<E> queryForPage(String statementName, Page<E> page,Map param);
//	
	
}
