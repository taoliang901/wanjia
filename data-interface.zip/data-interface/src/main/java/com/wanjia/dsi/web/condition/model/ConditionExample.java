package com.wanjia.dsi.web.condition.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ConditionExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ConditionExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andConditionIdIsNull() {
            addCriterion("CONDITION_ID is null");
            return (Criteria) this;
        }

        public Criteria andConditionIdIsNotNull() {
            addCriterion("CONDITION_ID is not null");
            return (Criteria) this;
        }

        public Criteria andConditionIdEqualTo(String value) {
            addCriterion("CONDITION_ID =", value, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdNotEqualTo(String value) {
            addCriterion("CONDITION_ID <>", value, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdGreaterThan(String value) {
            addCriterion("CONDITION_ID >", value, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdGreaterThanOrEqualTo(String value) {
            addCriterion("CONDITION_ID >=", value, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdLessThan(String value) {
            addCriterion("CONDITION_ID <", value, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdLessThanOrEqualTo(String value) {
            addCriterion("CONDITION_ID <=", value, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdLike(String value) {
            addCriterion("CONDITION_ID like", value, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdNotLike(String value) {
            addCriterion("CONDITION_ID not like", value, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdIn(List<String> values) {
            addCriterion("CONDITION_ID in", values, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdNotIn(List<String> values) {
            addCriterion("CONDITION_ID not in", values, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdBetween(String value1, String value2) {
            addCriterion("CONDITION_ID between", value1, value2, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionIdNotBetween(String value1, String value2) {
            addCriterion("CONDITION_ID not between", value1, value2, "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionNameIsNull() {
            addCriterion("CONDITION_NAME is null");
            return (Criteria) this;
        }

        public Criteria andConditionNameIsNotNull() {
            addCriterion("CONDITION_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andConditionNameEqualTo(String value) {
            addCriterion("CONDITION_NAME =", value, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameNotEqualTo(String value) {
            addCriterion("CONDITION_NAME <>", value, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameGreaterThan(String value) {
            addCriterion("CONDITION_NAME >", value, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameGreaterThanOrEqualTo(String value) {
            addCriterion("CONDITION_NAME >=", value, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameLessThan(String value) {
            addCriterion("CONDITION_NAME <", value, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameLessThanOrEqualTo(String value) {
            addCriterion("CONDITION_NAME <=", value, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameLike(String value) {
            addCriterion("CONDITION_NAME like", value, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameNotLike(String value) {
            addCriterion("CONDITION_NAME not like", value, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameIn(List<String> values) {
            addCriterion("CONDITION_NAME in", values, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameNotIn(List<String> values) {
            addCriterion("CONDITION_NAME not in", values, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameBetween(String value1, String value2) {
            addCriterion("CONDITION_NAME between", value1, value2, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionNameNotBetween(String value1, String value2) {
            addCriterion("CONDITION_NAME not between", value1, value2, "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionCodeIsNull() {
            addCriterion("CONDITION_CODE is null");
            return (Criteria) this;
        }

        public Criteria andConditionCodeIsNotNull() {
            addCriterion("CONDITION_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andConditionCodeEqualTo(String value) {
            addCriterion("CONDITION_CODE =", value, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeNotEqualTo(String value) {
            addCriterion("CONDITION_CODE <>", value, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeGreaterThan(String value) {
            addCriterion("CONDITION_CODE >", value, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeGreaterThanOrEqualTo(String value) {
            addCriterion("CONDITION_CODE >=", value, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeLessThan(String value) {
            addCriterion("CONDITION_CODE <", value, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeLessThanOrEqualTo(String value) {
            addCriterion("CONDITION_CODE <=", value, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeLike(String value) {
            addCriterion("CONDITION_CODE like", value, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeNotLike(String value) {
            addCriterion("CONDITION_CODE not like", value, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeIn(List<String> values) {
            addCriterion("CONDITION_CODE in", values, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeNotIn(List<String> values) {
            addCriterion("CONDITION_CODE not in", values, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeBetween(String value1, String value2) {
            addCriterion("CONDITION_CODE between", value1, value2, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionCodeNotBetween(String value1, String value2) {
            addCriterion("CONDITION_CODE not between", value1, value2, "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionIsNull() {
            addCriterion("CONDITION_DESCRIPTION is null");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionIsNotNull() {
            addCriterion("CONDITION_DESCRIPTION is not null");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionEqualTo(String value) {
            addCriterion("CONDITION_DESCRIPTION =", value, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionNotEqualTo(String value) {
            addCriterion("CONDITION_DESCRIPTION <>", value, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionGreaterThan(String value) {
            addCriterion("CONDITION_DESCRIPTION >", value, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionGreaterThanOrEqualTo(String value) {
            addCriterion("CONDITION_DESCRIPTION >=", value, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionLessThan(String value) {
            addCriterion("CONDITION_DESCRIPTION <", value, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionLessThanOrEqualTo(String value) {
            addCriterion("CONDITION_DESCRIPTION <=", value, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionLike(String value) {
            addCriterion("CONDITION_DESCRIPTION like", value, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionNotLike(String value) {
            addCriterion("CONDITION_DESCRIPTION not like", value, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionIn(List<String> values) {
            addCriterion("CONDITION_DESCRIPTION in", values, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionNotIn(List<String> values) {
            addCriterion("CONDITION_DESCRIPTION not in", values, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionBetween(String value1, String value2) {
            addCriterion("CONDITION_DESCRIPTION between", value1, value2, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionNotBetween(String value1, String value2) {
            addCriterion("CONDITION_DESCRIPTION not between", value1, value2, "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("CREATE_USER is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("CREATE_USER is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("CREATE_USER =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("CREATE_USER <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("CREATE_USER >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("CREATE_USER >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("CREATE_USER <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("CREATE_USER <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("CREATE_USER like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("CREATE_USER not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("CREATE_USER in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("CREATE_USER not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("CREATE_USER between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("CREATE_USER not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("CREATE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("CREATE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("CREATE_DATE =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("CREATE_DATE <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("CREATE_DATE >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("CREATE_DATE <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("CREATE_DATE in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("CREATE_DATE not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNull() {
            addCriterion("MODIFY_USER is null");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNotNull() {
            addCriterion("MODIFY_USER is not null");
            return (Criteria) this;
        }

        public Criteria andModifyUserEqualTo(String value) {
            addCriterion("MODIFY_USER =", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotEqualTo(String value) {
            addCriterion("MODIFY_USER <>", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThan(String value) {
            addCriterion("MODIFY_USER >", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER >=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThan(String value) {
            addCriterion("MODIFY_USER <", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER <=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLike(String value) {
            addCriterion("MODIFY_USER like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotLike(String value) {
            addCriterion("MODIFY_USER not like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserIn(List<String> values) {
            addCriterion("MODIFY_USER in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotIn(List<String> values) {
            addCriterion("MODIFY_USER not in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserBetween(String value1, String value2) {
            addCriterion("MODIFY_USER between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotBetween(String value1, String value2) {
            addCriterion("MODIFY_USER not between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNull() {
            addCriterion("MODIFY_DATE is null");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNotNull() {
            addCriterion("MODIFY_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andModifyDateEqualTo(Date value) {
            addCriterion("MODIFY_DATE =", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotEqualTo(Date value) {
            addCriterion("MODIFY_DATE <>", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThan(Date value) {
            addCriterion("MODIFY_DATE >", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE >=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThan(Date value) {
            addCriterion("MODIFY_DATE <", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE <=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateIn(List<Date> values) {
            addCriterion("MODIFY_DATE in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotIn(List<Date> values) {
            addCriterion("MODIFY_DATE not in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE not between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("DEL_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("DEL_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(String value) {
            addCriterion("DEL_FLAG =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(String value) {
            addCriterion("DEL_FLAG <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(String value) {
            addCriterion("DEL_FLAG >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(String value) {
            addCriterion("DEL_FLAG <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLike(String value) {
            addCriterion("DEL_FLAG like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotLike(String value) {
            addCriterion("DEL_FLAG not like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<String> values) {
            addCriterion("DEL_FLAG in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<String> values) {
            addCriterion("DEL_FLAG not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(String value1, String value2) {
            addCriterion("DEL_FLAG between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(String value1, String value2) {
            addCriterion("DEL_FLAG not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andConditionIdLikeInsensitive(String value) {
            addCriterion("upper(CONDITION_ID) like", value.toUpperCase(), "conditionId");
            return (Criteria) this;
        }

        public Criteria andConditionNameLikeInsensitive(String value) {
            addCriterion("upper(CONDITION_NAME) like", value.toUpperCase(), "conditionName");
            return (Criteria) this;
        }

        public Criteria andConditionCodeLikeInsensitive(String value) {
            addCriterion("upper(CONDITION_CODE) like", value.toUpperCase(), "conditionCode");
            return (Criteria) this;
        }

        public Criteria andConditionDescriptionLikeInsensitive(String value) {
            addCriterion("upper(CONDITION_DESCRIPTION) like", value.toUpperCase(), "conditionDescription");
            return (Criteria) this;
        }

        public Criteria andCreateUserLikeInsensitive(String value) {
            addCriterion("upper(CREATE_USER) like", value.toUpperCase(), "createUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLikeInsensitive(String value) {
            addCriterion("upper(MODIFY_USER) like", value.toUpperCase(), "modifyUser");
            return (Criteria) this;
        }

        public Criteria andDelFlagLikeInsensitive(String value) {
            addCriterion("upper(DEL_FLAG) like", value.toUpperCase(), "delFlag");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}