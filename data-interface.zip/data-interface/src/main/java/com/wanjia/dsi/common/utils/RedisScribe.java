/**
 * 
 */
package com.wanjia.dsi.common.utils;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * @author huanglei698
 *
 */
@Service
public class RedisScribe implements Runnable, InitializingBean {

	@Value("#{jedisConfig['paymentStockChannel']}")
	private String paymentStockChannel;

	@Autowired
	private CommonJedis commonJedis;

	@Override
	public void run() {
		RedisListener listener = new RedisListener();
		commonJedis.psubscribe(listener, new String[] { paymentStockChannel });
	}

	@Override
	public void afterPropertiesSet() {
		new Thread(this).start();
	}
}
