package com.wanjia.dsi.web.job.service.impl;


import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.job.dao.mapper.TalentJobHotMapper;
import com.wanjia.dsi.web.job.model.TalentJobHot;
import com.wanjia.dsi.web.job.model.TalentJobHotExample;
import com.wanjia.dsi.web.job.service.TalentJobHotService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class TalentJobHotServiceImpl extends BaseServiceImpl implements TalentJobHotService {

	private Logger logger = Logger.getLogger(TalentJobHotServiceImpl.class);

	@Autowired
	private TalentJobHotMapper talentJobHotMapper;

	@Override
	public JsonResponse<List<TalentJobHot>> getAllClinicJobHotList(String requestId, TalentJobHot clinicJobHot) {
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getAllClinicJobHotList method start...");
		
		JsonResponse<List<TalentJobHot>> result = new JsonResponse<List<TalentJobHot>>();
		try {
			TalentJobHotExample example = new TalentJobHotExample();
			List<TalentJobHot> jobHotList = talentJobHotMapper.selectByExample(example);
			result.setResult(jobHotList);
		} catch (Exception e) {
			logger.info("查询热门岗位失败:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getAllClinicJobHotList method end...");
		return result;
	}

	
}
