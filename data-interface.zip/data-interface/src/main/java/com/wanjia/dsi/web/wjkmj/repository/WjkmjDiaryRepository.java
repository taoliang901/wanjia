package com.wanjia.dsi.web.wjkmj.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.base.mongodb.impl.MongoDbRepositoryImpl;
import com.wanjia.dsi.web.wjkmj.model.WjkmjDayCount;
import com.wanjia.dsi.web.wjkmj.model.WjkmjDiaryBO;

@Repository
public class WjkmjDiaryRepository extends MongoDbRepositoryImpl<WjkmjDiaryBO> {

	@Resource
	private MongoTemplate mongoTemplate;

	/**
	 * 获取今天投票的统计数据，group by clinicId,countDate
	 * 
	 * @param voteDate
	 * @param clinicIds
	 * @return
	 */
	public List<WjkmjDayCount> getWjkmjDayCountListMongo(Date voteDate, List<String> clinicIds) {
		List<WjkmjDayCount> result = new ArrayList<WjkmjDayCount>();

		String voteDateOfDay = DateUtils.format(voteDate, DateUtils.DATE_FORMAT_TYPE3);
		List<DBObject> pipeline = new ArrayList<DBObject>();
		// 记录过滤条件
		String matchStr = null;
		if (clinicIds != null && clinicIds.size() > 0) {
			StringBuffer clinicOr = new StringBuffer("[");
			for (int i = 0; i < clinicIds.size(); i++) {
				if (i == clinicIds.size() - 1) {
					clinicOr.append("{clinicId: \"" + clinicIds.get(i) + "\"}]");
				} else {
					clinicOr.append("{clinicId: \"" + clinicIds.get(i) + "\"},");
				}
			}
			matchStr = "{$match:{voteDateOfDay:\"" + voteDateOfDay + "\",$or: " + clinicOr.toString() + "}}";
		} else {
			matchStr = "{$match:{voteDateOfDay:\"" + voteDateOfDay + "\"}}";
		}
		DBObject match = (DBObject) JSON.parse(matchStr);
		pipeline.add(match);

		// 分组条件
		String groupStr = "{$group:{_id: {'clinicId':'$clinicId','voteDateOfDay':'$voteDateOfDay'}, voteToday:{$sum:1}}}";
		DBObject group = (DBObject) JSON.parse(groupStr);
		pipeline.add(group);

		// 获取数据
		DBCollection conn = mongoTemplate.getCollection("wjkmjDiaryBO");
		AggregationOutput output = conn.aggregate(pipeline);
		for (Iterator<DBObject> it = output.results().iterator(); it.hasNext();) {
			BasicDBObject dbo = (BasicDBObject) it.next();
			BasicDBObject keyValus = (BasicDBObject) dbo.get("_id");
			WjkmjDayCount wjkmjDayCount = new WjkmjDayCount();

			wjkmjDayCount.setClinicId(keyValus.getString("clinicId"));
			String vateDate = keyValus.getString("voteDateOfDay");
			wjkmjDayCount.setCountDate(DateUtils.parse(vateDate, DateUtils.DATE_FORMAT_TYPE3));
			if ((Integer) dbo.get("voteToday") > 0) {
				wjkmjDayCount.setVoteToday((Integer) dbo.get("voteToday"));
			} else {
				wjkmjDayCount.setVoteToday(0);
			}
			result.add(wjkmjDayCount);
		}
		return result;
	}

	/**
	 * 获取今天投票的统计数据，group by clinicId,countDate,userIp
	 * 
	 * @param voteDate
	 * @param clinicIds
	 * @param userIp
	 * @return
	 */
	public List<WjkmjDayCount> getWjkmjDayIsVoteListMongo(Date voteDate, List<String> clinicIds, String userIp) {
		List<WjkmjDayCount> result = new ArrayList<WjkmjDayCount>();

		String voteDateOfDay = DateUtils.format(voteDate, DateUtils.DATE_FORMAT_TYPE3);
		List<DBObject> pipeline = new ArrayList<DBObject>();
		// 记录过滤条件
		String matchStr = null;
		if (clinicIds != null && clinicIds.size() > 0) {
			StringBuffer clinicOr = new StringBuffer("[");
			for (int i = 0; i < clinicIds.size(); i++) {
				if (i == clinicIds.size() - 1) {
					clinicOr.append("{clinicId: \"" + clinicIds.get(i) + "\"}]");
				} else {
					clinicOr.append("{clinicId: \"" + clinicIds.get(i) + "\"},");
				}
			}
			matchStr = "{$match:{userIp:\"" + userIp + "\",voteDateOfDay:\"" + voteDateOfDay + "\", $or: "
					+ clinicOr.toString() + "}}";
		} else {
			matchStr = "{$match:{userIp:\"" + userIp + "\",voteDateOfDay:\"" + voteDateOfDay + "\"}}";
		}
		DBObject match = (DBObject) JSON.parse(matchStr);
		pipeline.add(match);

		// 分组条件
		String groupStr = "{$group:{_id:{'clinicId':'$clinicId','voteDateOfDay':'$voteDateOfDay','userIp':'$userIp'},voteToday:{$sum:1}}}";
		DBObject group = (DBObject) JSON.parse(groupStr);
		pipeline.add(group);

		// 获取数据
		DBCollection conn = mongoTemplate.getCollection("wjkmjDiaryBO");
		AggregationOutput output = conn.aggregate(pipeline);
		for (Iterator<DBObject> it = output.results().iterator(); it.hasNext();) {
			BasicDBObject dbo = (BasicDBObject) it.next();
			BasicDBObject keyValus = (BasicDBObject) dbo.get("_id");
			WjkmjDayCount wjkmjDayCount = new WjkmjDayCount();

			wjkmjDayCount.setClinicId(keyValus.getString("clinicId"));
			String vateDate = keyValus.getString("voteDateOfDay");
			wjkmjDayCount.setCountDate(DateUtils.parse(vateDate, DateUtils.DATE_FORMAT_TYPE3));
			if ((Integer) dbo.get("voteToday") > 0) {
				wjkmjDayCount.setIsVoted("1");
			} else {
				wjkmjDayCount.setIsVoted("0");
			}
			result.add(wjkmjDayCount);
		}
		return result;
	}

	/**
	 * 根据诊所ID, 用户ID，投票日期判读是否存在记录(是否已投票)
	 * 
	 * @param voteDate
	 * @param clinicIds
	 * @param userIp
	 * @return
	 */
	public boolean isVoted(Date voteDate, String activityId, String clinicId, String userIp) {

		Query query = new Query();
		if (StringUtils.isNotBlank(clinicId)) {
			query.addCriteria(Criteria.where("clinicId").is(clinicId));
		} else {
			throw new ServiceException(null, "诊所Id不能为空!");
		}

		if (StringUtils.isNotBlank(userIp)) {
			query.addCriteria(Criteria.where("userIp").is(userIp));
		} else {
			throw new ServiceException(null, "用户IP不能为空!");
		}

		if (voteDate != null) {
			String voteDateOfDay = DateUtils.format(voteDate, DateUtils.DATE_FORMAT_TYPE3);
			query.addCriteria(Criteria.where("voteDateOfDay").is(voteDateOfDay));
		} else {
			throw new ServiceException(null, "用户投票日期不能为空!");
		}

		if (activityId != null) {
			query.addCriteria(Criteria.where("activityId").is(activityId));
		}

		// 每个IP每天只能对每个诊所投一次票
		if (this.findCount(query, WjkmjDiaryBO.class) == 0) {
			return false;
		} else {
			return true;
		}
	}
}
