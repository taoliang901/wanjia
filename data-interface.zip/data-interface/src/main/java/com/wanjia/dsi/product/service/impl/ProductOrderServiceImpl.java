package com.wanjia.dsi.product.service.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.pahaoche.hy.user.service.SmsServer;
import com.pahaoche.hy.user.service.SmsUtils;
import com.pahaoche.hy.util.RandomUtil;
import com.pinganwj.clinic.api.ApptService;
import com.pinganwj.clinic.api.ProductApptApi;
import com.pinganwj.clinic.api.WeiXinTempApi;
import com.pinganwj.clinic.api.domain.EmptyRsp;
import com.pinganwj.clinic.api.domain.appt.ApptRecordInfo;
import com.pinganwj.clinic.api.domain.appt.ApptRecordQueryReq;
import com.pinganwj.clinic.api.domain.appt.ApptRecordQueryRsp;
import com.pinganwj.clinic.api.domain.appt.ModifyApptReq;
import com.pinganwj.clinic.api.domain.appt.PatientVisit;
import com.pinganwj.clinic.api.domain.appt.product.GetProductApptCountReq;
import com.pinganwj.clinic.api.domain.appt.product.ProductApptSubmitReq;
import com.pinganwj.clinic.api.domain.appt.product.ProductApptSubmitRsp;
import com.pinganwj.clinic.api.domain.weixin.MessageResult;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.common.utils.DateTools;
import com.wanjia.dsi.common.utils.ValidateUtils;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.PrdServiceMapper;
import com.wanjia.dsi.product.dao.mapper.PrdTypeServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdKucunMapper;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.PrdService;
import com.wanjia.dsi.product.model.PrdServiceExample;
import com.wanjia.dsi.product.model.PrdTypeService;
import com.wanjia.dsi.product.model.ProductInfo;
import com.wanjia.dsi.product.model.VOPrdKucunMUI;
import com.wanjia.dsi.product.service.HyPrdConfigService;
import com.wanjia.dsi.product.service.ProductMessageService;
import com.wanjia.dsi.product.service.ProductOrderService;
import com.wanjia.dsi.product.service.ProductService;
import com.wanjia.dsi.product.service.RecivePrdFromCodeService;
import com.wanjia.dsi.product.service.StockService;
import com.wanjia.dsi.product.vo.VOPrdAllClinics;
import com.wanjia.dsi.product.vo.VOPrdBooking;
import com.wanjia.dsi.product.vo.VOPrdKucun;
import com.wanjia.dsi.product.vo.VOPrdService;
import com.wanjia.dsi.web.hyPerson.dao.mapper.AddressInfoApprovalMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyClinicInfoMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyFrontParnterMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyTreatmentPersonMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.VOClcInfoApprovalMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.VoHyUserInfoMapper;
import com.wanjia.dsi.web.hyPerson.model.AddressInfoApproval;
import com.wanjia.dsi.web.hyPerson.model.AddressInfoApprovalExample;
import com.wanjia.dsi.web.hyPerson.model.HyClinicInfo;
import com.wanjia.dsi.web.hyPerson.model.HyFrontParnter;
import com.wanjia.dsi.web.hyPerson.model.HyFrontParnterExample;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;
import com.wanjia.dsi.web.hyPerson.service.TreatmentService;
import com.wanjia.dsi.web.hyPerson.vo.VOClcInfoApproval;
import com.wanjia.dsi.web.hyPerson.vo.hy.VoHyUserInfo;
import com.wanjia.dsi.web.message.service.MessageService;
import com.wanjia.message.service.MessageProducerService;
import com.wanjia.sms.interior.interfaces.sms.model.req.SendSMSRequest;
import com.wanjia.sms.interior.interfaces.sms.service.SmsClientService;

/**
 * 预约信息接口
 * 
 * @author FANGYUNLONG278
 *
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class ProductOrderServiceImpl implements ProductOrderService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	// 缓存服务
	@Autowired
	private CommonJedis commonJedis;
	
	// 短信发送
	@Resource
	public SmsServer smsServer;
	
	// 查询产品库存
	@Resource
	private VOPrdKucunMapper vOPrdKucunMapper;
	
	// 插入我的产品表
	@Resource
	private RecivePrdFromCodeService recivePrdFromCodeService;
	
	// 深圳产品接口
	@Autowired
	private ProductApptApi productApptApi;
	
	// 深圳预约接口
	@Autowired
	private ApptService apptService;

	// 就诊人查询
	@Autowired
	private TreatmentService treatmentService;
	
	// SMS短信发送（非卡不卡）
	@Autowired
	private SmsClientService smsClientService;
	
	// 查询诊所信息
	@Resource
	private VOClcInfoApprovalMapper vOClcInfoApprovalMapper;
	
	// 消息发送
	@Autowired
	private MessageService messageService;
	
	// 产品库存缓存
	@Resource
	private StockService stockService;
	
	// 预约产品信息
	@Autowired
	private ProductMessageService productMessageService;
	
	@Autowired
	private MessageProducerService messageProducerService;
	
	@Autowired 
	private ProductService productService;
	
	@Autowired
	private HyPrdConfigService hyPrdConfigService;
	
	@Autowired
	private VoHyUserInfoMapper hyUserInfoMapper;
	
	// 产品服务项目
	@Autowired
	private PrdServiceMapper prdServiceMapper;
	
	// 就诊人数据
	@Autowired
	private HyTreatmentPersonMapper hyTreatmentPersonMapper;
	
	@Autowired
	private WeiXinTempApi weiXinTempApi;
	
	@Autowired
	private HyFrontParnterMapper hyFrontParnterMapper;
	
	@Autowired AddressInfoApprovalMapper addressInfoApprovalMapper;
	
	// 产品信息
	@Autowired
	private PrdInfoMapper prdInfoMapper;
	
	// 服务项目信息
	@Autowired
	private PrdTypeServiceMapper prdTypeServiceMapper;
	
	// 诊所信息
	@Autowired
	private HyClinicInfoMapper hyClinicInfoMapper;
	
	@Autowired
	private PrdKucunMapper prdKucunMapper;
	
	@Override
	public JsonResponse<Void> submitOrder(VOPrdBooking booking) throws ParseException {
		logger.info("OrderService.submitOrder开始：");
		JsonResponse<Void> jr = new JsonResponse<Void>();
		
		// 1)提交预约接口前：参数校验
		Date start = new Date();
		String userId = booking.getUserId();
		checkDataBeforeBooking(booking, userId);
        Date end = new Date();
        logger.info("1）提交预约接口前：参数校验，耗时【" + (end.getTime() - start.getTime()) * 1.0 / 1000 + "】秒");
        
        
        // 2)判断卡号密码是否正确
        start = new Date();
        VOPrdKucun kucun = productMessageService.findKucunbyMsg(null, null, booking.getPrdKucunId(), "4").getResult();
        end = new Date();
        logger.info("2）判断卡号密码是否正确，耗时【" + (end.getTime() - start.getTime()) * 1.0 / 1000 + "】秒");
        
		// 4)验证就诊人年龄是否符合产品服务项目要求
        logger.info("4）验证就诊人年龄是否符合产品服务项目要求");
        List<HyTreatmentPerson> visitList = booking.getVisitList();
        logger.info("就诊人信息："+visitList);
        // 暂时支持一个就诊人，一个服务项目，一次性产品的所有服务项目年龄段一样
        // 查询产品服务项目
    	PrdServiceExample prdExample = new PrdServiceExample();
		PrdServiceExample.Criteria prdCriteria = prdExample.createCriteria();
		prdCriteria.andPrdIdEqualTo(booking.getCouponId());
		if(StringUtils.isNotBlank(booking.getPrdServiceId())&&!booking.getPrdServiceId().contains("|")){
			prdCriteria.andServiceIdEqualTo(booking.getPrdServiceId());
		}
		prdCriteria.andDelFlagEqualTo(0);
		List<PrdService> prdServiceList = prdServiceMapper.selectByExample(prdExample);
		PrdService prdService = prdServiceList.get(0);
		// 就诊人年龄小于服务项目年龄范围下限||大于上限，则不能逾越
		if(StringUtils.isNotBlank(prdService.getFloorAge())&&StringUtils.isNotBlank(prdService.getTopAge())){
	        for(HyTreatmentPerson item:visitList)
	        {
	        	if(StringUtils.isBlank(item.getVisitBrithday())){
	        		throw new ServiceException(null, "就诊人出生日期不得为空，请先修改就诊人信息");
	        	}
	        	int age = DateTools.getAge(item.getVisitBrithday());
				if(age<Integer.parseInt(prdService.getFloorAge())||age>Integer.parseInt(prdService.getTopAge())){
					throw new ServiceException(null, "就诊人不符合预约服务项目的年龄要求，请更换就诊人");
				}
			}
        }
		
		// 4)卡号密码预约，且第一次预约（即订单表不存在），则插入三张订单表（需卡号密码）
		start = new Date();
		if(StringUtils.isBlank(kucun.getBuyerUserId())) {    
			logger.info("调用dubbo接口：recivePrdFromCodeService.insertOrderDetailService()");
			recivePrdFromCodeService.insertOrderDetailService(booking.getCouponId(), Long.parseLong(userId), booking.getPrdKucunId(), null, booking.getTreatDate());
		}
		end = new Date();
		logger.info("4）线下卡，且第一次预约（即订单表不存在），耗时【" + (end.getTime() - start.getTime()) * 1.0 / 1000 + "】秒");

		// 6)校验【项目次数】：无限次、一次性项目：次数与就诊人有关（编辑时对应项目的剩余次数+old_N：2处）；
        start = new Date();
        /** 一次性产品（即：使用频次 0-一次使用,1-多次使用） */
		if("0".equals(booking.getUseFrequence())) {
			logger.info("调用dubbo接口：productApptApi.getProductApptCount()");
	        GetProductApptCountReq req = new GetProductApptCountReq();
	        req.setCardId(booking.getPrdKucunId());
	        com.pinganwj.clinic.api.domain.JsonResponse<Integer> countResult = productApptApi.getProductApptCount(req);
	        if(!"SUCCESS".equals(countResult.getStatus().toString())) {
	        	logger.error("调用dubbo接口失败：productApptApi.getProductApptCount()"+countResult.getErrorMsg());
	        	throw new ServiceException(null, countResult.getErrorMsg());
			}
	        Integer usedCnt = countResult.getResult();
	        if(!"2".equals(booking.getFlag())) {
		        if(usedCnt >= 1) {
		        	throw new ServiceException(null, "该卡只能使用一次");
		        }
	        }
		} else {
			if(!"0".equals(booking.getIsUnlimite())) {
				logger.info("调用dubbo接口：productApptApi.getProductApptCount()");
		        GetProductApptCountReq req = new GetProductApptCountReq();
		        req.setCardId(booking.getPrdKucunId());
		        req.setHealthProductItemId(booking.getPrdServiceId());
		        com.pinganwj.clinic.api.domain.JsonResponse<Integer> countResult = productApptApi.getProductApptCount(req);
		        if(!"SUCCESS".equals(countResult.getStatus().toString())) {
		        	logger.error("调用dubbo接口失败：productApptApi.getProductApptCount()"+countResult.getErrorMsg());
		        	throw new ServiceException(null, countResult.getErrorMsg());
				}
		        Integer usedCnt = countResult.getResult();
		        
		        if((booking.getServiceCount()-usedCnt+booking.getEditOldVisitCnt()) < booking.getVisitList().size()) {
		        	throw new ServiceException(null,"该服务项目不足"+booking.getVisitList().size()+"次（只剩"+(booking.getServiceCount()-usedCnt+booking.getEditOldVisitCnt())+"次）");
		        }
			}
		}
		end = new Date();
		logger.info("6）校验【项目次数】，耗时【" + (end.getTime() - start.getTime()) * 1.0 / 1000 + "】秒");

		// 9)调用深圳接口，进行预约
		ProductApptSubmitReq req = new ProductApptSubmitReq();
		req.setCardId(booking.getPrdKucunId());
		req.setHealthProductId(booking.getCouponId());
		req.setHealthProductName(booking.getCouponName());
		req.setHealthProductItemId(booking.getPrdServiceId());
		req.setHealthProductItemName(booking.getServiceName());
		req.setUserId(userId);
		req.setClinicId(booking.getClinicId());
		req.setApptDate(booking.getTreatDate());
		req.setApptStartTime(booking.getTreatTimeStart());
		req.setApptEndTime(booking.getTreatTimeEnd());
		req.setMemberName(booking.getRealName());
		req.setMemberMobile(booking.getMobile());
		req.setApptRemark(booking.getRemark());
		PatientVisit visit = new PatientVisit();
		visit.setId(""+booking.getVisitList().get(0).getVisitId());
		visit.setName(""+booking.getVisitList().get(0).getVisitName());
		visit.setMobile(""+booking.getVisitList().get(0).getVisitMobile());
		visit.setIdCardTypeCode(""+booking.getVisitList().get(0).getVisitIdCardTypeCode());
		visit.setIdCardNo(""+booking.getVisitList().get(0).getVisitIdCardCode());
		visit.setSexCode(""+booking.getVisitList().get(0).getVisitSex());
		visit.setBirthday(""+booking.getVisitList().get(0).getVisitBrithday());
		req.setPatientVisit(visit);
		
		// 更新就诊人数据
		for(HyTreatmentPerson hyTreatmentPerson : booking.getVisitList()){
			hyTreatmentPerson.setModifyDate(new Date());
			hyTreatmentPersonMapper.updateByPrimaryKeySelective(hyTreatmentPerson);
		}

	    // 7)如果是编辑
        start = new Date();
        String apptOrderCode;  //预约订单号
        if(StringUtils.isNotBlank(booking.getOrderId())) {//修改预约
        	ModifyApptReq modifyApptReq = new ModifyApptReq();
        	modifyApptReq.setApptOrderCode(booking.getOrderId()); //预约订单号
        	modifyApptReq.setApptOptUserType(0); // 预约操作人员类型（0：会员，1：诊所工作人员，2，运营客服人员）
        	modifyApptReq.setClinicId(booking.getClinicId());  //诊所ID
        	modifyApptReq.setApptDate(booking.getTreatDate()); //就诊日期(yyyy-MM-dd)
        	modifyApptReq.setApptStartTime(booking.getTreatTimeStart()); //时段开始时间(HH:MM)
        	modifyApptReq.setApptEndTime(booking.getTreatTimeEnd()); //时段结束时间(HH:MM)
        	modifyApptReq.setPatientVisit(visit);//设置就诊人
        	modifyApptReq.setApptRemark(booking.getRemark());
        	com.pinganwj.clinic.api.domain.JsonResponse<EmptyRsp>  modifyResult = apptService.modifyAppt(modifyApptReq);
        	if(!"SUCCESS".equals(modifyResult.getStatus().toString())) {
        		logger.error("调用dubbo接口失败：apptService.modifyAppt()");
	        	throw new ServiceException(null, modifyResult.getErrorMsg());
			}	
        	apptOrderCode = booking.getOrderId();
        	end = new Date();
            logger.info("7）修改预约，耗时【" + (end.getTime() - start.getTime()) * 1.0 / 1000 + "】秒");
        }else{//提交预约
     	    com.pinganwj.clinic.api.domain.JsonResponse<ProductApptSubmitRsp> submitResult = productApptApi.productApptSubmit(req);
             if(!"SUCCESS".equals(submitResult.getStatus().toString())) {
             	logger.error("调用dubbo接口失败：productApptApi.productApptSubmit()");
             	throw new ServiceException(null, submitResult.getErrorMsg());
     		}
             ProductApptSubmitRsp  rsp2 = submitResult.getResult();
             apptOrderCode = rsp2.getApptOrderCode();
             logger.info("9,10,11）OrderService.submitOrder预约成功："+ booking.getOrderId());
        }
        
        // 12)预约成功后，发送短信给【诊所管理员】
		VOClcInfoApproval clinic = vOClcInfoApprovalMapper.selectByPrimaryKey(booking.getClinicId());
        String mobile = clinic.getMobileOfChild();
        if(StringUtils.isBlank(mobile)) {
        	mobile = clinic.getMobileOfParent();
        }
        // 获取诊所验证的手机号
        HyClinicInfo hyClinicInfo = hyClinicInfoMapper.selectByPrimaryKey(booking.getClinicId());
        if(StringUtils.isNotBlank(hyClinicInfo.getBookFlag())&&"1".equals(hyClinicInfo.getBookFlag())){
        	mobile = hyClinicInfo.getMobile();
        }
        
        if(StringUtils.isBlank(mobile)) {
        	logger.error("预约成功短信通知诊所【"+booking.getClinicId()+"】失败：诊所对应手机号为空！");
        } else {
            SendSMSRequest req4 = new SendSMSRequest("hy", mobile, null);
            req4.setTemplateID(SendSMSRequest.JK160930009);
            req4.putParams("year", booking.getTreatDate().substring(0, 4)); // yyyy-MM-dd
            req4.putParams("month", booking.getTreatDate().substring(5, 7));
            req4.putParams("day", booking.getTreatDate().substring(8, 10));
            req4.putParams("time", booking.getTreatTimeStart());
            req4.putParams("clinicName", booking.getClinicName());
            req4.putParams("productName", booking.getCouponName());
           // req4.putParams("bookingNo", rsp2.getApptOrderCode());
            req4.putParams("bookingNo", apptOrderCode);
            req4.putParams("patient", booking.getVisitList().get(0).getVisitName());
            try {
            	JsonResponse<String> jsonResp = smsClientService.sendSMSByDubbo(req4);
            	if(JsonResponse.Status.ERROR.equals(jsonResp.getStatus().toString())) {
            		logger.error("预约成功短信通知诊所【"+booking.getClinicId()+"】失败："+mobile+"：响应失败："+jsonResp.getErrorCode()+"："+jsonResp.getErrorMsg());
            	} else if(JsonResponse.Status.WARNING.equals(jsonResp.getStatus().toString())) {
            		logger.warn("预约成功短信通知诊所【"+booking.getClinicId()+"】警告："+mobile+"：响应警告："+jsonResp.getErrorCode()+"："+jsonResp.getErrorMsg());
            	}
            } catch(Exception e) {
            	logger.error("预约成功短信通知诊所【"+booking.getClinicId()+"】失败："+mobile+"：抛出异常", e);
            }
        }
        logger.info("12）OrderService.submitOrder预约成功后，发送短信给【诊所管理员】成功");
        
        
        // 13)预约成功后，发消息给诊所管理员
		try {
    		logger.info("调用dubbo接口：messageService.patientBooking()");
    		//JsonResponse<Void> res3 = messageService.patientBooking(rsp2.getApptOrderCode(), UUID.randomUUID().toString(), 
    		JsonResponse<Void> res3 = messageService.patientBooking(apptOrderCode, UUID.randomUUID().toString(), 
            		visit.getName(), booking.getTreatDate()+" "+booking.getTreatTimeStart(), 
            		booking.getClinicId(), booking.getServiceName());
			if(!"SUCCESS".equals(res3.getStatus().toString())) {
				logger.error("预约成功后，给诊所发【成功】消息异常："+res3.getStatus().toString()+"："+res3.getErrorMsg());
			}
		} catch(Exception e) {
			logger.error("预约成功后，给诊所发【成功】消息异常！", e);
		}
		logger.info("14)OrderService.submitOrder再发预约成功消息成功");
		
		// 15)预约成功后，更新缓存库存
		logger.info("15）更新库存信息"+booking.getCouponId()+"----------"+booking.getPrdKucunId());
		stockService.setStockStatus(booking.getCouponId(), booking.getPrdKucunId(), "1");
		jr.setStatus(Status.SUCCESS);
		return jr;
	}
	
	//提交预约参数有效性校验
	private JsonResponse<Void> checkDataBeforeBooking(VOPrdBooking order, String userId) {

		JsonResponse<Void> result = new JsonResponse<Void>();

		// 1、检验参数有效性
        if(StringUtils.isBlank(order.getPrdKucunId())) {
			throw new ServiceException(null, "产品库存ID不能为空!");
        }
        if(StringUtils.isBlank(order.getClinicId())) {
			throw new ServiceException(null, "诊所ID不能为空!");
        }
        if(StringUtils.isBlank(order.getTreatDate())) {
			throw new ServiceException(null, "就诊时间不可为空!");
        }
        if(CollectionUtils.isEmpty(order.getVisitList())) {
			throw new ServiceException(null, "就诊人列表不可为空!");
        }
        if(StringUtils.isBlank(order.getCouponId())) {
			throw new ServiceException(null, "产品ID不能为空!");
        }
        if(StringUtils.isBlank(order.getCouponName())) {
			throw new ServiceException(null, "产品名称不能为空!");
        }
        if(StringUtils.isBlank(order.getUseFrequence())) {
			throw new ServiceException(null, "是否一次性使用不能为空!");
        }
		if(!"0".equals(order.getUseFrequence())){
	        if(StringUtils.isBlank(order.getPrdServiceId())) {
				throw new ServiceException(null, "服务项目ID不能为空!");
	        }
	        if(StringUtils.isBlank(order.getServiceName())) {
				throw new ServiceException(null, "服务项目名称不能为空!");
	        }
		}
        if(order.getVisitList().size() != 1)	// 08.11版本暂时只能选择一个就诊人
        {
			throw new ServiceException(null, "暂时只能预约1个就诊人！");
        }
        for(int i=0; i<order.getVisitList().size(); i++) {
        	HyTreatmentPerson item = order.getVisitList().get(i);
    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitName(), 48)) {
    			throw new ServiceException(null, "【就诊人名称】超过"+48+"个字节<br/>");
    		}
    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitIdCardTypeCode(), 10)) {
    			throw new ServiceException(null, "【证件类型】超过"+10+"个字节<br/>");
    		}
    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitIdCardCode(), 48)) {
    			throw new ServiceException(null, "【证件号码】超过"+48+"个字节<br/>");
    		}
    		if (!ValidateUtils.checkMaxLengthForByte(item.getVisitMobile(), 48)) {
    			throw new ServiceException(null, "【手机号】超过"+32+"个字节<br/>");
    		}
        }  
        return result;
	}

	@Override
	public JsonResponse<VOPrdBooking>  findBookingMessage(String bookingId){
		// 返回值
		JsonResponse<VOPrdBooking> jr = new JsonResponse<VOPrdBooking>();
		VOPrdBooking vOPrdBooking = new VOPrdBooking();
		
		// 数据校验
		if(StringUtils.isBlank(bookingId)) {
			throw new ServiceException(null, "【bookingId】不能为空！");
		}
		
		// 调用深圳接口,查询预约信息
		ApptRecordQueryReq req = new ApptRecordQueryReq();
		req.setApptOrderCode(bookingId);
		logger.info("调用dubbo接口开始：apptService.getApptRecord()"+bookingId);
        com.pinganwj.clinic.api.domain.JsonResponse<ApptRecordQueryRsp> getAppResult = apptService.getApptRecord(req);
        if(!"SUCCESS".equals(getAppResult.getStatus().toString())) {
        	logger.error("调用dubbo接口失败：apptService.getApptRecord()"+getAppResult.getErrorMsg());
        	throw new ServiceException(null, getAppResult.getErrorMsg());
		}
        logger.info("调用dubbo接口成功：apptService.getApptRecord()"+bookingId);
        ApptRecordQueryRsp rsp = getAppResult.getResult();
        List<ApptRecordInfo> apptRecordInfos = rsp.getApptRecords();
		if(apptRecordInfos==null || apptRecordInfos.size()==0) {
			throw new ServiceException(null, "根据预约单号查询预约记录为空！");
		} else if(apptRecordInfos.size() > 1) {
			throw new ServiceException(null, "根据预约单号查询出【"+apptRecordInfos.size()+"】条预约记录！");
		} 
		ApptRecordInfo apptRecordInfo = apptRecordInfos.get(0);
		
		// 设置预约单信息
		vOPrdBooking.setOrderId(bookingId);
		vOPrdBooking.setStatus(""+apptRecordInfo.getApptStatus());
		vOPrdBooking.setPrdKucunId(apptRecordInfo.getCardId());
		vOPrdBooking.setTreatDate(apptRecordInfo.getSchedleDate());
		vOPrdBooking.setPrdServiceId(apptRecordInfo.getHealthProductItemId());
		vOPrdBooking.setTreatTime(apptRecordInfo.getTimeSpanStartTime()+"～"+apptRecordInfo.getTimeSpanEndTime());
		vOPrdBooking.setRemark(apptRecordInfo.getApptRemark());
		
		// 设置就诊人信息
		PatientVisit patientVisit = apptRecordInfo.getPatientVisit();
		List<HyTreatmentPerson> visitList = new ArrayList<HyTreatmentPerson>();
		HyTreatmentPerson hyTreatmentPerson = new HyTreatmentPerson();
		hyTreatmentPerson.setVisitName(patientVisit.getName());
		hyTreatmentPerson.setVisitId(patientVisit.getId());
		hyTreatmentPerson.setVisitSex(patientVisit.getSexCode());
		hyTreatmentPerson.setVisitBrithday(patientVisit.getBirthday());
		hyTreatmentPerson.setVisitIdCardTypeCode(patientVisit.getIdCardTypeCode());
		hyTreatmentPerson.setVisitIdCardCode(patientVisit.getIdCardNo());
		hyTreatmentPerson.setVisitMobile(patientVisit.getMobile());
		visitList.add(hyTreatmentPerson);
		vOPrdBooking.setVisitList(visitList);
		
		// 设置诊所信息
		VOClcInfoApproval clinic = vOClcInfoApprovalMapper.selectByPrimaryKey(apptRecordInfo.getClinicId());
		vOPrdBooking.setClinicId(clinic.getId());
		vOPrdBooking.setClinicName(clinic.getClinicName());
		vOPrdBooking.setOpeningTime(clinic.getOpeningTime());
		vOPrdBooking.setCityCode(clinic.getCityCode());
		vOPrdBooking.setCity(clinic.getCity());
		vOPrdBooking.setDistrictCode(clinic.getDistrictCode());
		vOPrdBooking.setDistrict(clinic.getDistrictCode());
		vOPrdBooking.setParentAccountId(clinic.getParentAccountId());
		
		jr.setStatus(Status.SUCCESS);
		jr.setResult(vOPrdBooking);
		return jr;
	}
	
	private static String[] splitTime(String bookingTime) {
		String[] dateTime = StringUtils.split(bookingTime, " ");
		String[] date = StringUtils.split(dateTime[0], "-");
		String[] time = StringUtils.split(dateTime[1], ":");
		return (String[]) ArrayUtils.addAll(date, time);
	}

	@Override
	public JsonResponse<VOPrdKucunMUI> loadBookingMessage(String userId,String prdId, String kucunId, String cardNo,
			String cardPassword, String bookingId,String serviceItemId) {
		JsonResponse<VOPrdKucunMUI> response = new JsonResponse<VOPrdKucunMUI>();
		VOPrdKucunMUI prdMui = new VOPrdKucunMUI();
		VOPrdBooking booking = new VOPrdBooking();
		String flag = null;
		
		//判断是线上新增还是线下卡
		if(StringUtils.isBlank(kucunId)&&StringUtils.isBlank(bookingId)){
			//如果是线下卡第一次预约，必须输入卡号和密码
			if(StringUtils.isBlank(cardNo)||StringUtils.isBlank(cardPassword)){
				response.setStatus(Status.ERROR);
				response.setErrorMsg("线下卡卡号密码不能为空");
				return response;
			}
			flag="1";
		}else{
			flag="4";
		}
		if(StringUtils.isNotBlank(prdId)){
			//获取健康产品基本信息
			ProductInfo productInfo = new ProductInfo();
			productInfo.setId(prdId);
			JsonResponse<ProductInfo> produceInfoResp = productService.getProduceInfo(productInfo);
			logger.info("获取"+prdId+"产品接口结果信息："+produceInfoResp.toString());
			if(JsonResponse.Status.SUCCESS.getValue().equals(produceInfoResp.getStatus().getValue())){
				productInfo = produceInfoResp.getResult();
			}
			
			// 1、查询该产品对应的可选的【诊所总账户、城市、诊所】列表
			VOPrdKucun kucun_1 = new VOPrdKucun();
			kucun_1.setId(kucunId);
			kucun_1.setBuyerUserId(userId);
			kucun_1.setCouponId(prdId);
			//预约的bookingId不为空说明是编辑操作，查询预约的数据
			if(StringUtils.isNotBlank(bookingId)){
				JsonResponse<VOPrdBooking> bookingResp = findBookingMessage(bookingId);
				if(null!=bookingResp&&"SUCCESS".equals(bookingResp.getStatus().toString())&&null!=bookingResp.getResult()){
					prdMui.setBooking(bookingResp.getResult());//预约信息
					booking=bookingResp.getResult();
					kucunId = booking.getPrdKucunId();
					serviceItemId=booking.getPrdServiceId();
				}
			}
			
			// 数据验证
	        if(null!=booking.getStatus()&&!"1".equals(booking.getStatus()) && !"2".equals(booking.getStatus())
	        		&& !"8".equals(booking.getStatus())&& !"9".equals(booking.getStatus())) {
				String errMsg = "[warn]该预约记录非【待确认预约、待就诊】，不能再编辑";
				logger.error(errMsg);
				response.setStatus(Status.ERROR);
				response.setErrorCode(errMsg);
				return response;
			}
	        //在我的产品页面跳入进去说明已经使用过，不需要再输入卡号密码
			JsonResponse<VOPrdKucun> res1 = productMessageService.findKucunbyMsg(cardNo, cardPassword,
					kucunId, flag);
			if(null!=res1&&!"SUCCESS".equals(res1.getStatus().toString())){
				//如果错误返回错误信息
				response.setStatus(Status.ERROR);
				response.setErrorCode(res1.getErrorMsg());
				return response;
			}else if(null==res1){
				response.setStatus(Status.ERROR);
				response.setErrorMsg("系统繁忙");
				return response;
			}
			if(res1.getStatus().getValue().equals(JsonResponse.Status.SUCCESS.getValue()) && null != res1.getResult()){
				try {
					if(res1.getResult().getReceiveDate()==null){
						res1.getResult().setReceiveDate(new Date());
					}
					if(res1.getResult().getValidBeginDate()==null){
						res1.getResult().setValidBeginDate(new Date());
					}
					if(res1.getResult().getValidEndDate()==null){
						res1.getResult().setValidEndDate(new Date());
					}
					if(res1.getResult().getModifyDate()==null){
						res1.getResult().setModifyDate(new Date());
					}
					if(res1.getResult().getCreateDate()==null){
						res1.getResult().setCreateDate(new Date());
					}
					BeanUtils.copyProperties(prdMui, res1.getResult());
					
					
				} catch (Exception e) {
					logger.error("复制信息失败",e);
					response.setStatus(Status.ERROR);
					response.setErrorMsg("系统繁忙，请稍后");
					return response;
				} 
			}
			//查询健康产品服务的诊所相关信息
			JsonResponse<VOPrdAllClinics> vOPrdAllClinicsResp = productMessageService.findClinicsByProduct(prdMui.getCouponId(),userId,kucunId,bookingId,serviceItemId);
			logger.info("查询健康产品服务诊所相关信息 vOPrdAllClinicsResp："+vOPrdAllClinicsResp);
			if(vOPrdAllClinicsResp.getStatus().getValue().equals(JsonResponse.Status.SUCCESS.getValue()) && null != vOPrdAllClinicsResp.getResult()){
				//查询到数据不为空
				prdMui.setvOPrdAllClinics(vOPrdAllClinicsResp.getResult());
			}else{
				response.setErrorMsg(vOPrdAllClinicsResp.getErrorMsg());
				response.setErrorCode(vOPrdAllClinicsResp.getErrorCode()); 
			}
			
			//查询健康产品服务项目相关信息
			JsonResponse<List<VOPrdService>> serviceListResp = productMessageService.findPrdServiceList(prdMui.getCouponId());
			logger.info("查询健康产品服务项目相关信息 serviceListResp："+serviceListResp);
			if(serviceListResp.getStatus().getValue().equals(JsonResponse.Status.SUCCESS.getValue()) && null != serviceListResp.getResult()){
				//查询到数据不为空
				prdMui.setPrdServiceList(serviceListResp.getResult());
			}else{
				response.setStatus(Status.ERROR);
				response.setErrorMsg(serviceListResp.getErrorMsg());
				response.setErrorCode(serviceListResp.getErrorCode());
			}
			if(StringUtils.isNotBlank(prdMui.getVisitId())){
				HyTreatmentPerson hyTreatmentPerson = hyTreatmentPersonMapper.selectByPrimaryKey(prdMui.getVisitId());
				prdMui.setHyTreatmentPerson(hyTreatmentPerson);
				//如果不是激活产品，并且也是单人使用产品
			}else if("1".equals(productInfo.getIsNeedManyUse())){
				//查询有没有预约记录
				com.pinganwj.clinic.api.domain.JsonResponse<List<String>> visitIds = productApptApi.getVisitIds(kucunId, userId, "1,2,3,4,5,8,9" ,bookingId);
				if(null!=visitIds&&null!=visitIds.getResult()&&visitIds.getResult().size()>0){
					HyTreatmentPerson hyTreatmentPerson = hyTreatmentPersonMapper.selectByPrimaryKey(visitIds.getResult().get(0));
					prdMui.setHyTreatmentPerson(hyTreatmentPerson);
				}
			}
			
			response.setResult(prdMui);
		}else{
			response.setStatus(Status.ERROR);
			response.setErrorMsg("系统繁忙，请稍后");
			return response;
		}
		return response;
	}

	@Override
	public JsonResponse<Void> submitOrderForGateWay(VOPrdBooking booking) throws ParseException {
//		String treatDate = booking.getTreatDate();
//		String treatTimeStart = booking.getTreatTimeStart();
		JsonResponse<Void> jr = new JsonResponse<Void>();
		logger.info("预约信息："+JSONObject.toJSON(booking).toString());
//		try {
//			Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(treatDate+" "+treatTimeStart+":00");
//			JsonResponse<HyPrdConfig> prdConfigresp = hyPrdConfigService.getPrdConfig("CREATE_TIME_LIMIT", booking.getClinicId());
//			int hours =0;
//			if(prdConfigresp!=null&&null!=prdConfigresp.getResult()&&StringUtils.isNoneBlank(prdConfigresp.getResult().getConfigData())){
//				try {
//					hours = Integer.valueOf(prdConfigresp.getResult().getConfigData());
//				} catch (NumberFormatException e) {
//					logger.warn("序列化配置日期失败：clinicId"+booking.getClinicId()+"配置的时间："+prdConfigresp.getResult().getConfigData());
//					e.printStackTrace();
//				}
//			}
//			if(date.before(DateUtils.addHour(new Date(),hours))){
//				
//				jr.setStatus(Status.ERROR);
//				if(hours == 0){
//					jr.setErrorMsg("预约"+booking.getClinicName()+"的健康产品就诊时间不得早于当前时间");
//				}else{
//					jr.setErrorMsg("当前时间必须早于预约"+booking.getClinicName()+"的健康产品服务时间的前："+hours+"小时");
//				}
//				return jr;
//			}
//		} catch (ParseException e) {
//			logger.warn("序列化时间失败"+treatDate+" "+treatTimeStart);
//			jr.setErrorMsg("查询诊所可就诊时间失败");
//			jr.setStatus(Status.ERROR);
//			return jr;
//			
//		}
		 VoHyUserInfo vohyUserInfo = hyUserInfoMapper.getVoHyUserInfoByUserId(Long.valueOf(booking.getUserId()));
		logger.info("预约健康产品的用户信息vohyUserInfo："+vohyUserInfo);
		 if(null!=vohyUserInfo){
			//设置用户相关信息
			booking.setUserId(booking.getUserId());
			booking.setRealName(vohyUserInfo.getRealName());
			booking.setMobile(vohyUserInfo.getMobile());
		}else{
			jr.setErrorMsg("查询用户信息失败");
			jr.setStatus(Status.ERROR);
			return jr;
		}
		//不是密码领取就是卡号预约
		if(StringUtils.isNotBlank(booking.getOrderId())){
			booking.setEditOldVisitCnt(1);
			booking.setFlag("2");
		}else {
			booking.setEditOldVisitCnt(0);
			if(StringUtils.isBlank(booking.getCardPassword())){
				booking.setFlag("4");
			}else{
				booking.setFlag("1");
			}
		}
		if(!"0".equals(booking.getUseFrequence())){
			logger.info("UseFrequence:"+booking.getUseFrequence());
			booking.setUseFrequence("1");
		}

		logger.info("ServiceId--------"+booking.getPrdServiceId());
		logger.info("ServiceName--------"+booking.getServiceName());
		jr =submitOrder(booking);
//		if(null!=jr&&Status.SUCCESS.equals(jr.getResult())){
			//查询诊所信息
			senWxMessage(booking);
//		}
		logger.info("健康产品预约结束resp: "+jr.toString());
		return jr;
	}

	/**
	 * 预约成功给微信推送消息
	 * @param booking
	 */
	private void senWxMessage(VOPrdBooking booking) {
		//查询诊所名称
		VOClcInfoApproval clcInfoApproval = vOClcInfoApprovalMapper.selectByPrimaryKey(booking.getClinicId());
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("clinicName",clcInfoApproval.getClinicName());
		//查询诊所地址
		AddressInfoApprovalExample example2 = new AddressInfoApprovalExample();
		AddressInfoApprovalExample.Criteria criteria2 = example2.createCriteria();
		criteria2.andForeignIdEqualTo(booking.getClinicId());
		List<AddressInfoApproval> list = addressInfoApprovalMapper.selectByExample(example2);
		
		map.put("addressName", list.get(0).getAddress());
		//查询openid
		HyFrontParnterExample example = new HyFrontParnterExample();
		HyFrontParnterExample.Criteria criteria = example.createCriteria();
		criteria.andMemberidEqualTo(booking.getUserId());
		List<HyFrontParnter> parnters = hyFrontParnterMapper.selectByExample(example);
		if (CollectionUtils.isEmpty(parnters)) {
			logger.error("为查询到用户绑定的微信号 userId："+booking.getUserId());
		}
		String openId = parnters.get(0).getPartneridNotEncrypted();
		map.put("apptTime", booking.getTreatDate()+"("+booking.getTreatTime()+")");
		map.put("visitName", booking.getVisitList().get(0).getVisitName());
		map.put("productItemName", booking.getServiceName());
		map.put("productName", booking.getCouponName());
		MessageResult message = null;
		try {
			if(StringUtils.isNotBlank(openId)){
				map.put("openId", openId);
				message = weiXinTempApi.sendAddRegMessage(map);
				logger.info("微信发送消息的参数对象 map："+map);
			}
		} catch (Exception e) {
			logger.error("微信发送消息失败",e);
		}
		logger.info("微信发送的消息："+message);
	}

	@Override
	public JsonResponse<HyTreatmentPerson> findBeforeVisitByCard(String cardId,String userId) {
		// 返回值
		JsonResponse<HyTreatmentPerson> res = new JsonResponse<HyTreatmentPerson>();
		HyTreatmentPerson hyTreatmentPerson = new HyTreatmentPerson();
		
		// 查询该卡预约订单记录
		ApptRecordQueryReq req5 = new ApptRecordQueryReq();
		req5.setUserId(userId);
		req5.setCardId(cardId);
		req5.setApptStatus("1,2,3,4,5,8,9");
		logger.info("ProductOrderService.findVisitByCard开始" + cardId);
		com.pinganwj.clinic.api.domain.JsonResponse<ApptRecordQueryRsp> queryResult = apptService.getApptRecord(req5);
		if (!"SUCCESS".equals(queryResult.getStatus().toString())) {
			logger.error("调用dubbo接口失败：apptService.getApptRecord()");
			throw new ServiceException(null, queryResult.getErrorMsg());
		}
		ApptRecordQueryRsp rsp = queryResult.getResult();
		logger.info("ProductOrderService.findVisitByCard成功");
		
		// 获取上一次预约的就诊人信息
		List<ApptRecordInfo> records = rsp.getApptRecords();
		if (records != null && records.size() > 0) {
			PatientVisit patientVisit = records.get(0).getPatientVisit();
			hyTreatmentPerson.setVisitId(patientVisit.getId());
			hyTreatmentPerson.setVisitIdCardTypeCode(patientVisit.getIdCardTypeCode());
			hyTreatmentPerson.setVisitIdCardCode(patientVisit.getIdCardNo());
			hyTreatmentPerson.setVisitMobile(patientVisit.getMobile());
			hyTreatmentPerson.setVisitSex(patientVisit.getSexCode());
			hyTreatmentPerson.setVisitBrithday(patientVisit.getBirthday());
		}
		res.setStatus(Status.SUCCESS);
		res.setResult(hyTreatmentPerson);
		return res;
	}

	@Override
	public JsonResponse<String> findServiceTypeExplain(String prdId,String serviceTypeId) {
		// 返回值
		JsonResponse<String> res = new JsonResponse<String>();
		
		// 查询产品
		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		
		// 如果为一次性产品
		if("0".equals(prdInfo.getUseFrequence())){
			res.setStatus(Status.SUCCESS);
			return res;
		}
		PrdTypeService prdTypeService = prdTypeServiceMapper.selectByPrimaryKey(serviceTypeId);
		if(StringUtils.isNotBlank(prdTypeService.getInstruct())){
			res.setResult(prdTypeService.getInstruct());
		}
		res.setStatus(Status.SUCCESS);
		return res;
	}
	
	/**
	 * 更换手机号发送手机短信
	 * 
	 * @param request
	 * @param reponse
	 * @return
	 */
	@Override
	public JsonResponse<String> sendMessage(String mobile, String smsTempId,String ipAddress) {
		// 手机号不可为空
		if (StringUtils.isBlank(mobile)) {
			throw new ServiceException("A00001", "手机号不可为空!");
		}

		// 返回结果
		JsonResponse<String> result = new JsonResponse<String>();
		String uuid = UUID.randomUUID().toString();

		// 生成随机码
		String randomStr = RandomUtil.random(6);

		// 短信发送
		Map<String, String> map = new HashMap<String, String>();
		map.put("validateCode", randomStr);
		boolean msgResult = SmsUtils.sendAllMsg(smsServer, mobile, smsTempId, ipAddress, map);

		// 短信发送成功
		if (msgResult) {
			result.setStatus(Status.SUCCESS);
			result.setResult(uuid);
			// 缓存10分钟
			commonJedis.addObject(uuid, randomStr, 600);
		} else {
			throw new ServiceException("A00001", "短信发送失败!");
		}
		return result;
	}

	@Override
	public JsonResponse<Boolean> checkMessage(String mobile, String uuidKey,
			String checkNum) {
		// 返回结果
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();

		if (StringUtils.isBlank(mobile)) {
			throw new ServiceException("A00001", "手机号不可为空!");
		}
		// 用户没有点击获取验证码按钮
		if (StringUtils.isBlank(uuidKey)) {
			throw new ServiceException("A00001", "请点击获【获取验证码】按钮,获取手机号验证码!");
		}
		// 原手机号验证码不可为空
		if (StringUtils.isBlank(checkNum)) {
			throw new ServiceException("A00001", "手机号验证码不可为空!");
		}	
		// 手机号验证码超时
		if (commonJedis.getObject(uuidKey) == null) {
			throw new ServiceException("A00001", "手机号验证码已超时,请重新获取!");
		}
		// 初始手机验证码验证
		if (!commonJedis.getObject(uuidKey).equals(checkNum)) {
			throw new ServiceException("A00001", "手机号验证码不正确!");
		}	
		result.setStatus(Status.SUCCESS);
		return result;
	}

	@Override
	public JsonResponse<Boolean> activateProduct(HyTreatmentPerson person,String userId,String prdId,String kucunId,String activateCode) {
		// 返回结果
		JsonResponse<Boolean> activateResult = new JsonResponse<Boolean>();
		
		// 激活码验证
		PrdKucun prdKucun = prdKucunMapper.selectByPrimaryKey(kucunId);
		if(!activateCode.equals(prdKucun.getCheckValue())){
			throw new ServiceException("A00001", "激活码不正确,请重新输入!");
		}
		
		// 插入就诊人
		person.setDelFlag("0");
		person.setCreateDate(new Date());
		person.setCreateUser(userId);
		int insertResult = hyTreatmentPersonMapper.insertSelective(person);
		if(insertResult!=1){
			throw new ServiceException("A00001", "系统异常，请稍后重试!");
		}
		
		// 激活
		JsonResponse<String> result = recivePrdFromCodeService.activeMyProduct(
				userId, prdId, kucunId, person.getVisitId(), null, null, "1");
		if (!"SUCCESS".equals(result.getStatus().toString())) {
			throw new ServiceException(result.getErrorCode(), result.getErrorMsg());
		}	
		activateResult.setStatus(Status.SUCCESS);
		return activateResult;
	}

	@Override
	public JsonResponse<Boolean> receiveProduct(String kucunId,String userId) {
		// 返回结果
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		
		// 更新产品领取字段
		PrdKucun prdKucun = prdKucunMapper.selectByPrimaryKey(kucunId);
		prdKucun.setTakenStatus("1");
		prdKucun.setBuyerUserId(userId);
		prdKucun.setModifyDate(new Date());
		prdKucunMapper.updateByPrimaryKeySelective(prdKucun);
		result.setStatus(Status.SUCCESS);
		return result;
	}

	@Override
	public JsonResponse<Boolean> directActivateProduct(String prdId,String kucunId, String userId) {
		// 返回结果
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		PrdInfo prdInfo = prdInfoMapper.selectByPrimaryKey(prdId);
		PrdKucun prdKucun = prdKucunMapper.selectByPrimaryKey(kucunId);
		prdKucun.setBuyerUserId(userId);
		prdKucun.setModifyDate(new Date());
		// 设置有效期
		Date date = new Date();
		prdKucun.setValidBeginDate(date);
		if(StringUtils.isNoneBlank(prdInfo.getValidValueUnit())&&StringUtils.isNoneBlank(prdInfo.getValidValue())){
			if("0".equals(prdInfo.getValidValueUnit())){
				prdKucun.setValidEndDate(DateUtils.addYear(date, Integer.parseInt(prdInfo.getValidValue())));
			}else if("1".equals(prdInfo.getValidValueUnit())){
				prdKucun.setValidEndDate(DateUtils.addMonth(date, Integer.parseInt(prdInfo.getValidValue())));
			}else if("2".equals(prdInfo.getValidValueUnit())){
				prdKucun.setValidEndDate(DateUtils.addDay(date, Integer.parseInt(prdInfo.getValidValue())));
			}else{
				prdKucun.setValidEndDate(DateUtils.addHour(date, Integer.parseInt(prdInfo.getValidValue())));
			}
		}
		prdKucunMapper.updateByPrimaryKeySelective(prdKucun);
		result.setStatus(Status.SUCCESS);
		return result;
	}
}
