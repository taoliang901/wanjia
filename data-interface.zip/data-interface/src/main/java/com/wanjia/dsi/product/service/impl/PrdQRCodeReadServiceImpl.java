package com.wanjia.dsi.product.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esotericsoftware.minlog.Log;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.product.dao.mapper.PrdQRCodeMapper;
import com.wanjia.dsi.product.model.PrdQRCode;
import com.wanjia.dsi.product.service.PrdQRCodeReadService;

/**
 * This element is automatically generated on 16-9-21 下午4:20, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdQRCodeReadServiceImpl implements PrdQRCodeReadService {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired
    private PrdQRCodeMapper prdQRCodeMapper;

	@Override
	public JsonResponse<PrdQRCode> findById(String id) {
		JsonResponse<PrdQRCode> jr = new JsonResponse<PrdQRCode>();
		try{
			PrdQRCode prdQRCode = prdQRCodeMapper.findById(id);
			jr.setResult(prdQRCode);
			jr.setStatus(Status.SUCCESS);
		}catch(Exception e){
			jr.setStatus(Status.ERROR);
			logger.error("findById PrdQRCode ", e);
		}
		return jr;
		
	}

	@Override
	public JsonResponse<List<PrdQRCode>> findByEntity(PrdQRCode prdQRCode) {
		JsonResponse<List<PrdQRCode>> jr = new JsonResponse<List<PrdQRCode>>();
		try{
			List<PrdQRCode> prdQRCodeList = prdQRCodeMapper.findByEntity(prdQRCode);
			jr.setResult(prdQRCodeList);
			jr.setStatus(Status.SUCCESS);
		}catch(Exception e){
			jr.setStatus(Status.ERROR);
			logger.error("findByEntity PrdQRCode ", e);
		}
		return jr;
		
	}

    
}