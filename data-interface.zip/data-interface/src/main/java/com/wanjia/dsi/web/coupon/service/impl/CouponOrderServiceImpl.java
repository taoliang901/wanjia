package com.wanjia.dsi.web.coupon.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.web.coupon.dao.mapper.ProduceCouponOrderMapper;
import com.wanjia.dsi.web.coupon.model.ClinicHeadquartersApproval;
import com.wanjia.dsi.web.coupon.model.CouponOrder;
import com.wanjia.dsi.web.coupon.model.CouponOrderInfo;
import com.wanjia.dsi.web.coupon.model.CouponOrderVisit;
import com.wanjia.dsi.web.coupon.service.CouponOrderService;

/**
 * This element is automatically generated on 16-6-13 上午11:37, do not modify.
 * <br>
 * Service implementation class
 */
@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class CouponOrderServiceImpl extends BaseServiceImpl implements CouponOrderService {

	@Autowired
	private ProduceCouponOrderMapper couponOrderMapper;

	public JsonResponse<PageInfo<CouponOrderInfo>> getCouponOrderList(Map<String, Object> map) {

		JsonResponse<PageInfo<CouponOrderInfo>> respose = new JsonResponse<PageInfo<CouponOrderInfo>>();
		try {
			PageHelper.startPage(Integer.parseInt((String) map.get("pageNo")), Integer.parseInt((String) map.get("pageSize")));// 设置分页页号和页码

			List<CouponOrderInfo> list = this.couponOrderMapper.getCouponOrderList(map);

			if (list == null) {
				return null;
			}
			for (CouponOrderInfo couponOrderInfo : list) {
				StringBuffer sb = new StringBuffer("");
				List<CouponOrderVisit> visitorsList = couponOrderMapper.findCouponOrderVisitList("order_id", couponOrderInfo.getOrderId());
				if (visitorsList != null && visitorsList.size() > 0) {
					for (CouponOrderVisit couponOrderVisit : visitorsList) {
						sb.append(couponOrderVisit.getVisitName() + ",");
					}
					couponOrderInfo.setVisitors(sb.toString().substring(0, sb.toString().length() - 1));
				}

			}

			PageInfo<CouponOrderInfo> page = new PageInfo<CouponOrderInfo>(list);// 获得分页信息
			respose.setResult(page);

		} catch (Exception e) {
			this.error(e);
			respose.setStatus(Status.ERROR);
		}

		return respose;

	}

	@Override
	public JsonResponse<Boolean> updateCouponStatus(CouponOrder model, String[] orderId_array) {

		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		boolean isSuccess = false;
		try {
			for (String ordId : orderId_array) {
				model.setOrderId(ordId);
				update(model);
			}
			isSuccess = true;
			result.setResult(isSuccess);
		} catch (Exception e) {
			this.error(e);
			result.setStatus(Status.ERROR);
			result.setResult(isSuccess);
		}

		return result;

	}

	public void update(CouponOrder model) {

		model.setModifyDate(new Date());
		couponOrderMapper.update(model);
	}

	public CouponOrderServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public JsonResponse<CouponOrderInfo> getCardInfoByCardNo(Map<String, Object> map) {
		JsonResponse<CouponOrderInfo> response = new JsonResponse<CouponOrderInfo>();
		try {
			List<CouponOrderInfo> list = couponOrderMapper.getCouponOrderList(map);
			CouponOrderInfo couponOrderInfo = null;
			if (list != null && list.size() > 0) {
				couponOrderInfo = list.get(0);
				if (StringUtils.isNotEmpty(couponOrderInfo.getAccountType()) && couponOrderInfo.getAccountType().equals("1")) {
					if (StringUtils.isNotEmpty(couponOrderInfo.getParentAccountId())) {
						// ClinicInfoApproval clinicInfoApproval =
						// clinicInfoApprovalService.findOneByProperty("CLINIC_REGISTER_ID",
						// couponOrderInfo.getParentAccountId());
						ClinicHeadquartersApproval param_model = new ClinicHeadquartersApproval();
						param_model.setClinicRegisterId(couponOrderInfo.getParentAccountId());
						param_model.setDelFlag("0");
						param_model = couponOrderMapper.findClinicHeadquartersApproval(param_model);
						if (param_model != null) {
							// 连锁品牌
							couponOrderInfo.setParentAccountName(param_model.getEnterpriseFullName());

						}

					}
				}

				List<CouponOrderVisit> visitorsList = couponOrderMapper.findCouponOrderVisitList("order_id", couponOrderInfo.getOrderId());
				couponOrderInfo.setOrderVisitList(visitorsList);
				response.setResult(couponOrderInfo);
			}
		} catch (Exception e) {
			this.error(e);
			response.setStatus(Status.ERROR);
		}

		return response;

	}

}