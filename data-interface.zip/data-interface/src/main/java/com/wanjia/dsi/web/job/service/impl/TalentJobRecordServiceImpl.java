package com.wanjia.dsi.web.job.service.impl;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.job.dao.mapper.TalentJobRecordMapper;
import com.wanjia.dsi.web.job.model.TalentJobRecord;
import com.wanjia.dsi.web.job.service.TalentJobRecordService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class TalentJobRecordServiceImpl extends BaseServiceImpl implements TalentJobRecordService {

	private Logger logger = Logger.getLogger(TalentJobRecordServiceImpl.class);

	@Autowired
	private TalentJobRecordMapper talentJobRecordMapper;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public JsonResponse<List<TalentJobRecord>> getJobRecordList(String requestId, String userId,String[] jobIdList) {
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getJobRecordList method start...");
		
		JsonResponse<List<TalentJobRecord>> result = new JsonResponse<List<TalentJobRecord>>();
		try {
			if(!StringUtils.isBlank(userId) && jobIdList != null && jobIdList.length > 0){
				Map paramMap=new HashMap();
				paramMap.put("userId",userId);
				paramMap.put("jobIdList",jobIdList);
				List<TalentJobRecord> jobHotList = talentJobRecordMapper.selectByUserIdAndJobId(paramMap);
				result.setResult(jobHotList);
			}
		} catch (Exception e) {
			logger.info("查询热门岗位失败:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":getJobRecordList method end...");
		return result;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public JsonResponse insertTalentJobRecord(String requestId, TalentJobRecord talentJobRecord) {
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":insertTalentJobRecord method start...");
		
		JsonResponse result = new JsonResponse();
		try {
			talentJobRecord.setId(UUID.randomUUID().toString());
			talentJobRecord.setCreateDate(new Date());
			talentJobRecord.setModifyDate(new Date());
			talentJobRecord.setStatus("0");
			talentJobRecord.setDelFlag("0");
			talentJobRecordMapper.insertSelective(talentJobRecord);
		} catch (Exception e) {
			logger.info("查询热门岗位失败:" + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		logger.info("requestId:" + requestId + "," + this.getClass().getName() + ":insertTalentJobRecord method end...");
		return result;
	}

	
	
}
