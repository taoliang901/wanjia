package com.wanjia.dsi.base.mongodb.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.mongodb.WriteResult;
import com.wanjia.dsi.base.mongodb.MongoDbRepository;
import com.wanjia.dsi.base.mongodb.Pagination;

/**
 * Mongdb 通用api
 * 
 * @author CHENKANG560
 *
 * @param <T>
 */
public class MongoDbRepositoryImpl<T> implements MongoDbRepository<T> {

	@Resource
	private MongoTemplate mongoTemplate;

	@Override
	public List<T> findAll(Class<T> clazz) {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(clazz);
	}

	@Override
	public void insert(T object, Class<T> clazz) {
		// TODO Auto-generated method stub
		mongoTemplate.insert(object);

	}

	@Override
	public boolean exists(Query query, Class<T> clazz) {
		// TODO Auto-generated method stub
		return mongoTemplate.exists(query, clazz);
	}

	@Override
	public T findById(String id, Class<T> clazz) {
		// TODO Auto-generated method stub
		return mongoTemplate.findOne(new Query(Criteria.where("_id").is(id)), clazz);
	}

	@Override
	public WriteResult updateObject(String id, String name, Class<T> clazz) {
		// TODO Auto-generated method stub
		return mongoTemplate.updateFirst(new Query(Criteria.where("_id").is(id)), Update.update("name", name), clazz);
	}

	@Override
	public void deleteById(String id, Class<T> clazz) {
		mongoTemplate.remove(new Query(Criteria.where("_id").is(id)), clazz);

	}

	@Override
	public void createCollection(Class<T> clazz) {
		if (!mongoTemplate.collectionExists(clazz)) {
			mongoTemplate.createCollection(clazz);
		}

	}

	@Override
	public void dropCollection(Class<T> clazz) {
		if (mongoTemplate.collectionExists(clazz)) {
			mongoTemplate.dropCollection(clazz);
		}

	}

	// @Override
	public Pagination<T> getPage(int pageNo, int pageSize, Query query, Sort sort, Class<T> clazz) {

		if (sort != null) {
			query.with(sort);
		}
		long totalCount = this.mongoTemplate.count(query, clazz);
		Pagination<T> page = new Pagination<T>(pageNo, pageSize, totalCount);
		query.skip(page.getFirstResult());// skip相当于从那条记录开始
		query.limit(pageSize);// 从skip开始,取多少条记录
		List<T> datas = this.find(query, clazz);
		page.setDatas(datas);
		return page;
	}

	@Override
	public List<T> find(Query query, Class<T> clazz) {
		// TODO Auto-generated method stub
		return mongoTemplate.find(query, clazz);
	}

	@Override
	public T findById(String id, Class<T> clazz, String collectionName) {
		// TODO Auto-generated method stub
		return mongoTemplate.findById(id, clazz, collectionName);
	}

	@Override
	public void updateFirst(Query query, Class<T> clazz, Update update) {
		mongoTemplate.updateFirst(query, update, clazz);

	}

	@Override
	public T findAndRemove(Query query, Class<T> clazz) {
		// TODO Auto-generated method stub
		return this.mongoTemplate.findAndRemove(query, clazz);
	}

	@Override
	public T findAndModify(Query query, Update update, Class<T> clazz) {
		// TODO Auto-generated method stub
		return this.mongoTemplate.findAndModify(query, update, clazz);
	}

	@Override
	public void deleteBatch(Query query, Class<T> clazz) {
		// TODO Auto-generated method stub
		mongoTemplate.remove(query, clazz);
	}

	@Override
	public long findCount(Query query, Class<T> clazz) {
		// TODO Auto-generated method stub
		return this.mongoTemplate.count(query, clazz);
	}

	@Override
	public void updateMany(Query query, Update update, Class<T> clazz) {
		// TODO Auto-generated method stub
		this.mongoTemplate.updateMulti(query, update, clazz);
	}
	
	@Override
	public void insertBatch(List<T> list, Class<T> clazz) {
		this.mongoTemplate.insert(list, clazz);
	}
}
