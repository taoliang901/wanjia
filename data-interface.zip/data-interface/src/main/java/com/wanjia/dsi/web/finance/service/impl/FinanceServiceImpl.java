package com.wanjia.dsi.web.finance.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.Assert;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.web.finance.dao.mapper.FinanceMapper;
import com.wanjia.dsi.web.finance.service.FinanceService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class FinanceServiceImpl extends BaseServiceImpl implements FinanceService {

	@Autowired
	private FinanceMapper financeMapper;

	
	@Autowired
	private CommonJedis commonJedis;

	@Value("#{jedisConfig['expirationTime']}")
	private int expirationTime;
	
	
	
	@Override
	public JsonResponse<List<Map<String, Object>>> getBankList(String requestId) {
		// TODO Auto-generated method stub
		JsonResponse<List<Map<String, Object>>> result = new JsonResponse<List<Map<String, Object>>>();
		List<Map<String, Object>>  list = new ArrayList<Map<String, Object>>();
		try {
			//缓存是否有
			if (!commonJedis.exists(Consts.GET_BANK_LIST)) {
				//no 从数据库去
				this.pringLog("dictCode.not exists");
				list = financeMapper.getBankList();
				commonJedis.addObject(Consts.GET_BANK_LIST, financeMapper.getBankList(), expirationTime);
			} else {
				//从redis取
				this.pringLog("dictCode exists");
				list = (List<Map<String, Object>>) commonJedis.getObject(Consts.GET_BANK_LIST);

			}
			
			
			result.setResult(list);
		} catch (Exception e) {
			// Log.error(e.getMessage());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<List<Map<String, Object>>> getBankBranchList(String requestId,String bankDBID) {
		JsonResponse<List<Map<String, Object>>> result = new JsonResponse<List<Map<String, Object>>>();
		Assert.isNotEmpty(bankDBID);
		try {

			if (StringUtils.isNotBlank(bankDBID)) {
				//返回结果
				result.setResult(financeMapper.getBankBranchList(bankDBID));
			}

		} catch (Exception e) {
			// Log.error(e.getMessage());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;

	}

}
