package com.wanjia.dsi.web.home.controller;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.common.annotation.Endpoint;
import com.wanjia.dsi.common.annotation.Name;
import com.wanjia.dsi.web.home.model.FlexGridQueryResult;
import com.wanjia.dsi.web.home.model.InterfaceInfo;


@Controller
public class HomeController {

	@Autowired
	private RequestMappingHandlerMapping handlerMapping;

	@RequestMapping("/home/endpoints.do")
	public ModelAndView index(Model model) {
		Map<RequestMappingInfo, HandlerMethod> handlerMethods = this.handlerMapping.getHandlerMethods();
		ModelAndView modelAndView = new ModelAndView("handlerMethods", "endpoints", this.handlerMapping.getHandlerMethods());
		
		int EndpointCount = 0;	//用于统计被Endpoint注释的接口的数量	
		if (CollectionUtils.size(handlerMethods) > 0) {
		    
			List<InterfaceInfo> infos = new ArrayList<InterfaceInfo>();
			
			Set<RequestMappingInfo> keyset = handlerMethods.keySet();
			InterfaceInfo interfaceInfoinfo = null;
			
			for (RequestMappingInfo requestMappingInfo : keyset) {
				String URL = requestMappingInfo.getPatternsCondition().getPatterns().toString();
				URL = URL.replace("[", "");
				URL = URL.replace("]", "");
				
				HandlerMethod handlerMethod = handlerMethods.get(requestMappingInfo);
				MethodParameter[] methods = handlerMethod.getMethodParameters();		
				interfaceInfoinfo = new InterfaceInfo();
				interfaceInfoinfo.setInterfaceUrl("/"+"data-interface" + URL);
				
				for(int i=0;i<methods.length;i++){					
					MethodParameter methodParameter = methods[i];
				
				//取参数名称
				String[] ParamsName = new String[100];	
				Annotation[][] annotations = methodParameter.getMethod().getParameterAnnotations();//方法中获取所有参数，第一维是参数，第二维是参数的注解
		        for (int n = 0; n < annotations.length; n++) {
		            for (int j = 0; j < annotations[n].length; j++) {
		            	if (annotations[n][j] instanceof RequestParam) {//获取被RequestParam注解注释的参数信息
		                RequestParam requestParam = (RequestParam) annotations[n][j];
		                ParamsName[n]=requestParam.value().toString()+"(";		                
		                if(requestParam.required()){//判断是否是必传参数
		                	ParamsName[n] = ParamsName[n]+"★";
		                	}
		            	}
		            	if (annotations[n][j] instanceof Name){//获取被Name注解注释的参数信息
		            		Name name = (Name) annotations[n][j];
		            		ParamsName[n] = ParamsName[n]+name.value().toString()+")";
                        }
                	}
		        }				
						
		        Class<?>[] ParamTypes = methodParameter.getMethod().getParameterTypes();//取参数类型             
		        for (int n = 0 ; n < annotations.length ; n++) {
		        	if(ParamTypes[n].toString().indexOf("Http") != -1){
		        		ParamTypes[n] = null;		        		
		        	}
		        }
		        
		        StringBuffer interfaceParams = new StringBuffer("");
		        StringBuffer interfaceRequiredParams = new StringBuffer(""); 

		        for (int n = 0 ; n < annotations.length ; n++) {//将参数名称和参数类型合并
					if(ParamTypes[n] != null){//拼接参数名称和参数类型，每一行显示一个参数
						if(n == 0){
							interfaceParams.append(ParamTypes[n].getSimpleName().toString()+" ").append(ParamsName[n]);	
						}else{
							interfaceParams.append("<br>");
							for(int a=0;a<19;a++){//从第二行参数开始，输出19个空格和第一行参数对齐
								interfaceParams.append("&nbsp;");
							}							
							interfaceParams.append(ParamTypes[n].getSimpleName().toString()+" ").append(ParamsName[n]);	
						}						
					}	
				}
				interfaceInfoinfo.setInterfaceParams(interfaceParams.toString());
				if(interfaceRequiredParams.toString().length() > 0){
					interfaceInfoinfo.setInterfaceRequiredParams(interfaceRequiredParams.toString().substring(0, interfaceRequiredParams.toString().length()-2));				
				}				
				}
				
				if(handlerMethod.getMethodAnnotation(Deprecated.class) != null){//判断该接口是否被Deprecated注释
					interfaceInfoinfo.setInterfaceDeprecated(true);
				}
				
				if (handlerMethod.getMethodAnnotation(Endpoint.class) != null) { // 若该接口被Endpoint注释，则EndpointFlag赋值为1
					interfaceInfoinfo.setInterfaceEndpoint(true);
					interfaceInfoinfo.setInterfaceName(handlerMethod.getMethodAnnotation(Endpoint.class).description().toString());
					EndpointCount++;
				}
				infos.add(interfaceInfoinfo);
			}
			
			modelAndView.addObject("infos", infos);
		}		
		modelAndView.addObject("EndpointCount",EndpointCount);

		return modelAndView;
		
		}
	
	@RequestMapping("/home/getInterfaceInfo.do")
	@ResponseBody
	public JsonResponse<List<InterfaceInfo>> getInterfaceInfo(){
		
        JsonResponse<List<InterfaceInfo>> jr = new JsonResponse<List<InterfaceInfo>>();
        FlexGridQueryResult<InterfaceInfo> queryResult= new FlexGridQueryResult<InterfaceInfo>();
        Map<RequestMappingInfo, HandlerMethod> handlerMethods = this.handlerMapping.getHandlerMethods();
        int EndpointCount = 0;	//用于统计被Endpoint注释的接口的数量	
        List<InterfaceInfo> infos = new ArrayList<InterfaceInfo>();
        if (CollectionUtils.size(handlerMethods) > 0) {

           

            Set<RequestMappingInfo> keyset = handlerMethods.keySet();
            InterfaceInfo interfaceInfoinfo = null;

            for (RequestMappingInfo requestMappingInfo : keyset) {
				String URL = requestMappingInfo.getPatternsCondition().getPatterns().toString();
				URL = URL.replace("[", "");
				URL = URL.replace("]", "");
				
				HandlerMethod handlerMethod = handlerMethods.get(requestMappingInfo);
				MethodParameter[] methods = handlerMethod.getMethodParameters();		
				interfaceInfoinfo = new InterfaceInfo();
				interfaceInfoinfo.setInterfaceUrl("/"+"data-interface" + URL);
				
				if (handlerMethod.getMethodAnnotation(Endpoint.class) != null) { // 若该接口被Endpoint注释，则EndpointFlag赋值为1
					interfaceInfoinfo.setInterfaceEndpoint(true);
					interfaceInfoinfo.setInterfaceName(handlerMethod.getMethodAnnotation(Endpoint.class).description().toString());
					EndpointCount++;
				}else continue;
				
				
				for(int i=0;i<methods.length;i++){					
					MethodParameter methodParameter = methods[i];
				
				//取参数名称
				String[] ParamsName = new String[100];	
				Annotation[][] annotations = methodParameter.getMethod().getParameterAnnotations();//方法中获取所有参数，第一维是参数，第二维是参数的注解
		        for (int n = 0; n < annotations.length; n++) {
		            for (int j = 0; j < annotations[n].length; j++) {
		            	if (annotations[n][j] instanceof RequestParam) {//获取被RequestParam注解注释的参数信息
		                RequestParam requestParam = (RequestParam) annotations[n][j];
		                ParamsName[n]=requestParam.value().toString()+"(";		                
		                if(requestParam.required()){//判断是否是必传参数
		                	ParamsName[n] = ParamsName[n]+"★";
		                	}
		            	}
		            	if (annotations[n][j] instanceof Name){//获取被Name注解注释的参数信息
		            		Name name = (Name) annotations[n][j];
		            		ParamsName[n] = ParamsName[n]+name.value().toString()+")";
		            	}
	            	}
		        }				
						
		        Class<?>[] ParamTypes = methodParameter.getMethod().getParameterTypes();//取参数类型             
		        for (int n = 0 ; n < annotations.length ; n++) {
		        	if(ParamTypes[n].toString().indexOf("Http") != -1){//若参数类型为HttpServletResponse或HttpServletReques赋值空，不输出
		        		ParamTypes[n] = null;		        		
                    }
                }

                List<String> interfaceParam = new ArrayList<String>();
                
		        for (int n = 0 ; n < annotations.length ; n++) {//将参数名称和参数类型合并
					if(ParamTypes[n] != null){
						interfaceParam.add(ParamTypes[n].getSimpleName().toString()+"  "+ParamsName[n]);	
					}	
				}
				interfaceInfoinfo.setInterfaceParamList(interfaceParam);
				}
				
				if(handlerMethod.getMethodAnnotation(Deprecated.class) != null){//判断该接口是否被Deprecated注释
					interfaceInfoinfo.setInterfaceDeprecated(true);
				}
				interfaceInfoinfo.setInterfaceCount(EndpointCount);
				infos.add(interfaceInfoinfo);
			}
            queryResult.setRows(infos);
            queryResult.setTotal(EndpointCount);
            jr.setResult(infos);
		}
        jr.setSuccessMsg("调用接口信息接口成功");
		return jr;
	}
}
