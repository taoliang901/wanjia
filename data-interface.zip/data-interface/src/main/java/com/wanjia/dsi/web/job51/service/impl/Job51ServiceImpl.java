package com.wanjia.dsi.web.job51.service.impl;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.pahaoche.member.util.Tools;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.invoker.ResumeFromSource;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.common.utils.Job51XmlConverUtil;
import com.wanjia.dsi.common.utils.RestTemplateUtil;
import com.wanjia.dsi.web.area.dao.mapper.AreaMapper;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvRecordMapper;
import com.wanjia.dsi.web.job.model.TalentCv;
import com.wanjia.dsi.web.job.model.TalentCvExample;
import com.wanjia.dsi.web.job.model.TalentCvRecord;
import com.wanjia.dsi.web.job.model.TalentCvRecordExample;
import com.wanjia.dsi.web.job51.dao.mapper.Job51AccountMapper;
import com.wanjia.dsi.web.job51.dao.mapper.Job51CvMapper;
import com.wanjia.dsi.web.job51.model.Job51Account;
import com.wanjia.dsi.web.job51.model.Job51AccountExample;
import com.wanjia.dsi.web.job51.model.Job51Cv;
import com.wanjia.dsi.web.job51.model.Job51CvExample;
import com.wanjia.dsi.web.job51.service.Job51Service;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class Job51ServiceImpl extends BaseServiceImpl implements Job51Service {
	@Autowired
	private CommonJedis commonJedis;

	private Logger logger = Logger.getLogger(Job51ServiceImpl.class);
	
	@Value("#{job51Props['hostUrl']}")
	private String hostUrl;
	
	@Value("#{job51Props['adduserUrl']}")
	private String adduserUrl;
	
	@Value("#{job51Props['modifypasswordUrl']}")
	private String modifypasswordUrl;
	
	@Value("#{job51Props['deleteuserUrl']}")
	private String deleteuserUrl;
	
	@Value("#{job51Props['searchresumeUrl']}")
	private String searchresumeUrl;
	
	@Value("#{job51Props['viewresumeUrl']}")
	private String viewresumeUrl;
	
	@Value("#{job51Props['downloadresumeUrl']}")
	private String downloadresumeUrl;
	
	@Value("#{job51Props['adminToken']}")
	private String adminToken;
	
	@Value("#{job51Props['defaultEmail']}")
	private String defaultEmail;
	
	@Value("#{job51Props['degreeTransRules']}")
	private String degreeTransRules;
	
	@Autowired
	private Job51AccountMapper job51AccountMapper;
	
	@Autowired
	private Job51CvMapper job51CvMapper;
	
	@Autowired
	private TalentCvMapper talentCvMapper;
	
	@Autowired
	private AreaMapper areaMapper;
	
	@Autowired
	private TalentCvRecordMapper talentCvRecordMapper;

	@SuppressWarnings("rawtypes")
	@Override
	public JsonResponse addUser(Job51Account job51Account) {
		JsonResponse result = new JsonResponse();
		if(StringUtils.isBlank(job51Account.getClinicId())){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.MustPassParameter.getCode());
			result.setErrorMsg(ErrorType.MustPassParameter.getDesc());
			return result;
		}
		
		try {
			Job51AccountExample example = new Job51AccountExample();
			example.createCriteria().andClinicIdEqualTo(job51Account.getClinicId());
			List<Job51Account> job51AccountList = (List<Job51Account>) job51AccountMapper.selectByExample(example);
			if(job51AccountList != null && !job51AccountList.isEmpty() && job51AccountList.size() > 0){
				job51Account = job51AccountList.get(0);
				job51Account.setDelFlag("0");
		        job51AccountMapper.updateByPrimaryKeySelective(job51Account);
				return result;
				
			}else{
				if(StringUtils.isBlank(job51Account.getLoginName())){
					job51Account.setLoginName("wj" + DateUtils.format(new Date(), "yyyyMMddHHmmssSSS"));
				}
				
		        if(StringUtils.isBlank(job51Account.getPassword())){
		        	job51Account.setPassword("wj" + DateUtils.format(new Date(), "yyyyMMddHH"));
				}
		        
		        if(StringUtils.isBlank(job51Account.getName())){
		        	job51Account.setName("wj" + DateUtils.format(new Date(), "yyyyMMddHHmmssSSS"));
				}
		        
		        if(StringUtils.isBlank(job51Account.getEmail())){
		        	job51Account.setEmail(defaultEmail);
				}
		        
		        String jsonStr = "";
				
				LinkedHashMap<String,String> paramMap = new LinkedHashMap<String,String>();
				paramMap.put("admin_token", adminToken);
				paramMap.put("loginname", job51Account.getLoginName());
				paramMap.put("password", job51Account.getPassword());
				paramMap.put("name", job51Account.getName());
				paramMap.put("email", job51Account.getEmail());
				
				jsonStr =  RestTemplateUtil.getByHttpURLConnection(hostUrl + adduserUrl + "?" +  getParamStrFromMap(paramMap));
				if(!StringUtils.isBlank(jsonStr)){
					jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
					JSONObject obj = JSONObject.parseObject(jsonStr);
					if(obj.getString("result") != null && "1".equals(obj.getString("result")) && obj.getString("hruid") != null){
						String hruid = obj.getString("hruid");
						String access_token = obj.getString("access_token");
						
						job51Account.setId(UUID.randomUUID().toString());
						job51Account.setJob51UserId(hruid);
						job51Account.setAccessToken(access_token);
						job51Account.setPassword(Tools.getMD5Str(job51Account.getPassword()));
						job51Account.setDelFlag("0");
						
						deleteuser(job51Account.getClinicId());
						
						job51AccountMapper.insertSelective(job51Account);
					}
				}
			}
		
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("job51 addUser异常！", e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return result;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public JsonResponse modifypassword(String clinicId,String password) {
		JsonResponse result = new JsonResponse();
		if(StringUtils.isBlank(clinicId) || StringUtils.isBlank(password)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.MustPassParameter.getCode());
			result.setErrorMsg(ErrorType.MustPassParameter.getDesc());
			return result;
		}
		
		String jsonStr = "";
		try {
			Job51AccountExample example = new Job51AccountExample();
			example.createCriteria().andClinicIdEqualTo(clinicId);
			List<Job51Account> job51AccountList = (List<Job51Account>) job51AccountMapper.selectByExample(example);
			
			if(job51AccountList != null && !job51AccountList.isEmpty() && job51AccountList.size() > 0){
				Job51Account job51Account = job51AccountList.get(0);
				
				LinkedHashMap<String,String> paramMap = new LinkedHashMap<String,String>();
				paramMap.put("admin_token", adminToken);
				paramMap.put("hruid", job51Account.getJob51UserId());
				paramMap.put("password", password);
				paramMap.put("access_token", job51Account.getAccessToken());
				
				jsonStr =  RestTemplateUtil.getByHttpURLConnection(hostUrl + modifypasswordUrl + "?" +  getParamStrFromMap(paramMap));
				if(!StringUtils.isBlank(jsonStr)){
					jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
					JSONObject obj = JSONObject.parseObject(jsonStr);
					if(obj.getString("result") != null && "1".equals(obj.getString("result")) && obj.getString("access_token") != null){
						job51Account.setAccessToken(obj.getString("access_token"));
						job51Account.setPassword(Tools.getMD5Str(job51Account.getPassword()));
						job51AccountMapper.updateByPrimaryKeySelective(job51Account);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("job51 modifypassword异常！",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return result;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public JsonResponse deleteuser(String clinicId){
		JsonResponse result = new JsonResponse();
		if(StringUtils.isBlank(clinicId)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.MustPassParameter.getCode());
			result.setErrorMsg(ErrorType.MustPassParameter.getDesc());
			return result;
		}
		
		try {
			Job51AccountExample example = new Job51AccountExample();
			example.createCriteria().andClinicIdEqualTo(clinicId);
			List<Job51Account> job51AccountList = (List<Job51Account>) job51AccountMapper.selectByExample(example);
			//只做逻辑删除，在下次开通这家诊所时，设置delFlag就行
			if(job51AccountList != null && !job51AccountList.isEmpty() && job51AccountList.size() > 0){
				Job51Account job51Account = job51AccountList.get(0);
				job51Account.setDelFlag("1");
				job51AccountMapper.updateByPrimaryKeySelective(job51Account);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("job51 deleteuser异常！",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return result;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public JsonResponse search51JOBIntoMysql(String startDate,String endDate) {
        JsonResponse result = new JsonResponse();
		
		int pageNo = 0;
		int pageSize = 50;
		
		logger.info("searchAllOldIntoMysql start");
		try {
			Job51AccountExample example = new Job51AccountExample();
			example.createCriteria().andClinicIdEqualTo("pinganwj");
			List<Job51Account> job51AccountList = (List<Job51Account>) job51AccountMapper.selectByExample(example);
			
			if(job51AccountList != null && !job51AccountList.isEmpty() && job51AccountList.size() > 0){
				Job51Account job51Account = job51AccountList.get(0);
				
				List<Area> areaList = areaMapper.findAllCity();
//				areaList = areaList.subList(0, 2);
				
				
				List<String> funTypeList = Job51XmlConverUtil.getFunTypeList();
				
				for(int i=0;i<areaList.size();i++){
					if(!areaList.get(i).getCityName().equals("北京市") && !areaList.get(i).getCityName().equals("深圳市") && !areaList.get(i).getCityName().equals("广州市")  ){
						continue;
					}
					
					for(int j=0;j<funTypeList.size();j++){
						if(StringUtils.isNotBlank(areaList.get(i).getCityName())){
							String areaName = areaList.get(i).getCityName().replace("市", "");
							String areaCode = getXmlCodeByValue("DD_JOBAREA",areaName);
							String myCityId = areaList.get(i).getCityId();
							String workfun = funTypeList.get(j);
							
							if(StringUtils.isBlank(areaCode)){
								logger.info("searchAllOldIntoMysql start total...........null....areaCode..." + areaCode + "....areaName..." + areaName  + "....i..." + i);
								continue;
							}
							
							LinkedHashMap<String,String> paramMap = new LinkedHashMap<String,String>();
							paramMap.put("hruid", job51Account.getJob51UserId());
							paramMap.put("access_token", job51Account.getAccessToken());
							
							paramMap.put("expectjobarea", areaCode);
							
							paramMap.put("workfun", workfun);
							
							String lastupdateto = startDate;
							while(DateUtils.compare2Date(endDate, lastupdateto) > 0){
								Date lastupdatefromDate = DateUtils.parse(lastupdateto, "yyyyMMdd");
								Date lastupdatetoDate = DateUtils.addDay(lastupdatefromDate, 1);
								lastupdateto = DateUtils.format(lastupdatetoDate, "yyyyMMdd");
								
								paramMap.put("lastupdatefrom", DateUtils.format(lastupdatefromDate, "yyyyMMdd"));
								paramMap.put("lastupdateto", lastupdateto);
								paramMap.put("lastupdate", "1");
								
								paramMap.put("pageindex", pageNo+"");
								paramMap.put("pagesize", pageSize+"");
								paramMap.put("orderby", "0");
								
								String paramStr = getParamStrFromMap(paramMap);
								if(!StringUtils.isBlank(paramStr) && paramStr.startsWith("&")){
									paramStr = paramStr.substring(1, paramStr.length());
								}
								String jsonStr = RestTemplateUtil.postByHttpURLConnection(hostUrl + searchresumeUrl,paramStr);
								
								if(!StringUtils.isBlank(jsonStr)){
									jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
									JSONObject obj = JSONObject.parseObject(jsonStr);
									if(obj.getString("result") != null && "1".equals(obj.getString("result")) && obj.getString("resumelist") != null && obj.getString("totalrecords") != null){
										String totalrecords = obj.getString("totalrecords");
										if(StringUtils.isNotBlank(totalrecords) && StringUtils.isNumeric(totalrecords)){
											int total = Integer.parseInt(totalrecords);
											logger.info("searchAllOldIntoMysql start total..........." + total + "....lastupdateto..." + lastupdateto + "....areaCode..." + areaCode + "....areaName..." + areaName  + "....i..." + i);
											
											insert51JobIntoMysql(myCityId,workfun,areaCode,total,pageNo,pageSize,paramMap);
											
											logger.info("searchAllOldIntoMysql end total..........." + total + "....lastupdateto..." + lastupdateto + "....areaCode..." + areaCode + "....areaName..." + areaName  + "....i..." + i);
										}
									}
								}
							}
						}
					}
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("job51 searchresume异常！",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("searchAllOldIntoMysql end");
		return result;
	}

	private void insert51JobIntoMysql(String myCityId,String workfun, String areaCode, int total, int pageNo, int pageSize,LinkedHashMap<String, String> paramMap) {
		List<Job51Cv> cvList = new ArrayList<Job51Cv>();
		for(int limit = 0;limit < total ; limit = limit + pageSize,pageNo++){
			paramMap.put("pageindex", pageNo+"");
			paramMap.put("pagesize", pageSize+"");
			
			String paramStr = getParamStrFromMap(paramMap);
			if(!StringUtils.isBlank(paramStr) && paramStr.startsWith("&")){
				paramStr = paramStr.substring(1, paramStr.length());
			}
			String jsonStr = RestTemplateUtil.postByHttpURLConnection(hostUrl + searchresumeUrl,paramStr);
			
			if(!StringUtils.isBlank(jsonStr)){
				jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
				JSONObject obj = JSONObject.parseObject(jsonStr);
				JSONArray resumeArray = (JSONArray) obj.get("resumelist");
				if(!resumeArray.isEmpty() && resumeArray.size() > 0){
					
					for(int i=0;i<resumeArray.size();i++){
						JSONObject resumeObj = resumeArray.getJSONObject(i);
						
						Job51Cv cv = new Job51Cv();
						cv = transferJob51CvObj(resumeObj);
						
						cv.setExpectjobarea(areaCode);
						
						cv.setWorkfunc(workfun);
						
						if(cv != null && cv.getIsblacklist() != null && !"1".equals(cv.getIsblacklist())){
							cvList.add(cv);
						}
						
					}
				}
			}
		}
		
		//每次插入或更新1000条
		if(cvList != null && cvList.size() > 0){
			for(int i=1;i<=cvList.size()/1000 + 1;i++){
				List<Job51Cv> subList = new ArrayList<Job51Cv>();
				if(i > cvList.size()/1000 && (cvList.size()%1000 != 0)){
					for(int j=(i-1)*1000;j<cvList.size();j++){
						subList.add(cvList.get(j));
					}
					upsertBatch(subList,myCityId);
				}else{
					for(int j=(i-1)*1000;j<1000*i;j++){
						subList.add(cvList.get(j));
					}
					upsertBatch(subList,myCityId);
				}
			}
		}
	}

	private void upsertBatch(List<Job51Cv> subList,String myCityId) {
		List<TalentCv> talentcvList = transferJob51cvListTomyCv(subList,myCityId);
		
		List<Job51Cv> insertJob51CvList = new ArrayList<Job51Cv>();
		List<Job51Cv> updateJob51CvList = new ArrayList<Job51Cv>();
		
		List<TalentCv> insertTalentCvList = new ArrayList<TalentCv>();
		List<TalentCv> updateTalentCvList = new ArrayList<TalentCv>();
		
		//Job51Cv更新列表和插入列表
		HashMap<String,String> hadJob51CvUerIdMap = new HashMap<String,String>();
		List<String> userIds = new ArrayList<String>();
		for(int j=0;j<subList.size();j++){
			userIds.add(subList.get(j).getUserid());
		}
		Job51CvExample example = new Job51CvExample();
		example.createCriteria().andUseridIn(userIds);
		List<Job51Cv> hadJob51CvList = job51CvMapper.selectByExample(example);
		for(int j=0;j<hadJob51CvList.size();j++){
			hadJob51CvUerIdMap.put(hadJob51CvList.get(j).getUserid(), hadJob51CvList.get(j).getUserid());
		}
		if(!hadJob51CvUerIdMap.isEmpty()){
			for(int j=0;j<subList.size();j++){
				if(hadJob51CvUerIdMap.containsKey(subList.get(j).getUserid())){
					updateJob51CvList.add(subList.get(j));
				}else{
					insertJob51CvList.add(subList.get(j));
				}
			}
		}else{
			insertJob51CvList = subList;
		}
		
		//TalentCv更新列表和插入列表
        HashMap<String,String> hadTalentCvIdMap = new HashMap<String,String>();
        TalentCvExample talentCvexample = new TalentCvExample();
        talentCvexample.createCriteria().andIdIn(userIds);
		List<TalentCv> hadTalentCvList = talentCvMapper.selectByExample(talentCvexample);
		for(int j=0;j<hadTalentCvList.size();j++){
			hadTalentCvIdMap.put(hadTalentCvList.get(j).getId(), hadTalentCvList.get(j).getId());
		}
		if(!hadTalentCvIdMap.isEmpty()){
			for(int j=0;j<talentcvList.size();j++){
				if(hadTalentCvIdMap.containsKey(talentcvList.get(j).getId())){
					updateTalentCvList.add(talentcvList.get(j));
				}else{
					insertTalentCvList.add(talentcvList.get(j));
				}
			}
		}else{
			insertTalentCvList = talentcvList;
		}
		
		if(insertJob51CvList != null && insertJob51CvList.size() > 0){
			job51CvMapper.insertBatch(insertJob51CvList);
		}
		
		if(updateJob51CvList != null && updateJob51CvList.size() > 0){
			job51CvMapper.updateBatch(updateJob51CvList);
		}
		
		if(insertTalentCvList != null && insertTalentCvList.size() > 0){
			talentCvMapper.insertBatch(insertTalentCvList);
		}
		
		if(updateTalentCvList != null && updateTalentCvList.size() > 0){
			talentCvMapper.updateBatch(updateTalentCvList);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public JsonResponse searchresume(String hruid,String access_token,String lastupdatefrom,String lastupdateto,String lastupdate) {
		JsonResponse result = new JsonResponse();
		
		if(StringUtils.isBlank(hruid)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.MustPassParameter.getCode());
			result.setErrorMsg(ErrorType.MustPassParameter.getDesc());
			return result;
		}
		
		try {
			LinkedHashMap<String,String> paramMap = new LinkedHashMap<String,String>();
			paramMap.put("hruid", hruid);
			paramMap.put("access_token", access_token);
//			paramMap.put("isexpectjobarea", "1");
			paramMap.put("expectjobarea", "020000");
			
			
			paramMap.put("workfun", "1309");
			
			paramMap.put("lastupdatefrom", lastupdatefrom);
			paramMap.put("lastupdateto", lastupdateto);
			paramMap.put("lastupdate", lastupdate);
			
			paramMap.put("pageindex", "0");
			paramMap.put("pagesize", "50");
			paramMap.put("orderby", "1");
			
			String paramStr = getParamStrFromMap(paramMap);
			if(!StringUtils.isBlank(paramStr) && paramStr.startsWith("&")){
				paramStr = paramStr.substring(1, paramStr.length());
			}
			String jsonStr = RestTemplateUtil.postByHttpURLConnection(hostUrl + searchresumeUrl,paramStr);
			jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
			JSONObject obj = JSONObject.parseObject(jsonStr);
			if(obj.getString("result") != null && "1".equals(obj.getString("result")) && obj.getString("resumelist") != null && obj.getString("totalrecords") != null){
				String totalrecords = obj.getString("totalrecords");
				logger.info(totalrecords);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("job51 searchresume异常！",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<HashMap<String,Object>> viewresume(String clinicId,String resumeid){
		JsonResponse<HashMap<String,Object>> result = new JsonResponse<HashMap<String,Object>>();
		
		if(StringUtils.isBlank(clinicId) || StringUtils.isBlank(resumeid)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.MustPassParameter.getCode());
			result.setErrorMsg(ErrorType.MustPassParameter.getDesc());
			return result;
		}
		
		try {
			
			Job51AccountExample example = new Job51AccountExample();
			example.createCriteria().andClinicIdEqualTo(clinicId);
			List<Job51Account> job51AccountList = (List<Job51Account>) job51AccountMapper.selectByExample(example);
			if(job51AccountList != null && !job51AccountList.isEmpty() && job51AccountList.size() > 0){
				Job51Account job51Account = job51AccountList.get(0);
				
				LinkedHashMap<String,String> paramMap = new LinkedHashMap<String,String>();
				paramMap.put("hruid", job51Account.getJob51UserId());
				paramMap.put("access_token", job51Account.getAccessToken());
				paramMap.put("userid", resumeid);
				
				String jsonStr = RestTemplateUtil.getXmlByHttpURLConnection(hostUrl + viewresumeUrl + "?" +  getParamStrFromMap(paramMap));
				//两个"﻿<?xml"看起来一样，但是不replace,有问题,getBytes不一样
//				logger.info("﻿<?xm".equals("<?xm"));
				jsonStr = jsonStr.replace("﻿<?xml", "<?xml");
//				System.out.println(jsonStr);
				if(jsonStr.contains("<result>0</result>")){
					String errorMsg = "";
					if(jsonStr.indexOf("<msg>")>-1 && jsonStr.indexOf("</msg>")>-1){
						errorMsg = jsonStr.substring(jsonStr.indexOf("<msg>")+5, jsonStr.indexOf("</msg>"));
					}
					logger.error("51简历详情异常" + resumeid + ":" + errorMsg);
					result.setStatus(Status.ERROR);
					result.setErrorCode(ErrorType.SystemBusy.getCode());
					result.setErrorMsg(errorMsg);
					return result;
				}
				
				
				HashMap<String,Object> job51CvMap = Job51XmlConverUtil.jobDetailXmlToMap(jsonStr);
				
				System.out.println(job51CvMap);
				
				job51CvMap.put("resumeid", resumeid);
				result.setResult(job51CvMap);
				upsertTalentCvBy51JobCvMap(job51CvMap);
				
				TalentCvRecord record = new TalentCvRecord();
				record.setId(UUID.randomUUID().toString());
				record.setClinicId(clinicId);
				record.setTalentCvId("51JOB" + resumeid);
				record.setCreateDate(new Date());
				record.setReadFlag("0");
				record.setDelFlag("0");
				
				talentCvRecordMapper.insertSelective(record);
				
			}else{
				logger.error("该诊所未开通job51账户！");
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg("该诊所未开通job51账户！");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("job51 viewresume异常！",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
	
	private void upsertTalentCvBy51JobCvMap(HashMap<String, Object> job51CvMap) {
		TalentCv talentCv = new TalentCv();
		
		talentCv.setId("51JOB" + job51CvMap.get("resumeid").toString());
		talentCv.setCvShowId(job51CvMap.get("resumeid").toString());
		
		TalentCv talentCvExists = talentCvMapper.selectByPrimaryKey(job51CvMap.get("resumeid").toString());
		
		Boolean insertFlag = true;
		if(talentCvExists != null && StringUtils.isNotBlank(talentCvExists.getId())){
			//简历没有刷新
			if(talentCvExists.getRefreshTime() != null && job51CvMap.get("revisionDate").equals(DateUtils.format(talentCvExists.getRefreshTime(), DateUtils.DATE_FORMAT_TYPE3))){
				return;
			}else{
				insertFlag = false;
			}
		}else{
			insertFlag = true;
		}
		
		talentCv.setMemberId(-1l);
		talentCv.setStatus("3");
		talentCv.setDelFlag("0");
		
		//简历更新日期
		if(job51CvMap.get("revisionDate") != null && StringUtils.isNotBlank(job51CvMap.get("revisionDate").toString())){
			talentCv.setRefreshTime(DateUtils.parse(job51CvMap.get("revisionDate").toString(), DateUtils.DATE_FORMAT_TYPE3));
		}
		
		try{
			//期望薪资
			if(job51CvMap.get("excpectSalary") != null && StringUtils.isNotBlank(job51CvMap.get("excpectSalary").toString())){
				if(job51CvMap.get("excpectSalary").equals("面议")){
					talentCv.setIsNegotiable("1");
				}else if(job51CvMap.get("excpectSalaryMinMax").equals("1500以下")){
					talentCv.setExpectedSalaryMax(1500l);
				}else if(job51CvMap.get("excpectSalaryMinMax").equals("100000及以上")){
					talentCv.setExpectedSalaryMin(100000l);
				}else if(job51CvMap.get("excpectSalaryMinMax").toString().contains("-")){
					talentCv.setExpectedSalaryMin(Long.parseLong(job51CvMap.get("excpectSalaryMinMax").toString().split("-")[0].replace(" ", "")));
					talentCv.setExpectedSalaryMax(Long.parseLong(job51CvMap.get("excpectSalaryMinMax").toString().split("-")[1].replace(" ", "")));
				}else{
					talentCv.setIsNegotiable("1");
				}
			}else{
				talentCv.setIsNegotiable("1");
			}
		}catch(Exception e){
			logger.info("期望薪资格式问题----------");
		}
		
		//工作经验
		if(job51CvMap.get("workYearNum") != null && StringUtils.isNotBlank(job51CvMap.get("workYearNum").toString())){
			if(StringUtils.isNumeric(job51CvMap.get("workYearNum").toString())){
        		int workYearNum = Integer.parseInt(job51CvMap.get("workYearNum").toString());
        		if(workYearNum<3){
        			talentCv.setExperience("02");
        		}else if(workYearNum>=3 && workYearNum<5){
        			talentCv.setExperience("03");
        		}else if(workYearNum>=5 && workYearNum<10){
        			talentCv.setExperience("04");
        		}else if(workYearNum>=10 && workYearNum<15){
        			talentCv.setExperience("05");
        		}else if(workYearNum>=15){
        			talentCv.setExperience("06");
        		}
        	}
		}else{
			talentCv.setExperience("01");
		}
		
		//专业
		talentCv.setProfessional(job51CvMap.get("majorLatest").toString());
		
		//最高学历
		talentCv.setEducationLevel(getTransCode(degreeTransRules,job51CvMap.get("degreeLatestCode").toString()));
		
		//工作地点
		talentCv.setCityName(job51CvMap.get("expectArea").toString());
		
		//简历名称
		talentCv.setIntentionJobName(job51CvMap.get("epectFunc").toString());
		
		talentCv.setFromSource(ResumeFromSource.Job51.getDesc());
		
		if(insertFlag){
			talentCvMapper.insertSelective(talentCv);
		}else{
			commonJedis.removeObject("job51cvDetail_" + "51JOB" + job51CvMap.get("resumeid").toString());
			talentCvMapper.updateByPrimaryKeySelective(talentCv);
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public JsonResponse<HashMap<String,Object>> viewresumeFromDownload(String clinicId,String resumeid){
		JsonResponse<HashMap<String,Object>> result = new JsonResponse<HashMap<String,Object>>();
		
		if(StringUtils.isBlank(clinicId) || StringUtils.isBlank(resumeid)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.MustPassParameter.getCode());
			result.setErrorMsg(ErrorType.MustPassParameter.getDesc());
			return result;
		}
		try {
			Job51AccountExample example = new Job51AccountExample();
			example.createCriteria().andClinicIdEqualTo(clinicId);
			List<Job51Account> job51AccountList = (List<Job51Account>) job51AccountMapper.selectByExample(example);
			if(job51AccountList != null && !job51AccountList.isEmpty() && job51AccountList.size() > 0){
				Job51Account job51Account = job51AccountList.get(0);
				HashMap<String,Object> cvMap = new HashMap<String,Object>();
				if(commonJedis.getObject("job51cvDetail_" + "51JOB"  + resumeid) != null){
					cvMap = (HashMap<String,Object>) commonJedis.getObject("job51cvDetail_" + "51JOB" +  resumeid);
				}else{
					LinkedHashMap<String,String> paramMap = new LinkedHashMap<String,String>();
					paramMap.put("hruid", job51Account.getJob51UserId());
					paramMap.put("access_token", job51Account.getAccessToken());
					paramMap.put("userid", resumeid);
					String jsonStr = RestTemplateUtil.getXmlByHttpURLConnection(hostUrl + viewresumeUrl + "?" +  getParamStrFromMap(paramMap));
					//两个"﻿<?xml"看起来一样，但是不replace,有问题,getBytes不一样
//					logger.info("﻿<?xm".equals("<?xm"));
					jsonStr = jsonStr.replace("﻿<?xml", "<?xml");
					cvMap = Job51XmlConverUtil.jobDetailXmlToMap(jsonStr);
				}
				
				result.setResult(cvMap);
				
				TalentCvRecord record = new TalentCvRecord();
				record.setId(UUID.randomUUID().toString());
				record.setClinicId(clinicId);
				record.setTalentCvId(resumeid);
				record.setCreateDate(new Date());
				record.setReadFlag("0");
				record.setDelFlag("0");
				
				talentCvRecordMapper.insertSelective(record);
				
			}else{
				logger.error("该诊所未开通job51账户！");
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg("该诊所未开通job51账户！");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("job51 viewresume异常！",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public JsonResponse downloadresume(String clinicId,String resumeid) {
		JsonResponse result = new JsonResponse();
		
		if(StringUtils.isBlank(clinicId) || StringUtils.isBlank(resumeid)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.MustPassParameter.getCode());
			result.setErrorMsg(ErrorType.MustPassParameter.getDesc());
			return result;
		}
		
		try {
			Job51AccountExample example = new Job51AccountExample();
			example.createCriteria().andClinicIdEqualTo(clinicId);
			List<Job51Account> job51AccountList = (List<Job51Account>) job51AccountMapper.selectByExample(example);
			if(job51AccountList != null && !job51AccountList.isEmpty() && job51AccountList.size() > 0){
				Job51Account job51Account = job51AccountList.get(0);
				if(hasDownload(clinicId, resumeid).getResult()){
					result.setStatus(Status.ERROR);
					result.setErrorCode(ErrorType.SystemBusy.getCode());
					result.setErrorMsg("简历已在下载库中！");
					return result;
				}else{
					TalentCvRecord record = new TalentCvRecord();
					record.setId(UUID.randomUUID().toString());
					record.setClinicId(clinicId);
					record.setTalentCvId(resumeid);
					record.setCreateDate(new Date());
					record.setDelFlag("0");
					if(commonJedis.getObject("job51cvDetail_" + "51JOB" +  resumeid) != null){
						record.setReadFlag("2");
						result.setResult(commonJedis.getObject("job51cvDetail_" + "51JOB" +  resumeid));
					}else{
						record.setReadFlag("1");
						
						LinkedHashMap<String,String> paramMap = new LinkedHashMap<String,String>();
						paramMap.put("hruid", job51Account.getJob51UserId());
						paramMap.put("access_token", job51Account.getAccessToken());
						paramMap.put("userid", resumeid);
						
						String jsonStr = RestTemplateUtil.getByHttpURLConnection(hostUrl + downloadresumeUrl  + "?" +  getParamStrFromMap(paramMap));
						jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
						JSONObject obj = JSONObject.parseObject(jsonStr);
						if(obj.getString("result") != null && "1".equals(obj.getString("result"))){
							result.setStatus(Status.SUCCESS);
							
							jsonStr = RestTemplateUtil.getXmlByHttpURLConnection(hostUrl + viewresumeUrl + "?" +  getParamStrFromMap(paramMap));
							//两个"﻿<?xml"看起来一样，但是不replace,有问题,getBytes不一样
//							logger.info("﻿<?xm".equals("<?xm"));
							jsonStr = jsonStr.replace("﻿<?xml", "<?xml");
							HashMap cvMap = Job51XmlConverUtil.jobDetailXmlToMap(jsonStr);
							commonJedis.putObject("job51cvDetail_" + "51JOB" +  resumeid, cvMap);
							
						}else{
							if(obj.getString("result") != null && obj.getString("error") != null){
								JSONObject errorMsg = JSONObject.parseObject(obj.getString("error"));
								result.setErrorMsg(errorMsg.getString("msg"));
							}else{
								result.setErrorMsg(ErrorType.SystemBusy.getDesc());
							}
							logger.error(resumeid + ":51job下载简历接口返回失败！");
							result.setStatus(Status.ERROR);
							result.setErrorCode(ErrorType.SystemBusy.getCode());
							return result;
						}
					}
					talentCvRecordMapper.insertSelective(record);
				}
			}else{
				logger.error("该诊所未开通51job账户！");
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg("该诊所未开通51job账户！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(resumeid + ":job51 downloadresume异常！",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	public String getParamStrFromMap(LinkedHashMap<String,String> paramMap){
		StringBuffer returnStr = new StringBuffer("");
		StringBuffer source = new StringBuffer("");
		try {
			if(!paramMap.isEmpty()){
				Set<Entry<String, String>> mapSet = paramMap.entrySet();
				for (Map.Entry<String, String> entry : mapSet) {   
					returnStr.append("&" + entry.getKey() + "=" + entry.getValue());
					source.append(entry.getValue());
		        }  
				source.append("EhirePHP");
				returnStr.append("&sign=" + Tools.getMD5Str(Tools.getMD5Str(source.toString())));
			}
			 
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("getParamStrFromMap异常！",e);
		}
		
		return returnStr.toString();
	}
	
	public List<Job51Cv> getJob51CvList(int total,int pageNo,int pageSize,LinkedHashMap<String,String> paramMap){
		List<Job51Cv> cvList = new ArrayList<Job51Cv>();
		for(int limit = 0;limit < total ; limit = limit + pageSize,pageNo++){
			paramMap.put("pageindex", pageNo+"");
			paramMap.put("pagesize", pageSize+"");
			
			String paramStr = getParamStrFromMap(paramMap);
			if(!StringUtils.isBlank(paramStr) && paramStr.startsWith("&")){
				paramStr = paramStr.substring(1, paramStr.length());
			}
			String jsonStr = RestTemplateUtil.postByHttpURLConnection(hostUrl + searchresumeUrl,paramStr);
			
			if(!StringUtils.isBlank(jsonStr)){
				jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
				JSONObject obj = JSONObject.parseObject(jsonStr);
				JSONArray resumeArray = (JSONArray) obj.get("resumelist");
				if(!resumeArray.isEmpty() && resumeArray.size() > 0){
					
					for(int i=0;i<resumeArray.size();i++){
						JSONObject resumeObj = resumeArray.getJSONObject(i);
						
						Job51Cv cv = new Job51Cv();
						cv = transferJob51CvObj(resumeObj);
						
						if(cv != null && cv.getIsblacklist() != null && !"1".equals(cv.getIsblacklist())){
							cvList.add(cv);
						}
						
					}
				}
			}
		}
		return cvList;
	}
	
	public Job51Cv transferJob51CvObj(JSONObject resumeObj){
		Job51Cv cv = new Job51Cv();
        
		cv.setId(UUID.randomUUID().toString());
		if(resumeObj.containsKey("userid")){
			cv.setUserid(resumeObj.getString("userid"));
		}
		if(resumeObj.containsKey("haspic")){
			cv.setHaspic(resumeObj.getString("haspic"));
		}
		if(resumeObj.containsKey("ismba")){
			cv.setIsmba(resumeObj.getString("ismba"));
		}
		if(resumeObj.containsKey("ishighlight")){
			cv.setIshighlight(resumeObj.getString("ishighlight"));
		}
		if(resumeObj.containsKey("topschool")){
			cv.setTopschool(resumeObj.getString("topschool"));
		}
		if(resumeObj.containsKey("iscertified")){
			cv.setIscertified(resumeObj.getString("iscertified"));
		}
		if(resumeObj.containsKey("age")){
			cv.setAge(resumeObj.getString("age"));
		}
		if(resumeObj.containsKey("workyear")){
			cv.setWorkyear(resumeObj.getString("workyear"));
		}
		if(resumeObj.containsKey("sex")){
			cv.setSex(resumeObj.getString("sex"));
		}
		if(resumeObj.containsKey("area")){
			cv.setArea(resumeObj.getString("area"));
		}
		if(resumeObj.containsKey("workfunc")){
			cv.setWorkfunc(resumeObj.getString("workfunc"));
		}
		if(resumeObj.containsKey("topdegree")){
			cv.setTopdegree(resumeObj.getString("topdegree"));
		}
		if(resumeObj.containsKey("lastupdate")){
			cv.setLastupdate(resumeObj.getString("lastupdate"));
		}
		if(resumeObj.containsKey("hukou")){
			cv.setHukou(resumeObj.getString("hukou"));
		}
		if(resumeObj.containsKey("expectsalary")){
			cv.setExpectsalary(resumeObj.getString("expectsalary"));
		}
		if(resumeObj.containsKey("currentsalary")){
			cv.setCurrentsalary(resumeObj.getString("currentsalary"));
		}
		if(resumeObj.containsKey("lastupdate")){
			cv.setLastupdate(resumeObj.getString("lastupdate"));
		}
		if(resumeObj.containsKey("workindustry")){
			cv.setWorkindustry(resumeObj.getString("workindustry"));
		}
		if(resumeObj.containsKey("topmajor")){
			cv.setTopmajor(resumeObj.getString("topmajor"));
		}
		if(resumeObj.containsKey("serial")){
			cv.setSerial(resumeObj.getString("serial"));
		}
		if(resumeObj.containsKey("isdownload")){
			cv.setIsdownload(resumeObj.getString("isdownload"));
		}
		if(resumeObj.containsKey("isblacklist")){
			cv.setIsblacklist(resumeObj.getString("isblacklist"));
		}
		if(resumeObj.containsKey("isusershield")){
			cv.setIsusershield(resumeObj.getString("isusershield"));
		}
		return cv;
	}
	
	
	public List<TalentCv> transferJob51cvListTomyCv(List<Job51Cv> job51CvList,String myCityId){
		List<TalentCv> talentCvList = new ArrayList<TalentCv>();
		
		if(!job51CvList.isEmpty() && job51CvList.size() > 0){
			for(int i=0;i<job51CvList.size();i++){
//				logger.info("transferJob51cvListTomyCv....." + i);
				if(job51CvList.get(i).getUserid() != null){
					talentCvList.add(transferJob51cvTomyCv(job51CvList.get(i),myCityId));
				}
			}
		}
		return talentCvList;
	}
	
	public LinkedHashMap<String, Object> transferResumeObjToMap(JSONObject resumeObj){
		LinkedHashMap<String, Object> talentCvMap = new LinkedHashMap<String, Object>();
		try {
			//简历id
			if(resumeObj.containsKey("userid")){
				talentCvMap.put("id", resumeObj.getString("userid"));
			}
			//简历名称
			if(resumeObj.containsKey("workfunc")){
				talentCvMap.put("intentionJobName",getXmlValueByCode("DD_FUNTYPE",resumeObj.getString("workfunc")));
			}
			
			//期望薪资
			if(resumeObj.containsKey("expectsalary")){
				String expectsalary = getXmlValueByCode("DD_SALTYPE",resumeObj.getString("expectsalary"));
				talentCvMap.put("isNegotiable","0");
				if(StringUtils.isNotBlank(expectsalary)){
					talentCvMap.put("expectedSalaryName",expectsalary);
				}else{
					talentCvMap.put("isNegotiable","1");
				}
			}
			
			//专业
			if(resumeObj.containsKey("topmajor")){
				talentCvMap.put("professional",getXmlValueByCode("DD_MAJOR",resumeObj.getString("topmajor")));
			}
			
			//最高学历
			if(resumeObj.containsKey("topdegree")){
				talentCvMap.put("educationLevel",getXmlValueByCode("DD_DEGREE",resumeObj.getString("topdegree")));
					
			}
			
		    talentCvMap.put("fromSource", ResumeFromSource.Job51.getDesc());
			
			
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("transferJob51cvTomyCv异常！",e);
		}
		return talentCvMap;
	}
	
	public TalentCv transferJob51cvTomyCv(Job51Cv job51Cv,String myCityId){
		TalentCv talentCv = new TalentCv();
		try {
			talentCv.setId(job51Cv.getUserid());
			
			talentCv.setMemberId(-1l);
			
			talentCv.setStatus("3");
			
			talentCv.setDelFlag("0");
			
			//期望薪资
			if(job51Cv.getExpectsalary() != null && StringUtils.isNumeric(job51Cv.getExpectsalary())){
				String expectsalary = getXmlValueByCode("DD_SALTYPE",job51Cv.getExpectsalary());
				talentCv.setIsNegotiable("0");
				if(expectsalary.equals("1500以下")){
					talentCv.setExpectedSalaryMax(1500l);
				}else if(expectsalary.equals("100000及以上")){
					talentCv.setExpectedSalaryMin(100000l);
				}else if(expectsalary.contains("-")){
					talentCv.setExpectedSalaryMin(Long.parseLong(expectsalary.split("-")[0].replace(" ", "")));
					talentCv.setExpectedSalaryMax(Long.parseLong(expectsalary.split("-")[1].replace(" ", "")));
				}else{
					talentCv.setIsNegotiable("1");
				}
			}
			
			//最高学历
			talentCv.setEducationLevel(getTransCode(degreeTransRules,job51Cv.getTopdegree()));
			
			//最高专业
			talentCv.setEducationMajor(job51Cv.getTopmajor());
			
			//工作地点
			HashMap<String,Area> areaMap = new HashMap<String,Area>();

//			if(commonJedis.getObject("myAllAreaMap") != null){
//				areaMap = (HashMap<String, Area>) commonJedis.getObject("myAllAreaMap");
//			}else{
//				List<Area> areaList = areaMapper.queryAreaList();
//				for(int i=0;i<areaList.size();i++){
//					Area area = areaList.get(i);
//					areaMap.put(area.getAreaId(), area);
//				}
//				commonJedis.putObject("myAllAreaMap", areaMap , 24*3600);
//			}
			
			List<Area> areaList = areaMapper.queryAreaList();
			for(int i=0;i<areaList.size();i++){
				Area area = areaList.get(i);
				areaMap.put(area.getAreaId(), area);
			}
			
			Area area = new Area();
			if(areaMap.containsKey(myCityId)){
				area = areaMap.get(myCityId);
			}
			
			if(area != null && area.getCityId() != null){
				talentCv.setProvinceId(area.getProvinceId());
				talentCv.setProvinceName(area.getProvinceName());
				talentCv.setCityId(area.getCityId());
				talentCv.setCityName(area.getCityName());
			}
			
			//简历名称
			talentCv.setIntentionJobName(getXmlValueByCode("DD_FUNTYPE",job51Cv.getWorkfunc()));
			
			talentCv.setFromSource("51JOB");
			
			talentCv.setReleaseTime(DateUtils.parse(job51Cv.getLastupdate(), DateUtils.DATE_FORMAT_TYPE1));
			
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("transferJob51cvTomyCv异常！",e);
		}
		return talentCv;
	}
	
	public String getTransCode(String rules,String job51code){
		String returnStr = "";
		try {
			JSONArray transArray = JSONArray.parseArray(rules);
			if(!transArray.isEmpty() && transArray.size() > 0){
				for(int i=0;i<transArray.size();i++){
					JSONObject obj = transArray.getJSONObject(i);
					if(obj.getString("job51code").equals(job51code)){
						returnStr = obj.getString("mycode");
						break;
					}
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("getDegreeTransCode异常！",e);
		}
		return returnStr;
	}
	
	public String getXmlValueByCode(String xmlName,String xmlCode){
		String returnStr = "";
		try {
			HashMap<String,String> xmlMap = new HashMap<String,String>();
//			if(commonJedis.getObject("job51ValueByCode" + xmlName) == null){
//				xmlMap = Job51XmlConverUtil.xmltoMapValueByCode(xmlName);
//				commonJedis.putObject("job51ValueByCode" + xmlName, xmlMap);
//			}else{
//				xmlMap = (HashMap<String, String>) commonJedis.getObject("job51ValueByCode" + xmlName);
//			}
			
			xmlMap = Job51XmlConverUtil.xmltoMapValueByCode(xmlName);
			
			if(!xmlMap.isEmpty() && xmlMap.containsKey(xmlCode)){
				returnStr = xmlMap.get(xmlCode);
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("getXmlValue异常！",e);
		}
		return returnStr;
	}
	
	public String getXmlCodeByValue(String xmlName,String xmlValue){
		String returnStr = "";
		try {
			HashMap<String,String> xmlMap = new HashMap<String,String>();
//			if(commonJedis.getObject("job51CodeByValue" + xmlName) == null){
//				xmlMap = Job51XmlConverUtil.xmltoMapCodeByValue(xmlName);
//				commonJedis.putObject("job51CodeByValue" + xmlName, xmlMap);
//			}else{
//				xmlMap = (HashMap<String, String>) commonJedis.getObject("job51CodeByValue" + xmlName);
//			}
			
			xmlMap = Job51XmlConverUtil.xmltoMapCodeByValue(xmlName);
			if(!xmlMap.isEmpty()){
				if(xmlValue.equals("香港岛") || xmlValue.equals("九龙半岛") || xmlValue.equals("新界")){
					returnStr = "330000";
				}else if(xmlMap.containsKey(xmlValue)){
					returnStr = xmlMap.get(xmlValue);
				}else if(xmlValue.length()>=4){
					for(int i=xmlValue.length();i>1;i--){
						if(xmlMap.containsKey(xmlValue.substring(0,i))){
							returnStr = xmlMap.get(xmlValue.substring(0,i));
							break;
						}
					}
				}
			}

		}catch (Exception e) {
			e.printStackTrace();
			logger.error("getXmlCode异常！",e);
		}
		return returnStr;
	}

	@Override
	public JsonResponse<Boolean> hasDownload(String clinicId, String cvId) {
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		try {
			TalentCvRecordExample exmaple = new TalentCvRecordExample();
			List<String> readFlagList = new ArrayList<String>();
			readFlagList.add("1");
			readFlagList.add("2");
			exmaple.createCriteria().andClinicIdEqualTo(clinicId).andTalentCvIdEqualTo(cvId).andDelFlagEqualTo("0").andReadFlagIn(readFlagList);
			int countNum = talentCvRecordMapper.countByExample(exmaple);
			if(countNum > 0){
				result.setResult(true);
			}else{
				result.setResult(false);
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("hasDownload异常！",e);
			result.setResult(false);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<PageInfo<LinkedHashMap<String, Object>>> search51JOBList(Map<String,String> searchPramMap) {
		JsonResponse<PageInfo<LinkedHashMap<String, Object>>> result = new JsonResponse<PageInfo<LinkedHashMap<String, Object>>>();
		
		if(StringUtils.isBlank(searchPramMap.get("pageNo")) || !StringUtils.isNumeric(searchPramMap.get("pageNo"))){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.IllegalArgument.getCode());
			result.setErrorMsg("pageNo参数不合法");
			return result;
		}
		
	    if(StringUtils.isBlank(searchPramMap.get("pageSize")) || !StringUtils.isNumeric(searchPramMap.get("pageSize"))){
	    	result.setStatus(Status.ERROR);
	    	result.setErrorCode(ErrorType.IllegalArgument.getCode());
			result.setErrorMsg("pageSize参数不合法");
			return result;
		}
		
		try {
			Job51AccountExample example = new Job51AccountExample();
			example.createCriteria().andClinicIdEqualTo("pinganwj");
			List<Job51Account> job51AccountList = (List<Job51Account>) job51AccountMapper.selectByExample(example);
			if(job51AccountList != null && !job51AccountList.isEmpty() && job51AccountList.size() > 0){
				Job51Account job51Account = job51AccountList.get(0);
				
				LinkedHashMap<String,String> paramMap = new LinkedHashMap<String,String>();
				paramMap.put("hruid", job51Account.getJob51UserId());
				paramMap.put("access_token", job51Account.getAccessToken());
				
				//关键字
				if(searchPramMap.containsKey("keyWord")){
					paramMap.put("keyword", searchPramMap.get("keyWord"));
				}
				
				//期望工作地点
				if(searchPramMap.containsKey("cityName")){
					paramMap.put("isexpectjobarea", "1");
					if(searchPramMap.containsKey("areaName")){
						paramMap.put("expectjobarea", getXmlCodeByValue("DD_JOBAREA",searchPramMap.get("cityName").replace("市", "") + "-" + searchPramMap.get("areaName")));
					    logger.info("搜索简历--------期望工作地点---------" + searchPramMap.get("cityName").replace("市", "") + "-" + searchPramMap.get("areaName") + "," + getXmlCodeByValue("DD_JOBAREA",searchPramMap.get("cityName").replace("市", "") + "-" + searchPramMap.get("areaName")));
					}else{
						paramMap.put("expectjobarea", getXmlCodeByValue("DD_JOBAREA",searchPramMap.get("cityName").replace("市", "")));
						logger.info("搜索简历--------期望工作地点---------" + searchPramMap.get("cityName").replace("市", "") + "-" + getXmlCodeByValue("DD_JOBAREA",searchPramMap.get("cityName").replace("市", "")));
					}
				}
				
				//期望职能
				if(searchPramMap.containsKey("intentionJob")){
					paramMap.put("workfun", searchPramMap.get("intentionJob"));
				}
				
				//工作经验最小值
				if(searchPramMap.containsKey("experienceMin")){
					paramMap.put("workyearfrom", searchPramMap.get("experienceMin"));
				}
				
				//工作经验最大值
				if(searchPramMap.containsKey("experienceMax")){
					paramMap.put("workyearto", searchPramMap.get("experienceMax"));
				}
				
				//学历开始
				if(searchPramMap.containsKey("educationLevel")){
					paramMap.put("degreefrom", searchPramMap.get("educationLevel"));
				}
				
				//期望薪资最小值
				if(searchPramMap.containsKey("experienceMin")){
					paramMap.put("expectsalaryfrom", searchPramMap.get("experienceMin"));
				}
				
				//期望薪资最大值
				if(searchPramMap.containsKey("experienceMax")){
					paramMap.put("expectsalaryto", searchPramMap.get("experienceMax"));
				}
				
				//更新时间
				paramMap.put("lastupdatefrom", DateUtils.format(DateUtils.addDay(new Date(), -60), DateUtils.YYYYMMDD));
				paramMap.put("lastupdateto", DateUtils.format(new Date(), DateUtils.YYYYMMDD));
				paramMap.put("lastupdate", "4");
				
				//pageNo
				if(searchPramMap.containsKey("pageNo")){
					paramMap.put("pageindex", (Integer.parseInt(searchPramMap.get("pageNo"))-1) + "");
				}
				
				//pageSize
				if(searchPramMap.containsKey("pageSize")){
					paramMap.put("pagesize", searchPramMap.get("pageSize"));
				}
				
				//orderby
				if(searchPramMap.containsKey("orderby")){
					paramMap.put("orderby", searchPramMap.get("orderby"));
				}else{
					paramMap.put("orderby", "1");
				}
				
				String paramStr = getParamStrFromMap(paramMap);
				if(!StringUtils.isBlank(paramStr) && paramStr.startsWith("&")){
					paramStr = paramStr.substring(1, paramStr.length());
				}
				String jsonStr = RestTemplateUtil.postByHttpURLConnection(hostUrl + searchresumeUrl,paramStr);
				jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
				JSONObject obj = JSONObject.parseObject(jsonStr);
				if(obj.getString("result") != null && "1".equals(obj.getString("result")) && obj.getString("resumelist") != null && obj.getString("totalrecords") != null){
					String totalrecords = obj.getString("totalrecords");
					
					if(StringUtils.isNotBlank(totalrecords) && StringUtils.isNumeric(totalrecords)){
						PageInfo<LinkedHashMap<String, Object>> page = new PageInfo<LinkedHashMap<String, Object>>();
						page.setTotal(Long.parseLong(totalrecords));
						if(Long.parseLong(totalrecords)%Integer.parseInt(searchPramMap.get("pageSize")) == 0){
							page.setPages(Integer.parseInt(totalrecords)/Integer.parseInt(searchPramMap.get("pageSize")));
						}else{
							page.setPages(Integer.parseInt(totalrecords)/Integer.parseInt(searchPramMap.get("pageSize"))+ 1);
						}
						
						JSONArray resumeArray = (JSONArray) obj.get("resumelist");
						
						if(!resumeArray.isEmpty() && resumeArray.size() > 0){
							
							
							List<LinkedHashMap<String, Object>> resumeList = new ArrayList<LinkedHashMap<String, Object>>();
							for(int i=0;i<resumeArray.size();i++){
								JSONObject resumeObj = resumeArray.getJSONObject(i);
								resumeList.add(transferResumeObjToMap(resumeObj));
							}
							page.setList(resumeList);
						}
						
						if(page != null){
							result.setResult(page);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("job51 search51JOBList异常！",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		
		return result;
	}
}
