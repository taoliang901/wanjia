package com.wanjia.dsi.web.wjkmj.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.github.pagehelper.ISelect;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.activity.dao.mapper.WjkmjDetailMapper;
import com.wanjia.dsi.web.activity.model.WjkmjDetail;
import com.wanjia.dsi.web.wjkmj.dao.mapper.WjkmjDayCountMapper;
import com.wanjia.dsi.web.wjkmj.model.WjkmjDayCount;
import com.wanjia.dsi.web.wjkmj.model.WjkmjDayCountExample;
import com.wanjia.dsi.web.wjkmj.model.WjkmjDiaryBO;
import com.wanjia.dsi.web.wjkmj.repository.WjkmjDiaryRepository;
import com.wanjia.dsi.web.wjkmj.service.WjkmjService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class WjkmjServiceImpl implements WjkmjService {

	private static String CLASS_NAME = WjkmjServiceImpl.class.getName();

	@Value("#{serverConstants['numbersForCTC']}")
	private String numbersForCTC;

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private WjkmjDiaryRepository wjkmjDiaryRepository;

	@Autowired
	private WjkmjDayCountMapper wjkmjDayCountMapper;

	@Autowired
	private WjkmjDetailMapper wjkmjDetailMapper;

	@Override
	public JsonResponse<Void> updateWjkmjToday(String requestId, Date voteDate) {
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":updateWjkmjToday method start...");
		JsonResponse<Void> result = new JsonResponse<Void>();
		try {
			// 插入当前日期的所有投票记录
			wjkmjDayCountMapper.insertWjkmjToday(voteDate);

			// 把刚刚insert进去的list查出来准备更新,需要用已经生成好的id进行update
			WjkmjDayCountExample example = new WjkmjDayCountExample();
			example.createCriteria().andCountDateEqualTo(voteDate);
			List<WjkmjDayCount> dbList = wjkmjDayCountMapper.selectByExample(example);
			List<String> clinicIds = new ArrayList<String>();
			for (int i = 0; i < dbList.size(); i++) {
				clinicIds.add(dbList.get(i).getClinicId());
			}

			// 用当前日期的前一天的WjkmjDayCount+今天的MongoDB流水统计计算出今天的WjkmjDayCount
			Calendar c = Calendar.getInstance();
			c.setTime(voteDate);
			c.add(Calendar.DAY_OF_YEAR, -1);
			Date yesterday = c.getTime();

			// 昨天的投票记录
			HashMap<String, WjkmjDayCount> countMap = new HashMap<String, WjkmjDayCount>();
			JsonResponse<List<WjkmjDayCount>> jr = getWjkmjDayCountList(requestId, yesterday);
			if (jr.getResult() != null && jr.getResult().size() > 0) {
				for (WjkmjDayCount wdc : jr.getResult()) {
					countMap.put(wdc.getClinicId(), wdc);
				}
			}

			// MongDB中所有的投票记录
			List<WjkmjDayCount> wjkmjDayCountMogo = wjkmjDiaryRepository.getWjkmjDayCountListMongo(voteDate, clinicIds);
			// 合并昨天的投票记录（MYSQL中)与（MongoDB中）的记录，并根据随机数生成今天的记录
			for (WjkmjDayCount wdc : dbList) {
				// 生产今天的随机数
				wdc.setRandomToday(getRandom());

				// 更新今天的投票数
				for (WjkmjDayCount mongoObj : wjkmjDayCountMogo) {
					if (wdc.getClinicId().equals(mongoObj.getClinicId())) {
						wdc.setVoteToday(mongoObj.getVoteToday());
					}
				}

				WjkmjDayCount wdcOfYesterday = new WjkmjDayCount();
				if (!countMap.isEmpty() && countMap.containsKey(wdc.getClinicId())) {
					// 昨天投票数不为空
					wdcOfYesterday = countMap.get(wdc.getClinicId());
					wdc.setOperateCount(wdcOfYesterday.getOperateCount() + wdcOfYesterday.getOperateToday());
					wdc.setRandomCount(wdcOfYesterday.getRandomCount() + wdcOfYesterday.getRandomToday());
					wdc.setVoteCount(wdcOfYesterday.getVoteCount() + wdcOfYesterday.getVoteToday());
				}

				wdc.setCountDate(voteDate);
			}

			// 写入数据库
			wjkmjDayCountMapper.batchUpdate(dbList);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("updateWjkmjToday error is:" + e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":updateWjkmjToday method end...");
		return result;
	}

	/**
	 * 
	 * 根据投票日期，获取所有诊所投票记录
	 * 
	 */
	@Override
	public JsonResponse<PageInfo<WjkmjDayCount>> getWjkmjDayCountShowList(String requestId, WjkmjDayCount wjkmjDayCount,
			Date voteDate, String userIp, String orderByClause, int pageSize, int pageNum) {
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":getWjkmjDayCountShowList method start...");
		JsonResponse<PageInfo<WjkmjDayCount>> result = new JsonResponse<PageInfo<WjkmjDayCount>>();
		try {
			// 从MYSQL中获取所有报名的诊所以及诊所前一天的投票记录
			int star = (pageNum - 1) * pageSize;
			star = star < 0 ? 0 : star;

			final Date yesterday = DateUtils.addDay(voteDate, -1);
			final String orderByClauseFinal = orderByClause;
			final String clinicIdFinal = wjkmjDayCount.getClinicId();
			final String clinicNameFinal = wjkmjDayCount.getClinicName();
			PageInfo<WjkmjDayCount> pageInfo = new PageInfo<WjkmjDayCount>();
			
			// 获取分页记录
			Map<String, Object> map = new HashMap<String, Object>();

			// 获取已统计的投票最大时间
			WjkmjDayCount maxDayCount = wjkmjDayCountMapper.getMaxVoteDate();
			// 如果统计的最大时间小于昨天，侧获取系统的最大统计时间
			if (maxDayCount != null && maxDayCount.getCountDate() != null
					&& DateUtils.format(yesterday, DateUtils.DATE_FORMAT_TYPE3)
							.compareTo(DateUtils.format(maxDayCount.getCountDate(), DateUtils.DATE_FORMAT_TYPE3)) > 0) {
				map.put("voteDate", maxDayCount.getCountDate());
			} else {
				map.put("voteDate", yesterday);
			}
			
			map.put("limit", pageSize);
			map.put("offset", star);
			if (orderByClauseFinal != null) {
				map.put("orderByClause", orderByClauseFinal);
			}
			if (clinicNameFinal != null) {
				map.put("clinicName", clinicNameFinal);
			}
			if (clinicIdFinal != null) {
				map.put("clinicId", clinicIdFinal);
			}
			List<WjkmjDayCount> list = wjkmjDayCountMapper.selectWjkmByDateList(map);
			pageInfo.setList(list);

			long count = PageHelper.count(new ISelect() {
				@Override
				public void doSelect() {
					Map<String, Object> map = new HashMap<String, Object>();
					if (clinicNameFinal != null) {
						map.put("clinicName", clinicNameFinal);
					}
					if (clinicIdFinal != null) {
						map.put("clinicId", clinicIdFinal);
					}

					wjkmjDetailMapper.getAllByActivityId(map);
				}
			});
			pageInfo.setTotal(count);
			pageInfo.setPageNum(pageNum < 1 ? 1 : pageNum);
			pageInfo.setPageSize(pageSize);
			long totalPages = count % pageSize == 0 ? count / pageSize : count / pageSize + 1;
			pageInfo.setPages(Long.valueOf(totalPages).intValue());

			// 从MongoDB中获取数据
			getWjkmjDayCountFromMongoDB(pageInfo.getList(), voteDate, userIp);

			// 设置返回结果
			result.setResult(pageInfo);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("getWjkmjDayCountShowList error is:" + e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":getWjkmjDayCountShowList method end...");
		return result;
	}

	/**
	 * 
	 * 根据投票日期，获取所有诊所投票记录
	 * 
	 */
	@Override
	public JsonResponse<List<WjkmjDayCount>> getWjkmjDayCountShowList(String requestId, Date voteDate, String userIp,
			Date createDate, String orderByClause, String limit) {
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":getWjkmjDayCountShowList method start...");
		JsonResponse<List<WjkmjDayCount>> result = new JsonResponse<List<WjkmjDayCount>>();
		try {
			// 从MYSQL中获取所有报名的诊所以及诊所前一天的投票记录
			Map<String, Object> map = new HashMap<String, Object>();
			Date yesterday = DateUtils.addDay(voteDate, -1);
			// 获取已统计的投票最大时间
			WjkmjDayCount maxDayCount = wjkmjDayCountMapper.getMaxVoteDate();
			// 如果统计的最大时间小于昨天，侧获取系统的最大统计时间
			if (maxDayCount != null && maxDayCount.getCountDate() != null
					&& DateUtils.format(yesterday, DateUtils.DATE_FORMAT_TYPE3)
							.compareTo(DateUtils.format(maxDayCount.getCountDate(), DateUtils.DATE_FORMAT_TYPE3)) > 0) {
				map.put("voteDate", maxDayCount.getCountDate());
			} else {
				map.put("voteDate", yesterday);
			}

			if (createDate != null) {
				map.put("createDate", createDate);
			}
			if (orderByClause != null) {
				map.put("orderByClause", orderByClause);
			}
			if (limit != null) {
				map.put("limit", Integer.valueOf(limit));
				map.put("offset", 0);
			}

			List<WjkmjDayCount> wjkmjDayCountList = wjkmjDayCountMapper.selectWjkmByDateList(map);

			// 从MongoDB中获取数据
			getWjkmjDayCountFromMongoDB(wjkmjDayCountList, voteDate, userIp);

			// 设置返回结果
			result.setResult(wjkmjDayCountList);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("getWjkmjDayCountShowList error is:" + e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":getWjkmjDayCountShowList method end...");
		return result;
	}

	/**
	 * 
	 * 插入投票记录到MongoDB
	 * 
	 */
	@Override
	public JsonResponse<Void> insertWjkmjDiaryBO(String requestId, WjkmjDiaryBO wjkmjDiaryBO) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		try {
			Query query = new Query();
			if (StringUtils.isNotBlank(wjkmjDiaryBO.getClinicId())) {
				query.addCriteria(Criteria.where("clinicId").is(wjkmjDiaryBO.getClinicId()));
			}

			if (StringUtils.isNotBlank(wjkmjDiaryBO.getUserIp())) {
				query.addCriteria(Criteria.where("userIp").is(wjkmjDiaryBO.getUserIp()));
			}

			if (wjkmjDiaryBO.getVoteDate() != null) {
				String voteDateOfDay = DateUtils.format(wjkmjDiaryBO.getVoteDate(), DateUtils.DATE_FORMAT_TYPE3);
				wjkmjDiaryBO.setVoteDateOfDay(voteDateOfDay);
				query.addCriteria(Criteria.where("voteDateOfDay").is(wjkmjDiaryBO.getVoteDateOfDay()));
			}

			// 每个IP每天只能对每个诊所投一次票
			if (wjkmjDiaryRepository.findCount(query, WjkmjDiaryBO.class) == 0) {
				wjkmjDiaryRepository.insert(wjkmjDiaryBO, WjkmjDiaryBO.class);
			} else {
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg("用户今天对该诊所已经报过名...");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("getWjkmjDayCountShowList error is:" + e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	/**
	 * 
	 * 根据诊所ID，判断诊所是否参加CTC报名
	 * 
	 */
	@Override
	public JsonResponse<Boolean> isJoinCTC(String requestId, String activityId, String clinicId) {
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":isJoinCTC method start...");
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		try {

			Map<String, Object> map = new HashMap<String, Object>();
			map.put("delFlag", 0);
			map.put("clinicId", clinicId);
			if (activityId != null) {
				map.put("activityId", activityId);
			}

			@SuppressWarnings("unchecked")
			List<WjkmjDetail> clinicList = wjkmjDetailMapper.findByProperties(map);
			if (clinicList != null && clinicList.size() > 0) {
				result.setResult(true);
			} else {
				result.setResult(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("isJoinCTC error is:" + e.getMessage());
			result.setStatus(Status.ERROR);
			result.setResult(false);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":isJoinCTC method end...");
		return result;
	}

	/**
	 * 
	 * 判读当前IP是否对当前诊所投票
	 * 
	 */
	@Override
	public JsonResponse<Boolean> isVoted(String requestId, Date voteDate, String activityId, String clinicId,
			String userIp) {
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":isVoted method start...");
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		try {

			Map<String, Object> map = new HashMap<String, Object>();
			map.put("delFlag", 0);
			map.put("clinicId", clinicId);
			map.put("userIp", userIp);
			if (activityId != null) {
				map.put("activityId", activityId);
			}

			boolean isVoted = wjkmjDiaryRepository.isVoted(voteDate, null, clinicId, userIp);
			result.setResult(isVoted);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("isVoted error is:" + e.getMessage());
			result.setStatus(Status.ERROR);
			result.setResult(false);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":isVoted method end...");
		return result;
	}

	/**
	 * 
	 * 判读当前IP是否对当前诊所投票
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<WjkmjDetail> findByProperties(Map<String, Object> map) {
		return this.wjkmjDetailMapper.findByProperties(map);
	}

	/**
	 * 
	 * 判读当前IP是否对当前诊所投票
	 * 
	 */
	@Override
	public List<WjkmjDetail> getByDate(Map<String, Object> map) {
		return this.wjkmjDetailMapper.getByDate(map);
	}

	/**
	 * 从DB中，根据COUNT_DATE获取投票记录
	 * 
	 * @param requestId
	 * @param voteDate
	 * @return
	 */
	private JsonResponse<List<WjkmjDayCount>> getWjkmjDayCountList(String requestId, Date voteDate) {
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":getWjkmjDayCountList method start...");
		JsonResponse<List<WjkmjDayCount>> result = new JsonResponse<List<WjkmjDayCount>>();
		WjkmjDayCountExample example = new WjkmjDayCountExample();
		try {
			example.createCriteria().andCountDateEqualTo(voteDate);
			List<WjkmjDayCount> wjkmjDayCountList = wjkmjDayCountMapper.selectByExample(example);
			result.setResult(wjkmjDayCountList);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("getWjkmjDayCountShowList error is:" + e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		logger.info("requestId:" + requestId + "," + CLASS_NAME + ":getWjkmjDayCountList method end...");
		return result;
	}

	private void getWjkmjDayCountFromMongoDB(List<WjkmjDayCount> wjkmjDayCountList, Date voteDate, String userIp) {
		logger.info("getWjkmjDayCountFromMongoDB method start...");
		Date start = new Date();
		if (wjkmjDayCountList != null && wjkmjDayCountList.size() > 0) {
			List<String> clinicIds = new ArrayList<String>();
			for (int i = 0; i < wjkmjDayCountList.size(); i++) {
				clinicIds.add(wjkmjDayCountList.get(i).getClinicId());
			}

			// 从MongoDB中获得group by clinic，voteDate的统计数据
			List<WjkmjDayCount> wjkmjDayCountMogo = wjkmjDiaryRepository.getWjkmjDayCountListMongo(voteDate, clinicIds);
			HashMap<String, Integer> wjkmjDayCountMap = new HashMap<String, Integer>();
			for (int i = 0; i < wjkmjDayCountMogo.size(); i++) {
				wjkmjDayCountMap.put(wjkmjDayCountMogo.get(i).getClinicId(), wjkmjDayCountMogo.get(i).getVoteToday());
			}

			HashMap<String, String> wjkmjDayIsVoteMap = new HashMap<String, String>();
			// 获得group by
			// clinicId,countDate,userIp的统计数据，用以判断用户今天对这家诊所是否已经投过票
			if (!StringUtils.isBlank(userIp)) {
				List<WjkmjDayCount> wjkmjDayIsVoteMogo = wjkmjDiaryRepository.getWjkmjDayIsVoteListMongo(voteDate,
						clinicIds, userIp);
				for (int i = 0; i < wjkmjDayIsVoteMogo.size(); i++) {
					wjkmjDayIsVoteMap.put(wjkmjDayIsVoteMogo.get(i).getClinicId(),
							wjkmjDayIsVoteMogo.get(i).getIsVoted());
				}
			}

			// 根据从MYSQL和MongoDB中获取的记录，计算诊所当前的总投票数
			for (WjkmjDayCount wjkmjDayCount : wjkmjDayCountList) {
				Integer showCount = wjkmjDayCount.getOperateCount() + wjkmjDayCount.getRandomCount()
						+ wjkmjDayCount.getVoteCount() + wjkmjDayCount.getOperateToday()
						+ wjkmjDayCount.getRandomToday() + wjkmjDayCount.getVoteToday();
				if (!wjkmjDayCountMap.isEmpty() && wjkmjDayCountMap.containsKey(wjkmjDayCount.getClinicId())) {
					if (wjkmjDayCountMap.get(wjkmjDayCount.getClinicId()) != null) {
						showCount += wjkmjDayCountMap.get(wjkmjDayCount.getClinicId());
					}
				}

				if (!wjkmjDayIsVoteMap.isEmpty() && wjkmjDayIsVoteMap.containsKey(wjkmjDayCount.getClinicId())) {
					String isVoted = wjkmjDayIsVoteMap.get(wjkmjDayCount.getClinicId());
					if (isVoted == null) {
						wjkmjDayCount.setIsVoted("0");
					} else {
						wjkmjDayCount.setIsVoted(isVoted);
					}
				} else {
					wjkmjDayCount.setIsVoted("0");
				}
				wjkmjDayCount.setShowCount(showCount);
				wjkmjDayCount.setCountDate(voteDate);
			}
		}

		Date end = new Date();
		logger.info("getWjkmjDayCountFromMongoDB method end and cost " + (end.getTime() - start.getTime()));
	}

	/**
	 * 获取投票每天产生的随机数
	 * 
	 * @return
	 */
	private Integer getRandom() {
		Integer result = new Integer("0");
		// 判断月份
		int a, b, c, d, p, n = 0;
		String numbers = "";
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int month = cal.get(Calendar.MONTH) + 1;
		if (month <= 7) {// 7月
			numbers = numbersForCTC.split(";")[0];
		} else if (month == 8) {// 8月
			numbers = numbersForCTC.split(";")[1];
		} else {// 9月
			numbers = numbersForCTC.split(";")[2];
		}
		a = Integer.parseInt(numbers.split(",")[0]);
		b = Integer.parseInt(numbers.split(",")[1]);
		c = Integer.parseInt(numbers.split(",")[2]);
		d = Integer.parseInt(numbers.split(",")[3]);
		p = Integer.parseInt(numbers.split(",")[4]);
		Random random = new Random();
		if (random.nextInt(100) > p) {
			n = 0;
		} else {
			n = 1;
		}
		result += random.nextInt(b) % (b - a + 1) + a; // a-b 之间的随机数
		result += (random.nextInt(d) % (d - c + 1) + c) * n; // (c-d 之间的随机数)*n
		return result;
	}
}
