package com.wanjia.dsi.product.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.exceptions.ServiceException;
import com.wanjia.dsi.product.dao.mapper.HyPrdAgreementPrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.HyPrdClinicConfigMapper;
import com.wanjia.dsi.product.model.HyPrdAgreementPrdInfo;
import com.wanjia.dsi.product.model.HyPrdAgreementPrdInfoExample;
import com.wanjia.dsi.product.model.HyPrdClinicConfig;
import com.wanjia.dsi.product.model.HyPrdClinicConfigExample;
import com.wanjia.dsi.product.service.HyPrdClinicConfigService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class HyPrdClinicConfigServiceImpl implements HyPrdClinicConfigService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private HyPrdClinicConfigMapper hyPrdClinicConfigMapper;
	
	@Resource
	private HyPrdAgreementPrdInfoMapper hyPrdAgreementPrdInfoMapper;

	@Override
	public JsonResponse<HyPrdClinicConfig> getPrdConfigByClinic(String prdId,String clinicId) {
		// 返回参数
		JsonResponse<HyPrdClinicConfig> res = new JsonResponse<HyPrdClinicConfig>();

		// 数据校验
		if (StringUtils.isBlank(prdId)) {
			throw new ServiceException("ERROR1", "【产品ID】不能为空！");
		}
		if (StringUtils.isBlank(clinicId)) {
			throw new ServiceException("ERROR1", "【诊所ID】不能为空！");
		}

		// 先查询合同预约时间配置
		HyPrdClinicConfigExample example = new HyPrdClinicConfigExample();
		HyPrdClinicConfigExample.Criteria criteria = example.createCriteria();
		criteria.andProductIdEqualTo(prdId);
		criteria.andClinicIdEqualTo(clinicId);
		criteria.andSourceFlagEqualTo("1");
		criteria.andDelFlagEqualTo("0");
		List<HyPrdClinicConfig> hyPrdClinicConfigList = hyPrdClinicConfigMapper.selectByExample(example);
		if (CollectionUtils.isNotEmpty(hyPrdClinicConfigList)) {
			// 循环判断配置是否有效,存在有效的，直接返回
			for(HyPrdClinicConfig item:hyPrdClinicConfigList)
			{
				HyPrdAgreementPrdInfoExample prdExample = new HyPrdAgreementPrdInfoExample();
				HyPrdAgreementPrdInfoExample.Criteria prdCriteria = prdExample.createCriteria();
				prdCriteria.andSubAgreementIdEqualTo(item.getSubAgreementId());
				HyPrdAgreementPrdInfo hyPrdAgreementPrdInfo = hyPrdAgreementPrdInfoMapper.selectByExample(prdExample).get(0);
				if (new Date().compareTo(hyPrdAgreementPrdInfo.getBeginDate()) >= 0
						&& new Date().compareTo(hyPrdAgreementPrdInfo.getEndDate()) <= 0) {
					res.setResult(item);
					res.setStatus(Status.SUCCESS);
					return res;
				}
			}
		}

		// 再查询产品预约时间配置
		HyPrdClinicConfigExample example1 = new HyPrdClinicConfigExample();
		HyPrdClinicConfigExample.Criteria criteria1 = example1.createCriteria();
		criteria1.andProductIdEqualTo(prdId);
		criteria1.andClinicIdEqualTo(clinicId);
		criteria1.andSourceFlagEqualTo("0");
		criteria1.andDelFlagEqualTo("0");
		List<HyPrdClinicConfig> hyPrdClinicConfigList1 = hyPrdClinicConfigMapper.selectByExample(example1);
		if (CollectionUtils.isNotEmpty(hyPrdClinicConfigList1)) {
			// 数据返回
			HyPrdClinicConfig hyPrdClinicConfig = hyPrdClinicConfigList1.get(0);
			res.setResult(hyPrdClinicConfig);
			res.setStatus(Status.SUCCESS);
			return res;
		}
		res.setStatus(Status.SUCCESS);
		return res;
	}
}
