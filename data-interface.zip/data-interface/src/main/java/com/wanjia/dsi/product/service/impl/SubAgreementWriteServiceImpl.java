package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.product.dao.mapper.FrameAgreementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdClinicConfigMapper;
import com.wanjia.dsi.product.dao.mapper.PrdFrameworkAgreementLogMapper;
import com.wanjia.dsi.product.dao.mapper.PrdRatioSettlementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdSubAgreementMapper;
import com.wanjia.dsi.product.model.FrameAgreement;
import com.wanjia.dsi.product.model.PrdAgreementClinic;
import com.wanjia.dsi.product.model.PrdAgreementPrdinfo;
import com.wanjia.dsi.product.model.PrdClinicConfig;
import com.wanjia.dsi.product.model.PrdFrameworkAgreementLog;
import com.wanjia.dsi.product.model.PrdRatioSettlement;
import com.wanjia.dsi.product.model.PrdSubAgreement;
import com.wanjia.dsi.product.service.SubAgreementWriteService;
import com.wanjia.dsi.product.vo.VOCheckClinicAndPrdServerTime;

@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class SubAgreementWriteServiceImpl implements SubAgreementWriteService {

	private Logger logger = LoggerFactory.getLogger(SubAgreementWriteServiceImpl.class);

	@Autowired
	private PrdSubAgreementMapper prdSubAgreementMapper;

	@Autowired
	private PrdAgreementClinicMapper prdAgreementClinicMapper;

	@Autowired
	private PrdAgreementPrdinfoMapper prdAgreementPrdinfoMapper;

	@Autowired
	private PrdFrameworkAgreementLogMapper prdFrameworkAgreementLogMapper;
	
	@Autowired
	private FrameAgreementMapper frameAgreementMapper;
	
	@Autowired
	private PrdRatioSettlementMapper prdRatioSettlementMapper;
	
	@Autowired
	private PrdClinicConfigMapper prdClinicConfigMapper;
	
	@Override
	@SuppressWarnings("unchecked")
	public JsonResponse<Void> saveSubAgreement(Map<String, Object> map) {

		JsonResponse<Void> jr = new JsonResponse<Void>();

		PrdSubAgreement prdSubAgreement = (PrdSubAgreement) map.get("prdSubAgreement");
		List<PrdAgreementClinic> prdAgreementClinicList = (List<PrdAgreementClinic>) map.get("prdAgreementClinicList");
	    List<PrdAgreementPrdinfo> prdAgreementPrdinfoList = (List<PrdAgreementPrdinfo>) map.get("prdAgreementPrdinfoList");
	    List<PrdRatioSettlement> prdRatioSettlementsList = (List<PrdRatioSettlement>) map.get("prdRatioSettlementsList");
	    List<PrdClinicConfig> prdClinicConfigList = (List<PrdClinicConfig>) map.get("prdClinicConfigList");
	    
	    List<String> concatIdList = new ArrayList<String>();
	    for(PrdAgreementClinic clinic:prdAgreementClinicList){
	        for(PrdAgreementPrdinfo prdinfo:prdAgreementPrdinfoList){
	            String concatId = clinic.getClinicId()+"|"+prdinfo.getPrdId();
	            concatIdList.add(concatId);
	        }
	    }
	    
	    JsonResponse<Boolean> checkJr = checkClinicAndPrdServerTime(concatIdList, prdAgreementClinicList, prdAgreementPrdinfoList);
	    if(checkJr.getResult()){
	        jr.setStatus(Status.ERROR);
	        jr.setErrorMsg(checkJr.getSuccessMsg().toString());
	        return jr;
	    }
	    
	    String status = "";
		if (null == prdSubAgreement) {
			logger.error("prdSubAgreement can not be null");
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("prdSubAgreement can not be null");
			return jr;
		}
		
		long checkPrdSubAgreement = prdSubAgreementMapper.countByProperty("id", prdSubAgreement.getId());
		if (checkPrdSubAgreement > 0) {
		    PrdSubAgreement old =  prdSubAgreementMapper.findById(prdSubAgreement.getId());
		    if("2".equals(old.getSubStatus())){
		        prdSubAgreement.setSubStatus("1");//续期
		    }
			prdSubAgreementMapper.update(prdSubAgreement);
			status = "4";//编辑
		} else {
			prdSubAgreementMapper.insert(prdSubAgreement);
			status = "6";//附属合同创建
		}

		
		Map<String, Object> oldClinicListMap = new HashMap<String, Object>();
		oldClinicListMap.put("delFlag", "0");
		oldClinicListMap.put("subAgreementId", prdSubAgreement.getId());
		List<PrdAgreementClinic> oldClinicList = prdAgreementClinicMapper.findByProperties(oldClinicListMap);
		// 循环中更新数据库
		for (PrdAgreementClinic pac : oldClinicList) {
			pac.setDelFlag("1");
			prdAgreementClinicMapper.update(pac);
		}

		if (prdAgreementClinicList != null && prdAgreementClinicList.size() > 0) {
			prdAgreementClinicMapper.insertBatch(prdAgreementClinicList);
		}

		Map<String, Object> oldPrdInfoListMap = new HashMap<String, Object>();
		oldPrdInfoListMap.put("delFlag", "0");
		oldPrdInfoListMap.put("subAgreementId", prdSubAgreement.getId());
		List<PrdAgreementPrdinfo> oldPrdInfoList = prdAgreementPrdinfoMapper.findByProperties(oldPrdInfoListMap);
		for (PrdAgreementPrdinfo pap : oldPrdInfoList) {
			pap.setDelFlag("1");
			prdAgreementPrdinfoMapper.update(pap);
		}

		if (prdAgreementPrdinfoList != null && prdAgreementPrdinfoList.size() > 0) {
			prdAgreementPrdinfoMapper.insertBatch(prdAgreementPrdinfoList);
		}
		
		Map<String,Object> oldPrdRatioSettlementMap = new HashMap<String,Object>();
		oldPrdRatioSettlementMap.put("delFlag", "0");
		oldPrdRatioSettlementMap.put("subAgreementId", prdSubAgreement.getId());
        List<PrdRatioSettlement> oldPrdRatioSettlementList = prdRatioSettlementMapper.findByProperties(oldPrdRatioSettlementMap);
        for(PrdRatioSettlement prsl : oldPrdRatioSettlementList){
            prsl.setDelFlag("1");
            prdRatioSettlementMapper.update(prsl);
        }
        
        if (prdRatioSettlementsList != null && prdRatioSettlementsList.size() > 0) {
            prdRatioSettlementMapper.insertBatch(prdRatioSettlementsList);
        }
        
        Map<String,Object> oldClinicConfigMap = new HashMap<String,Object>();
        oldClinicConfigMap.put("delFlag", "0");
        oldClinicConfigMap.put("subAgreementId", prdSubAgreement.getId());
        List<PrdClinicConfig> oldClinicConfigList = prdClinicConfigMapper.findByProperties(oldClinicConfigMap);
        for(PrdClinicConfig pcc : oldClinicConfigList){
            pcc.setDelFlag("1");
            prdClinicConfigMapper.updateByPrimaryKeySelective(pcc);
        }
        
        if (prdClinicConfigList != null && prdClinicConfigList.size() > 0) {
            prdClinicConfigMapper.insertBatch(prdClinicConfigList);
        }
        
        
		PrdFrameworkAgreementLog frameworkAgreementLog = new PrdFrameworkAgreementLog();
		frameworkAgreementLog.setId(UUID.randomUUID().toString());
		frameworkAgreementLog.setAgreementId(prdSubAgreement.getAgreementId());
		frameworkAgreementLog.setSubAgreementId(prdSubAgreement.getId());
		frameworkAgreementLog.setContractName(prdSubAgreement.getContractName());
		frameworkAgreementLog.setContractNo(prdSubAgreement.getContractNo());
		frameworkAgreementLog.setStatus(status);
		frameworkAgreementLog.setOperator(prdSubAgreement.getModifyUser());
		frameworkAgreementLog.setOperatorDate(prdSubAgreement.getModifyDate());
		frameworkAgreementLog.setCreateDate(prdSubAgreement.getModifyDate());
		frameworkAgreementLog.setCreateUser(prdSubAgreement.getCreateUser());
		frameworkAgreementLog.setModifyDate(prdSubAgreement.getModifyDate());
		frameworkAgreementLog.setModifyUser(prdSubAgreement.getModifyUser());
		frameworkAgreementLog.setDelFlag("0");
		prdFrameworkAgreementLogMapper.insert(frameworkAgreementLog);
		
		jr.setStatus(Status.SUCCESS);
		jr.setSuccessMsg("提交成功");
		return jr;
	}
    
    @Override
    public JsonResponse<Void> updateSubAgreementStatus(Map<String,Object> map){
        
        JsonResponse<Void> jr = new JsonResponse<Void>();
        String userName = "";
        String subAgreementId = "";
        String status = "";//日志操作状态
        try{
            if(map.containsKey("subAgreementId")){
                subAgreementId = map.get("subAgreementId").toString();
                if(map.containsKey("userName")){
                    userName = map.get("userName").toString();
                }
                
                PrdSubAgreement prdSubAgreement = prdSubAgreementMapper.findById(subAgreementId);
                FrameAgreement frameAgreement = frameAgreementMapper.findById(prdSubAgreement.getAgreementId());
                
                if(map.containsKey("subStatus")){
                    String subStatus = map.get("subStatus").toString();
                    
                    if("2".equals(frameAgreement.getStatus())&&"1".equals(subStatus)){
                        jr.setErrorMsg("框架合同状态已终止,附属合同不能生效！");
                        jr.setStatus(Status.ERROR);
                        return jr;
                    }
                    
                    
                    if("1".equals(subStatus) && "1".equals(prdSubAgreement.getSubStatus())){
                        jr.setErrorMsg("该合同状态已经改变，请刷新后再试！");
                        jr.setStatus(Status.ERROR);
                        return jr;
                    }
                    
                    if("2".equals(subStatus) && !"1".equals(prdSubAgreement.getSubStatus())){
                        jr.setErrorMsg("该合同状态已经改变，请刷新后再试！");
                        jr.setStatus(Status.ERROR);
                        return jr;
                    }
                    
                    status = subStatus;
                    
                    prdSubAgreement.setSubStatus(subStatus);
                    if(map.containsKey("userName")){
                        prdSubAgreement.setModifyUser(userName);
                    }
                    prdSubAgreement.setModifyDate(new Date());
                    prdSubAgreementMapper.update(prdSubAgreement);
                }
                
                if(map.containsKey("delFlag")){
                    
                    status = "5";//日志操作状态为删除
                    
                    String delFlag = map.get("delFlag").toString();
                    prdSubAgreement.setDelFlag(delFlag);
                    prdSubAgreement.setModifyDate(new Date());
                    prdSubAgreement.setModifyUser(userName);
                    prdSubAgreementMapper.update(prdSubAgreement);
                    
                    Map<String,Object> clinicMap = new HashMap<String,Object>();
                    clinicMap.put("subAgreementId", subAgreementId);
                    clinicMap.put("clinicType", "2");//查询单体诊所
                    clinicMap.put("delFlag", "0");
                    List<PrdAgreementClinic> prdAgreementClinicList = prdAgreementClinicMapper.findByProperties(clinicMap);
                    for(PrdAgreementClinic prdAgreementClinic : prdAgreementClinicList){
                        prdAgreementClinic.setDelFlag(delFlag);
                        prdAgreementClinic.setModifyUser(userName);
                        prdAgreementClinic.setModifyUser(userName);
                        prdAgreementClinicMapper.update(prdAgreementClinic);
                    }
                    
                    Map<String,Object> prdMap = new HashMap<String,Object>();
                    prdMap.put("subAgreementId", subAgreementId);
                    prdMap.put("delFlag", "0");
                    List<PrdAgreementPrdinfo> prdAgreementPrdinfoList = prdAgreementPrdinfoMapper.findByProperties(prdMap);
                    for(PrdAgreementPrdinfo PrdAgreementPrdinfo : prdAgreementPrdinfoList){
                        PrdAgreementPrdinfo.setDelFlag(delFlag);
                        PrdAgreementPrdinfo.setModifyUser(userName);
                        PrdAgreementPrdinfo.setModifyUser(userName);
                        prdAgreementPrdinfoMapper.update(PrdAgreementPrdinfo);
                    }
                }
                
                PrdFrameworkAgreementLog frameworkAgreementLog = new PrdFrameworkAgreementLog();
                frameworkAgreementLog.setId(UUID.randomUUID().toString());
                frameworkAgreementLog.setAgreementId(prdSubAgreement.getAgreementId());
                frameworkAgreementLog.setSubAgreementId(prdSubAgreement.getId());
                frameworkAgreementLog.setContractName(prdSubAgreement.getContractName());
                frameworkAgreementLog.setContractNo(prdSubAgreement.getContractNo());
                frameworkAgreementLog.setStatus(status);
                frameworkAgreementLog.setOperator(prdSubAgreement.getModifyUser());
                frameworkAgreementLog.setOperatorDate(prdSubAgreement.getModifyDate());
                frameworkAgreementLog.setCreateDate(prdSubAgreement.getModifyDate());
                frameworkAgreementLog.setCreateUser(prdSubAgreement.getCreateUser());
                frameworkAgreementLog.setModifyDate(prdSubAgreement.getModifyDate());
                frameworkAgreementLog.setModifyUser(prdSubAgreement.getModifyUser());
                frameworkAgreementLog.setDelFlag("0");
                prdFrameworkAgreementLogMapper.insert(frameworkAgreementLog);
                
            }else{
                jr.setErrorMsg("附属合同ID为空");
                jr.setStatus(Status.ERROR);
                logger.error("附属合同ID为空");
                return jr;
            }
        }catch(Exception e){
            logger.error("更新附属合同状态出错,agreementId="+subAgreementId,e);
            jr.setErrorMsg("更新附属合同状态出错,agreementId="+subAgreementId);
            jr.setStatus(Status.ERROR);
            return jr;
        }
        jr.setStatus(Status.SUCCESS);
        jr.setSuccessMsg("提交成功");
        return jr;
    }
    
    @Override
    public JsonResponse<Void> terminateContractQuartz(){
        JsonResponse<Void> jr = new JsonResponse<Void>();
        long updateNumber = 0;
        
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("delFlag","0");
        map.put("subStatus", "1");
        List<PrdSubAgreement> prdSubAgreementList = prdSubAgreementMapper.findByProperties(map);
        
        for(PrdSubAgreement prdSubAgreement:prdSubAgreementList){
            try{
                Date endMaxDate = prdAgreementPrdinfoMapper.findMaxPrdEndDateBySubAgreementId(prdSubAgreement.getId());
                Date nowDate = new Date();
                if(null != endMaxDate){
                    if(endMaxDate.getTime()+3*60*60*1000 < nowDate.getTime()){//定时任务是每天1点执行，加3个小时，防止把当天的时间截止掉
                        prdSubAgreement.setSubStatus("2");//终止
                        prdSubAgreementMapper.update(prdSubAgreement);
                        updateNumber++;
                        
                        PrdFrameworkAgreementLog frameworkAgreementLog = new PrdFrameworkAgreementLog();
                        frameworkAgreementLog.setId(UUID.randomUUID().toString());
                        frameworkAgreementLog.setAgreementId(prdSubAgreement.getAgreementId());
                        frameworkAgreementLog.setSubAgreementId(prdSubAgreement.getId());
                        frameworkAgreementLog.setContractName(prdSubAgreement.getContractName());
                        frameworkAgreementLog.setContractNo(prdSubAgreement.getContractNo());
                        frameworkAgreementLog.setStatus("2");
                        frameworkAgreementLog.setOperator(prdSubAgreement.getModifyUser());
                        frameworkAgreementLog.setOperatorDate(prdSubAgreement.getModifyDate());
                        frameworkAgreementLog.setCreateDate(new Date());
                        frameworkAgreementLog.setCreateUser("System");
                        frameworkAgreementLog.setModifyDate(new Date());
                        frameworkAgreementLog.setModifyUser("System");
                        frameworkAgreementLog.setDelFlag("0");
                        prdFrameworkAgreementLogMapper.insert(frameworkAgreementLog);
                    }
                }
            }catch(Exception e){
                logger.error("更新附属合同状态出错,subAgreementId="+prdSubAgreement.getId(),e);
                jr.setStatus(Status.ERROR);
                jr.setErrorCode(ErrorType.SystemBusy.getCode());
                jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
            }
        }
        logger.info("生效的附属合同总数:"+prdSubAgreementList.size()+",更新的附属合同总数:"+updateNumber);
        
        jr.setStatus(Status.SUCCESS);
        jr.setSuccessMsg("生效的附属合同总数:"+prdSubAgreementList.size()+",更新的附属合同总数:"+updateNumber);
        return jr;
    }
    
    /**
     * 同一产品在不同附加合同中对应同一诊所，服务期限不能重叠
     * 该方法用于校验同一个诊所，同一个产品，在不同附属合同中的服务期限是否重复
     * @return
     */
    private JsonResponse<Boolean> checkClinicAndPrdServerTime(List<String> concatId,List<PrdAgreementClinic> clinicList,List<PrdAgreementPrdinfo> prdList){
        
        logger.info("======开始校验合同期限,concatId.size="+concatId.size());
        
        for(String id : concatId){
            logger.info("======开始校验合同期限,concatId="+id);
        }
        
        List<VOCheckClinicAndPrdServerTime> list = prdAgreementPrdinfoMapper.checkClinicAndPrdServerTime(concatId);
        JsonResponse<Boolean> jr = new JsonResponse<Boolean>(false);
        logger.info("======开始校验合同期限,list.size="+list.size());
        for(VOCheckClinicAndPrdServerTime clinicAndPrdServerTime:list){
            logger.info("=========concatId==========="+clinicAndPrdServerTime.getConcatId());
            if(concatId.contains(clinicAndPrdServerTime.getConcatId())){
                for(int i=0;i<prdList.size();i++){
                    
                    if(prdList.get(i).getSubAgreementId().equals(clinicAndPrdServerTime.getSubAgreementId())){
                        continue;
                    }
                    
                    logger.info("=========clinicAndPrdServerTime.getPrdId()==========="+clinicAndPrdServerTime.getPrdId());
                    logger.info("=========prdList.get(i).getPrdId()==========="+prdList.get(i).getPrdId());
                    if(clinicAndPrdServerTime.getPrdId().equals(prdList.get(i).getPrdId())){
                        if(clinicAndPrdServerTime.getBeginDate().getTime()<=prdList.get(i).getEndDate().getTime()
                                &&clinicAndPrdServerTime.getBeginDate().getTime()>=prdList.get(i).getBeginDate().getTime()){
                            jr.setResult(true);
                            jr.setSuccessMsg(clinicAndPrdServerTime.getClinicName()+"中的"+clinicAndPrdServerTime.getCouponName()+"服务期限与《"+clinicAndPrdServerTime.getContractName()+"》中该产品的服务期限有重叠，请重新选择服务时间！");
                            logger.info(clinicAndPrdServerTime.getClinicName()+"中的"+clinicAndPrdServerTime.getCouponName()+"服务期限与附属合同《"+clinicAndPrdServerTime.getContractName()+"》中该产品的服务期限有重叠，请重新选择服务时间！");
                            return jr;
                        }
                        if(clinicAndPrdServerTime.getEndDate().getTime()>=prdList.get(i).getBeginDate().getTime()
                                &&clinicAndPrdServerTime.getEndDate().getTime()<=prdList.get(i).getEndDate().getTime()){
                            jr.setResult(true);
                            jr.setSuccessMsg(clinicAndPrdServerTime.getClinicName()+"中的"+clinicAndPrdServerTime.getCouponName()+"服务期限与《"+clinicAndPrdServerTime.getContractName()+"》中该产品的服务期限有重叠，请重新选择服务时间！");
                            logger.info(clinicAndPrdServerTime.getClinicName()+"中的"+clinicAndPrdServerTime.getCouponName()+"服务期限与附属合同《"+clinicAndPrdServerTime.getContractName()+"》中该产品的服务期限有重叠，请重新选择服务时间！");
                            return jr;
                        }
                    }
                }
                
            }
        }
        
        return jr;
    }
}
