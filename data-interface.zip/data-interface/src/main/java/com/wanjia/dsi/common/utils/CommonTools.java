package com.wanjia.dsi.common.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
/*import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;*/
import org.apache.log4j.Logger;
import org.springframework.util.DigestUtils;

import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdOrderDetail;

public class CommonTools {

	public static Logger logger = Logger.getLogger(CommonTools.class);

	public final static double PI = Math.PI; // 圆周率

	public final static double R = 6371393; // 地球的半径,米

	public static final String STRING_EMPTY = "";

	public static final String GBK = "gbk";

	public static final String NULL = "null";

	public static final String N_ONLY = "N";

	public static final String L_ONLY = "L";

	public static final String NUMBER = "0123456789";

	public static final String LETTER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	public static final String ISO_8859_1 = "iso-8859-1";

	public static final String STR_ZERO = "0";

	public static final double DOUBLE_ZERO = 0;

	public static final String DATE_SHORT = "yyyy-MM-dd";

	public static final String DATE_LONG = "yyyy-MM-dd HH:mm:ss";

	public static final String MAIL = "^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$+";

	public static final String MOBILE = "^[1][0-9][0-9]{9}$";

	private String message;

	private BufferedReader readTextBuffer;

	private CommonTools() {
		// 禁止该类被实例化
	}

	/****
	 * 生成UUID
	 * 
	 * @return
	 */
	public static String generateUUID() {
		return UUID.randomUUID().toString();
	}

	public static int getRandom() {
		int max = 200000;
		int min = 10;
		Random random = new Random();

		return random.nextInt(max) % (max - min + 1) + min;
	}

	public static String getRandomString(int length) {
		String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";// 含有字符和数字的字符串
		Random random = new Random();// 随机类初始化
		StringBuffer sb = new StringBuffer();// StringBuffer类生成，为了拼接字符串

		for (int i = 0; i < length; ++i) {
			int number = random.nextInt(62);// [0,62)

			sb.append(str.charAt(number));
		}
		return sb.toString();
	}

	/**
	 * app版本号的处理方法.如1.2.11 会转为1.211,以便进行版本比较.
	 * 
	 * @param str
	 * @return
	 */
	public static double getStringToDouble(String str) {
		try {
			if (StringUtils.isNotBlank(str)) {
				return Double.valueOf(str.substring(0, 2) + str.substring(2, str.length()).replace(".", ""));
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	/***
	 * url解码
	 * 
	 * @param value
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String getUrlDecode(String value) throws UnsupportedEncodingException {
		value = new String(value.getBytes("iso-8859-1"), "utf-8");
		return java.net.URLDecoder.decode(value, "UTF-8");
	}

	/**
	 * 判断字符串是否包含{}
	 * 
	 * @param inputString
	 * @return
	 */
	public static final boolean isNotIncludeBrace(String inputString) {

		if (nullOrEmpty(inputString)) {
			if (inputString.indexOf('{') > -1 || inputString.indexOf('}') > -1) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 是否为字母或者数字
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isNumAndLetter(String str) {
		if (str.matches("\\w*")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 手机号验证
	 * 
	 * @param str
	 * @return 验证通过返回true
	 */
	public static boolean isMobile(String str) {
		if (str == null) {
			return false;
		}
		return Pattern.compile(MOBILE).matcher(str).matches();
	}

	/**
	 * 验证邮箱格式
	 * 
	 * @param strEmail
	 * @return
	 */
	public static boolean isEmail(String strEmail) {
		Pattern p = Pattern.compile(MAIL, Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(strEmail);
		return m.matches();
	}

	/**
	 * 判断对象是否为null或者为空
	 * 
	 * @param object
	 *            判断的对象
	 * @return
	 */
	public static boolean nullOrEmpty(Object object) {
		return object == null || STRING_EMPTY.equals(object.toString().trim());
	}

	/**
	 * 判断对象是否为null或者为空
	 * 
	 * @param object
	 *            判断的对象
	 * @return
	 */
	public static boolean notNullAndEmpty(Object object) {
		return nullOrEmpty(object) ? false : true;
	}

	/**
	 * 获取对象的String值
	 * 
	 * @param object
	 *            操作的对象
	 * @return
	 */
	public static String getStrValue(Object object) {
		if (nullOrEmpty(object)) {
			return STRING_EMPTY;
		} else {
			return object.toString().trim();
		}
	}

	/**
	 * 获取对象的int值[譬如:String型的"1.25"，用Integer.valueOf().intValue()或者Integer.
	 * parseInt()都会抛出异常，需先转换为double]
	 * 
	 * @param object
	 *            被转换的对象
	 * @return
	 */
	public static int getIntValue(Object object) {
		return (int) getDoubleValue(object);
	}

	/**
	 * 获取对象的double值
	 * 
	 * @param object
	 *            被转换的对象
	 * @return
	 */
	public static double getDoubleValue(Object object) {
		try {
			return Double.valueOf(getStrValue(object)).doubleValue();
		} catch (Exception ex) {
			return DOUBLE_ZERO;
		}
	}

	/**
	 * 得到当前系统时间，返回String类型，格式为"yyyy-MM-dd"
	 * 
	 * @return
	 */
	public static String getSysyyyyMMdd() {
		SimpleDateFormat f = new SimpleDateFormat(DATE_SHORT);
		return f.format(new Date());
	}

	/**
	 * 得到当前系统时间，返回Date类型，格式为yyyy-MM-dd
	 * 
	 * @return
	 */
	public static Date getSysShortDate() {
		SimpleDateFormat f = new SimpleDateFormat(DATE_SHORT);
		try {
			return f.parse(getSysyyyyMMdd());
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 得到当前系统时间 返回String类型，格式为"yyyy-MM-dd HH:mm:ss"
	 * 
	 * @return
	 */
	public static String getSysyyyyMMddHHmmss() {
		SimpleDateFormat f = new SimpleDateFormat(DATE_LONG);
		return f.format(new Date());
	}

	/**
	 * 得到当前系统时间 返回Date类型，格式为yyyy-MM-dd HH:mm:ss
	 * 
	 * @return
	 */
	public static Date getSysLongDate() {
		SimpleDateFormat f = new SimpleDateFormat(DATE_LONG);
		try {
			return f.parse(getSysyyyyMMddHHmmss());
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 将String型日期转换为Date型长日期（带时分秒）
	 * 
	 * @param date
	 *            被转换的对象
	 * @return
	 */
	public static Date stringToDate(String date) {
		if (nullOrEmpty(date)) {
			return null;
		} else {
			SimpleDateFormat f = new SimpleDateFormat(DATE_LONG);
			try {
				return f.parse(getStrValue(date));
			} catch (Exception e) {
				return null;
			}
		}
	}

	/**
	 * 将Date型日期转换为String型长日期（带时分秒）
	 * 
	 * @param date
	 *            被转换的对象
	 * @return
	 */
	public static String dateToString(Date date) {
		if (nullOrEmpty(date)) {
			return STRING_EMPTY;
		} else {
			SimpleDateFormat f = new SimpleDateFormat(DATE_LONG);
			return f.format(date);
		}
	}

	/**
	 * 将String型指定格式日期转换为Date型日期
	 * 
	 * @param date
	 *            被转换的对象
	 * @param pattern
	 *            被转换的对象格式
	 * @return
	 */
	public static Date stringToDate(String date, String pattern) {
		if (nullOrEmpty(pattern)) {
			return stringToDate(date);
		} else {
			SimpleDateFormat f = new SimpleDateFormat(pattern);
			try {
				return f.parse(getStrValue(date));
			} catch (Exception e) {
				return null;
			}
		}
	}

	/**
	 * 将Date型日期转换为String型指定格式日期
	 * 
	 * @param date
	 *            被转换日期对象
	 * @param pattern
	 *            指定转换格式
	 * @return
	 */
	public static String dateToString(Date date, String pattern) {
		if (nullOrEmpty(pattern)) {
			return dateToString(date);
		} else {
			SimpleDateFormat format = new SimpleDateFormat(pattern);
			return format.format(date);
		}
	}

	/**
	 *      * Get Interval days by      *      *
	 * 
	 * @param enddate
	 *                 *
	 * @param begindate
	 *                 * @return     
	 */
	public static int getIntervalDays(Date enddate, Date begindate) {
		long millisecond = enddate.getTime() - begindate.getTime();
		int day = (int) (millisecond / 24L / 60L / 60L / 1000L);
		return day;
	}

	/**
	 * 在指定时间上增加指定年、月、日、时、分、秒，日期类型
	 * 
	 * @param date
	 *            指定日期时间
	 * @param field
	 *            需要做变更的日历时间域
	 * @param value
	 *            增加的时间
	 * @return
	 */
	public static Date markDate(Date date, int field, int value) {
		if (nullOrEmpty(date)) {
			return null;
		} else {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			switch (field) {
			case Calendar.YEAR:
				calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) + value);
				break;
			case Calendar.MONTH:
				calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + value);
				break;
			case Calendar.DAY_OF_YEAR:
				calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) + value);
				break;
			case Calendar.HOUR:
				calendar.set(Calendar.HOUR, calendar.get(Calendar.HOUR) + value);
				break;
			case Calendar.MINUTE:
				calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + value);
				break;
			case Calendar.SECOND:
				calendar.set(Calendar.SECOND, calendar.get(Calendar.SECOND) + value);
				break;
			default:
				break;
			}
			return calendar.getTime();
		}
	}

	/**
	 * double型在做运算时会失去精度，高精度数据运算需要用BigDecimal，同时必须用String来构造
	 */

	/**
	 * 高精度加法运算
	 * 
	 * @param data1
	 *            加数
	 * @param data2
	 *            被加数
	 * @return
	 */
	public static double addition(Object data1, Object data2) {
		return new BigDecimal(getStrValue(getDoubleValue(data1))).add(new BigDecimal(getStrValue(getDoubleValue(data2)))).doubleValue();
	}

	/**
	 * 高精度减法运算
	 * 
	 * @param data1
	 *            减数
	 * @param data2
	 *            被减数
	 * @return
	 */
	public static double subduction(Object data1, Object data2) {
		return new BigDecimal(getStrValue(getDoubleValue(data1))).subtract(new BigDecimal(getStrValue(getDoubleValue(data2)))).doubleValue();
	}

	/**
	 * 高精度乘法运算
	 * 
	 * @param data1
	 *            乘数
	 * @param data2
	 *            被乘数
	 * @return
	 */
	public static double multiplication(Object data1, Object data2) {
		return new BigDecimal(getStrValue(getDoubleValue(data1))).multiply(new BigDecimal(getStrValue(getDoubleValue(data2)))).doubleValue();
	}

	/**
	 * 高精度除法运算
	 * 
	 * @param data1
	 *            除数
	 * @param data2
	 *            被除数
	 * @return
	 */
	public static double division(Object data1, Object data2) {
		if (getDoubleValue(data2) != DOUBLE_ZERO) {
			return new BigDecimal(getStrValue(getDoubleValue(data1))).divide(new BigDecimal(getStrValue(getDoubleValue(data2)))).doubleValue();
		} else {
			return DOUBLE_ZERO;
		}
	}

	/***
	 * 使用NIO进行快速的文件拷贝
	 * 
	 * @param in
	 * @param out
	 * @throws IOException
	 */
	public static void fileCopy(File in, File out) throws IOException {
		FileChannel inChannel = new FileInputStream(in).getChannel();
		FileChannel outChannel = new FileOutputStream(out).getChannel();
		try {
			// inChannel.transferTo(0, inChannel.size(), outChannel); //
			// original -- apparently has trouble copying large files on Windows

			// magic number for Windows, 64Mb - 32Kb)
			int maxCount = (64 * 1024 * 1024) - (32 * 1024);
			long size = inChannel.size();
			long position = 0;
			while (position < size) {
				position += inChannel.transferTo(position, maxCount, outChannel);
			}
		} finally {
			if (inChannel != null) {
				inChannel.close();
			}
			if (outChannel != null) {
				outChannel.close();
			}
		}
	}

	/**
	 * 发送请求的公共方法
	 * 
	 * @param list
	 * @param url
	 * @return
	 */
	/*
	 * public String doPost(List<NameValuePair> list, String url) {
	 * 
	 * String result = null; try {
	 * 
	 * HttpEntity requesthttpEntity = new UrlEncodedFormEntity(list, "UTF-8");
	 * 
	 * HttpPost httpPost = new HttpPost(url);
	 * 
	 * httpPost.setEntity(requesthttpEntity); HttpClient httpClient = new
	 * DefaultHttpClient();
	 * 
	 * httpClient.getParams().setParameter("http.connection.timeout",
	 * Integer.valueOf(20000));
	 * 
	 * httpClient.getParams().setParameter("http.socket.timeout",
	 * Integer.valueOf(20000));
	 * 
	 * this.logger.debug(httpPost.getURI()); StringBuffer sb = new
	 * StringBuffer(); for (NameValuePair p : list) { sb.append("&" +
	 * p.getName() + "=" + p.getValue()); } this.logger.debug("param=" +
	 * sb.toString()); HttpResponse httpResponse = httpClient.execute(httpPost);
	 * if (httpResponse.getStatusLine().getStatusCode() != 200) { throw new
	 * Exception("Failed : HTTP error code : " +
	 * httpResponse.getStatusLine().getStatusCode()); }
	 * 
	 * HttpEntity httpEntity = httpResponse.getEntity(); result =
	 * EntityUtils.toString(httpEntity); } catch (Exception e) {
	 * logger.error("异常007" + e.getMessage()); } return result; }
	 */

	/**
	 * 获得IP
	 * 
	 * @param request
	 * @return
	 */
	public static String getIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		String[] ips = ip.split(",");
		for (int i = 0; i < ips.length; i++) {
			if (!"unknown".equalsIgnoreCase(ips[i])) {
				return ips[i];
			}
		}
		return null;
	}

	/**
	 * 字符日期转毫秒
	 * 
	 * @param dateStr
	 * @return
	 * @throws ParseException
	 */
	public static Long cvtLongStrFmt(String dateStr) throws ParseException {
		Long ret = null;
		if (dateStr != null) {
			String dateFmtStr = (dateStr.length() == 10 ? "yyyy-MM-dd" : "yyyy-MM-dd HH:mm:ss");
			ret = new SimpleDateFormat(dateFmtStr).parse(dateStr).getTime();
		}
		return ret;
	}

	// +++++++++++++ 加密,解密++++++++++++++++++++++++++++++++++++
	/**
	 * md5加密方法
	 * 
	 * @param source
	 *            源字符串
	 * @return 加密后的字符串
	 * @throws NoSuchAlgorithmException
	 */
	public static String md5(String source) throws NoSuchAlgorithmException {

		char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(source.getBytes());
		byte[] tmp = md.digest();
		char[] str = new char[16 * 2];

		int k = 0;
		for (int i = 0; i < 16; i++) {
			byte byte0 = tmp[i];
			str[k++] = hexDigits[byte0 >>> 4 & 0xf];
			str[k++] = hexDigits[byte0 & 0xf];
		}

		return new String(str);
	}

	/**
	 * base64解码
	 * 
	 * @param source
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String base64Decode(String source) throws UnsupportedEncodingException {
		return new String(Base64.decodeBase64(source.getBytes("UTF-8")), "UTF-8");
	}

	/**
	 * base64编码
	 * 
	 * @param source
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String base64Encode(String source) throws UnsupportedEncodingException {
		return new String(Base64.encodeBase64(source.getBytes("UTF-8")), "UTF-8");
	}

	/**
	 * 遍历文件夹中文件
	 * 
	 * @param filepath
	 * @return 返回file［］数组
	 */
	public File[] getFileList(String filepath) {
		File d = null;
		File list[] = null;
		// 建立当前目录中文件的File对象
		try {
			d = new File(filepath);
			if (d.exists()) {
				list = d.listFiles();
			}
		} catch (Exception ex) {
			message = "遍历文件夹出错";
		}
		// 取得代表目录中所有文件的File对象数组

		return list;
	}

	/**
	 * 读取文本文件内容
	 * 
	 * @param filePathAndName
	 *            带有完整绝对路径的文件名
	 * @param encoding
	 *            文本文件打开的编码方式
	 * @return 返回文本文件的内容
	 */
	public String readTxt(String filePathAndName, String encoding) throws IOException {
		encoding = encoding.trim();
		StringBuffer str = new StringBuffer("");
		String st = "";
		try {
			FileInputStream fs = new FileInputStream(filePathAndName);
			InputStreamReader isr;
			if (encoding.equals("")) {
				isr = new InputStreamReader(fs);
			} else {
				isr = new InputStreamReader(fs, encoding);
			}
			readTextBuffer = new BufferedReader(isr);
			try {
				String data = "";
				while ((data = readTextBuffer.readLine()) != null) {
					str.append(data);
				}
			} catch (Exception e) {
				str.append(e.toString());
			}
			st = str.toString();
			if (st != null && st.length() > 1)
				st = st.substring(0, st.length() - 1);
		} catch (IOException es) {
			st = "";
			logger.error("readTxt IOException", es);
		}
		return st;
	}

	/**
	 * 新建目录
	 * 
	 * @param folderPath
	 *            目录
	 * @return 返回目录创建后的路径
	 */
	public static String createFolder(String folderPath) {
		String txt = folderPath;
		try {
			java.io.File myFilePath = new java.io.File(txt);
			txt = folderPath;
			if (!myFilePath.exists()) {
				myFilePath.mkdir();
			}
		} catch (Exception e) {
			// message = "创建目录操作出错";
			logger.error("createFolder Exception 创建目录操作出错.", e);
		}
		return txt;
	}

	/**
	 * 多级目录创建
	 * 
	 * @param folderPath
	 *            准备要在本级目录下创建新目录的目录路径例如 c:myf
	 * @param paths
	 *            无限级目录参数，各级目录以单数线区分 例如 a|b|c
	 * @return 返回创建文件后的路径
	 */
	public static String createFolders(String folderPath, String paths) {
		String txts = folderPath;
		try {
			String txt;
			txts = folderPath;
			StringTokenizer st = new StringTokenizer(paths, "|");
			for (int i = 0; st.hasMoreTokens(); i++) {
				txt = st.nextToken().trim();
				if (txts.lastIndexOf("/") != -1) {
					txts = createFolder(txts + txt);
				} else {
					txts = createFolder(txts + txt + "/");
				}
			}
		} catch (Exception e) {
			// message = "创建目录操作出错";
			logger.error("createFolders Exception 多级目录创建.", e);
		}
		return txts;
	}

	/**
	 * 新建文件
	 * 
	 * @param filePathAndName
	 *            文本文件完整绝对路径及文件名
	 * @param fileContent
	 *            文本文件内容
	 * @return
	 */
	public void createFile(String filePathAndName, String fileContent) {

		try {
			String filePath = filePathAndName;
			filePath = filePath.toString();
			File myFilePath = new File(filePath);
			if (!myFilePath.exists()) {
				myFilePath.createNewFile();
			}
			FileWriter resultFile = new FileWriter(myFilePath);
			PrintWriter myFile = new PrintWriter(resultFile);
			String strContent = fileContent;
			myFile.println(strContent);
			myFile.close();
			resultFile.close();
		} catch (Exception e) {
			message = "创建文件操作出错";
			logger.error("createFile Exception 创建文件操作出错.", e);
		}
	}

	/**
	 * 有编码方式的文件创建
	 * 
	 * @param filePathAndName
	 *            文本文件完整绝对路径及文件名
	 * @param fileContent
	 *            文本文件内容
	 * @param encoding
	 *            编码方式 例如 GBK 或者 UTF-8
	 * @return
	 */
	public void createFile(String filePathAndName, String fileContent, String encoding) {

		try {
			String filePath = filePathAndName;
			filePath = filePath.toString();
			File myFilePath = new File(filePath);
			if (!myFilePath.exists()) {
				myFilePath.createNewFile();
			}
			PrintWriter myFile = new PrintWriter(myFilePath, encoding);
			String strContent = fileContent;
			myFile.println(strContent);
			myFile.close();
		} catch (Exception e) {
			message = "创建文件操作出错";
			logger.error("createFile Exception 有编码方式的文件创建.", e);
		}
	}

	/**
	 * 删除文件
	 * 
	 * @param filePathAndName
	 *            文本文件完整绝对路径及文件名
	 * @return Boolean 成功删除返回true遭遇异常返回false
	 */
	public static boolean delFile(String filePathAndName) {
		boolean bea = false;
		try {
			String filePath = filePathAndName;
			File myDelFile = new File(filePath);
			if (myDelFile.exists()) {
				myDelFile.delete();
				bea = true;
			} else {
				bea = false;
				// message = (filePathAndName + "删除文件操作出错");
			}
		} catch (Exception e) {
			// message = e.toString();
			logger.error("delFile Exception 删除文件.", e);
		}
		return bea;
	}

	/**
	 * 删除文件
	 * 
	 * @param folderPath
	 *            文件夹完整绝对路径
	 * @return
	 */
	public static void delFolder(String folderPath) {
		try {
			delAllFile(folderPath); // 删除完里面所有内容
			String filePath = folderPath;
			filePath = filePath.toString();
			java.io.File myFilePath = new java.io.File(filePath);
			myFilePath.delete(); // 删除空文件夹
		} catch (Exception e) {
			// message = ("删除文件夹操作出错");
			logger.error("delFolder Exception 删除文件.", e);
		}
	}

	/**
	 * 删除指定文件夹下所有文件
	 * 
	 * @param path
	 *            文件夹完整绝对路径
	 * @return
	 * @return
	 */
	public static boolean delAllFile(String path) {
		boolean bea = false;
		File file = new File(path);
		if (!file.exists()) {
			return bea;
		}
		if (!file.isDirectory()) {
			return bea;
		}
		String[] tempList = file.list();
		File temp = null;
		for (int i = 0; i < tempList.length; i++) {
			if (path.endsWith(File.separator)) {
				temp = new File(path + tempList[i]);
			} else {
				temp = new File(path + File.separator + tempList[i]);
			}
			if (temp.isFile()) {
				temp.delete();
			}
			if (temp.isDirectory()) {
				delAllFile(path + "/" + tempList[i]);// 先删除文件夹里面的文件
				delFolder(path + "/" + tempList[i]);// 再删除空文件
				bea = true;
			}
		}
		return bea;
	}

	/**
	 * 复制单个文件
	 * 
	 * @param oldPathFile
	 *            准备复制的文件源
	 * @param newPathFile
	 *            拷贝到新绝对路径带文件名
	 * @return
	 */
	public static void copyFile(String oldPathFile, String newPathFile) {
		try {
			int bytesum = 0;
			int byteread = 0;
			File oldfile = new File(oldPathFile);
			if (oldfile.exists()) { // 文件存在
				InputStream inStream = new FileInputStream(oldPathFile); // 读入源文件
				FileOutputStream fs = new FileOutputStream(newPathFile);
				byte[] buffer = new byte[1444];
				while ((byteread = inStream.read(buffer)) != -1) {
					bytesum += byteread; // 字节 文件大小
					fs.write(buffer, 0, byteread);
				}
				inStream.close();
			}
		} catch (Exception e) {
			// message = ("复制单个文件操作出错");
			logger.error("copyFile Exception 复制单个文件操作出错.", e);
		}
	}

	public static void copyFile(File oldFile, File newFile) {
		FileOutputStream fos = null;
		FileInputStream fis = null;
		if (null == newFile || null == oldFile) {
			logger.error("newFile or oldFile is null return.");
			return;
		}
		try {
			// 建立文件输出流
			fos = new FileOutputStream(newFile);
			// 建立文件上传流
			fis = new FileInputStream(oldFile);
			byte[] buffer = new byte[1024];
			int len = 0;
			while ((len = fis.read(buffer)) > 0) {
				fos.write(buffer, 0, len);
			}
		} catch (Exception e) {
			logger.error("copyFile Exception.", e);
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				logger.error("copyFile IOException.", e);
			}
		}
	}

	/**
	 * 复制整个文件夹的内容
	 * 
	 * @param oldPath
	 *            准备拷贝的目录
	 * @param newPath
	 *            指定绝对路径的新目录
	 * @return
	 */
	public static void copyFolder(String oldPath, String newPath) {
		try {
			new File(newPath).mkdirs(); // 如果文件夹不存在 则建立新文件
			File a = new File(oldPath);
			String[] file = a.list();
			File temp = null;
			for (int i = 0; i < file.length; i++) {
				if (oldPath.endsWith(File.separator)) {
					temp = new File(oldPath + file[i]);
				} else {
					temp = new File(oldPath + File.separator + file[i]);
				}
				if (temp.isFile()) {
					FileInputStream input = new FileInputStream(temp);
					FileOutputStream output = new FileOutputStream(newPath + "/" + (temp.getName()).toString());
					byte[] b = new byte[1024 * 5];
					int len;
					while ((len = input.read(b)) != -1) {
						output.write(b, 0, len);
					}
					output.flush();
					output.close();
					input.close();
				}
				if (temp.isDirectory()) {// 如果是子文件
					copyFolder(oldPath + "/" + file[i], newPath + "/" + file[i]);
				}
			}
		} catch (Exception e) {
			// message = "复制整个文件夹内容操作出错";
			logger.error("复制整个文件夹内容操作出错 Exception.", e);
		}
	}

	/**
	 * 移动文件
	 * 
	 * @param oldPath
	 * @param newPath
	 * @return
	 */
	public static void moveFile(String oldPath, String newPath) {
		copyFile(oldPath, newPath);
		delFile(oldPath);
	}

	/**
	 * 移动目录
	 * 
	 * @param oldPath
	 * @param newPath
	 * @return
	 */
	public static void moveFolder(String oldPath, String newPath) {
		copyFolder(oldPath, newPath);
		delFolder(oldPath);
	}

	/**
	 * 建立一个可以追加的bufferedwriter
	 * 
	 * @param fileDir
	 * @param fileName
	 * @return
	 */
	public static BufferedWriter getWriter(String fileDir, String fileName) {
		try {
			File f1 = new File(fileDir);
			if (!f1.exists()) {
				f1.mkdirs();
			}
			f1 = new File(fileDir, fileName);
			if (!f1.exists()) {
				f1.createNewFile();
			}
			BufferedWriter bw = new BufferedWriter(new FileWriter(f1.getPath(), true));
			return bw;
		} catch (Exception e) {
			logger.error("建立一个可以追加的bufferedwriterException.", e);
			return null;
		}
	}

	/**
	 * 得到一个bufferedreader
	 * 
	 * @param fileDir
	 * @param fileName
	 * @param encoding
	 * @return
	 */
	public BufferedReader getReader(String fileDir, String fileName, String encoding) {
		try {
			File file = new File(fileDir, fileName);
			InputStreamReader read = new InputStreamReader(new FileInputStream(file), encoding);
			BufferedReader br = new BufferedReader(read);
			return br;

		} catch (FileNotFoundException ex) {
			logger.error("FileNotFoundException.", ex);
			return null;
		} catch (IOException e) {
			logger.error("IOException.", e);
			return null;
		}

	}

	public String getMessage() {
		return this.message;
	}

	public static boolean isXLSXFile(File file) {
		boolean isXLSXFile = false;
		byte[] b = new byte[50];
		InputStream is = null;
		try {
			is = new FileInputStream(file);
			is.read(b);
			String fileTypeHex = String.valueOf(getFileHexString(b));
			if (fileTypeHex.startsWith("504b030414")) {
				isXLSXFile = true;
			}
		} catch (FileNotFoundException e) {
			logger.error("FileNotFoundException.", e);
		} catch (IOException e) {
			logger.error("IOException.", e);
		} finally {
			try {
				if (is != null)
					is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return isXLSXFile;
	}

	public final static String getFileHexString(byte[] b) {
		StringBuilder stringBuilder = new StringBuilder();
		if (b == null || b.length <= 0) {
			return null;
		}
		for (int i = 0; i < b.length; i++) {
			int v = b[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}

	/**
	 * 解决此问题的关键是要理解空间几何模型，在理解空间几何模型的基础上再利用数学公式求取两点之间的值。其解决步骤如下：
	 * 1、设两点分别为P1、P2，如果其值是用度分秒形式表示，则需将其转换成十进制度的形式，如P1点纬度为23度30分，
	 * 则其纬度值转换成十进制度的形式为23.5度。如果值为十进制度的形式，则直接进入第二步。
	 * 2、分别将两点的经度、纬度值转换成弧度制形式，如P1纬度为23.5度，转换成弧度制则为：23.5*PI / 180。分别用
	 * P1latInRad、P1LongInRad、P2latInRad、P2LongInRad表示。
	 * 3、分别求取两点间的纬度差（dlat）与经度差（dlon）； 4、求取两点间的正弦与余弦值，公式如下： A=sin2(dlat/2) +
	 * cos(P1LatInRad)*cos(P2LatInRad)*Sin2(dlon/2) (1) 5、求取两点的正切值，公式如下：
	 * C=2*Math.Atan2(Math.Sqrt(A), Math.Sqrt(1-A)) (2) 6、返回两点间的距离：公式如下：
	 * D=EarthRadiusKm * C (3)
	 * 
	 * @param longt1
	 *            当前经度
	 * @param lat1
	 *            当前纬度
	 * @param longt2
	 *            车辆经度
	 * @param lat2
	 *            车辆纬度
	 * @return
	 */
	public static double getDistance(double longt1, double lat1, double longt2, double lat2) {
		double x, y, distance;
		x = (longt2 - longt1) * PI * R * Math.cos(((lat1 + lat2) / 2) * PI / 180) / 180;
		y = (lat2 - lat1) * PI * R / 180;
		distance = Math.hypot(x, y);
		return distance;
	}

	public static double getFormatDistance(double longt1, double lat1, double longt2, double lat2) {
		double distance = getDistance(longt1, lat1, longt2, lat2);
		return new BigDecimal(distance).divide(new BigDecimal(1000)).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public static String generateToken(int len) {
		String localVar = "PA";
		String[] rNum = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
		int tmp = 0;
		StringBuffer sb = new StringBuffer();
		try {
			for (int i = 0; i < len; i++) {
				tmp = genRandomDigit(rNum.length);
				sb.append(rNum[tmp]);
				if (len / 2 == i && len > 10) {
					sb.append(localVar);
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return sb.toString();
	}

	public static int genRandomDigit(int seed) throws Exception {
		SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
		return secureRandom.nextInt(seed - 1) + 1;
	}

	/**
	 * 加密
	 * 
	 * @param input
	 * @param key
	 * @return
	 */
	public static String encrypt(String input, String key) {
		String res = null;
		try {
			SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, skey);
			byte[] crypted = cipher.doFinal(input.getBytes());
			// res = new String(Base64.encode(crypted));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return res;
	}

	/**
	 * 解密
	 * 
	 * @param input
	 * @param key
	 * @return
	 */
	/*
	 * public static String decrypt(String input, String key) { String res =
	 * null; try {
	 * 
	 * @SuppressWarnings("restriction") byte[] str = new
	 * sun.misc.BASE64Decoder().decodeBuffer(input); SecretKeySpec skey = new
	 * SecretKeySpec(key.getBytes(), "AES"); Cipher cipher =
	 * Cipher.getInstance("AES/ECB/PKCS5Padding");
	 * cipher.init(Cipher.DECRYPT_MODE, skey); byte[] bits =
	 * cipher.doFinal(str); res = new String(bits); } catch (Exception e) {
	 * logger.error(e.getMessage()); } return res; }
	 */

	/**
	 * 获取MD5字符串
	 * 
	 * @param inputStr
	 * @return
	 */
	public static String getMD5Str(String inputStr) {
		return DigestUtils.md5DigestAsHex(inputStr.getBytes());
	}

	/**
	 * unicode 转换成 中文
	 * 
	 * @author xujie
	 * @param theString
	 * @return
	 */
	public static String decodeUnicode(String theString) {
		char aChar;
		int len = theString.length();
		StringBuffer outBuffer = new StringBuffer(len);
		for (int x = 0; x < len;) {
			aChar = theString.charAt(x++);
			if (aChar == '\\') {
				aChar = theString.charAt(x++);
				if (aChar == 'u') {
					int value = 0;
					for (int i = 0; i < 4; i++) {
						aChar = theString.charAt(x++);
						switch (aChar) {
						case '0':
						case '1':
						case '2':
						case '3':
						case '4':
						case '5':
						case '6':
						case '7':
						case '8':
						case '9':
							value = (value << 4) + aChar - '0';
							break;
						case 'a':
						case 'b':
						case 'c':
						case 'd':
						case 'e':
						case 'f':
							value = (value << 4) + 10 + aChar - 'a';
							break;
						case 'A':
						case 'B':
						case 'C':
						case 'D':
						case 'E':
						case 'F':
							value = (value << 4) + 10 + aChar - 'A';
							break;
						default:
							throw new IllegalArgumentException("Malformed      encoding.");
						}
					}
					outBuffer.append((char) value);
				} else {
					if (aChar == 't') {
						aChar = '\t';
					} else if (aChar == 'r') {
						aChar = '\r';
					} else if (aChar == 'n') {
						aChar = '\n';
					} else if (aChar == 'f') {
						aChar = '\f';
					}
					outBuffer.append(aChar);
				}
			} else {
				outBuffer.append(aChar);
			}
		}
		return outBuffer.toString();
	}

	public static String getChinese(long seed) throws Exception {
		String str = null;
		int highPos, lowPos;
		seed = new Date().getTime();
		Random random = new Random(seed);
		highPos = (176 + Math.abs(random.nextInt(39)));
		lowPos = 161 + Math.abs(random.nextInt(93));
		byte[] b = new byte[2];
		b[0] = (new Integer(highPos)).byteValue();
		b[1] = (new Integer(lowPos)).byteValue();
		str = new String(b, "GB2312");
		return str;
	}

	public static String get10Chinese() throws Exception {
		String str = "";
		for (int i = 30; i > 0; i--) {
			str = str + getChinese(i);

		}
		return str;
	}

	public static String generateName() {

		String[] name1 = { "赵", "钱", "孙", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "李", "周", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "吴", "郑", "王", "冯", "陈", "诸", "卫", "蒋", "沈", "韩", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "杨", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "王", "张", "张", "张", "张", "张", "张", "张", "张", "于", "于", "于", "于", "于", "于", "于", "于", "于", "于", "于", "于", "于", "于", "于", "于", "余", "余", "余", "余", "余", "余", "余", "余", "余", "余", "余", "余", "余", "余", "余", "余", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "张", "陈", "陈", "陈", "陈", "陈", "陈", "陈", "陈", "陈", "陈", "陈", "陈", "陈", "陈", "朱", "秦", "尤", "许", "何", "吕", "施", "张", "孔", "曹", "严", "华", "金", "魏", "陶", "姜", "戚", "谢", "邹", "喻", "柏", "水", "窦", "章", "云", "苏", "潘", "葛", "奚", "范", "彭", "郎", "鲁", "韦", "昌", "马", "苗", "凤", "花", "方", "俞", "任", "袁", "柳", "酆", "鲍", "史", "唐", "费", "廉", "岑", "薛", "雷", "贺", "倪", "汤", "滕", "殷", "罗", "毕", "郝", "邬", "安", "常", "乐", "于", "时", "傅", "皮", "卡", "齐", "康", "伍", "余", "元", "卜", "顾", "孟", "平", "黄", "和", "穆", "萧", "尹", "姚", "邵", "堪", "汪", "祁", "毛", "禹", "狄", "米", "贝", "明", "臧", "计", "伏", "成", "戴", "谈", "宋", "茅", "庞", "熊", "纪", "舒", "屈", "项", "祝", "董", "粱", "杜", "阮", "蓝", "闵", "席", "季", "麻", "强", "贾", "路", "娄", "危", "江", "童", "颜", "郭", "梅", "盛", "林", "刁", "钟", "徐", "邱", "骆", "高", "夏", "蔡", "田", "樊", "胡", "凌", "霍", "虞", "万", "支", "柯", "咎", "管", "卢", "莫", "经", "房", "裘", "缪", "干", "解", "应", "宗", "丁", "宣", "贲", "邓", "郁", "单", "杭", "洪", "包", "诸", "左", "石", "崔", "吉", "钮", "龚", "程", "嵇", "邢", "滑", "裴", "陆", "荣", "翁", "荀", "羊", "於", "惠", "甄", "魏", "家", "封", "芮", "羿", "储", "靳", "汲", "邴", "糜", "松", "井", "段", "富", "巫", "乌", "焦", "巴", "弓", "牧", "隗", "山", "谷", "车", "侯", "宓", "蓬", "全", "郗", "班", "仰", "秋", "仲", "伊", "宫", "宁", "仇", "栾", "暴", "甘", "钭", "厉", "戎", "祖", "武", "符", "刘", "景", "詹", "束", "龙", "司马", "上官", "欧阳", "夏侯", "诸葛", "东方", "尉迟", "公孙", "长孙", "慕容", "司徒", "西门" };

		String[] name2 = { "超", "媛", "念", "立", "思", "嘉", "雨", "伟", "权", "秋", "佩", "雅", "联", "如", "渠", "保", "室", "铜", "梧", "胤", "昱", "佳", "伊", "校", "诗", "节", "如", "阁", "耕", "宫", "古", "谷", "观", "桂", "贵", "国", "广", "冠", "汉", "翰", "航", "杭", "海", "豪", "浩", "皓", "和", "河", "贺", "恒", "弘", "虹", "宏", "红", "厚", "鹄", "虎", "华", "欢", "怀", "辉", "惠", "会", "奇", "吉", "骥", "嘉", "佳", "甲", "稼", "江", "坚", "剑", "锦", "经", "镜", "界", "竞", "介", "京", "建", "净", "精", "敬", "静", "靖", "津", "进", "菁", "景", "炯", "驹", "举", "炬", "君", "俊", "军", "骏", "郡", "峻", "恺", "楷", "康", "可", "克", "珂", "逵", "魁", "阔", "昆", "奎", "宽", "况", "乐", "雷", "岭", "廉", "霖", "麟", "灵", "利", "良", "联", "烈", "罗", "陵", "梁", "立", "礼", "力", "莉", "烁", "隆", "龙", "禄", "璐", "露", "律", "茂", "梦", "密", "铭", "明", "绵", "妙", "默", "木", "能", "年", "宁", "念", "怒", "庞", "佩", "培", "朋", "鹏", "屏", "平", "魄", "珀", "璞", "奇", "琦", "齐", "启", "谦", "乾", "茜", "倩", "芹", "琴", "青", "卿", "秋", "权", "求", "情", "渠", "全", "荃", "群", "泉", "然", "让", "仁", "任", "荣", "儒", "锐", "若", "瑞", "三", "瑟", "森", "韶", "绍", "尚", "商", "珊", "善", "生", "升", "声", "晟", "胜", "盛", "诗", "时", "石", "实", "凇", "慎", "设", "守", "随", "世", "寿", "仕", "余", "帅", "双", "朔", "硕", "水", "誓", "适", "书", "舒", "殊", "顺", "思", "嗣", "似", "松", "颂", "素", "岁", "棠", "泰", "腾", "添", "铁", "同", "桐", "童", "彤", "团", "涂", "图", "土", "万", "旺", "望", "王", "闻", "威", "薇", "嵬", "伟", "卫", "蔚", "文", "微", "巍", "玮", "为", "畏", "吾", "午", "西", "熙", "玺", "仙", "先", "孝", "湘", "祥", "行", "献", "享", "效", "兴", "夏", "宣", "协", "向", "校", "轩", "瑕", "衔", "筱", "羡", "相", "香", "贤", "翔", "杏", "新", "信", "幸", "心", "星", "绣", "秀", "欣", "鑫", "兴", "行", "雄", "许", "炫", "雪", "学", "旭", "璇", "勋", "萱", "迅", "亚", "雅", "扬", "耀", "彦", "延", "岩", "炎", "永", "砚", "演", "焱", "洋", "阳", "曜", "耀", "夜", "译", "逸", "伊", "义", "艺", "意", "异", "怡", "翼", "毅", "银", "瑛", "仪", "易", "寅", "印", "苡", "野", "业", "英", "璎", "盈", "颖", "影", "雍", "勇", "悠", "由", "游", "佑", "友", "瑜", "遇", "玉", "岳", "元", "宇", "愚", "钰", "裕", "郁", "于", };

		int len1 = name1.length - 1;
		int len2 = name2.length - 1;
		int random1 = (int) (Math.random() * len1);
		int random2 = (int) (Math.random() * len2);
		int random2_1 = (int) (Math.random() * len2);

		String name = "";
		if (random1 < 256) {
			int randomN = (int) (Math.random() * 2);
			if (randomN == 1) {
				name = name1[random1] + name2[random2];
			} else {
				name = name1[random1] + name2[random2] + name2[random2_1];
			}
		} else {
			name = name1[random1] + name2[random2] + name2[random2_1];
		}

		return name;
	}

	/**
	 * 获得指定日期的前一天
	 * 
	 * @param specifiedDay
	 * @return
	 * @throws Exception
	 */
	public static String getSpecifiedDayBefore(String specifiedDay) {// 可以用new
																		// Date().toLocalString()传递参数
		Calendar c = Calendar.getInstance();
		Date date = null;
		try {
			date = new SimpleDateFormat("yy-MM-dd").parse(specifiedDay);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		c.setTime(date);
		int day = c.get(Calendar.DATE);
		c.set(Calendar.DATE, day - 1);

		String dayBefore = new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
		return dayBefore;
	}

	/**
	 * 获得指定日期的后一天
	 * 
	 * @param specifiedDay
	 * @return
	 */
	public static String getSpecifiedDayAfter(String specifiedDay) {
		Calendar c = Calendar.getInstance();
		Date date = null;
		try {
			date = new SimpleDateFormat("yy-MM-dd").parse(specifiedDay);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		c.setTime(date);
		int day = c.get(Calendar.DATE);
		c.set(Calendar.DATE, day + 1);

		String dayAfter = new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
		return dayAfter;
	}
	
	
	
	public static double distance(double long1, double lat1, double long2, double lat2) {  
	    double a, b, R;  
	    R = 6378137; // 地球半径  
	    lat1 = lat1 * Math.PI / 180.0;  
	    lat2 = lat2 * Math.PI / 180.0;  
	    a = lat1 - lat2;  
	    b = (long1 - long2) * Math.PI / 180.0;  
	    double d;  
	    double sa2, sb2;  
	    sa2 = Math.sin(a / 2.0);  
	    sb2 = Math.sin(b / 2.0);  
	    d = 2  
	            * R  
	            * Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1)  
	                    * Math.cos(lat2) * sb2 * sb2));  
	    return d;  
	}  
	
	
	public static int stringToInteger(String value){
		return Integer.parseInt(value);
	}
	
	public static double stringToDouble(String value){
		return Double.parseDouble(value);
	}
	
	
	
	public static boolean compareContent(String str1,String str2){

		if(str1==null){
			str1 = "";
		}
		if(str2==null){
			str2 = "";
		}
		if(!str1.equals(str2)){
			return false;
		}
		return true; 
	}
	/**
	 * 得到范围内的随机数
	 * @param min
	 * @param max
	 * @return
	 */
	public static int getRandIntRange(int min,int max){
		int result = min;
		Random rand = new Random();
		result = rand.nextInt(max-min) + min;
		return result;
	}

	/**
	 * 设置产品信息
	 */
	public static void setProductInfo(long userId, PrdInfo prdInfo,
			PrdOrderDetail prdOrderDetail) {
		prdOrderDetail.setPrdTypeName(prdInfo.getPrdTypeName());
		prdOrderDetail.setPrdTypeId(prdInfo.getPrdTypeId());
		prdOrderDetail.setPrdSupply(prdInfo.getPrdSupply());
		prdOrderDetail.setPrdChannel(prdInfo.getPrdChannel());
		prdOrderDetail.setCouponName(prdInfo.getCouponName());
		prdOrderDetail.setPropaganda(prdInfo.getPropaganda());
		prdOrderDetail.setPrdPhoto(prdInfo.getPrdPhoto());
		prdOrderDetail.setPrdIntroduce(prdInfo.getPrdIntroduce());
		prdOrderDetail.setPrdInstruct(prdInfo.getPrdInstruct());
		prdOrderDetail.setPrdBeginDate(prdInfo.getPrdBeginDate());
		prdOrderDetail.setPrdEndDate(prdInfo.getPrdEndDate());
		prdOrderDetail.setPrdPrice(prdInfo.getPrdPrice());
		prdOrderDetail.setPrdPriceUnit(prdInfo.getPrdPriceUnit());
		prdOrderDetail.setMarketPrice(prdInfo.getMarketPrice());
		prdOrderDetail.setServerPrice(prdInfo.getServerPrice());
		prdOrderDetail.setServerSettleType(prdInfo.getServerSettleType());
		prdOrderDetail.setIsFreeUse(prdInfo.getIsFreeUse());
		prdOrderDetail.setFreeUseValue(prdInfo.getFreeUseValue());
		prdOrderDetail.setFreeUseUnit(prdInfo.getFreeUseUnit());
		prdOrderDetail.setIsNeedPassword(prdInfo.getIsNeedPassword());
		prdOrderDetail.setIsNeedManyUse(prdInfo.getIsNeedManyUse());
		prdOrderDetail.setUpperLimit(prdInfo.getUpperLimit());
		prdOrderDetail.setIsNeedManyBook(prdInfo.getIsNeedManyBook());
		prdOrderDetail.setBookUpperLimit(prdInfo.getBookUpperLimit());
		prdOrderDetail.setSettlementMethod(prdInfo.getSettlementMethod());
		prdOrderDetail.setSettlementDay(prdInfo.getSettlementDay());
		prdOrderDetail.setIsSupportBuyOnline(prdInfo.getIsSupportBuyOnline());
		prdOrderDetail.setIsSupportReceiveFree(prdInfo.getIsSupportReceiveFree());
		prdOrderDetail.setIsNeedInviteValue(prdInfo.getIsNeedInviteValue());
		prdOrderDetail.setIsInsurancePrd(prdInfo.getIsInsurancePrd());
		prdOrderDetail.setInsuranceFilename(prdInfo.getInsuranceFilename());
		prdOrderDetail.setInsuranceFilepath(prdInfo.getInsuranceFilepath());
		prdOrderDetail.setAppointmentTips(prdInfo.getAppointmentTips());
		prdOrderDetail.setIsSupportGive(prdInfo.getIsSupportGive());
		prdOrderDetail.setSettlementValue(prdInfo.getSettlementValue());
		prdOrderDetail.setUseBeginTime(prdInfo.getUseBeginTime());
		prdOrderDetail.setUseEndTime(prdInfo.getUseEndTime());
		prdOrderDetail.setIsWeekendOn(prdInfo.getIsWeekendOn());
		prdOrderDetail.setIsHolidayOn(prdInfo.getIsHolidayOn());
		prdOrderDetail.setProvince(prdInfo.getProvince());
		prdOrderDetail.setCity(prdInfo.getCity());
		prdOrderDetail.setRegisterOperation(prdInfo.getRegisterOperation());
		prdOrderDetail.setRegisterValue(prdInfo.getRegisterValue());
		prdOrderDetail.setRegisterUnit(prdInfo.getRegisterUnit());
		prdOrderDetail.setActiveOperation(prdInfo.getActiveOperation());
		prdOrderDetail.setActiveValue(prdInfo.getActiveValue());
		prdOrderDetail.setActiveUnit(prdInfo.getActiveUnit());
		prdOrderDetail.setCheckValue(prdInfo.getCheckValue());
		prdOrderDetail.setCouponStock(prdInfo.getCouponStock());
		prdOrderDetail.setStatus(prdInfo.getStatus());
		prdOrderDetail.setIsFrontShow(prdInfo.getIsFrontShow());
		prdOrderDetail.setIsSupportKfyy(prdInfo.getIsSupportKfyy());
		prdOrderDetail.setDelFlag(String.valueOf(prdInfo.getDelFlag()));
		prdOrderDetail.setCreateUser(String.valueOf(userId));
		prdOrderDetail.setCreateDate(new Date());
		prdOrderDetail.setUseFrequence(prdInfo.getUseFrequence());  
		prdOrderDetail.setIsValidFrom(prdInfo.getIsValidFrom());
		prdOrderDetail.setValidValue(prdInfo.getValidValue());
		prdOrderDetail.setValidValueUnit(prdInfo.getValidValueUnit());
		prdOrderDetail.setActivationDeadline(prdInfo.getActivationDeadline());
		prdOrderDetail.setPrdListPhoto(prdInfo.getPrdListPhoto());
		prdOrderDetail.setOnlineDate(prdInfo.getOnlineDate());
		prdOrderDetail.setPlatformFlag(prdInfo.getPlatformFlag());
		prdOrderDetail.setClinicTypeFlag(prdInfo.getClinicTypeFlag());
		prdOrderDetail.setClinicId(prdInfo.getClinicId());
	}
}
