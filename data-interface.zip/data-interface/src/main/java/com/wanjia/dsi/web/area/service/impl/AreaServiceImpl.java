package com.wanjia.dsi.web.area.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.area.dao.mapper.AreaMapper;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.area.service.AreaService;

/**
 * This element is automatically generated on 16-3-1 ����6:41, do not modify.
 * <br>
 * Service implementation class
 */
@Service
@SuppressWarnings("unchecked")
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class AreaServiceImpl extends BaseServiceImpl implements AreaService {
	@Autowired
	private AreaMapper areaMapper;

	@Value("#{serverConstants['debugSwitch']}")
	private String debugSwitch;

	@Value("#{serverConstants['getCityListFromTabao']}")
	private String getCityListFromTabao;

	@Value("#{serverConstants['getCityListFromSina']}")
	private String getCityListFromSina;

	@Value("#{serverConstants['getCityListFromGaode']}")
	private String getCityListFromGaode;

	@Value("#{jedisConfig['expirationTime']}")
	private int expirationTime;

	@Autowired
	private CommonJedis commonJedis;
	
	

	@Override
	public JsonResponse<List<Area>> queryAreaList(String requestId) {
		// TODO Auto-generated method stub
		JsonResponse<List<Area>> result = new JsonResponse<List<Area>>();

		List<Area> queryAreaList = new ArrayList<Area>();

		try {
			//如果在缓存里
			if (commonJedis.exists(Consts.QUERY_AREA_LIST)) {
				queryAreaList = (List<Area>) commonJedis.getObject(Consts.QUERY_AREA_LIST);
				//如果不存在缓存里
			} else {
				//数据库查询
				queryAreaList = areaMapper.queryAreaList();
				//放到缓存
				commonJedis.putObject(Consts.QUERY_AREA_LIST, queryAreaList, expirationTime);
			}

			result.setResult(queryAreaList);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<Area> getCityByIpOnTaobao(String requestId, String ip) {
		// TODO Auto-generated method stub
		JsonResponse<Area> result = new JsonResponse<Area>();
		// Map<String, Object> parameterMap = new HashMap<String, Object>();

		Area area = new Area();
		try {
			//校验参数
			super.checkParams(ip);// checkParams(ip);
			//调用淘宝接口，返回城市名称
			String cityName = this.getCityByIpOnTaobao(ip, debugSwitch, getCityListFromTabao);

			String name = getCityName(JSONObject.parseObject(cityName));
			this.pringLog("cityName is:" + name);
			if (StringUtils.isNoneBlank(name)) {
				area.setName("%" + name + "%");
				area.setDelFlag("0");
				//去数据库查询
				area = (Area) areaMapper.findInTaobao(area).get(0);
				result.setResult(area);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		// {"code":0,"data":{"area":"华东","area_id":"300000","city":"上海市","city_id":"310100","country":"中国","country_id":"CN","county":"","county_id":"-1","ip":"116.226.186.167","isp":"电信","isp_id":"100017","region":"上海市","region_id":"310000"}}

		return result;

	}

	@Override
	public JsonResponse<Area> getCityByIpOnSina(String requestId, String ip) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		JsonResponse<Area> result = new JsonResponse<Area>();
		// Map<String, Object> parameterMap = new HashMap<String, Object>();

		Area area = new Area();
		try {
			//校验参数
			super.checkParams(ip);// checkParams(ip);
			//调用新浪接口，返回城市名称
			String cityName = this.getCityByIpOnSina(ip, debugSwitch, getCityListFromSina);
			String name = getCityNameInSina(JSONObject.parseObject(cityName));
			this.pringLog("cityName is:" + name);
			if (StringUtils.isNoneBlank(name)) {
				area.setName("%" + name + "%");
				area.setDelFlag("0");
				//去数据库查询
				area = (Area) areaMapper.findInTaobao(area).get(0);
				result.setResult(area);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		// {"code":0,"data":{"area":"华东","area_id":"300000","city":"上海市","city_id":"310100","country":"中国","country_id":"CN","county":"","county_id":"-1","ip":"116.226.186.167","isp":"电信","isp_id":"100017","region":"上海市","region_id":"310000"}}

		return result;
	}

	@Override
	public JsonResponse<Area> getCityByIpOnGaode(String requestId, String ip) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		JsonResponse<Area> result = new JsonResponse<Area>();
		// Map<String, Object> parameterMap = new HashMap<String, Object>();

		Area area = new Area();
		try {
			super.checkParams(ip);// checkParams(ip);
			//调用高德接口，返回城市名称
			String cityName = this.getCityByIpOnGaode(ip, debugSwitch, getCityListFromGaode);

			String name = getCityNameInGaode(JSONObject.parseObject(cityName));
			this.pringLog("cityName is:" + name);
			if (StringUtils.isNoneBlank(name)) {
				//城市名称模糊匹配
				area.setName("%" + name + "%");
				area.setDelFlag("0");
				//去数据库查询
				List<Area> areaList = areaMapper.findInTaobao(area);
				if(areaList !=null && areaList.size() > 0 ){
					area = areaList.get(0);
				}
				result.setResult(area);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		// {"code":0,"data":{"area":"华东","area_id":"300000","city":"上海市","city_id":"310100","country":"中国","country_id":"CN","county":"","county_id":"-1","ip":"116.226.186.167","isp":"电信","isp_id":"100017","region":"上海市","region_id":"310000"}}

		return result;
	}

	@Override
	public JsonResponse<List<Area>> getCityList(String requestId, Area area) {
		// TODO Auto-generated method stub
		JsonResponse result = new JsonResponse();
		Map<String, Object> parameterMap = new HashMap<String, Object>();
		// this.checkParams(area);
		try {

			// Area parse = (Area)JSON.parse(area);
			// Area parseObject = (Area) this.getT(area, Area.class);
			//非空校验
			if (!CommonTools.notNullAndEmpty(area)) {
				area = new Area();
			}
			area.setDelFlag("0");
			//查询数据库
			List<Area> findByEntity = areaMapper.findByEntity(area);
			result.setResult(findByEntity);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		// {"code":0,"data":{"area":"华东","area_id":"300000","city":"上海市","city_id":"310100","country":"中国","country_id":"CN","county":"","county_id":"-1","ip":"116.226.186.167","isp":"电信","isp_id":"100017","region":"上海市","region_id":"310000"}}
		return result;
	}

	/*
	 * <p>Title: getCmsCityList</p> <p>Description: </p>
	 * 
	 * @return
	 * 
	 * @see com.wanjia.dsi.web.area.service.AreaService#getCmsCityList()
	 */
	@Override
	public JsonResponse<List<Area>> getCmsCityList(String requestId, Area area, String pageNo, String pageSize) {
		// TODO Auto-generated method stub
		JsonResponse result = new JsonResponse();
		try {
			if (CommonTools.notNullAndEmpty(area)) {
				area.setDelFlag("0");
				//查询数据库
				List<Area> cmsCityList = areaMapper.getCmsCityList(area);
				result.setResult(cmsCityList);
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		// {"code":0,"data":{"area":"华东","area_id":"300000","city":"上海市","city_id":"310100","country":"中国","country_id":"CN","county":"","county_id":"-1","ip":"116.226.186.167","isp":"电信","isp_id":"100017","region":"上海市","region_id":"310000"}}

		return result;
	}

	@Override
	public Area findById(Long id) {
		return (Area) areaMapper.findById(id);
	}

	@Override
	public List<Area> findWithPagination(int offset, int count) {
		return (List<Area>) areaMapper.findWithPagination(offset, count);
	}

	@Override
	public List<Area> findAll() {
		return (List<Area>) areaMapper.findAll();
	}

	@Override
	public List<Area> findByEntity(Area model) {
		return (List<Area>) areaMapper.findByEntity(model);
	}

	@Override
	public List<Area> findByEntityWithPagination(Area model, int offset, int count) {
		return (List<Area>) areaMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	public Area findOneByEntity(Area model) {
		return (Area) areaMapper.findOneByEntity(model);
	}

	@Override
	public List<Area> findByProperty(String propertyName, String propertyValue) {
		return (List<Area>) areaMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	public Area findOneByProperty(String propertyName, String propertyValue) {
		return (Area) areaMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	public List<Area> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
		return (List<Area>) areaMapper.findByPropertyWithPagination(propertyName, propertyValue, offset, count);
	}

	@Override
	public List<Area> findByProperties(Map<String, Object> map) {
		return (List<Area>) areaMapper.findByProperties(map);
	}

	@Override
	public long countByEntity(Area model) {
		return (long) areaMapper.countByEntity(model);
	}

	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		return (long) areaMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	public long countByProperties(Map<String, Object> map) {
		return (long) areaMapper.countByProperties(map);
	}

	@Override
	public void update(Area model) {
		areaMapper.update(model);
	}

	@Override
	public void insert(Area model) {
		areaMapper.insert(model);
	}

	@Override
	public void deleteByEntity(Area model) {
		areaMapper.deleteByEntity(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		areaMapper.deleteByProperty(propertyName, propertyValue);
	}

	public long countAll() {
		return this.areaMapper.countAll();
	}

	public void insertBatch(List<Area> list) {
		this.areaMapper.insertBatch(list);
	}

	public void delete(Long id) {
		this.areaMapper.deleteById(id);
	}

	private String getCityName(JSONObject parseObject) {

		String code = parseObject.getString("code");
		String name = "";
		if ("0".equals(code)) {
			name = parseObject.getJSONObject("data").getString("city");
		}
		if (StringUtils.isNotEmpty(name)) {
			name = name.substring(0, name.length() - 1);
		}
		return name;
	}

	private String getCityNameInSina(JSONObject parseObject) {

		return parseObject.getString("city");
	}

	private String getCityNameInGaode(JSONObject parseObject) {

		return parseObject.getString("city");
	}

	@Override
	public JsonResponse<Map<String, List<Area>>> getAreaListForGateway() {
		// TODO Auto-generated method stub
		JsonResponse<Map<String, List<Area>>> result = new JsonResponse<Map<String, List<Area>>>();
		Map<String, List<Area>> map = new HashMap<String, List<Area>>();
		try {
			//校验是否存在redis
			boolean exists = commonJedis.exists(Consts.GET_AREA_LIST_FOR_GATEWAY);
			//存在
			if (exists) {
				map = (Map<String, List<Area>>) commonJedis.getObject(Consts.GET_AREA_LIST_FOR_GATEWAY);
				//不存在
			} else {
				//从数据库查询
				map = this.getMapList(areaMapper.getAreaListForGateway());
				//放缓存
				commonJedis.addObject(Consts.GET_AREA_LIST_FOR_GATEWAY, map, expirationTime);
			}
			result.setResult(map);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;

	}

	public Map<String, List<Area>> getMapList(List<Area> oldList) {
		Map<String, List<Area>> map = new HashMap<String, List<Area>>();
		List<Area> ls = null;
		// 26个字母数组
		String[] bArray = { "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
		        "T", "U", "V", "W", "X", "Y", "Z" };

		if (oldList == null && oldList.size() == 0) {
			return null;
		}
		int a = 0;
		//迭代，设置城市信息
		for (int j = 0; j < bArray.length; j++) {
			ls = new ArrayList<Area>();
			for (int i = 0; i < oldList.size(); i++) {
				String key = oldList.get(i).getPinyin();
				if (bArray[j].equals(key)) {
					//迭代，设置城市信息
					ls.add(oldList.get(i));

				}
			}
			//放map里
			map.put(bArray[j], ls);

		}

		return map;
	}

	@Override
	public JsonResponse<List<Area>> gainAreaList(List<String> areaIds) {
		JsonResponse<List<Area>> result = new JsonResponse<List<Area>>();
		try {
			//查询数据库
			result.setResult(areaMapper.gainAreaList(areaIds));

		} catch (Exception e) {
			logger.error("error is", e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<List<Area>> getAllCityOpenRegion(List<String> areaIds) {
		JsonResponse<List<Area>> result = new JsonResponse<List<Area>>();
		try {
			List<Area> cmsCityList = areaMapper.getAllCityOpenRegion(areaIds);
			result.setResult(cmsCityList);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	public List<Map<String, Object>> findCitySelect() {
		// TODO Auto-generated method stub
		return areaMapper.findCitySelect();
	}

	@Override
	public JsonResponse<List<Area>> findHotCity(int pageNo,int pageSize) {
		JsonResponse<List<Area>> jr = new JsonResponse<List<Area>>();
		List<Area> list = new ArrayList<Area>();
		PageHelper.startPage(pageNo,pageSize);
		try {
			list = areaMapper.findHotCity();
			jr.setResult(list);
		} catch (Exception e) {
			logger.error("查询开通服务的热门城市失败：pageNo："+pageNo+"----pageSize:"+pageSize, e);
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("查询开通服务的热门城市失败");
			e.printStackTrace();
		}
		return jr;
	}

}