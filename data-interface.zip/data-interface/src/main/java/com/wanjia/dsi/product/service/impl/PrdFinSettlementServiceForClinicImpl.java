package com.wanjia.dsi.product.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.StringUtils;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdFinSettlementDetailMapper;
import com.wanjia.dsi.product.dao.mapper.PrdFinSettlementMapper;
import com.wanjia.dsi.product.model.PrdFinSettlement;
import com.wanjia.dsi.product.model.PrdFinSettlementDetail;
import com.wanjia.dsi.product.model.SettleStatus;
import com.wanjia.dsi.product.service.PrdFinSettlementForClinicService;
import com.wanjia.dsi.product.vo.VOPrdAgreementAndSubAgreementInfo;
import com.wanjia.dsi.product.vo.VOPrdFinSettleCountForClinic;
import com.wanjia.dsi.product.vo.VOPrdFinSettlementForClinic;
import com.wanjia.dsi.web.coupon.dao.mapper.PrdFinSettlementLogMapper;
import com.wanjia.dsi.web.coupon.model.PrdFinSettlementLog;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdFinSettlementServiceForClinicImpl implements PrdFinSettlementForClinicService {
	private Logger logger = LoggerFactory.getLogger(PrdFinSettlementServiceImpl.class);
	
    @Autowired
    private PrdFinSettlementMapper prdFinSettlementMapper;
    
    @Autowired
    private PrdFinSettlementDetailMapper prdFinSettlementDetailMapper;
    
    @Resource
	private PrdAgreementPrdinfoMapper prdAgreementPrdinfoMapper;
    
    @Resource
   	private PrdFinSettlementLogMapper prdFinSettlementLogMapper;

    /**
     * 单体诊所
     */
	@Override
	public JsonResponse<List<VOPrdFinSettlementForClinic>> getPrdFinSettlementBillForClinic(Map<String, Object> map) {
		
		//DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//DateFormat df = new SimpleDateFormat("yyyy.MM");
		String clinicId = (String)map.get("clinicId");
		String settleMonthStr = (String)map.get("settleMonth");
		map.put("delFlag", "0");
		JsonResponse<List<VOPrdFinSettlementForClinic>> response = new JsonResponse<List<VOPrdFinSettlementForClinic>>();
		try{
			if(StringUtils.isBlank(clinicId)){
				response.setStatus(Status.ERROR);
				response.setErrorMsg("参数诊所ID列表为空");
				return response;
			}
			if(StringUtils.isBlank(settleMonthStr)){
				response.setStatus(Status.ERROR);
				response.setErrorMsg("参数结算年月为空");
			}
			
			Map<String, Object> mapSettleParam = new HashMap<String, Object>();
			mapSettleParam.put("clinicId", clinicId);
			mapSettleParam.put("settleMonth", settleMonthStr);
			List<VOPrdFinSettlementForClinic> finSettlementList = prdFinSettlementMapper.selectSettlementDetailForSingleClinicToPagination(map);
			for(VOPrdFinSettlementForClinic settlement : finSettlementList){
				
				mapSettleParam.put("settleDate", settlement.getSettleDate());
				List<PrdFinSettlement> prdFinSettlementList = prdFinSettlementMapper.findByProperties(mapSettleParam);
				if(CollectionUtils.isEmpty(prdFinSettlementList)){
					logger.error("【ERROR】子诊所查询主张单总表失败，数据为空！");
					response.setStatus(Status.ERROR);
					response.setErrorMsg("子诊所查询主张单总表失败，数据为空");
					return response;
				}
				
				PrdFinSettlement prdFinSettlement = prdFinSettlementList.get(0);
				settlement.setStatus(prdFinSettlement.getStatus());
				settlement.setId(prdFinSettlement.getId());
				settlement.setModifyDate(prdFinSettlement.getModifyDate());
				if("01".equals(settlement.getStatus()) || "02".equals(settlement.getStatus())){
					settlement.setStatusDesc("未出账");
				}else if("03".equals(settlement.getStatus())){
					settlement.setStatusDesc("待确认");
				}else if("04".equals(settlement.getStatus())){
					settlement.setStatusDesc("已驳回");
				}else if("05".equals(settlement.getStatus()) || "06".equals(settlement.getStatus())){
					settlement.setStatusDesc("已确认");
				}else if("07".equals(settlement.getStatus())){
					settlement.setStatusDesc("已付款");
				}
				
				Set<String> detailStatusSetRes = new HashSet<String>();
				settlement.setSettleMonth(settleMonthStr);
				StringBuilder sb = new StringBuilder();
				StringBuilder sb1 = new StringBuilder();
				List<String> prdNameList = new ArrayList<String>();
				List<String> subAgreementNoList = new ArrayList<String>();
				List<String> agreementNoList = new ArrayList<String>();
				Map<String, Object> detailMap = new HashMap<String, Object>();
				detailMap.put("clinicId", settlement.getClinicId());
				detailMap.put("settleDate", settlement.getSettleDate());
				detailMap.put("delFlag", "0");
				//查询结算明细
				List<PrdFinSettlementDetail> settlementDetailList = (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findByProperties(detailMap);
				if(CollectionUtils.isEmpty(settlementDetailList)){
					continue;
				}
				
				settlement.setRejectDesc(settlementDetailList.get(0).getRejectDesc());
				Map<String, String> agreementNoStatus = new HashMap<String, String>();
				Map<String, String> subAgreementNoStatus = new HashMap<String, String>();
				settlement.setAgreementNoStatus(agreementNoStatus);
				settlement.setSubAgreementNoStatus(subAgreementNoStatus);
				//汇总结算明细（附属合同、框架合同和产品名称）
				for(PrdFinSettlementDetail detail : settlementDetailList){
					if(StringUtils.isNotBlank(detail.getStatus())){
						detailStatusSetRes.add(detail.getStatus());//统计明细中的状态所有值
					}
					
					if(StringUtils.isNotBlank(detail.getPrdName()) && !prdNameList.contains(detail.getPrdName())){
						sb.append(detail.getPrdName()+"、");
						prdNameList.add(detail.getPrdName());
					}
					//查询合同号信息
					Map<String, Object> agreementMapParam = new HashMap<String, Object>();
					agreementMapParam.put("prdId", detail.getPrdId());
					agreementMapParam.put("clinicId", detail.getClinicId());
					//Date settleMonth = df.parse(settleMonthStr);
					//String [] settleMonthArray = DateUtil.getMonthStartAndEndDate(settleMonth);
					//agreementMapParam.put("beginDate", df1.parse(settleMonthArray[0]+" 00:00:00"));
					//agreementMapParam.put("endDate", df1.parse(settleMonthArray[1]+" 23:59:59"));
					List<VOPrdAgreementAndSubAgreementInfo> agreementAndSubAgreementList = prdAgreementPrdinfoMapper.searchClinicAgreementInfoByParams(agreementMapParam);
					if(CollectionUtils.isEmpty(agreementAndSubAgreementList)){
						continue;
					}
					VOPrdAgreementAndSubAgreementInfo vo = agreementAndSubAgreementList.get(0);
					if(StringUtils.isNotBlank(vo.getAgreementContractNo()) && !agreementNoStatus.containsKey(vo.getAgreementContractNo())){
						
						agreementNoList.add(vo.getAgreementContractNo());
						agreementNoStatus.put(vo.getAgreementContractNo(), vo.getAgreementContractStatus());
					}
					if(StringUtils.isNotBlank(vo.getSubAgreementContractNo()) && !subAgreementNoStatus.containsKey(vo.getSubAgreementContractNo())){
						sb1.append(vo.getSubAgreementContractId()+"|");
						subAgreementNoList.add(vo.getSubAgreementContractNo());
						subAgreementNoStatus.put(vo.getSubAgreementContractNo(), vo.getSubAgreementContractStatus());
					}
				}
				
				if(detailStatusSetRes.size() > 1){//如果明细中有两个或者两个以上的状态值，就用总表中的状态;否则，就用字表中的状态
					settlement.setStatus(prdFinSettlement.getStatus());
				}else{
					settlement.setStatus(detailStatusSetRes.iterator().next());
				}
				
				//对拼接的产品名字符串删除最后的“、”
				String prdNameStr = sb.toString();
				if(prdNameStr.indexOf("、") > 0){
					prdNameStr = prdNameStr.substring(0, prdNameStr.length()-1);
				}
				if(StringUtils.isNotBlank(prdNameStr)){
					settlement.setPrdNameStr(prdNameStr);					
				}
				
				String subAgreementNoStr = sb1.toString();
				if(subAgreementNoStr.indexOf("|") > 0){
					subAgreementNoStr = subAgreementNoStr.substring(0, subAgreementNoStr.length()-1);
				}
				if(StringUtils.isNotBlank(subAgreementNoStr)){
					settlement.setSubAgreementNoListJson(subAgreementNoStr);
				}
				if(agreementNoList.size() > 0){
					settlement.setAgreementNo(agreementNoList.get(0));
				}
				settlement.setPrdNameList(prdNameList);
				settlement.setSubAgreementNoList(subAgreementNoList);
			}
			
			response.setResult(finSettlementList);
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	}
	
	@Override
	public JsonResponse<VOPrdFinSettleCountForClinic> countPrdFinSettlementBillForClinic(Map<String, Object> map) {
		String clinicId = (String)map.get("clinicId");
		String settleMonthStr = (String)map.get("settleMonth");
		JsonResponse<VOPrdFinSettleCountForClinic> response = new JsonResponse<VOPrdFinSettleCountForClinic>();
		if(StringUtils.isBlank(clinicId)){
			response.setStatus(Status.ERROR);
			response.setErrorMsg("参数诊所ID为空");
			return response;
		}
		if(StringUtils.isBlank(settleMonthStr)){
			response.setStatus(Status.ERROR);
			response.setErrorMsg("参数结算年月为空");
		}
		try{
			
			VOPrdFinSettleCountForClinic vo = prdFinSettlementMapper.countIncomeByProperties(map);
			response.setResult(vo);
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	}
	
	
	
	/**
	 * 子诊所
	 */
	@Override
	public JsonResponse<List<VOPrdFinSettlementForClinic>> getPrdFinSettlementBillForSubClinic(Map<String, Object> map) {
		
		//DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		DateFormat df = new SimpleDateFormat("yyyy.MM");
		String chainRegisterId = (String)map.get("chainRegisterId");
		String settleMonthStr = (String)map.get("settleMonth");
		String clinicId = (String)map.get("clinicId");
		JsonResponse<List<VOPrdFinSettlementForClinic>> response = new JsonResponse<List<VOPrdFinSettlementForClinic>>();
		try{
			if(StringUtils.isBlank(chainRegisterId)){
				response.setStatus(Status.ERROR);
				response.setErrorMsg("参数连锁诊所为空");
				return response;
			}
			if(StringUtils.isBlank(settleMonthStr)){
				response.setStatus(Status.ERROR);
				response.setErrorMsg("参数结算年月为空");
			}
			
			Map<String, Object> mapSettleParam = new HashMap<String, Object>();
			mapSettleParam.put("clinicRegisterId", chainRegisterId);
			mapSettleParam.put("settleMonth", settleMonthStr);
			
			List<VOPrdFinSettlementForClinic> finSettlementList = prdFinSettlementMapper.selectSettlementDetailForSubClinicToPagination(map);
			
			for(VOPrdFinSettlementForClinic settlement : finSettlementList){
				
				mapSettleParam.put("settleDate", settlement.getSettleDate());
				List<PrdFinSettlement> prdFinSettlementList = prdFinSettlementMapper.findByProperties(mapSettleParam);
				if(CollectionUtils.isEmpty(prdFinSettlementList)){
					logger.error("【ERROR】子诊所查询主张单总表失败，数据为空！");
					response.setStatus(Status.ERROR);
					response.setErrorMsg("子诊所查询主张单总表失败，数据为空");
					return response;
				}
				
				PrdFinSettlement prdFinSettlement = prdFinSettlementList.get(0);
				settlement.setId(prdFinSettlement.getId());
				settlement.setModifyDate(prdFinSettlement.getModifyDate());
				if("01".equals(settlement.getStatus())){
					settlement.setStatusDesc("未出账");
				}else if("03".equals(settlement.getStatus())){
					settlement.setStatusDesc("待确认");
				}else if("04".equals(settlement.getStatus())){
					settlement.setStatusDesc("已驳回");
				}else if("05".equals(settlement.getStatus())){
					settlement.setStatusDesc("已确认");
				}else if("07".equals(settlement.getStatus())){
					settlement.setStatusDesc("已付款");
				}
				
				Set<String> detailStatusSetRes = new HashSet<String>();
				settlement.setSettleMonth(settleMonthStr);
				StringBuilder sb = new StringBuilder();
				StringBuilder sb1 = new StringBuilder();
				List<String> prdNameList = new ArrayList<String>();
				List<String> subAgreementNoList = new ArrayList<String>();
				List<String> agreementNoList = new ArrayList<String>();
				Map<String, Object> detailMap = new HashMap<String, Object>();
				detailMap.put("clinicId", settlement.getClinicId());
				detailMap.put("settleDate", settlement.getSettleDate());
				detailMap.put("delFlag", "0");
				//查询结算明细
				List<PrdFinSettlementDetail> settlementDetailList = (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findByProperties(detailMap);
				if(CollectionUtils.isEmpty(settlementDetailList)){
					continue;
				}
				
				settlement.setRejectDesc(settlementDetailList.get(0).getRejectDesc());
				Map<String, String> agreementNoStatus = new HashMap<String, String>();
				Map<String, String> subAgreementNoStatus = new HashMap<String, String>();
				settlement.setAgreementNoStatus(agreementNoStatus);
				settlement.setSubAgreementNoStatus(subAgreementNoStatus);
				//汇总结算明细（附属合同、框架合同和产品名称）
				for(PrdFinSettlementDetail detail : settlementDetailList){
					if(StringUtils.isNotBlank(detail.getStatus())){
						detailStatusSetRes.add(detail.getStatus());//统计明细中的状态所有值
					}
					
					if(StringUtils.isNotBlank(detail.getPrdName()) && !prdNameList.contains(detail.getPrdName())){
						sb.append(detail.getPrdName()+"、");
						prdNameList.add(detail.getPrdName());
					}
					//查询合同号信息
					Map<String, Object> agreementMapParam = new HashMap<String, Object>();
					agreementMapParam.put("prdId", detail.getPrdId());
					agreementMapParam.put("clinicId", detail.getClinicId());
					//Date settleMonth = df.parse(settleMonthStr);
					//String [] settleMonthArray = DateUtil.getMonthStartAndEndDate(settleMonth);
					//agreementMapParam.put("beginDate", df1.parse(settleMonthArray[0]+" 00:00:00"));
					//agreementMapParam.put("endDate", df1.parse(settleMonthArray[1]+" 23:59:59"));
					List<VOPrdAgreementAndSubAgreementInfo> agreementAndSubAgreementList = prdAgreementPrdinfoMapper.searchClinicAgreementInfoByParams(agreementMapParam);
					if(CollectionUtils.isEmpty(agreementAndSubAgreementList)){
						continue;
					}
					VOPrdAgreementAndSubAgreementInfo vo = agreementAndSubAgreementList.get(0);
					if(StringUtils.isNotBlank(vo.getAgreementContractNo()) && !agreementNoStatus.containsKey(vo.getAgreementContractNo())){
						
						agreementNoList.add(vo.getAgreementContractNo());
						agreementNoStatus.put(vo.getAgreementContractNo(), vo.getAgreementContractStatus());
					}
					if(StringUtils.isNotBlank(vo.getSubAgreementContractNo()) && !subAgreementNoStatus.containsKey(vo.getSubAgreementContractNo())){
						sb1.append(vo.getSubAgreementContractId()+"|");
						subAgreementNoList.add(vo.getSubAgreementContractNo());
						subAgreementNoStatus.put(vo.getSubAgreementContractNo(), vo.getSubAgreementContractStatus());
					}
				}
				
				//对拼接的产品名字符串删除最后的“、”
				String prdNameStr = sb.toString();
				if(prdNameStr.indexOf("、") > 0){
					prdNameStr = prdNameStr.substring(0, prdNameStr.length()-1);
				}
				if(StringUtils.isNotBlank(prdNameStr)){
					settlement.setPrdNameStr(prdNameStr);					
				}
				
				String subAgreementNoStr = sb1.toString();
				if(subAgreementNoStr.indexOf("|") > 0){
					subAgreementNoStr = subAgreementNoStr.substring(0, subAgreementNoStr.length()-1);
				}
				if(StringUtils.isNotBlank(subAgreementNoStr)){
					settlement.setSubAgreementNoListJson(subAgreementNoStr);
				}
				if(agreementNoList.size() > 0){
					settlement.setAgreementNo(agreementNoList.get(0));
				}
				settlement.setPrdNameList(prdNameList);
				settlement.setSubAgreementNoList(subAgreementNoList);
			}
			response.setResult(finSettlementList);
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	}
	
	@Override
	public JsonResponse<VOPrdFinSettleCountForClinic> countPrdFinSettlementBillForSubClinic(Map<String, Object> map) {
		String chainRegisterId = (String)map.get("chainRegisterId");
		String settleMonthStr = (String)map.get("settleMonth");
		JsonResponse<VOPrdFinSettleCountForClinic> response = new JsonResponse<VOPrdFinSettleCountForClinic>();
		if(StringUtils.isBlank(chainRegisterId)){
			response.setStatus(Status.ERROR);
			response.setErrorMsg("参数连锁诊所为空");
			return response;
		}
		if(StringUtils.isBlank(settleMonthStr)){
			response.setStatus(Status.ERROR);
			response.setErrorMsg("参数结算年月为空");
		}
		try{
			VOPrdFinSettleCountForClinic vo = prdFinSettlementMapper.countSettlementDetailForSubClinicToPagination(map);
			response.setResult(vo);
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	}
	
	
	
	/**
	 * 连锁诊所
	 */
	@Override
	public JsonResponse<List<VOPrdFinSettlementForClinic>> getPrdFinSettlementBillForChainClinic(
			Map<String, Object> map) {
		//DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		DateFormat df = new SimpleDateFormat("yyyy.MM");
		String chainRegisterId = (String)map.get("chainRegisterId");
		String settleMonthStr = (String)map.get("settleMonth");
		JsonResponse<List<VOPrdFinSettlementForClinic>> response = new JsonResponse<List<VOPrdFinSettlementForClinic>>();
		try{
			if(StringUtils.isBlank(chainRegisterId)){
				response.setStatus(Status.ERROR);
				response.setErrorMsg("参数连锁诊所为空");
				return response;
			}
			if(StringUtils.isBlank(settleMonthStr)){
				response.setStatus(Status.ERROR);
				response.setErrorMsg("参数结算年月为空");
			}
			
			Map<String, Object> mapSettleParam = new HashMap<String, Object>();
			mapSettleParam.put("clinicRegisterId", chainRegisterId);
			mapSettleParam.put("settleMonth", settleMonthStr);
			
			List<VOPrdFinSettlementForClinic> finSettlementList = prdFinSettlementMapper.selectSettlementDetailForChainToPagination(map);
			for(VOPrdFinSettlementForClinic settlement : finSettlementList){
				mapSettleParam.put("settleDate", settlement.getSettleDate());
				List<PrdFinSettlement> prdFinSettlementList = prdFinSettlementMapper.findByProperties(mapSettleParam);
				if(CollectionUtils.isNotEmpty(prdFinSettlementList)){
					
					PrdFinSettlement prdFinSettlement = prdFinSettlementList.get(0);
					
					settlement.setId(prdFinSettlement.getId());
					settlement.setModifyDate(prdFinSettlement.getModifyDate());
					settlement.setRejectDesc(prdFinSettlement.getRejectDesc());
					settlement.setStatus(prdFinSettlement.getStatus());//连锁诊所登陆时，用总结算表的状态
					if("01".equals(prdFinSettlement.getStatus()) || "02".equals(prdFinSettlement.getStatus())){
						settlement.setStatusDesc("未出账");
					}else if("03".equals(prdFinSettlement.getStatus())){
						settlement.setStatusDesc("待确认");
					}else if("04".equals(prdFinSettlement.getStatus())){
						settlement.setStatusDesc("已驳回");
					}else if("05".equals(prdFinSettlement.getStatus()) || "06".equals(prdFinSettlement.getStatus())){
						settlement.setStatusDesc("已确认");
					}else if("07".equals(prdFinSettlement.getStatus())){
						settlement.setStatusDesc("已付款");
					}else{
						settlement.setStatusDesc(SettleStatus.getSettleStatus(prdFinSettlement.getStatus()).getCode());
					}
				}else{
					logger.error("【连锁诊所查询】prdFinSettlementList的大小为0");
				}
				
				settlement.setSettleMonth(settleMonthStr);
				StringBuilder sb = new StringBuilder();
				StringBuilder sb1 = new StringBuilder();
				List<String> prdNameList = new ArrayList<String>();
				List<String> subAgreementNoList = new ArrayList<String>();
				List<String> agreementNoList = new ArrayList<String>();
				Map<String, Object> detailMap = new HashMap<String, Object>();
				detailMap.put("clinicId", settlement.getClinicId());
				detailMap.put("settleDate", settlement.getSettleDate());
				detailMap.put("delFlag", "0");
				//查询结算明细
				List<PrdFinSettlementDetail> settlementDetailList = (List<PrdFinSettlementDetail>)prdFinSettlementDetailMapper.findByProperties(detailMap);
				if(CollectionUtils.isEmpty(settlementDetailList)){
					logger.error("【连锁诊所查询】settlementDetailList的大小为0");
					continue;
				}
				Map<String, String> agreementNoStatus = new HashMap<String, String>();
				Map<String, String> subAgreementNoStatus = new HashMap<String, String>();
				settlement.setAgreementNoStatus(agreementNoStatus);
				settlement.setSubAgreementNoStatus(subAgreementNoStatus);
				//汇总结算明细（附属合同、框架合同和产品名称）
				for(PrdFinSettlementDetail detail : settlementDetailList){
					if(StringUtils.isNotBlank(detail.getPrdName()) && !prdNameList.contains(detail.getPrdName())){
						sb.append(detail.getPrdName()+"、");
						prdNameList.add(detail.getPrdName());
					}
					//查询合同号信息
					Map<String, Object> agreementMapParam = new HashMap<String, Object>();
					agreementMapParam.put("prdId", detail.getPrdId());
					agreementMapParam.put("clinicId", detail.getClinicId());
					//Date settleMonth = df.parse(settleMonthStr);
					//String [] settleMonthArray = DateUtil.getMonthStartAndEndDate(settleMonth);
					//agreementMapParam.put("beginDate", df1.parse(settleMonthArray[0]+" 00:00:00"));
					//agreementMapParam.put("endDate", df1.parse(settleMonthArray[1]+" 23:59:59"));
					List<VOPrdAgreementAndSubAgreementInfo> agreementAndSubAgreementList = prdAgreementPrdinfoMapper.searchClinicAgreementInfoByParams(agreementMapParam);
					if(CollectionUtils.isEmpty(agreementAndSubAgreementList)){
						logger.error("【连锁诊所查询】agreementAndSubAgreementList的大小为0");
						continue;
					}
					VOPrdAgreementAndSubAgreementInfo vo = agreementAndSubAgreementList.get(0);
					if(StringUtils.isNotBlank(vo.getAgreementContractNo()) && !agreementNoStatus.containsKey(vo.getAgreementContractNo())){
						agreementNoList.add(vo.getAgreementContractNo());
						agreementNoStatus.put(vo.getAgreementContractNo(), vo.getAgreementContractStatus());
					}
					if(StringUtils.isNotBlank(vo.getSubAgreementContractNo()) && !subAgreementNoStatus.containsKey(vo.getSubAgreementContractNo())){
						sb1.append(vo.getSubAgreementContractId()+"|");
						subAgreementNoList.add(vo.getSubAgreementContractNo());
						subAgreementNoStatus.put(vo.getSubAgreementContractNo(), vo.getSubAgreementContractStatus());
					}
				}
				
				//对拼接的产品名字符串删除最后的“、”
				String prdNameStr = sb.toString();
				if(prdNameStr.indexOf("、") > 0){
					prdNameStr = prdNameStr.substring(0, prdNameStr.length()-1);
				}
				if(StringUtils.isNotBlank(prdNameStr)){
					settlement.setPrdNameStr(prdNameStr);					
				}
				
				String subAgreementNoStr = sb1.toString();
				if(subAgreementNoStr.indexOf("|") > 0){
					subAgreementNoStr = subAgreementNoStr.substring(0, subAgreementNoStr.length()-1);
				}
				if(StringUtils.isNotBlank(subAgreementNoStr)){
					settlement.setSubAgreementNoListJson(subAgreementNoStr);
				}
				if(agreementNoList.size() > 0){
					settlement.setAgreementNo(agreementNoList.get(0));
				}
				settlement.setPrdNameList(prdNameList);
				settlement.setSubAgreementNoList(subAgreementNoList);
			}
			response.setResult(finSettlementList);
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	}

	@Override
	public JsonResponse<VOPrdFinSettleCountForClinic> countPrdFinSettlementBillForChainClinic(Map<String, Object> map) {
		String chainRegisterId = (String)map.get("chainRegisterId");
		String settleMonthStr = (String)map.get("settleMonth");
		JsonResponse<VOPrdFinSettleCountForClinic> response = new JsonResponse<VOPrdFinSettleCountForClinic>();
		if(StringUtils.isBlank(chainRegisterId)){
			response.setStatus(Status.ERROR);
			response.setErrorMsg("参数连锁诊所为空");
			return response;
		}
		if(StringUtils.isBlank(settleMonthStr)){
			response.setStatus(Status.ERROR);
			response.setErrorMsg("参数结算年月为空");
		}
		try{
			VOPrdFinSettleCountForClinic vo = prdFinSettlementMapper.countSettlementDetailForChainToPagination(map);
			response.setResult(vo);
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	}
	
	
	
	
	
	@Override
	public JsonResponse<PrdFinSettlement> getPrdFinSettlementById(String id) {
		JsonResponse<PrdFinSettlement> response = new JsonResponse<PrdFinSettlement>();
		if(StringUtils.isBlank(id)){
			response.setStatus(Status.ERROR);
			response.setErrorMsg("参数ID为空");
			return response;
		}
		try{
			PrdFinSettlement vo = (PrdFinSettlement)prdFinSettlementMapper.findById(id);
			response.setResult(vo);
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	}

	@Override
	@Transactional
	public JsonResponse<String> handelBillReconStatus(Map<String, Object> map, String handelStatus, String clinicType) {
		JsonResponse<String> response = new JsonResponse<String>();
		String resMsg = null;
		String settleId = (String)map.get("settleId");
		String rejectDesc = (String)map.get("rejectDesc");
		
		try{
			PrdFinSettlement vo = (PrdFinSettlement)prdFinSettlementMapper.findById(settleId);
			if(vo == null){
				resMsg = "未查到对应的数据";
				response.setStatus(Status.ERROR);
				response.setErrorMsg(resMsg);
				return response;
			}
			
			vo.setModifyUser("CC_SYSTEM");
			vo.setModifyDate(new Date());
			
			map.put("modifyDate", new Date());
			map.put("modifyUser", "CC_SYSTEM");
			
			//单体诊所
			if("single".equals(clinicType)){
				
				if("reject".equals(handelStatus)){//对账有误，诊所驳回
					vo.setStatus("04");
					if(StringUtils.isNotBlank(rejectDesc)){
						vo.setRejectDesc(rejectDesc);
					}
					prdFinSettlementMapper.update(vo);
					map.put("status","04");
					map.put("rejectDesc", rejectDesc);
					prdFinSettlementDetailMapper.updateStatusForClinicConfirm(map);
					
					insertSettleLog(settleId,"07",rejectDesc);
				}else if("confirm".equals(handelStatus)){//诊所确认，待收发票
					vo.setStatus("05");
					prdFinSettlementMapper.update(vo);
					map.put("status","05");
					logger.error("****************************状态："+(String)map.get("settleId"));
					logger.error("****************************状态："+(String)map.get("clinicId"));
					logger.error("****************************状态："+(String)map.get("status"));
					prdFinSettlementDetailMapper.updateStatusForClinicConfirm(map);
					insertSettleLog(settleId,"08",null);
				}
			//子诊所
			}else if("sub".equals(clinicType)){
				if("reject".equals(handelStatus)){//对账有误，诊所驳回
					vo.setStatus("04");
					if(StringUtils.isNotBlank(rejectDesc)){
						vo.setRejectDesc(rejectDesc);
					}
					
					prdFinSettlementMapper.update(vo);
					map.put("status","04");
					map.put("rejectDesc", rejectDesc);
					prdFinSettlementDetailMapper.updateStatusForClinicConfirm(map);
					
					insertSettleLog(settleId,"07",rejectDesc);
				}else if("confirm".equals(handelStatus)){//诊所确认，待收发票
					String clinicId = (String)map.get("clinicId");
					String chainRegisterId = (String)map.get("chainRegisterId");
					Map<String, Object> detailMapParam = new HashMap<String, Object>();
					detailMapParam.put("delFlag", "0");
					detailMapParam.put("settleId", settleId);
					detailMapParam.put("clinicId", clinicId);
					detailMapParam.put("clinicRegisterId", chainRegisterId);
					//其他诊所统计
					Long allOtherNum = prdFinSettlementDetailMapper.countByPropertiesWithNotIncludeSelf(detailMapParam);
					detailMapParam.put("status", "05");
					//其他诊所已确认统计
					Long confirmNum = prdFinSettlementDetailMapper.countByPropertiesWithNotIncludeSelf(detailMapParam);
					if(allOtherNum > 0 || allOtherNum == confirmNum){
						vo.setStatus("05");
						//其他诊所都已确认，修改主表状态为已确认
						prdFinSettlementMapper.update(vo);
					}
					
					map.put("status","05");
					prdFinSettlementDetailMapper.updateStatusForClinicConfirm(map);
					insertSettleLog(settleId,"08",null);
				}
			}
			
			response.setResult("success");
		}catch(Exception e){
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
			response.setErrorMsg("账单处理失败");
		}
		return response;
	}
	
	private void insertSettleLog(String settleId,String operateType, String operateDesc){
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		PrdFinSettlementLog settleLog = new PrdFinSettlementLog();
		settleLog.setId(UUID.randomUUID().toString());
		settleLog.setSettleId(settleId);
		settleLog.setOperateType(operateType);
		settleLog.setOperateDesc(operateDesc);
		settleLog.setOperateUser("SYSTEM_CC");
		settleLog.setOperateDate(df1.format(new Date()));
		settleLog.setCreateDate(new Date());
		settleLog.setCreateUser("SYSTEM_CC");
		settleLog.setDelFlag("0");
		prdFinSettlementLogMapper.insert(settleLog);
	}
	
	@Override
	public JsonResponse<List<PrdFinSettlement>> getPrdFinSettlementByClinicRegisterId(Map<String, Object> paramMap) {
		JsonResponse<List<PrdFinSettlement>> response = new JsonResponse<List<PrdFinSettlement>>();
		try {
			List<PrdFinSettlement> list = (List<PrdFinSettlement>) prdFinSettlementMapper.selectSettlementDetailForChainGroup(paramMap);
			response.setResult(list);
		} catch (Exception e) {
			logger.error(e.getMessage());
			response.setStatus(Status.ERROR);
		}
		return response;
	}
	
}
