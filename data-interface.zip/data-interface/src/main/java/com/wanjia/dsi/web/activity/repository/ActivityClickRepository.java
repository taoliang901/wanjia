package com.wanjia.dsi.web.activity.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.mongodb.impl.MongoDbRepositoryImpl;
import com.wanjia.dsi.web.activity.model.ActivityClickBO;
import com.wanjia.dsi.web.activity.model.ActivityStatic;

@Repository
public class ActivityClickRepository extends MongoDbRepositoryImpl<ActivityClickBO> {

	@Resource
	private MongoTemplate mongoTemplate;
	
	/**
	 * 获取今天投票的统计数据，group by clinicId
	 * 
	 * @param voteDate
	 * @param clinicIds
	 * @return
	 */
	public List<ActivityStatic> getActivityClickCountListMongo(Date clickDate, List<String> activityIds) {
		List<ActivityStatic> result = new ArrayList<ActivityStatic>();

		try {
			String clickDateOfDay = DateUtils.format(clickDate, DateUtils.DATE_FORMAT_TYPE3);
			List<DBObject> pipeline = new ArrayList<DBObject>();
			// 记录过滤条件
			String matchStr = null;
			
			if (activityIds != null && activityIds.size() > 0) {
				StringBuffer activityOr = new StringBuffer("[");
				for (int i = 0; i < activityIds.size(); i++) {
					if (i == activityIds.size() - 1) {
						activityOr.append("{activityId: \"" + activityIds.get(i) + "\"}]");
					} else {
						activityOr.append("{activityId: \"" + activityIds.get(i) + "\"},");
					}
				}
				matchStr = "{$match:{clickDate:\"" + clickDateOfDay + "\",$or: " + activityOr.toString() + "}}";
			}else{
				matchStr = "{$match:{clickDate:\"" + clickDateOfDay + "\"}}";
			}
			
			
			DBObject match = (DBObject) JSON.parse(matchStr);
			pipeline.add(match);
			
			// 分组条件
			String groupStr = "{$group:{_id: {'activityId':'$activityId'}, clickToday:{$sum:1}}}";
			DBObject group = (DBObject) JSON.parse(groupStr);
			pipeline.add(group);
	
			// 获取数据
			DBCollection conn = mongoTemplate.getCollection("activityClickBO");
			AggregationOutput output = conn.aggregate(pipeline);
			for (Iterator<DBObject> it = output.results().iterator(); it.hasNext();) {
				BasicDBObject dbo = (BasicDBObject) it.next();
				BasicDBObject keyValus = (BasicDBObject) dbo.get("_id");
				ActivityStatic activityStatic = new ActivityStatic();
				activityStatic.setActivityId(keyValus.getString("activityId"));
				
				if ((Integer) dbo.get("clickToday") > 0) {
					activityStatic.setClickCount((Integer) dbo.get("clickToday"));
				} else {
					activityStatic.setClickCount(0);
				}
				result.add(activityStatic);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	
}
