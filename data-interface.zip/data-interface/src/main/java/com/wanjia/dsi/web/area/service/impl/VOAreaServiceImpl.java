package com.wanjia.dsi.web.area.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.web.area.dao.mapper.VOAreaMapper;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.area.model.VOArea;
import com.wanjia.dsi.web.area.service.VOAreaService;
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class VOAreaServiceImpl implements VOAreaService {
	
	private static final Logger logger = LoggerFactory.getLogger(VOAreaServiceImpl.class);

	
	@Autowired
	private VOAreaMapper voAreaMapper;
	
	@Override
	public JsonResponse<List<VOArea>> findCityByFirstStr() {
		JsonResponse<List<VOArea>> jr = new JsonResponse<List<VOArea>>();
		List<VOArea> list = new ArrayList<VOArea>();
		try {
			list = voAreaMapper.findCityByFirstStr();
			jr.setResult(list);
		} catch (Exception e) {
			logger.error("根据拼音首字母查询城市信息失败",e);
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("根据拼音首字母查询城市信息失败");
			e.printStackTrace();
		}
		return jr;
	}

	@Override
	public JsonResponse<VOArea> findCityByCharacter(String key) {
		JsonResponse<VOArea> jr =new JsonResponse<VOArea>();
		if(StringUtils.isEmpty(key)||key.length()!=1){
			logger.info("参数错误 key:"+key);
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("参数不合法");
			return jr;
		}
		key=StringUtils.lowerCase(key);
		 VOArea voArea = new VOArea(); 
		 try {
			voArea= voAreaMapper.findCityByCharacter(key);
			jr.setResult(voArea);
		} catch (Exception e) {
			logger.error("根据首字母查询城市信息失败 key:"+key,e);
			jr.setStatus(Status.ERROR);
			jr.setErrorMsg("根据首字母查询城市信息失败");
			e.printStackTrace();
		}
		return jr;
	}

}
