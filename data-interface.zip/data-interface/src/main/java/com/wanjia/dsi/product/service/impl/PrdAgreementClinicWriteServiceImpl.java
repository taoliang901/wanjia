package com.wanjia.dsi.product.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.model.PrdAgreementClinic;
import com.wanjia.dsi.product.service.PrdAgreementClinicWriteService;

/**
 * This element is automatically generated on 16-11-14 上午10:42, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class PrdAgreementClinicWriteServiceImpl implements PrdAgreementClinicWriteService {
    @Autowired
    private PrdAgreementClinicMapper prdAgreementClinicMapper;

	@Override
	public void insert(PrdAgreementClinic prdAgreementClinic) {
		
		prdAgreementClinicMapper.insert(prdAgreementClinic);
	}

	@Override
	public void update(PrdAgreementClinic prdAgreementClinic) {
		prdAgreementClinicMapper.update(prdAgreementClinic);
	}

	@Override
	public void deleteByEntity(PrdAgreementClinic prdAgreementClinic) {
		prdAgreementClinicMapper.deleteByEntity(prdAgreementClinic);
		
	}

	@Override
	public void deleteById(String id) {
		prdAgreementClinicMapper.deleteById(id);
		
	}

	@Override
	public void deleteAndUpdate(PrdAgreementClinic prdAgreementClinic) {
		PrdAgreementClinic f1 = new PrdAgreementClinic();
		f1.setAgreementId(prdAgreementClinic.getAgreementId());
		f1.setDelFlag("1");
		prdAgreementClinicMapper.deleteByAgreementId(f1.getAgreementId());
		
		prdAgreementClinicMapper.insert(prdAgreementClinic);
		
	}

    
}