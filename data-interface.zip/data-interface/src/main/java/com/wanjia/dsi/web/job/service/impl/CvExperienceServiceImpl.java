package com.wanjia.dsi.web.job.service.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvExperienceMapper;
import com.wanjia.dsi.web.job.model.TalentCvExperience;
import com.wanjia.dsi.web.job.model.TalentCvExperienceExample;
import com.wanjia.dsi.web.job.service.CvExperienceService;
import com.wanjia.dsi.web.job.service.CvService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CvExperienceServiceImpl implements CvExperienceService {

	@Autowired
	private TalentCvExperienceMapper mapper;
	
	@Autowired
	private CvService cvService;

	@Override
	public JsonResponse<List<TalentCvExperience>> getCvExperienceList(String cvId,String expId) {
		// 返回值
		JsonResponse<List<TalentCvExperience>> jr = new JsonResponse<List<TalentCvExperience>>();
		
		// 查询数据
		TalentCvExperienceExample example = new TalentCvExperienceExample();
		TalentCvExperienceExample.Criteria criteria = example.createCriteria();
		if(StringUtils.isNotEmpty(cvId)){
			criteria.andCvIdEqualTo(cvId);
		}
		if(StringUtils.isNotEmpty(expId)){
			criteria.andIdEqualTo(expId);
		}
		criteria.andDelFlagEqualTo("0");
		example.setOrderByClause("WORKING_START_TIME DESC");
		List<TalentCvExperience> exps = mapper.selectByExample(example);
		jr.setResult(exps);
		jr.setStatus(Status.SUCCESS);
		return jr;
	}

	@Override
	public JsonResponse<Void> modifyCvExperience(TalentCvExperience cvExperience) {
		// 返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		cvExperience.setModifyDate(new Date());
		mapper.updateByPrimaryKeySelective(cvExperience);
		
		// 更新简历状态
		cvService.modifyCvStatus(cvExperience.getCvId());
		jr.setStatus(Status.SUCCESS);
		return jr;
	}

	@Override
	public JsonResponse<Void> addCvExperience(TalentCvExperience cvExperience) {
		// 返回值
		JsonResponse<Void> jr = new JsonResponse<Void>();
		cvExperience.setId(UUID.randomUUID().toString());
		cvExperience.setDelFlag("0");
		cvExperience.setCreateDate(new Date());
		cvExperience.setCreateUser(cvExperience.getCvId());
		mapper.insertSelective(cvExperience);
		
		// 更新简历状态
		cvService.modifyCvStatus(cvExperience.getCvId());
		jr.setStatus(Status.SUCCESS);
		return jr;
	}

	@Override
	public JsonResponse<List<TalentCvExperience>> getCvExperienceTransDictList(String cvId, String expId) {
		// 返回值
				JsonResponse<List<TalentCvExperience>> jr = new JsonResponse<List<TalentCvExperience>>();
				
				// 查询数据
				TalentCvExperienceExample example = new TalentCvExperienceExample();
				TalentCvExperienceExample.Criteria criteria = example.createCriteria();
				if(StringUtils.isNotEmpty(cvId)){
					criteria.andCvIdEqualTo(cvId);
				}
				if(StringUtils.isNotEmpty(expId)){
					criteria.andIdEqualTo(expId);
				}
				criteria.andDelFlagEqualTo("0");
				List<TalentCvExperience> exps = mapper.selectByExample(example);
				jr.setResult(exps);
				jr.setStatus(Status.SUCCESS);
				return jr;
	}
}
