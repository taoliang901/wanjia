package com.wanjia.dsi.web.sms.service.impl;

import java.util.ArrayList;
import java.util.List;


import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.common.json.JSON;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.sms.dao.mapper.SmsLogInfoMapper;
import com.wanjia.dsi.web.sms.model.SmsLogInfo;
import com.wanjia.dsi.web.sms.model.SmsMessage;
import com.wanjia.dsi.web.sms.model.ValidateCode;
import com.wanjia.dsi.web.sms.service.SmsMessageService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class SmsMessageServiceImpl implements SmsMessageService {

	protected final Logger logger = LoggerFactory.getLogger(SmsMessageServiceImpl.class);
	@Autowired
	private SmsLogInfoMapper smsLogInfoMapper;

	@Override
	public JsonResponse<List<SmsMessage>> findMessageByPhone(String phone) {
		JsonResponse<List<SmsMessage>> jr = new JsonResponse<List<SmsMessage>>();
		// 为空不允许查询
		if (StringUtils.isEmpty(phone)) {
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.IllegalArgument.getCode());
			jr.setErrorMsg(ErrorType.IllegalArgument.getDesc());
			return jr;
		}
		List<SmsMessage> messageList = new ArrayList<SmsMessage>();
		try {
			List<SmsLogInfo> list = smsLogInfoMapper.findMessageByPhone(phone);

			// 可能查询的结果为空
			if (list == null || list.size() == 0) {
				jr.setStatus(Status.SUCCESS);
				return jr;
			}
			logger.info("list.size="+list.size());
			// 不为空的话取出所有的注册有关的信息
			for (SmsLogInfo smsLogInfo : list) {
				String message = smsLogInfo.getMessage();
				logger.info("message:"+message);
				// 模板是这个的话才需要进行反序列化
				if (StringUtils.isNotEmpty(message) && message.contains("JK160708001")) {
					SmsMessage smsMessage = JSON.parse(message, SmsMessage.class);
					// 反序列化成消息对象
					/*
					 * if (StringUtils.isNotEmpty(smsMessage.getREQUEST_MOBILE_NO())) {
					 * smsMessage.setMobileNo(smsMessage.getREQUEST_MOBILE_NO()); }
					 */
					smsMessage.setCreateDate(smsLogInfo.getCreateDate());
					// 判断jsonParam是否为空，不为空，直接手动截取
					if (!StringUtils.isEmpty(smsMessage.getJsonParam())) {
						ValidateCode code = JSON.parse(smsMessage.getJsonParam(), ValidateCode.class);
						smsMessage.setValidateCode(code.getValidateCode());
					}
					messageList.add(smsMessage);
					if (messageList.size() == 3) {
						break;
					}
				}
			}
			jr.setStatus(Status.SUCCESS);
			jr.setResult(messageList);
		} catch (Exception e) {
			logger.error("findMessageByPhone:" + e.getMessage(),e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(e.getMessage());
		}

		return jr;
	}

}
