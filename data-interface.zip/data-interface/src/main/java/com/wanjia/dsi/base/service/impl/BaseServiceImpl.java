package com.wanjia.dsi.base.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.StringUtil;
import com.wanjia.dsi.common.error.ErrorType;

public class BaseServiceImpl {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * 判空
	 * 
	 * @param params
	 * @throws Exception
	 */
	protected void checkParams(String... params) throws Exception {
		if (params != null) {
			for (String param : params) {
				if (StringUtils.isBlank(param)) {
					throw new Exception(ErrorType.MustPassParameter.getDesc());
				}
			}
		}
	}

	/**
	 * 判空
	 * 
	 * @param params
	 * @throws Exception
	 */
	protected void checkParamsContains(String regex, String... params) throws Exception {
		if (params != null) {
			for (String param : params) {
				if (StringUtils.isBlank(param)) {
					if (!param.contains(regex)) {
						throw new Exception(ErrorType.IllegalArgument.getDesc());
					}

				}
			}
		}
	}

	public void pringLog(Object object) {

		if (object == null) {
			logger.info("object is null");
		} else {
			logger.info(object.toString());
		}

	}

	public void error(Object object) {

		if (object == null) {
			logger.info("object is null");
		} else {
			logger.info(object.toString());
		}

	}

	public <T> Object getT(String object, Class<T> t) {
		T parseObject = null;
		try {
			parseObject = JSONObject.parseObject(object, t);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return parseObject;
	}

	public String getCityByIpOnTaobao(String ip, String debugSwitch, String getCityListFromTabao) {

		String city = "";
		try {

			if (debugSwitch != null && "1".equals(debugSwitch)) {
				Properties prop = System.getProperties();
				// 设置http访问要使用的代理服务器的地址
				prop.setProperty("http.proxyHost", "10.37.84.115");
				// 设置http访问要使用的代理服务器的端口
				prop.setProperty("http.proxyPort", "8080");
			}

			city = restTemplate.getForObject(getCityListFromTabao + "?ip=" + ip, String.class);

		} catch (RestClientException e1) {
			logger.error(e1.getMessage());
		} finally {
			if (debugSwitch != null && "1".equals(debugSwitch)) {
				System.getProperties().clear();
			}

		}
		return city;
	}

	public String getCityByIpOnSina(String ip, String debugSwitch, String getCityListFromSina) {

		String city = "";
		try {

			/*
			 * if (debugSwitch != null && "1".equals(debugSwitch)) { Properties
			 * prop = System.getProperties(); // 设置http访问要使用的代理服务器的地址
			 * prop.setProperty("http.proxyHost", "10.37.84.115"); //
			 * 设置http访问要使用的代理服务器的端口 prop.setProperty("http.proxyPort", "8080");
			 * }
			 */

			city = restTemplate.getForObject(getCityListFromSina + "?ip=" + ip + "&format=json", String.class);

		} catch (RestClientException e1) {
			logger.error("getCityListFromSina error:" + e1.getMessage());
			city = restTemplate.getForObject(getCityListFromSina + "?ip=" + ip + "&format=json", String.class);
		} finally {
			if (debugSwitch != null && "1".equals(debugSwitch)) {
				System.getProperties().clear();
			}

		}
		return city;
	}

	public String getCityByIpOnGaode(String ip, String debugSwitch, String getCityListFromGaode) {

		String city = "";
		try {

			/*
			 * if (debugSwitch != null && "1".equals(debugSwitch)) { Properties
			 * prop = System.getProperties(); // 设置http访问要使用的代理服务器的地址
			 * prop.setProperty("http.proxyHost", "10.37.84.115"); //
			 * 设置http访问要使用的代理服务器的端口 prop.setProperty("http.proxyPort", "8080");
			 * }
			 */
			city = restTemplate.getForObject(getCityListFromGaode + "&ip=" + ip, String.class);

		} catch (RestClientException e1) {
			logger.error("getCityListFromSina error:" + e1.getMessage());
			city = restTemplate.getForObject(getCityListFromGaode + "&ip=" + ip, String.class);
		} finally {
			if (debugSwitch != null && "1".equals(debugSwitch)) {
				System.getProperties().clear();
			}
		}
		return city;
	}

	public Map<String, String> getPageNoAndPageSize(String pageNo, String pageSize) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("pageNo", StringUtil.isEmpty(pageNo) ? "1" : pageNo);
		map.put("pageSize", StringUtil.isEmpty(pageSize) ? "10" : pageSize);
		return map;

	}

}
