package com.wanjia.dsi.product.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.utils.StringUtils;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.product.dao.mapper.PrdFinSettlementDetailMapper;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdKucunMapper;
import com.wanjia.dsi.product.model.PrdAgreementPrdinfo;
import com.wanjia.dsi.product.model.PrdFinSettlementDetail;
import com.wanjia.dsi.product.model.PrdFinSettlementDetailVo;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.SettleStatus;
import com.wanjia.dsi.product.model.SettleType;
import com.wanjia.dsi.product.service.PrdAgreementPrdinfoService;
import com.wanjia.dsi.product.service.ProductBalanceService;

@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class ProductBalanceServiceImpl implements ProductBalanceService {
	private static final Logger logger = LoggerFactory.getLogger(ProductBalanceServiceImpl.class);
	
	@Autowired
	private PrdFinSettlementDetailMapper prdFinSettlementDetailMapper;
	@Autowired
	private PrdAgreementPrdinfoService prdAgreementPrdinfoService;
	@Autowired
	private PrdInfoMapper prdInfoMapper;
	@Autowired
	private PrdKucunMapper prdKucunMapper;
	@Autowired
	private CommonJedis commonJedis;
	
	private final static String NOT_DEL_FLAG = "0";
	
	private final static String redisPrefix = "stock_balance_update";
	
	@Override
	public JsonResponse<List<PrdFinSettlementDetailVo>> updateCardBalanceForHistory(String beginDate, String endDate) {
		JsonResponse<List<PrdFinSettlementDetailVo>> response = new JsonResponse<List<PrdFinSettlementDetailVo>>();
		List<PrdFinSettlementDetailVo> volist = new ArrayList<PrdFinSettlementDetailVo>();
		
		try{
			//第一步，获取起始和截止时间内的账单中涉及的产品和卡
			Map<String, Object> map = new HashMap<String,Object>();
			map.put("beginDate", beginDate);
			map.put("endDate", endDate);
			map.put("status", SettleStatus.AlreadyPay.getValue());
			List<PrdFinSettlementDetailVo> list = prdFinSettlementDetailMapper.queryCardGroupByPrd(map);
			if(list!=null && !list.isEmpty()){
				for(PrdFinSettlementDetailVo vo : list){
					
					//第二步，判断是否存在合同，存在合同则说明初始余额的值可能需要变更
					map.clear();
					map.put("prdId", vo.getPrdId());
					map.put("delFlag", NOT_DEL_FLAG);
					List<PrdAgreementPrdinfo> paList = prdAgreementPrdinfoService.findByProperties(map);
					if(paList!=null && !paList.isEmpty()){
						PrdAgreementPrdinfo prdAgreementPrdinfo = paList.get(0);
						BigDecimal price = new BigDecimal(prdAgreementPrdinfo.getPrice());//合同价格
						
						PrdInfo prd = prdInfoMapper.selectByPrimaryKey(vo.getPrdId());
						if(prd!=null && StringUtils.isNotEmpty(prd.getSettlementValue())){//产品结算价
							BigDecimal prdPrice = new BigDecimal(prd.getSettlementValue());
							BigDecimal diff = price.subtract(prdPrice);
							
							//获取当前产品的所有卡
							List<PrdFinSettlementDetail> detailList = vo.getChildren();
							if(detailList!=null && !detailList.isEmpty()){
								for(PrdFinSettlementDetail detail : detailList){
									
									//判断是否存在redis中，若存在，则说明是处理过的卡，不能重复处理
									if(commonJedis.exists(redisPrefix+detail.getCardId())){
										continue;
									}
									
									//获取库存
									PrdFinSettlementDetailVo pfdVo = new PrdFinSettlementDetailVo();
									pfdVo.setCardId(detail.getCardId());
									PrdKucun stock = prdKucunMapper.selectByPrimaryKey(detail.getCardId());
									
									//若合同价格和产品原价相同，则目前的卡余额置为0
									if(diff.compareTo(BigDecimal.valueOf(0))==0){
										
										if(SettleType.MONTH_WHOLE.getValue().equals(prdAgreementPrdinfo.getSettleType())){
											stock.setBalance("0");
											prdKucunMapper.updateByPrimaryKeySelective(stock);
											
											//表示本次更新之前，余额一直是产品的结算价，从未被更新过，本次将一次
											pfdVo.setDifference(price+"");
										}else{
											
											//按比例结，
											pfdVo.setDifference("0");
										}
									}
									
									//若合同价格和产品原价不相同，则需要处理余额，将目前的卡余额加上当前的差值
									else{
										String origBalance = stock.getBalance();
										if(StringUtils.isNotEmpty(origBalance)){
											BigDecimal newBalance = new BigDecimal(origBalance).add(diff); 
											stock.setBalance(newBalance+"");
											prdKucunMapper.updateByPrimaryKeySelective(stock);
											
											//将成功更新的差额保存下来
											pfdVo.setDifference(diff+"");
										}else{
											
											//0表示没有更新，因为不存在余额
											pfdVo.setDifference("0");
										}
									}
									
									volist.add(pfdVo);
									
									//将处理完的卡存入redis，保证重跑时不会重复处理
									commonJedis.putObject(redisPrefix+pfdVo.getCardId(), pfdVo.getDifference());
								}
							}
							
						}
						
					}
					
				}
			}
			
			response.setResult(volist);
			response.setStatus(JsonResponse.Status.SUCCESS);
			
		}catch(Exception e){
			//删除redis中保存的所有回滚的卡记录
			if(volist!=null && !volist.isEmpty()){
				for(PrdFinSettlementDetailVo vo : volist){
					commonJedis.removeObject(redisPrefix+vo.getCardId());
				}
			}
			
			response.setStatus(JsonResponse.Status.ERROR);
			logger.error("更新历史账单卡余额失败！", e);
		}
		
		return response;
	}

	
}
