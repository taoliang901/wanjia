/**
 * 
 */
package com.wanjia.dsi.common.utils;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author huanglei698
 *
 */
@Service
public class RedisPublish {

	private Logger logger = Logger.getLogger(RedisPublish.class);

	@Autowired
	private CommonJedis commonJedis;

	public void publishMessage(String channel, String message) {
		commonJedis.publish(channel, message);
		logger.info("已被调用：" + channel + "的消息是" + message);
	}

}
