package com.wanjia.dsi.web.area.service.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.area.dao.mapper.PickerMUIMapper;
import com.wanjia.dsi.web.area.model.PickerMUI;
import com.wanjia.dsi.web.area.service.PickerMUIService;
import com.wanjia.dsi.web.clinic.model.VOClinicProduct;

@Service
@SuppressWarnings("unchecked")
@com.alibaba.dubbo.config.annotation.Service
public class PickerMUIServiceImpl implements PickerMUIService {
	@Autowired
	PickerMUIMapper pickerMUIMapper;

	@Override
	public JsonResponse<List<PickerMUI>> getCityDistrict(VOClinicProduct voClinicProduct) {

		JsonResponse<List<PickerMUI>> result = new JsonResponse<List<PickerMUI>>();
		try {
			List<PickerMUI> pickerMUIList = null;
			String totalRegisterId = voClinicProduct.getTotalRegisterId();//注册id
			
			if(StringUtils.isEmpty(totalRegisterId)){//没有传总诊所id
				pickerMUIList = pickerMUIMapper.getCityDistrict(voClinicProduct);
			}else{//通过总诊所id查询对应城市区县信息
				pickerMUIList = pickerMUIMapper.getCityDistrictByTotalAccount(voClinicProduct);
			}
			result.setResult(pickerMUIList);
			result.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

}
