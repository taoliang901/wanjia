package com.wanjia.dsi.web.jobYLRC.service.impl;


import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.job36.mobile.webservice.MemInfoWebService;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.jobYYRC.dao.mapper.YyrcAccountMapper;
import com.wanjia.dsi.web.jobYYRC.model.MemInfo;
import com.wanjia.dsi.web.jobYYRC.model.YyrcAccount;
import com.wanjia.dsi.web.jobYYRC.model.YyrcAccountExample;
import com.wanjia.dsi.web.jobYYRC.service.JobYYRCAccountService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class JobYYRCAccountServiceImpl extends BaseServiceImpl implements JobYYRCAccountService {

	@Autowired
	private YyrcAccountMapper yyrcAccountMapper;
	
	/*@Autowired
	private MemInfoWebService memInfoWebService;*/
	
	@Override
	public JsonResponse<Void> addAccount(YyrcAccount yyrcAccount) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		if(StringUtils.isBlank(yyrcAccount.getClinicId())){
			result.setErrorMsg("参数错误,clinicId不能为空！");
			return result;
		}
		try{
			yyrcAccount.setId(UUID.randomUUID().toString());
			yyrcAccount.setDelFlag("0");
			yyrcAccountMapper.insertSelective(yyrcAccount);	
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("addAccount异常！",e);
			result.setErrorMsg("addAccount异常！");
		}
		return result;
	}

	@Override
	public JsonResponse<Void> deleteAccountByClinicId(String clinicId) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		if(StringUtils.isBlank(clinicId)){
			result.setErrorMsg("参数错误！");
			return result;
		}
		try{
			yyrcAccountMapper.deleteAccountByClinicId(clinicId);
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("deleteAccountByClinicId异常！",e);
			result.setErrorMsg("deleteAccountByClinicId异常！");
		}
		return result;
	}

	@Override
	public JsonResponse<YyrcAccount> selectAccountByClinicId(String clinicId) {
		JsonResponse<YyrcAccount> result = new JsonResponse<YyrcAccount>();
		if(StringUtils.isBlank(clinicId)){
			result.setErrorMsg("参数错误！");
			return result;
		}
		try{
			YyrcAccountExample example = new YyrcAccountExample();
			example.createCriteria().andClinicIdEqualTo(clinicId).andDelFlagEqualTo("0");
			List<YyrcAccount> list = yyrcAccountMapper.selectByExample(example);
			if(!list.isEmpty() && list.size() > 0){
				result.setResult(list.get(0));
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("selectAccountByClinicId异常！",e);
			result.setErrorMsg("selectAccountByClinicId异常！");
		}
		return result;
	}
	
	@Override
	public JsonResponse<MemInfo> registMem(MemInfo memInfo) {
		JsonResponse<MemInfo> result = new JsonResponse<MemInfo>();
		try {
			
			JsonResponse<YyrcAccount> jrAccount = selectAccountByClinicId("pinganwj");
			if(jrAccount != null && jrAccount.getResult() != null && jrAccount.getResult().getId() != null){
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg("已注册！");
				return result;
			}
			
			String jsonStr  = "";//memInfoWebService.regist(memInfo);
//			System.out.println(jsonStr);
			
			jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
			JSONObject obj = JSONObject.parseObject(jsonStr);
			if(obj.getString("code") != null && "E200".equals(obj.getString("code"))){
				JSONObject data = (JSONObject) obj.get("data");
				MemInfo returnMemInfo = JSONObject.toJavaObject(data, MemInfo.class);
				if(returnMemInfo != null){
					result.setResult(returnMemInfo);
					
					YyrcAccount yyrcAccount = new YyrcAccount();
					yyrcAccount.setId(UUID.randomUUID().toString());
					yyrcAccount.setClinicId("pinganwj");
					yyrcAccount.setDelFlag("0");
					yyrcAccount.setLoginName(returnMemInfo.getAccName());
					yyrcAccount.setPassword(returnMemInfo.getAccPwd());
					yyrcAccount.setYyrcUserId(returnMemInfo.getMemId()+"");
					yyrcAccount.setName(returnMemInfo.getMemName());
					addAccount(yyrcAccount);
				}
			}else{
				if(obj.getString("message") != null && obj.getString("message") != null){
					result.setErrorMsg(obj.getString("message"));
				}else{
					result.setErrorMsg(ErrorType.SystemBusy.getDesc());
				}
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("regist异常！",e);
			result.setErrorMsg("系统异常！");
		}
		return result;
	}
	
}
