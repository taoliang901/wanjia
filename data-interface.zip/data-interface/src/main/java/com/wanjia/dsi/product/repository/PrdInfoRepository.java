package com.wanjia.dsi.product.repository;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.wanjia.dsi.base.mongodb.impl.MongoDbRepositoryImpl;
import com.wanjia.dsi.product.model.PrdInfoBO;
@Repository
public class PrdInfoRepository extends MongoDbRepositoryImpl<PrdInfoBO>{
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private MongoTemplate mongoTemplate;
}
