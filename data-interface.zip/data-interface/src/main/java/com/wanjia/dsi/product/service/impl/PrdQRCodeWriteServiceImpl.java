package com.wanjia.dsi.product.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.product.dao.mapper.PrdQRCodeMapper;
import com.wanjia.dsi.product.model.PrdQRCode;
import com.wanjia.dsi.product.service.PrdQRCodeWriteService;

/**
 * This element is automatically generated on 16-9-21 下午4:20, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdQRCodeWriteServiceImpl implements  PrdQRCodeWriteService {
	@Autowired
	private PrdQRCodeMapper prdQRCodeMapper;
	
	@Override
	public void insert(PrdQRCode prdQRCode) {
		prdQRCodeMapper.insert(prdQRCode);
		
	}

	@Override
	public void update(PrdQRCode prdQRCode) {
		prdQRCodeMapper.update(prdQRCode);
		
	}
    
}