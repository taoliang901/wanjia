package com.wanjia.dsi.web.cms.activity.service.impl;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.cms.activity.model.MyCollectionBO;
import com.wanjia.dsi.web.cms.activity.model.MyCollectionStatisticsBO;
import com.wanjia.dsi.web.cms.activity.model.VOMyCollection;
import com.wanjia.dsi.web.cms.activity.repository.MyCollectionRepository;
import com.wanjia.dsi.web.cms.activity.repository.MyCollectionStatisticsRepository;
import com.wanjia.dsi.web.cms.activity.model.LocalMedicine;
import com.wanjia.dsi.web.activity.model.Activity;
import com.wanjia.dsi.web.activity.service.ActivityService;
import com.wanjia.dsi.web.cms.activity.model.DiseaseSmryInfo;
import com.wanjia.dsi.web.cms.activity.service.DiseaseSmryInfoService;
import com.wanjia.dsi.web.cms.activity.service.LocalMedicineService;
import com.wanjia.dsi.web.cms.activity.service.MycollectionService;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class MyCollectionServiceImpl implements MycollectionService {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	MyCollectionRepository repository;
	@Autowired
	MyCollectionStatisticsRepository statisticsRepository;
	@Autowired
	LocalMedicineService localMedicineService;
	@Autowired
	DiseaseSmryInfoService diseaseSmryInfoService;
	@Autowired
	ActivityService activityService;
	
	@Override
	public JsonResponse<Void> insertMycollection(MyCollectionBO myCollectionBO) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		try {
			String infoId = myCollectionBO.getInfoId();
			String source = myCollectionBO.getSource();
			String userId = myCollectionBO.getUserId();
			String type = myCollectionBO.getType();
			logger.info("MyCollectionServiceImpl->insertMycollection,infoId:" + infoId + ",source:" + source + ",userId:" + userId + ",type:" + type);
			if (StringUtils.isNotBlank(infoId) && StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(type)) {
				Date now = new Date();
				myCollectionBO.setCollectionTime(now);
				myCollectionBO.setCollectionDate(DateUtils.format(now, DateUtils.DATE_FORMAT_TYPE3));
				
				//判断是否已经收藏
				boolean b = repository.exists(new Query(Criteria.where("userId").is(userId).andOperator(Criteria.where("infoId").is(infoId),Criteria.where("type").is(type))), MyCollectionBO.class);
				if(!b){//已经收藏就不保存到mongo
					repository.insert(myCollectionBO, MyCollectionBO.class);
					boolean statis = statisticsRepository.exists(new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type))), MyCollectionStatisticsBO.class);
					if(!statis){//不是第一次被收藏。需要保存到统计表
						// 保存收藏量统计
						MyCollectionStatisticsBO myCollectionStatisticsBO = new MyCollectionStatisticsBO();
						int randomNum = CommonTools.getRandIntRange(300, 500);  
						myCollectionStatisticsBO.setRandomNum(randomNum);//初始化随机访问量
						myCollectionStatisticsBO.setRealCountNum(1); //实际访问量
						myCollectionStatisticsBO.setCountNum(randomNum + 1); //访问量=随机量+实际访问量
						myCollectionStatisticsBO.setInfoId(infoId);
						myCollectionStatisticsBO.setType(type);
						statisticsRepository.insert(myCollectionStatisticsBO, MyCollectionStatisticsBO.class);
					}else{
						Query query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
						Update update = new Update();
						update.inc("countNum", 1);//总阅读量加1
						update.inc("realCountNum", 1);//实际阅读量加1
						statisticsRepository.updateFirst(query, MyCollectionStatisticsBO.class, update);
					}
				}
				result.setStatus(Status.SUCCESS);
			} else {
				logger.error("MyCollectionServiceImpl->insertMycollection: infoId or source or type is null");
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.IllegalArgument.getCode());
				result.setErrorMsg(ErrorType.IllegalArgument.getDesc());
			}
		} catch (Exception e) {
			logger.error("MyCollectionServiceImpl->insertMycollection,infoId:" + myCollectionBO.getInfoId());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<PageInfo<LocalMedicine>>  getMyLocalMedicine(VOMyCollection voMyCollection) {
		String userId = voMyCollection.getUserId();
		String type = voMyCollection.getType();
		String infoId = voMyCollection.getInfoId();
		String pageSize = voMyCollection.getPageSize();
		String pageNo = voMyCollection.getPageNo();
		List<String> infoIdList = repository.getInfoIdListMongo(userId, type,infoId);
		if (infoIdList == null || infoIdList.isEmpty()) {
			return null;
		}
		return localMedicineService.getLocalMedicine(infoIdList,pageSize,pageNo);
	}

	@Override
	public JsonResponse<PageInfo<DiseaseSmryInfo>>  getMyDiseaseSmryInfo(VOMyCollection voMyCollection) {
		String userId = voMyCollection.getUserId();
		String type = voMyCollection.getType();
		String infoId = voMyCollection.getInfoId();
		String pageSize = voMyCollection.getPageSize();
		String pageNo = voMyCollection.getPageNo();
		List<String> infoIdList = repository.getInfoIdListMongo(userId, type,infoId);
		if (infoIdList == null || infoIdList.isEmpty()) {
			return null;
		}
		return diseaseSmryInfoService.getDiseaseSmryInfo(infoIdList,pageSize,pageNo);
	}

	@Override
	public JsonResponse<PageInfo<Activity>>  getMyActivity(VOMyCollection voMyCollection) {
		String userId = voMyCollection.getUserId();
		String type = voMyCollection.getType();
		String infoId = voMyCollection.getInfoId();
		String pageSize = voMyCollection.getPageSize();
		String pageNo = voMyCollection.getPageNo();
		List<String> infoIdList = repository.getInfoIdListMongo(userId, type,infoId);
		if (infoIdList == null || infoIdList.isEmpty()) {
			return null;
		}
		return activityService.getMyActivity(infoIdList,pageSize,pageNo);
	}

	@Override
	public JsonResponse<Void> deleteMyCollection(String userId, String type,String infoId) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		try{
			repository.deleteBatch(new Query(Criteria.where("userId").is(userId).andOperator(Criteria.where("infoId").is(infoId),Criteria.where("type").is(type))), MyCollectionBO.class);
			Query query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
			Update update = new Update();
			update.inc("countNum", -1);//总收藏量加-1
			update.inc("realCountNum", -1);//实际收藏量加-1
			statisticsRepository.updateFirst(query, MyCollectionStatisticsBO.class, update);
			result.setStatus(Status.SUCCESS);
		}catch(Exception e){
			logger.error("MyCollectionServiceImpl->deleteMyCollection,infoId:" + infoId + ",userId:" + userId + ",type:" + type);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<Boolean> isExists(String userId, String type, String infoId) {
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		try {
			boolean b = repository.exists(new Query(Criteria.where("userId").is(userId)
					.andOperator(Criteria.where("infoId").is(infoId), Criteria.where("type").is(type))),MyCollectionBO.class);
			result.setResult(b);
			result.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("MyCollectionServiceImpl->isExists,infoId:" + infoId + ",userId:" + userId + ",type:"
					+ type);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<PageInfo<VOMyCollection>> getCollectionStatistic(VOMyCollection voMyCollection) {
		JsonResponse<PageInfo<VOMyCollection>> jr = new JsonResponse<PageInfo<VOMyCollection>>();
		String infoId = voMyCollection.getInfoId();
		String type = voMyCollection.getType();
		logger.info("MyCollectionServiceImpl->getCollectionStatistic,infoId:" + infoId + ",type:" + type);
		try {
			String pageNo = voMyCollection.getPageNo();
			String pageSize = voMyCollection.getPageSize();
			// 设置分页参数
			if (StringUtils.isBlank(pageNo)) {
				pageNo = "1";
			}
			// 设置分页参数
			if (StringUtils.isBlank(pageSize)) {
				pageSize = "10";
			}
			PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));
			List<VOMyCollection> result = repository.getCollectionStatistic(type, infoId);
			PageInfo<VOMyCollection> page = new PageInfo<VOMyCollection>(result);
			jr.setResult(page);
			jr.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			logger.error("MyCollectionServiceImpl->getCollectionStatistic:" + e.toString());
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return jr;
	}

	@Override
	public JsonResponse<List<MyCollectionStatisticsBO>> getCollectionStatistic(String type, List<String> infoIds) {
		JsonResponse<List<MyCollectionStatisticsBO>> result = new JsonResponse<List<MyCollectionStatisticsBO>>();
		logger.info("MyCollectionServiceImpl->getCollectionStatistic start ,type:" + type);
		try{
				
			for(String infoId:infoIds){
				//判断是否已经统计过
				boolean statis = statisticsRepository.exists(new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type))), MyCollectionStatisticsBO.class);
				if(!statis){//不是第一次被收藏。需要保存到统计表
					// 保存收藏量统计
					MyCollectionStatisticsBO myCollectionStatisticsBO = new MyCollectionStatisticsBO();
					int randomNum = CommonTools.getRandIntRange(300, 500);  
					myCollectionStatisticsBO.setRandomNum(randomNum);//初始化随机访问量
					myCollectionStatisticsBO.setRealCountNum(0); //实际访问量
					myCollectionStatisticsBO.setCountNum(randomNum); //访问量=随机量+实际访问量
					myCollectionStatisticsBO.setInfoId(infoId);
					myCollectionStatisticsBO.setType(type);
					statisticsRepository.insert(myCollectionStatisticsBO, MyCollectionStatisticsBO.class);
				}
			}
			Query query;
				if(infoIds != null && infoIds.size() >0){
					//query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
					query = new Query(Criteria.where("infoId").in(infoIds).andOperator(Criteria.where("type").is(type)));
				}else{
					query = new Query(Criteria.where("type").is(type));
				}
				List<MyCollectionStatisticsBO> infomationList = statisticsRepository.find(query, MyCollectionStatisticsBO.class);
				//PageInfo<InfomationStatistcBO> page = new PageInfo<InfomationStatistcBO>(infomationList);
				result.setResult(infomationList);
				result.setStatus(Status.SUCCESS);	
				logger.info("MyCollectionServiceImpl->getCollectionStatistic end ");
		}catch(Exception e){
			logger.error("MyCollectionServiceImpl->getCollectionStatistic  " + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public synchronized JsonResponse<String> syncMycollectionStatistc(String dateStr,String type) {
		JsonResponse<String> jr = new JsonResponse<String>();
		jr.setResult(repository.syncMycollectionStatistc(dateStr,type));
		return jr;
	}

	@Override
	public synchronized JsonResponse<String>  initMycollectionStatistc(String type, List<String> infoIds) {
		JsonResponse<String> result = new JsonResponse<String>();
		if (infoIds == null || infoIds.size() < 0) {
			result.setResult("id列表为空，不需要同步！");
			result.setStatus(Status.SUCCESS);
			return result;
		}
		logger.info("MyCollectionServiceImpl->initMycollectionStatistc start ,type:" + type + ",infoIdsSize:" + infoIds.size());
		ExecutorService exe = null;
		try {
			int size = infoIds.size(); // 总条数
			int thNum = 4; // 启动最大线程数
			int everyTimeExeNum = 1000; // 每次最多执行条数
			int maxDeal = 10000; // 单线程启动最大条数
			int num = size / everyTimeExeNum; // 需要执行批数
			int residueEvery = size % everyTimeExeNum; // 总数除每次执行数目的余数
			if (residueEvery > 0) {// 整除有余数时，要加1次出来
				num = num + 1;
			}
			if (size > maxDeal) {// 大于10000，就启动多线程
				if (num <= thNum) {// 总批数小于等于启动线程数，启动线程数按照总批数

					exe = Executors.newFixedThreadPool(num);
					for (int i = 0; i < num; i++) {
						int beginIndex = i * everyTimeExeNum;
						int endTmp = i * everyTimeExeNum + everyTimeExeNum - 1;
						if (i == num - 1) {// 最后一批，需要取最后余数
							endTmp = i * everyTimeExeNum + residueEvery - 1;
						}
						int endIndex = endTmp;
						exe.execute(new Runnable() {
							@Override
							public void run() {
								insertMycollectionStatistics(type, infoIds, beginIndex, endIndex);
							}
						});
					}
					exe.shutdown();
					while (true) {
						if (exe.isTerminated()) {
							logger.info("InfomationServiceImpl->initInfomationStatistic end,Executors  isTerminated");
							break;
						}
						Thread.sleep(10000);
					}
				} else {// 总批数大于启动线程数，启动线程数按照最大启动
					exe = Executors.newFixedThreadPool(thNum);
					for (int th = 0; th < num; th++) {
						int beginIndex = th * everyTimeExeNum;
						int endTmp = th * everyTimeExeNum + everyTimeExeNum - 1;
						if (th == num - 1) {// 最后一批，需要取最后余数
							endTmp = th * everyTimeExeNum + residueEvery - 1;
						}
						int endIndex = endTmp;
						exe.execute(new Runnable() {
							@Override
							public void run() {
								insertMycollectionStatistics(type, infoIds, beginIndex, endIndex);
							}
						});
					}
					exe.shutdown();
					while (true) {
						if (exe.isTerminated()) {
							logger.info("InfomationServiceImpl->initInfomationStatistic end,Executors  isTerminated");
							break;
						}
						Thread.sleep(10000);
					}
				}
			} else {// 小于10000直接插入，不用多线程
				insertMycollectionStatistics(type, infoIds, 0, size - 1);
			}
			result.setStatus(Status.SUCCESS);
			// result.setResult("总条数:" + infoIds.size() + ",新增条数：" + count);
			result.setResult("初始化我的收藏成功，总条数:" + size);
			infoIds.clear();
			logger.info("MyCollectionServiceImpl->initMycollectionStatistc end ,type:" + type + ",infoIdsSize:" + infoIds.size());
		} catch (Exception e) {
			logger.error("MyCollectionServiceImpl->initMycollectionStatistc end " + e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		} finally {
			if (exe != null) {
				exe.shutdown();
			}
			logger.info("InfomationServiceImpl->initInfomationStatistic finally ExecutorService:"  + exe);
		}
		return result;
	}
	
	/**
	 * 插入数据到我的收藏统计表
	 * @param infoIds  各个类型统计id 必填
	 * @param type 类型 ；资讯：A，药品：M ，疾病：D  必填 
	 * @param beginIndex infoIds的开始索引
	 * @param endIndex   infoIds的结束索引
	 */
	public void insertMycollectionStatistics(String type,List<String> infoIds,int beginIndex,int endIndex){
		
		for(int k=beginIndex;k<=endIndex;k++){
			
			String infoId = infoIds.get(k);
			//判断是否已经统计过
			boolean statis = statisticsRepository.exists(new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type))), MyCollectionStatisticsBO.class);
			if(!statis){//不是第一次被收藏。需要保存到统计表
				if(StringUtils.isNotBlank(infoId)){
					// 保存收藏量统计
					MyCollectionStatisticsBO myCollectionStatisticsBO = new MyCollectionStatisticsBO();
					int randomNum = CommonTools.getRandIntRange(300, 500);  
					myCollectionStatisticsBO.setRandomNum(randomNum);//初始化随机访问量
					myCollectionStatisticsBO.setRealCountNum(0); //实际访问量
					myCollectionStatisticsBO.setCountNum(randomNum); //访问量=随机量+实际访问量
					myCollectionStatisticsBO.setInfoId(infoId);
					myCollectionStatisticsBO.setType(type);
					statisticsRepository.insert(myCollectionStatisticsBO, MyCollectionStatisticsBO.class);
				}
				
			}
		}
	}
	
}
