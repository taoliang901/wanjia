package com.wanjia.dsi.web.dictionary.service.impl;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.esotericsoftware.minlog.Log;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.dictionary.dao.mapper.DictionaryMapper;
import com.wanjia.dsi.web.dictionary.model.Dictionary;
import com.wanjia.dsi.web.dictionary.model.Element;
import com.wanjia.dsi.web.dictionary.model.ElementResult;
import com.wanjia.dsi.web.dictionary.service.DictionaryService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-3-2 下午1:29, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class DictionaryServiceImpl extends BaseServiceImpl implements DictionaryService {
	@Autowired
	private DictionaryMapper dictionaryMapper;

	@Autowired
	private CommonJedis commonJedis;

	@Value("#{jedisConfig['expirationTime']}")
	private int expirationTime;

	@Override
	public Dictionary findById(String id) {
		return (Dictionary) dictionaryMapper.findById(id);
	}

	@Override
	public List<Dictionary> findWithPagination(int offset, int count) {
		return (List<Dictionary>) dictionaryMapper.findWithPagination(offset, count);
	}

	@Override
	public List<Dictionary> findAll() {
		return (List<Dictionary>) dictionaryMapper.findAll();
	}

	@Override
	public List<Dictionary> findByEntity(Dictionary model) {
		return (List<Dictionary>) dictionaryMapper.findByEntity(model);
	}

	@Override
	public List<Dictionary> findByEntityWithPagination(Dictionary model, int offset, int count) {
		return (List<Dictionary>) dictionaryMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	public Dictionary findOneByEntity(Dictionary model) {
		return (Dictionary) dictionaryMapper.findOneByEntity(model);
	}

	@Override
	public List<Dictionary> findByProperty(String propertyName, String propertyValue) {
		return (List<Dictionary>) dictionaryMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	public Dictionary findOneByProperty(String propertyName, String propertyValue) {
		return (Dictionary) dictionaryMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	public List<Dictionary> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
		return (List<Dictionary>) dictionaryMapper.findByPropertyWithPagination(propertyName, propertyValue, offset, count);
	}

	@Override
	public List<Dictionary> findByProperties(Map<String, Object> map) {
		return (List<Dictionary>) dictionaryMapper.findByProperties(map);
	}

	@Override
	public long countByEntity(Dictionary model) {
		return (long) dictionaryMapper.countByEntity(model);
	}

	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		return (long) dictionaryMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	public long countByProperties(Map<String, Object> map) {
		return (long) dictionaryMapper.countByProperties(map);
	}

	@Override
	public void update(Dictionary model) {
		dictionaryMapper.update(model);
	}

	@Override
	public void insert(Dictionary model) {
		dictionaryMapper.insert(model);
	}

	@Override
	public void deleteByEntity(Dictionary model) {
		dictionaryMapper.deleteByEntity(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		dictionaryMapper.deleteByProperty(propertyName, propertyValue);
	}

	public long countAll() {
		return this.dictionaryMapper.countAll();
	}

	public void insertBatch(List<Dictionary> list) {
		this.dictionaryMapper.insertBatch(list);
	}

	public void delete(String id) {
		this.dictionaryMapper.deleteById(id);
	}

	public DictionaryServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public JsonResponse<Map<String, Object>> getDictionaryList(String requestId, String dictCode) {
		// TODO Auto-generated method stub
		JsonResponse<Map<String, Object>> result = new JsonResponse<Map<String, Object>>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<Dictionary> list = new ArrayList<Dictionary>();
		Dictionary dictionary = new Dictionary();

		try {
			this.checkParams(dictCode);
			this.checkParamsContains(",", dictCode);
			if (StringUtils.isNotBlank(dictCode)) {

				this.pringLog("code is:" + dictCode);
				
				
				//支持多个字典码
				String[] split = dictCode.split(",");
				for (int t = 0; t < split.length; t++) {
					
					String code = (String) split[t];
					//查看是否存在
//					if (!commonJedis.exists(code)) {
						this.pringLog("dictCode.not exists");
						dictionary.setDictCode(code.trim());
						// list =
						// dictionaryService.findByProperties(parameterMap);
						//查询数据库，并放入redis
						list = dictionaryMapper.findByEntity(dictionary);
//						commonJedis.addObject(code, list, expirationTime);
//						//从redis取
//					} else {
//						this.pringLog("dictCode exists");
//						list = (List<Dictionary>) commonJedis.getObject(code);
//
//					}
					resultMap.put(code, list);
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
			Log.error(e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		result.setResult(resultMap);
		return result;

	}

	@Override
	public JsonResponse<Boolean> updateRedis(String requestId, String dictCode) {
		// TODO Auto-generated method stub
		JsonResponse<Boolean> result = new JsonResponse<Boolean>();
		List<Dictionary> list = new ArrayList<Dictionary>();
		Dictionary dictionary = new Dictionary();
		boolean isSuccess = false;

		try {
			this.checkParams(dictCode);
			if (CommonTools.notNullAndEmpty(dictCode)) {
				this.pringLog("code is:" + dictCode);
				dictionary.setDictCode(dictCode);
				list = dictionaryMapper.findByEntity(dictionary);
				if (commonJedis.exists(dictCode)) {
					this.pringLog("exists");
					commonJedis.removeObject(dictCode);
				}
				commonJedis.addObject(dictCode, list, expirationTime);
				isSuccess = true;
			}

		} catch (Exception e) {
			// TODO: handle exception
			Log.error(e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		result.setResult(isSuccess);
		return result;
	}

	@Override
	public JsonResponse<List<ElementResult>> getDictInfo() {
		// TODO Auto-generated method stub
		JsonResponse<List<ElementResult>> result = new JsonResponse<List<ElementResult>>();

		try {
			List<ElementResult> element = new ArrayList<ElementResult>();
			//查看是否存在
			if (!commonJedis.exists(Consts.GETMAPLIST)) {
				this.pringLog("not exists");
				element = this.getMapList(dictionaryMapper.getDictInfo());
				commonJedis.addObject(Consts.GETMAPLIST, element, expirationTime);
			} else {
				//从redis取
				this.pringLog(" exists");
				element = (List<ElementResult>) commonJedis.getObject(Consts.GETMAPLIST);

			}
			result.setResult(element);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Log.error(e.getMessage());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	private List<ElementResult> getMapList(List<Element> dictInfo) {
		//根据app要求 进行转换
		String[] list = new String[] { "CLINIC_JOB_4_01", "CLINIC_JOB_4_02",  "CLINIC_JOB_6_01", "CLINIC_JOB_6_02", "CLINIC_JOB_6_03", "CLINIC_JOB_6_04" };
		String[] listName = new String[] { "医院/临床医疗","辅助科室及护理","护理","药学","中医学","医师" };


		List<ElementResult> result = new ArrayList<ElementResult>();
		List<Element> e =null;
		ElementResult element = null;
		if (CollectionUtils.isNotEmpty(dictInfo)) {
			for (int b = 0; b < list.length; b++) {
				element = new ElementResult();
				e = new ArrayList<Element>();
				for (int a = 0; a < dictInfo.size(); a++) {
					String parentKey = dictInfo.get(a).getParentKey();
					if (parentKey.equals(list[b])) {
						e.add(dictInfo.get(a));
					}

				}
				element.setKey(list[b]);
				element.setValue(listName[b]);
				element.setList(e);
				result.add(element);
			}

		}
		return result;
	}

}