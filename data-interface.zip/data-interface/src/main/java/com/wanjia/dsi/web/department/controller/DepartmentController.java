
package com.wanjia.dsi.web.department.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.cms.common.entity.ClinicDepartment;
import com.wanjia.dsi.web.cms.common.entity.EasyUITreeDataModelBase;
import com.wanjia.dsi.web.cms.department.service.CmsDepartmentCriteriaService;
import com.wanjia.dsi.web.department.model.Department;
import com.wanjia.dsi.web.department.service.DepartmentService;
import com.alibaba.fastjson.JSONObject;
import com.esotericsoftware.minlog.Log;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.dsi.base.controller.BaseWebController;
import com.wanjia.dsi.common.annotation.Endpoint;
import com.wanjia.dsi.common.annotation.Name;
import com.wanjia.dsi.common.error.ErrorType;




import com.wanjia.dsi.common.annotation.Endpoint.Invoker;

/***
 * 
* @ClassName: DictionaryController 
* @Description: TODO(这里用一句话描述这个类的作用) 
* @author Chenkang 
* @date 2016年3月2日 下午1:38:14 
*
 */
@SuppressWarnings("rawtypes")
@Controller
public class DepartmentController extends BaseWebController {

	

	@Autowired
	private DepartmentService departmentService;
	
	
	@Autowired
	private CmsDepartmentCriteriaService cmsDepartmentCriteriaService;
	
	/***
	 * 
	* @Title: getDepartmentList 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @param department
	* @param @return
	* @param @throws Exception    设定文件 
	* @return JsonResponse    返回类型 
	* @throws
	 */
	@RequestMapping(value = "/department/getDepartmentList.do",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台}, description = "科室列表 ")
	public JsonResponse<PageInfo<Department>> getDepartmentList(
			@RequestParam(required = false, value = "pageNo", defaultValue = "1") @Name(value = "页码") String pageNo, 
			@RequestParam(required = false, value = "pageSize", defaultValue = "100000") @Name(value = "每页个数") String pageSize,
			@RequestParam(required = false, value = "departmentId") @Name(value = "departmentId") String departmentId,
			@RequestParam(required = false, value = "departmentName") @Name(value = "departmentName") String departmentName,
			@RequestParam(required = false, value = "departmentCode") @Name(value = "departmentCode") String departmentCode,
			@RequestParam(required = false, value = "departmentDescription") @Name(value = "departmentDescription") String departmentDescription,
			@RequestParam(required = false, value = "parentId") @Name(value = "parentId") String parentId) throws Exception {
		
		return departmentService.getDepartmentList(null,pageNo, pageSize, departmentId, departmentName, departmentCode, departmentDescription, parentId);

	}
	
	/***
	 * 
	* @Title: getDepartmentList 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @param department
	* @param @return
	* @param @throws Exception    设定文件 
	* @return JsonResponse    返回类型 
	* @throws
	 */
	@RequestMapping(value = "/department/listInHomepage.do",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台}, description = "网站首页科室列表 ")
	public JsonResponse<List<EasyUITreeDataModelBase<ClinicDepartment>>> listInHomepage() throws Exception {
		
		return cmsDepartmentCriteriaService.listInHomepage();

	}
	
	
	@RequestMapping(value = "/department/queryDepartmentList.do",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	@Endpoint(invokers = { Invoker.诊所服务}, description = "科室列表（放缓存） ")
	public JsonResponse<PageInfo<Department>> queryDepartmentList(
			@RequestParam(required = false, value = "pageNo", defaultValue = "1") @Name(value = "页码") String pageNo, 
			@RequestParam(required = false, value = "pageSize", defaultValue = "10") @Name(value = "每页个数") String pageSize,
			@RequestParam(required = false, value = "departmentId") @Name(value = "departmentId") String departmentId,
			@RequestParam(required = false, value = "departmentName") @Name(value = "departmentName") String departmentName,
			@RequestParam(required = false, value = "departmentCode") @Name(value = "departmentCode") String departmentCode,
			@RequestParam(required = false, value = "departmentDescription") @Name(value = "departmentDescription") String departmentDescription,
			@RequestParam(required = false, value = "parentId") @Name(value = "parentId") String parentId) throws Exception {
		
		return departmentService.getDepartmentListInRedis(null,pageNo, pageSize, departmentId, departmentName, departmentCode, departmentDescription, parentId);

	}
	
	
	@RequestMapping(value = "/department/query.do",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	@Endpoint(invokers = { Invoker.诊所服务}, description = "科室列表（放缓存） ")
	public JsonResponse query1DepartmentList(
			@RequestParam(required = false, value = "pageNo", defaultValue = "1") @Name(value = "页码") String pageNo, 
			@RequestParam(required = false, value = "pageSize", defaultValue = "10") @Name(value = "每页个数") String pageSize,
			@RequestParam(required = false, value = "departmentId") @Name(value = "departmentId") String departmentId,
			@RequestParam(required = false, value = "departmentName") @Name(value = "departmentName") String departmentName,
			@RequestParam(required = false, value = "departmentCode") @Name(value = "departmentCode") String departmentCode,
			@RequestParam(required = false, value = "departmentDescription") @Name(value = "departmentDescription") String departmentDescription,
			@RequestParam(required = false, value = "parentId") @Name(value = "parentId") String parentId) throws Exception {
		
		return departmentService.findInCmsDepartMent("", "", "", "", "", "", "0");

	}
	
	
	
	
	
	
	
	

}
