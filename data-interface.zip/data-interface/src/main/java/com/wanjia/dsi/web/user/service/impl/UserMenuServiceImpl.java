package com.wanjia.dsi.web.user.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.user.dao.mapper.UserMenuMapper;
import com.wanjia.dsi.web.user.model.TreeDataModel;
import com.wanjia.dsi.web.user.model.UserMenuBean;
import com.wanjia.dsi.web.user.service.UserMenuService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class UserMenuServiceImpl extends BaseServiceImpl implements UserMenuService {

	@Autowired
	private UserMenuMapper userMenuMapper;

	public UserMenuServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	// 根据usercode获取菜单
	@Override
	public JsonResponse<List<TreeDataModel<UserMenuBean>>> getUserList(String sysCode, String userCode) {
		JsonResponse<List<TreeDataModel<UserMenuBean>>> result = new JsonResponse<List<TreeDataModel<UserMenuBean>>>();
		try {
			Map<String, Object> paraMap = new HashMap<String, Object>();
			paraMap.put("sysCode", sysCode);
			paraMap.put("userCode", userCode);
			logger.info("用户：" + userCode);
			logger.info("项目名称：" + sysCode);
			if (sysCode == null || sysCode.equals("") || userCode == null || userCode.equals("")) {
				return null;
			}
			List<UserMenuBean> menuList = queryMenuResourceBeanByUserCode(paraMap);

			// 返回树形数据结构
			TreeDataModel<UserMenuBean> rootBean = new TreeDataModel<UserMenuBean>("0", "根菜单");
			List<TreeDataModel<UserMenuBean>> rootList = new ArrayList<TreeDataModel<UserMenuBean>>();

			// 查询该用户所拥有的一级菜单
			List<UserMenuBean> p_List = queryParentMenuByUserCode(paraMap);
			// 一级节点list
			List<TreeDataModel<UserMenuBean>> list = new ArrayList<TreeDataModel<UserMenuBean>>();
			TreeDataModel<UserMenuBean> p_model = null;
			// 二级节点list
			List<TreeDataModel<UserMenuBean>> childlist = null;
			if (p_List != null) {
				for (UserMenuBean bean : p_List) {
					p_model = new TreeDataModel<UserMenuBean>(bean.getMenuId(), bean.getName());

					p_model.setIconCls(bean.getIconUrl());
					p_model.setAttributes(bean);
					childlist = new ArrayList<TreeDataModel<UserMenuBean>>();
					for (UserMenuBean bean2 : menuList) {
						if (bean2.getParentId() != null && bean.getMenuId().equals(bean2.getParentId())) {
							TreeDataModel<UserMenuBean> c_model = new TreeDataModel<UserMenuBean>(bean2.getMenuId(),
									bean2.getName());
							c_model.setIconCls(bean2.getIconUrl());
							c_model.setAttributes(bean2);
							childlist.add(c_model);
						}
					}
					p_model.setChildren(childlist);
					list.add(p_model);
				}
			}

			rootBean.setChildren(list);

			rootList.add(rootBean);
			result.setStatus(Status.SUCCESS);
			result.setResult(rootList);
		} catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}

	private List<UserMenuBean> queryMenuResourceBeanByUserCode(Map<String, Object> paraMap) {
		return userMenuMapper.queryMenuResourceBeanByUserCode(paraMap);
	}

	private List<UserMenuBean> queryParentMenuByUserCode(Map<String, Object> paraMap) {
		return userMenuMapper.queryParentMenuByUserCode(paraMap);
	}
}
