package com.wanjia.dsi.web.log.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.dao.mapper.CasUserRoleVOMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.CasUserVOMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyUserMapper;
import com.wanjia.dsi.web.hyPerson.model.CasUser;
import com.wanjia.dsi.web.hyPerson.model.CasUserRole;
import com.wanjia.dsi.web.hyPerson.model.HyUser;
import com.wanjia.dsi.web.hyPerson.util.UserRoleKey;
import com.wanjia.dsi.web.log.model.GwRequestLog;
import com.wanjia.dsi.web.log.service.LogService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class LogServiceImpl implements LogService {
	private Logger logger = Logger.getLogger(LogServiceImpl.class);
	@Resource
	private MongoTemplate mongoTemplate;

	@Autowired
	private CasUserVOMapper casUserVOMapper;
	@Autowired
	private CasUserRoleVOMapper casUserRoleVoMapper;
	@Autowired
	private HyUserMapper hyUserMapper;

	@Override
	public JsonResponse<Void> saveRequestLog(GwRequestLog log) {
		JsonResponse<Void> response = new JsonResponse<Void>();
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			if (StringUtils.isNotBlank(log.getLoginName())) {
				map.put("loginName", log.getLoginName());
			}
			if (StringUtils.isNotBlank(log.getMobile())) {
				map.put("mobile", log.getMobile());
			}
			if (StringUtils.isNotBlank(log.getCasUuid())) {
				map.put("id", log.getCasUuid());
			}

			
			//此处补救app自动登陆时的用户角色埋点
			if(!map.containsKey("loginName")
					&& !map.containsKey("mobile")
					&& !map.containsKey("id")){
				String userId = log.getUserCode();//会员id
				
				//根据userId查询CasUser
				if(StringUtils.isNotBlank(userId)){
					map.clear();
					map.put("id", userId);
					List<HyUser> huList = hyUserMapper.getHyUser(map);
					if(huList!=null && !huList.isEmpty()){
						HyUser hu = huList.get(0);
						
						//查询CasUser
						map.clear();
						map.put("id", hu.getCasUuid());
						List<CasUser> cuList = casUserVOMapper.findByProperties(map);
						if(cuList!=null && !cuList.isEmpty()){
							CasUser user = cuList.get(0);
							log.setCasUuid(user.getId());
							log.setLoginName(user.getLoginName());
							log.setMobile(user.getMobile());
							
							//查询用户角色
							String role = this.getUserRole(hu.getCasUuid());
							if(StringUtils.isNotBlank(role)){
								log.setUserRole(role);
							}
						}
					}
				}
			}else{
				//此处只对存在参数的情况进行埋点，否则无意义
				List<CasUser> list = casUserVOMapper.findByLoginNameORMobile(map);
				if (list != null && !list.isEmpty()) {
					if (list.size() > 1) {
						logger.warn("--行为日志记录异常，原因为loginName[" + log.getLoginName() + "]和mobile[" + log.getMobile() + "]查询到"
								+ list.size() + "条CasUser记录");
					} else {
						// 正常情况
						CasUser user = list.get(0);
						log.setCasUuid(user.getId());
						log.setLoginName(user.getLoginName());
						log.setMobile(user.getMobile());
						
						//查询用户角色
						String role = this.getUserRole(user.getId());
						if(StringUtils.isNotBlank(role)){
							log.setUserRole(role);
						}
					}
				}
			}
			
			mongoTemplate.insert(log);
			response.setStatus(JsonResponse.Status.SUCCESS);
		} catch (Exception e) {
			response.setStatus(JsonResponse.Status.ERROR);
			logger.error("--记录行为日志异常！请求参数为：" + ToStringBuilder.reflectionToString(log, ToStringStyle.MULTI_LINE_STYLE),
					e);
		}
		return response;
	}
	
	/**
	 * 根据casUuid获取用户角色，按优先级获取角色：诊所3->医生2->内部员工4->普通用户1
	 * @param casUuid
	 * @return
	 */
	private String getUserRole(String casUuid){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("userId", casUuid);
		map.put("delFlag", "0");
		List<CasUserRole> list = casUserRoleVoMapper.findByProperties(map);
		if(list!=null && !list.isEmpty()){
			StringBuffer buff = new StringBuffer();
			for(CasUserRole role : list){
				buff.append(",").append(role.getRoleKey());
			}
			String roles = buff.toString().substring(1);
			
			//按优先级获取角色：诊所3->医生2->内部员工4->普通用户1
			if(roles.contains(UserRoleKey.CLINIC_ADMIN.getCode())){
				return UserRoleKey.CLINIC_ADMIN.getCode();
			}
			else if(roles.contains(UserRoleKey.DOCTOR.getCode())){
				return UserRoleKey.DOCTOR.getCode();
			}
			if(roles.contains(UserRoleKey.CLINIC_EMPLOYE.getCode())){
				return UserRoleKey.CLINIC_EMPLOYE.getCode();
			}
			if(roles.contains(UserRoleKey.HY.getCode())){
				return UserRoleKey.HY.getCode();
			}
		}
		
		return null;
	}
}
