package com.wanjia.dsi.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.elasticsearch.common.lang3.StringUtils;

public class DateTools {

	/**
	 * 获取上个月第一天
	 * */
	public static String getFirstDayOfPreMonth(){
    	Calendar calendar = Calendar.getInstance();
    	calendar.add(Calendar.MONTH, -1);
    	//这个月
    	//calendar.add(Calendar.MONTH, 0);
    	calendar.set(Calendar.DAY_OF_MONTH, 1);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
    	String firstDay = format.format(calendar.getTime());
    	//System.out.println(firstDay);
    	return firstDay;
    }
	   
	/**
	 * 获取上个月最后一天
	 * */
    public static String getLastDayOfPreMonth(){
    	Calendar calendar = Calendar.getInstance();
    	//这个月
    	//calendar.add(Calendar.MONTH, 1);
    	calendar.set(Calendar.DAY_OF_MONTH, 0);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
    	String lastDay = format.format(calendar.getTime());
    //	System.out.println(lastDay);
    	return lastDay;
    }
   
    /**
	 * 获取上月 返回值如2016.10 
	 * */
    public static String getPreMonthForBill(){
    	Calendar calendar = Calendar.getInstance();
    	calendar.add(Calendar.MONTH, -1);
    //	calendar.set(Calendar.DAY_OF_MONTH, 1);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy.MM"); 
    	
    	return format.format(calendar.getTime());
    }
    
    /**
	 * 获取本月 返回值如2016.11 
	 * */
    public static String getCurrMonthForBill(){
    	Calendar calendar = Calendar.getInstance();
    	calendar.add(Calendar.MONTH, 0);
    //	calendar.set(Calendar.DAY_OF_MONTH, 1);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy.MM"); 
    	
    	return format.format(calendar.getTime());
    }
    
    public static String getSysDateforBill(){
    	String sysdate = "";
    	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(new Date());
    	SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd"); 
    	sysdate =  format.format(calendar.getTime());
    	return sysdate;
    }
    
    public static String getYesterday(){
    	String yesterday = "";
    	Calendar calendar = Calendar.getInstance();
    	calendar.add(Calendar.DATE, -1);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
    	yesterday =  format.format(calendar.getTime());
    	return yesterday;
    }
    
    
	public static int getAge(String birthDateString) throws ParseException {
		if (StringUtils.isBlank(birthDateString))
			throw new RuntimeException("出生日期不能为null");
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
		Date birthDate = format.parse(birthDateString);
    	
		int age = 0;
		Date now = new Date();

		SimpleDateFormat format_y = new SimpleDateFormat("yyyy");
		SimpleDateFormat format_M = new SimpleDateFormat("MM");

		String birth_year = format_y.format(birthDate);
		String this_year = format_y.format(now);

		String birth_month = format_M.format(birthDate);
		String this_month = format_M.format(now);

		// 初步，估算
		age = Integer.parseInt(this_year) - Integer.parseInt(birth_year);

		// 如果未到出生月份，则age - 1
		if (this_month.compareTo(birth_month) < 0)
			age -= 1;
		if (age < 0)
			age = 0;
		return age;
	}
    

    
    
    /**
	 * 获取本月第一天
	 * */
	public static String getFirstDayOfCurrMonth(){
    	Calendar calendar = Calendar.getInstance();
    	calendar.add(Calendar.MONTH, 0);
    	calendar.set(Calendar.DAY_OF_MONTH, 1);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
    	String firstDay = format.format(calendar.getTime());
    //	System.out.println(firstDay);
    	return firstDay;
    }
	   
	/**
	 * 获取本月最后一天
	 * */
    public static String getLastDayOfCurrMonth(){
    	Calendar calendar = Calendar.getInstance();
    	//这个月
    	calendar.add(Calendar.MONTH, 1);
    	calendar.set(Calendar.DAY_OF_MONTH, 0);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
    	String lastDay = format.format(calendar.getTime());
    //	System.out.println(lastDay);
    	return lastDay;
    }
    
    /**
	 * 获取上个月第一天
	 * */
	public static String get1stDayOfPreMonthBySecond(){
    	Calendar calendar = Calendar.getInstance();
    	calendar.add(Calendar.MONTH, -1);
    	//这个月
    	//calendar.add(Calendar.MONTH, 0);
    	calendar.set(Calendar.DAY_OF_MONTH, 1);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
    	String firstDay = format.format(calendar.getTime());
    	//System.out.println(firstDay);
    	return firstDay + " 00:00:00";
    }
	   
	/**
	 * 获取上个月最后一天
	 * */
    public static String getEndDayOfPreMonthBySecond(){
    	Calendar calendar = Calendar.getInstance();
    	//这个月
    	//calendar.add(Calendar.MONTH, 1);
    	calendar.set(Calendar.DAY_OF_MONTH, 0);
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
    	String lastDay = format.format(calendar.getTime());
    //	System.out.println(lastDay);
    	return lastDay + " 23:59:59";
    }
    
    public static void main(String args[]) throws ParseException{
    //	String str = "921012134";
//    	System.out.println(getFirstDayOfPreMonth());
//   		System.out.println(getLastDayOfPreMonth());
    	System.out.println(DateTools.getEndDayOfPreMonthBySecond());
    }
}
