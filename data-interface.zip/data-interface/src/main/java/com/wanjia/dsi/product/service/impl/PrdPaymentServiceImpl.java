/**
 * 
 */
package com.wanjia.dsi.product.service.impl;

import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.product.service.PrdPaymentService;

/**
 * @author huanglei698
 *
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
public class PrdPaymentServiceImpl implements PrdPaymentService {

	private Logger logger = Logger.getLogger(PrdPaymentServiceImpl.class);

	@Value("#{serverConstants['prdPaymentOutTime']}")
	private String outTime;

	@Autowired
	private CommonJedis commonJedis;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.PrdPaymentService#produceOutOfTimePayments
	 * ()
	 */
	@Override
	public void produceOutOfTimePayments() {
		long timestamp = System.currentTimeMillis();
		long timediff = Long.parseLong(outTime);
		long endTime = timestamp - timediff;
		Map<String, Double> payments = commonJedis.getRemZsetMembersByScoresRange(Consts.PRD_PAYMENT_ZET, new Double(0),
				new Double(endTime));
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmiss");
		// 取出的超时订单放入缓存中进行处理
		Set<String> keySet = payments.keySet();
		String[] paymentIds = keySet.toArray(new String[keySet.size()]);
		for (String paymentId : paymentIds) {
			logger.info("过期订单的ID是：[" + paymentId + "]，时间是：[" + payments.get(paymentId).longValue() + "]");
			commonJedis.putHashObject(Consts.PRD_PAYMENT_CANCEL, paymentId,
					format.format(payments.get(paymentId).longValue()));
		}
		/**
		 * 以下进行业务处理，处理完的订单从需从redis中删除
		 */

		// start
		// 以下为超时订单处理完后调用的删除redis的代码
		// commonJedis.removeHashObject(Consts.PRD_PAYMENT_CANCEL, paymentId);
		// end

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.PrdPaymentService#setUnpayPayment(java.
	 * lang.String, long)
	 */
	@Override
	public void setUnpayPayment(String paymentId, long timstamp) {
		commonJedis.putZsetObject(Consts.PRD_PAYMENT_ZET, new Double(timstamp), paymentId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.PrdPaymentService#remvePayment(java.lang.
	 * String)
	 */
	@Override
	public void remvePayment(String... paymentIds) {
		commonJedis.removeZsetMembers(Consts.PRD_PAYMENT_ZET, paymentIds);

	}

}
