package com.wanjia.dsi.web.finance.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.common.annotation.Endpoint;
import com.wanjia.dsi.common.annotation.Name;
import com.wanjia.dsi.common.annotation.Endpoint.Invoker;
import com.wanjia.dsi.web.finance.service.FinanceService;

@Controller
public class FinanceController {

	
	
	
	
	
	
	@Autowired
	private FinanceService financeService;
	
	
	@RequestMapping(value = "/finance/getBankList.do",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台}, description = "得到银行列表 ")
	public JsonResponse<List<Map<String, Object>>> getBankList() {
		
		return financeService.getBankList(null);

	}
	
	
	
	@RequestMapping(value = "/finance/getBankBranchList.do",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台}, description = "得到银行支行列表 ")
	public JsonResponse<List<Map<String, Object>>> getBankBranchList(
			@RequestParam(required = false, value = "branchBankId") @Name(value = "银行id") String branchBankId) {
		
		return financeService.getBankBranchList(null,branchBankId);

	}
	
	
	
	
	
}
