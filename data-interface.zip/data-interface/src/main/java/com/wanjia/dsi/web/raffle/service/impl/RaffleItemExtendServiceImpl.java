package com.wanjia.dsi.web.raffle.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanjia.dsi.web.raffle.dao.mapper.RaffleItemExtendMapper;
import com.wanjia.dsi.web.raffle.model.RaffleItemExtend;
import com.wanjia.dsi.web.raffle.model.RaffleItemExtendExample;
import com.wanjia.dsi.web.raffle.service.RaffleItemExtendService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class RaffleItemExtendServiceImpl implements RaffleItemExtendService {

	@Autowired
	private RaffleItemExtendMapper raffleItemExtendMapper;

	/**
	 * 根据抽奖次数与ItemID获取该项的扩展规则
	 * 
	 * @param itemId
	 * @param hitCount
	 * @return
	 */
	@Override
	public RaffleItemExtend findByItemIdAndHitCount(String itemId, int hitCount) {

		RaffleItemExtendExample example = new RaffleItemExtendExample();
		RaffleItemExtendExample.Criteria criteria = example.createCriteria();
		criteria.andItemIdEqualTo(itemId);
		criteria.andLimitHitCountLessThanOrEqualTo(hitCount);
		criteria.andDelFlagEqualTo("0");
		example.setOrderByClause("LIMIT_HIT_COUNT desc");

		List<RaffleItemExtend> list = raffleItemExtendMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}
	}
}