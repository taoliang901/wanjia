/**   
* @Title: BaseEntity.java 
* @Package com.wanjia.dsi.base 
* @Description: TODO(用一句话描述该文件做什么) 
* @author CHENKANG560  
* @date 2016年3月7日 下午7:47:47 
* @version V1.0   
*/
package com.wanjia.dsi.base.entity;

/** 
* @ClassName: BaseEntity 
* @Description: TODO(这里用一句话描述这个类的作用) 
* @author Chenkang 
* @date 2016年3月7日 下午7:47:47 
*  
*/
public class BaseEntity {

	private int pageNo = 1;
	private int pageSize =10;
	/** 
	* <p>Title: </p> 
	* <p>Description: </p>  
	*/
	public BaseEntity() {
		// TODO Auto-generated constructor stub
	}
	
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
