package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.product.dao.mapper.PrdServiceMapper;
import com.wanjia.dsi.product.service.HyCouponService;
import com.wanjia.dsi.product.service.ProductMessageService;
import com.wanjia.dsi.product.vo.CouponClinicAndCityVo;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class HyCouponServiceImpl extends BaseServiceImpl implements HyCouponService {

	private Logger logger = Logger.getLogger(HyCouponServiceImpl.class);
	
	@Autowired
	private PrdServiceMapper prdServiceMapper;
	
	@Autowired
	private ProductMessageService productMessageService;
	
	@Override
	public JsonResponse<Map<String, Object>> getCouponClinicAndCity(String couponId) {
		JsonResponse<Map<String, Object>> response = new JsonResponse<Map<String, Object>>();
		
		try{
			Map<String,Object> param = new HashMap<String,Object>();
			param.put("couponId", couponId);
//			List<Map<String,Object>> list = prdServiceMapper.getCouponClinicAndCity(param);
			List<Map<String,Object>> list =  null;
			List<String> clinicIdList = productMessageService.getClinicId(couponId);  //得到合同和产品对应的诊所id
			param.put("clinicIdList", clinicIdList);
			if(clinicIdList != null && clinicIdList.size() > 0){
				list = prdServiceMapper.getCLinicAdressById(param);
			}
			if(list!=null && !list.isEmpty()){
				Integer clinicNum = 0;
				//将城市和连锁诊所去重
				Map<String,Object> resMap = new HashMap<String,Object>();
				Map<String,Object> clinicMap = new HashMap<String,Object>();
				Map<String,Object> cityMap = new HashMap<String,Object>();
				for(Map<String, Object> map : list){
					String cityCode = map.get("cityCode")+"";
					String parentAccountId = map.get("parentAccountId")+"";
					if(!cityMap.containsKey(cityCode)){
						cityMap.put(cityCode, map.get("city"));
					}
					if(!clinicMap.containsKey(parentAccountId)){
						clinicMap.put(parentAccountId, map.get("parentAccountName"));
					}
					if("_NULL_".equals(parentAccountId)){
						clinicNum++;
					}
				}
				
				//封装结果
				List<CouponClinicAndCityVo> clinic = new ArrayList<CouponClinicAndCityVo>(clinicMap.size());
				CouponClinicAndCityVo allClinicVo = null;
				for(Entry<String,Object> e : clinicMap.entrySet()){
					if("_NULL_".equals(e.getKey())){
						allClinicVo = new CouponClinicAndCityVo();
						allClinicVo.setParentAccountId(e.getKey());
						allClinicVo.setParentAccountName(e.getValue()+"");
					}else{
						CouponClinicAndCityVo vo = new CouponClinicAndCityVo();
						vo.setParentAccountId(e.getKey());
						vo.setParentAccountName(e.getValue()+"");
						clinic.add(vo);
					}
				}
				//处理排序
				if(allClinicVo!=null){
					clinic.add(0, allClinicVo);
				}
				
				List<CouponClinicAndCityVo> city = new ArrayList<CouponClinicAndCityVo>(cityMap.size());
				for(Entry<String,Object> e : cityMap.entrySet()){
					CouponClinicAndCityVo vo = new CouponClinicAndCityVo();
					vo.setCityCode(e.getKey());
					vo.setCity(e.getValue()+"");
					city.add(vo);
				}
				
				resMap.put("clinicNum", clinicNum);//诊所数量
				resMap.put("clinic", clinic);//产品所在诊所
				resMap.put("city", city);//产品所在城市
				response.setStatus(JsonResponse.Status.SUCCESS);
				response.setResult(resMap);
			}
		}catch(Exception e){
			logger.error("获取预约产品所在诊所和城市出错！",e);
			response.setStatus(JsonResponse.Status.ERROR);
		}
		
		return response;
	}

	@Override
	public JsonResponse<Map<String, String>> getDistrictsByCity(String couponId,String cityCode,String clinicCode) {
		JsonResponse<Map<String, String>> response = new JsonResponse<Map<String, String>>();
		try{
			Map<String,Object> param = new HashMap<String,Object>();
			param.put("couponId", couponId);
			param.put("cityCode", cityCode);
			param.put("parentAccountId", clinicCode);
//			List<Map<String,Object>> list = prdServiceMapper.getCouponClinicAndCity(param);
			List<Map<String,Object>> list =  null;
			List<String> clinicIdList = productMessageService.getClinicId(couponId);  //得到合同和产品对应的诊所id
			param.put("clinicIdList", clinicIdList);
			if(clinicIdList != null && clinicIdList.size() > 0){
				list = prdServiceMapper.getCLinicAdressById(param);
			}
			if(list!=null && !list.isEmpty()){
				//将地区去重
				Map<String,String> districtMap = new HashMap<String,String>();
				for(Map<String, Object> map : list){
					String districtCode = map.get("districtCode")+"";
					if(!districtMap.containsKey(districtCode)){
						districtMap.put(districtCode, map.get("district")+"");
					}
				}
				
				response.setStatus(JsonResponse.Status.SUCCESS);
				response.setResult(districtMap);
			}
		}catch(Exception e){
			logger.error("获取区县出错！",e);
			response.setStatus(JsonResponse.Status.ERROR);
		}
		
		return response;
	}

	@Override
	public JsonResponse<List<Map<String,Object>>> queryCouponClinic(String couponId, String cityCode,
			String clinicCode, String districtCode,String clinicName) {
		JsonResponse<List<Map<String,Object>>> response = new JsonResponse<List<Map<String,Object>>>();
		try{
			Map<String,Object> param = new HashMap<String,Object>();
			//param.put("couponId", couponId);
			param.put("clinicName", clinicName);
			param.put("cityCode", cityCode);
			param.put("districtCode", districtCode);
			param.put("parentAccountId", clinicCode);
			//List<Map<String,Object>> list = prdServiceMapper.getCouponClinicAndCity(param);
			List<Map<String,Object>> list =  null;
			List<String> clinicIdList = productMessageService.getClinicId(couponId);  //得到合同和产品对应的诊所id
			param.put("clinicIdList", clinicIdList);
			if(clinicIdList != null && clinicIdList.size() > 0){
				list = prdServiceMapper.getCLinicAdressById(param);
			}
			response.setStatus(JsonResponse.Status.SUCCESS);
			response.setResult(list);
		}catch(Exception e){
			logger.error("获取诊所出错！",e);
			response.setStatus(JsonResponse.Status.ERROR);
		}
		
		return response;
	}

	@Override
	public JsonResponse<Map<String, String>> getCityByClinic(String couponId, String clinicCode,String cityCode) {
		JsonResponse<Map<String, String>> response = new JsonResponse<Map<String, String>>();
		try{
			Map<String,Object> param = new HashMap<String,Object>();
			param.put("couponId", couponId);
			if(StringUtils.isNotBlank(cityCode)){
				param.put("cityCode", cityCode);
			}
			param.put("parentAccountId", clinicCode);
//			List<Map<String,Object>> list = prdServiceMapper.getCouponClinicAndCity(param);
			List<Map<String,Object>> list =  null;
			List<String> clinicIdList = productMessageService.getClinicId(couponId);  //得到合同和产品对应的诊所id
			param.put("clinicIdList", clinicIdList);
			if(clinicIdList != null && clinicIdList.size() > 0){
				list = prdServiceMapper.getCLinicAdressById(param);
			}
			if(list!=null && !list.isEmpty()){
				//将城市去重
				Map<String,String> cityMap = new HashMap<String,String>();
				for(Map<String, Object> map : list){
					String code = map.get("cityCode")+"";
					if(!cityMap.containsKey(code)){
						cityMap.put(code, map.get("city")+"");
					}
				}
				
				response.setStatus(JsonResponse.Status.SUCCESS);
				response.setResult(cityMap);
			}
		}catch(Exception e){
			logger.error("获取城市出错！",e);
			response.setStatus(JsonResponse.Status.ERROR);
		}
		return response;
	}

}
