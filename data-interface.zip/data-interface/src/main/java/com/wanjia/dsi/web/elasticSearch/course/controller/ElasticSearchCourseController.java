package com.wanjia.dsi.web.elasticSearch.course.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.common.annotation.Endpoint;
import com.wanjia.dsi.common.annotation.Endpoint.Invoker;
import com.wanjia.dsi.web.college.model.Course;
import com.wanjia.dsi.web.elasticsearch.course.ElasticSearchCourseService;

@Controller
public class ElasticSearchCourseController {

	@Autowired
	private ElasticSearchCourseService elasticSearchCourseService;

	@RequestMapping("/elasticsearch/course/insert.do")
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站服務 }, description = "同步所有诊所信息,使用upsert")
	public JsonResponse<Void> syncItems() {

		Course course = new Course();
		course.setCourseId("123");
		course.setCourseContent("以前框架使用quartz框架执行定时调度问题、以前框架使用quartz框架执行定时调度问题、以前框架使用quartz框架执行定时调度问题、");
		elasticSearchCourseService.insertCourse(course);
		return new JsonResponse<Void>();
	}

}
