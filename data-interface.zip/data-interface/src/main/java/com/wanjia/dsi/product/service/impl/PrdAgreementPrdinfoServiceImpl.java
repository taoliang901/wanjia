package com.wanjia.dsi.product.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.model.PrdAgreementPrdinfo;
import com.wanjia.dsi.product.service.PrdAgreementPrdinfoService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdAgreementPrdinfoServiceImpl implements PrdAgreementPrdinfoService{

	private Logger logger = LoggerFactory.getLogger(PrdAgreementPrdinfoServiceImpl.class);

	@Autowired
    private PrdAgreementPrdinfoMapper prdAgreementPrdinfoMapper;
	
	@Override
	public PrdAgreementPrdinfo searchPrdPriceByParams(Map<String, Object> map) {
		
		return prdAgreementPrdinfoMapper.searchPrdPriceByParams(map);
	}

	@Override
	public List<PrdAgreementPrdinfo> findByProperties(Map<String, Object> map) {
		return prdAgreementPrdinfoMapper.findByProperties(map);
	}
}
