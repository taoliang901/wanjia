package com.wanjia.dsi.web.clollege.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.college.dao.mapper.CeCourseTypeMapper;
import com.wanjia.dsi.web.college.model.CeCourseType;
import com.wanjia.dsi.web.college.service.CeCourseTypeService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CeCourseTypeServiceImpl extends BaseServiceImpl implements CeCourseTypeService {

	@Autowired
	private CeCourseTypeMapper ceCourseTypeMapper;

	@Override
	public JsonResponse<List<CeCourseType>> findAllCeCourseType() {
		JsonResponse<List<CeCourseType>> jr = new JsonResponse<List<CeCourseType>>();
		try {
			List<CeCourseType> list = ceCourseTypeMapper.findAllCeCourseType();
			jr.setResult(list);
			jr.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("findAllCeCourseType:" + e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return jr;
	}

	@Override
	public JsonResponse<List<CeCourseType>> findAllCeCourseType(int pageSize) {
		JsonResponse<List<CeCourseType>> jr = new JsonResponse<List<CeCourseType>>();
		try {
			PageHelper.startPage(1, pageSize);
			List<CeCourseType> list = ceCourseTypeMapper.findAllCeCourseType();
			jr.setStatus(Status.SUCCESS);
			jr.setResult(new PageInfo(list).getList());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("findAllCeCourseType(int pageSize):" + e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return jr;
	}

}
