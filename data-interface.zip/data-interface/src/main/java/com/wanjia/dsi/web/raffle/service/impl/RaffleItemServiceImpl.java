package com.wanjia.dsi.web.raffle.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.web.raffle.dao.mapper.RaffleItemMapper;
import com.wanjia.dsi.web.raffle.dao.mapper.RaffleItemVOMapper;
import com.wanjia.dsi.web.raffle.model.RaffleItem;
import com.wanjia.dsi.web.raffle.service.RaffleItemService;

/**
 * This element is automatically generated on 16-7-25 上午11:37, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class RaffleItemServiceImpl implements RaffleItemService {
	
    @Autowired
    private RaffleItemMapper raffleItemMapper;
    
    @Autowired
    private RaffleItemVOMapper raffleItemVOMapper;

    @Override
    @Transactional(readOnly=true)
    public RaffleItem findById(String id) {
        return (RaffleItem)raffleItemMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleItem> findWithPagination(int offset, int count) {
        return (List<RaffleItem>)raffleItemMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleItem> findAll() {
        return (List<RaffleItem>)raffleItemMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleItem> findByEntity(RaffleItem model) {
        return (List<RaffleItem>)raffleItemMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleItem> findByEntityWithPagination(RaffleItem model, int offset, int count) {
        return (List<RaffleItem>)raffleItemMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public RaffleItem findOneByEntity(RaffleItem model) {
        return (RaffleItem)raffleItemMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleItem> findByProperty(String propertyName, String propertyValue) {
        return (List<RaffleItem>)raffleItemMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public RaffleItem findOneByProperty(String propertyName, String propertyValue) {
        return (RaffleItem)raffleItemMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleItem> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<RaffleItem>)raffleItemMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<RaffleItem> findByProperties(Map<String, Object> map) {
        return (List<RaffleItem>)raffleItemMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(RaffleItem model) {
        return (long)raffleItemMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)raffleItemMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)raffleItemMapper.countByProperties(map);
    }

    @Override
    public void update(RaffleItem model) {
        model.setModifyDate(new Date());
        raffleItemMapper.update(model);
    }

    @Override
    public void insert(RaffleItem model) {
        model.setCreateDate(new Date());
        raffleItemMapper.insert(model);
    }

    @Override
    public void deleteByEntity(RaffleItem model) {
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        raffleItemMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.raffleItemMapper.countAll();
    }

    public void insertBatch(List<RaffleItem> list) {
        this.raffleItemMapper.insertBatch(list);
    }

    public void delete(String id) {
        RaffleItem model = new RaffleItem();
        model.setDelFlag("1");
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.raffleItemMapper.update(model);
    }

	@Override
	public List<RaffleItem> findByRaffleKey(String raffleKey) {
		return this.raffleItemVOMapper.findByRaffleKey(raffleKey);
	}
}