/**   
* @Title: AreaController.java 
* @Package com.wanjia.dsi.web.area.controller 
* @Description: TODO(用一句话描述该文件做什么) 
* @author CHENKANG560  
* @date 2016年3月1日 下午6:47:16 
* @version V1.0   
*/
package com.wanjia.dsi.web.condition.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.dsi.base.controller.BaseWebController;
import com.wanjia.dsi.common.annotation.Endpoint;
import com.wanjia.dsi.common.annotation.Endpoint.Invoker;
import com.wanjia.dsi.common.annotation.Name;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.web.condition.model.Condition;
import com.wanjia.dsi.web.condition.service.ConditionService;

/**
 * @ClassName: AreaController
 * @Description: 病症
 * @author Chenkang
 * @date 2016年3月1日 下午6:47:16
 * 
 */
@Controller
public class ConditionController extends BaseWebController {

	@Autowired
	private ConditionService conditionService;

	/***
	 * 
	* @Title: getconditionList 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param @param condition
	* @param @param pageNo
	* @param @param pageSize
	* @param @return
	* @param @throws Exception    设定文件 
	* @return JsonResponse<Map<String,Object>>    返回类型 
	* @throws
	 */
	@RequestMapping(value = "/condition/getconditionList.do")
	@ResponseBody
	@Endpoint(invokers = { Invoker.网站前台 }, description = "病症推荐")
	public JsonResponse<PageInfo<Condition>> getconditionList(
			@RequestParam(required = false, value = "pageNo", defaultValue = "1") @Name(value = "页码") int pageNo, 
			@RequestParam(required = false, value = "pageSize", defaultValue = "10") @Name(value = "每页个数") int pageSize) throws Exception {
		Condition parseObject = new Condition();
		parseObject.setDelFlag("0");
		List<Condition> list = new ArrayList<Condition>();
		JsonResponse<PageInfo<Condition>> result = new JsonResponse<PageInfo<Condition>>();
		try {
			PageHelper.startPage(pageNo, pageSize);//设置分页页号和页码
			list = conditionService.getConditionList(parseObject, 0, 0);
			PageInfo<Condition> page = new PageInfo<Condition>(list);//获得分页信息
			result.setResult(page);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;

	}

}
