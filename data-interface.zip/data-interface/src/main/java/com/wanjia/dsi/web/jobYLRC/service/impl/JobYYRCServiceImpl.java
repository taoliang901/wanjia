package com.wanjia.dsi.web.jobYLRC.service.impl;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.job36.mobile.webservice.ResumeWebService;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.invoker.ResumeFromSource;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.common.utils.Job51XmlConverUtil;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvMapper;
import com.wanjia.dsi.web.job.dao.mapper.TalentCvRecordMapper;
import com.wanjia.dsi.web.job.model.TalentCv;
import com.wanjia.dsi.web.job.model.TalentCvRecord;
import com.wanjia.dsi.web.job51.service.Job51Service;
import com.wanjia.dsi.web.jobYYRC.model.MyResume;
import com.wanjia.dsi.web.jobYYRC.model.ResumeCondition;
import com.wanjia.dsi.web.jobYYRC.model.YyrcAccount;
import com.wanjia.dsi.web.jobYYRC.service.JobYYRCAccountService;
import com.wanjia.dsi.web.jobYYRC.service.JobYYRCService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class JobYYRCServiceImpl extends BaseServiceImpl implements JobYYRCService {
	@Autowired
	private CommonJedis commonJedis;
	
	@Autowired
	private Job51Service job51Service;
	
	@Autowired
	private JobYYRCAccountService jobYYRCAccountService;
	/*
	@Autowired
	private ResumeWebService resumeWebService;*/
	
	@Autowired
	private TalentCvMapper talentCvMapper;
	
	@Autowired
	private TalentCvRecordMapper talentCvRecordMapper;

	@Override
	public JsonResponse<PageInfo<LinkedHashMap<String, Object>>> searchResume(Map<String,String> searchPramMap) {
		JsonResponse<PageInfo<LinkedHashMap<String, Object>>> result = new JsonResponse<PageInfo<LinkedHashMap<String, Object>>>();
		
		if(StringUtils.isBlank(searchPramMap.get("pageNo")) || !StringUtils.isNumeric(searchPramMap.get("pageNo"))){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.IllegalArgument.getCode());
			result.setErrorMsg("pageNo参数不合法");
			return result;
		}
		
	    if(StringUtils.isBlank(searchPramMap.get("pageSize")) || !StringUtils.isNumeric(searchPramMap.get("pageSize"))){
	    	result.setStatus(Status.ERROR);
	    	result.setErrorCode(ErrorType.IllegalArgument.getCode());
			result.setErrorMsg("pageSize参数不合法");
			return result;
		}
		
	    try {
		    ResumeCondition condition = new ResumeCondition();
		    
		    //关键字
			if(searchPramMap.containsKey("keyWord")){
				condition.setKeyword(searchPramMap.get("keyWord"));
			}
			
			//期望工作地点
	        if(searchPramMap.containsKey("jobLocation")){
	        	condition.setJobLocation1(searchPramMap.get("jobLocation"));
			}else if(searchPramMap.containsKey("cityName")){
				condition.setJobLocation1(getXmlCodeByValue("YYRC_AREA",searchPramMap.get("cityName")));
			}
		    
		    //期望职能
			if(searchPramMap.containsKey("intentionJob") && StringUtils.isNumeric(searchPramMap.get("intentionJob"))){
				condition.setJobFunction1(Integer.parseInt(searchPramMap.get("intentionJob")));
			}
		    
		    //工作经验最小值
			if(searchPramMap.containsKey("experienceMin") && StringUtils.isNumeric(searchPramMap.get("experienceMin"))){
				condition.setReqWorkYear1(Integer.parseInt(searchPramMap.get("experienceMin")));
			}
			
			//工作经验最大值
			if(searchPramMap.containsKey("experienceMax") && StringUtils.isNumeric(searchPramMap.get("experienceMax"))){
				condition.setReqWorkYear2(Integer.parseInt(searchPramMap.get("experienceMax")));
			}
			
			//学历开始
			if(searchPramMap.containsKey("educationLevel") && StringUtils.isNumeric(searchPramMap.get("educationLevel"))){
				condition.setReqDegreeID1(Integer.parseInt(searchPramMap.get("educationLevel")));
				condition.setReqDegreeID2(Integer.parseInt(searchPramMap.get("educationLevel")));
			}
			
			//期望薪资
			if(searchPramMap.containsKey("salary") && StringUtils.isNumeric(searchPramMap.get("salary"))){
				condition.setSalary(Integer.parseInt(searchPramMap.get("salary")));
			}
			
			//orderby
			if(searchPramMap.containsKey("orderby") && StringUtils.isNumeric(searchPramMap.get("orderby"))){
				condition.setOrderId(Integer.parseInt(searchPramMap.get("orderby")));
			}else{
				condition.setOrderId(0);
			}
		
			String jsonStr = "";//resumeWebService.searchResume(condition, Integer.parseInt(searchPramMap.get("pageNo")), Integer.parseInt(searchPramMap.get("pageSize")));
//			String jsonStr = "{\"code\":\"E200\",\"message\":\"成功！\",\"data\":{\"pageSize\":10,\"pageNo\":1,\"totalPages\":100,\"totalSize\":1000,\"step\":5,\"url\":\"/\",\"list\":[{\"resId\":\"900875\",\"jobFunction1\":1406,\"jobFunction2\":1403,\"jobFunction3\":0,\"jobLocation1\":\"0200\",\"jobLocation2\":\"0700\",\"jobLocation3\":\"0800\",\"location\":\"0200\",\"degreeId\":50,\"workyear\":5,\"age\":32,\"sex\":0,\"school\":\"长江大学\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"广播电视新闻学\",\"otherSkills\":\"\",\"selfDescription\":\"有意向的公司，请加我QQ，可发送一份案例作品，作深入了解。\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"1059473\",\"jobFunction1\":0,\"jobFunction2\":0,\"jobFunction3\":0,\"jobLocation1\":\"0200\",\"jobLocation2\":\"0706\",\"jobLocation3\":\"0802\",\"location\":\"1002\",\"degreeId\":50,\"workyear\":0,\"age\":59,\"sex\":0,\"school\":\"河南医科大学\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"临床医学\",\"otherSkills\":\" 沟通能力强 执行力强 学习力强 诚信正直 沉稳内敛\",\"selfDescription\":\"本人临床医学本科毕业，内科主任医师，二级健康管理师。具有扎实的医学基础，从事医疗工作三十多年，熟悉内科常见病诊断治疗和危重疑难病症的处理，对高血压、糖尿病、恶性肿瘤等严重慢性疾病防治管理具有较为丰富的经验；曾担任基层医院内科主任、总检主任、医务科长、业务副院长、院长职务，熟悉医疗卫生法律法规及政策，掌握医疗管理工作内容、方法、流程，能够胜任上述岗位工作。\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"1185842\",\"jobFunction1\":0,\"jobFunction2\":0,\"jobFunction3\":0,\"jobLocation1\":\"0311\",\"jobLocation2\":\"1100\",\"jobLocation3\":\"0200\",\"location\":\"1300\",\"degreeId\":40,\"workyear\":10,\"age\":34,\"sex\":0,\"school\":\"九江学院\",\"updateDateL\":0,\"photoNum\":1,\"speciality\":\"医学影像诊断\",\"otherSkills\":\"学习力强\",\"selfDescription\":\"执业医师 懂放射和ct\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"1448704\",\"jobFunction1\":1001,\"jobFunction2\":0,\"jobFunction3\":0,\"jobLocation1\":\"0200\",\"jobLocation2\":\"0800\",\"jobLocation3\":\"1900\",\"location\":\"0200\",\"degreeId\":40,\"workyear\":16,\"age\":38,\"sex\":0,\"school\":\"湖北中医药高等专科学校\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"中西医结合\",\"otherSkills\":\"沟通能力强 执行力强 学习力强 有亲和力 诚信正直 雷厉风行 阳光开朗 善于创新 有创业经历 \",\"selfDescription\":\"有较强的文字功底，良好的沟通/组织和协调能力，应变能力强。能够与时俱进，有亲和力和感染力,待人诚实,为人诚信,善于沟通,执行力强；能够灵活处理工作中的突发事件。喜欢富有挑战性的工作,有较强的社会阅历，对社会的接触面较广,人缘关系佳。对工作兢兢业业,尽心尽责,有良好的团队精神和组织统筹能力。并较有较好的系统思维(ST)和创新思维(能够使用“创新2.0和互联网+模式改进/创新运营”)；有亲和力和感染力，待人诚实，为人诚信，善于沟通，执行力强；    \n        熟悉宏观管理与计划/规划并能独立制定及组织实施和考核监控,以达到/实现目标达成的目的；    \n        熟练掌握相关管理工具，包括：BS(头脑风暴法)/SM(战略管理)/PM(计划管理)/SMART(目标遵循原则法)/BCG(波士顿矩阵图)/SWOT(战略分析法)/SM(战略地图)/5W2H(七何分析法)/WBS(工作分解结构)/SOP(标准化作业程序)/5S管理/PDCA(过程管理循环法)/TM(时间管理)/BSC(平衡计分卡)/KPI(关健指标考核法)、OCP(企业定位)、PP(产品定位)等；\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"867067\",\"jobFunction1\":1001,\"jobFunction2\":2140,\"jobFunction3\":0,\"jobLocation1\":\"0100\",\"jobLocation2\":\"0200\",\"jobLocation3\":\"0800\",\"location\":\"1803\",\"degreeId\":50,\"workyear\":5,\"age\":55,\"sex\":0,\"school\":\"长江大学\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"临床医学系毕业\",\"otherSkills\":\"1、              对企业绝对的忠诚度；2、              有绝对吃苦耐劳的精神；3、              有丰富的现代企业管理培训经验；4、              有丰富的民营医院管理经验；5、              有最新的等级医院创建经验；6、              有良好的团队精神和带团队的经验；7、              有绝对严谨认真的工作态度和很强的学习精神；8、              有医院医疗、财务、经营、品牌推广等综合管理经验。9、    有比较强的执行力。\",\"selfDescription\":\"　　　　　　　李侬   简历     应聘职位  ：院长；  业务院长                   一般资料：                                  　李侬，男，1962年5月出生，身高：170cm，本科，副主任医师。　出生地：浙江绍兴 现定居地：湖北宜昌市 　身份证号码：422724196205210113　个人经历：　1983年7月毕业于宜昌卫生学校计划统计专业。　1986年9月至1989年8月现长江大学临床医学系毕业（脱产三年）　1990年—1995年当阳市医院普外科工作，(3甲)　1995年调入当阳市妇幼保健院人外科主任、门诊主任、业务院长（3甲）　1997年晋升主治医师，在三甲医院（宜昌市中心医院进修一年）（3甲）　1998年2001年当阳市卫生局医政科　2001年----2004年城区玉阳医院院长书记；　2004年---2008年3月玉泉医院院长书记　2008年---2011年武汉唐人集团宜昌医院业务院长（2甲）　2011年----2012年10月，江西洋达医疗投资集团　2012年10月至2013年5月武汉济和医院业务院长（2甲）　2013年5月至---宜昌民福医院业务院长（2甲）  2014年2月北京军事医学科学院　　2008年至2011年工作于宜昌市某医院（宜昌市第一家二级综合民营医院），业务院长负责医疗业务部，重点抓医疗管理工作，兼做经营分析。   该医院床位200张，50年代筹建，以脊柱外科，普外科、妇产科为专科特色，至2011  年月收入平均250万。   本人业务上能独立开展普外科手术，大肠癌，乳腺甲状腺肿瘤手术，外伤性脾破裂切除，外伤性肝破裂膈肌破裂心包破裂修补等手术及腹腔镜胆囊手术小儿外科疝气、隐睾等手术，妇科宫外孕、附件囊肿、子宫肌瘤等腹腔镜手术，能开展食管中下段癌，直肠癌根治等手术。曾于国家级以上杂志发表学术论文共9篇，发表管理方面的文章3篇。　 管理上擅长现代企业化管理理念来管理医院，能够开展创新管理模式（把公立与民营有机结合），相当熟悉医政管理的政策和要求，对于民营医院特色的质量管理、绩效管理、经营管理、人力资源管理、品牌推广等有自己的成功经验和心得；擅长员工培训，培养忠诚度高、有工作激情的员工。工作上非常注重细节管理，特别注重强有力的执行力，善于把复杂的问题简单化，简单的问题流程化。善于沟通，有较强的协调能力。有丰富的民营医院处理纠纷的经验。　一定程度上掌握网络推广、优化和竞价，经常负责进行咨询培训，掌握民营医院广告投入的技巧，善于进行合理市场分析，可以全面掌握杂志编排、发放，市场转诊管理、户外广告的洽谈、分析和具体管理，有较好的媒体风险预防和处理能力。　求职意向：1、 大型规模综合医院（二甲规模）或专科医院；2、 医院有良好的自主管理平台，可以充分发挥自身价值；3、 集团拥有良好的文化和合理的福利待遇；4、 远离家族化、亲情化管理。　应聘优势：1、 对企业绝对的忠诚度；2、 有绝对吃苦耐劳的精神；3、 有丰富的现代企业管理培训经验；4、 有丰富的民营医院管理经验；5、 有最新的等级医院创建经验；6、 有良好的团队精神和带团队的经验；7、 有绝对严谨认真的工作态度和很强的学习精神；8、 有医院医疗、财务、经营、品牌推广等综合管理经验。9、 有比较强的执行力。　　联系方式：   15926999444（宜昌市）   　邮箱：1981787753@qq.com         QQ：1981787753\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"1241484\",\"jobFunction1\":2090,\"jobFunction2\":0,\"jobFunction3\":0,\"jobLocation1\":\"0200\",\"jobLocation2\":\"\",\"jobLocation3\":\"\",\"location\":\"0200\",\"degreeId\":50,\"workyear\":12,\"age\":35,\"sex\":0,\"school\":\"武汉大学医学院\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"护理学\",\"otherSkills\":\" 沟通能力强 学习力强 诚信正直 沉稳内敛 阳光开朗\",\"selfDescription\":\"本人专业知识扎实，主管护师，责任心强，富有爱心和耐心，工作细心，学习能力强，与人沟通能力强，人际关系融洽。性格开朗，乐观，自信，有良好的合作精神，愿顺从，能以谦虚的态度赞扬接纳优越者。\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"579255\",\"jobFunction1\":1039,\"jobFunction2\":1012,\"jobFunction3\":1024,\"jobLocation1\":\"0200\",\"jobLocation2\":\"0302\",\"jobLocation3\":\"0311\",\"location\":\"1710\",\"degreeId\":40,\"workyear\":11,\"age\":39,\"sex\":0,\"school\":\"河南中医学院\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"中西医结合\",\"otherSkills\":\"\",\"selfDescription\":\"\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"1293294\",\"jobFunction1\":1042,\"jobFunction2\":0,\"jobFunction3\":0,\"jobLocation1\":\"0200\",\"jobLocation2\":\"0800\",\"jobLocation3\":\"0700\",\"location\":\"0804\",\"degreeId\":60,\"workyear\":18,\"age\":47,\"sex\":0,\"school\":\"香港亚洲商学院\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"工商管理\",\"otherSkills\":\"沟通能力强 执行力强 学习力强 有亲和力 诚信正直 雷厉风行 沉稳内敛 阳光开朗 人脉广 善于创新\",\"selfDescription\":\"在管理方面:具备较强的规划能力/执行力/观察分析能力/综合调度能力/沟通能力/团队领导能力1、品德高尚，见识广博，工作勤奋，基本功过硬。不文过饰非，堪为全体员工的模范。2、头脑灵活，对医疗市场有预见性的洞察力，有果断的判断、勇敢的实践和坚忍不拔的毅力以及有旺盛的进取精神和独创精神。　　3、有人情味，总能考虑别人的难处，把医院的收益与员工的生活福利联系在一起，使医院与全体职工形成一个不可分离的整体。在上司、部下、科室、同事、关系单位之间经常创造一种令人满意的气氛，像磁铁一样有吸引力，有领导才能。　　4、自觉认清医院对社会应负的道义责任和其它责任，并在行动中恪守无误，把全体职工的真正声音带到最高决策层，并提出解决问题的建议。5、严守信誉，不先私后公，在任何情况下不为浮利轻举妄动，不排斥别人，兼听和采纳各方意见和好的建议。6、不光做面子上的事情，遇到困难不畏缩，不是先考虑“为什么“，而是研究“怎样才能完成”。　　7、组织、决策和创新才能;能抓住大事，把小事分给部属，能发挥部属的才能，善于组织人力、物力、财力，依据事实而非依据主观想象进行决策，具有高瞻远瞩并对新事物、新环境、新观念有敏锐的感受能力。　　8、团队合作精神，愿与他人一起工作，能赢得人们的合作，尊重他人，重视采纳员工意见，不武断狂妄，对员工不是压服、而是说服，加强学习与培训管理。　　9、能善于发现培养下级的能力，了解下级的需要，对下级善于进行教育，以提高他们的素质和工作效率，调动积极性的能力，能采用巧妙的方法使下级人员积极、主动地工作，而不是被动地单纯听从命令、指示。　　10、保障医疗质量、医护质量、医疗安全、医疗水平在高水准状态运行。　　总的来说，医院院长是与人打交道，必须经常与人接触，要能管理人、用人。而现代人观念既然已经多元化，医院院长用牵引机式的方法去领导部属的话，便不能成功了。因此一位出色的院长也应该成为一个多元化的全才。最重要的是员工们对院长最大的满意则是院长为员工、为医院、为社会创造和给予了更多、更意想不到的实惠与利益。\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"224386\",\"jobFunction1\":1409,\"jobFunction2\":9999,\"jobFunction3\":0,\"jobLocation1\":\"0200\",\"jobLocation2\":\"0800\",\"jobLocation3\":\"0300\",\"location\":\"0200\",\"degreeId\":20,\"workyear\":20,\"age\":56,\"sex\":0,\"school\":\"安徽一中\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"电气\",\"otherSkills\":\"集丰富的工作经验，和扎实的技术水平于一体的技术人才\",\"selfDescription\":\"本人从事电工维修己有二十年时间，有丰富的工作经验和扎实的技术水平。特别精通高低压线路安装操作和维修，电气控制线路安装和检修。并于2001年进修于合肥飞跃电工进修学院获得四级中级证书和深圳特种操作证和高压进网操作证。熟练掌握网络，空调，弱电，发电机等方面安装维修和操作，基建工程进度跟进，监督，验收\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]},{\"resId\":\"1314865\",\"jobFunction1\":1042,\"jobFunction2\":0,\"jobFunction3\":0,\"jobLocation1\":\"0600\",\"jobLocation2\":\"0200\",\"jobLocation3\":\"0802\",\"location\":\"0808\",\"degreeId\":40,\"workyear\":2,\"age\":20,\"sex\":0,\"school\":\"江西中医学院\",\"updateDateL\":0,\"photoNum\":0,\"speciality\":\"护理\",\"otherSkills\":\"沟通能力强 执行力强 学习力强 有亲和力 诚信正直 阳光开朗 \",\"selfDescription\":\"本人性格开朗，有较好的沟通能力，待人真诚，工作认真负责，积极主动，吃苦耐劳。\",\"educationList\":[],\"workExpList\":[],\"stylePhotoList\":[],\"pointList\":[],\"trainingList\":[],\"projectList\":[]}]}}";
			System.out.println(jsonStr);
			jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
			JSONObject obj = JSONObject.parseObject(jsonStr);
			if(obj.getString("code") != null && "E200".equals(obj.getString("code"))){
				JSONObject data = (JSONObject) obj.get("data");
				if(data.containsKey("totalPages") && data.containsKey("totalSize") && data.containsKey("list")){
					PageInfo<LinkedHashMap<String, Object>> page = new PageInfo<LinkedHashMap<String, Object>>();
					page.setTotal(data.getInteger("totalSize"));
					page.setPages(data.getInteger("totalPages"));
					JSONArray resumeArray = (JSONArray) data.get("list");
	                
					if(!resumeArray.isEmpty() && resumeArray.size() > 0){
						List<LinkedHashMap<String, Object>> resumeList = new ArrayList<LinkedHashMap<String, Object>>();
						for(int i=0;i<resumeArray.size();i++){
							MyResume myResume = JSONObject.toJavaObject(resumeArray.getJSONObject(i), MyResume.class);
							resumeList.add(transferResumeObjToMap(myResume));
						}
						page.setList(resumeList);
					}
					if(page != null){
						result.setResult(page);
					}
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("searchResume异常！",e);
		}
		return result;
	}

	@Override
	public JsonResponse<MyResume> viewResume(String clinicId,String resId) {
        JsonResponse<MyResume> result = new JsonResponse<MyResume>();
		
        if(StringUtils.isBlank(clinicId) || StringUtils.isBlank(resId) || !StringUtils.isNumeric(resId)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.IllegalArgument.getCode());
			result.setErrorMsg("参数不合法");
			return result;
		}
        
		try {
			String jsonStr  ="";// resumeWebService.viewResume(Integer.parseInt(resId));
//			System.out.println(jsonStr);
			
			jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
			JSONObject obj = JSONObject.parseObject(jsonStr);
			if(obj.getString("code") != null && "E200".equals(obj.getString("code"))){
				JSONObject data = (JSONObject) obj.get("data");
				MyResume myResume = JSONObject.toJavaObject(data, MyResume.class);
				if(myResume != null){
					result.setResult(myResume);
					
					upsertTalentCvByYYRC(myResume);
					
					TalentCvRecord record = new TalentCvRecord();
					record.setId(UUID.randomUUID().toString());
					record.setClinicId(clinicId);
					record.setTalentCvId("YYRC" + myResume.getId());
					record.setCreateDate(new Date());
					record.setReadFlag("0");
					record.setDelFlag("0");
					
					talentCvRecordMapper.insertSelective(record);
				}
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("viewResume异常！",e);
		}
		return result;
	}

	@Override
	public JsonResponse<MyResume> downloadResume(String clinicId,String resId) {
		JsonResponse<MyResume> result = new JsonResponse<MyResume>();
			
		if(StringUtils.isBlank(clinicId) || StringUtils.isBlank(resId) || !StringUtils.isNumeric(resId)){
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.IllegalArgument.getCode());
			result.setErrorMsg("参数不合法");
			return result;
		}
		
		try {
			JsonResponse<YyrcAccount> jrAccountQy = jobYYRCAccountService.selectAccountByClinicId("pinganwj");
			if(jrAccountQy == null || jrAccountQy.getResult() == null || jrAccountQy.getResult().getId() == null){
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg("暂未开通医药人才网企业账号！");
				return result;
			}
			
			JsonResponse<YyrcAccount> jrAccount = jobYYRCAccountService.selectAccountByClinicId(clinicId);
			if(jrAccount == null || jrAccount.getResult() == null || jrAccount.getResult().getYyrcUserId() == null){
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg("暂未开通医药人才网账号！");
				return result;
			}
			
			if(job51Service.hasDownload(clinicId, "YYRC"+resId).getResult()){
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg("简历已在下载库中！");
				return result;
			}else{
				TalentCvRecord record = new TalentCvRecord();
				record.setId(UUID.randomUUID().toString());
				record.setClinicId(clinicId);
				record.setTalentCvId("YYRC" + resId);
				record.setCreateDate(new Date());
				record.setDelFlag("0");
				if(commonJedis.getObject("YYRCCVDetail_" + "YYRC" +  resId) != null){
					record.setReadFlag("2");
					result.setResult((MyResume) commonJedis.getObject("YYRCCVDetail_" + "YYRC" +  resId));
				}else{
					record.setReadFlag("1");
					
					String jsonStr  ="";// resumeWebService.downloadResume(Integer.parseInt(resId), Integer.parseInt(jrAccountQy.getResult().getYyrcUserId()), jrAccountQy.getResult().getName());
					jsonStr = jsonStr.substring(jsonStr.indexOf("{"), jsonStr.length());
					JSONObject obj = JSONObject.parseObject(jsonStr);
					if(obj.getString("code") != null && "E200".equals(obj.getString("code"))){
						JSONObject data = (JSONObject) obj.get("data");
						MyResume myResume = JSONObject.toJavaObject(data, MyResume.class);
						if(myResume != null){
							result.setResult(myResume);
							result.setStatus(Status.SUCCESS);
							commonJedis.putObject("YYRCCVDetail_" + "YYRC" +  resId, myResume);
						}
					}else{
						if(obj.getString("message") != null && obj.getString("message") != null){
							result.setErrorMsg(obj.getString("message"));
						}else{
							result.setErrorMsg(ErrorType.SystemBusy.getDesc());
						}
						logger.error(resId + ":YYRC下载简历接口返回失败！");
						result.setStatus(Status.ERROR);
						result.setErrorCode(ErrorType.SystemBusy.getCode());
						return result;
					}
				}
				talentCvRecordMapper.insertSelective(record);
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("viewResume异常！",e);
		}
		return result;
	}
	
	public String getXmlCodeByValue(String xmlName,String xmlValue){
		String returnStr = "";
		try {
			HashMap<String,String> xmlMap = new HashMap<String,String>();
			
			xmlMap = Job51XmlConverUtil.xmltoMapCodeByValue(xmlName);
			if(!xmlMap.isEmpty()){
				if(xmlMap.containsKey(xmlValue)){
					returnStr = xmlMap.get(xmlValue);
				}else if(xmlValue.length()>=4){
					for(int i=xmlValue.length();i>1;i--){
						if(xmlMap.containsKey(xmlValue.substring(0,i))){
							returnStr = xmlMap.get(xmlValue.substring(0,i));
							break;
						}
					}
				}
			}

		}catch (Exception e) {
			e.printStackTrace();
			logger.error("getXmlCode异常！",e);
		}
		return returnStr;
	}
	
	public LinkedHashMap<String, Object> transferResumeObjToMap(MyResume myResume){
		LinkedHashMap<String, Object> talentCvMap = new LinkedHashMap<String, Object>();
		try {
			//简历id
			talentCvMap.put("id", myResume.getResId());
			//简历名称
			talentCvMap.put("intentionJobName",getXmlValueByCode("YYRC_FUNCTION",myResume.getJobFunction1()+""));
			
			//期望薪资
			if("0".equals(myResume.getSalary())){
				talentCvMap.put("isNegotiable","1");
			}else{
				talentCvMap.put("expectedSalaryName",myResume.getSalary());
			}
			
			//专业
			talentCvMap.put("professional",myResume.getSpeciality());
			
			//最高学历
			talentCvMap.put("educationLevel",getXmlValueByCode("YYRC_DEGREE",myResume.getDegreeId()+""));
			
		    talentCvMap.put("fromSource", ResumeFromSource.YYRC.getDesc());
			
			
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("transferYYRCResumeObjToMap异常！",e);
		}
		return talentCvMap;
	}
	
	public String getXmlValueByCode(String xmlName,String xmlCode){
		String returnStr = "";
		try {
			HashMap<String,String> xmlMap = new HashMap<String,String>();
			xmlMap = Job51XmlConverUtil.xmltoMapValueByCode(xmlName);
			
			if(!xmlMap.isEmpty() && xmlMap.containsKey(xmlCode)){
				returnStr = xmlMap.get(xmlCode);
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("getXmlValue异常！",e);
		}
		return returnStr;
	}
	
	private void upsertTalentCvByYYRC(MyResume myResume) {
		TalentCv talentCv = new TalentCv();
		talentCv.setId("YYRC"+myResume.getId());
		talentCv.setCvShowId(myResume.getId()+"");
		
		TalentCv talentCvExists = talentCvMapper.selectByPrimaryKey("YYRC"+myResume.getId());
		
		Boolean insertFlag = true;
		if(talentCvExists != null && StringUtils.isNotBlank(talentCvExists.getId())){
			//简历没有刷新
			if(talentCvExists.getRefreshTime() != null && myResume.getUpdateDate().equals(DateUtils.format(talentCvExists.getRefreshTime(), DateUtils.DATE_FORMAT_TYPE3))){
				return;
			}else{
				insertFlag = false;
			}
		}else{
			insertFlag = true;
		}
		
		talentCv.setMemberId(-1l);
		talentCv.setStatus("3");
		talentCv.setDelFlag("0");
		
		//简历更新日期
		if(myResume.getUpdateDate() != null && StringUtils.isNotBlank(myResume.getUpdateDate())){
			talentCv.setRefreshTime(DateUtils.parse(myResume.getUpdateDate(), DateUtils.DATE_FORMAT_TYPE3));
		}
		
		try{
			//期望薪资
			if(myResume.getSalary() != null && StringUtils.isNotBlank(myResume.getSalary())){
				if(StringUtils.isNumeric(myResume.getSalary())){
					long salary = Long.parseLong(myResume.getSalary());
					talentCv.setExpectedSalaryMin(salary);
					talentCv.setExpectedSalaryMax(salary);
				}else{
					talentCv.setIsNegotiable("1");
				}
			}else{
				talentCv.setIsNegotiable("1");
			}
		}catch(Exception e){
			logger.info("期望薪资格式问题----------");
		}
		
		//工作经验
		if(myResume.getWorkyear() == 0){
			talentCv.setExperience("01");
		}else if(myResume.getWorkyear()>0 && myResume.getWorkyear() <= 3){
			talentCv.setExperience("02");
		}else if(myResume.getWorkyear()>3 && myResume.getWorkyear() <= 5){
			talentCv.setExperience("03");
		}else if(myResume.getWorkyear()>5 && myResume.getWorkyear() <= 10){
			talentCv.setExperience("04");
		}else if(myResume.getWorkyear()>10 && myResume.getWorkyear() <= 15){
			talentCv.setExperience("05");
		}else{
			talentCv.setExperience("06");
		}
		
		//专业
		talentCv.setProfessional(myResume.getSpeciality());
		
		//最高学历
		switch (myResume.getDegreeId()) {
			case -1:
				talentCv.setEducationLevel("07");
				break;
			case 10:
				talentCv.setEducationLevel("07");
				break;
			case 20:
				talentCv.setEducationLevel("07");
				break;
			case 25:
				talentCv.setEducationLevel("05");
				break;
			case 40:
				talentCv.setEducationLevel("04");
				break;
			case 50:
				talentCv.setEducationLevel("03");
				break;
			case 55:
				talentCv.setEducationLevel("03");
				break;
			case 60:
				talentCv.setEducationLevel("02");
				break;
			case 70:
				talentCv.setEducationLevel("01");
				break;
			case 80:
				talentCv.setEducationLevel("07");
				break;
			default:
				talentCv.setEducationLevel("07");
				break;
		}
		
		//工作地点
		StringBuffer locationName = new StringBuffer("'");
		if(StringUtils.isNotBlank(myResume.getJobLocation1Name())){
			locationName.append(myResume.getJobLocation1Name());
		}
		if(StringUtils.isNotBlank(myResume.getJobLocation2Name())){
			locationName.append("+" + myResume.getJobLocation2Name());
		}
		if(StringUtils.isNotBlank(myResume.getJobLocation3Name())){
			locationName.append("+" + myResume.getJobLocation3Name());
		}
		talentCv.setCityName(locationName.toString());
		
		
		//简历名称
		StringBuffer intentionJobName = new StringBuffer("'");
		if(StringUtils.isNotBlank(myResume.getJobFunction1Name())){
			intentionJobName.append(myResume.getJobFunction1Name());
		}
		if(StringUtils.isNotBlank(myResume.getJobFunction2Name())){
			intentionJobName.append("+" + myResume.getJobFunction2Name());
		}
		if(StringUtils.isNotBlank(myResume.getJobFunction3Name())){
			intentionJobName.append("+" + myResume.getJobFunction3Name());
		}
		talentCv.setIntentionJobName(intentionJobName.toString());
		
		talentCv.setFromSource(ResumeFromSource.YYRC.getDesc());
		
		if(insertFlag){
			talentCvMapper.insertSelective(talentCv);
		}else{
			talentCvMapper.updateByPrimaryKeySelective(talentCv);
		}
		
	}
	
}
