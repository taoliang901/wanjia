package com.wanjia.dsi.web.condition.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.web.condition.dao.mapper.ConditionMapper;
import com.wanjia.dsi.web.condition.model.Condition;
import com.wanjia.dsi.web.condition.service.ConditionService;

/**
 * This element is automatically generated on 16-3-2 下午2:40, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class ConditionServiceImpl implements ConditionService {
	@Autowired
	private ConditionMapper conditionMapper;

	/*
	 * <p>Title: getDepartmentList</p> <p>Description: </p>
	 * 
	 * @param condition
	 * 
	 * @return
	 * 
	 * @see
	 * com.wanjia.dsi.web.condition.service.ConditionService#getDepartmentList(
	 * com.wanjia.dsi.web.condition.model.Condition)
	 */
	@Override
	public List<Condition> getConditionList(Condition condition, int offset, int pageSize) {
		// TODO Auto-generated method stub
		return (List<Condition>) conditionMapper.getConditionList(condition, offset, pageSize);
	}

	@Override
	public Condition findById(Long id) {
		return (Condition) conditionMapper.findById(id);
	}

	@Override
	public List<Condition> findWithPagination(int offset, int count) {
		return (List<Condition>) conditionMapper.findWithPagination(offset, count);
	}

	@Override
	public List<Condition> findAll() {
		return (List<Condition>) conditionMapper.findAll();
	}

	@Override
	public List<Condition> findByEntity(Condition model) {
		return (List<Condition>) conditionMapper.findByEntity(model);
	}

	@Override
	public List<Condition> findByEntityWithPagination(Condition model, int offset, int count) {
		return (List<Condition>) conditionMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	public Condition findOneByEntity(Condition model) {
		return (Condition) conditionMapper.findOneByEntity(model);
	}

	@Override
	public List<Condition> findByProperty(String propertyName, String propertyValue) {
		return (List<Condition>) conditionMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	public Condition findOneByProperty(String propertyName, String propertyValue) {
		return (Condition) conditionMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	public List<Condition> findByPropertyWithPagination(String propertyName, String propertyValue, int offset,
			int count) {
		return (List<Condition>) conditionMapper.findByPropertyWithPagination(propertyName, propertyValue, offset,
				count);
	}

	@Override
	public List<Condition> findByProperties(Map<String, Object> map) {
		return (List<Condition>) conditionMapper.findByProperties(map);
	}

	@Override
	public long countByEntity(Condition model) {
		return (long) conditionMapper.countByEntity(model);
	}

	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		return (long) conditionMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	public long countByProperties(Map<String, Object> map) {
		return (long) conditionMapper.countByProperties(map);
	}

	@Override
	public void update(Condition model) {
		conditionMapper.update(model);
	}

	@Override
	public void insert(Condition model) {
		conditionMapper.insert(model);
	}

	@Override
	public void deleteByEntity(Condition model) {
		conditionMapper.deleteByEntity(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		conditionMapper.deleteByProperty(propertyName, propertyValue);
	}

	public long countAll() {
		return this.conditionMapper.countAll();
	}

	public void insertBatch(List<Condition> list) {
		this.conditionMapper.insertBatch(list);
	}

	public void delete(Long id) {
		this.conditionMapper.deleteById(id);
	}

	/*
	 * <p>Title: getConditionListCount</p> <p>Description: </p>
	 * 
	 * @param condition
	 * 
	 * @return
	 * 
	 * @see com.wanjia.dsi.web.condition.service.ConditionService#
	 * getConditionListCount(com.wanjia.dsi.web.condition.model.Condition)
	 */
	@Override
	public Long getConditionListCount(Condition condition) {
		// TODO Auto-generated method stub
		return (long) this.conditionMapper.getConditionListCount(condition);
	}
}