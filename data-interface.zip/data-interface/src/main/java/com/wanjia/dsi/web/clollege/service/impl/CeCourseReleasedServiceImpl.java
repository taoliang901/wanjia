package com.wanjia.dsi.web.clollege.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.web.college.dao.mapper.CeCourseReleasedMapper;
import com.wanjia.dsi.web.college.model.CeCourseReleased;
import com.wanjia.dsi.web.college.service.CeCourseReleasedService;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CeCourseReleasedServiceImpl extends BaseServiceImpl implements CeCourseReleasedService {

	@Autowired
	private CeCourseReleasedMapper ceCourseReleasedMapper;

	@Override
	public JsonResponse<PageInfo<CeCourseReleased>> findAllCeCourseReleasedByType(int pageNo, int pageSize,
			int typeId) {
		JsonResponse<PageInfo<CeCourseReleased>> jr = new JsonResponse<PageInfo<CeCourseReleased>>();
		try {
			PageHelper.startPage(pageNo, pageSize);
			List<CeCourseReleased> list = ceCourseReleasedMapper.findAllCeCourseReleasedByType(typeId);
			PageInfo<CeCourseReleased> pageInfo = new PageInfo<CeCourseReleased>(list);
			jr.setResult(pageInfo);
			jr.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("findAllCeCourseReleasedByType" + e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return jr;
	}

	@Override
	public JsonResponse<CeCourseReleased> findCeCourseReleasedByCourseId(String course_id) {
		JsonResponse<CeCourseReleased> jr = new JsonResponse<CeCourseReleased>();
		try {
			CeCourseReleased ceCourseReleased = ceCourseReleasedMapper.findCeCourseReleasedByCourseId(course_id);
			jr.setStatus(Status.SUCCESS);
			jr.setResult(ceCourseReleased);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("findCeCourseReleasedByCourseId" + e);
			jr.setStatus(Status.ERROR);
			jr.setErrorCode(ErrorType.SystemBusy.getCode());
			jr.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return jr;
	}

}
