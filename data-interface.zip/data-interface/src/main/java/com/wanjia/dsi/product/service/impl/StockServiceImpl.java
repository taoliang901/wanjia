package com.wanjia.dsi.product.service.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.product.dao.mapper.StockMapper;
import com.wanjia.dsi.product.model.Stock;
import com.wanjia.dsi.product.service.ProductService;
import com.wanjia.dsi.product.service.StockService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class StockServiceImpl implements StockService {

	private Logger logger = Logger.getLogger(StockServiceImpl.class);

	@Autowired
	private CommonJedis commonJedis;

	@Autowired
	private StockMapper sotckMapper;

	@Autowired
	private ProductService productService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#delStockStatus(java.lang.
	 * String, java.lang.String)
	 */
	@Deprecated
	@Override
	public JsonResponse<Map<String, String>> getStockStatus(String prdId) {
		JsonResponse<Map<String, String>> jsonResponse = new JsonResponse<Map<String, String>>();
		Map<String, String> result = commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId);
		jsonResponse.setResult(commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId));
		return jsonResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#delStockStatus(java.lang.
	 * String, java.lang.String)
	 */
	@Override
	public void setStockStatus(String prdId, String stockId, String allCardNo) {
		// 增加已消耗库存
		commonJedis.putHashObject(Consts.PRD_STOCK_PREFIX + prdId, stockId, allCardNo);
		// 减少未消耗库存
		commonJedis.removeHashObject(Consts.PRD_STOCK_UNUSED_PREFIX, stockId);

		int usedCount = commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId).size();
		int unusedCount = commonJedis.getHashObject(Consts.PRD_STOCK_UNUSED_PREFIX + prdId).size();
		// 更新已消耗库存/未消耗库存数字
		commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_USED_PREFIX, new Double(usedCount), prdId);
		commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_UNUSED_PREFIX, new Double(unusedCount), prdId);

		commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_PREFIX, new Double(usedCount + unusedCount), prdId);
		/**
		 * 更新mongo的已消耗库存
		 */
		productService.insertPrdInfoBOByPrdId(prdId, null,
				String.valueOf(commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId).size()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#delStockStatus(java.lang.
	 * String, java.lang.String)
	 */
	@Override
	public void setStockStatusBatch(Map<String, Map<String, String>> stocks) {
		if (stocks != null) {
			Set<String> prdIds = stocks.keySet();
			for (String prdId : prdIds) {
				Map<String, String> prdStocks = stocks.get(prdId);
				Set<String> stockIdSet = prdStocks.keySet();
				String[] stockIds = stockIdSet.toArray(new String[stockIdSet.size()]);
				for (String stockId : stockIds) {
					// 增加已消耗库存
					commonJedis.putHashObject(Consts.PRD_STOCK_PREFIX + prdId, stockId, prdStocks.get(stockId));
				}
				// 减少未消耗库存
				commonJedis.removeHashObject(Consts.PRD_STOCK_UNUSED_PREFIX + prdId, stockIds);

				int usedCount = commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId).size();
				int unusedCount = commonJedis.getHashObject(Consts.PRD_STOCK_UNUSED_PREFIX + prdId).size();
				// 更新已消耗/未消耗库存数量
				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_USED_PREFIX, new Double(usedCount), prdId);
				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_UNUSED_PREFIX, new Double(unusedCount), prdId);

				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_PREFIX, new Double(usedCount + unusedCount),
						prdId);
				/**
				 * 更新mongo的已消耗库存
				 */
				productService.insertPrdInfoBOByPrdId(prdId, null,
						String.valueOf(commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId).size()));
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#delStockStatus(java.lang.
	 * String, java.lang.String)
	 */
	@Override
	public void delStockStatus(String prdId, String... stockIds) {
		// 减少已消耗库存
		commonJedis.removeHashObject(Consts.PRD_STOCK_PREFIX + prdId, stockIds);

		Map<String, String> map = new HashMap<String, String>();
		for (String stockId : stockIds) {
			map.put(stockId, commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId).get(stockId));
		}

		// 增加未消耗库存
		commonJedis.putHashMapObjects(Consts.PRD_STOCK_UNUSED_PREFIX + prdId, map);

		int usedCount = commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId).size();
		int unusedCount = commonJedis.getHashObject(Consts.PRD_STOCK_UNUSED_PREFIX + prdId).size();
		// 更新已消耗/未消耗库存总数
		commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_USED_PREFIX, new Double(usedCount), prdId);
		commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_UNUSED_PREFIX, new Double(unusedCount), prdId);

		commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_PREFIX, new Double(usedCount + unusedCount), prdId);
		/**
		 * 更新mongo的已消耗库存
		 */
		productService.insertPrdInfoBOByPrdId(prdId, null,
				String.valueOf(commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId).size()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wanjia.dsi.product.service.StockService#
	 * updateStockStatusForModifyAppointment(java.lang.String, java.lang.String,
	 * java.lang.String[])
	 */
	@Deprecated
	@Override
	public void updateStockStatusForModifyAppointment(String prdId, String newStockId, String newStatus,
			String... cancelstockIds) {
		commonJedis.removeHashObject(prdId, cancelstockIds);
		commonJedis.putHashObject(Consts.PRD_STOCK_PREFIX + prdId, newStockId, newStatus);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#getStockStatus(java.lang.
	 * String[])
	 */
	@Deprecated
	@Override
	public JsonResponse<Map<String, Map<String, String>>> getStocksStatus(String... prdIds) {
		JsonResponse<Map<String, Map<String, String>>> jsonResponse = new JsonResponse<Map<String, Map<String, String>>>();
		Map<String, Map<String, String>> resultMap = new HashMap<String, Map<String, String>>();
		if (prdIds != null) {
			String[] propertyIds = new String[prdIds.length];
			for (int i = 0; i < prdIds.length; i++) {
				propertyIds[i] = Consts.PRD_STOCK_PREFIX + prdIds[i];
			}
			resultMap = commonJedis.getHashObjects(propertyIds);
			jsonResponse.setResult(resultMap);
		}
		return jsonResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wanjia.dsi.product.service.StockService#updateAllStockStatus()
	 */
	@Override
	public JsonResponse<String> updateAllStockStatus() {
		JsonResponse<String> jsonResponse = new JsonResponse<String>();
		try {
			Stock stockParam = new Stock();
			stockParam.setDelFlag("0");
			// 获取库存总量，包括使用的和未使用的
			List<Stock> stocks = sotckMapper.findSotcks(stockParam);

			// 获取产品列表
			List<String> allPrdIds = sotckMapper.findSotckProduct();
			Map<String, Map<String, String>> productsUsed = new HashMap<String, Map<String, String>>();
			Map<String, Map<String, String>> productsUnused = new HashMap<String, Map<String, String>>();
			for (String prdId : allPrdIds) {
				Map<String, String> productUsed = new HashMap<String, String>();
				Map<String, String> productUnused = new HashMap<String, String>();
				productsUsed.put(prdId, productUsed);
				productsUnused.put(prdId, productUnused);
				// 保存产品的总数量 为0
				commonJedis.putObject(Consts.PRD_TOTAL_STOCK_PREFIX + prdId, new Integer(0));
				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_USED_PREFIX, new Double(0), prdId);
				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_PREFIX, new Double(0), prdId);
			}

			for (Stock stock : stocks) {
				String stockPrdId = stock.getCouponId();
				if (StringUtils.equals("1", stock.getStatus())) {
					if (productsUsed.get(stockPrdId) != null) {
						Map<String, String> product = productsUsed.get(stockPrdId);
						product.put(stock.getId(), stock.getAllCardNo());
						productsUsed.put(stockPrdId, product);
					}
				} else {
					if (productsUnused.get(stockPrdId) != null) {
						Map<String, String> product = productsUnused.get(stockPrdId);
						product.put(stock.getId(), stock.getAllCardNo());
						productsUnused.put(stockPrdId, product);
					}
				}
			}
			StringBuilder result = new StringBuilder();
			for (String prdId : allPrdIds) {
				Map<String, String> productUsed = productsUsed.get(prdId);
				Map<String, String> productUnused = productsUnused.get(prdId);

				int usedCount = productUsed.size();
				int unusedCount = productUnused.size();
				commonJedis.removeObject(Consts.PRD_STOCK_PREFIX + prdId);
				commonJedis.removeObject(Consts.PRD_STOCK_UNUSED_PREFIX + prdId);
				commonJedis.putHashMapObjects(Consts.PRD_STOCK_PREFIX + prdId, productUsed);
				commonJedis.putHashMapObjects(Consts.PRD_STOCK_UNUSED_PREFIX + prdId, productUnused);

				if (StringUtils.equals(prdId, "9a4c9e84-aedf-4028-b721-8b9e07ba1098")) {
					Map<String, String> m1 = commonJedis.getHashObject(Consts.PRD_STOCK_PREFIX + prdId);
					Map<String, String> m2 = commonJedis.getHashObject(Consts.PRD_STOCK_UNUSED_PREFIX + prdId);
					m1.size();
					m2.size();
				}
				// 保存ZSET
				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_USED_PREFIX, new Double(usedCount), prdId);
				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_UNUSED_PREFIX, new Double(unusedCount), prdId);
				commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_PREFIX, new Double(usedCount + unusedCount),
						prdId);

				productService.insertPrdInfoBOByPrdId(prdId, String.valueOf(usedCount + unusedCount),
						String.valueOf(usedCount));
				String singleLog = "产品：[" + prdId + "]，已使用：[" + usedCount + "]，总数：[" + (usedCount + unusedCount) + "]";
				System.out.println(singleLog);
				result.append(singleLog);
			}

			jsonResponse.setResult(result.toString());
		} catch (Exception e) {
			logger.error("初始化库存错误", e);
			jsonResponse.setStatus(JsonResponse.Status.ERROR);
			jsonResponse.setResult("初始化库存错误：" + e.getStackTrace());
		}
		return jsonResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#updateStockNumber(java.lang.
	 * String, int)
	 */
	@Deprecated
	@Override
	public void updateStockNumber(String prdId, Integer number) {
		// commonJedis.putObject(Consts.PRD_TOTAL_STOCK_PREFIX + prdId, number);
		commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_USED_PREFIX, new Double(number), prdId);
		/**
		 * 更新mongo的总库存
		 */
		productService.insertPrdInfoBOByPrdId(prdId, String.valueOf(number), null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#updateStockNumberAndFulNo(
	 * java.lang. String, int)
	 */
	@Override
	public void updateStockNumberAndFulNo(String prdId, Integer number, Map<String, String> map) {
		// 更新库存ID与库存的完整卡号
		commonJedis.putHashMapObjects(Consts.PRD_STOCK_UNUSED_PREFIX + prdId, map);

		// 更新库存总量
		commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_PREFIX, new Double(number), prdId);

		/**
		 * 更新mongo的总库存
		 */
		productService.insertPrdInfoBOByPrdId(prdId, String.valueOf(number), null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#getStocksNumber(java.lang.
	 * String[])
	 */
	@Deprecated
	@Override
	public JsonResponse<Map<String, Object>> getStocksNumber(String... prdIds) {
		JsonResponse<Map<String, Object>> jsonResponse = new JsonResponse<Map<String, Object>>();
		if (prdIds != null) {
			String[] propertyIds = new String[prdIds.length];
			for (int i = 0; i < propertyIds.length; i++) {
				propertyIds[i] = Consts.PRD_TOTAL_STOCK_PREFIX + prdIds[i];
			}
			jsonResponse.setResult(commonJedis.getObjects(propertyIds));
		}
		return jsonResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wanjia.dsi.product.service.StockService#getStockPrefix()
	 */
	@Deprecated
	@Override
	public String getStockPrefix() {
		return commonJedis.getRedisPrefix() + Consts.PRD_STOCK_PREFIX;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wanjia.dsi.product.service.StockService#getStockNumberPrefix()
	 */
	@Deprecated
	@Override
	public String getStockNumberPrefix() {
		return commonJedis.getRedisPrefix() + Consts.PRD_TOTAL_STOCK_PREFIX;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#getStockNumber(java.lang.
	 * String[])
	 */
	@Deprecated
	@Override
	public JsonResponse<Integer> getStockNumber(String prdId) {
		JsonResponse<Integer> jsonResponse = new JsonResponse<Integer>();
		jsonResponse.setResult((Integer) commonJedis.getObject(Consts.PRD_TOTAL_STOCK_PREFIX + prdId));
		return jsonResponse;
	}

	public static void main(String[] args) {
		Set<String> set = new HashSet<String>();
		set.add("1111");
		set.add("1111");
		for (String str : set) {
			System.out.println(str);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#getStockOnlineUsed(java.lang.
	 * String[])
	 */
	@Override
	public JsonResponse<Map<String, Integer>> getStockUsedNumber(String... prdId) {
		JsonResponse<Map<String, Integer>> jsonResponse = new JsonResponse<Map<String, Integer>>();
		if (prdId != null) {
			jsonResponse.setResult(commonJedis.getZsetObjectsWithInt(Consts.PRD_TOTAL_STOCK_ZSET_USED_PREFIX, prdId));
		}
		return jsonResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#getStockTotalNumber(java.lang
	 * .String[])
	 */
	@Override
	public JsonResponse<Map<String, Integer>> getStockTotalNumber(String... prdId) {
		JsonResponse<Map<String, Integer>> jsonResponse = new JsonResponse<Map<String, Integer>>();
		if (prdId != null) {
			jsonResponse.setResult(commonJedis.getZsetObjectsWithInt(Consts.PRD_TOTAL_STOCK_ZSET_PREFIX, prdId));
		}
		return jsonResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wanjia.dsi.product.service.StockService#useStock(java.lang.String)
	 */
	@Override
	public JsonResponse<Map<String, String>> getFreeStock(String prdId, int count) {
		JsonResponse<Map<String, String>> jsonResponse = new JsonResponse<Map<String, String>>();
		Map<String, String> stocks = new HashMap<String, String>();
		for (int i = 0; i < count; i++) {
			Map<String, String> rs = commonJedis.getHashObject(Consts.PRD_STOCK_UNUSED_PREFIX + prdId);
			// 获取库存ID并从未消耗库存中减去这个库存
			Map<String, String> stock = commonJedis.getRemHashField(Consts.PRD_STOCK_UNUSED_PREFIX + prdId);
			stocks.putAll(stock);
			// 更新未消耗库存总数
			commonJedis.putZsetObject(Consts.PRD_TOTAL_STOCK_ZSET_UNUSED_PREFIX,
					new Double(commonJedis.getHashObject(Consts.PRD_STOCK_UNUSED_PREFIX + prdId).size()), prdId);
		}
		jsonResponse.setResult(stocks);
		return jsonResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.wanjia.dsi.product.service.StockService#restoreStock(java.lang.
	 * String, java.util.Map)
	 */
	@Override
	public void restoreStock(String prdId, Map<String, String> stocks) {
		commonJedis.putHashMapObjects(Consts.PRD_STOCK_UNUSED_PREFIX + prdId, stocks);
	}

}
