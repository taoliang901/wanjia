package com.wanjia.dsi.product.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.rpc.RpcException;
import com.github.pagehelper.PageInfo;
import com.pinganwj.clinic.api.ProductApptApi;
import com.pinganwj.clinic.api.domain.appt.product.GetHealthProductItemUseTimesRsp;
import com.pinganwj.clinic.api.domain.appt.product.HealthProductItemUseTimes;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.product.dao.mapper.PrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.PrdServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOAddressInfoApprovalMapper;
import com.wanjia.dsi.product.dao.mapper.VOMyProductDetailMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdClinicMapper;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.PrdKucunExample;
import com.wanjia.dsi.product.model.PrdService;
import com.wanjia.dsi.product.model.PrdServiceExample;
import com.wanjia.dsi.product.model.VOMyProductDetail;
import com.wanjia.dsi.product.model.VOPrdOrderDetailService;
import com.wanjia.dsi.product.service.MyProductDetailService;
import com.wanjia.dsi.product.vo.VOAddressInfoApproval;
import com.wanjia.dsi.web.clinic.dao.mapper.ClinicHeadquartersMapper;
import com.wanjia.dsi.web.clinic.model.ClinicHeadquarters;
import com.wanjia.dsi.web.dictionary.model.Dictionary;
import com.wanjia.dsi.web.dictionary.service.DictionaryService;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyClinicInfoMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyClinicRegisterMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.HyTreatmentPersonMapper;
import com.wanjia.dsi.web.hyPerson.dao.mapper.SysAreaCityMapper;
import com.wanjia.dsi.web.hyPerson.model.HyClinicInfo;
import com.wanjia.dsi.web.hyPerson.model.HyClinicRegister;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;
import com.wanjia.dsi.web.hyPerson.model.SysAreaCity;
import com.wanjia.dsi.web.hyPerson.model.SysAreaCityExample;

@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class MyProductDetailServiceImpl extends BaseServiceImpl implements MyProductDetailService {

	@Autowired
	private VOMyProductDetailMapper voMyProductDetailMapper;
	@Autowired
	private VOAddressInfoApprovalMapper voAddressInfoApprovalMapper;
	@Autowired
	SysAreaCityMapper sysAreaCityMapper;
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private ProductApptApi productApptApi;

	// 库存查询接口（自动生成）
	@Autowired
	private PrdKucunMapper prdKucunMapper;
	
	// 就诊人查询接口（自动生成）
	@Autowired
	private HyTreatmentPersonMapper personMapper;
	
	@Autowired
	private DictionaryService dictionaryService;
	
	// 产品信息接口（自动生成）
	@Autowired
	private HyClinicInfoMapper clinicInfoMapper;
	
	// 产品订单服务接口（自动生成）
	@Autowired
	private PrdServiceMapper prdServiceMapper;
	
	// 产品注册信息接口（自动生成）
	@Autowired
	private HyClinicRegisterMapper clinicRegisterMapper;
	
	// 查询产品诊所
	@Resource
	private VOPrdClinicMapper vOPrdClinicMapper;
	
	@Autowired
	private ClinicHeadquartersMapper clinicHeadquartersMapper;

	
	@Override
	public JsonResponse<PageInfo<VOMyProductDetail>> getMyProductList(String userId, String prdType,
			String provinceCode, String cityCode, String prdStatus, String pageNo, String pageSize) {
		JsonResponse<PageInfo<VOMyProductDetail>> response = new JsonResponse<PageInfo<VOMyProductDetail>>();
		//PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));
		VOMyProductDetail voMyProductDetai = new VOMyProductDetail();
		voMyProductDetai.setUserId(userId);
		if (StringUtils.isNotEmpty(provinceCode)) {
			voMyProductDetai.setProvince(provinceCode);
		}
		if (StringUtils.isNotEmpty(cityCode)) {
			voMyProductDetai.setCity(cityCode);
		}
		if (StringUtils.isNotEmpty(prdType)) {
			voMyProductDetai.setPrdTypeName(prdType);
		}
		List<VOMyProductDetail> detailList = voMyProductDetailMapper.getMyProductList(voMyProductDetai);
		logger.info("detailList-----" + detailList);
		// 如果为空。或者没有查到数据。直接返回即可
		if (detailList == null || detailList.size() == 0) {
			return response;
		}
		List<String> cardIds = new ArrayList<String>();
		// 获取数据后，调用预约接口，合并处理数据
		for (VOMyProductDetail detail : detailList) {
			// 把所有库存id放入列表中
			cardIds.add(detail.getKucunId());
		}
		
		try {
			//更新订单状态
			getProductState(detailList,cardIds);
		} catch (RpcException rpc) {
			logger.error("MyProductDetailServiceImpl---getHealthProductItemUseTimes", rpc);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("MyProductDetailServiceImpl---getHealthProductItemUseTimes", e);
		}
		
		// 设置有效时间（已使用：剩余天数。其他：有效期区间）
		for (VOMyProductDetail detail : detailList) {
			//通过有效时间和获得有效起始时间和有效期
			getValidDateForList(detail);
		}
				
		List<VOMyProductDetail> list = new ArrayList<VOMyProductDetail>();
		PageInfo<VOMyProductDetail> page = new PageInfo<VOMyProductDetail>(detailList);// 获得分页信息
		int pageNum = Integer.parseInt(pageNo);
		int size = Integer.parseInt(pageSize);
		page.setPageNum(pageNum);
		List<VOMyProductDetail> result = new ArrayList<VOMyProductDetail>();
		logger.info("detaillist-----"+detailList);
		if (StringUtils.isNotEmpty(prdStatus)) {
			for (VOMyProductDetail detail : detailList) {
				// 产品类型不为空，
				if (prdStatus.equals(detail.getProductState())) {
					list.add(detail);
				}
			}
			if((pageNum-1)*size<list.size()){
				int begin=(pageNum - 1) * size;
				int end=(pageNum * size) > list.size() ? list.size():(pageNum * size);
				logger.info("begin:"+begin);
				logger.info("end:"+end);
				for(int i=begin;i<end;i++){
					result.add(list.get(i));
				}
				page.setList(result);
			}else{
				page.setList(null);
			}
			logger.info("prdStatus result"+result);
			page.setPages(list.size() % size == 0 ? list.size() / size : list.size() / size + 1);
			page.setTotal(list.size());
		} else {
			if((pageNum-1)*size<detailList.size()){
				int begin=(pageNum - 1) * size;
				int end=(pageNum * size) > detailList.size() ? detailList.size():(pageNum * size);
				logger.info("begin:"+begin);
				logger.info("end:"+end);
				for(int i=begin;i<end;i++){
					result.add(detailList.get(i));
				}
				page.setList(result);
			}else{
				page.setList(null);
			}
			logger.info("prdtype citycode result"+result);
			page.setPages(detailList.size() % size == 0 ? detailList.size() / size : detailList.size() / size + 1);
			page.setTotal(detailList.size());
		}
		response.setResult(page);
		return response;
	}

	@Override
	public JsonResponse<VOMyProductDetail> findMyPrdOrderDetail(String prdId, String userId, String kucunId,
			String orderDetaiId) {
		JsonResponse<VOMyProductDetail> result = new JsonResponse<VOMyProductDetail>();
		
		// 设置参数
		VOMyProductDetail voMyProductDetail = new VOMyProductDetail();
		voMyProductDetail.setUserId(userId);
		voMyProductDetail.setKucunId(kucunId);
		if (StringUtils.isNotEmpty(prdId)) {
			voMyProductDetail.setPrdId(prdId);
		}
		if (StringUtils.isNotEmpty(orderDetaiId)) {
			voMyProductDetail.setId(orderDetaiId);
		}
		
		// 查询产品详情
		VOMyProductDetail myProductDetail = voMyProductDetailMapper.findMyPrdOrderDetail(voMyProductDetail);
		if(myProductDetail == null){
			return result;
		}
		
		// 查询产品服务城市
		VOAddressInfoApproval voAddressInfoApproval = new VOAddressInfoApproval();
		voAddressInfoApproval.setPrdId(myProductDetail.getPrdId());
		StringBuffer  citySB = new StringBuffer();
		StringBuffer provinceSB = new StringBuffer();
		String fwCity = "";
		List<VOAddressInfoApproval> voAddressInfoApprovalList = voAddressInfoApprovalMapper.selectByPrdId(voAddressInfoApproval);
		for(VOAddressInfoApproval vo: voAddressInfoApprovalList){
			provinceSB.append(vo.getProvince()).append("、");
			citySB.append(vo.getCity()).append("、");
		}
		fwCity = citySB.toString();
		
		if(citySB == null || "".equals(citySB)){
			fwCity = provinceSB.toString();
		}
		if(fwCity != null){
			fwCity = fwCity.substring(0,fwCity.length() -1);	
		}else{
			fwCity = fwCity.replaceAll("市", "");
		}
		myProductDetail.setCity(fwCity);
		
		// 设置产品图片
		int len = 5;// 存放图片张数
		String photo = myProductDetail.getPrdPhoto();
		String[] photemp = photo.split("@");
		if (photemp.length < 5 && photemp.length > 0) {
			len = photemp.length;
		}
		String[] pho = new String[len];
		for (int k = 0; k < len; k++) {
			pho[k] = photemp[k];
		}
		myProductDetail.setPrdPhotos(pho);
		
		// 设置有效期限
		getValidDate(myProductDetail);
		
		// 打印服务项目数量日志
		List<VOPrdOrderDetailService> serviceList = myProductDetail.getVoPrdOrderDetailServiceList();
		logger.info("serviceList" + serviceList.size());
		
		// 设置产品订单状态
		List<String> cardIds = new ArrayList<String>();
		cardIds.add(myProductDetail.getKucunId());
		try {
			List<VOMyProductDetail> detailList = new ArrayList<VOMyProductDetail>();
			detailList.add(myProductDetail);
			//更新订单状态
			getProductState(detailList,cardIds);
		} catch (RpcException rpc) {
			logger.error("MyProductDetailServiceImpl---getHealthProductItemUseTimes", rpc);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("MyProductDetailServiceImpl---getHealthProductItemUseTimes", e);
		}
		
		// 设置产品已预约人数（已使用的库存数）
		PrdKucunExample kucunExample = new PrdKucunExample();
		PrdKucunExample.Criteria kucunCriteria = kucunExample.createCriteria();
		kucunCriteria.andCouponIdEqualTo(myProductDetail.getPrdId());
		kucunCriteria.andDelFlagEqualTo("0");
		kucunCriteria.andBuyerUserIdIsNotNull();
		kucunCriteria.andStatusEqualTo("1");
		List<PrdKucun> prdKucunList = prdKucunMapper.selectByExample(kucunExample);
		myProductDetail.setOrderNumber(prdKucunList.size());
		
		PrdKucun prdKucun = prdKucunMapper.selectByPrimaryKey(myProductDetail.getKucunId());
		// 设置激活时候的就诊人信息
		if(StringUtils.isNotBlank(prdKucun.getVisitId())){
			HyTreatmentPerson hyTreatmentPerson = personMapper.selectByPrimaryKey(prdKucun.getVisitId());
//			if(hyTreatmentPerson!=null&&StringUtils.isNotBlank(hyTreatmentPerson.getVisitIdCardTypeCode())){
//				String visitIdCardType = convertVisitIdCardTypeCode(hyTreatmentPerson.getVisitIdCardTypeCode());
//				if(StringUtils.isNotBlank(visitIdCardType)){
//					hyTreatmentPerson.setVisitIdCardTypeCode(visitIdCardType);
//				}
//			}
			myProductDetail.setHyTreatmentPerson(hyTreatmentPerson);
			//就诊人信息不为空的话查询绑定的诊所
		}
		if(StringUtils.isNotBlank(kucunId)&&StringUtils.isNotBlank(userId)&&StringUtils.isNotBlank(prdId)){
			myProductDetail.setBindClinic(findBindClinic(prdId, kucunId, userId));
		}
		//设置保单号信息，卡号信息
		myProductDetail.setAllCardNo(prdKucun.getAllCardNo());
		myProductDetail.setPolicyNo(prdKucun.getPolicyNo());
		myProductDetail.setInsuranceCompany(prdKucun.getInsuranceCompany());
		
		
		
		result.setResult(myProductDetail);
		result.setStatus(Status.SUCCESS);
		return result;
	}

	
	@Override
	public JsonResponse<List<VOMyProductDetail>> getMyProductInfoByUserId(String userId, String prdId) {
		JsonResponse<List<VOMyProductDetail>> resp = new JsonResponse<List<VOMyProductDetail>>();
		VOMyProductDetail voMyProductDetai = new VOMyProductDetail();
		voMyProductDetai.setUserId(userId);
		voMyProductDetai.setPrdId(prdId);
		List<VOMyProductDetail> list = voMyProductDetailMapper.getMyProductList(voMyProductDetai);
		resp.setResult(list);
		return resp;
	}

	@Override
	public String findProvinceCityByCode(List<String> cityCodeList,String separator) {
		StringBuffer sb = new StringBuffer();
		String result = "";
		SysAreaCityExample sace = new SysAreaCityExample();
		SysAreaCityExample.Criteria cri = sace.createCriteria();
		cri.andAreaIdIn(cityCodeList);
		List<SysAreaCity> sysAreaCityList = sysAreaCityMapper.selectByExample(sace);
		if(null == sysAreaCityList){
			return result;
		}
		for(SysAreaCity sysAreaCity : sysAreaCityList ){
			sb.append(sysAreaCity.getName()).append(separator);
		}
		result = sb.toString();
		if(null != result && !"".equals(result)){
			result = result.substring(0,result.length() -1);
		}
		return result;
	}

	/**
	 * 通过有效时间和获得有效起始时间和有效期
	 * @param detail 订单明细
	 */
	public void getValidDateForList(VOMyProductDetail detail) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd");
		if(detail.getValidBeginDate()!=null){
			String format1 = simpleDateFormat.format(detail.getValidBeginDate());
			String format2 = simpleDateFormat.format(detail.getValidEndDate());
			if(null!=format1&&null!=format1){
				if("已使用".equals(detail.getProductState())){
					long intervalMilli = detail.getValidEndDate().getTime() - new Date().getTime();
					if(intervalMilli > 24 * 60 * 60 * 1000){
						detail.setAvailableTime("剩余时间："+(int) (intervalMilli / (24 * 60 * 60 * 1000)) + "天");
					}else{
						detail.setAvailableTime("剩余时间："+(int) (intervalMilli / (60 * 60 * 1000)) + "小时");
					}
				}else{
					detail.setAvailableTime(format1 + "-" + format2);
				}
			}
		}
	}
	
	/**
	 * 通过有效时间和获得有效起始时间和有效期
	 * @param detail 订单明细
	 */
	public void getValidDate(VOMyProductDetail detail) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd");
		if(detail.getValidBeginDate()!=null){
			String format1 = simpleDateFormat.format(detail.getValidBeginDate());
			String format2 = simpleDateFormat.format(detail.getValidEndDate());
			detail.setAvailableTime(format1 + "-" + format2);
		}else{
			if("0".equals(detail.getValidValueUnit())){
				detail.setAvailableTime("自卡激活起"+detail.getValidValue()+"年");
			}else if("1".equals(detail.getValidValueUnit())){
				detail.setAvailableTime("自卡激活起"+detail.getValidValue()+"月");
			}else if("2".equals(detail.getValidValueUnit())){
				detail.setAvailableTime("自卡激活起"+detail.getValidValue()+"日");
			}else if("3".equals(detail.getValidValueUnit())){
				detail.setAvailableTime("自卡激活起"+detail.getValidValue()+"时");
			}
			
		}
	}
	
	/**
	 * 调用预约接口，获得产品状态
	 * @param detailList 订单列表
	 * @param cardIds 卡id列表
	 */
	public void getProductState(List<VOMyProductDetail> detailList, List<String> cardIds) {
		if (null != detailList && null != cardIds) {
			// 调用深圳接口获取产品使用次数
			com.pinganwj.clinic.api.domain.JsonResponse<GetHealthProductItemUseTimesRsp> jr = new com.pinganwj.clinic.api.domain.JsonResponse<GetHealthProductItemUseTimesRsp>();
			jr = productApptApi.getHealthProductItemUseTimes(cardIds);
			if (null != jr && null != jr.getResult() && null != jr.getResult().getHealthProductItemUseTimesMap()) {
				// 判断每一个产品详情的状态
				for (VOMyProductDetail detail : detailList) {
					// 取出商品对应的服务使用次数的list
					List<HealthProductItemUseTimes> list = jr.getResult().getHealthProductItemUseTimesMap()
							.get(detail.getKucunId());
					// 如果list为空，说明没有该产品的预约记录。
					List<VOPrdOrderDetailService> serviceList = detail.getVoPrdOrderDetailServiceList();
					logger.info("serviceList:" + serviceList);
					logger.info("深圳接口返回的serviceList:" + list);
					//一次性产品
					if ("0".equals(detail.getUseFrequence())) {
						if (null == list || list.size() == 0) {
							Date dt = new Date();
							if (detail.getValidEndDate() != null && dt.after(getAfterDate(detail.getValidEndDate()))) {
								detail.setProductState("已过期");
							} else {
								if ("1".equals(detail.getOnlineFlag()) || "0".equals(detail.getDistributeType())) {//ONLINE_FLAG = 1 or distribute_type = 0 
									getSupportBuyOnlineState(detail);  
								} else {
									detail.setProductState("未使用");
								}
							}
						} else if (null != list) {
							Date dt = new Date();
							if (detail.getValidEndDate() != null && dt.after(getAfterDate(detail.getValidEndDate()))) {
								detail.setProductState("已过期");
							} else {
								// 判断第一个服务项目是
								logger.info(list.get(0).getHealthProductItemId() + "使用次数:" + list.get(0).getTimes());
								if (0 == list.get(0).getTimes()) {
									detail.setProductState("未使用");
								} else {
									detail.setProductState("使用完毕");
								}
							}
						}
						if ("未使用".equals(detail.getProductState()) || "已使用".equals(detail.getProductState())) {
							detail.setAppointment("是");
						}
					}else{
						//非一次性产品
						//获得我的产品状态
						getProductStateMx(detail,serviceList,list);
					}
					System.out.println(detail.getProductState());
				}
			}
		}
	}
	/**
	 * 获得我的产品状态
	 * @param detail
	 * @param serviceList
	 * @param list
	 */
public void getProductStateMx(VOMyProductDetail detail,List<VOPrdOrderDetailService> serviceList,List<HealthProductItemUseTimes> list){
	if (null != serviceList) {
		if (null != list) {
			for (VOPrdOrderDetailService service : serviceList) {
				for (HealthProductItemUseTimes h : list) {
					if (h.getHealthProductItemId().equals(service.getServiceId())) {
						// 设置已经使用的次数，前台进行相减计算即可
						service.setUsedCount(h.getTimes());
					}
				}
			}
			// 判断产品是否全部用完，只要有一个不是eque就是false，无限次肯定和有限次不可能equal
			boolean flag = false;
			// 判断用户是否使用过
			boolean isUserFlag = false;
			for (VOPrdOrderDetailService service : serviceList) {
				if (service.getServiceCount() != null) {
					if (!service.getServiceCount().equals(String.valueOf(service.getUsedCount()))) {
						flag = true;
						break;
					}
				} else {
					flag = true;
					break;
				}
			}
			logger.info("isUserFlag:" + isUserFlag);
			for (VOPrdOrderDetailService service : serviceList) {
				logger.info("usedCount:" + service.getUsedCount());
				if (service.getUsedCount() != 0) {
					isUserFlag = true;
				}
			}
			logger.info("isUserFlag:" + isUserFlag);
			logger.info("detail.getValidEndDate():" + detail.getValidEndDate());
			logger.info("detail.getValidEndDate():" + detail.getValidEndDate());
			// 获得当前时间
			Date dt = new Date();
			// 只要预约后就说明已经使用，userid就不为空
			// isUserFlag：是否使用过
			// flag:是否全部使用完，true:没有使用完，false：使用完
			
			// 未使用， 产品没有过期
			if (isUserFlag == false && (detail.getValidEndDate() == null || dt.before(getAfterDate(detail.getValidEndDate())))) {
				detail.setProductState("未使用");
			// 已使用， 产品没有过期，没有使用完
			} else if (flag == true && dt.before(getAfterDate(detail.getValidEndDate()))) {
				detail.setProductState("已使用");
			// 已使用， 产品没有过期，使用完了
			} else if (flag == false && dt.before(getAfterDate(detail.getValidEndDate()))) {
				detail.setProductState("使用完毕");
			// 过期
			} else {
				detail.setProductState("已过期");
			}
			logger.info("isUserFlag : " + isUserFlag);
			logger.info("flag : " + flag);
			logger.info(detail.getId() + ":" + detail.getProductState());
		} else {
			Date dt = new Date();
			if(detail.getValidEndDate() != null && dt.after(getAfterDate(detail.getValidEndDate()))){
				detail.setProductState("已过期");
			}else{
				if ("1".equals(detail.getOnlineFlag()) || "0".equals(detail.getDistributeType())) {// 
					getSupportBuyOnlineState(detail);
				} else {
					detail.setProductState("未使用");
				}
			}
		}
	} else {
		Date dt = new Date();
		if(detail.getValidEndDate() != null && dt.after(getAfterDate(detail.getValidEndDate()))){
			detail.setProductState("已过期");
		}else{
			if ("0".equals(detail.getIsSupportBuyOnline())) {// 是否支持在线购买（0是，1否）
				getSupportBuyOnlineState(detail);
			} else {
				detail.setProductState("未使用");
			}
		}
	}
	if ("未使用".equals(detail.getProductState()) || "已使用".equals(detail.getProductState())) {
		detail.setAppointment("是");
	}
}

/**
 * 获得未领取和未激活状态
 * @param detail
 */
	public void getSupportBuyOnlineState(VOMyProductDetail detail) {
		if ("0".equals(detail.getIsSupportReceiveFree())) {// 是否支持免费领取（0是，1否）
			if ("0".equals(detail.getTakenStatus())) {// 领取状态(0:未领取;1.已领取)(只用于线上会员购买领取类型产品,且库存为线上库存)
				detail.setProductState("未领取");
			}
			if ("0".equals(detail.getIsValidFrom())) { // 自激活起 0-是 1-否
				if (detail.getValidBeginDate() == null) {
					detail.setProductState("未激活");
				}
			}
		}else{
			detail.setProductState("未使用");
		}
	}
	/**
	 * 获取后一天
	 * @param date
	 * @return
	 */
	public Date getAfterDate(Date date){
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE,1);
		date =cal.getTime();
		return  date;
	}
	
	private String convertVisitIdCardTypeCode(String visitIdCardTypeCode){
		if(StringUtils.isBlank(visitIdCardTypeCode)){
			return null;
		}
		Dictionary model = new Dictionary();
		model.setDictCode("PRD_CARD_TYPE");
		List<Dictionary> list = new ArrayList<Dictionary>();
		try {
			 list = dictionaryService.findByEntity(model);
		} catch (Exception e) {
			logger.info("查询就诊人证件类型失败");
		}
		if(list!=null){
			for (Dictionary dictionary : list) {
				if(visitIdCardTypeCode.equals(dictionary.getDictKey())){
					return dictionary.getDictDescription();
				}
			}
		}
		return null;
	}
	private String findBindClinic(String couponId,String kucunId,String userId){
		PrdServiceExample prdExample = new PrdServiceExample();
		PrdServiceExample.Criteria prdCriteria = prdExample.createCriteria();
		prdCriteria.andPrdIdEqualTo(couponId);
		prdCriteria.andIsBandClinicEqualTo("0");
		prdCriteria.andDelFlagEqualTo(0);
		List<PrdService> prdServiceList = prdServiceMapper.selectByExample(prdExample);
		// 为绑定诊所的服务项目
		if(CollectionUtils.isNotEmpty(prdServiceList))
		{
			List<String> healthProductItemIds = new ArrayList<String>();
			for(PrdService item : prdServiceList){
				healthProductItemIds.add(item.getServiceId());
			}
			// 调用深圳接口查询该服务已提交预约的诊所ID
			com.pinganwj.clinic.api.domain.JsonResponse<List<String>> clinicIdResult = productApptApi.getClinicIds(kucunId, userId, healthProductItemIds, "1,2,3,4,5,8,9",null);
			List<String> clinicIds = clinicIdResult.getResult();
			if(CollectionUtils.isNotEmpty(clinicIds))
			{
				String clinicId = clinicIds.get(0);
				//判断诊所为单体诊所还是连锁诊所
				HyClinicInfo hyClinicInfo = clinicInfoMapper.selectByPrimaryKey(clinicId);
				if(hyClinicInfo!=null){
					HyClinicRegister register = clinicRegisterMapper.selectByPrimaryKey(hyClinicInfo.getClinicRegisterId());
					String parentId = register.getParentAccountId();
					// 为单体诊所
					if(StringUtils.isBlank(parentId)){
						return hyClinicInfo.getClinicName();
					// 为连锁诊所
					}else{
						if(StringUtils.isNotBlank(register.getParentAccountId())){
							ClinicHeadquarters entity = new ClinicHeadquarters();
							entity.setClinicRegisterId(register.getParentAccountId());
							List<ClinicHeadquarters> list = clinicHeadquartersMapper.findByEntity(entity );
							if(list!=null&&null!=list.get(0)){
								return list.get(0).getEnterpriseFullName();
							}
						}
					}
				}
			}
		}
		return null;
	}

}
