package com.wanjia.dsi.web.coupon.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.web.coupon.dao.mapper.PrdFinSettlementLogMapper;
import com.wanjia.dsi.web.coupon.model.PrdFinSettlementLog;
import com.wanjia.dsi.web.coupon.service.PrdFinSettlementLogService;

/**
 * This element is automatically generated on 16-11-19 ����7:42, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
public class PrdFinSettlementLogServiceImpl implements PrdFinSettlementLogService {
    @Autowired
    private PrdFinSettlementLogMapper prdFinSettlementLogMapper;

    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlementLog findById(String id) {
        return (PrdFinSettlementLog)prdFinSettlementLogMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementLog> findWithPagination(int offset, int count) {
        return (List<PrdFinSettlementLog>)prdFinSettlementLogMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementLog> findAll() {
        return (List<PrdFinSettlementLog>)prdFinSettlementLogMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementLog> findByEntity(PrdFinSettlementLog model) {
        return (List<PrdFinSettlementLog>)prdFinSettlementLogMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementLog> findByEntityWithPagination(PrdFinSettlementLog model, int offset, int count) {
        return (List<PrdFinSettlementLog>)prdFinSettlementLogMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlementLog findOneByEntity(PrdFinSettlementLog model) {
        return (PrdFinSettlementLog)prdFinSettlementLogMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementLog> findByProperty(String propertyName, String propertyValue) {
        return (List<PrdFinSettlementLog>)prdFinSettlementLogMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public PrdFinSettlementLog findOneByProperty(String propertyName, String propertyValue) {
        return (PrdFinSettlementLog)prdFinSettlementLogMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementLog> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<PrdFinSettlementLog>)prdFinSettlementLogMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<PrdFinSettlementLog> findByProperties(Map<String, Object> map) {
        return (List<PrdFinSettlementLog>)prdFinSettlementLogMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(PrdFinSettlementLog model) {
        return (long)prdFinSettlementLogMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)prdFinSettlementLogMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)prdFinSettlementLogMapper.countByProperties(map);
    }

    @Override
    public void update(PrdFinSettlementLog model) {
        prdFinSettlementLogMapper.update(model);
    }

    @Override
    public void insert(PrdFinSettlementLog model) {
        prdFinSettlementLogMapper.insert(model);
    }

    @Override
    public void deleteByEntity(PrdFinSettlementLog model) {
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        prdFinSettlementLogMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.prdFinSettlementLogMapper.countAll();
    }

    public void insertBatch(List<PrdFinSettlementLog> list) {
        this.prdFinSettlementLogMapper.insertBatch(list);
    }

    public void delete(String id) {
        PrdFinSettlementLog model = new PrdFinSettlementLog();
        model.setId(id);
        this.prdFinSettlementLogMapper.update(model);
    }

	@Override
	public List<PrdFinSettlementLog> queryLog(Map<String, Object> map) {
		return null;
	}
}