package com.wanjia.dsi.web.cms.department.service.impl;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.clinic.model.ClinicInfo;
import com.wanjia.dsi.web.cms.common.entity.ClinicDepartment;
import com.wanjia.dsi.web.cms.common.entity.ClinicDepartmentTree;
import com.wanjia.dsi.web.cms.common.entity.EasyUITreeDataModelBase;
import com.wanjia.dsi.web.cms.common.util.EasyUITreeUtils;
import com.wanjia.dsi.web.cms.department.dao.mapper.CmsDepartmentCriteriaMapper;
import com.wanjia.dsi.web.cms.department.model.CmsDepartmentCriteria;
import com.wanjia.dsi.web.cms.department.service.CmsDepartmentCriteriaService;
import com.wanjia.dsi.web.cms.disease.dao.mapper.CmsDiseaseCriteriaMapper;
import com.wanjia.dsi.web.cms.disease.model.CmsDiseaseCriteria;
import com.wanjia.dsi.web.department.model.Department;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-3-9 下午1:45, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CmsDepartmentCriteriaServiceImpl implements CmsDepartmentCriteriaService {
	@Autowired
	private CmsDepartmentCriteriaMapper cmsDepartmentCriteriaMapper;

	@Autowired
	private CmsDiseaseCriteriaMapper cmsDiseaseCriteriaMapper;
	
	
	@Value("#{jedisConfig['expirationTime']}")
	private int expirationTime;
	
	@Autowired
	private CommonJedis commonJedis;
	
	

	@Override
	public CmsDepartmentCriteria findById(Long id) {
		return (CmsDepartmentCriteria) cmsDepartmentCriteriaMapper.findById(id);
	}

	@Override
	public List<CmsDepartmentCriteria> findWithPagination(int offset, int count) {
		return (List<CmsDepartmentCriteria>) cmsDepartmentCriteriaMapper.findWithPagination(offset, count);
	}

	@Override
	public List<CmsDepartmentCriteria> findAll() {
		return (List<CmsDepartmentCriteria>) cmsDepartmentCriteriaMapper.findAll();
	}

	@Override
	public List<CmsDepartmentCriteria> findByEntity(CmsDepartmentCriteria model) {
		return (List<CmsDepartmentCriteria>) cmsDepartmentCriteriaMapper.findByEntity(model);
	}

	@Override
	public List<CmsDepartmentCriteria> findByEntityWithPagination(CmsDepartmentCriteria model, int offset, int count) {
		return (List<CmsDepartmentCriteria>) cmsDepartmentCriteriaMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	public CmsDepartmentCriteria findOneByEntity(CmsDepartmentCriteria model) {
		return (CmsDepartmentCriteria) cmsDepartmentCriteriaMapper.findOneByEntity(model);
	}

	@Override
	public List<CmsDepartmentCriteria> findByProperty(String propertyName, String propertyValue) {
		return (List<CmsDepartmentCriteria>) cmsDepartmentCriteriaMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	public CmsDepartmentCriteria findOneByProperty(String propertyName, String propertyValue) {
		return (CmsDepartmentCriteria) cmsDepartmentCriteriaMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	public List<CmsDepartmentCriteria> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
		return (List<CmsDepartmentCriteria>) cmsDepartmentCriteriaMapper.findByPropertyWithPagination(propertyName, propertyValue, offset, count);
	}

	@Override
	public List<CmsDepartmentCriteria> findByProperties(Map<String, Object> map) {
		return (List<CmsDepartmentCriteria>) cmsDepartmentCriteriaMapper.findByProperties(map);
	}

	@Override
	public long countByEntity(CmsDepartmentCriteria model) {
		return (long) cmsDepartmentCriteriaMapper.countByEntity(model);
	}

	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		return (long) cmsDepartmentCriteriaMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	public long countByProperties(Map<String, Object> map) {
		return (long) cmsDepartmentCriteriaMapper.countByProperties(map);
	}

	@Override
	public void update(CmsDepartmentCriteria model) {
		cmsDepartmentCriteriaMapper.update(model);
	}

	@Override
	public void insert(CmsDepartmentCriteria model) {
		cmsDepartmentCriteriaMapper.insert(model);
	}

	@Override
	public void deleteByEntity(CmsDepartmentCriteria model) {
		cmsDepartmentCriteriaMapper.deleteByEntity(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		cmsDepartmentCriteriaMapper.deleteByProperty(propertyName, propertyValue);
	}

	public long countAll() {
		return this.cmsDepartmentCriteriaMapper.countAll();
	}

	public void insertBatch(List<CmsDepartmentCriteria> list) {
		this.cmsDepartmentCriteriaMapper.insertBatch(list);
	}

	public void delete(Long id) {
		this.cmsDepartmentCriteriaMapper.deleteById(id);
	}

	@Override
	public JsonResponse<List<EasyUITreeDataModelBase<ClinicDepartment>>> listInHomepage() {
		// TODO Auto-generated method stub
		JsonResponse<List<EasyUITreeDataModelBase<ClinicDepartment>>> result = new JsonResponse<List<EasyUITreeDataModelBase<ClinicDepartment>>>();
		Department department = new Department();
		List<EasyUITreeDataModelBase<ClinicDepartment>> createEsyUITree = new ArrayList<EasyUITreeDataModelBase<ClinicDepartment>>();
		try {
			
			/*if(commonJedis.exists(Consts.LIST_IN_HOME_PAGE)){
				createEsyUITree = (List<EasyUITreeDataModelBase<ClinicDepartment>>)commonJedis.getObject(Consts.LIST_IN_HOME_PAGE);
			}else{
				 createEsyUITree = this.createEsyUITree();
				 commonJedis.addObject(Consts.LIST_IN_HOME_PAGE, createEsyUITree, expirationTime);
			}
			result.setResult(createEsyUITree);*/
			result.setResult(this.createEsyUITree());
		} catch (Exception e) {
			//Log.error(e.getMessage());
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
	
	
	public List<EasyUITreeDataModelBase<ClinicDepartment>> createEsyUITree() {
		CmsDepartmentCriteria criteria = new CmsDepartmentCriteria();
		CmsDiseaseCriteria disCriteria = new CmsDiseaseCriteria();
		criteria.setPublishFlag(1);
		disCriteria.setPublishFlag(1);
		Long publishGroupId = cmsDepartmentCriteriaMapper.findPublishGroupId(criteria);
		if (null == publishGroupId) {
			criteria.setPublishFlag(1);
			disCriteria.setPublishFlag(1);
			publishGroupId = cmsDepartmentCriteriaMapper.findPublishGroupId(criteria);
		}
		criteria.setPublishGroupId(publishGroupId);
		disCriteria.setPublishGroupId(publishGroupId);

		List<CmsDepartmentCriteria> dptList = cmsDepartmentCriteriaMapper.selectBySelective(criteria);
		List<CmsDiseaseCriteria> disList = cmsDiseaseCriteriaMapper.selectBySelective(disCriteria);

		List<ClinicDepartmentTree> dtpTree = findCmsToClinicDepartmentTree(dptList, disList);
		// =
		List<EasyUITreeDataModelBase<ClinicDepartment>>  createCmsDptEasyUITree = EasyUITreeUtils.createCmsDptEasyUITree("root", "诊疗类别", dtpTree);

		return createCmsDptEasyUITree;
	}
	

	private List<ClinicDepartmentTree> findCmsToClinicDepartmentTree(List<CmsDepartmentCriteria> dptList, List<CmsDiseaseCriteria> disList) {

		List<ClinicDepartmentTree> treeList = new ArrayList<ClinicDepartmentTree>();
		// 一级类目
		for (Iterator<CmsDepartmentCriteria> it = dptList.iterator(); it.hasNext();) {
			CmsDepartmentCriteria department = it.next();
			if (Consts.DPT_ROOT.equals(department.getParentId())) {
				ClinicDepartmentTree dpt = new ClinicDepartmentTree();
				BeanUtils.copyProperties(department, dpt);
				treeList.add(dpt);
			}
		}
		// 二级类目筛选
		for (Iterator<ClinicDepartmentTree> treeIt = treeList.iterator(); treeIt.hasNext();) {
			ClinicDepartmentTree dptTree = treeIt.next();
			List<ClinicDepartmentTree> subitemList = new ArrayList<ClinicDepartmentTree>();
			for (Iterator<CmsDepartmentCriteria> it = dptList.iterator(); it.hasNext();) {
				CmsDepartmentCriteria department = it.next();
				if (!Consts.DPT_ROOT.equals(department.getParentId()) && dptTree.getDepartmentId().equals(department.getParentId())) {
					ClinicDepartmentTree dpt = new ClinicDepartmentTree();
					BeanUtils.copyProperties(department, dpt);
					subitemList.add(dpt);
				}
			}
			dptTree.setSubitemList(subitemList);
		}
		// 三级类目
		for (Iterator<ClinicDepartmentTree> treeIt = treeList.iterator(); treeIt.hasNext();) {
			ClinicDepartmentTree dptTree = treeIt.next();
			List<ClinicDepartmentTree> subitemList = dptTree.getSubitemList();
			for (Iterator<ClinicDepartmentTree> subitemIt = subitemList.iterator(); subitemIt.hasNext();) {
				ClinicDepartmentTree subitem = subitemIt.next();
				List<ClinicDepartmentTree> dptDiseaseList = new ArrayList<ClinicDepartmentTree>();
				for (Iterator<CmsDiseaseCriteria> it = disList.iterator(); it.hasNext();) {
					CmsDiseaseCriteria dis = it.next();
					if (dis.getDepartmentId().equals(subitem.getDepartmentId())) {
						CmsDepartmentCriteria cmsDpt = dis.transCmsDepartmentField();
						ClinicDepartmentTree clinDpt = new ClinicDepartmentTree();
						BeanUtils.copyProperties(cmsDpt, clinDpt);
						dptDiseaseList.add(clinDpt);
					}
				}
				subitem.setSubitemList(dptDiseaseList);
			}
		}
		return treeList;
	}

	@Override
	public JsonResponse<List<CmsDepartmentCriteria>> getCmsDepartmentByTime(Date beginDate,Date endDate) {
		JsonResponse<List<CmsDepartmentCriteria>> result = new JsonResponse<List<CmsDepartmentCriteria>>();
		Map map = new HashMap<String, Object>();
		map.put("beginDate", beginDate);
		map.put("endDate", endDate);
		try {
			result.setResult(cmsDepartmentCriteriaMapper.getCmsDepartmentByTime(map));
		} catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

}