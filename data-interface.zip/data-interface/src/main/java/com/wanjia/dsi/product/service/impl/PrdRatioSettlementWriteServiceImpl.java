package com.wanjia.dsi.product.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.product.dao.mapper.FrameAgreementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdRatioSettlementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdSubAgreementMapper;
import com.wanjia.dsi.product.model.FrameAgreement;
import com.wanjia.dsi.product.model.PrdRatioSettlement;
import com.wanjia.dsi.product.service.PrdRatioSettlementWriteService;




@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class PrdRatioSettlementWriteServiceImpl implements PrdRatioSettlementWriteService {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private PrdRatioSettlementMapper prdRatioSettlementMapper;

	@Override
	public void insert(PrdRatioSettlement ratio) {
		prdRatioSettlementMapper.insert(ratio);
		
	}

	@Override
	public void update(PrdRatioSettlement ratio) {
		prdRatioSettlementMapper.update(ratio);
		
	}

	@Override
	public void deleteByPrductId(String prdId) {
		prdRatioSettlementMapper.deleteByPrductId(prdId);
		
	}

	
	
}
