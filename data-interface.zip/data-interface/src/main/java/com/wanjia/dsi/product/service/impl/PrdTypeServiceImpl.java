package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.product.dao.mapper.PrdTypeMapper;
import com.wanjia.dsi.product.dao.mapper.PrdTypeVOMapper;
import com.wanjia.dsi.product.model.PrdType;
import com.wanjia.dsi.product.model.PrdTypeVO;
import com.wanjia.dsi.product.model.ProductInfo;
import com.wanjia.dsi.product.service.PrdTypeService;
import com.wanjia.dsi.web.area.dao.mapper.AreaMapper;
import com.wanjia.dsi.web.area.model.Area;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class PrdTypeServiceImpl implements PrdTypeService {

	@Autowired
	private PrdTypeMapper prdTypeMapper;

	@Autowired
	private PrdTypeVOMapper prdTypeVOMapper;

	@Autowired
	private AreaMapper areaMapper;

	private static final Logger logger = LoggerFactory.getLogger(PrdTypeServiceImpl.class);

	@Override
	public JsonResponse<List<PrdType>> getTypeList() {
		JsonResponse<List<PrdType>> jr = new JsonResponse<List<PrdType>>();
		try {
			Map<String, String> map = new HashMap<String, String>();
			List<PrdType> list = prdTypeMapper.getTypeList(map);
			jr.setResult(list);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("PrdTypeServiceImpl --- getTypeList", e);
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}

	@Override
	public JsonResponse<List<PrdType>> getTypeList(String status, String bookingType) {
		JsonResponse<List<PrdType>> jr = new JsonResponse<List<PrdType>>();
		try {

			Map<String, String> map = new HashMap<String, String>();
			if (!StringUtils.isEmpty(status)) {
				map.put("status", status);
			}

			if (!StringUtils.isEmpty(bookingType)) {
				map.put("bookingType", bookingType);
			}

			List<PrdType> list = prdTypeMapper.getTypeList(map);
			jr.setResult(list);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("PrdTypeServiceImpl --- getTypeList", e);
			jr.setStatus(Status.ERROR);
		}

		return jr;
	}

	@Override
	public JsonResponse<List<ProductInfo>> getProductTop3ByTypeName(Map<String, Object> map) {
		JsonResponse<List<ProductInfo>> jr = new JsonResponse<List<ProductInfo>>();
		jr.setStatus(JsonResponse.Status.SUCCESS);

		try {
			List<PrdTypeVO> list = prdTypeVOMapper.getAllTypeIncludeProductTop3(map);
			if (list != null && list.size() > 0) {
				List<ProductInfo> productList = new ArrayList<ProductInfo>();
				for (PrdTypeVO prdTypeVO : list) {
					if (prdTypeVO.getList() != null && prdTypeVO.getList().size() > 0) {
						for (ProductInfo productInfo : prdTypeVO.getList()) {
							// 设置省份和市信息
							productInfo.setProvince(convertProvince(productInfo.getProvince()));
							productInfo.setCity(convertCity(productInfo.getCity()));
							productList.add(productInfo);
						}
					}
				}
				jr.setResult(productList);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(" Call Service PrdTypeServiceImpl failed in getAllTypeIncludeProductTop3", e);
			jr.setStatus(Status.ERROR);
		}

		return jr;
	}

	/**************
	 * 省code转换为名称
	 * 
	 * @param province
	 * @return
	 */
	private String convertProvince(String province) {
		logger.info("~~~~~~~ province ~~~~~~~" + province);
		StringBuilder provinceBuilder = new StringBuilder("");
		List<String> provinceString = new ArrayList<String>();
		if (StringUtils.isNotBlank(province)) {
			String[] split = province.split("\\|");

			for (int i = 0; i < split.length; i++) {
				if (StringUtils.isNotBlank(split[i])) {
					if ("0".equals(split[i])) {
						provinceBuilder.append("全国");
						break;
					} else {
						// 查出所有的省份信息
						provinceString.add(split[i]);
					}
				}
			}
			if (CollectionUtils.isNotEmpty(provinceString)) {
				// id 转成 name
				List<Area> gainAreaList = areaMapper.gainAreaList(provinceString);
				if (CollectionUtils.isNotEmpty(gainAreaList)) {
					for (int i = 0; i < gainAreaList.size(); i++) {
						if (i == gainAreaList.size() - 1) {
							provinceBuilder.append(gainAreaList.get(i).getName());
						} else {
							provinceBuilder.append(gainAreaList.get(i).getName()).append(",");
						}
					}
				}
			}
		}

		return provinceBuilder.toString();
	}

	/**************
	 * 市code转换为名称
	 * 
	 * @param city
	 * @return
	 */
	private String convertCity(String city) {
		logger.info("~~~~~~~ city ~~~~~~~" + city);
		StringBuilder cityBuilder = new StringBuilder("");
		List<String> cityString = new ArrayList<String>();
		if (StringUtils.isNotBlank(city)) {
			String[] split = city.split("\\|");

			for (int i = 0; i < split.length; i++) {
				if (StringUtils.isNotBlank(split[i])) {
					if ("0".equals(split[i])) {
						cityBuilder.append("全国");
						break;
					} else {
						// 查出所有的省份信息
						cityString.add(split[i]);
					}
				}
			}

			if (CollectionUtils.isNotEmpty(cityString)) {
				// 蒋id转换成名字
				List<Area> gainAreaList = areaMapper.gainAreaList(cityString);
				if (CollectionUtils.isNotEmpty(gainAreaList)) {
					// 按照，拼接
					for (int i = 0; i < gainAreaList.size(); i++) {
						if (i == gainAreaList.size() - 1) {
							cityBuilder.append(gainAreaList.get(i).getName());
						} else {
							cityBuilder.append(gainAreaList.get(i).getName()).append(",");
						}
					}
				}
			}
		}

		return cityBuilder.toString();
	}
	
	@Override
	public JsonResponse<List<PrdType>> getOnlineProduceTypeList(Map<String, Object> map) {
		JsonResponse<List<PrdType>> jr = new JsonResponse<List<PrdType>>();
		try {
			List<PrdType> list = prdTypeMapper.getOnlineProduceTypeList(map);
			jr.setResult(list);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("PrdTypeServiceImpl --- getTypeList", e);
			jr.setStatus(Status.ERROR);
		}
		return jr;
	}
}
