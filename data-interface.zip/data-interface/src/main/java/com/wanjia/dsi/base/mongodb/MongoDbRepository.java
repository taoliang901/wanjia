package com.wanjia.dsi.base.mongodb;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.mongodb.WriteResult;

/***
 * Mongdb 通用方法接口
 * 
 * @author CHENKANG560
 *
 * @param <T>
 */
public interface MongoDbRepository<T> {
	/**
	 * 查看所有
	 * @param clazz
	 * @return
	 */
	public List<T> findAll(Class<T> clazz);
	/**
	 * 插入
	 * @param clazz
	 * @return
	 */
	public void insert(T object, Class<T> clazz);
	/**
	 * 根据id 查看单个对象
	 * @param clazz
	 * @return
	 */
	public T findById(String id, Class<T> clazz);
	
	
	/***
	 * 判断是否存在
	 * @param query
	 * @param clazz
	 * @return
	 */
	public boolean exists(Query query, Class<T> clazz);
	
	
	
	
	
	
	

	public WriteResult updateObject(String id, String name, Class<T> clazz);
	/**
	 * 根据id 删除单个对象
	 * @param clazz
	 * @return
	 */
	public void deleteById(String id, Class<T> clazz);
	
	
	/**
	 * 根据id 删除多个单个对象
	 * @param clazz
	 * @return
	 */
	public void deleteBatch(Query query, Class<T> clazz);
	

	/**
	 * 创建collection
	 * @param clazz
	 * @return
	 */
	public void createCollection(Class<T> clazz);
	/**
	 * 删除collection
	 * @param clazz
	 * @return
	 */
	public void dropCollection(Class<T> clazz);

	/***
	 * 分页
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param query
	 * @param clazz
	 * @return
	 */
	public Pagination<T> getPage(int pageNo, int pageSize, Query query,Sort sort, Class<T> clazz);

	/**
	 * 通过条件查询实体(集合)
	 * 
	 * 
	 */
	public List<T> find(Query query, Class<T> clazz);
	
	/**
	 * 通过条件查询实体(集合)个数
	 * 
	 * 
	 */
	public long findCount(Query query, Class<T> clazz);
	
	
	
	

	/**
	 * 通过ID获取记录,并且指定了集合名(表的意思)
	 * 
	 * @param id
	 * @param collectionName
	 *            集合名
	 * @return
	 */
	public T findById(String id,  Class<T> clazz,String collectionName);

	/**
	 * 通过条件查询更新数据
	 * 
	 * @param query
	 * @param update
	 * @return
	 */
	public void updateFirst(Query query,Class<T> clazz, Update update);

	/**
	 * 按条件查询,并且删除记录
	 * 
	 * @param query
	 * @return
	 */
	public T findAndRemove(Query query,Class<T> clazz);

	/**
	 * 查询并且修改记录
	 * 
	 * @param query
	 * @param update
	 * @return
	 */
	public T findAndModify(Query query, Update update,Class<T> clazz);
	
	
	
	
	void updateMany(Query query,Update update,Class<T> clazz);
	
	public void insertBatch(List<T> list,Class<T> clazz);
	
	
	
	
	
	
	
	
	
}
