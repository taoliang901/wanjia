package com.wanjia.dsi.web.message;

import java.util.Properties;

import org.springframework.stereotype.Component;

@Component
public class MessageConsts {
	// C端用户
	public static String SYS_ROLE_PATIENT_VALUE = "1";

	// 诊所管理员
	public static String SYS_ROLE_CLINIC_VALUE = "3";

	// 消息类型名称
	public static String BOOKING_MESSAGE_TYPE = "业务消息";
	/*
	 * public static String CLINIC_UPGRADE_ACCOUNT_TYPE = "诊所申请升级总账号";
	 * 
	 * public static String CLINIC_ASSOC_ACCOUNT_TYPE = "诊所申请关联总账号";
	 */

	// 消息类型ID
	public static String BOOKING_MESSAGE_TYPE_ID = "2";

	/*
	 * public static String CLINIC_UPGRADE_ACCOUNT_TYPE_ID = "8";
	 * 
	 * public static String CLINIC_ASSOC_ACCOUNT_TYPE_ID = "9";
	 */

	// 设置弹框显示
	public static String IS_SHOW_YES = "1";

	// 设为未读状态
	public static String IS_READ_UN = "0";

	// 设置城市代码为全国
	public static String CITY_CODE_ALL = "0";

	public static String STATUS = "1";

	public static String DEL_FLAG = "0";

	public static String TEMPLATE_ID = "bookingTemplate";

	public static String UPGRADE_ACCOUNT_TEMPLATE_ID = "upgradeAccountTemplate";

	public static String ASSOC_ACCOUNT_TEMPLATE_ID = "associatedAccountTemplate";

	public static String USER = "messageAuthor";

	// 提交预约
	public static String TOPIC_BOOKING = "topic.booking";
	// 诊所确认预约
	public static String TOPIC_CLINIC_CONFIRM_BOOKING = "topic.clinic.confirm.booking";
	// 客户取消预约
	public static String TOPIC_PATIENT_CANCEL_BOOKING = "topic.patient.calcel.booking";
	// 诊所取消预约
	public static String TOPIC_CLINIC_CANCEL_BOOKING = "topic.clinic.cancel.booking";
	// 客户确认就诊
	public static String TOPIC_PATIENT_CONFIRM_CONSULTATION = "topic.patient.confirm.consultation";
	// 诊所确认就诊
	public static String TOPIC_CLINIC_CONFIRM_CONSULTATION = "topic.clinic.confirm.consultation";
	// 客户提交评价
	public static String TOPIC_PATIENT_RATED = "topic.patient.rated";
	// 诊所回复评价
	public static String TOPIC_CLINIC_REPLY_RATED = "topic.clinic.reply.rated";

	// 提交预约
	public static String CONTENT_BOOKING = "content.booking";
	// 诊所确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT = "content.clinic.confirm.booking.patient";
	// 诊所确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC = "content.clinic.confirm.booking.clinic";
	// 会员修改预约后确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_FORUPDATE = "content.clinic.confirm.booking.patient.forupdate";
	// 诊所修改预约后确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_FORUPDATE = "content.clinic.confirm.booking.clinic.forupdate";
	// 客户取消预约
	public static String CONTENT_PATIENT_CANCEL_BOOKING = "content.patient.calcel.booking";
	// 诊所取消预约
	public static String CONTENT_CLINIC_CANCEL_BOOKING = "content.clinic.cancel.booking";
	// 客户确认就诊
	public static String CONTENT_PATIENT_CONFIRM_CONSULTATION = "content.patient.confirm.consultation";
	// 诊所确认就诊
	public static String CONTENT_CLINIC_CONFIRM_CONSULTATION = "content.clinic.confirm.consultation";
	// 客户提交评价
	public static String CONTENT_PATIENT_RATED = "content.patient.rated";
	// 诊所回复评价
	public static String CONTENT_CLINIC_REPLY_RATED = "content.clinic.reply.rated";
	// 提交预约
	public static String CONTENT_BOOKING_NORMAL = "content.booking.normal";
	// 诊所确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_NORMAL = "content.clinic.confirm.booking.patient.normal";
	// 诊所确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_NORMAL = "content.clinic.confirm.booking.clinic.normal";
	// 会员修改预约后确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_FORUPDATE_NORMAL = "content.clinic.confirm.booking.patient.forupdate.normal";
	// 诊所修改预约后确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_FORUPDATE_NORMAL = "content.clinic.confirm.booking.clinic.forupdate.normal";
	// 客户取消预约
	public static String CONTENT_PATIENT_CANCEL_BOOKING_NORMAL = "content.patient.calcel.booking.normal";
	// 诊所取消预约
	public static String CONTENT_CLINIC_CANCEL_BOOKING_NORMAL = "content.clinic.cancel.booking.normal";
	// 客户确认就诊
	public static String CONTENT_PATIENT_CONFIRM_CONSULTATION_NORMAL = "content.patient.confirm.consultation.normal";
	// 诊所确认就诊
	public static String CONTENT_CLINIC_CONFIRM_CONSULTATION_NORMAL = "content.clinic.confirm.consultation.normal";
	// 客户提交评价
	public static String CONTENT_PATIENT_RATED_NORMAL = "content.patient.rated.normal";
	// 诊所回复评价
	public static String CONTENT_CLINIC_REPLY_RATED_NORMAL = "content.clinic.reply.rated.normal";

	// 提交预约
	public static String CONTENT_BOOKING_APP = "content.booking.app";
	// 诊所确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_APP = "content.clinic.confirm.booking.patient.app";
	// 诊所确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_APP = "content.clinic.confirm.booking.clinic.app";
	// 会员修改预约后确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_APP_FORUPDATE = "content.clinic.confirm.booking.patient.app.forupdate";
	// 诊所修改预约后确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_APP_FORUPDATE = "content.clinic.confirm.booking.clinic.forupdate";
	// 客户取消预约
	public static String CONTENT_PATIENT_CANCEL_BOOKING_APP = "content.patient.calcel.booking.app";
	// 诊所取消预约
	public static String CONTENT_CLINIC_CANCEL_BOOKING_APP = "content.clinic.cancel.booking.app";
	// 客户确认就诊
	public static String CONTENT_PATIENT_CONFIRM_CONSULTATION_APP = "content.patient.confirm.consultation.app";
	// 诊所确认就诊
	public static String CONTENT_CLINIC_CONFIRM_CONSULTATION_APP = "content.clinic.confirm.consultation.app";
	// 客户提交评价
	public static String CONTENT_PATIENT_RATED_APP = "content.patient.rated.app";
	// 诊所回复评价
	public static String CONTENT_CLINIC_REPLY_RATED_APP = "content.clinic.reply.rated.app";
	// 提交预约
	public static String CONTENT_BOOKING_NORMAL_APP = "content.booking.normal.app";
	// 诊所确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_NORMAL_APP = "content.clinic.confirm.booking.patient.normal.app";
	// 诊所确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_NORMAL_APP = "content.clinic.confirm.booking.clinic.normal.app";
	// 会员修改预约后确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_PATIENT_NORMAL_APP_FORUPDATE = "content.clinic.confirm.booking.patient.normal.app.forupdate";
	// 诊所修改预约后确认预约
	public static String CONTENT_CLINIC_CONFIRM_BOOKING_CLINIC_NORMAL_APP_FORUPDATE = "content.clinic.confirm.booking.clinic.normal.app.forupdate";
	// 客户取消预约
	public static String CONTENT_PATIENT_CANCEL_BOOKING_NORMAL_APP = "content.patient.calcel.booking.normal.app";
	// 诊所取消预约
	public static String CONTENT_CLINIC_CANCEL_BOOKING_NORMAL_APP = "content.clinic.cancel.booking.normal.app";
	// 客户确认就诊
	public static String CONTENT_PATIENT_CONFIRM_CONSULTATION_NORMAL_APP = "content.patient.confirm.consultation.normal.app";
	// 诊所确认就诊
	public static String CONTENT_CLINIC_CONFIRM_CONSULTATION_NORMAL_APP = "content.clinic.confirm.consultation.normal.app";
	// 客户提交评价
	public static String CONTENT_PATIENT_RATED_NORMAL_APP = "content.patient.rated.normal.app";
	// 诊所回复评价
	public static String CONTENT_CLINIC_REPLY_RATED_NORMAL_APP = "content.clinic.reply.rated.normal.app";

	public static String CONTENT_CLINIC_UPGRADE_ACCOUNT = "content.clinic.upgrade.account";

	public static String CONTENT_CLINIC_ASSOCIATED_ACCOUNT = "content.clinic.associated.account";

	/**
	 * 发布渠道类型： 1:微信,2：B端APP,3:C端APP,4:网站
	 */
	public static final String CHANNEL_TYPE_WX = "1";
	public static final String CHANNEL_TYPE_BD = "2";
	public static final String CHANNEL_TYPE_CD = "3";
	public static final String CHANNEL_TYPE_WZ = "4";
	
	/**
	 * 消息权限模块号
	 */
	public static final String MESSAGE_MODULE_SOURCE_CODE_YYGL="APT";
	public static final String MESSAGE_MODULE_SOURCE_CODE_KCGL="DRUG";
	public static final String MESSAGE_MODULE_SOURCE_CODE_MYDGL="SAT";

	public static void main(String[] args) {
		Properties properties = new Properties();
	}
}
