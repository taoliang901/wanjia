package com.wanjia.dsi.web.wx.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.util.AESEncode;
import com.wanjia.dsi.web.util.SaltfigureGenerator;
import com.wanjia.dsi.web.wx.service.EncryptOpenidService;

@Service
@com.alibaba.dubbo.config.annotation.Service
public class EncryptOpenidServiceImpl implements EncryptOpenidService {

	private final Logger logger = LoggerFactory.getLogger(EncryptOpenidServiceImpl.class);
	
	@Override
	public JsonResponse<String> encrypt(String openid) {
		JsonResponse<String> response = new JsonResponse<String>();
		try{
			// 校验openid
			if(!StringUtils.isNotBlank(openid)){
				response.setErrorMsg("未获取到openid");
				response.setStatus(JsonResponse.Status.ERROR);
				return response;
			}
			
			//生成盐值
			String key = SaltfigureGenerator.getAESSaltfigureForOpenid();
			
			//AES加密
			String aes = AESEncode.aesEncrypt(openid, key);
			
			logger.info("微信加密key：["+ key +"]--------openid:["+openid+"]----------AES:[" + aes + "]");
			
			response.setResult(aes);
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.warn("加密openid异常！", e);
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("加密openid异常！");
		}
		return response;
	}
	
	public JsonResponse<String> decrypt(String encryptStr,String decryptKey){
		JsonResponse<String> response = new JsonResponse<String>();
		try{
			String decryptStr = AESEncode.aesDecrypt(encryptStr, decryptKey);
			response.setResult(decryptStr);
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			logger.warn("AES解密异常！", e);
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("AES解密异常！");
		}
		return response;
	}

	@Override
	public JsonResponse<String> decryptForOpenid(String openidEncryptStr) {
		JsonResponse<String> response = new JsonResponse<String>();
		try{
			//获取盐值
			String decryptKey = SaltfigureGenerator.getAESSaltfigureForOpenid();
			String decryptStr = AESEncode.aesDecrypt(openidEncryptStr, decryptKey);
			response.setResult(decryptStr);
			response.setStatus(JsonResponse.Status.SUCCESS);
			logger.info("微信加密openidEncryptStr：["+ openidEncryptStr +"]--------decryptKey:["+decryptKey+"]----------decryptStr:[" + decryptStr + "]");
		}catch(Exception e){
			logger.warn("AES解密异常！", e);
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("AES解密openid异常！");
		}
		
		return response;
	}

}
