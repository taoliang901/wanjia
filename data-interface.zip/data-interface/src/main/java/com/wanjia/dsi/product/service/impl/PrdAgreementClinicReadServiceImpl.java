package com.wanjia.dsi.product.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.model.PrdAgreementClinic;
import com.wanjia.dsi.product.service.PrdAgreementClinicReadService;

/**
 * This element is automatically generated on 16-11-14 上午10:42, do not modify. <br>
 * Service implementation class
 */
@Service
@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class PrdAgreementClinicReadServiceImpl implements PrdAgreementClinicReadService {
    @Autowired
    private PrdAgreementClinicMapper prdAgreementClinicMapper;

	@Override
	public PrdAgreementClinic findById(String id) {
		
		PrdAgreementClinic prdAgreementClinic = prdAgreementClinicMapper.findById(id);
		return prdAgreementClinic;
	}

	@Override
	public List<PrdAgreementClinic> findByAgreementId(String id) {
		
		List<PrdAgreementClinic> prdAgreementClinics = prdAgreementClinicMapper.findByAgreementId(id);
		return prdAgreementClinics;
	}

   
}