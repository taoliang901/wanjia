package com.wanjia.dsi.web.callCenter.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.web.callCenter.dao.mapper.IssueMapper;
import com.wanjia.dsi.web.callCenter.model.Issue;
import com.wanjia.dsi.web.callCenter.service.IssueService;


/**
 * This element is automatically generated on 16-7-14 下午2:39, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class IssueServiceImpl  extends BaseServiceImpl implements IssueService {
    @Autowired
    private IssueMapper issueMapper;
    
    

	@Override
	public void createIssueForPrd(Issue issue) {
		//插工单表
		issueMapper.insert(issue);
		
	}

	@Override
	public void updateIssueForPrd(Issue issue) {
		//更新工单
		issueMapper.update(issue);
		
		
	}

	@Override
	public Issue findById(Long id) {
		issueMapper.findById(id);
		return null;
	}

	@Override
	public List<Issue> findWithPagination(int offset, int count) {
		return issueMapper.findWithPagination(offset, count);
		
	}

	@Override
	public List<Issue> findAll() {
		
		return issueMapper.findAll();
	}

	@Override
	public List<Issue> findByEntity(Issue model) {
		
		return issueMapper.findByEntity(model);
	}

	@Override
	public List<Issue> findByEntityWithPagination(Issue model, int offset,
			int count) {
		
		return issueMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	public Issue findOneByEntity(Issue model) {
		
		return (Issue) issueMapper.findOneByEntity(model);
	}

	@Override
	public List<Issue> findByProperty(String propertyName, String propertyValue) {
		
		return (List<Issue>)issueMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	public Issue findOneByProperty(String propertyName, String propertyValue) {
		
		return (Issue) issueMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	public List<Issue> findByPropertyWithPagination(String propertyName,
			String propertyValue, int offset, int count) {
		
		return (List<Issue>)issueMapper.findByPropertyWithPagination(propertyName, propertyValue, offset, count);
	}

	@Override
	public List<Issue> findByProperties(Map<String, Object> map) {
		
		return (List<Issue>)issueMapper.findByProperties(map);
	}

	@Override
	public long countByEntity(Issue model) {
		
		return issueMapper.countByEntity(model);
	}

	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		
		return issueMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	public long countByProperties(Map<String, Object> map) {
		
		return issueMapper.countByProperties(map);
	}

	@Override
	public void update(Issue model) {
		issueMapper.update(model);
		
	}

	@Override
	public void insert(Issue model) {
		issueMapper.insert(model);
	}

	@Override
	public void deleteByEntity(Issue model) {
		issueMapper.deleteByEntity(model);
		
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		issueMapper.deleteByProperty(propertyName, propertyValue);
	}

	@Override
	public long countAll() {
		
		return issueMapper.countAll();
	}

	@Override
	public void insertBatch(List<Issue> list) {
		issueMapper.insertBatch(list);
	}

	@Override
	public void delete(Long id) {
		issueMapper.deleteById(id);
		
	}


}