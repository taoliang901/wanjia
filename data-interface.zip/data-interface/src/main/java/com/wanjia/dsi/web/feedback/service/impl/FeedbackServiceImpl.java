package com.wanjia.dsi.web.feedback.service.impl;

import com.wanjia.dsi.web.feedback.dao.mapper.FeedbackMapper;
import com.wanjia.dsi.web.feedback.model.Feedback;
import com.wanjia.dsi.web.feedback.service.FeedbackService;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This element is automatically generated on 16-5-6 ����11:24, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class FeedbackServiceImpl implements FeedbackService {
    @Autowired
    private FeedbackMapper feedbackMapper;

    @Override
    public Feedback findById(Long id) {
        return (Feedback)feedbackMapper.findById(id);
    }

    @Override
    public List<Feedback> findWithPagination(int offset, int count) {
        return (List<Feedback>)feedbackMapper.findWithPagination(offset,count);
    }

    @Override
    public List<Feedback> findAll() {
        return (List<Feedback>)feedbackMapper.findAll();
    }

    @Override
    public List<Feedback> findByEntity(Feedback model) {
        return (List<Feedback>)feedbackMapper.findByEntity(model);
    }

    @Override
    public List<Feedback> findByEntityWithPagination(Feedback model, int offset, int count) {
        return (List<Feedback>)feedbackMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    public Feedback findOneByEntity(Feedback model) {
        return (Feedback)feedbackMapper.findOneByEntity(model);
    }

    @Override
    public List<Feedback> findByProperty(String propertyName, String propertyValue) {
        return (List<Feedback>)feedbackMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    public Feedback findOneByProperty(String propertyName, String propertyValue) {
        return (Feedback)feedbackMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    public List<Feedback> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<Feedback>)feedbackMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    public List<Feedback> findByProperties(Map<String, Object> map) {
        return (List<Feedback>)feedbackMapper.findByProperties(map);
    }

    @Override
    public long countByEntity(Feedback model) {
        return (long)feedbackMapper.countByEntity(model);
    }

    @Override
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)feedbackMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    public long countByProperties(Map<String, Object> map) {
        return (long)feedbackMapper.countByProperties(map);
    }

    @Override
    public void update(Feedback model) {
        feedbackMapper.update(model);
    }

    @Override
    public void insert(Feedback model) {
        feedbackMapper.insert(model);
    }

    @Override
    public void deleteByEntity(Feedback model) {
        feedbackMapper.deleteByEntity(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        feedbackMapper.deleteByProperty(propertyName,propertyValue);
    }

    public long countAll() {
        return this.feedbackMapper.countAll();
    }

    public void insertBatch(List<Feedback> list) {
        this.feedbackMapper.insertBatch(list);
    }

    public void delete(Long id) {
        this.feedbackMapper.deleteById(id);
    }
}