package com.wanjia.dsi.product.service.impl;

import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.pahaoche.hy.user.service.SmsServer;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.sms.interior.interfaces.sms.model.req.SendSMSRequest;
//import com.pahaoche.rbmq.client.RbmqClient;
//import com.pahaoche.umc.fwk.sms.helper.SmsRequest;
import com.wanjia.sms.interior.interfaces.sms.service.SmsClientService;

/*********************************************************************************
 * //* Copyright (C) 2014 Pingan Haoche (PAHAOCHE). All Rights Reserved. //* //*
 * Filename: SmsServerImpl.java //* Revision: 1.0 //* Author: <your name> //*
 * Created On: 2014-3-24 //* Modified by: //* Modified On: //* //* Description:
 * <description> /
 ********************************************************************************/

// 短信发送代码冗余
public class SmsServerImpl implements SmsServer {

    private static Logger     logger = Logger.getLogger(SmsServerImpl.class);

//    private SendSMSUtils sendSMSUtils;
    private SmsClientService smsClientService;

    //private RbmqClient mqClient;

//    public SmsServerImpl() {
//        mqClient = RbmqClient.getRbmqClient();
//    }

    @Override
    public boolean sendSms(String mo, String tempId, String randomNum, String ipAddress) throws Exception {

    	boolean flg = true;
    	SendSMSRequest req = new SendSMSRequest("hy", mo, null);
    	// 拼接短信URL
//    	String pa_tempId = "";
    	if ("1".equals(tempId)) {
//            smsRequest.setTempletId("hy_register");
//            pa_tempId = "HC160322003";
            req.setTemplateID(SendSMSRequest.JK160930001);
        }
        else if ("2".equals(tempId)) {//网站会员登录
//            smsRequest.setTempletId("hy_login");
//            pa_tempId = "HC160322001";
            req.setTemplateID(SendSMSRequest.JK160930002);
        }
        else if ("3".equals(tempId)) {
//            smsRequest.setTempletId("hy_reset");
//            pa_tempId = "HC160322002";
        	req.setTemplateID(SendSMSRequest.JK160930004);
        }
        else if ("4".equals(tempId)) {//万里通登录验证码
//            smsRequest.setTempletId("hy_justnum");
//            pa_tempId = "HC160322004";
            req.setTemplateID(SendSMSRequest.JK160419005);
        }
        else {
        	logger.error("短信发送失败0，原因：模板ID不正确【"+tempId+"】");
        	return false;
        }

//		String jsonParams = "{'randomNum':'" + randomNum + "'}";
		req.putParams("randomNum", randomNum);
		try {
//			JsonResponse<String> jsonResp = sendSMSUtils.sendSMS(mo, pa_tempId, jsonParams);
			JsonResponse<String> jsonResp = smsClientService.sendSMSByDubbo(req);
			// 成功
			if(JsonResponse.Status.SUCCESS==jsonResp.getStatus()) {
				logger.info("短信发送成功！");
			}
			// 异常
			else if(JsonResponse.Status.ERROR==jsonResp.getStatus()) {
				logger.error("短信发送失败1，原因：" + jsonResp.getErrorCode() + "：" + jsonResp.getErrorMsg());
				flg = false;
			}
			// 警告
			else if(JsonResponse.Status.WARNING==jsonResp.getStatus()) {
				logger.warn("短信发送出现警告，原因：" + jsonResp.getErrorCode() + "：" + jsonResp.getErrorMsg());
			}
		} catch(Exception e) {
			logger.error("短信发送失败2，原因：" + e.getMessage());
			flg = false;
		}
        // MsgRequest request = new MsgRequest();
        // request.setClientQuene("clientResponse.default");
        /*SmsRequest smsRequest = new SmsRequest();
        smsRequest.setIp(ipAddress);
        smsRequest.setMobileNo(mo);
        smsRequest.setMsgContent("hytest");
        SimpleDateFormat formatter = new SimpleDateFormat(SmsRequest.DATE_FORMAT);
        smsRequest.setMsgSendTime(formatter.format(new Date()));
        smsRequest.setMsgUserCode("HYSYS");
        if ("1".equals(tempId)) {
            smsRequest.setTempletId("hy_register");
            smsRequest.setAttribute("randomNum", randomNum);
        }
        else if ("2".equals(tempId)) {//网站会员登录
            smsRequest.setTempletId("hy_login");
            smsRequest.setAttribute("randomNum", randomNum);
        }
        else if ("3".equals(tempId)) {
            smsRequest.setTempletId("hy_reset");
            smsRequest.setAttribute("randomNum", randomNum);
        }
        else if ("4".equals(tempId)) {//万里通登录验证码
            smsRequest.setTempletId("hy_justnum");
            smsRequest.setAttribute("randomNum", randomNum);
        }
        else if ("5".equals(tempId)) { //好车宝转入转出
            smsRequest.setTempletId("wz_yzm");
            smsRequest.setAttribute("randomNum", randomNum);
        }
        else {
            return false;
        }
        request.setParams(smsRequest.map);
        mqClient.send(request);*/

        return flg;
    }
    
    @Override
    public boolean sendAppSms(String mo, String tempId, String username,String password,String ipAddress) throws Exception {
       /* MsgRequest request = new MsgRequest();
        // request.setClientQuene("clientResponse.default");
        SmsRequest smsRequest = new SmsRequest();
        smsRequest.setIp(ipAddress);
        smsRequest.setMobileNo(mo);
        smsRequest.setMsgContent("hytest");
        SimpleDateFormat formatter = new SimpleDateFormat(SmsRequest.DATE_FORMAT);
        smsRequest.setMsgSendTime(formatter.format(new Date()));
        smsRequest.setMsgUserCode("HYSYS");
        if ("app_login".equals(tempId)) {
            smsRequest.setTempletId("app_login");
            smsRequest.setAttribute("username", username);
            smsRequest.setAttribute("password", password);
        }
        else {
            return false;
        }
        request.setParams(smsRequest.map);
        mqClient.send(request);
        logger.info("mqClient.send(request) is run");*/

    	throw new RuntimeException("暂不实现该接口");
    }

	@Override
	public boolean sendAllSms(String mobile, String smsTempId,
			String ipAddress, Map<String, String> map) throws Exception {
		boolean flg = true;
		SendSMSRequest req = new SendSMSRequest("hy", mobile, null);

		// 设置模板ID
		req.setTemplateID(smsTempId);

		// 设置短信模板参数
		Iterator entries = map.entrySet().iterator();
		while (entries.hasNext()) {
			Map.Entry entry = (Map.Entry) entries.next();
			String key = (String) entry.getKey();
			String value = (String) entry.getValue();
			req.putParams(key, value);
		}

		// 发送短信
		try {
			JsonResponse<String> jsonResp = smsClientService
					.sendSMSByDubbo(req);
			// 成功
			if (JsonResponse.Status.SUCCESS == jsonResp.getStatus()) {
				logger.info("短信发送成功！");
			}
			// 异常
			else if (JsonResponse.Status.ERROR == jsonResp.getStatus()) {
				logger.error("短信发送失败1，原因：" + jsonResp.getErrorCode() + "："
						+ jsonResp.getErrorMsg());
				flg = false;
			}
			// 警告
			else if (JsonResponse.Status.WARNING == jsonResp.getStatus()) {
				logger.warn("短信发送出现警告，原因：" + jsonResp.getErrorCode() + "："
						+ jsonResp.getErrorMsg());
			}
		} catch (Exception e) {
			logger.error("短信发送失败2，原因：" + e.getMessage());
			flg = false;
		}
		return flg;
	}
    
	public SmsClientService getSmsClientService() {
		return smsClientService;
	}

	public void setSmsClientService(SmsClientService smsClientService) {
		this.smsClientService = smsClientService;
	}
}
