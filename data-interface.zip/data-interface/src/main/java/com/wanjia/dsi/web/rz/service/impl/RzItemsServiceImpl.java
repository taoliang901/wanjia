package com.wanjia.dsi.web.rz.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.rz.dao.mapper.RzItemsMapper;
import com.wanjia.dsi.web.rz.dao.mapper.RzResultMapper;
import com.wanjia.dsi.web.rz.dao.mapper.RzTemplateItemsMapper;
import com.wanjia.dsi.web.rz.model.Radar;
import com.wanjia.dsi.web.rz.model.RzItemsInfo;
import com.wanjia.dsi.web.rz.model.RzResult;
import com.wanjia.dsi.web.rz.service.RzItemsService;


@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class RzItemsServiceImpl implements RzItemsService{
	
	protected final Logger logger = LoggerFactory.getLogger(RzItemsServiceImpl.class);
	
	@Autowired
	private RzItemsMapper rzItemsMapper;
	@Autowired
	private RzTemplateItemsMapper rzTemplateItemsMapper;
	@Autowired
	private RzResultMapper rzResultMapper;
	
	@Override
	public JsonResponse<List<RzItemsInfo>> queryClinicItems(Map<String, Object> map) {
		JsonResponse<List<RzItemsInfo>> response = new JsonResponse<List<RzItemsInfo>>();
		try{
			List<RzItemsInfo> list = rzItemsMapper.searchClinicRzInfo(map);
			response.setResult(list);
			response.setStatus(JsonResponse.Status.SUCCESS);
		}catch(Exception e){
			e.printStackTrace();
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("查询认证标准项出错！");
		}
		
		return response;
	}

	public String countPassItemNum(Map<String, Object> map){
		String num = this.rzItemsMapper.countPassItemNum(map);
    	if(num == null){
    		num = "0";
    	}
    	return num;
	}
	
	public String countFailItemNum(Map<String, Object> map){
		String num = this.rzItemsMapper.countFailItemNum(map);
    	if(num == null){
    		num = "0";
    	}
    	return num;
	}
	
	public String countUnusedItemNum(Map<String, Object> map){
		String num = this.rzItemsMapper.countUnusedItemNum(map);
    	if(num == null){
    		num = "0";
    	}
    	return num;
	}

	@Override
	public JsonResponse<Map<String, Object>> queryRzScoreStatistic(String resultId) {
		JsonResponse<Map<String, Object>> jason = new JsonResponse<Map<String, Object>>();
		logger.info("resultId = " + resultId);
		try{
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("resultId",resultId);
			paramMap.put("delFlag","0");
			paramMap.put("id",resultId);
			//查询认证结果
			List<RzResult> rzResult = rzResultMapper.findByProperties(paramMap);
			if(rzResult!=null && !rzResult.isEmpty()){
				paramMap.put("reportScore", rzResult.get(0).getReportScore());//获取认证报告评分
				
				String passNum = countPassItemNum(paramMap);
				paramMap.put("passNum", passNum);
				String failNum = countFailItemNum(paramMap);
				paramMap.put("failNum", failNum);
				String unUsedNum = countUnusedItemNum(paramMap);
				paramMap.put("unUsedNum", unUsedNum);
				
				jason.setResult(paramMap);
				jason.setStatus(JsonResponse.Status.SUCCESS);
				jason.setSuccessMsg("获取统计达标数据成功！");
			}else{
				jason.setStatus(JsonResponse.Status.ERROR);
				jason.setErrorMsg("认证结果不存在！");
			}
		}catch(Exception e){
			e.printStackTrace();
			jason.setStatus(JsonResponse.Status.ERROR);
			jason.setErrorMsg("获取统计达标数据出错！");
		}
		
		return jason;
	}
	
	@Override
	public JsonResponse<List<Radar>> queryRadar(Map<String, Object> map) {
		JsonResponse<List<Radar>> response = new JsonResponse<List<Radar>>();
		try{
			//查询诊所认证时的实际相关分数
			List<Radar> clinicStandardScore = rzTemplateItemsMapper.getClinicStandardScore(map);
			
			if(clinicStandardScore!=null && !clinicStandardScore.isEmpty()){
				
				Map<String,Object> radarItems =  rzTemplateItemsMapper.getradarItems(map);
				
				//未设置雷达图属性时则默认只返回所有的认证标准类型
				if(radarItems == null || radarItems.get("radar_items") == null || "".equals(radarItems.get("radar_items"))){
					//List<Radar> radars = rzTemplateItemsMapper.getTotalRadarItems(map);
					response.setResult(null);//表示未设置雷达图属性
				}else{
					//查询认证标准的实际相关分数
					String standardTypes[] = radarItems.get("radar_items").toString().split(",");
					StringBuffer standards = new StringBuffer();
					for(String st : standardTypes){
						standards.append(",").append("'").append(st).append("'");
					}
					map.put("standardTypes", standards.toString().substring(1));
					map.put("template_id", radarItems.get("template_id"));
					List<Radar> standardScores = rzTemplateItemsMapper.getStandardScore(map);
					if(standardScores!=null && !standardScores.isEmpty()){
						for(Radar radar : standardScores){
							BigDecimal average = radar.getTotalScore().divide(radar.getTotalCount(), 2, BigDecimal.ROUND_HALF_UP);
							radar.setAverage(average);
							for(Radar clinicRadar : clinicStandardScore){
								if(radar.getStandardType().equals(clinicRadar.getStandardType())){
									BigDecimal clinicAverage = clinicRadar.getClinicTotalScore().divide(clinicRadar.getClinicTotalCount(), 2, BigDecimal.ROUND_HALF_UP);
									radar.setClinicAverage(clinicAverage);
									radar.setClinicTotalCount(clinicRadar.getClinicTotalCount());
									radar.setClinicTotalScore(clinicRadar.getClinicTotalScore());
								}else{
									continue;
								}
							}
						}
					}
					response.setResult(standardScores);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("获取雷达图统计数据出错！");
		}
		
		response.setStatus(JsonResponse.Status.SUCCESS);
		return response;
	}

	@Override
	public JsonResponse<List<RzItemsInfo>> queryRzItemsForClinic(Map<String, Object> map) {
		JsonResponse<List<RzItemsInfo>> response = new JsonResponse<List<RzItemsInfo>>();
		
		try{
			List<RzItemsInfo> list = rzItemsMapper.searchClinicRzInfo(map);
			if(list!=null && !list.isEmpty()){
				for(RzItemsInfo item : list){
					if(item.getImagePath()==null){
						continue;
					}else{
						if(item.getImageShow()!=null){
							String[] imagePath_array = item.getImageShow().split(",");
							String[] imagePath = item.getImagePath().split(",");
							StringBuffer path = new StringBuffer();
							path.append("");
							int num = imagePath.length;
							/*if(imagePath_array!=null){
								num = imagePath_array.length;
							}*/
							for(int i=0;i<num;i++){
								if("0".equals(imagePath_array[i])){
									path.append(",").append(imagePath[i]);
								}
							}
							if(path!=null && !"".equals(path.toString())){
								item.setImagePathView(path.toString().substring(1));
								path.setLength(0);
							}
						}else{
							item.setImagePathView(item.getImagePath());
						}
						
					}
					
				}
			}
			
			response.setResult(list);
		}catch(Exception e){
			e.printStackTrace();
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("获取认证标准项出错！");
		}
		
		return response;
	}

	@Override
	public JsonResponse<Map<String, Object>> getAuditReport(Map<String, Object> map) {
		JsonResponse<Map<String, Object>> response = new JsonResponse<Map<String,Object>>();
		
		//参数校验
		if(map.get("resultId")==null || "".equals(map.get("resultId"))){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到认证结果id参数");
			return response;
		}
		if(map.get("clinicId")==null || "".equals(map.get("clinicId"))){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg("未获取到诊所id参数");
			return response;
		}
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		//统计达标项
		JsonResponse<Map<String, Object>> scoreStatistic = queryRzScoreStatistic(map.get("resultId")+"");
		if(JsonResponse.Status.ERROR.getValue().equals(scoreStatistic.getStatus().getValue())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg(scoreStatistic.getErrorMsg());
			return response;
		}
		resMap.put("scoreStatistic", scoreStatistic.getResult());
		
		//统计雷达图平均分
		JsonResponse<List<Radar>> radars = queryRadar(map);
		if(JsonResponse.Status.ERROR.getValue().equals(radars.getStatus().getValue())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg(radars.getErrorMsg());
			return response;
		}
		resMap.put("radars", radars.getResult());
		
		//查询认证项
		JsonResponse<List<RzItemsInfo>> items = queryRzItemsForClinic(map);
		if(JsonResponse.Status.ERROR.getValue().equals(items.getStatus().getValue())){
			response.setStatus(JsonResponse.Status.ERROR);
			response.setErrorMsg(items.getErrorMsg());
			return response;
		}
		resMap.put("items", items.getResult());
		response.setResult(resMap);
		response.setStatus(JsonResponse.Status.SUCCESS);
		return response;
	}
	
	public static void main(String[] args) {
		//查询诊所认证时的实际相关分数
		List<Radar> clinicStandardScore = new ArrayList<Radar>();
		Radar Radar1 = new Radar();
		Radar1.setStandardType("01");
		Radar1.setClinicTotalScore(new BigDecimal("15"));
		Radar1.setClinicTotalCount(new BigDecimal("2"));
		
		Radar Radar2 = new Radar();
		Radar2.setStandardType("02");
		Radar2.setClinicTotalScore(new BigDecimal("23"));
		Radar2.setClinicTotalCount(new BigDecimal("2"));
		
		Radar Radar3 = new Radar();
		Radar3.setStandardType("03");
		Radar3.setClinicTotalScore(new BigDecimal("3.6"));
		Radar3.setClinicTotalCount(new BigDecimal("1"));
		
		Radar Radar4 = new Radar();
		Radar4.setStandardType("04");
		Radar4.setClinicTotalScore(new BigDecimal("6.8"));
		Radar4.setClinicTotalCount(new BigDecimal("1"));
		
		Radar Radar5 = new Radar();
		Radar5.setStandardType("05");
		Radar5.setClinicTotalScore(new BigDecimal("0"));
		Radar5.setClinicTotalCount(new BigDecimal("1"));
		
		clinicStandardScore.add(Radar1);
		clinicStandardScore.add(Radar2);
		clinicStandardScore.add(Radar3);
		clinicStandardScore.add(Radar4);
		clinicStandardScore.add(Radar5);
		
		if(clinicStandardScore!=null && !clinicStandardScore.isEmpty()){
			
			Map<String,Object> radarItems =  new HashMap<String,Object>();//rzTemplateItemsMapper.getradarItems(map);
			radarItems.put("template_id", "ad5df2b9-73ec-4f87-ae46-89fd341a542e");
			radarItems.put("radar_items", "01,02,03,04,05");
			
			//未设置雷达图属性时则默认只返回所有的认证标准类型
			if(radarItems == null || radarItems.get("radar_items") == null || "".equals(radarItems.get("radar_items"))){
				//List<Radar> radars = rzTemplateItemsMapper.getTotalRadarItems(map);
				//response.setResult(null);//表示未设置雷达图属性
			}else{
				//查询认证标准的实际相关分数
				String standardTypes[] = radarItems.get("radar_items").toString().split(",");
				StringBuffer standards = new StringBuffer();
				for(String st : standardTypes){
					standards.append(",").append("'").append(st).append("'");
				}
//				map.put("standardTypes", standards.toString().substring(1));
//				map.put("template_id", radarItems.get("template_id"));
				List<Radar> standardScores = new ArrayList<Radar>();//rzTemplateItemsMapper.getStandardScore(map);
				Radar Radar11 = new Radar();
				Radar11.setStandardType("01");
				Radar11.setTotalScore(new BigDecimal("40"));
				Radar11.setTotalCount(new BigDecimal("2"));
				Radar11.setStandardTypeDesc("硬件管理");
				
				Radar Radar12 = new Radar();
				Radar12.setStandardType("02");
				Radar12.setTotalScore(new BigDecimal("40"));
				Radar12.setTotalCount(new BigDecimal("2"));
				Radar12.setStandardTypeDesc("人员管理");
				
				Radar Radar13 = new Radar();
				Radar13.setStandardType("03");
				Radar13.setTotalScore(new BigDecimal("30"));
				Radar13.setTotalCount(new BigDecimal("1"));
				Radar13.setStandardTypeDesc("运营管理");
				
				Radar Radar14 = new Radar();
				Radar14.setStandardType("04");
				Radar14.setTotalScore(new BigDecimal("20"));
				Radar14.setTotalCount(new BigDecimal("1"));
				Radar14.setStandardTypeDesc("医疗质量管理");
				
				Radar Radar15 = new Radar();
				Radar15.setStandardType("05");
				Radar15.setTotalScore(new BigDecimal("0.2"));
				Radar15.setTotalCount(new BigDecimal("1"));
				Radar15.setStandardTypeDesc("社会影响力");
				
				standardScores.add(Radar11);
				standardScores.add(Radar12);
				standardScores.add(Radar13);
				standardScores.add(Radar14);
				standardScores.add(Radar15);
				
				if(standardScores!=null && !standardScores.isEmpty()){
					for(Radar radar : standardScores){
						BigDecimal average = radar.getTotalScore().divide(radar.getTotalCount(), 2, BigDecimal.ROUND_HALF_UP);
						radar.setAverage(average);
						for(Radar clinicRadar : clinicStandardScore){
							if(radar.getStandardType().equals(clinicRadar.getStandardType())){
								BigDecimal clinicAverage = clinicRadar.getClinicTotalScore().divide(clinicRadar.getClinicTotalCount(), 2, BigDecimal.ROUND_HALF_UP);
								radar.setClinicAverage(clinicAverage);
								radar.setClinicTotalCount(clinicRadar.getClinicTotalCount());
								radar.setClinicTotalScore(clinicRadar.getClinicTotalScore());
							}else{
								continue;
							}
						}
					}
				}
				
				for(Radar radar : standardScores){
					
					System.out.println(ToStringBuilder.reflectionToString(radar, ToStringStyle.MULTI_LINE_STYLE));
				}
			}
		}
	}
}
