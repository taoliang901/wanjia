package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.product.dao.mapper.FrameAgreementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementClinicMapper;
import com.wanjia.dsi.product.dao.mapper.PrdAgreementPrdinfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdClinicConfigMapper;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdRatioSettlementMapper;
import com.wanjia.dsi.product.dao.mapper.PrdSubAgreementMapper;
import com.wanjia.dsi.product.model.FrameAgreement;
import com.wanjia.dsi.product.model.PrdAgreementClinic;
import com.wanjia.dsi.product.model.PrdAgreementPrdFullInfo;
import com.wanjia.dsi.product.model.PrdAgreementPrdinfo;
import com.wanjia.dsi.product.model.PrdClinicConfig;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdInfoExample;
import com.wanjia.dsi.product.model.PrdRatioSettlement;
import com.wanjia.dsi.product.model.PrdSubAgreement;
import com.wanjia.dsi.product.service.SubAgreementReadService;
import com.wanjia.dsi.product.vo.VOPrdSubAgreementClinic;
import com.wanjia.dsi.web.clinic.dao.mapper.AddressInfoMapper;
import com.wanjia.dsi.web.clinic.model.AddressInfo;

@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class SubAgreementReadServiceImpl implements SubAgreementReadService {

    private Logger logger = LoggerFactory.getLogger(SubAgreementReadServiceImpl.class);
    
    @Autowired
    private AddressInfoMapper addressInfoMapper;
    
    @Autowired
    private PrdAgreementClinicMapper prdAgreementClinicMapper;
    
    @Autowired
    private PrdSubAgreementMapper prdSubAgreementMapper;
    
    @Autowired
    private PrdInfoMapper prdInfoMapper;
    
    @Autowired
    private PrdAgreementPrdinfoMapper prdAgreementPrdinfoMapper;
    
    @Autowired
    private FrameAgreementMapper frameAgreementMapper;
    
    @Autowired
    private PrdRatioSettlementMapper prdRatioSettlementMapper;
    
    @Autowired
    private PrdClinicConfigMapper prdClinicConfigMapper;
    
    @Override
    public JsonResponse<Map<String,Object>> findOneSubAgreementById(Map<String,Object> idMap) {
        Map<String,Object> map = new HashMap<String, Object>();
        JsonResponse<Map<String,Object>> jr = new JsonResponse<Map<String,Object>>();
        String agreementId = "";
        String subAgreementId = "";
        
        try{
//            if(StringUtils.isEmpty(subAgreementId)){
//                logger.error("根据ID获取单个附属合同失败,subAgreementId 为空");
//                jr.setErrorMsg("根据ID获取单个附属合同失败,subAgreementId为空");
//                jr.setStatus(Status.ERROR);
//                return jr;
//            }
            
            agreementId = idMap.get("agreementId").toString();
            if(idMap.containsKey("subAgreementId")){
                subAgreementId = idMap.get("subAgreementId").toString();
            }
            
            PrdSubAgreement prdSubAgreement = prdSubAgreementMapper.findById(subAgreementId);
            FrameAgreement frameAgreement = frameAgreementMapper.findById(agreementId);
            
            List<PrdAgreementClinic> prdAgreementClinicList = new ArrayList<PrdAgreementClinic>();
            List<PrdAgreementPrdFullInfo> prdAgreementPrdinfoList = new ArrayList<PrdAgreementPrdFullInfo>();
            
            Map<String,Object> clinicMap = new HashMap<String, Object>();
            
            if(StringUtils.isNotEmpty(subAgreementId)){
                clinicMap.put("subAgreementId", subAgreementId);
                clinicMap.put("clinicType", "2");//查询单体诊所
                clinicMap.put("agreementId", agreementId);
                clinicMap.put("delFlag", "0");
                prdAgreementClinicList = prdAgreementClinicMapper.findByProperties(clinicMap);
            }else{
                if("2".equals(frameAgreement.getClinicType())){
                    clinicMap.put("clinicType", "2");//查询乙方诊所
                    clinicMap.put("agreementId", agreementId);
                    clinicMap.put("delFlag", "0");
                    prdAgreementClinicList = prdAgreementClinicMapper.findByProperties(clinicMap);
                }
            }
            
            if(prdSubAgreement != null){
                Map<String,Object> prdMap = new HashMap<String,Object>();
                prdMap.put("subAgreementId", prdSubAgreement.getId());
                prdMap.put("delFlag", "0");
                prdAgreementPrdinfoList = prdAgreementPrdinfoMapper.findByPropertiesWithFullInfo(prdMap);
                
                PrdInfoExample example = new PrdInfoExample();
                PrdInfoExample.Criteria criteria = example.createCriteria();
                List<String> prdIds = new ArrayList<String>();
                for(PrdAgreementPrdFullInfo fullInfo : prdAgreementPrdinfoList){
                    prdIds.add(fullInfo.getPrdId());
                }
                criteria.andIdIn(prdIds);
                List<PrdInfo> prdList = prdInfoMapper.selectByExample(example);
                
                /*附属合同产品可选的服务期限要在产品有效期和框架合同有效期的交集之内
                                                     例如:产品有效期2017.1.1~2017.2.1,框架合同有效期 2016.12.1~2017.1.20,则该产品在附属合同可选的有效期为2017.1.1~2017.1.20
                                                     如果产品有效期是无限期，则该产品在附加合同的有效期是框架合同有效期
                                                     以下代码用于获取该产品在附属合同中的有效期限*/
                for(int i = 0;i<prdList.size();i++){
                    if("1".equals(prdList.get(i).getIsValidFrom())){//判断是否是自激活起的产品 ： 自激活起 0-是 1-否
                        
                        if(prdList.get(i).getPrdBeginDate() != null&&frameAgreement.getBeginDate()!=null){
                            if(prdList.get(i).getPrdBeginDate().getTime()<frameAgreement.getBeginDate().getTime()){
                                prdList.get(i).setPrdBeginDate(frameAgreement.getBeginDate());
                            }
                        }else if(prdList.get(i).getPrdBeginDate() == null&&frameAgreement.getBeginDate()!=null){
                            prdList.get(i).setPrdBeginDate(frameAgreement.getBeginDate());
                        }
                        
                        if(prdList.get(i).getPrdEndDate() != null&&frameAgreement.getEndDate()!=null){
                            if(prdList.get(i).getPrdEndDate().getTime()>frameAgreement.getEndDate().getTime()){
                                prdList.get(i).setPrdEndDate(frameAgreement.getEndDate());
                            }
                        }else if(prdList.get(i).getPrdEndDate() == null&&frameAgreement.getEndDate()!=null){
                            prdList.get(i).setPrdEndDate(frameAgreement.getEndDate());
                        }
                        
                    }else if("0".equals(prdList.get(i).getIsValidFrom())){
                        if(frameAgreement.getBeginDate()!=null){//自激活起的产品，beginDate为空
                            prdList.get(i).setPrdBeginDate(frameAgreement.getBeginDate());
                        }
                        
                        if(prdList.get(i).getActivationDeadline() != null&&frameAgreement.getEndDate()!=null){
                            if(prdList.get(i).getActivationDeadline().getTime()>frameAgreement.getEndDate().getTime()){
                                prdList.get(i).setPrdEndDate(frameAgreement.getEndDate());
                            }
                        }else if(prdList.get(i).getActivationDeadline() == null&&frameAgreement.getEndDate()!=null){
                            prdList.get(i).setPrdEndDate(frameAgreement.getEndDate());
                        }
                    }
                    
                    for(int j = 0;j<prdAgreementPrdinfoList.size();j++){
                        if(prdAgreementPrdinfoList.get(j).getPrdId().equals(prdList.get(i).getId())){
                            prdAgreementPrdinfoList.get(j).setBeginTime(prdList.get(i).getPrdBeginDate());
                            prdAgreementPrdinfoList.get(j).setEndTime(prdList.get(i).getPrdEndDate());
                            break;
                        }
                    }
                }
                
                map.put("prdSubAgreement", prdSubAgreement);
            }else if("2".equals(frameAgreement.getClinicType())){
                prdSubAgreement = new PrdSubAgreement();
                map.put("prdSubAgreement", prdSubAgreement);
            }
            
            map.put("prdAgreementClinicList", prdAgreementClinicList);
            map.put("prdAgreementPrdinfoList", prdAgreementPrdinfoList);
            
            jr.setResult(map);
            jr.setStatus(JsonResponse.Status.SUCCESS);
        }catch(Exception e){
            logger.error("根据ID获取单个附属合同失败,FrameAgreementId="+subAgreementId,e);
            e.printStackTrace();
            jr.setErrorMsg("根据ID获取单个附属合同失败,FrameAgreementId="+subAgreementId);
            jr.setStatus(Status.ERROR);
        }
        
        return jr;
    }
    
    @Override
    public JsonResponse<List<AddressInfo>> findClinicCity(String clinicId) {

        JsonResponse<List<AddressInfo>> jr = new JsonResponse<List<AddressInfo>>();
        try{
            List<AddressInfo> cityList = addressInfoMapper.getCityListByParentAccountId(clinicId);
            jr.setResult(cityList);
            jr.setStatus(Status.SUCCESS);
        }catch(Exception e){
            e.printStackTrace();
            logger.error("获取总账号下子诊所诊所城市列表失败",e);
            jr.setStatus(Status.ERROR);
        }
        
        return jr;
    }

    @Override
    public JsonResponse<List<VOPrdSubAgreementClinic>> findSubClinicList(Map<String, Object> map) {
        JsonResponse<List<VOPrdSubAgreementClinic>> jr = new JsonResponse<List<VOPrdSubAgreementClinic>>();
        try{
            List<VOPrdSubAgreementClinic> subClinicList =  prdAgreementClinicMapper.findSubClinicList(map);
            jr.setStatus(Status.SUCCESS);
            jr.setResult(subClinicList);
        }catch(Exception e){
            jr.setStatus(Status.ERROR);
            logger.error("附属合同获取子诊所失败",e);
        }
        return jr;
    }

    @Override
    public JsonResponse<List<PrdInfo>> findPrdInfoList(Map<String, Object> map) {
        
        JsonResponse<List<PrdInfo>> jr = new JsonResponse<List<PrdInfo>>();
        String param = "";
        try{
            
            PrdInfoExample example = new PrdInfoExample();
            PrdInfoExample.Criteria criteria = example.createCriteria();
            criteria.andStatusEqualTo("0");//上线产品
            criteria.andPlatformFlagEqualTo("0");//平台创建
            
            if(map.containsKey("prdTypeName")){
                param = param + "prdTypeName:" + map.get("prdTypeName").toString()+",";
                criteria.andPrdTypeNameEqualTo(map.get("prdTypeName").toString());
            }
            
            if(map.containsKey("couponName")){
                
                param = param + "couponName:" + map.get("couponName").toString()+",";
                
                criteria.andCouponNameLike(map.get("couponName").toString());
            }
            List<PrdInfo> prdInfoList = prdInfoMapper.selectByExample(example);
            
            /*--start 获取诊所创建的产品--*/
            List<PrdInfo> prdInfoByClinicCreate = new ArrayList<PrdInfo>();
            if(map.containsKey("clinicId")){
                
                param = param + "clinicId:" + map.get("clinicId").toString();
                
                PrdInfoExample example1 = new PrdInfoExample();
                PrdInfoExample.Criteria criteria1 = example1.createCriteria();
                criteria1.andClinicIdEqualTo(map.get("clinicId").toString());
                prdInfoByClinicCreate = prdInfoMapper.selectByExample(example1);
                criteria.andClinicIdEqualTo(map.get("clinicId").toString());
            }
            prdInfoList.addAll(prdInfoByClinicCreate);
            /*--end 获取诊所创建的产品--*/
            
            logger.info("查询产品信息，param = "+param);
            
            FrameAgreement frameAgreement = new FrameAgreement();
            logger.info("开始获取产品列表,agreementId============");
            if(map.containsKey("agreementId")){
                logger.info("开始获取产品列表,agreementId="+map.get("agreementId").toString());
                frameAgreement = frameAgreementMapper.findById(map.get("agreementId").toString());
            }
            
            //附属合同产品可选的服务期限要在产品有效期和框架合同有效期的交集之内
            //例如:产品有效期2017.1.1~2017.2.1,框架合同有效期 2016.12.1~2017.1.20,则该产品在附属合同可选的有效期为2017.1.1~2017.1.20
            //如果产品有效期是无限期，则该产品在附加合同的有效期是框架合同有效期
            for(int i = 0;i<prdInfoList.size();i++){
                if("1".equals(prdInfoList.get(i).getIsValidFrom())){//判断是否是自激活起的产品 ： 自激活起 0-是 1-否
                    
                    if(prdInfoList.get(i).getPrdBeginDate() != null&&frameAgreement.getBeginDate()!=null){
                        if(prdInfoList.get(i).getPrdBeginDate().getTime()<frameAgreement.getBeginDate().getTime()){
                            prdInfoList.get(i).setPrdBeginDate(frameAgreement.getBeginDate());
                        }
                    }else if(prdInfoList.get(i).getPrdBeginDate() == null&&frameAgreement.getBeginDate()!=null){
                        prdInfoList.get(i).setPrdBeginDate(frameAgreement.getBeginDate());
                    }
                    
                    if(prdInfoList.get(i).getPrdEndDate() != null&&frameAgreement.getEndDate()!=null){
                        if(prdInfoList.get(i).getPrdEndDate().getTime()>frameAgreement.getEndDate().getTime()){
                            prdInfoList.get(i).setPrdEndDate(frameAgreement.getEndDate());
                        }
                    }else if(prdInfoList.get(i).getPrdEndDate() == null&&frameAgreement.getEndDate()!=null){
                        prdInfoList.get(i).setPrdEndDate(frameAgreement.getEndDate());
                    }
                    
                }else if("0".equals(prdInfoList.get(i).getIsValidFrom())){
                    if(frameAgreement.getBeginDate()!=null){//自激活起的产品，beginDate为空
                        prdInfoList.get(i).setPrdBeginDate(frameAgreement.getBeginDate());
                    }
                    
                    if(prdInfoList.get(i).getActivationDeadline() != null&&frameAgreement.getEndDate()!=null){
                        if(prdInfoList.get(i).getActivationDeadline().getTime()>frameAgreement.getEndDate().getTime()){
                            prdInfoList.get(i).setPrdEndDate(frameAgreement.getEndDate());
                        }
                    }else if(prdInfoList.get(i).getActivationDeadline() == null&&frameAgreement.getEndDate()!=null){
                        prdInfoList.get(i).setPrdEndDate(frameAgreement.getEndDate());
                    }
                }
            }
            
            jr.setResult(prdInfoList);
            jr.setStatus(Status.SUCCESS);
        }catch(Exception e){
            logger.error("获取失败产品列表失败",e);
            jr.setStatus(Status.ERROR);
        }
        return jr;
    }
    
    @Override
    public JsonResponse<Map<String,Object>> findSubAgreementPrdList(Map<String,Object> map){
        
        JsonResponse<Map<String,Object>> jr = new JsonResponse<Map<String,Object>>();
        Map<String,Object> resultMap = new HashMap<String,Object>();
        try{
            Map<String,Object> prdSubMap = new HashMap<String,Object>();
            if(map.containsKey("agreementId")){
                String agreementId = map.get("agreementId").toString();
                prdSubMap.put("agreementId", agreementId);
                prdSubMap.put("delFlag","0");
            }else{
                jr.setStatus(Status.ERROR);
                jr.setErrorMsg("agreementId为空");
                return jr;
            }
            List<PrdSubAgreement> prdSubAgreementsList = prdSubAgreementMapper.findByProperties(prdSubMap);
            List<PrdAgreementPrdinfo> subAgreementsPrdInfoList = prdAgreementPrdinfoMapper.findByProperties(prdSubMap);
            
            resultMap.put("prdSubAgreementsList",prdSubAgreementsList);
            resultMap.put("subAgreementsPrdInfoList",subAgreementsPrdInfoList);
            jr.setResult(resultMap);
            jr.setStatus(Status.SUCCESS);
            
        }catch(Exception e){
            jr.setStatus(Status.ERROR);
            jr.setErrorMsg("查询附属合同列表失败");
            logger.error("查询附属合同列表失败");
            return jr;
        }
        return jr;
    }

	@Override
	public JsonResponse<List<Map<String, Object>>> findSubAgreementInfoList(Map<String, Object> map) {
	    
		JsonResponse<List<Map<String, Object>>> jr = new JsonResponse<List<Map<String, Object>>>();
        List<Map<String,Object>> mapList = new ArrayList<Map<String,Object>>();
        try{
            Map<String,Object> prdSubMap = new HashMap<String,Object>();
            if(map.containsKey("agreementId")){
                String agreementId = map.get("agreementId").toString();
                prdSubMap.put("agreementId", agreementId);
                prdSubMap.put("delFlag","0");
            }else{
                jr.setStatus(Status.ERROR);
                jr.setErrorMsg("agreementId为空");
                return jr;
            }

            List<PrdSubAgreement> prdSubAgreementsList = prdSubAgreementMapper.findByProperties(prdSubMap);
            
            //子合同的产品信息列表
            List<PrdAgreementPrdFullInfo> prdList = new ArrayList<PrdAgreementPrdFullInfo>();
            
            //子合同的诊所信息列表
            List<PrdAgreementClinic> prdAgreementClinicList = new ArrayList<PrdAgreementClinic>();
            //获取子合同的诊所信息和产品信息
            if(prdSubAgreementsList!=null ){
            	for(PrdSubAgreement sub : prdSubAgreementsList){
            		
            	    Map<String,Object> itemMap = new HashMap<String,Object>();
            		String subId = sub.getId();
            		Map<String,Object> subParam = new HashMap<String, Object>();
            		subParam.put("subAgreementId", subId);
            		subParam.put("delFlag","0");
            		
            	    prdList = prdAgreementPrdinfoMapper.findByPropertiesWithFullInfo(subParam);
            		     		
            		prdAgreementClinicList = prdAgreementClinicMapper.findByProperties(subParam);
            		
            		itemMap.put("agreement", sub);
            		itemMap.put("clinics", prdAgreementClinicList);
            		itemMap.put("prds", prdList);
            		mapList.add(itemMap);
            	}
            }
            
            jr.setResult(mapList);
            jr.setStatus(Status.SUCCESS);
            
        }catch(Exception e){
            jr.setStatus(Status.ERROR);
            jr.setErrorMsg("查询附属合同列表失败");
            logger.error("查询附属合同列表失败",e);
            e.printStackTrace();
            return jr;
        }
        return jr;
	}

	@Override
	public JsonResponse<List<PrdAgreementPrdFullInfo>> findSubAgreementPrdFullList(Map<String, Object> map) {
		JsonResponse<List<PrdAgreementPrdFullInfo>> jr = new JsonResponse<List<PrdAgreementPrdFullInfo>>();
		try{
			List<PrdAgreementPrdFullInfo> prdList = prdAgreementPrdinfoMapper.findByPropertiesWithFullInfo(map);
			jr.setResult(prdList);
		}catch(Exception e){
			 jr.setStatus(Status.ERROR);
	         jr.setErrorMsg("查询合同产品列表失败");
	         logger.error("查询合同产品列表失败");
		}
		return jr;
	}
	
	@Override
	public JsonResponse<Map<String,Object>> findSettlementRatio(Map<String, Object> map){
	    
	    JsonResponse<Map<String,Object>> jr = new JsonResponse<Map<String,Object>>();
	    
	    try{
	        String productId = "";
            if(map.containsKey("productId")){
                productId = map.get("productId").toString();
            }
	        if(StringUtils.isBlank(productId)){
	            logger.error("获取产品结算比例失败,productId为空");
	            jr.setStatus(Status.ERROR);
	            jr.setErrorMsg("获取产品结算比例失败,productId为空");
	            return jr;
	        }
	        
	        String subAgreementId = "";
	        if(map.containsKey("subAgreementId")){
	            subAgreementId = map.get("subAgreementId").toString();
	        }
	        
	        //获取从附属合同创建的比例
	        List<PrdRatioSettlement> prductRatioList = new ArrayList<PrdRatioSettlement>();
	        if(StringUtils.isNotBlank(subAgreementId)){
	            Map<String,Object> paramMap = new HashMap<String,Object>();
	            paramMap.put("productId", productId);
	            paramMap.put("subAgreementId", subAgreementId);
	            paramMap.put("sourceFlag", "1");//来源是附属合同
	            paramMap.put("delFlag", "0");
	            prductRatioList = prdRatioSettlementMapper.findByProperties(paramMap);
	        }
	        
	        //如果来源是附属合同的比例结算为空，则获取产品创建的比例结算
	        if(prductRatioList == null || prductRatioList.size()<1){
	            Map<String,Object> paramMap = new HashMap<String,Object>();
	            paramMap.put("productId", productId);
	            paramMap.put("sourceFlag", "0");//来源是附属合同
	            paramMap.put("delFlag", "0");
	            prductRatioList = prdRatioSettlementMapper.findByProperties(paramMap);
	        }
	        
	        Collections.sort(prductRatioList, new Comparator<PrdRatioSettlement>() {
	            public int compare(PrdRatioSettlement arg0, PrdRatioSettlement arg1) {

	                int flag = 0;
	                int sqe0 = Integer.valueOf(arg0.getSequence());
	                int sqe1 = Integer.valueOf(arg1.getSequence());
	                flag = sqe0-sqe1;
	                
	                return flag; 
	            }
	        });
	        
	        map.put("prductRatioList", prductRatioList);
	        jr.setResult(map);
	        jr.setStatus(Status.SUCCESS);
	    }catch(Exception e){
	        logger.error("获取产品结算比例失败",e);
	        jr.setStatus(Status.ERROR);
	        jr.setErrorMsg("获取产品结算比例失败");
	    }
	    
	    return jr;
	}
	
	@Override
	public JsonResponse<List<PrdClinicConfig>> findClinicConfig(String prdId,String subAgreementId){
	    
	    JsonResponse<List<PrdClinicConfig>> jr = new JsonResponse<List<PrdClinicConfig>>();
	    
	    try{
	        logger.info("开始查询诊所预约配置,prdId="+prdId+",subAgreementId="+subAgreementId);
	        if(StringUtils.isBlank(prdId)){
	            logger.error("获取诊所配置失败,prdId为空");
	            jr.setStatus(Status.ERROR);
	            jr.setErrorMsg("获取诊所配置失败,prdId为空");
	            
	            return jr;
	        }
	        
	        List<PrdClinicConfig> clinicConfigList = new ArrayList<PrdClinicConfig>();
	        
	        Map<String,Object> map = new HashMap<String,Object>();
	        map.put("productId", prdId);
	        map.put("delFlag", "0");
	        if(StringUtils.isNotBlank(subAgreementId)){
	            map.put("subAgreementId", subAgreementId);
	            map.put("sourceFlag", "1");
	            clinicConfigList = prdClinicConfigMapper.findByProperties(map);
	        }
	        
	        if(clinicConfigList == null||clinicConfigList.size()<1){
	            map.remove("subAgreementId");
	            map.put("sourceFlag", "0");
	            clinicConfigList = prdClinicConfigMapper.findByProperties(map);
	        }
	        
	        jr.setResult(clinicConfigList);
	        jr.setStatus(Status.SUCCESS);
	    }catch(Exception e){
	        logger.error("获取诊所配置失败");
            jr.setStatus(Status.ERROR);
            jr.setErrorMsg("获取诊所配置失败");
            
            return jr;
	    }
	    
        return jr;
	}
	
	
	
}
