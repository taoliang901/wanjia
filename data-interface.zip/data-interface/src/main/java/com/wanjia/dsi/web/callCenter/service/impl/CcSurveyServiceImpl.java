package com.wanjia.dsi.web.callCenter.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONWriter.State;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.ThreadLocalContext;
import com.wanjia.dsi.web.callCenter.dao.mapper.CcSurveyMapper;
import com.wanjia.dsi.web.callCenter.model.CcSurvey;
import com.wanjia.dsi.web.callCenter.service.CcSurveyService;


/**
 * This element is automatically generated on 16-8-5 上午11:17, do not modify. <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class CcSurveyServiceImpl implements CcSurveyService {
	@Autowired
    private CcSurveyMapper ccSurveyMapper;
    
    
    
    @Override
    @Transactional(readOnly=true)
    public CcSurvey findById(String id) {
        return (CcSurvey)ccSurveyMapper.findById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findWithPagination(int offset, int count) {
        return (List<CcSurvey>)ccSurveyMapper.findWithPagination(offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findAll() {
        return (List<CcSurvey>)ccSurveyMapper.findAll();
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByEntity(CcSurvey model) {
        return (List<CcSurvey>)ccSurveyMapper.findByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByEntityWithPagination(CcSurvey model, int offset, int count) {
        return (List<CcSurvey>)ccSurveyMapper.findByEntityWithPagination(model,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public CcSurvey findOneByEntity(CcSurvey model) {
        return (CcSurvey)ccSurveyMapper.findOneByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByProperty(String propertyName, String propertyValue) {
        return (List<CcSurvey>)ccSurveyMapper.findByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public CcSurvey findOneByProperty(String propertyName, String propertyValue) {
        return (CcSurvey)ccSurveyMapper.findOneByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
        return (List<CcSurvey>)ccSurveyMapper.findByPropertyWithPagination(propertyName,propertyValue,offset,count);
    }

    @Override
    @Transactional(readOnly=true)
    public List<CcSurvey> findByProperties(Map<String, Object> map) {
        return (List<CcSurvey>)ccSurveyMapper.findByProperties(map);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByEntity(CcSurvey model) {
        return (long)ccSurveyMapper.countByEntity(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperty(String propertyName, String propertyValue) {
        return (long)ccSurveyMapper.countByProperty(propertyName,propertyValue);
    }

    @Override
    @Transactional(readOnly=true)
    public long countByProperties(Map<String, Object> map) {
        return (long)ccSurveyMapper.countByProperties(map);
    }

    @Override
    public void update(CcSurvey model) {
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        ccSurveyMapper.update(model);
    }

    @Override
    public void insert(CcSurvey model) {
        model.setCreateUser(ThreadLocalContext.getSystemUserId());
        model.setCreateDate(new Date());
        ccSurveyMapper.insert(model);
    }

    @Override
    public void deleteByEntity(CcSurvey model) {
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        this.update(model);
    }

    @Override
    public void deleteByProperty(String propertyName, String propertyValue) {
        ccSurveyMapper.deleteByProperty(propertyName,propertyValue);
    }

    @Transactional(readOnly=true)
    public long countAll() {
        return this.ccSurveyMapper.countAll();
    }

    public void insertBatch(List<CcSurvey> list) {
        this.ccSurveyMapper.insertBatch(list);
    }

    public void delete(String id) {
        CcSurvey model = new CcSurvey();
        model.setDelFlag("1");
        model.setModifyUser(ThreadLocalContext.getSystemUserId());
        model.setModifyDate(new Date());
        model.setId(String.valueOf(id));
        this.ccSurveyMapper.update(model);
    }
    
    
    

   
    @Override
    public List<CcSurvey> findSurveyList(Map<String,Object> map){
        return ccSurveyMapper.findSurveyList(map);
    }
    
   
  
	@Override
	public JsonResponse<CcSurvey> findOvertimeSurvey() {
		JsonResponse<CcSurvey> res = new JsonResponse<CcSurvey>();
		try{
			List<CcSurvey> ccSurveys = ccSurveyMapper.findOvertimeSurvey();
			if (ccSurveys!=null&&ccSurveys.size()>0){
				res.setResult(ccSurveys.get(0));
				res.setStatus(Status.SUCCESS);
			}else{
				res.setErrorMsg("获取超时问卷信息失败");
			}
		}catch(Exception e){
			e.printStackTrace();
			res.setErrorMsg("获取超时问卷信息失败");
		}
		return res;
	}
     
}