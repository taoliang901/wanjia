package com.wanjia.dsi.web.cms.activity.service.impl;

import java.util.Date;
import java.util.List;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.integral.service.UserIntegralLogService;
import com.wanjia.dsi.integral.util.IntegralConst;
import com.wanjia.dsi.integral.util.IntegralEvent;
import com.wanjia.dsi.web.cms.activity.model.InfomationStatistcBO;
import com.wanjia.dsi.web.cms.activity.model.VOInfomationStatistc;
import com.wanjia.dsi.web.cms.activity.repository.InfomationStatistcRepository;
import com.wanjia.dsi.web.cms.activity.service.InfomationStatistcService;
@Service
@com.alibaba.dubbo.config.annotation.Service
public class InfomationStatistcServiceImpl implements InfomationStatistcService{
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	InfomationStatistcRepository repository;
	
	@Autowired
	private UserIntegralLogService userIntegralLogService;
	
	@Override
	public JsonResponse<Void> insertOrUpdateInfomationStatistc(InfomationStatistcBO infomationStatistcBO) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		try {
			String infoId = infomationStatistcBO.getInfoId();
			String type = infomationStatistcBO.getType();
			logger.info("InfomationStatistcServiceImpl->insertInfomationStatistc,infoId:" + infoId + ",type:" + type);
			if (StringUtils.isNotBlank(infoId) && StringUtils.isNotBlank(type)) {
				Date now = new Date();
				String rq = DateUtils.format(now, DateUtils.DATE_FORMAT_TYPE3);
				/*infomationStatistcBO.setUpdateTime(now);
				infomationStatistcBO.setUpdateDate(rq);*/
				Query query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
				//判断是否已经收藏
				boolean b = repository.exists(query, InfomationStatistcBO.class);
				if(b){//mongodb已经有该条数据，访问量加1
					Update update = new Update();
					update.inc("countNum", 1);//更新加1
					update.set("updateTime", now);
					update.set("updateDate", rq);
					repository.updateFirst(query, InfomationStatistcBO.class, update);
				}else{//没有需要插入新数据\
					infomationStatistcBO.setCountNum(1);
					repository.insert(infomationStatistcBO, InfomationStatistcBO.class);
				}
				result.setStatus(Status.SUCCESS);

				if (!StringUtils.isEmpty(infomationStatistcBO.getUserId())) {
					try {
						// 阅读，插入积分记录
						userIntegralLogService.insert(infomationStatistcBO.getUserId(), IntegralEvent.READER,
								IntegralConst.TABLE_NAME_INFOMATION_STATISTC, infoId, null,
								infomationStatistcBO.getClientType());
					} catch (Exception ex) {
						logger.error("阅读成功，插入积分记录异常" + ex);
					}
				}
			} else {
				logger.error("InfomationStatistcServiceImpl->insertInfomationStatistc: infoId or type is null");
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.IllegalArgument.getCode());
				result.setErrorMsg(ErrorType.IllegalArgument.getDesc());
			}
		} catch (Exception e) {
			logger.error("InfomationStatistcServiceImpl->insertInfomationStatistc,infoId:" + infomationStatistcBO.getInfoId());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<PageInfo<InfomationStatistcBO>> getInfomationStatistic(VOInfomationStatistc voInfomationStatistc) {
		JsonResponse<PageInfo<InfomationStatistcBO>> result = new JsonResponse<PageInfo<InfomationStatistcBO>>();
		String infoId = voInfomationStatistc.getInfoId();
		String type = voInfomationStatistc.getType();
		String pageNo = voInfomationStatistc.getPageNo();
		String pageSize = voInfomationStatistc.getPageSize();
		logger.info("InfomationStatistcServiceImpl->getInfomationStatistic,infoId:" + infoId + ",type:" + type);
		try{
				// 设置分页参数
				if (StringUtils.isBlank(pageNo)) {
					pageNo = "1";
				}
				// 设置分页参数
				if (StringUtils.isBlank(pageSize)) {
					pageSize = "10";
				}
				PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));
				Query query;
				if(StringUtils.isNotBlank(infoId)){
					query = new Query(Criteria.where("infoId").is(infoId).andOperator(Criteria.where("type").is(type)));
				}else{
					query = new Query(Criteria.where("type").is(type));
				}
				List<InfomationStatistcBO> infomationList = repository.find(query, InfomationStatistcBO.class);
				PageInfo<InfomationStatistcBO> page = new PageInfo<InfomationStatistcBO>(infomationList);
				result.setResult(page);
				result.setStatus(Status.SUCCESS);	
		}catch(Exception e){
			logger.error("InfomationStatistcServiceImpl->getInfomationStatistic,infoId:" + voInfomationStatistc.getInfoId());
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
}
