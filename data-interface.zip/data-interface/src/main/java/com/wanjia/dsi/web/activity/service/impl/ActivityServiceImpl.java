package com.wanjia.dsi.web.activity.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.common.utils.Assert;
import com.wanjia.common.utils.DateUtils;
import com.wanjia.dsi.base.service.impl.BaseServiceImpl;
import com.wanjia.dsi.common.error.ErrorType;
import com.wanjia.dsi.integral.service.UserIntegralLogService;
import com.wanjia.dsi.integral.util.IntegralConst;
import com.wanjia.dsi.integral.util.IntegralEvent;
import com.wanjia.dsi.web.activity.dao.mapper.ActivityMapper;
import com.wanjia.dsi.web.activity.dao.mapper.ActivityStaticMapper;
import com.wanjia.dsi.web.activity.dao.mapper.WjkmjDetailMapper;
import com.wanjia.dsi.web.activity.dao.mapper.WzSpecialMapper;
import com.wanjia.dsi.web.activity.model.Activity;
import com.wanjia.dsi.web.activity.model.ActivityClickBO;
import com.wanjia.dsi.web.activity.model.ActivityStatic;
import com.wanjia.dsi.web.activity.model.CmsPageConfig;
import com.wanjia.dsi.web.activity.model.VOActivity;
import com.wanjia.dsi.web.activity.model.WjkmjDetail;
import com.wanjia.dsi.web.activity.model.WzSpecial;
import com.wanjia.dsi.web.activity.repository.ActivityClickRepository;
import com.wanjia.dsi.web.activity.service.ActivityService;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VOActivityMapper;
import com.wanjia.dsi.web.cms.activity.model.InfomationStatistcBO;
import com.wanjia.dsi.web.cms.activity.model.MyCollectionStatisticsBO;
import com.wanjia.dsi.web.cms.activity.service.InfomationService;
import com.wanjia.dsi.web.cms.activity.service.MycollectionService;
import com.wanjia.dsi.web.elasticsearch.info.service.ElasticsearchInforService;

/**
 * This element is automatically generated on 16-3-1 ����3:16, do not modify.
 * <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class ActivityServiceImpl extends BaseServiceImpl implements ActivityService {
	@Autowired
	private ActivityMapper activityMapper;
	@Autowired
	private VOActivityMapper voActivityMapper;

	@Autowired
	private WzSpecialMapper wzSpecialMapper;

	@Autowired
	private WjkmjDetailMapper wjkmjDetailMapper;
	
	@Autowired
	private ActivityStaticMapper activityStaticMapper;
	
	@Autowired
	private ActivityClickRepository activityClickRepository;
	
	@Autowired
	private ElasticsearchInforService elasticsearchInforService;
	
	@Autowired
	private UserIntegralLogService userIntegralLogService;
	
	@Autowired
	private InfomationService infomationService;
	
	@Autowired
	private MycollectionService mycollectionService;
	
	@Override
	public Activity findById(Long id) {
		return (Activity) activityMapper.findById(id);
	}

	@Override
	public List<Activity> findWithPagination(int offset, int count) {
		return (List<Activity>) activityMapper.findWithPagination(offset, count);
	}

	@Override
	public List<Activity> findAll() {
		return (List<Activity>) activityMapper.findAll();
	}

	@Override
	public List<Activity> findByEntity(Activity model) {
		return (List<Activity>) activityMapper.findByEntity(model);
	}

	@Override
	public List<Activity> findByEntityWithPagination(Activity model, int offset, int count) {
		return (List<Activity>) activityMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	public Activity findOneByEntity(Activity model) {
		return (Activity) activityMapper.findOneByEntity(model);
	}

	@Override
	public List<Activity> findByProperty(String propertyName, String propertyValue) {
		return (List<Activity>) activityMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	public Activity findOneByProperty(String propertyName, String propertyValue) {
		return (Activity) activityMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	public List<Activity> findByPropertyWithPagination(String propertyName, String propertyValue, int offset, int count) {
		return (List<Activity>) activityMapper.findByPropertyWithPagination(propertyName, propertyValue, offset, count);
	}

	@Override
	public List<Activity> findByProperties(Map<String, Object> map) {
		return (List<Activity>) activityMapper.findByProperties(map);
	}

	@Override
	public long countByEntity(Activity model) {
		return (long) activityMapper.countByEntity(model);
	}

	@Override
	public long countByProperty(String propertyName, String propertyValue) {
		return (long) activityMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	public long countByProperties(Map<String, Object> map) {
		return (long) activityMapper.countByProperties(map);
	}

	@Override
	public void update(Activity model) {
		activityMapper.update(model);
	}

	@Override
	public void insert(Activity model) {
		activityMapper.insert(model);
	}

	@Override
	public void deleteByEntity(Activity model) {
		activityMapper.deleteByEntity(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		activityMapper.deleteByProperty(propertyName, propertyValue);
	}

	public long countAll() {
		return this.activityMapper.countAll();
	}

	public void insertBatch(List<Activity> list) {
		this.activityMapper.insertBatch(list);
	}

	public void delete(Long id) {
		this.activityMapper.deleteById(id);
	}

	/*
	 * <p>Title: getActivityList</p> <p>Description: </p>
	 * 
	 * @param map
	 * 
	 * @return
	 * 
	 * @see
	 * com.wanjia.dsi.web.banner.service.ActivityService#getActivityList(java.
	 * util.Map)
	 */
	@Override
	public JsonResponse<PageInfo<Activity>> getActivityListByPageInfo(String requestId, String pageConfigId, String pageNo, String pageSize) {
		// TODO Auto-generated method stub
		JsonResponse<PageInfo<Activity>> result = new JsonResponse<PageInfo<Activity>>();
		Map<String, Object> parameterMap = new HashMap<String, Object>();
		List<Activity> findAll = null;
		try {
			// this.checkParams(pageName,activityTypeName);
			Map<String, String> pageNoAndPageSize = super.getPageNoAndPageSize(pageNo, pageSize);
			// 设置分页页号和页码
			PageHelper.startPage(Integer.parseInt(pageNoAndPageSize.get("pageNo")), Integer.parseInt(pageNoAndPageSize.get("pageSize")));
			//设置查询参数
			parameterMap.put("pageConfigId", pageConfigId);
			parameterMap.put("delFlag", "0");
			//查询
			findAll = activityMapper.getActivityListByPageInfo(parameterMap);
			// 获得分页信息
			PageInfo<Activity> page = new PageInfo<Activity>(findAll);
			List<Activity> activityList = page.getList();
			
			if(activityList != null && activityList.size() > 0){
				List<String> activityIds = new ArrayList<String>();
				for(Activity activityTmp:activityList){
					if(activityTmp != null && activityTmp.getActivityId() != null){
						activityIds.add(activityTmp.getActivityId());
					}
				}
				
				JsonResponse<List<InfomationStatistcBO>> infomationStatistcJr = infomationService.getInfomationStatistic("A", activityIds);
				JsonResponse<List<MyCollectionStatisticsBO>> myCollectionStatisticsBOJr = mycollectionService.getCollectionStatistic("A", activityIds);
				
				HashMap<String,Long> clickMap = new HashMap<String,Long>();
				HashMap<String,Long> collectMap = new HashMap<String,Long>();
				
				if(infomationStatistcJr != null && infomationStatistcJr.getResult() != null && infomationStatistcJr.getResult().size() > 0){
					for(InfomationStatistcBO clickBO : infomationStatistcJr.getResult()){
						clickMap.put(clickBO.getInfoId(), clickBO.getCountNum());
					}
				}
				
				if(myCollectionStatisticsBOJr != null && myCollectionStatisticsBOJr.getResult() != null && myCollectionStatisticsBOJr.getResult().size() > 0){
					for(MyCollectionStatisticsBO collectBO : myCollectionStatisticsBOJr.getResult()){
						collectMap.put(collectBO.getInfoId(), collectBO.getCountNum());
					}
				}
				
				for(Activity activityTmp:activityList){
					if(activityTmp != null && activityTmp.getActivityId() != null){
						if(clickMap.containsKey(activityTmp.getActivityId())){
							activityTmp.setActivityClickCount(clickMap.get(activityTmp.getActivityId()));
						}
						if(collectMap.containsKey(activityTmp.getActivityId())){
							activityTmp.setActivityCollectCount(collectMap.get(activityTmp.getActivityId()));
						}
					}
				}
				
				
//				//今天之前的累计数据
//				ActivityStaticExample activityStaticExample = new ActivityStaticExample();
//				activityStaticExample.createCriteria().andActivityIdIn(activityIds);
//				List<ActivityStatic> activityStaticList = activityStaticMapper.selectByExample(activityStaticExample);
//				HashMap<String,Integer> mysqlStaticMap = new HashMap<String,Integer>();
//				for(ActivityStatic activityStatic:activityStaticList){
//					if(activityStatic != null){
//						mysqlStaticMap.put(activityStatic.getActivityId(), activityStatic.getClickCount());
//					}
//				}
//				
//				//今天的点击累计
//				List<ActivityStatic> mogoClickList = activityClickRepository.getActivityClickCountListMongo(new Date(),activityIds);
//				HashMap<String,Integer> mogoStaticMap = new HashMap<String,Integer>();
//				for(ActivityStatic activityStatic:mogoClickList){
//					if(activityStatic != null){
//						mogoStaticMap.put(activityStatic.getActivityId(), activityStatic.getClickCount());
//					}
//				}
//				
//				if(!mysqlStaticMap.isEmpty()){
//					for(Activity activityTmp:activityList){
//						if(activityTmp != null && mysqlStaticMap.containsKey(activityTmp.getActivityId())){
//							activityTmp.setActivityClickCount(activityTmp.getActivityClickCount() + mysqlStaticMap.get(activityTmp.getActivityId()));
//						}
//					}
//				}
//				
//				if(!mogoStaticMap.isEmpty()){
//					for(Activity activityTmp:activityList){
//						if(activityTmp != null && mogoStaticMap.containsKey(activityTmp.getActivityId())){
//							activityTmp.setActivityClickCount(activityTmp.getActivityClickCount() + mogoStaticMap.get(activityTmp.getActivityId()));
//						}
//					}
//				}
			}
			
			page.setList(activityList);
			
			result.setResult(page);
			result.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}

	@Override
	public JsonResponse<Activity> getActivityListById(String requestId, String activityId) {
		// TODO Auto-generated method stub
		JsonResponse<Activity> result = new JsonResponse<Activity>();
		Assert.notNull(activityId);
		try {
			//查询
			Activity findById = (Activity) activityMapper.findById(activityId);
			if(findById == null){
				result.setStatus(Status.ERROR);
				result.setErrorMsg("该资讯已删除，请刷新列表重试！");
				return result;
			}
//			//今天之前的累计数据
//			ActivityStaticExample activityStaticExample = new ActivityStaticExample();
//			activityStaticExample.createCriteria().andActivityIdEqualTo(activityId);
//			List<ActivityStatic> activityStaticList = activityStaticMapper.selectByExample(activityStaticExample);
//			if(activityStaticList != null && activityStaticList.size() > 0){
//				if(activityStaticList.get(0) != null){
//					findById.setActivityClickCount(activityStaticList.get(0).getClickCount());
//				}
//			}
//			
//			//今天的点击累计
//			List<String> activityIds = new ArrayList<String>();
//			activityIds.add(activityId);
//			List<ActivityStatic> mogoClickList = activityClickRepository.getActivityClickCountListMongo(new Date(),activityIds);
//			if(mogoClickList != null && mogoClickList.size() > 0){
//				if(mogoClickList.get(0) != null){
//					findById.setActivityClickCount(findById.getActivityClickCount() + mogoClickList.get(0).getClickCount());
//				}
//			}
//			findById.setActivityClickCount(findById.getActivityClickCount() + 5000); //阅读量增加5000，以后调整可删除
			
			List<String> activityIds = new ArrayList<String>();
			activityIds.add(activityId);
			
			JsonResponse<List<InfomationStatistcBO>> infomationStatistcJr = infomationService.getInfomationStatistic("A", activityIds);
			JsonResponse<List<MyCollectionStatisticsBO>> myCollectionStatisticsBOJr = mycollectionService.getCollectionStatistic("A", activityIds);
			
			HashMap<String,Long> clickMap = new HashMap<String,Long>();
			HashMap<String,Long> collectMap = new HashMap<String,Long>();
			
			if(infomationStatistcJr != null && infomationStatistcJr.getResult() != null && infomationStatistcJr.getResult().size() > 0){
				for(InfomationStatistcBO clickBO : infomationStatistcJr.getResult()){
					clickMap.put(clickBO.getInfoId(), clickBO.getCountNum());
				}
			}
			
			if(myCollectionStatisticsBOJr != null && myCollectionStatisticsBOJr.getResult() != null && myCollectionStatisticsBOJr.getResult().size() > 0){
				for(MyCollectionStatisticsBO collectBO : myCollectionStatisticsBOJr.getResult()){
					collectMap.put(collectBO.getInfoId(), collectBO.getCountNum());
				}
			}
			
			if(clickMap.containsKey(findById.getActivityId())){
				findById.setActivityClickCount(clickMap.get(findById.getActivityId()));
			}
			if(collectMap.containsKey(findById.getActivityId())){
				findById.setActivityCollectCount(collectMap.get(findById.getActivityId()));
			}
			
			result.setResult(findById);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}

	@Override
	public JsonResponse<List<CmsPageConfig>> getCmsPageInfoListById(String requestId, String pageConfigId, String pageId, String activityTypeId) {
		JsonResponse<List<CmsPageConfig>> result = new JsonResponse<List<CmsPageConfig>>();
		CmsPageConfig cmsPageConfig = new CmsPageConfig();
		try {
			//设置参数 start
			if (StringUtils.isNotBlank(pageConfigId)) {
				cmsPageConfig.setPageConfigId(pageConfigId);
			}
			if (StringUtils.isNotBlank(pageId)) {
				cmsPageConfig.setPageId(pageId);
			}
			if (StringUtils.isNotBlank(activityTypeId)) {
				cmsPageConfig.setActivityTypeId(activityTypeId);
			}
			
			cmsPageConfig.setDelFlag("0");
			//设置参数 end
			//查询并返回
			result.setResult(activityMapper.getCmsPageInfo(cmsPageConfig));
			result.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}
	@Override
	public Map<String, String> getpageConfigMap(String pageConfigId, String pageId, String activityTypeId) {
		Map<String, String> result = new HashMap<String, String>();
		CmsPageConfig cmsPageConfig = new CmsPageConfig();
		if (StringUtils.isNotBlank(pageConfigId)) {
			cmsPageConfig.setPageConfigId(pageConfigId);
		}
		if (StringUtils.isNotBlank(pageId)) {
			cmsPageConfig.setPageId(pageId);
		}
		if (StringUtils.isNotBlank(activityTypeId)) {
			cmsPageConfig.setActivityTypeId(activityTypeId);
		}
		cmsPageConfig.setDelFlag("0");
		List<CmsPageConfig> list = activityMapper.getCmsPageInfo(cmsPageConfig);
		for (CmsPageConfig c : list) {
			result.put(c.getPageConfigId(), c.getPageConfigName());
		}
		return result;
	}
	
	@Override
	public JsonResponse<PageInfo<Activity>> getInformationListForApp(String pageNo, String pageSize) {
		// TODO Auto-generated method stub

		JsonResponse<PageInfo<Activity>> result = new JsonResponse<PageInfo<Activity>>();
		try {
			//设置参数 
			if (StringUtils.isBlank(pageNo)) {
				pageNo = "1";
			}
			if (StringUtils.isBlank(pageSize)) {
				pageSize = "10";
			}
			// 设置分页页号和页码
			PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));
			List<Activity> informationListForApp = activityMapper.getInformationListForApp();
			// 获得分页信息
			PageInfo<Activity> page = new PageInfo<Activity>(informationListForApp);
			result.setResult(page);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}

		return result;
	}

	@Override
	public JsonResponse<PageInfo<WzSpecial>> getWzSpecialList(WzSpecial wzSpecial) {
		// TODO Auto-generated method stub
		JsonResponse<PageInfo<WzSpecial>> result = new JsonResponse<PageInfo<WzSpecial>>();

		try {
			// 设置参数
			if (wzSpecial == null) {
				wzSpecial = new WzSpecial();
			}
			wzSpecial.setDelFlag("0");
			// 设置分页页号和页码
			PageHelper.startPage(Integer.parseInt(wzSpecial.getPageNo()), Integer.parseInt(wzSpecial.getPageSize()));
			// 获得分页信息
			result.setResult(new PageInfo<WzSpecial>(wzSpecialMapper.findByEntity(wzSpecial)));

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ActivityServiceImpl----getWzSpecialList",e);
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;

	}

	@SuppressWarnings("rawtypes")
	@Override
	public JsonResponse updateSpecialStatus() {
		JsonResponse jr = new JsonResponse();
		activityMapper.updateSecialStatusUndo();
		activityMapper.updateSecialStatusDoing();
		activityMapper.updateSecialStatusDone();
		return jr;
	}

	@Override
	public JsonResponse<List<WjkmjDetail>> getList(WjkmjDetail wjkmjDetail) {

		JsonResponse<List<WjkmjDetail>> result = new JsonResponse<List<WjkmjDetail>>();
		try {
				
			//wjkmjDetailMapper
			if(wjkmjDetail == null){
				wjkmjDetail = new WjkmjDetail();
			}
			wjkmjDetail.setDelFlag("0");
			//查询并返回数据
			result.setResult(wjkmjDetailMapper.findByEntity(wjkmjDetail));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<List<Activity>> getActivitiListByPageAndType(String pageId, String activityTypeId, int limit) {
		JsonResponse<List<Activity>> result = new JsonResponse<List<Activity>>();
		try {
			if(StringUtils.isNotBlank(pageId) && StringUtils.isNotBlank(activityTypeId)){
				//查询数据
				List<Activity> activityList = activityMapper.getActivityListByPageAndType(pageId,activityTypeId,limit);
				result.setResult(activityList);
				result.setStatus(Status.SUCCESS);
			}else{
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg(ErrorType.SystemBusy.getDesc());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
	
	@Override
	public JsonResponse<List<Activity>> getActivityListByPageAndTypeBClient(String pageId, String activityTypeId, int limit) {
		JsonResponse<List<Activity>> result = new JsonResponse<List<Activity>>();
		try {
			if(StringUtils.isNotBlank(pageId) && StringUtils.isNotBlank(activityTypeId)){
				//查询数据
				List<Activity> activityList = activityMapper.getActivityListByPageAndTypeBClient(pageId,activityTypeId,limit);
				result.setResult(activityList);
			}else{
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.SystemBusy.getCode());
				result.setErrorMsg(ErrorType.SystemBusy.getDesc());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<Void> insertActivityClick(String activityId, String source) {
		return this.insertActivityClick(activityId, source, null, null);
	}

	@Override
	public JsonResponse<Void> insertActivityClick(String activityId, String source, String userId, String clientType) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		try {
			if (StringUtils.isNotBlank(activityId) && StringUtils.isNotBlank(source)) {
				ActivityClickBO activityClick = new ActivityClickBO();
				activityClick.setActivityId(activityId);
				activityClick.setSource(source);
				activityClick.setId(UUID.randomUUID().toString());
				Date now = new Date();
				activityClick.setClickTime(now);
				activityClick.setClickDate(DateUtils.format(now, DateUtils.DATE_FORMAT_TYPE3));
				activityClickRepository.insert(activityClick, ActivityClickBO.class);

				if (!StringUtils.isEmpty(userId)) {
					try {
						// 登录成功，插入积分记录
						userIntegralLogService.insert(userId, IntegralEvent.READER,
								IntegralConst.TABLE_NAME_ACTIVITY_CLICK_BO, activityId, null, clientType);
					} catch (Exception ex) {
						logger.error("阅读成功，插入积分记录异常" + ex);
					}
				}
			} else {
				result.setStatus(Status.ERROR);
				result.setErrorCode(ErrorType.IllegalArgument.getCode());
				result.setErrorMsg(ErrorType.IllegalArgument.getDesc());
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}
	
	@Override
	public JsonResponse<Void> insertAllActivityStatic() {
		JsonResponse<Void> result = new JsonResponse<Void>();
		try {
			activityStaticMapper.insertAllActivityStatic();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<Void> updateActivityClickCount(Date date) {
		JsonResponse<Void> result = new JsonResponse<Void>();
		try {
			List<ActivityStatic> mogoClickList = activityClickRepository.getActivityClickCountListMongo(date,null);
			
			//在updateActivityClickCount之前已经调用过insertAllActivityStatic，所以staticList的activityId是全量的
			List<ActivityStatic> staticList = activityStaticMapper.selectByExample(null);
			HashMap<String,ActivityStatic> staticMap = new HashMap<String,ActivityStatic>();
			
			if(staticList != null && staticList.size() > 0){
				for(ActivityStatic activityStatic:staticList){
					if(activityStatic != null){
						staticMap.put(activityStatic.getActivityId(), activityStatic);
					}
				}
			}
			
			
			List<ActivityStatic> updateList = new ArrayList<ActivityStatic>();
			
			if(!staticMap.isEmpty() && mogoClickList != null && mogoClickList.size() > 0){
				for(ActivityStatic activity:mogoClickList){
					if(activity != null && staticMap.containsKey(activity.getActivityId())){
						ActivityStatic activityStatic = new ActivityStatic();
						
						activityStatic.setActivityId(activity.getActivityId());
						activityStatic.setActivityStaticId(staticMap.get(activity.getActivityId()).getActivityStaticId());
						activityStatic.setClickCount(staticMap.get(activity.getActivityId()).getClickCount() + activity.getClickCount());
						
						updateList.add(activityStatic);
					}
				}
			}
			
			if(updateList != null && updateList.size() > 0){
				activityStaticMapper.batchUpdate(updateList);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(Status.ERROR);
			result.setErrorCode(ErrorType.SystemBusy.getCode());
			result.setErrorMsg(ErrorType.SystemBusy.getDesc());
		}
		return result;
	}

	@Override
	public JsonResponse<PageInfo<Activity>> getMyActivity(List<String> infoIdList, String pageSize, String pageNo) {
		// 设置分页参数
		if (StringUtils.isBlank(pageNo)) {
			pageNo = "1";
		}
		// 设置分页参数
		if (StringUtils.isBlank(pageSize)) {
			pageSize = "10";
		}
		List<Activity> result = voActivityMapper.getActivity(infoIdList);
		JsonResponse<PageInfo<Activity>> respose = new JsonResponse<PageInfo<Activity>>();
		// 设置分页页号和页码
		PageHelper.startPage(Integer.parseInt(pageNo), Integer.parseInt(pageSize));

		PageInfo<Activity> page = new PageInfo<Activity>(result);// 获得分页信息
		respose.setResult(page);
		return respose;
	}
	
	@Override
	public JsonResponse<List<String>> getAllActivityId(Date beginDate,Date endDate) {
		VOActivity voActivity = new VOActivity();
		voActivity.setBeginDate(beginDate);
		voActivity.setEndDate(endDate);
		List<String> result = voActivityMapper.getAllActivityId(voActivity);
		JsonResponse<List<String>> respose = new JsonResponse<List<String>>();
		respose.setResult(result);
		return respose;
	}
}