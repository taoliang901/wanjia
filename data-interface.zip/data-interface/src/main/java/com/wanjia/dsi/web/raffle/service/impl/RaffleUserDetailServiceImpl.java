package com.wanjia.dsi.web.raffle.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.Logger;
import org.elasticsearch.common.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pinganwj.clinic.api.ClinicApiService;
import com.pinganwj.clinic.api.domain.EmptyRsp;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.web.raffle.dao.mapper.RaffleItemVOMapper;
import com.wanjia.dsi.web.raffle.dao.mapper.RaffleTypeMapper;
import com.wanjia.dsi.web.raffle.dao.mapper.RaffleUserDetailMapper;
import com.wanjia.dsi.web.raffle.dao.mapper.RaffleUserDetailVOMapper;
import com.wanjia.dsi.web.raffle.dao.mapper.RaffleUserIncomMapper;
import com.wanjia.dsi.web.raffle.dao.mapper.RaffleUserIncomVOMapper;
import com.wanjia.dsi.web.raffle.model.RaffleItem;
import com.wanjia.dsi.web.raffle.model.RaffleItemExtend;
import com.wanjia.dsi.web.raffle.model.RaffleType;
import com.wanjia.dsi.web.raffle.model.RaffleUserDetail;
import com.wanjia.dsi.web.raffle.model.RaffleUserIncom;
import com.wanjia.dsi.web.raffle.service.RaffleItemExtendService;
import com.wanjia.dsi.web.raffle.service.RaffleUserDetailService;
import com.wanjia.dsi.web.raffle.util.RaffleCycleType;

/**
 * This element is automatically generated on 16-7-25 上午11:38, do not modify.
 * <br>
 * Service implementation class
 */
@Service
@com.alibaba.dubbo.config.annotation.Service
@Transactional
public class RaffleUserDetailServiceImpl implements RaffleUserDetailService {

	// 日志类
	private static final Logger logger = Logger.getLogger(RaffleUserDetailServiceImpl.class);
	
	private static String CLINIC = "clinic";
	private static String CLINIC_CLOUD="clinic-cloud";

	private static Lock lock = new ReentrantLock();

	@Autowired
	private RaffleUserDetailMapper raffleUserDetailMapper;

	@Autowired
	private RaffleUserDetailVOMapper raffleUserDetailVOMapper;

	@Autowired
	private RaffleItemVOMapper raffleItemVOMapper;

	@Autowired
	private RaffleUserIncomMapper raffleUserIncomMapper;

	@Autowired
	private RaffleUserIncomVOMapper raffleUserIncomVOMapper;

	@Autowired
	private RaffleItemExtendService raffleItemExtendService;

	@Autowired
	private RaffleTypeMapper raffleTypeMapper;
	
	@Autowired
	private ClinicApiService clinicApiService;

	@Override
	@Transactional(readOnly = true)
	public RaffleUserDetail findById(String id) {
		return (RaffleUserDetail) raffleUserDetailMapper.findById(id);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RaffleUserDetail> findWithPagination(int offset, int count) {
		return (List<RaffleUserDetail>) raffleUserDetailMapper.findWithPagination(offset, count);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RaffleUserDetail> findAll() {
		return (List<RaffleUserDetail>) raffleUserDetailMapper.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public List<RaffleUserDetail> findByEntity(RaffleUserDetail model) {
		return (List<RaffleUserDetail>) raffleUserDetailMapper.findByEntity(model);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RaffleUserDetail> findByEntityWithPagination(RaffleUserDetail model, int offset, int count) {
		return (List<RaffleUserDetail>) raffleUserDetailMapper.findByEntityWithPagination(model, offset, count);
	}

	@Override
	@Transactional(readOnly = true)
	public RaffleUserDetail findOneByEntity(RaffleUserDetail model) {
		return (RaffleUserDetail) raffleUserDetailMapper.findOneByEntity(model);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RaffleUserDetail> findByProperty(String propertyName, String propertyValue) {
		return (List<RaffleUserDetail>) raffleUserDetailMapper.findByProperty(propertyName, propertyValue);
	}

	@Override
	@Transactional(readOnly = true)
	public RaffleUserDetail findOneByProperty(String propertyName, String propertyValue) {
		return (RaffleUserDetail) raffleUserDetailMapper.findOneByProperty(propertyName, propertyValue);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RaffleUserDetail> findByPropertyWithPagination(String propertyName, String propertyValue, int offset,
			int count) {
		return (List<RaffleUserDetail>) raffleUserDetailMapper.findByPropertyWithPagination(propertyName, propertyValue,
				offset, count);
	}

	@Override
	@Transactional(readOnly = true)
	public List<RaffleUserDetail> findByProperties(Map<String, Object> map) {
		return (List<RaffleUserDetail>) raffleUserDetailMapper.findByProperties(map);
	}

	@Override
	@Transactional(readOnly = true)
	public long countByEntity(RaffleUserDetail model) {
		return (long) raffleUserDetailMapper.countByEntity(model);
	}

	@Override
	@Transactional
	public long countByProperty(String propertyName, String propertyValue) {
		return (long) raffleUserDetailMapper.countByProperty(propertyName, propertyValue);
	}

	@Override
	@Transactional
	public long countByProperties(Map<String, Object> map) {
		return (long) raffleUserDetailMapper.countByProperties(map);
	}

	@Override
	public void update(RaffleUserDetail model) {
		model.setModifyDate(new Date());
		raffleUserDetailMapper.update(model);
	}

	@Override
	public void insert(RaffleUserDetail model) {
		model.setCreateDate(new Date());
		raffleUserDetailMapper.insert(model);
	}

	@Override
	public void deleteByEntity(RaffleUserDetail model) {
		model.setDelFlag("1");
		model.setModifyDate(new Date());
		this.update(model);
	}

	@Override
	public void deleteByProperty(String propertyName, String propertyValue) {
		raffleUserDetailMapper.deleteByProperty(propertyName, propertyValue);
	}

	@Transactional(readOnly = true)
	public long countAll() {
		return this.raffleUserDetailMapper.countAll();
	}

	@Override
	public void insertBatch(List<RaffleUserDetail> list) {
		this.raffleUserDetailMapper.insertBatch(list);
	}

	@Override
	public void delete(String id) {
		RaffleUserDetail model = new RaffleUserDetail();
		model.setDelFlag("1");
		model.setModifyDate(new Date());
		model.setId(String.valueOf(id));
		this.raffleUserDetailMapper.update(model);
	}

	@Override
	public List<RaffleUserDetail> findByRaffleKey(Map<String, Object> map) {
		return this.raffleUserDetailVOMapper.findByRaffleKey(map);
	}

	/**
	 * ErrorCode: 001:抽奖机会已用完 002:根据raffleKey未找到抽奖记录 003:参数错误 004:未找到抽奖项目
	 * 005:不能识别的抽奖活动类型 006:抽奖活动还未开始 007:抽奖活动已结束
	 */
	@Override
	public JsonResponse<RaffleUserDetail> startDrawRaffle(String userId, String userType, String raffleKey) {
		return this.startDrawRaffle(null, userId, userType, raffleKey);
	}
	
	
	/**
	 * ErrorCode: 001:抽奖机会已用完 002:根据raffleKey未找到抽奖记录 003:参数错误 004:未找到抽奖项目
	 * 005:不能识别的抽奖活动类型 006:抽奖活动还未开始 007:抽奖活动已结束
	 */
	@Override
	public JsonResponse<RaffleUserDetail> startDrawRaffle(String clinicId, String userId, String userType, String raffleKey) {

		JsonResponse<RaffleUserDetail> jr = new JsonResponse<RaffleUserDetail>();
		jr.setStatus(JsonResponse.Status.SUCCESS);

		if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(raffleKey)) {
			// 系统繁忙，请稍后再试
			jr.setStatus(JsonResponse.Status.ERROR);
			jr.setErrorCode("003");
			jr.setErrorMsg("系统繁忙，请稍后再试!");
			logger.equals("抽奖参数错误，userId[" + userId + "],raffleKey[" + raffleKey + "]");
		} else {
			// 获取抽奖类型
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("typeKey", raffleKey);
			map.put("delFlag", "0");
			List<RaffleType> typeList = raffleTypeMapper.findByProperties(map);

			if (typeList != null && typeList.size() > 0) {
				RaffleType raffleType = typeList.get(0);
				Date nowDate = new Date();

				if (raffleType.getStatrDate() != null && nowDate.before(raffleType.getStatrDate())) {
					// 抽奖活动还未开始
					jr.setStatus(JsonResponse.Status.ERROR);
					jr.setErrorCode("006");
					jr.setErrorMsg("抽奖活动还未开始!");
					return jr;
				}

				if (raffleType.getEndDate() != null && nowDate.after(raffleType.getEndDate())) {
					// 抽奖活动还未开始
					jr.setStatus(JsonResponse.Status.ERROR);
					jr.setErrorCode("007");
					jr.setErrorMsg("抽奖活动已结束!");
					return jr;
				}

				if (!RaffleCycleType.DAY.getCode().equals(raffleType.getCycleType())
						&& !RaffleCycleType.ONE.getCode().equals(raffleType.getCycleType())) {
					jr.setStatus(JsonResponse.Status.ERROR);
					jr.setErrorCode("005");
					jr.setErrorMsg("不能识别的抽奖活动类型!");
					return jr;
				}

				// 抽奖针对用户为诊所用户或者云诊所用户, 校验诊所ID是否有效
				if ((CLINIC.equals(raffleType.getUserType()) || CLINIC_CLOUD.equals(raffleType.getUserType())) 
						&& StringUtils.isEmpty(clinicId)) {
					// 系统繁忙，请稍后再试
					jr.setStatus(JsonResponse.Status.ERROR);
					jr.setErrorCode("003");
					jr.setErrorMsg("系统繁忙，请稍后再试!");
					logger.equals("抽奖参数错误，clinicId不能为空");
					return jr;
				}

				// 获取系统时间
				Calendar c = Calendar.getInstance();
				Date startRaffleDate = null, endRaffleDate = null;
				if (RaffleCycleType.DAY.getCode().equals(raffleType.getCycleType())) {
					// 已抽奖的开始时间
					startRaffleDate = getDayBegin(c);
					// 已抽奖的结束时间
					endRaffleDate = getDayEnd(c);
				}

				// 默认的抽奖次数
				int defaulCount = raffleType.getDefaultCount() == null ? 0 : raffleType.getDefaultCount();
				// 获取用户通过任务获取的抽奖次数(目前有效的次数)
				map.clear();
				map.put("userId", userId);
				map.put("raffleTypeId", raffleType.getId());
				map.put("delFlag", "0");
				int incomCount = 0;
				List<RaffleUserIncom> incomList = raffleUserIncomVOMapper.findValidIncomByUserId(map);
				if (incomList != null && incomList.size() > 0) {
					for (RaffleUserIncom incom : incomList) {
						incomCount += (incom.getIncomCount() == null ? 0 : incom.getIncomCount());
						incomCount -= (incom.getUsedCount() == null ? 0 : incom.getUsedCount());
					}
				}

				// 获取用户使用系统赠送(chanceSource==1)的抽奖机会已抽奖的次数
				long raffleCountDefault = this.countByRaffleDate(raffleType.getId(), null, userId, null, "1", null,
						startRaffleDate, endRaffleDate);
				if (incomCount <= 0) {
					if (defaulCount > 0) {
						if (raffleCountDefault >= defaulCount) {
							// 抽奖机会已用完
							jr.setStatus(JsonResponse.Status.ERROR);
							jr.setErrorCode("001");
							if (RaffleCycleType.DAY.getCode().equals(raffleType.getCycleType())) {
								jr.setErrorMsg("您的抽奖机会已用完，记得明天再来哦!");
							} else if (RaffleCycleType.ONE.getCode().equals(raffleType.getCycleType())) {
								jr.setErrorMsg("您的抽奖机会已用完!");
							}
						}
					} else {
						// 抽奖机会已用完
						jr.setStatus(JsonResponse.Status.ERROR);
						jr.setErrorCode("001");
						if (RaffleCycleType.DAY.getCode().equals(raffleType.getCycleType())) {
							jr.setErrorMsg("您的抽奖机会已用完，明天再来吧!");
						} else if (RaffleCycleType.ONE.getCode().equals(raffleType.getCycleType())) {
							jr.setErrorMsg("您的抽奖机会已用完!");
						}
					}
				}

				// 还有抽奖机会，开始抽奖
				if (jr.getStatus().toString().equals(JsonResponse.Status.SUCCESS.toString())) {
					// 开始抽奖，获取抽奖项目
					List<RaffleItem> raffleItems = raffleItemVOMapper.findByRaffleKey(raffleKey);
					if (raffleItems != null && raffleItems.size() > 0) {
						try {
							// 线程之间并发控制
							lock.lock();
							
							boolean clinicOpenCloud = false;
							RaffleItem hitItem = null, defaultHitItem = null;
							if (CLINIC_CLOUD.equals(raffleType.getUserType())) {
								// 抽奖用户类型为云诊所，检测诊所是否开通云诊所服务
								com.pinganwj.clinic.api.domain.JsonResponse<EmptyRsp> er = clinicApiService.clinicIsNotAllotPackage(clinicId);
								if (er.getStatus().equals(com.pinganwj.clinic.api.domain.JsonResponse.Status.SUCCESS)
										&& "E1".equals(er.getSuccessMsg())) {
									clinicOpenCloud = true;
								}
							}				
							
							if(CLINIC_CLOUD.equals(raffleType.getUserType()) && !clinicOpenCloud){
								// 抽奖用户类型为云诊所时，如果当前诊所未开通云诊所，侧用户永远不中奖
								for (RaffleItem item : raffleItems) {
									if(item.getIsDefault() == 1){
										hitItem = item;
										break;
									}
								}								
							} else {							
								// 开始抽奖, 1~10000的随机数
								int randomInt = new Random().nextInt(10000) + 1;							
								long totalHitCount = 0;
								// userType: 抽奖的用户类型：用户（user), 诊所(clinic)
								if (CLINIC.equals(raffleType.getUserType()) || CLINIC_CLOUD.equals(raffleType.getUserType())) {
									// 以诊所为单位进行抽奖
									totalHitCount = this.countByRaffleDate(raffleType.getId(), clinicId, null, null, null,
											"1", null, null);
								} else {
									// 以用户为单位进行抽奖
									totalHitCount = this.countByRaffleDate(raffleType.getId(), null, userId, null, null,
											"1", null, null);
								}							
	
								// 没有奖项的奖项列表
								List<RaffleItem> noneItemList = new ArrayList<RaffleItem>();
								for (RaffleItem item : raffleItems) {
									// 抽中的Item
									if (item.getHitLower() != null && randomInt >= item.getHitLower()
											&& item.getHitUpper() != null && randomInt <= item.getHitUpper()) {
										// 获取该项目总的抽奖数
										long totalRaffleCount = this.countByRaffleDate(raffleType.getId(), null, null,
												item.getId(), null, null, null, null);
										// 获取该项目今天总的抽奖数
										long todayRaffleCount = this.countByRaffleDate(raffleType.getId(), null, null,
												item.getId(), null, null, getDayBegin(c), getDayEnd(c));
	
										// 是否超过该项目今天的抽奖数或者总的抽奖限制
										if ((item.getDayLimit() == null || item.getDayLimit() == -1
												|| item.getDayLimit() > todayRaffleCount)
												&& (item.getTotalLimit() == null && item.getTotalLimit() == -1
														|| item.getTotalLimit() > totalRaffleCount)) {
											// 检测该项目是否存在大于中奖次数的扩展项
											RaffleItemExtend itemExtend = raffleItemExtendService.findByItemIdAndHitCount(
													item.getId(), Long.valueOf(totalHitCount).intValue());
											if (itemExtend != null) {
												if (itemExtend.getHitLower() != null
														&& randomInt >= itemExtend.getHitLower()
														&& itemExtend.getHitUpper() != null
														&& randomInt <= itemExtend.getHitUpper()) {
													hitItem = item;
												}
											} else {
												hitItem = item;
											}
										}
									}
	
									// 连续多次未中奖，默认中奖项
									if (item.getIsDefault() != null && item.getIsDefault() == 2) {
										defaultHitItem = item;
									}
	
									// 当天抽奖已用完，默认抽中的未中奖项Item
									if (item.getIsDefault() != null && item.getIsDefault() == 1) {
										noneItemList.add(item);
									}
								}
	
								// 默认不中奖项目
								RaffleItem defaultNoneItem = null;
								if (noneItemList.size() > 0) {
									int noneIndex = new Random().nextInt(noneItemList.size());
									defaultNoneItem = noneItemList.get(noneIndex);
								}
	
								hitItem = hitItem == null ? defaultNoneItem : hitItem;
								// 存在默认可中奖项，且默认最小可以中奖项大于0，且当前用户总的中奖次数小于最小可中奖次数
								if (hitItem.getIsHit() == 0 && defaultHitItem != null && raffleType.getMinHitCount() > 0
										&& totalHitCount < raffleType.getMinHitCount()) {
									// 获取用户使用做任务获取(chanceSource==2)的抽奖机会抽奖的次数
									long raffleCountIncom = this.countByRaffleDate(raffleType.getId(), null, userId, null, "2", 
											null, startRaffleDate, endRaffleDate);
									// 多少次内必定会中奖的次数 <= 总抽奖次数 + 最小可中奖次数
									if (raffleType.getMaxCount() <= (raffleCountDefault + raffleCountIncom)
											+ raffleType.getMinHitCount()) {
										// 设置为默认可中奖项
										hitItem = defaultHitItem;
									}
								}
	
								// 检测中奖项是否超过该抽奖类型天或总的中奖限制
								if (hitItem.getIsHit() == 1) {
									// 抽奖奖品，检查用户中奖次数是否大于总的最大中奖次数
									if (raffleType.getTotalMaxHitCount() != null
											&& totalHitCount >= raffleType.getTotalMaxHitCount()) {
										// 中奖次数已大于设置的最大中奖次数，设置为默认不中奖项
										hitItem = defaultNoneItem;
									} else {
										if (RaffleCycleType.DAY.getCode().equals(raffleType.getCycleType())) {
											// 抽奖类型为按天循环，检测用户中奖次数是否大于每天中奖次数
											long dayHitCount = 0;
											// userType: 抽奖的用户类型：用户（user), 诊所(clinic)
											if (CLINIC.equals(raffleType.getUserType()) || CLINIC_CLOUD.equals(raffleType.getUserType())) {
												// 以诊所为单位进行抽奖
												dayHitCount = this.countByRaffleDate(raffleType.getId(), clinicId, null,
														null, null, "1", startRaffleDate, endRaffleDate);
											} else {
												dayHitCount = this.countByRaffleDate(raffleType.getId(), null, userId,
														null, null, "1", startRaffleDate, endRaffleDate);
											}

											if (dayHitCount >= raffleType.getMaxHitCount()) {
												// 中奖次数已大于每天中奖次数，设置为默认不中奖项
												hitItem = defaultNoneItem;
											}
										}
									}
								}
	
								// 检测中奖项是否超过该项目天或总的中奖限制
								if (hitItem.getIsHit() == 1) {
									// 获取该项目总的抽奖数
									long totalRaffleCount = this.countByRaffleDate(raffleType.getId(), null, null, hitItem.getId(), 
											null, null, null, null);
									// 获取该项目今天总的抽奖数
									long todayRaffleCount = this.countByRaffleDate(raffleType.getId(), null, null, hitItem.getId(), 
											null, null, getDayBegin(c), getDayEnd(c));
									// 是否超过该项目今天的抽奖数或者总的抽奖限制
									if ((hitItem.getDayLimit() != null && hitItem.getDayLimit() != -1
											&& hitItem.getDayLimit() <= todayRaffleCount)
											|| (hitItem.getTotalLimit() != null && hitItem.getTotalLimit() != -1
													&& hitItem.getTotalLimit() <= totalRaffleCount)) {
										// 当天抽奖已用完，默认抽中的未中奖项
										hitItem = defaultNoneItem;
									}
								}
							}

							// 得到中奖项目，生成中奖记录
							RaffleUserDetail detail = new RaffleUserDetail();
							detail.setId(CommonTools.generateUUID());
							detail.setRaffleTypeId(hitItem.getRaffleTypeId());
							detail.setRaffleItemId(hitItem.getId());
							detail.setRaffleItemName(hitItem.getName());
							detail.setRaffleItemValue(hitItem.getValue());
							detail.setRaffleOrderValue(hitItem.getOrderValue());
							detail.setRaffleDate(new Date());
							detail.setUserType(userType);
							detail.setUserId(userId);
							detail.setClinicId(clinicId);
							detail.setIsHit(hitItem.getIsHit());
							// 抽奖机会的来源（1：系统赠送，2：任务获取）
							detail.setChanceSource(incomCount > 0 ? "2" : "1");
							detail.setDelFlag("0");
							detail.setCreateUser(userId);
							detail.setCreateDate(new Date());
							detail.setModifyUser(userId);
							detail.setModifyDate(new Date());

							// 插入中奖记录
							raffleUserDetailMapper.insert(detail);
							// 有限使用分享获取的抽奖机会
							if (incomList != null && incomList.size() > 0) {
								RaffleUserIncom userIncom = incomList.get(0);
								userIncom.setUsedCount(userIncom.getUsedCount() + 1);
								userIncom.setModifyDate(new Date());
								userIncom.setModifyUser(userId);
								raffleUserIncomMapper.update(userIncom);
							}

							jr.setResult(detail);
						} finally {
							lock.unlock();
						}
					} else {
						// 系统繁忙，请稍后再试
						logger.equals("根据[" + raffleKey + "]未找到抽奖项目");
						jr.setStatus(JsonResponse.Status.ERROR);
						jr.setErrorCode("004");
						jr.setErrorMsg("系统繁忙，请稍后再试!");
					}
				}
			} else {
				// 系统繁忙，请稍后再试
				logger.equals("根据[" + raffleKey + "]未找到抽奖类型");
				jr.setStatus(JsonResponse.Status.ERROR);
				jr.setErrorCode("002");
				jr.setErrorMsg("系统繁忙，请稍后再试!");
			}
		}

		return jr;
	}

	@Override
	public Long countByRaffleDate(Map<String, Object> map) {
		return this.raffleUserDetailVOMapper.countByRaffleDate(map);
	}

	@Override
	public List<RaffleUserDetail> findByNullAdditional(Map<String, Object> map) {
		return this.raffleUserDetailVOMapper.findByNullAdditional(map);
	}

	private long countByRaffleDate(String typeId, String clinicId, String userId, String raffleItemId,
			String chanceSource, String isHit, Date startRaffleDate, Date endRaffleDate) {
		// 获取抽奖且中奖的次数
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("raffleTypeId", typeId);
		map.put("delFlag", "0");

		if (StringUtils.isNotBlank(clinicId)) {
			map.put("clinicId", clinicId);
		}

		if (StringUtils.isNotBlank(userId)) {
			map.put("userId", userId);
		}

		if (raffleItemId != null) {
			map.put("raffleItemId", raffleItemId);
		}

		if (startRaffleDate != null) {
			map.put("startRaffleDate", startRaffleDate);
		}

		if (endRaffleDate != null) {
			map.put("endRaffleDate", endRaffleDate);
		}

		// 获取用户使用系统赠送的抽奖机会已抽奖的次数
		if (chanceSource != null) {
			map.put("chanceSource", chanceSource);
		}

		if (isHit != null) {
			map.put("isHit", isHit);
		}

		Long hitRaffleCount = raffleUserDetailVOMapper.countByRaffleDate(map);

		return hitRaffleCount == null ? 0 : hitRaffleCount;
	}

	private Date getDayBegin(Calendar c) {
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.MILLISECOND, 0);
		return c.getTime();
	}

	private Date getDayEnd(Calendar c) {
		c.set(Calendar.HOUR_OF_DAY, 23);
		c.set(Calendar.MINUTE, 59);
		c.set(Calendar.MILLISECOND, 59);

		return c.getTime();
	}
}