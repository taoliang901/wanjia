package com.job36.mobile.webservice;


import javax.jws.WebService;

import com.wanjia.dsi.web.jobYYRC.model.MemInfo;



//@WebService
public interface MemInfoWebService {
	/**
	 * 根据id获取企业信息
	 * @param memId
	 * @return
	 */
	public String get(Integer memId);
	/**
	 * 注册
	 * @param memInfo
	 * @return
	 */
	public String regist(MemInfo memInfo);


	/**
	 * 预览企业
	 * @param memId
	 * @return
	 */
	public String view(Integer memId);
	
	/**
	 * 更新企业信息
	 * @param memInfo
	 * @return
	 */
	public String update(MemInfo memInfo);
	
	/**
	 * 更新企业简介
	 * @param memInfo
	 * @return
	 */
	public String updateIntro(MemInfo memInfo);
}
