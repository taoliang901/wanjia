package com.job36.mobile.webservice;

import javax.jws.WebService;

import com.wanjia.dsi.web.jobYYRC.model.MemInfo;
import com.wanjia.dsi.web.jobYYRC.model.ResumeCondition;


/**
 * Title: SearchResumeWebService
 * Description: 简历
 */

//@WebService
public interface ResumeWebService {
	
	/***
	 * 搜索简历
	 * @param condition
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public String searchResume(ResumeCondition condition, int pageNo, int pageSize);
	
	/***
	 * 预览简历
	 * @param resId
	 * @return
	 */
	public String viewResume(int resId);
	
	/***
	 * 下载简历
	 * @param resId:简历id
	 * @param memId:下载企业id
	 * @param memName:下载企业名称
	 * @return
	 */
	public String downloadResume (int resId, int memId, String memName);
	
	/**
	 * 注册
	 * @param memInfo
	 * @return
	 */
	public String regist(MemInfo memInfo);
	
}
