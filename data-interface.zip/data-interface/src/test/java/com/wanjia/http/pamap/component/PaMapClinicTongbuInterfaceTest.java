package com.wanjia.http.pamap.component;

import java.net.URLEncoder;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wanjia.http.pamap.model.request.PaMapReqRecord;
import com.wanjia.http.pamap.model.response.PaMapRespBusiData;
import com.wanjia.http.pamap.utils.EncryptUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PaMapClinicTongbuInterfaceTest {

	private Log log = LogFactory.getLog(getClass());

	@Resource(name = "paMapClinicTongbuInterface")
	PaMapClinicTongbuInterface paMapClinicTongbuInterface;
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * 同步诊所至地图
	 */
	@Test
	public void testDoTongbu() throws Exception {
		log.info("=============== sart ====");
		
		PaMapReqRecord data = new PaMapReqRecord();
		data.setSyncId("af7f73ca-3af5-4d78-9c35-2653c160d493");
		data.setName("回归测试6271");
		data.setIcon("http://imagetest.pawjzs.com:81/aaaaaa.png");
		data.setAddress("四川成都市高新区");
		data.setDetailAddress("四川成都市高新区新闸路03");
//		data.setPhoneNumber("15800509104");
		data.setProvinceCode("2440");
		data.setCityCode("2441");
		data.setDistrictCode("2461");
		data.setLongitude(104.038765);
		data.setLatitude(30.59262);
		data.setEnabledBooking("0");
		
		PaMapRespBusiData res = paMapClinicTongbuInterface.doTongbu("1", data);
		System.out.println(res);
		log.info("=============== end ====");
	}

	/**
	 * 地图调用我的预约
	 */
	@Test
	public void testMyBookings() throws Exception {
		
//		String url = "https://gwdev.pawjzs.com/external/pamap/myBookings.do";
//		String url = "https://gwtest.pawjzs.com/external/pamap/myBookings.do";
		String url = "https://gwtest.pawjzs.com/external/pamap/myBookings.do";
//		String url = "http://172.18.50.6:8412/external/pamap/myBookings.do";
//		String url = "http://localhost:8080/external/pamap/myBookings.do";
		long current = System.currentTimeMillis();
		
		String uid = "pamap";
		String authKey = "432BA1C857ED1D7520C8C6C66AB0D26F";
		String qid = "UUID0000001";
		String toaId = "530361466501261300";
		
		String dataString = uid+authKey+qid+toaId;
		String sign = EncryptUtil.encryptBASE64(EncryptUtil.encryptHMAC((dataString+current).getBytes("utf-8"), "123456"));
		sign = URLEncoder.encode(sign, "UTF-8");

		log.info("【我的预约列表】请求字符串： " + dataString);
		log.info("签名： " + sign);
		// ---------------------------------- 2、发送请求 -----------------------------
		String res = null;

		url +="?uid="+uid
				+"&authKey="+authKey
				+"&qid="+qid
				+"&tt="+current
				+"&toaId="+toaId
				+"&sign="+sign
				+"&pageNo="+1		//当前页码（从1开始计数）
				+"&pageSize="+10;

		HttpClient hc = new DefaultHttpClient();
		hc.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,10000);
		hc.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,30000);
		
		log.info(url);
		HttpGet httpget = new HttpGet(url);
		// 发送请求
		HttpResponse httpresponse = hc.execute(httpget);
		// 获取返回数据
		org.apache.http.HttpEntity entity = httpresponse.getEntity();
		res = EntityUtils.toString(entity);
		
		log.info("【我的预约列表】响应结果： " + res);
		
		
	}
}
