package com.wanjia.dsi.web.feedback.service.impl;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.web.feedback.model.Feedback;
import com.wanjia.dsi.web.feedback.service.FeedbackService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class FeedbackServiceImplTest {
	@Autowired
	FeedbackService feedbackService;
	@Test
	public void testinsert(){
		// 07210096c705419f9b1df57e9420d396
		Feedback model = new Feedback();
		model.setId("test3");
		model.setCasId("casId");
		model.setAppsrc("0");
		model.setDealRemark("dealRemark");
		model.setFeedbackContent("feedbackContent");
		model.setFeedbackSrc("0");
		model.setMobile("mobile");
		model.setDealFlag(0);
		model.setCallName("callname");
		model.setContactInfomation("contactInfomation");
		feedbackService.insert(model);
	}
	
	@Test
	public void testfindAll(){
		List<Feedback> feedback = feedbackService.findAll();
		for(Feedback f:feedback){
			System.out.println("--------" + f.getId() + "," +f.getCasId());
		}
	}
	
	@Test
	public void tesfindOneByEntity(){
		Feedback model = new Feedback();
		model.setId("test3");
		Feedback feedback = feedbackService.findOneByEntity(model);
		System.out.println("--------" + feedback.getId() + "," +feedback.getCasId() + "," +feedback.getFeedbackSrc() 
		+ "," +feedback.getContactInfomation() + "," +feedback.getCallName());
	}
}
