package com.wanjia.dsi.web.cms.activity.service.impl;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.model.InfomationStatistcBO;
import com.wanjia.dsi.web.cms.activity.model.VOInfomationStatistc;
import com.wanjia.dsi.web.cms.activity.service.InfomationStatistcService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class InfomationStatistcServiceImplTest {
	@Autowired
	InfomationStatistcService infomationStatistcService;
	@Test
	public void testinsertOrUpdateInfomationStatistc(){
		InfomationStatistcBO infomationStatistcBO = new InfomationStatistcBO();
		String infoId = "testInfo8";
		String type = "M";
		infomationStatistcBO.setInfoId(infoId);
		infomationStatistcBO.setType(type);
		infomationStatistcService.insertOrUpdateInfomationStatistc(infomationStatistcBO);
	}
	@Test
	public void testgetInfomationStatistic(){
		VOInfomationStatistc voInfomationStatistc = new VOInfomationStatistc();
		String infoId = "testInfo3";
		String type = "M";
		//voInfomationStatistc.setInfoId(infoId);
		voInfomationStatistc.setType(type);
		JsonResponse<PageInfo<InfomationStatistcBO>> jr = infomationStatistcService.getInfomationStatistic(voInfomationStatistc);
		PageInfo<InfomationStatistcBO> page = jr.getResult();
		List<InfomationStatistcBO>  infoList = page.getList();
		for(InfomationStatistcBO info:infoList){
			System.out.println("-------------------" + info.getInfoId() + "," + info.getType() + "," + info.getCountNum());
		}
	}
}
