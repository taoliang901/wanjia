package com.wanjia.dsi.web.area.service.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.area.model.VOArea;
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class VOAreaServiceImplTest {
	@Autowired
	private VOAreaServiceImpl voAreaServiceImpl;
	
	@Test
	public void testFindCityByFirstStr() {
		
		JsonResponse<List<VOArea>> jr = voAreaServiceImpl.findCityByFirstStr();
		if(null!=jr&&null!=jr.getResult()){
			System.out.println(jr.getResult());
		}
	}
	
	@Test
	public void testFindCityByCharacter(){
		JsonResponse<VOArea> jr = new JsonResponse<VOArea>();
		jr=voAreaServiceImpl.findCityByCharacter("B");
		System.out.println(jr.getResult());
	}
}
