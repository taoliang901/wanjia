package com.wanjia.dsi.web.cms.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import scala.collection.mutable.HashMap;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.department.model.CmsDepartmentCriteria;
import com.wanjia.dsi.web.cms.department.service.CmsDepartmentCriteriaService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class CmsDepartmentServiceImplTest {

	@Autowired
	private CmsDepartmentCriteriaService cmsDepartmentCriteriaService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetCmsDepartmentByTime() throws ParseException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date beginDate = df.parse("2016-01-01");
		Date endDate = df.parse("2016-12-22");

		JsonResponse<List<CmsDepartmentCriteria>> res = cmsDepartmentCriteriaService.getCmsDepartmentByTime(beginDate,endDate);
		System.out.println("===========================" + res.getStatus());
		System.out.println("===========================" + res.getErrorMsg());
		if(res.getResult() != null) {
			System.out.println("===========================" + res.getResult().size());
		}
	}
	
	
	
}
