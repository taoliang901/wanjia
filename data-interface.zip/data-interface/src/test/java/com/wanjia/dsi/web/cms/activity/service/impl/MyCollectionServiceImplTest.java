package com.wanjia.dsi.web.cms.activity.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.web.cms.activity.model.MyCollectionBO;
import com.wanjia.dsi.web.cms.activity.model.VODiseaseSmryInfo;
import com.wanjia.dsi.web.cms.activity.model.VOLocalMedicine;
import com.wanjia.dsi.web.cms.activity.model.VOMyCollection;
import com.wanjia.dsi.web.cms.activity.model.LocalMedicine;
import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.activity.model.Activity;
import com.wanjia.dsi.web.activity.model.VOActivity;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VOActivityMapper;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VODiseaseSmryInfoMapper;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VOLocalMedicineMapper;
import com.wanjia.dsi.web.cms.activity.model.DiseaseSmryInfo;
import com.wanjia.dsi.web.cms.activity.service.MycollectionService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class MyCollectionServiceImplTest {
	@Autowired
	MycollectionService mycollectionService;
	@Autowired
	VOActivityMapper voActivityMapper;
	@Autowired
	VOLocalMedicineMapper voLocalMedicineMapper;
	@Autowired
	VODiseaseSmryInfoMapper voDiseaseSmryInfoMapper;
	
	@Test
	public void testinsertMycollection() {
		MyCollectionBO infomationClickBO = new MyCollectionBO();
		String userId ="pinganwanjia2";
		String type ="A";
		String infoId = "info";
		String source = "127.0.0.1";
		infomationClickBO.setInfoId(infoId);
		infomationClickBO.setType(type);
		infomationClickBO.setUserId(userId);
		infomationClickBO.setSource(source);
		mycollectionService.insertMycollection(infomationClickBO);
	}

	@Test
	public void testgetMyLocalMedicine() {
		// H20084257  Z20053277
		VOMyCollection voMyCollection = new VOMyCollection();
		voMyCollection.setUserId("liugc");
		voMyCollection.setType("M");
		voMyCollection.setInfoId("H20084257");
		JsonResponse<PageInfo<LocalMedicine>> response = mycollectionService.getMyLocalMedicine(voMyCollection);
		PageInfo<LocalMedicine> page = response.getResult();
		List<LocalMedicine> result = page.getList();
		for(LocalMedicine l:result){
			System.out.println("----------------" +l.getMedCode());
		}
		
	}
	@Test
	public void testgetMyDiseaseSmryInfo() {
		// 1000 1001 
		VOMyCollection voMyCollection = new VOMyCollection();
		voMyCollection.setUserId("liugc");
		voMyCollection.setType("D");
		voMyCollection.setInfoId("1000");
		JsonResponse<PageInfo<DiseaseSmryInfo>> response =  mycollectionService.getMyDiseaseSmryInfo(voMyCollection);
		PageInfo<DiseaseSmryInfo> page = response.getResult();
		List<DiseaseSmryInfo> result = page.getList();
		for(DiseaseSmryInfo l:result){
			System.out.println("----------------" +l.getDiseaseId());
		}
	}
	@Test
	public void testgetMyActivity() {
		// 06782d14-fc62-11e5-8333-005056885cdb 0ad57b34-6028-46fc-81f9-6948ecaf9aaf
		VOMyCollection voMyCollection = new VOMyCollection();
		voMyCollection.setUserId("liugc");
		voMyCollection.setType("A");
		voMyCollection.setInfoId("06782d14-fc62-11e5-8333-005056885cdb");
		JsonResponse<PageInfo<Activity>> response = mycollectionService.getMyActivity(voMyCollection);
		PageInfo<Activity> page = response.getResult();
		List<Activity> result = page.getList();
		for(Activity l:result){
			System.out.println("----------------" +l.getActivityId());
		}
	}
	
	@Test
	public void testdeleteMyCollection(){
		String userId ="liugc1";
		String type ="A";
		String infoId = "0ad57b34-6028-46fc-81f9-6948ecaf9aaf";
		mycollectionService.deleteMyCollection(userId, type, infoId);
	}
	
	@Test
	public void testgetCollectionStatistic(){
		String type ="A";
		String infoId = "info";
		VOMyCollection voMyCollection = new VOMyCollection();
		voMyCollection.setType(type);
		voMyCollection.setInfoId(infoId);
		JsonResponse<PageInfo<VOMyCollection>> jr = mycollectionService.getCollectionStatistic(voMyCollection);
		PageInfo<VOMyCollection> page = jr.getResult();
		List<VOMyCollection> result = page.getList();
		for(VOMyCollection vo : result){
			System.out.println(vo.getInfoId() + "," + vo.getCollectionStatistic());
		}
	}
	
	@Test
	public void testsyncMycollectionStatistc(){
		String dateStr = null;
		String type = "M";
		mycollectionService.syncMycollectionStatistc(dateStr,type);
	}
	
	@Test
	public void testinitMycollectionStatistc(){
		/*VOActivity voActivity = new VOActivity();
		List<String> infoIds = voActivityMapper.getAllActivityId(voActivity);
		String type = "A";*/
		VODiseaseSmryInfo voDiseaseSmryInfo = new VODiseaseSmryInfo();
		List<String> infoIds = voDiseaseSmryInfoMapper.getAllDiseaseId(voDiseaseSmryInfo);
		String type = "D";
		/*VOLocalMedicine voLocalMedicine = new VOLocalMedicine();
		List<String> infoIds = voLocalMedicineMapper.getAllMedicineId(voLocalMedicine);
		String type = "M";*/
		
		JsonResponse<String> jr = mycollectionService.initMycollectionStatistc(type,infoIds);
		System.out.println(jr.getResult());
		
		
	}
}
