package com.wanjia.dsi.product.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.web.callCenter.service.IssueOBProductServiceRecordService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ProductServiceRecordServiceImplTest {

	@Autowired
	public IssueOBProductServiceRecordService issueOBProductServiceRecordService;
	
	
	@Test
	public void testCreateIssuesOfLowEvaluation(){
		issueOBProductServiceRecordService.createIssuesOfLowEvaluation();
	}
}
