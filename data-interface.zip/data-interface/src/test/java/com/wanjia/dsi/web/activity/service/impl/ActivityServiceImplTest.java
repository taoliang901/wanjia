package com.wanjia.dsi.web.activity.service.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.activity.model.Activity;
import com.wanjia.dsi.web.activity.model.CmsPageConfig;
import com.wanjia.dsi.web.activity.model.WzSpecial;
import com.wanjia.dsi.web.activity.service.ActivityService;
import com.wanjia.dsi.web.elasticsearch.info.service.ElasticsearchInforService;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ActivityServiceImplTest {

	@Autowired
	private ActivityService activityService;
	@Autowired
	private ElasticsearchInforService elasticsearchInforService;
	
	@Test
	public void testGetWzSpecialList() {
		WzSpecial wzSpecial = new WzSpecial();
		wzSpecial.setShowSystem(0);
		wzSpecial.setIsShowInList(1);
		JsonResponse<PageInfo<WzSpecial>> jr = activityService.getWzSpecialList(wzSpecial);
		System.out.println(jr.getResult().getList());
	}
	@Test
	public void testgetCmsPageInfoListById() {
		JsonResponse<List<CmsPageConfig>> jr = activityService.getCmsPageInfoListById("gateway", null, "11", "4");
		List<CmsPageConfig> result = jr.getResult();
		System.out.println("------------------------------------");
		for(int i=0;i<result.size();i++){
			System.out.println(result.get(i).getPageConfigId() + "," + result.get(i).getPageConfigName());
		}
		System.out.println("------------------------------------");
	}

	@Test
	public void testgetActivityListByPageInfo() {
		/*JsonResponse<PageInfo<Activity>> jr = activityService.getActivityListByPageInfo("gateway", "11-4-1", "1", "10");
		PageInfo<Activity> page = jr.getResult();
		List<Activity> result = page.getList();
		System.out.println("------------------------------------");
		for(int i=0;i<result.size();i++){
			System.out.println(result.get(i).getPageConfigId() + "," + result.get(i).getActivityId() 
					+"," + result.get(i).getActivityTitle());
		}
		System.out.println("------------------------------------");*/
		
		List<Activity> informationListForApp = new ArrayList<Activity>();
		informationListForApp = activityService.getInformationListForApp("1", "1000000").getResult().getList();
		int i = 0;
		elasticsearchInforService.deleteAll();
		if (CollectionUtils.isNotEmpty(informationListForApp)) {
			for (Activity activity : informationListForApp) {
				if (StringUtils.isNotBlank(activity.getActivityId())) {
					activity.setId(activity.getActivityId());
					elasticsearchInforService.upsert(activity);
					i++;
				}
			}
		}
	}
	
	@Test
	public void testgetInformationListForApp() {
		JsonResponse<PageInfo<Activity>> jr = activityService.getInformationListForApp("1","100000000");
		PageInfo<Activity> page = jr.getResult();
		List<Activity> result = page.getList();
		System.out.println("------------------------------------");
		for(int i=0;i<result.size();i++){
			System.out.println(result.get(i).getPageConfigId() + "," + result.get(i).getActivityId() 
					+"," + result.get(i).getActivityTitle() + ",PageId:" 
					+ result.get(i).getPageId() + ",ActivityTypeId:" + result.get(i).getActivityTypeId() );
		}
		System.out.println("------------------------------------");
	}
	
	@Test
	public void testgetActivityListById() {
		String activityId = "890e0a45-caef-4506-94b9-a29ed18a0ef3";
		String source = "352621066268464|305963eb";
		JsonResponse<Activity>  jr = activityService.getActivityListById(null,activityId);
		Activity activity = jr.getResult();
		System.out.println("-----------------------------");
		System.out.println(activity.getId() + "," + activity.getActivityId() + "," + activity.getActivityTitle());
		System.out.println("-----------------------------");
		activityService.insertActivityClick(activityId, source);
	}
	
	@Test
	public void testgetAllActivityId() {
		Date beginDate = new Date();
		Date endDate = new Date();
		JsonResponse<List<String>> jr = activityService.getAllActivityId(beginDate, endDate);
		System.out.println("---------------------------------------");
		System.out.println(jr.getResult().size());
		System.out.println("---------------------------------------");
	}
	
	
}
