package com.wanjia.dsi.atlas.tools;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MapSearchTest {

//	private final String HTTP_POST_URL="http://172.18.51.9:8407/";
	
//	private final String HTTP_POST_URL="http://172.18.51.29:8407/";  //F5
	
	private final String HTTP_POST_URL="http://172.18.50.75:8407/";
	
	private static final String APPLICATION_JSON = "application/json";

	private static final String CONTENT_TYPE_TEXT_JSON = "text/json";

	/**
	 * post请求方式,参数为json.toString()格式
	 * @param url
	 * @param json
	 * @throws Exception
	 */
	public static String httpPostWithJSON(String url, String json) throws Exception {
		
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost httpPost = new HttpPost(url);
		httpPost.addHeader(HTTP.CONTENT_TYPE, APPLICATION_JSON);
		StringEntity se = new StringEntity(json, "utf8");
		se.setContentType(CONTENT_TYPE_TEXT_JSON);
		se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, 	APPLICATION_JSON));
		httpPost.setEntity(se);
		HttpResponse response = httpClient.execute(httpPost);
		if (response.getStatusLine().getStatusCode() == 200) {
			String res = EntityUtils.toString(response.getEntity());
			return res;
		} else {
			return response.getStatusLine().getStatusCode()+"";
		}
	}
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
		JSONObject req = new JSONObject();
		req.element("lon", 121.463106);
		req.element("lat", 31.189194);
		req.element("radius", 5.2);
		String reqstr = req.toString();
		String url = HTTP_POST_URL + "/data/searchClnc";
		
		String respStr = "";
		try {
			respStr = httpPostWithJSON(url, req.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("【周边诊所搜索】请求参数："+reqstr);
		System.out.println("【周边诊所搜索】返回结果："+respStr);
		
		req = new JSONObject();
		req.element("address", "平安大厦");
		req.element("city", "上海");
		reqstr = req.toString();
		url = HTTP_POST_URL + "/data/geocoding";
		String respStr2 = "";
		try {
			respStr2 = httpPostWithJSON(url, req.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		System.out.println("【按地址搜索】请求参数："+reqstr);
		System.out.println("【按地址搜索】返回结果："+respStr2);
		
		
		String respStr3 = "";
		req = new JSONObject();
//		req.element("ip", "116.226.186.167");
		req.element("ip", "101.95.97.246");
		reqstr = req.toString();
		url = HTTP_POST_URL + "/data/ip";
		
		try {
			respStr3 = httpPostWithJSON(url, req.toString());
		} catch (Exception e) {

			e.printStackTrace();
		}
		
		System.out.println("【按IP地址搜索】请求参数："+reqstr);
		System.out.println("【按IP地址搜索】返回结果："+respStr3);
	}

}
