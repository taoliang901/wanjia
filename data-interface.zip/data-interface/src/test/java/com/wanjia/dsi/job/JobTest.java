package com.wanjia.dsi.job;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job.model.ClinicSearch;
import com.wanjia.dsi.web.job.model.JobSearch;
import com.wanjia.dsi.web.job.model.TalentCvVo;
import com.wanjia.dsi.web.job.service.CvService;
import com.wanjia.dsi.web.job.service.JobService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class JobTest {
	
	@Autowired
	private JobService jobService;
	
	@Autowired
	private CvService cvService;
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		ClinicSearch clinicSearch = new ClinicSearch();
		clinicSearch.setPageNo("2");
		clinicSearch.setPageSize("10");
		System.out.println(jobService.getClinicSearchList("111", clinicSearch));
	}
	
	@Test
	public void getCvList() {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("delFlag", "0");
		param.put("memberId", "640");
		JsonResponse<List<TalentCvVo>> result = cvService.getCvList("test", param );
		System.out.println(result.getResult());
	}
	
	@Test
	public void getJobSearchList() {
		JobSearch jobSearch = new JobSearch();
		jobSearch.setExpectedSalaryMin(5000l);
		jobSearch.setJobProperty("01");
		JsonResponse<PageInfo<JobSearch>> result = jobService.getJobSearchList("test", jobSearch);
		System.out.println(result.getResult());
	}

}
