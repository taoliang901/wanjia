package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.json.JsonResponse.Status;
import com.wanjia.dsi.product.service.AgreementReadForClinicService;
import com.wanjia.dsi.product.service.PrdFinSettlementForClinicService;
import com.wanjia.dsi.product.vo.VOPrdFinSettlementForClinic;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PrdFinSettlementServiceForClinicImplTest {

	@Autowired
	private PrdFinSettlementForClinicService prdFinSettlementForClinicService;
	
	@Autowired
	private AgreementReadForClinicService agreementReadForClinicService;
	
	@Test
	public void testGetSettlementForClinic(){
		Map<String, Object> mapParam = new HashMap<String, Object>();
		List<String> clinicList = new ArrayList<String>();
		String clinicId = "d676560e-81f0-4cdc-b8b9-6782b9b9ea66";
		clinicList.add(clinicId);
		mapParam.put("clinicIdList", clinicList);
		mapParam.put("settleMonth", "2016.10");
		List<String> statusList = new ArrayList<String>();
		statusList.add("01");
		statusList.add("02");
		statusList.add("03");
		statusList.add("04");
		statusList.add("05");
		statusList.add("06");
		statusList.add("07");
		mapParam.put("statusList", statusList);
		
		JsonResponse<List<VOPrdFinSettlementForClinic>> jr = prdFinSettlementForClinicService.getPrdFinSettlementBillForClinic(mapParam);
		if(jr != null && Status.SUCCESS.equals(jr.getStatus()) ){
			if(CollectionUtils.isNotEmpty(jr.getResult())){
				List<VOPrdFinSettlementForClinic> settleForClinicList = jr.getResult();
				for(VOPrdFinSettlementForClinic vo : settleForClinicList){
//					System.out.println("数据："+vo.getSubAgreementStr());
				}
			}else{
				System.out.println("空数据");
			}
		}else{
			System.out.println(jr.getErrorMsg());
		}
	}
	
	/*
	@Test
	public void testGetSubContractForClinic(){
		Map<String, Object> mapParam = new HashMap<String, Object>();
				
		List<String> list = new ArrayList<String>();
		list.add("20161116");
		list.add("1232");
		list.add("1111");
		list.add("201601p");
		mapParam.put("contractNoList", list);
		mapParam.put("delFlag", "0");
		JsonResponse<List<VOPrdSubAgreementForClinic>> jr = agreementReadForClinicService.getSubAgreementInfoByNos(mapParam);
		if(jr != null && Status.SUCCESS.equals(jr.getStatus()) ){
			if(CollectionUtils.isNotEmpty(jr.getResult())){
				List<VOPrdSubAgreementForClinic> agreementForClinicList = jr.getResult();
				for(VOPrdSubAgreementForClinic vo : agreementForClinicList){
					System.out.println("数据："+vo.getContractNo());
				}
			}else{
				System.out.println("空数据");
			}
		}else{
			System.out.println(jr.getErrorMsg());
		}
	}
	*/
}
