package com.wanjia.dsi.web.wjkmj;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.invoker.Invoker;
import com.wanjia.dsi.web.job.model.TalentCv;
import com.wanjia.dsi.web.job.model.TalentCvVo;
import com.wanjia.dsi.web.job.model.TalentJobRecord;
import com.wanjia.dsi.web.job.service.impl.CvServiceImpl;
import com.wanjia.dsi.web.wjkmj.model.WjkmjDayCount;
import com.wanjia.dsi.web.wjkmj.service.WjkmjService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class WjkmjImplTest {

	@Autowired
	private WjkmjService wjkmjService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddCv() {
		WjkmjDayCount wjkmjDayCount = new WjkmjDayCount();
		wjkmjDayCount.setClinicId("17268143-14d1-47ff-99ec-dc1d20194c36");
		JsonResponse<PageInfo<WjkmjDayCount>> jr = wjkmjService.getWjkmjDayCountShowList(Invoker.web.getValue(),wjkmjDayCount, new Date(), "0:0:0:0:0:0:0:1", "twd.CREATE_DATE asc", 1, 1);
	}
	
}
