package com.wanjia.dsi.product;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.service.ProductMessageService;
import com.wanjia.dsi.product.service.ProductOrderService;
import com.wanjia.dsi.product.vo.VOPrdBooking;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class OrderServiceTest {

	@Autowired
	private ProductOrderService orderService;

	@Autowired
	private ProductMessageService productMessageService;
	
	@Test
	public void testEncrypt() throws ParseException{
		VOPrdBooking booking = new VOPrdBooking();
		booking.setRealName("test");
		booking.setMobile("13487098657");
		booking.setUserId("89");
		booking.setClinicId("5a225b0c-36bd-4194-85c5-1c26c0aa8644");
		booking.setClinicName("黄礼昊的开发诊所");
		booking.setCouponId("80f02d97-c1ae-489c-af07-207dbed9ba02");
		booking.setCouponName("云龙测试产品");
		// 编辑预约时就诊人的数量，现在为1
		booking.setEditOldVisitCnt(0);
		booking.setFlag("4");
		booking.setIsUnlimite("1");
		
		booking.setPrdKucunId("23968c84-51f7-49ee-801e-483cfa5f46cd");
		booking.setPrdServiceId("lgc_service_2");
		booking.setServiceCount(100);
		booking.setServiceName("测试停用");
		
		
		booking.setTreatDate("2016-11-05");
		booking.setTreatTime("08:00～09:00");
		/** 一次性产品（即：使用频次 0-一次使用,1-多次使用） */
		booking.setUseFrequence("1");
		List<HyTreatmentPerson> visitList = new ArrayList<HyTreatmentPerson>();
		HyTreatmentPerson hyTreatmentPerson = new HyTreatmentPerson();
		hyTreatmentPerson.setVisitId("006d90ec-e0c4-48a5-86cd-92cfe349df1b");
		hyTreatmentPerson.setVisitMobile("13487846561");
		hyTreatmentPerson.setVisitName("232");
		visitList.add(hyTreatmentPerson);
		booking.setVisitList(visitList );
		JsonResponse<Void> result = orderService.submitOrder(booking);
		System.out.println(result.getStatus());
	}
	
	@Test
	public void findHyUsers(){
		JsonResponse<Set<String>> result = productMessageService.findHyUsers("123");
		System.out.println(result.getStatus());
	}
	
	@Test
	public void findBookingMessage(){
		JsonResponse<VOPrdBooking> result = orderService.findBookingMessage("JM9590190008");
		System.out.println(result.getStatus());
	}
	
	@Test
	public void receiveProduct(){
		JsonResponse<String> result = productMessageService.receiveProduct("0a234fea-d5c0-4a6f-ba9b-71653df18418", "640");
		System.out.println(result.getStatus());
	}
//	@Test
//	public void loadBookingMessage(){
//		JsonResponse<VOPrdKucunMUI> jr = orderService.loadBookingMessage("203", "f0dea86f-94a7-4d04-a184-44a4dae7f622", "6843e2c8-16ef-4497-b1ae-d29518bb943a", null, null, null);
//		System.out.println(jr.getResult());
//	}
	
	@Test
	public void findClinicsByProduct(){
//		JsonResponse<VOPrdAllClinics> result = productMessageService.findClinicsByProduct("7b54f6e4-3917-4b2a-badb-854f9380167f", "640", "0e260e4f-c819-4695-8ca0-6bec4911d876");
//		System.out.println(result.getResult());
	}
	
	@Test
	public void activateProduct(){
		HyTreatmentPerson person = new HyTreatmentPerson();
		person.setVisitId(UUID.randomUUID().toString());
		JsonResponse<Boolean> result = orderService.activateProduct(person , "640", "80f02d97-c1ae-489c-af07-207dbed9ba02", "13f56d33-d41c-4787-aedf-f3a3bc919534", "111111");
		System.out.println(result.getStatus());
	}
}
