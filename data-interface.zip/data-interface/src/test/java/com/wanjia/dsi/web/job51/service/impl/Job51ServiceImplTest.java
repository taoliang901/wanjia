package com.wanjia.dsi.web.job51.service.impl;


import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinictalent.service.TalentJobService;
import com.wanjia.dsi.web.job.model.TalentJob;
import com.wanjia.dsi.web.job.model.TalentJobWithBLOBs;
import com.wanjia.dsi.web.job.service.CvService;
import com.wanjia.dsi.web.job51.model.Job51Account;
import com.wanjia.dsi.web.job51.service.Job51Service;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class Job51ServiceImplTest {

	@Autowired
	private Job51Service job51Service;
	
	@Autowired
	private TalentJobService talentJobService;
	
	@Autowired
	private CvService cvService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testSearch51JOBIntoMysql() throws Exception {
		job51Service.search51JOBIntoMysql("20160101","20161024");
	}
	
	@Test
	public void testAddSystemUser() throws Exception {
		Job51Account job51Account = new Job51Account();
		job51Account.setClinicId("pinganwj");
		job51Service.addUser(job51Account);
	}

	@Test
	public void testAddUser() throws Exception {
		Job51Account job51Account = new Job51Account();
		job51Account.setClinicId("c420f4dc-7682-412e-a78c-4601b361cf44");
		job51Service.addUser(job51Account);
	}
	
//	@Test
//	public void testModifypassword() throws Exception {
//		job51Service.modifypassword("1576934","123qwer","9f120c529d6ef1f63ed7b1873efa775d");
//	}
//	
	@Test
	public void testDeleteuser() throws Exception {
		job51Service.deleteuser("c420f4dc-7682-412e-a78c-4601b361cf44");
	}
	
	
	@Test
	public void testSearchresume() throws Exception {
		job51Service.searchresume("3502320","8b39c15f66625c08d88dd5e04ffdb1d0","20161009","20161010","1");
	}
	
	@Test
	public void testViewresume() throws Exception {
		job51Service.viewresume("pinganwj","355414772");
//		job51Service.viewresume("pinganwj","353904642");
	}
	
	@Test
	public void testHasDownload() throws Exception {
		job51Service.hasDownload("c420f4dc-7682-412e-a78c-4601b361cf44","25308336");
	}
	
	@Test
	public void downloadresume() throws Exception {
		job51Service.downloadresume("c420f4dc-7682-412e-a78c-4601b361cf44","100115");
	}
	
	@Test
	public void search51JOBList() throws Exception {
		Map<String,String> hashMap = new HashMap<String,String>();
		hashMap.put("cityName", "上海市");
		hashMap.put("areaName", "静安区");
		hashMap.put("pageNo", "1");
		hashMap.put("pageSize", "5");
		hashMap.put("orderby", "1");
		hashMap.put("keyWord", "医生");
		
		JsonResponse<PageInfo<LinkedHashMap<String, Object>>> result = job51Service.search51JOBList(hashMap);
		System.out.println(result.getResult());
	}
	
	@Test
	public void getTalentJobListByClinicId() throws Exception {
		Map<String,String> hashMap = new HashMap<String,String>();
		hashMap.put("clinicId", "c420f4dc-7682-412e-a78c-4601b361cf44");
		hashMap.put("status", "3");
		
		JsonResponse<List<TalentJobWithBLOBs>> result = talentJobService.getTalentJobListByClinicId(hashMap);
		System.out.println(result.getResult());
	}
	
	@Test
	public void testGetCv() {
		this.cvService.getCvDetailTransDictById("clinic", "035bcc3c-292e-407b-8840-bcc5ffa0e217");
	}
	
	
}
