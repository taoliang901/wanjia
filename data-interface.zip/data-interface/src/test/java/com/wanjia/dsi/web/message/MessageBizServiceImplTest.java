package com.wanjia.dsi.web.message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.web.message.service.MessageService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class MessageBizServiceImplTest {
	private static final String clincId = "495a8463-0a29-413c-92a5-d0b05add2326";
	@Autowired
	private MessageService messageService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSendMessageAboutBooking(){
//		this.messageService.patientCancelBookingNormal("", "", "张医生", "2012-12-12", "c420f4dc-7682-412e-a78c-4601b361cf44", "FUCK");
//		this.messageService.patientCancelBooking("", "", "李医生", "2012-12-12 12:25", clincId, "what's this?patientCancelBooking is?");
//		this.messageService.patientRatedNormal("", "", "王医生", "2012-12-12 12:25", clincId, "what's this? patientRatedNormal is?");
//		this.messageService.patientRated("", "", "琳医生", "2012-12-12 12:25", clincId, "what's this? patientRated is?");
		this.messageService.medicinesStockLimitWarning(clincId, "十全大补丸1", "10", "100","1");
		this.messageService.medicinesStockLimitWarning(clincId, "十全大补丸1", "100", "10","1");
	}
	
	@Test
	public void testSendMessageToUserAndUnderling(){
		
		Map<String, Object> params = new HashMap<String,Object>();
		List<String> casUuids = new ArrayList<String>();
		casUuids.add("20927f7c-5952-4ee2-bfab-a5c6c99e533b");
		params.put("casUuids", casUuids);
		params.put("acceptRoleId", Consts.SYS_ROLE_PATIENT_VALUE);
		params.put("messageTopic", "预约提醒");
		params.put("appMessageType", "3");
		params.put("isPush", "1");
		params.put("channel", "2");
		params.put("receiveIdType", Consts.IS_CLINIC_ID);
		params.put("messageTypeId", "2");//系统公告
		params.put("content", "您好！您今日共有11个预约患者，可提前查看患者信息。!");
		Map<String,String> jumpParam = new HashMap<String,String>();
		jumpParam.put("moduleId", "05");
		params.put("jumpParam", jumpParam);
		params.put("jumpType", Consts.JUMP_TYPE_MODEL);
		this.messageService.sendMessageToUserAndUnderling(params );
	}
}
