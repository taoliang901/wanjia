package com.wanjia.dsi.web.cms.activity.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.activity.model.VOActivity;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VOActivityMapper;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VODiseaseSmryInfoMapper;
import com.wanjia.dsi.web.cms.activity.dao.mapper.VOLocalMedicineMapper;
import com.wanjia.dsi.web.cms.activity.model.InfomationClickBO;
import com.wanjia.dsi.web.cms.activity.model.InfomationStatistcBO;
import com.wanjia.dsi.web.cms.activity.model.VODiseaseSmryInfo;
import com.wanjia.dsi.web.cms.activity.model.VOInfomationStatistc;
import com.wanjia.dsi.web.cms.activity.model.VOLocalMedicine;
import com.wanjia.dsi.web.cms.activity.service.InfomationService;
import com.wanjia.dsi.web.cms.activity.service.InfomationStatistcService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class InfomationServiceImplTest {
	@Autowired
	InfomationService infomationService;
	@Autowired
	VOActivityMapper voActivityMapper;
	@Autowired
	VOLocalMedicineMapper voLocalMedicineMapper;
	@Autowired
	VODiseaseSmryInfoMapper voDiseaseSmryInfoMapper;
	
	@Test
	public void testinsertOrUpdateInfomationStatistc(){
		InfomationClickBO infomationClickBO = new InfomationClickBO();
		String infoId = "testInfo8";
		String type = "M";
		infomationClickBO.setInfoId(infoId);
		infomationClickBO.setType(type);
		infomationService.insertOrUpdateInfomation(infomationClickBO);
	}
	@Test
	public void testgetInfomationStatistic(){
		VOInfomationStatistc voInfomationStatistc = new VOInfomationStatistc();
		List<String> infoIds = new ArrayList<String>();
		infoIds.add("testInfo7");
		infoIds.add("testInfo8");
		infoIds.add("testInfo9");
		String type = "M";
		//voInfomationStatistc.setInfoId(infoId);
		voInfomationStatistc.setType(type);
		JsonResponse<List<InfomationStatistcBO>> jr = infomationService.getInfomationStatistic(type,infoIds);
		List<InfomationStatistcBO>  infoList = jr.getResult();
		for(InfomationStatistcBO info:infoList){
			System.out.println("-------------------" + info.getInfoId() + "," + info.getType() + "," + info.getCountNum());
		}
	}
	
	/*@Test
	public void testsyncInfomationClick(){
		String dateStr = "2016-12-14";
		String type = "A";
		JsonResponse<String>  jr = infomationService.syncInfomationClick(dateStr, type);
		System.out.println(jr.getResult());
	}*/
	@Test
	public void testsyncInfomationStatistc(){
		String dateStr = null;
		String type = "A";
		JsonResponse<String>  jr = infomationService.syncInfomationStatistc(dateStr, type);
		System.out.println(jr.getResult());
	}
	
	@Test
	public void testinitInfomationStatistic(){
		/*VOActivity voActivity = new VOActivity();
		List<String> infoIds = voActivityMapper.getAllActivityId(voActivity);
		String type = "A";*/
		/*VODiseaseSmryInfo voDiseaseSmryInfo = new VODiseaseSmryInfo();
		List<String> infoIds = voDiseaseSmryInfoMapper.getAllDiseaseId(voDiseaseSmryInfo);
		String type = "D";*/
		VOLocalMedicine voLocalMedicine = new VOLocalMedicine();
		List<String> infoIds = voLocalMedicineMapper.getAllMedicineId(voLocalMedicine);
		String type = "M";
		JsonResponse<String>  jr = infomationService.initInfomationStatistic(type,infoIds);
		System.out.println(jr.getResult());
	}
}
