package com.wanjia.dsi.web.hyPerson.service.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.service.RegisterBindService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class RegisterBindServiceImplTest {
	
	@Autowired
	private RegisterBindService registerBindService;
	@Test
	public void testWxUserBind() {
		JsonResponse<Boolean> jr = registerBindService.wxUserBind("203", "203");
		System.out.println(jr);
		
	}

}
