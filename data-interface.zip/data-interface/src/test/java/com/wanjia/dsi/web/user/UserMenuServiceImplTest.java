package com.wanjia.dsi.web.user;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.Assert;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.user.model.TreeDataModel;
import com.wanjia.dsi.web.user.model.UserMenuBean;
import com.wanjia.dsi.web.user.service.HtUserService;
import com.wanjia.dsi.web.user.service.UserMenuService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class UserMenuServiceImplTest {

	@Autowired
	private UserMenuService userMenuService;
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testUserList(){
		
		JsonResponse<List<TreeDataModel<UserMenuBean>>> json = userMenuService.getUserList("webcms", "wanjia");
		System.out.println("===========================" + json.getStatus());
		List<TreeDataModel<UserMenuBean>> list = json.getResult();
		TreeDataModel<UserMenuBean> treeDataModel = list.get(0);
		Assert.notNull(treeDataModel);
		List<TreeDataModel<UserMenuBean>> menuList = treeDataModel.getChildren();
		if(menuList != null) {
			System.out.println("===========================" + menuList.size());
		}
	}
}
