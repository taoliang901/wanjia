package com.wanjia.dsi.sso;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.sso.service.QRCodeService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class QRCodeServiceImplTest {

	@Autowired
	private QRCodeService qrCodeService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	// 二维码登录，绑定用户信息
	@Test
	public void testBindCasUser() throws Exception {

		String casUuid = "a6d8350f-15d1-476e-9234-07aae55551de";
		String redisKey = "1ecbe2fe-449f-40c9-982d-518c5e62cb18";
		JsonResponse<Void> jr = qrCodeService.bindCasUser(redisKey, casUuid);

		System.out.println("====================>" + jr.getStatus().toString());
	}
}
