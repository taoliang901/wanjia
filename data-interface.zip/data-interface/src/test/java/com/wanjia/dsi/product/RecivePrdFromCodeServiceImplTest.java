package com.wanjia.dsi.product;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.common.utils.CommonTools;
import com.wanjia.dsi.product.dao.mapper.PrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.PrdKucunMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderDetailMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderDetailServiceMapper;
import com.wanjia.dsi.product.dao.mapper.PrdOrderMapper;
import com.wanjia.dsi.product.dao.mapper.PrdServiceMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdInfoMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdKucunMapper;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.model.PrdInfoExample;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.PrdKucunExample;
import com.wanjia.dsi.product.model.PrdOrder;
import com.wanjia.dsi.product.model.PrdOrderDetail;
import com.wanjia.dsi.product.model.PrdOrderDetailService;
import com.wanjia.dsi.product.model.PrdService;
import com.wanjia.dsi.product.model.PrdServiceExample;
import com.wanjia.dsi.product.service.impl.RecivePrdFromCodeServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class RecivePrdFromCodeServiceImplTest {

	@Autowired
	private PrdOrderMapper prdOrderMapper;
	@Autowired
	private PrdOrderDetailMapper prdOrderDetailMapper;
	@Autowired
	private PrdOrderDetailServiceMapper prdOrderDetailServiceMapper;
	@Autowired
	private PrdKucunMapper prdKucunMapper;
	@Autowired
	private PrdInfoMapper prdInfoMapper;
	@Autowired
	private VOPrdKucunMapper voPrdKucunMapper;
	@Autowired
	private PrdServiceMapper prdServiceMapper;
	@Autowired
	private RecivePrdFromCodeServiceImpl recivePrdFromCodeServiceImpl;

	@Test
	public void testcheckPrdIdAndReceiveCode(){//已测试
		String prdId = "735312e0-35ba-4663-936c-5d418c226fe3";
		String receiveCode = "123";
		PrdKucun result = recivePrdFromCodeServiceImpl.checkPrdIdAndReceiveCode(prdId,receiveCode) ;
		System.out.println(result);
	}
	
// ("liugc-prdid01", 123, "123");
	/*@Test	
	public void testcheckAmount(){//已测试
		String prdId = "liugc-prdid01";
		boolean result = recivePrdFromCodeServiceImpl.checkAmount(prdId) ;
		System.out.println(result);
	}*/

	@Test
	public void testisNoRecevied(){//已测试
		String prdId = "735312e0-35ba-4663-936c-5d418c226fe3";
		String userId = "123";
		boolean result = recivePrdFromCodeServiceImpl.isNoRecevied( prdId, userId) ;
		System.out.println(result);
	}
	
	@Test
	public void testgetKucunIdByBuyerAndPrdId(){//已测试
		PrdKucun prdKucun = new PrdKucun();
		prdKucun.setCouponId("liugc-test");
		prdKucun.setBuyerUserId("123");
		prdKucun.setDelFlag("0");
		prdKucun.setStatus("0");
		String result = voPrdKucunMapper.getKucunIdByBuyerAndPrdId(prdKucun);
		System.out.println(result);
}
	
	@Test
	public void testgetKucunIdByLimitOne(){
		
		PrdKucun prdKucun = new PrdKucun();
		prdKucun.setCouponId("liugc-prdid01");
		/*prdKucun.setDelFlag("0");
		prdKucun.setStatus("0");
		prdKucun.setModifyUser(String.valueOf("123"));
		prdKucun.setModifyDate(new Date());*/
		String result = voPrdKucunMapper.getKucunIdByLimitOne(prdKucun);
		System.out.println(result);
	}
	
	@Test
	public void testupdateByExampleSelective(){//已测试
	PrdKucunExample ex = new PrdKucunExample();
	PrdKucunExample.Criteria excr = ex.createCriteria();
	excr.andIdEqualTo("liugc-001");
	excr.andBuyerUserIdIsNotNull();
	PrdKucun record = new PrdKucun();
	record.setBuyerUserId("1231");
	record.setModifyDate(new Date());
	record.setModifyUser("1231");
	int result = prdKucunMapper.updateByExampleSelective(record, ex);
	System.out.println(result);
	}

	@Test
	public void testinsertSelective() {//已测试
		// 插入订单表
		PrdOrder prdOrder = new PrdOrder();
		String orderId = CommonTools.generateUUID();
		prdOrder.setId(orderId);
		prdOrder.setUserId((long)123);
		prdOrder.setCreateUser("123");
		int result = prdOrderMapper.insertSelective(prdOrder);
		System.out.println(result);
	}

	
	@Test
	public void testselectByExample() {//已测试
	PrdInfoExample record = new PrdInfoExample();
	PrdInfoExample.Criteria cri = record.createCriteria();
	cri.andIdEqualTo("0446846f-e841-4c18-8872-0c83bf06b20b");
	List<PrdInfo> prdInfoList = prdInfoMapper.selectByExample(record);
	System.out.println("------------" + prdInfoList.size());
	for(PrdInfo prdInfo: prdInfoList){
		System.out.println(prdInfo.getId());
	}
	}

@Test	
public void testinsertDetailSelective(){//已测试
	PrdInfoExample record = new PrdInfoExample();
	PrdInfoExample.Criteria cri = record.createCriteria();
	cri.andIdEqualTo("0446846f-e841-4c18-8872-0c83bf06b20b");
	List<PrdInfo> prdInfoList = prdInfoMapper.selectByExample(record);
	for(PrdInfo prdInfo: prdInfoList){
		PrdOrderDetail prdOrderDetail = new PrdOrderDetail();
		String orderDetailId =  CommonTools.generateUUID();
		prdOrderDetail.setId(orderDetailId);
		prdOrderDetail.setOrderId("12");
		prdOrderDetail.setKucunId("123");
		prdOrderDetail.setPrdId("0446846f-e841-4c18-8872-0c83bf06b20b");
		prdOrderDetail.setPrdTypeName(prdInfo.getPrdTypeName());
		prdOrderDetail.setPrdSupply(prdInfo.getPrdSupply());
		prdOrderDetail.setPrdChannel(prdInfo.getPrdChannel());
		prdOrderDetail.setCouponName(prdInfo.getCouponName());
		prdOrderDetail.setPrdPhoto(prdInfo.getPrdPhoto());
		prdOrderDetail.setPrdIntroduce(prdInfo.getPrdIntroduce());
		prdOrderDetail.setPrdInstruct(prdInfo.getPrdInstruct());
		prdOrderDetail.setPrdBeginDate(prdInfo.getPrdBeginDate());
		prdOrderDetail.setPrdEndDate(prdInfo.getPrdEndDate());
		prdOrderDetail.setPrdPrice(prdInfo.getPrdPrice());
		prdOrderDetail.setPrdPriceUnit(prdInfo.getPrdPriceUnit());
		prdOrderDetail.setIsFreeUse(prdInfo.getIsFreeUse());
		prdOrderDetail.setFreeUseValue(prdInfo.getFreeUseValue());
		prdOrderDetail.setFreeUseUnit(prdInfo.getFreeUseUnit());
		prdOrderDetail.setIsNeedPassword(prdInfo.getIsNeedPassword());
		prdOrderDetail.setIsNeedManyUse(prdInfo.getIsNeedManyUse());
		prdOrderDetail.setUpperLimit(prdInfo.getUpperLimit());
		prdOrderDetail.setIsNeedManyBook(prdInfo.getIsNeedManyBook());
		prdOrderDetail.setBookUpperLimit(prdInfo.getBookUpperLimit());
		prdOrderDetail.setSettlementMethod(prdInfo.getSettlementMethod());
		prdOrderDetail.setSettlementValue(prdInfo.getSettlementValue());
		prdOrderDetail.setUseBeginTime(prdInfo.getUseBeginTime());
		prdOrderDetail.setUseEndTime(prdInfo.getUseEndTime());
		prdOrderDetail.setIsWeekendOn(prdInfo.getIsWeekendOn());
		prdOrderDetail.setIsHolidayOn(prdInfo.getIsHolidayOn());
		prdOrderDetail.setProvince(prdInfo.getProvince());
		prdOrderDetail.setCity(prdInfo.getCity());
		prdOrderDetail.setRegisterOperation(prdInfo.getRegisterOperation());
		prdOrderDetail.setRegisterValue(prdInfo.getRegisterValue());
		prdOrderDetail.setRegisterUnit(prdInfo.getRegisterUnit());
		prdOrderDetail.setActiveOperation(prdInfo.getActiveOperation());
		prdOrderDetail.setActiveValue(prdInfo.getActiveValue());
		prdOrderDetail.setActiveUnit(prdInfo.getActiveUnit());
		prdOrderDetail.setCheckValue(prdInfo.getCheckValue());
		prdOrderDetail.setCouponStock(prdInfo.getCouponStock());
		prdOrderDetail.setStatus(prdInfo.getStatus());
		prdOrderDetail.setDelFlag(String.valueOf(prdInfo.getDelFlag()));
		prdOrderDetail.setCreateUser(String.valueOf("123"));
		prdOrderDetail.setCreateDate(new Date());
		prdOrderDetailMapper.insertSelective(prdOrderDetail);
}
	
}	
	@Test
	public void testinsertServiceSelective(){//已测试
			PrdServiceExample ser = new PrdServiceExample();
			PrdServiceExample.Criteria crit = ser.createCriteria();
			crit.andPrdIdEqualTo("coupon_test_1");
			List<PrdService> serviceList = prdServiceMapper.selectByExample(ser);
			for(PrdService service : serviceList){
				PrdOrderDetailService prdOrderDetailService = new PrdOrderDetailService();
				prdOrderDetailService.setId(CommonTools.generateUUID());
				prdOrderDetailService.setOrderDetailId("12");
				prdOrderDetailService.setPrdId("coupon_test_1");
				prdOrderDetailService.setServiceId(service.getServiceId());
				prdOrderDetailService.setServiceCount(service.getServiceCount());
				prdOrderDetailService.setIsUnlimite(service.getIsUnlimite());
				prdOrderDetailService.setDelFlag(service.getDelFlag());
				prdOrderDetailService.setCreateUser(String.valueOf("123"));
				prdOrderDetailService.setCreateDate(new Date());
				prdOrderDetailServiceMapper.insertSelective(prdOrderDetailService);
			}
		}
	

	@Test
	public void testinsertOrderDetailService(){
		recivePrdFromCodeServiceImpl.insertOrderDetailService("liugc-prdid01", 1233, /*"liugc-001"*/null, "123", null);
		
	}
	
	@Test
	public void testreciveCode(){
		JsonResponse<String>  result = recivePrdFromCodeServiceImpl.reciveCode("a3a996bc-2dd6-405e-baf1-670b3c1d1f5d ", 25, null);
		System.out.println(result.getErrorMsg());
	}
	
//	@Test
//	public void testActiveProduct(){
//		JsonResponse<String> jr = recivePrdFromCodeServiceImpl.activeProduct("445", "de2a04a3-e01b-4a5f-bdec-8f0c250c9888", 
//				"45391490", "e358a7ec-0e9a-415b-9156-ec95027e048c","smsId_b8d12405-5e6b-40ce-bcee-0e77485e0158","473992");
//		System.out.println(jr.getResult());
//	}

	@Test
	public void testrecieveCode(){
		JsonResponse<String> jr = recivePrdFromCodeServiceImpl.reciveCode("8d189357-3160-42ca-b849-ff7cef1186b0", 445);
//		JsonResponse<String> jr = recivePrdFromCodeServiceImpl.reciveCode("9df90097-6766-4a9f-9c3e-6e8c7b339800", 445);
		System.out.println(jr.getResult());
	}
	
}
