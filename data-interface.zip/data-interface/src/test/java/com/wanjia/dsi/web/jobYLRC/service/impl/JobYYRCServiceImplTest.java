package com.wanjia.dsi.web.jobYLRC.service.impl;


import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.web.jobYYRC.model.MemInfo;
import com.wanjia.dsi.web.jobYYRC.service.JobYYRCService;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class JobYYRCServiceImplTest {

	@Autowired
	private JobYYRCService resumeService;
	

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testSearchResume() throws Exception {
		//设置搜索关键词
		Map<String,String> searchPramMap = new HashMap<String,String>();
//		{pageNo=1, orderby=1, pageSize=5}
		searchPramMap.put("pageNo", "1");
		searchPramMap.put("pageSize", "10");
//		searchPramMap.put("orderby", "1");
//		searchPramMap.put("keyWord", "护士");
//		searchPramMap.put("jobLocation", "0200");
//		searchPramMap.put("cityName", "苏州市");
//		searchPramMap.put("intentionJob", "1002");
		
		resumeService.searchResume(searchPramMap);
	}
	
	@Test
	public void testViewResume() throws Exception {
		resumeService.viewResume("","1340215");
	}
	
	@Test
	public void testDownloadResume() throws Exception {
		resumeService.downloadResume("c420f4dc-7682-412e-a78c-4601b361cf44","54624");
	}
	
}
