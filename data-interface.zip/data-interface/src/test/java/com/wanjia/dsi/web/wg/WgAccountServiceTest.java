package com.wanjia.dsi.web.wg;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.wg.model.WgAccount;
import com.wanjia.dsi.web.wg.service.WgAccountService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class WgAccountServiceTest {

	@Resource
	private WgAccountService wgAccountService;
	
	@Test
	public void testFindWgAccount() throws Exception {
		JsonResponse<WgAccount> jresp = wgAccountService.findWgAccount("qqqqq1", "MZ4LheKby+2Ou1vtgA41iQ==");
		System.out.println(jresp);
	}
}
