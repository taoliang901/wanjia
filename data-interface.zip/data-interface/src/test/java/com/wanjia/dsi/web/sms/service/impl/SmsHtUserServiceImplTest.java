package com.wanjia.dsi.web.sms.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.pahaoche.member.util.Tools;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.sms.model.HtUser;
import com.wanjia.dsi.web.sms.service.SmsHtUserService;
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class SmsHtUserServiceImplTest {
	@Autowired
	private SmsHtUserService smsHtUserService;
	@Test
	public void testFindByMobileAndPassWord() {
		HtUser htUser   =new HtUser();
		htUser.setUserCode("ceshiyixia");
		htUser.setPassword(Tools.getMD5Str("wj123456"));
		JsonResponse<HtUser> jr = smsHtUserService.findByMobileAndPassWord(htUser);
		System.out.println(jr.getResult());
	}

}
