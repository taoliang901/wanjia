package com.wanjia.dsi.product.service.impl;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.model.PrdOrder;
import com.wanjia.dsi.product.model.ProductInfo;
import com.wanjia.dsi.product.service.ProductService;
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ProductServiceImplTest {
	
	@Autowired
	private ProductService productService;
	
	@Test
	public void testGetContractList() {
	
	}

	@Test
	public void testFindCouponDetail() {
		
	}

	@Test
	public void testListPrdInventoryByPrdIds() {
		
	}

	@Test
	public void testGetProduceInfo() {
		ProductInfo productInfo = new ProductInfo();
		productInfo.setId("73194626-ee7f-44cd-afee-0072fe840098");
//		JsonResponse<ProductInfo> jr = productService.getProduceInfo(productInfo);
		JsonResponse<ProductInfo> jr = productService.findCouponDetail(productInfo );
		System.out.println(jr.getResult().getCity());
	}

	@Test
	public void testGetProduceList() {
		ProductInfo productInfo = new ProductInfo();
		productInfo.setPageNo(1);
		productInfo.setPageSize(10);
		productInfo.setSort("PRD_PRICE");
//		productInfo.setSort("USED_TOTAL");
		productInfo.setOrder("DESC");
		JsonResponse<PageInfo<ProductInfo>> jr = productService.getProduceList(productInfo);
		 List<ProductInfo> list = jr.getResult().getList();
		 for (ProductInfo productInfo2 : list) {
			System.out.println(productInfo2.getPrdPrice()+"-----"+productInfo2.getUsedTotal());
		}
	}

	@Test
	public void testGetOnlineProduceInfoMapOfStringObjectIntInt() {
	}

	@Test
	public void testGetOnlineProduceInfoMapOfStringObject() {
		
	}

	@Test
	public void testGetOnlineProduceTypeList() {
		
	}

	@Test
	public void testGetOnlineProduceInfoForList() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("isFrontShow", "0");
		map.put("prdTypeName", "中医保健");
		productService.getOnlineProduceInfoForList(map, 10, 1);
	}

	@Test
	public void testGetPrdTypeByName() {
	}
	
	@Test
	public void testgetProduceList(){
		ProductInfo productInfo = new ProductInfo();
		productInfo.setCouponName("微信");
		JsonResponse<PageInfo<ProductInfo>> list = productService.getProduceList(productInfo);
		System.out.println(list);
	}
}
