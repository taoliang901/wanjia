/**
 * 
 */
package com.wanjia.dsi.product.service.impl;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.product.service.PrdPaymentService;

/**
 * @author huanglei698
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PrdPaymentServiceImplTest {

	private Logger logger = Logger.getLogger(PrdPaymentServiceImplTest.class);

	@Autowired
	private PrdPaymentService prdPaymentService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	// @Test
	public void test() {
	}

	@Test
	public void updateAllStockStatus() {
		for (int i = 0; i < 10; i++) {
			long timestamp = System.currentTimeMillis();
			String id = "PAY_" + timestamp;
			// prdPaymentService.setUnpayPayment(id, timestamp);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			prdPaymentService.produceOutOfTimePayments();
		}
	}
}
