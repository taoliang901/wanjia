package com.wanjia.dsi.web.cms.appmanager.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.appmanager.model.AppVersion;
import com.wanjia.dsi.web.cms.appmanager.service.AppVersionService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class AppVersionServiceImplTest {

	@Autowired
	AppVersionService appVersionService;

	@Test
	public void testgetAppVersionList() {
		String appNameCode = "02";
		String releasePlatform = "01";
		String appChannelCode = "360";
		AppVersion appVersion = new AppVersion();
		appVersion.setAppNameCode(appNameCode);
		appVersion.setReleasePlatform(releasePlatform);
		appVersion.setAppChannelCode(appChannelCode);
		JsonResponse<AppVersion> jr = appVersionService.getAppVersion(appVersion);
		AppVersion a = jr.getResult();
		System.out.println("-----------------------------");
			System.out.println(a.getAppNameCode() + "," + a.getReleasePlatform() + ","
					+ a.getReleaseDate() + "," + a.getDownloadUrl() + "," + a.getAppChannelCode());
			System.out.println("-----------------------------");
	}
}
