package com.wanjia.dsi.web.area.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.alibaba.fastjson.JSON;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.area.service.AreaService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class AreaImplTest {

	@Autowired
	private AreaService areaService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSelect() {
		List<String> areaIds = new ArrayList<String>();
		areaIds.add("838");
		areaIds.add("2");

		JsonResponse<List<Area>> healthJr = areaService.getAllCityOpenRegion(areaIds);
		System.out.println("----" + JSON.toJSONString(healthJr));
	}
	
	@Test
	public void testFindHotCity(){
		JsonResponse<List<Area>> jr = areaService.findHotCity(1, 8);
		System.out.println(jr.getResult());
	}
}
