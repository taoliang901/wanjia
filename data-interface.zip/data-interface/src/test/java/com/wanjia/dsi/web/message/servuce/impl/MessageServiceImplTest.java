package com.wanjia.dsi.web.message.servuce.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.mongodb.Pagination;
import com.wanjia.dsi.web.message.model.MessageBO;
import com.wanjia.dsi.web.message.model.VOMessage;
import com.wanjia.dsi.web.message.service.MessageService;
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class MessageServiceImplTest {
	
	@Autowired
	private MessageService messageService;
	
	@Test
	public void testFindMessage() {
		
		MessageBO messageBO = new MessageBO();
		messageBO.setReceiverId("203");
		messageBO.setAcceptRole("1,3");
		messageBO.setIsRead("0");
		messageBO.setStatus("1");
		messageBO.setChannel("1");
		messageBO.setIsShow("1");
		JsonResponse<Pagination<MessageBO>> jr = messageService.findMessage(messageBO, 1, 10);
		System.out.println(jr);
	}
	@Test
	public void testfindMessageNoPage() {
		
		MessageBO messageBO = new MessageBO();
		messageBO.setClinicId("a1d8c8d2-0831-46cf-886e-20b3d08f76a0");
		messageBO.setReceiverId("313");
		messageBO.setAcceptRoleId("2");
		messageBO.setChannel("2");
		JsonResponse<List<MessageBO>> jr = messageService.findMessageNoPage(messageBO, 1, 100);
		List<MessageBO> list = jr.getResult();
		for(MessageBO m:list){
			System.out.println(m.getId() + "," + m.getClinicId());
		}
	}
	
	@Test
	public void testfindRecentMessageAndUnreadTotal() {
		
		MessageBO messageBO = new MessageBO();
		messageBO.setClinicId("a1d8c8d2-0831-46cf-886e-20b3d08f76a0");
		messageBO.setReceiverId("313");
		messageBO.setAcceptRoleId("2");
		messageBO.setChannel("2");
		JsonResponse<List<VOMessage>> jr = messageService.findRecentMessageAndUnreadTotal(messageBO);
		List<VOMessage> list = jr.getResult();
		for(VOMessage v: list){
			System.out.println(v.getMessageTypeId() + "," + v.getUnReadTotal());
		}
		
	}
}
