package com.wanjia.dsi.job;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job.model.ClinicSearch;
import com.wanjia.dsi.web.job.model.HyJobRecord;
import com.wanjia.dsi.web.job.model.TalentCvDetail;
import com.wanjia.dsi.web.job.model.TalentCvVo;
import com.wanjia.dsi.web.job.service.CvEducationService;
import com.wanjia.dsi.web.job.service.CvService;
import com.wanjia.dsi.web.job.service.JobService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class CvEducationTest {
	
	@Autowired
	private JobService jobService;
	
	@Autowired
	private CvService cvService;
	
	@Autowired
	private CvEducationService cvEducationService;
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		ClinicSearch clinicSearch = new ClinicSearch();
		clinicSearch.setPageNo("2");
		clinicSearch.setPageSize("10");
		System.out.println(jobService.getClinicSearchList("111", clinicSearch));
	}
	
	@Test
	public void getCvList() {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("delFlag", "0");
		param.put("memberId", "640");
		JsonResponse<List<TalentCvVo>> result = cvService.getCvList("test", param );
		System.out.println(result.getResult());
	}
	
	@Test
	public void getCvDetailById() {
		JsonResponse<TalentCvDetail> result = cvService.getCvDetailById("","347a5ed4-f237-4bfc-aaf0-cae435d87686");
		System.out.println(result.getResult());
	}
	
	@Test
	public void getHyJobRecordList() {
		cvService.getHyJobRecordList("123","0", "fd6f76b1-4d74-4a7d-b9a0-8d4e8ad39078");
	}
	
	@Test
	public void getCvEducationList() {
		cvEducationService.getCvEducationList("90396469-5ad7-49c8-8ce1-448f797235fe", null);
	}
}
