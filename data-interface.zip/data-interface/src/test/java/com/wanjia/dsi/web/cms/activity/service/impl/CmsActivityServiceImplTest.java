package com.wanjia.dsi.web.cms.activity.service.impl;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.model.CmsActivity;
import com.wanjia.dsi.web.cms.activity.service.CmsActivityService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class CmsActivityServiceImplTest {

	@Autowired
	CmsActivityService cmsActivityService ;
	@Test
	public void testfindByPageConfigId(){
		String pageConfigId = "1002-6-1";
		String imageType = "1440*2560";
		JsonResponse<List<CmsActivity>> result = cmsActivityService.findByPageConfigId(pageConfigId,imageType);
		List<CmsActivity> cmsActivityList = result.getResult();
		for(CmsActivity cms: cmsActivityList){
			System.out.println("ActivityId:" + cms.getActivityId() + ",ActivityTitle:" + cms.getActivityTitle()+ "," + cms.getActivityImageLocation());
		}
	}
	
}
