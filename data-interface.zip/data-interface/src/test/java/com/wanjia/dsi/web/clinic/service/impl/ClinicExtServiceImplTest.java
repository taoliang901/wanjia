package com.wanjia.dsi.web.clinic.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinic.model.ClinicExt;
import com.wanjia.dsi.web.clinic.service.ClinicExtService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ClinicExtServiceImplTest {

	@Autowired
	private ClinicExtService clinicExtService; 
	
	@Test
	public void testSearchClinicQRCodeByClinicId(){
		String clinicId = "abc12311";
		JsonResponse<ClinicExt> jr = clinicExtService.searchClinicQRCodeByClinicId(clinicId);
		System.out.println(jr.getStatus());
		System.out.println(jr.getResult().getTicket());
	}
}
