package com.wanjia.dsi.web.callCenter.service.impl;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.web.callCenter.model.Issue;
import com.wanjia.dsi.web.callCenter.model.IssueOBInfo;
import com.wanjia.dsi.web.callCenter.model.IssueOBProductServiceRecord;
import com.wanjia.dsi.web.callCenter.service.IssueOBProductServiceRecordService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class IssueOBProductServiceRecordServiceImplTest {

	@Autowired
	private IssueOBProductServiceRecordService issueOBProductServiceRecordService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	

	@Test
	public void testgetEntityByApptCode(){//已测
		/*
		List<IssueOBProductServiceRecord> list= issueOBProductServiceRecordService.getEntityByApptCode("JK0002190002");
		System.out.println("-------------------------------" +list.get(0).getId());*/
		
		List<Issue> issues = new ArrayList<Issue>();
		List<IssueOBInfo> issueOBinfos = new ArrayList<>();
		List<IssueOBProductServiceRecord> issueOBpsrs = new ArrayList<>();
		Issue issue = new Issue();
		String issueId = UUID.randomUUID().toString();
		issue.setId(issueId);
		issue.setCreateDate(new Date());
		issue.setCallType("1");
		issue.setIsConvey("0");
		issue.setStatus("0");
		issue.setDelFlag("0");
		
		String issueOBInfoId = UUID.randomUUID().toString();
		IssueOBInfo issueOBInfo = new IssueOBInfo();
		issueOBInfo.setId(issueOBInfoId);
		issueOBInfo.setIssueId(issueId);
		issueOBInfo.setCreateDate(new Date());
		issueOBInfo.setOvertimeType("2");
		
		IssueOBProductServiceRecord issueOBpsr = new IssueOBProductServiceRecord();
		issueOBpsr.setId(UUID.randomUUID().toString());
		issueOBpsr.setObId(issueOBInfoId);
		issueOBpsr.setCreateDate(new Date());
		
		issues.add(issue);
		issueOBinfos.add(issueOBInfo);
		issueOBpsrs.add(issueOBpsr);
		
		issueOBProductServiceRecordService.insertAllBatch(issues, issueOBinfos, issueOBpsrs);
		System.out.println("ok");
	}
	
	@Test
	public void testgetEntity(){//已测
		IssueOBProductServiceRecord io = (IssueOBProductServiceRecord) issueOBProductServiceRecordService.getEntityByApptCode("JL4488960002");
		System.out.println(io);
	}
	
	@Test
	public void testFindEntityByParams(){//已测
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("apptCode", "JM1364310002");
		params.put("overtimeType", "1");
		List<IssueOBProductServiceRecord> list = issueOBProductServiceRecordService.findEntityByParams(params);
		System.out.println(list.size());
	}
	
}
