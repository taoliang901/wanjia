package com.wanjia.dsi.web.diagnose;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.mongodb.Pagination;
import com.wanjia.dsi.web.selfdiagnose.model.DiagnoseRecordBO;
import com.wanjia.dsi.web.selfdiagnose.service.DiagnoseRecordService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class DiagnoseImplTest {

	@Autowired
	private DiagnoseRecordService diagnoseRecordService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInsert() {
		DiagnoseRecordBO recordBo = new DiagnoseRecordBO();
		recordBo.setId("4");
		recordBo.setMemberId("70");
		recordBo.setSex("0");
		recordBo.setAge(15);
		recordBo.setCity("武汉市");
		recordBo.setDiagnosePartCode("03");
		recordBo.setDiagnosePartName("头部");
		recordBo.setMainSymptomCode("03");
		recordBo.setMainSymptomName("头痛");
		recordBo.setDiagnoseNames("疾病名称3,疾病名称4");
		recordBo.setSpecialCase1Code("03");
		recordBo.setSpecialCase1Name("题目3名称");
		recordBo.setSpecialCase1AnswerCode("03");
		recordBo.setSpecialCase1AnswerName("题目3答案");
		recordBo.setSpecialCase2Code("04");
		recordBo.setSpecialCase2Name("题目4名称");
		recordBo.setSpecialCase2AnswerCode("04");
		recordBo.setSpecialCase2AnswerName("题目4答案");
		recordBo.setFollowSymptomCodes("01");
		recordBo.setFollowSymptomNames("伴随症状名称3,伴随症状名称4");
		recordBo.setDepartmentNames("科室名称3,科室名称4");
		recordBo.setCreateDate(new Date());
		recordBo.setDelFlag("0");
		diagnoseRecordService.insertDiagnoseRecord(recordBo );
	}
	
	@Test
	public void testSelect() {
		DiagnoseRecordBO recordBo = new DiagnoseRecordBO();
		recordBo.setMemberId("69");
		recordBo.setId("1");
		JsonResponse<Pagination<DiagnoseRecordBO>> result = diagnoseRecordService.findDiagnoseRecord(recordBo , 1, 10);
		System.out.println(result);
	}
}
