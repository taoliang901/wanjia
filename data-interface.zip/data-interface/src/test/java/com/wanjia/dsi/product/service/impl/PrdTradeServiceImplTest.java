package com.wanjia.dsi.product.service.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.service.PrdTradeService;
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PrdTradeServiceImplTest {
	
	@Autowired
	private PrdTradeService prdTradeService;

//	@Test
//	public void testAddPrdToUser() {
//		JsonResponse<String> jr = prdTradeService.addPrdToUser("203", "9a4c9e84-aedf-4028-b721-8b9e07ba1098", null, 1, "3");
//		System.out.println(jr.getResult());
//	}

	@Test
	public void testSelectRemaindedPrdKucun() {
//		01ee6461-5030-4dfb-877d-a1984987ca4f
		JsonResponse<Integer> jr = prdTradeService.selectRemaindedPrdKucun("00560835-46ec-414d-90df-259abc511926");
		System.out.println(jr.getResult());
	}

//	@Test
//	public void testDelUserPrd() {
//		List<String> prdKucunIds = new ArrayList<String>();
//		prdKucunIds.add("00560835-46ec-414d-90df-259abc511926");
//		JsonResponse<Void> jr = prdTradeService.delUserPrd(prdKucunIds , "203");
//		System.out.println(jr);
//	}

	@Test
	public void testAddPrdOrderToUser() {
		fail("Not yet implemented");
	}

	@Test
	public void testDelUserPrdOrder() {
		fail("Not yet implemented");
	}

}
