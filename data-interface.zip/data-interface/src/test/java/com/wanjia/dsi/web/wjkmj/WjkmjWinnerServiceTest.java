package com.wanjia.dsi.web.wjkmj;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.web.wjkmj.model.WjkmjDayCount;
import com.wanjia.dsi.web.wjkmj.model.WjkmjWinner;
import com.wanjia.dsi.web.wjkmj.service.WjkmjWinnerService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class WjkmjWinnerServiceTest {

	@Autowired
	private WjkmjWinnerService wjkmjWinnerService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFindByNameOrAddress() {
		WjkmjDayCount wjkmjDayCount = new WjkmjDayCount();
		wjkmjDayCount.setClinicId("17268143-14d1-47ff-99ec-dc1d20194c36");
		List<WjkmjWinner> jr = wjkmjWinnerService.findByNameOrAddress("222", "22", "10", 1, 1);
		
		System.out.println("============"  + jr.size());
	}
	
}
