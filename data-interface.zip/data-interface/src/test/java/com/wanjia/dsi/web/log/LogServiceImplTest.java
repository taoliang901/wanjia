package com.wanjia.dsi.web.log;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.log.model.GwRequestLog;
import com.wanjia.dsi.web.log.service.LogService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class LogServiceImplTest {

	@Autowired
	private LogService logService;
	
	@Test
	public void saveRequestLog() {
		GwRequestLog log = new GwRequestLog();
//		log.setMobile("18775638355");
		log.setUserCode("376");
		JsonResponse<Void> jr = logService.saveRequestLog(log);
		System.out.println("-----------------"+jr.getStatus().getValue());
	}
	
}
