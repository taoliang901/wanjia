package com.wanjia.dsi.web.department.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.department.model.Department;
import com.wanjia.dsi.web.department.service.DepartmentService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class DepartmentServiceImplTest {

	@Autowired
	private DepartmentService departmentService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetDepartmentListByTime() throws ParseException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date beginDate = df.parse("2016-05-24");
		Date endDate = df.parse("2016-12-22");

		JsonResponse<List<Department>> res = departmentService.getDepartmentListByTime(beginDate,endDate);
		System.out.println("===========================" + res.getStatus());
		System.out.println("===========================" + res.getErrorMsg());
		if(res.getResult() != null) {
			System.out.println("===========================" + res.getResult().size());
		}
	}
	
	
	
}
