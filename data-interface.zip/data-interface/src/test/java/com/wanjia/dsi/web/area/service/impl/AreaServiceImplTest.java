package com.wanjia.dsi.web.area.service.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.area.service.AreaService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class AreaServiceImplTest {
	@Autowired
	AreaService areaService;
	@Test
	public void testgetCityList(){
		Area area = new Area();
		String requestId = "";
		area.setParentId("3397");
		JsonResponse<List<Area>> jr = areaService.getCityList(requestId, area);
		List<Area> areaList = jr.getResult();
		for(Area ar:areaList){
			System.out.println("-------------" + ar.getAreaId() + "," + ar.getName());
		}
		
	}
	
	@Test
	public void testgetAreaListForGateway(){
		JsonResponse<Map<String, List<Area>>>  jr = areaService.getAreaListForGateway();
		Map<String, List<Area>> map = jr.getResult();
		Iterator<Map.Entry<String, List<Area>>> it = map.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry<String, List<Area>> entry = it.next();
			List<Area> value = entry.getValue();
			System.out.println("-------------------------");
			for(Area a:value){
				System.out.println(a.getId() + "," + a.getName() + "," + a.getAreaId() + "," + a.getCityId() + "," + a.getCityName());
			}
		}
	}

}
