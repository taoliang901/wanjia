package com.wanjia.dsi.web.activity.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.alibaba.dubbo.rpc.RpcException;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.invoker.Invoker;
import com.wanjia.dsi.base.mongodb.Pagination;
import com.wanjia.dsi.web.activity.model.Activity;
import com.wanjia.dsi.web.activity.service.ActivityService;
import com.wanjia.dsi.web.elasticsearch.info.service.ElasticsearchInforService;
import com.wanjia.dsi.web.selfdiagnose.model.DiagnoseRecordBO;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ActivityImplTest {

	@Autowired
	private ActivityService activityService;
	
	@Autowired
	private ElasticsearchInforService elasticsearchInforService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	
	@Test
	public void testSelect() {
		JsonResponse<Activity> healthJr = activityService.getActivityListById(Invoker.web.getValue(), "fc734038-4d9b-11e6-a7fa-005056899521");
		System.out.println("----");
	}
	
	@Test
	public void testInsertActivityClick() {
		activityService.insertActivityClick("71b742d9-fc62-11e5-8333-005056885cdb", "127.0.0.1");
		System.out.println("----");
	}
	
	@Test
	public void updateActivityClickStatic() {
		
		activityService.insertActivityClick("71b742d9-fc62-11e5-8333-005056885cdb", "127.0.0.1");
		
		activityService.insertAllActivityStatic();
		activityService.updateActivityClickCount(new Date());
		
		
		activityService.getActivityListById("", "71b742d9-fc62-11e5-8333-005056885cdb");
		
		Activity activity = new Activity();
		activity.setPageConfigId("");
		activity.setPageNo("1");
		activity.setPageSize("100000");
		elasticsearchInforService.findList(activity);
		
		System.out.println("----");
	}
}
