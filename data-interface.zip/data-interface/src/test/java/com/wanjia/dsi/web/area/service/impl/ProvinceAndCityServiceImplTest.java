package com.wanjia.dsi.web.area.service.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.area.model.ProvinceAndCity;
import com.wanjia.dsi.web.area.service.ProvinceAndCityService;
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ProvinceAndCityServiceImplTest {
	
	@Autowired
	private ProvinceAndCityService provinceAndCityService;
	

	@Test
	public void testGetProvinceAndCityAndDistrict() {
		JsonResponse<List<ProvinceAndCity>> jr = provinceAndCityService.getProvinceAndCityAndDistrict();
		if(jr.getResult()!=null){
			System.out.println(jr.getResult().size());
		}
	}

}
