package com.wanjia.dsi.web.wx;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.util.SaltfigureGenerator;
import com.wanjia.dsi.web.wx.service.EncryptOpenidService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class EncryptOpenidServiceTest {

	@Autowired
	private EncryptOpenidService encryptOpenidService;
	
	@Test
	public void testEncrypt(){
		System.out.println("=================start===================");
		String openid = "sdfji329348fs9jfd2hr8723sire";
		System.out.println(openid);
		JsonResponse<String> jr = encryptOpenidService.encrypt(openid);
		if(JsonResponse.Status.SUCCESS.equals(jr.getStatus())){
			System.out.println(jr.getResult());
			JsonResponse<String> djr = encryptOpenidService.decrypt(jr.getResult(), SaltfigureGenerator.getAESSaltfigureForOpenid());
			if(JsonResponse.Status.SUCCESS.equals(djr.getStatus())){
				System.out.println(djr.getResult());
				
				if(openid.equals(djr.getResult())){
					System.out.println("解密后内同相同");
				}
			}else{
				System.out.println(djr.getErrorMsg());
			}
		}else{
			System.out.println(jr.getErrorMsg());
		}
		System.out.println("=================end===================");
	}
}
