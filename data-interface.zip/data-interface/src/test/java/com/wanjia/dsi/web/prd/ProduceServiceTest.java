package com.wanjia.dsi.web.prd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.model.PrdInventory;
import com.wanjia.dsi.product.model.PrdType;
import com.wanjia.dsi.product.model.ProductInfo;
import com.wanjia.dsi.product.service.ProductService;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.area.service.AreaService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ProduceServiceTest {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ProductService productService;

	@Autowired
	private AreaService areaService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	// @Test
	public void test() throws Exception {

		// JsonResponse<PageInfo<ProductInfo>> contractList =
		// productService.getContractList(new ProductInfo());
		//
		// logger.info(contractList.toString());
	}

	// @Test
	public void test1() {
		List<String> prdIds = new ArrayList<String>();
		prdIds.add("32dd539c-f400-421b-9656-d7f9d0644de0");
		prdIds.add("liugc-prdid01");
		JsonResponse<List<PrdInventory>> resp = productService.listPrdInventoryByPrdIds(prdIds);
		System.out.println(resp);
	}

	@Test
	public void getProduceList() throws Exception {
		ProductInfo productInfo = new ProductInfo();
		productInfo.setSort("PRD_PRICE");
		productInfo.setOrder("ASC");
		JsonResponse<PageInfo<ProductInfo>> produceList = productService.getProduceList(productInfo);
		PageInfo<ProductInfo> pageInfo = produceList.getResult();
		for (int i = 0; i < pageInfo.getList().size(); i++) {
			System.out.println(pageInfo.getList().get(i).getPrdPrice());
			;
		}
		logger.info(produceList.toString());

	}

	// @Test
	public void getProduceInfo() throws Exception {
		ProductInfo productInfo = new ProductInfo();
		productInfo.setId("coupon_test_1");
		JsonResponse<ProductInfo> produceList = productService.getProduceInfo(productInfo);
		logger.info(produceList.toString());

	}

	@Test
	public void gainAreaList() throws Exception {

		List<String> areaIds = new ArrayList<String>();
		areaIds.add("779");
		areaIds.add("780");

		JsonResponse<List<Area>> gainAreaList = areaService.gainAreaList(areaIds);

		logger.info(gainAreaList.toString());

	}

	@Test
	public void getOnlineProduceTypeListTest() throws Exception {

		// 获取所有产品（已启用，status=0）类型，并获当前产品分类的前3个
		Map<String, Object> map = new HashMap<String, Object>();
		JsonResponse<List<PrdType>> typeList = productService.getOnlineProduceTypeList(map);

		logger.info(typeList.toString());
	}
}
