package com.wanjia.dsi.web.activity.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.service.LocalMedicineService;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class LocalMedicineServiceImplTest {

	@Autowired
	private LocalMedicineService localMedicineService;
	
	@Test
	public void testgetAllMedicineId() {
		Date beginDate = new Date();
		Date endDate = new Date();
		JsonResponse<List<String>> jr = localMedicineService.getAllMedicineId(beginDate, endDate);
		System.out.println("---------------------------------------");
		System.out.println(jr.getResult().size());
		System.out.println("---------------------------------------");
	}
	
}
