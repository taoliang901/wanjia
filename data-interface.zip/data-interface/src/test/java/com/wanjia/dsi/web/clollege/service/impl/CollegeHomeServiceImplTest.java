package com.wanjia.dsi.web.clollege.service.impl;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.college.model.CeCourseReleased;
import com.wanjia.dsi.web.college.service.CollegeHomeService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class CollegeHomeServiceImplTest {

	@Autowired
	private CollegeHomeService collegeHomeService;
	@Test
	public void testFindCecourseByTypeIds() {
		Integer[] typeIds = new Integer[] { 1, 2, 3 };
		JsonResponse<Map<Integer, List<CeCourseReleased>>> jr = collegeHomeService.findCecourseByTypeIds(typeIds, new Integer(3));
		for (int i = 1; i < 4; i++) {

			List<CeCourseReleased> list = jr.getResult().get(i);
			for (CeCourseReleased ceCourseReleased : list) {
				System.out.println(ceCourseReleased.getCourseTitle());
			}
			System.out.println("========================================================");
		}
	}
	@Test
	public void testFindCeCourseByLabel() {
		 JsonResponse<List<CeCourseReleased>> resp = collegeHomeService.findCeCourseByLabel("1", 10);
		 System.out.println(resp.getResult());
	}
}
