package com.wanjia.dsi.web.rz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.rz.model.Radar;
import com.wanjia.dsi.web.rz.model.RzItemsInfo;
import com.wanjia.dsi.web.rz.service.RzItemsService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class RzItemsServiceImplTest {

	@Autowired
	private RzItemsService rzItemsService;
	
	@Test
	public void testQueryClinicItems() {
		Map<String,Object> map = new HashMap<String,Object>();
		JsonResponse<List<RzItemsInfo>> response = rzItemsService.queryClinicItems(map);
		System.out.println(response.getStatus());
		
	}

	
	@Test
	public void testQueryRzScoreStatistic(){
		String resultId = "b2ef46a1-8367-43e1-a9fd-dd0ab75accce"; 
		
		JsonResponse<Map<String, Object>> jason = rzItemsService.queryRzScoreStatistic(resultId); 
		Map<String, Object> map = jason.getResult();
		System.out.println(map.get("passNum"));
		System.out.println(map.get("failNum"));
		System.out.println(map.get("unUsedNum"));
	}
	
	@Test
	public void queryRadar() {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("resultId", "d3677f0c-12f8-4a0c-965a-6feb720f2496");
		map.put("clinicId", "af7f73ca-3af5-4d78-9c35-2653c160d493");
		JsonResponse<List<Radar>> response = rzItemsService.queryRadar(map);
		System.out.println(response.getStatus());
		
	}
	
	@Test
	public void queryRzItemsForClinic() {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("resultId", "d3677f0c-12f8-4a0c-965a-6feb720f2496");
		map.put("clinicId", "af7f73ca-3af5-4d78-9c35-2653c160d493");
		JsonResponse<List<RzItemsInfo>> response = rzItemsService.queryClinicItems(map);
		System.out.println(response.getStatus());
		
	}
	
	@Test
	public void getAuditReport() {
		Map<String,Object> map = new HashMap<String,Object>();
//		map.put("resultId", "e144094a-7ff4-445b-86c6-0cffb736bde2");
//		map.put("clinicId", "a64092db-6181-4569-810f-195f4bb879a2");
		map.put("resultId", "d26ff872-ef4c-4bd9-af24-0897229c237f");
		map.put("clinicId", "1d651729-d672-42c1-b5c7-ec13fc98cc52");
		JsonResponse<Map<String, Object>> response = rzItemsService.getAuditReport(map);
		response.getResult().get("items");
		System.out.println(response.getStatus());
		System.out.println(response.getErrorMsg());
	}
}
