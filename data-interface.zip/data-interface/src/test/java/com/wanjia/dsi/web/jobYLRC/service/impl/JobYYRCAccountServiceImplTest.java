package com.wanjia.dsi.web.jobYLRC.service.impl;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.web.jobYYRC.model.MemInfo;
import com.wanjia.dsi.web.jobYYRC.model.YyrcAccount;
import com.wanjia.dsi.web.jobYYRC.service.JobYYRCAccountService;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class JobYYRCAccountServiceImplTest {

	@Autowired
	private JobYYRCAccountService accountService;
	

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testAddAccount() throws Exception {
		YyrcAccount yyrcAccount = new YyrcAccount();
		yyrcAccount.setClinicId("c420f4dc-7682-412e-a78c-4601b361cf44");
		yyrcAccount.setName("回归测试6272");
		accountService.addAccount(yyrcAccount);
	}
	
	@Test
	public void testRegistMem() throws Exception {
		MemInfo memInfo = new MemInfo();
		memInfo.setPinganMemId(10001);
		memInfo.setMemName("平安万家医疗投资管理有限责任公司test4");
		memInfo.setLicenceNum("test4");
		memInfo.setCalling(3800);
		memInfo.setProperity(-1);
		memInfo.setFoundDate("2006-07-04");
		memInfo.setRegisterFund(100000);
		memInfo.setCurrency(0);
		memInfo.setEmployeeNumber(0);
		memInfo.setMemIntroduction("平安万家医疗投资管理有限责任公司");
		memInfo.setContactPerson("陈龙孙");
		memInfo.setTELShowFlag(1);
		memInfo.settELShowFlag(1);
		memInfo.setFaxShowFlag(1);
		memInfo.setEmail("chenlongsuntest4717@pingan.com.cn");
		memInfo.setEmailShowFlag(1);
		memInfo.setAddress_P("上海");
		memInfo.setMailCode(0);
		memInfo.setNewsLetter(0);
		memInfo.setAccName("wanjiazhensuotest4");
		memInfo.setAccPwd("wanjiazhensuotest4");
		accountService.registMem(memInfo);
	}
	
	
}
