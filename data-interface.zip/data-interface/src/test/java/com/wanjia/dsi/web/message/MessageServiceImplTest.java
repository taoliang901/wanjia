package com.wanjia.dsi.web.message;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.mongodb.Pagination;
import com.wanjia.dsi.web.message.model.MessageBO;
import com.wanjia.dsi.web.message.model.VOMessage;
import com.wanjia.dsi.web.message.repository.MessageRepository;
import com.wanjia.dsi.web.message.service.MessageService;
import com.wanjia.dsi.web.message.servuce.impl.MessageServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class MessageServiceImplTest {

	@Autowired
	private MessageService messageService;
	@Autowired
	private MessageServiceImpl messageServiceImpl;
	@Autowired
	private MessageRepository messageRepository;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	// @Test
	public void patientBookingTest() {
		String bookingId = "01010101001111";
		String uid = "9999999999900000000009999999";
		String patientName = "hul";
		String bookingTime = "2016-08-09 12:00";
		String clinicId = "12121212";
		String clinicName = "测试诊所";
		String serviceName = "test";
		String memberId = "3212123";
		messageService.clinicConfirmBooking(bookingId, uid + "a", patientName, bookingTime, clinicId, clinicName,
				serviceName, memberId);
		messageService.patientBooking(bookingId + "09", uid + "b", patientName, bookingTime, clinicId, serviceName);
		messageService.patientCancelBooking(bookingId + "08", uid + "c", patientName, bookingTime, clinicId,
				serviceName);
		messageService.patientConfirmConsultation(bookingId + "07" + "d", uid, patientName, bookingTime, clinicId,
				serviceName);
		messageService.patientRated(bookingId + "06", uid + "e", patientName, bookingTime, clinicId, serviceName);
		messageService.clinicCancelBooking(bookingId + "05", uid + "f", clinicName, bookingTime, serviceName, "测试理由",
				memberId);
		messageService.clinicConfirmConsultation(bookingId + "04", uid + "h", clinicName, bookingTime, serviceName,
				memberId);
		messageService.clinicReplyRated(bookingId + "03", uid + "i", clinicName, bookingTime, serviceName, memberId);
		messageService.patientRated(bookingId, uid + "j", patientName, bookingTime, clinicId, serviceName);
	}

	@Test
	public void clinicConfirmBookingTest() {
		String bookingId = "01010101001111";
		String uid = "normal-hul-test";
		String patientName = "qx";
		String bookingTime = "2016-11-04 12:00";
		String clinicId = "12121212";
		String clinicName = "测试诊所";
		String serviceName = "test";
		String memberId = "3212123";
		String clinicAddress = "测试诊所地址";
		String consultationCode = "0909";
		messageService.clinicConfirmBooking(bookingId, uid + "-1-", patientName, bookingTime, clinicId, clinicName,
				serviceName, memberId, clinicAddress, consultationCode);
		messageService.clinicConfirmBookingNormal(bookingId, uid + "-n1-", patientName, bookingTime, clinicId,
				clinicName, serviceName, memberId, clinicAddress, consultationCode);
		messageService.patientBooking(bookingId + "09", uid + "-2-", patientName, bookingTime, clinicId, serviceName);
		messageService.patientBookingNormal(bookingId + "09", uid + "-n2-", patientName, bookingTime, clinicId,
				serviceName);
		messageService.patientCancelBooking(bookingId + "08", uid + "-3-", patientName, bookingTime, clinicId,
				serviceName);
		messageService.patientCancelBookingNormal(bookingId + "08", uid + "-n3-", patientName, bookingTime, clinicId,
				serviceName);
		messageService.patientConfirmConsultation(bookingId + "07", uid + "-4-", patientName, bookingTime, clinicId,
				serviceName);
		messageService.patientConfirmConsultationNormal(bookingId + "07", uid + "-n4-", patientName, bookingTime,
				clinicId, serviceName);
		messageService.patientRated(bookingId + "06", uid + "-5-", patientName, bookingTime, clinicId, serviceName);
		messageService.patientRatedNormal(bookingId + "06", uid + "-n5-", patientName, bookingTime, clinicId,
				serviceName);
		messageService.clinicCancelBooking(bookingId + "05", uid + "-6-", clinicName, bookingTime, serviceName, "测试理由",
				memberId);
		messageService.clinicCancelBookingNormal(bookingId + "05", uid + "-n6-", clinicName, bookingTime, serviceName,
				"测试理由", memberId);
		messageService.clinicConfirmConsultation(bookingId + "04", uid + "-7-", clinicName, bookingTime, serviceName,
				memberId);
		messageService.clinicConfirmConsultationNormal(bookingId + "04", uid + "-n7-", clinicName, bookingTime,
				serviceName, memberId);
		messageService.clinicConfirmBooking(bookingId + "03", uid + "-8-", patientName, bookingTime, clinicId,
				clinicName, serviceName, memberId, clinicAddress, consultationCode);
		messageService.clinicConfirmBookingNormal(bookingId + "03", uid + "-n8-", patientName, bookingTime, clinicId,
				clinicName, serviceName, memberId, clinicAddress, consultationCode);
		messageService.clinicReplyRated(bookingId, uid + "-9-", clinicName, bookingTime, serviceName, memberId);
		messageService.clinicReplyRatedNormal(bookingId, uid + "-n9-", clinicName, bookingTime, serviceName, memberId);
		messageService.clinicConfirmBookingForupdate(bookingId + "03", uid + "-10-", patientName, bookingTime, clinicId,
				clinicName, serviceName, memberId, clinicAddress, consultationCode);
		messageService.clinicConfirmBookingForupdateNormal(bookingId + "03", uid + "-n10-", patientName, bookingTime,
				clinicId, clinicName, serviceName, memberId, clinicAddress, consultationCode);
	}

	// @Test
	public void clinicUpgradeAccountTest() {
		String receiverId = "ef73827e-e852-4570-b12d-5316115dd79f";
		String uid = "201609051432001";
		messageService.clinicUpgradeAccount(receiverId, uid);
	}

	// @Test
	public void clinicAssociatedAccountTest() {
		String receiverId = "ef73827e-e852-4570-b12d-5316115dd79f";
		String uid = "201609051433002";
		String clinicName = "陶亮测试--第二轮";
		messageService.clinicAssociatedAccount(receiverId, uid, clinicName);
	}

	// @Test
	public void testfindMessage() {
		MessageBO bo = new MessageBO();
		String receiverId = "89";
		bo.setReceiverId(receiverId);
		JsonResponse<Pagination<MessageBO>> jr = messageService.findMessage(bo, 1, 10);
		Pagination<MessageBO> pm = jr.getResult();
		List<MessageBO> reuslt = pm.getDatas();
		for (MessageBO b : reuslt) {
			System.out.println(b.getAcceptRoleId() + "," + b.getContent() + "," + b.getId());
		}

	}
	/*
	 * @Test public void testfindRecentMessageAndUnreadTotal(){ MessageBO bo =
	 * new MessageBO(); String receiverId =
	 * "7d5e31a6-9af4-4ea7-af2a-d1bd4e85464b"; String acceptRoleId = "1";
	 * bo.setReceiverId(receiverId); bo.setAcceptRoleId(acceptRoleId);
	 * bo.setStatus("1"); JsonResponse<List<VOMessage>> jr =
	 * messageService.findRecentMessageAndUnreadTotal(bo); List<VOMessage> list
	 * = jr.getResult(); for(VOMessage messageBo : list){ System.out.println(
	 * "-----------------------------------------------------------");
	 * System.out.println(messageBo.getId() + "," + messageBo.getContent() + ","
	 * + messageBo.getPublishDate() + ",------" + messageBo.getMessageTypeId() +
	 * "," + messageBo.getReceiverId() + "," + messageBo.getUnReadTotal());
	 * System.out.println(
	 * "-----------------------------------------------------------"); }
	 * 
	 * }
	 */

	// @Test
	public void testsetBatchMessageByOneField() {
		String messageTypeId = null;
		String receiverId = "fcb6d753-449c-45ca-9de2-52a50a055f9";
		String acceptRoleId = null;
		// c2ba8856-192e-4327-a090-2bb5249c019e
		// c9bc557c-3aec-486d-9d69-12eac4b45a22
		List<String> idList = new ArrayList<String>();
		/*
		 * idList.add("c2ba8856-192e-4327-a090-2bb5249c019e");
		 * idList.add("c9bc557c-3aec-486d-9d69-12eac4b45a22");
		 */
		// isRead delFlag
		String updateKey = "delFlag";
		String updateValue = "0";
		messageService.setBatchMessageByOneField(messageTypeId, receiverId, acceptRoleId, idList, updateKey,
				updateValue);
	}

	// @Test
	public void testgetMessageCount() {
		String receiverId = "693";
		String acceptRoleId = "2";
		String messageTypeId = "1";
		MessageBO messageBO = new MessageBO();
		messageBO.setReceiverId(receiverId);
		messageBO.setAcceptRoleId(acceptRoleId);
		messageBO.setMessageTypeId(messageTypeId);
		JsonResponse<Long> result = messageService.getMessageCount(messageBO);
		System.out.println(result.getResult());
	}

	/*
	 * @Test public void testgetCountByTypeTest(){ MessageBO bo = new
	 * MessageBO(); String receiverId = "7d5e31a6-9af4-4ea7-af2a-d1bd4e85464b";
	 * String acceptRoleId = "1"; bo.setReceiverId(receiverId);
	 * bo.setAcceptRoleId(acceptRoleId); bo.setStatus("1"); String messageTypes
	 * =""; List<VOMessage> list =
	 * messageService.getCountByTypeTest(bo,messageTypes); for(VOMessage
	 * messageBo : list){ System.out.println(
	 * "-----------------------------------------------------------");
	 * System.out.println(messageBo.getId() + "," + messageBo.getContent() + ","
	 * + messageBo.getPublishDate() + ",------" + messageBo.getMessageTypeId() +
	 * "," + messageBo.getReceiverId() + "," + messageBo.getUnReadTotal());
	 * System.out.println(
	 * "-----------------------------------------------------------"); }
	 * 
	 * }
	 */
	// @Test
	public void testfindMessageNoPage() {
		MessageBO messageBo = new MessageBO();
		messageBo.setReceiverId("47");
		JsonResponse<List<MessageBO>> jr = messageService.findMessageNoPage(messageBo, 2, 5);
		List<MessageBO> result = jr.getResult();
		System.out.println("-----------------------------------");
		for (MessageBO m : result) {
			System.out.println(m.getId() + "," + m.getPublishDate());
		}
		System.out.println("-----------------------------------");

	}

	// @Test
	public void testfindRecentMessageAndUnreadTotal() {
		MessageBO bo = new MessageBO();
		String receiverId = "6f100718-4ab2-47e2-9260-9fe31c4e7d08";
		String acceptRoleId = "3";
		String channel = "2";
		bo.setReceiverId(receiverId);
		bo.setAcceptRoleId(acceptRoleId);
		bo.setChannel(channel);
		bo.setStatus("1");
		JsonResponse<List<VOMessage>> jr = messageService.findRecentMessageAndUnreadTotal(bo);
		List<VOMessage> list = jr.getResult();
		for (VOMessage messageBo : list) {
			System.out.println("-----------------------------------------------------------");
			System.out.println(messageBo.getId() + "," + messageBo.getContent() + "," + messageBo.getPublishDate()
					+ ",------" + messageBo.getMessageTypeId() + "," + messageBo.getReceiverId() + ","
					+ messageBo.getUnReadTotal());
			System.out.println("-----------------------------------------------------------");
		}

	}

	// @Test
	public void testgetMessageTypes() {
		MessageBO bo = new MessageBO();
		String receiverId = "7d5e31a6-9af4-4ea7-af2a-d1bd4e85464b";
		String acceptRoleId = "1";
		bo.setReceiverId(receiverId);
		bo.setAcceptRoleId(acceptRoleId);
		// bo.setStatus("1");
		List<String> result = messageRepository.getMessageTypes(bo);
		for (int i = 0; i < result.size(); i++) {
			System.out.println("-----------------------------------------------------------");
			System.out.println(result.get(i));
			System.out.println("-----------------------------------------------------------");
		}

	}
}
