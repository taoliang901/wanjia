package com.wanjia.dsi.web.clollege.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.college.model.CeCourseReleased;
import com.wanjia.dsi.web.college.service.CeCourseReleasedService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class CeCourseReleasedServiceImplTest {

	@Autowired
	private CeCourseReleasedService ceCourseReleasedService;
	@Test
	public void testFindCeCourseReleasedBykey() {
		//fail("Not yet implemented");
	}

	@Test
	public void testFindAllCeCourseReleased() {
		//fail("Not yet implemented");
	}

	@Test
	public void testFindCeCourseReleasedByCourseId() {
		JsonResponse<CeCourseReleased> jr = ceCourseReleasedService
				.findCeCourseReleasedByCourseId("c69c5947-de5b-4c6f-bb49-c630a59f2730");
		System.out.println(jr.toString());
	}

}
