package com.wanjia.dsi.product.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.dao.mapper.VOPrdClinicMapper;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.service.ProductMessageService;
import com.wanjia.dsi.product.vo.VOPrdAllClinics;
import com.wanjia.dsi.product.vo.VOPrdClinic;
import com.wanjia.dsi.web.clinic.model.VOClinicProduct;
import com.wanjia.dsi.web.clinic.model.VoClinic;
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ProductMessageServiceImplTest {
	
	@Autowired
	private ProductMessageService productMessageService;
	@Resource
	private VOPrdClinicMapper vOPrdClinicMapper;
	
	
	@Test
	public void testFindKucunbyMsg() {
	}

	@Test
	public void testFindClinicsByProduct() {
		JsonResponse<VOPrdAllClinics> jr = productMessageService.findClinicsByProduct("1fe39ae8-1d8e-4ef6-aa1f-e2fcdff96b22","821","2b52b794-684e-4c8f-a16b-3435c9871b5d",null,"d601bfc0-48ea-4d7f-8099-bc5e8106ca6b");
		System.out.println(jr.getResult());
	}

	@Test
	public void testFindPrdServiceList() {
	}

	@Test
	public void testFindHyUsers() {
	}

	@Test
	public void testFindBookingMessage() {
	}
	
	@Test
	public void getProductState() {
		JsonResponse<Map<String,String>> jr = productMessageService.getProductState("", "d1b97c82-d772-460a-a8ae-1ca4b7d8291c");
		System.out.println(jr.getResult());
	}
	@Test
	public void testreceiveProduct(){
		JsonResponse<String> jr = productMessageService.receiveProduct("0a234fea-d5c0-4a6f-ba9b-71653df18418", "203");
		System.out.println(jr);
	}
	@Test
	public void testgetVoClinicByProId(){
		VOClinicProduct voClinicProduct = new VOClinicProduct();
		voClinicProduct.setPrdId("2d7aa844-9a68-45b9-8b69-0492cc50692a");
		voClinicProduct.setUserId("3828");
		JsonResponse<PageInfo<VoClinic>> jr = productMessageService.getPrdClinicByProId(voClinicProduct,"51161f3d-c334-43a8-9b57-369bbcdf385e");
//		System.out.println(jr);
		
		List<VoClinic> list = jr.getResult().getList();
		for (VoClinic voClinic : list) {
			System.out.println(voClinic.getClinicName());
		}
	}
	@Test
	public void testgetCLinicAdressById(){
		String couponId = "07f78bfa-ed6c-4d31-a329-60477e04e5e5";
		List<VOPrdClinic> result = null;
		List<String> clinicIdList = productMessageService.getClinicId(couponId);
		//clinicIdList.add("1");
		if(clinicIdList != null && clinicIdList.size()>0){
			result = vOPrdClinicMapper.getCLinicAdressById(clinicIdList);
		}
		System.out.println("---------------------------------");
		for(VOPrdClinic v:result){
			System.out.println(v.getClinicId() + "," + v.getClinicName());
		}
		System.out.println("---------------------------------");
	}
	@Test
	public void testfindProductsByClinicId(){
		String clinicId = "e13d7e67-0fd0-4a25-9e86-c060655e616b";
		JsonResponse<PageInfo<PrdInfo>> jr = productMessageService.findProductsByClinicId(clinicId,1,100);
		PageInfo<PrdInfo> page = jr.getResult();
		List<PrdInfo> list = page.getList();
		for(PrdInfo p :list){
			System.out.println(p.getId() + "," + p.getCouponName());
		}
	}
}
