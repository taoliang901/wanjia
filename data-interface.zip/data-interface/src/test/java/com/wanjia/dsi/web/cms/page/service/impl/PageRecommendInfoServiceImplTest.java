package com.wanjia.dsi.web.cms.page.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.cms.page.dao.mapper.PageRecommendImgMapper;
import com.wanjia.dsi.cms.page.model.PageRecommendInfoCriteria;
import com.wanjia.dsi.cms.page.model.PageRecommendInfoVo;
import com.wanjia.dsi.cms.page.service.PageRecommendInfoService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PageRecommendInfoServiceImplTest {
	
	@Autowired
	PageRecommendInfoService pageRecommendInfoService ;
	
	@Autowired
	PageRecommendImgMapper pageRecommendImgMapper;
	/*
	@Test
	public void testFindPageRecommendInfo(){
		PageRecommendInfoCriteria criteria = new PageRecommendInfoCriteria();
		criteria.setPageKey("3543");
		criteria.setSiteKey("34543");
		JsonResponse<List<PageRecommendInfoVo>> result = pageRecommendInfoService.getPageRecommnedInfoVoList(criteria);
		List<PageRecommendInfoVo> recommendInfoList = result.getResult();
		if(CollectionUtils.isNotEmpty(recommendInfoList)){
			for(PageRecommendInfoVo rif: recommendInfoList){
				System.out.println("Id:" + rif.getId() + ",PageName:" + rif.getPageName());
			}
		}else{
			System.out.println("没有查到任何数据");
		}
		
	}
	
	@Test
	public void testFindPageInfo(){
		PageInfo pageInfo = new PageInfo();
		pageInfo.setTerminalType("M-APP");
		pageInfo.setDelFlag("0");
		JsonResponse<List<PageInfo>> pageInfoJR = pageRecommendInfoService.getPageInfoListByParam(pageInfo);
		if(pageInfoJR == null || CollectionUtils.isEmpty(pageInfoJR.getResult())){
			System.out.println("没有查到任何数据");
		}else{
			System.out.println("条数："+pageInfoJR.getResult().size());
		}
	}*/
	
	@Test
	public void testFindPageList(){
		PageRecommendInfoCriteria criteria = new PageRecommendInfoCriteria();
		criteria.setPageKey("MOBILE_B_APP_START");
		criteria.setNowDateTime(new Date());
		JsonResponse<List<PageRecommendInfoVo>> pageInfoJR = pageRecommendInfoService.getPageRecommendInfoVoList(criteria);
		if(pageInfoJR == null || CollectionUtils.isEmpty(pageInfoJR.getResult())){
			System.out.println("没有查到任何数据");
		}else{
			System.out.println("条数："+pageInfoJR.getResult().size());
		}
	}
	
	@Test
	public void testFindPageAllInfo(){
		Map<String,Object> criteria = new HashMap<String,Object>();
		criteria.put("pageKey", "MOBILE_B_APP_START");
		criteria.put("nowDateTime", new Date());
		JsonResponse<List<PageRecommendInfoVo>> pageInfoJR = pageRecommendInfoService.getPageRecommendInfoAllList(criteria);
		if(pageInfoJR == null || CollectionUtils.isEmpty(pageInfoJR.getResult())){
			System.out.println("没有查到任何数据");
		}else{
			System.out.println("条数："+pageInfoJR.getResult().size());
		}
	}
	

}
