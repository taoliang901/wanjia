package com.wanjia.dsi.web.clollege.service.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.college.model.CeCourseType;
import com.wanjia.dsi.web.college.service.CeCourseTypeService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class CeCourseTypeServiceImplTest {
	@Autowired
	private CeCourseTypeService ceCourseTypeService;
	@Test
	public void testFindAllCeCourseType() {
		JsonResponse<List<CeCourseType>> jr = ceCourseTypeService.findAllCeCourseType(3);
		for (CeCourseType c : jr.getResult()) {
			System.out.println(c.getTypeName());
		}
	}

}
