package com.wanjia.dsi.product;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.service.CouponService;
import com.wanjia.dsi.product.vo.VOPrdBooking;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = {"classpath*:spring/*.xml"})
public class CouponServiceImplTest {

	@Autowired
	private CouponService couponService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetOrderById() throws Exception {
		JsonResponse<VOPrdBooking> res = couponService.getBookingById("A0001");
		System.out.println("===========================" + res.getStatus());
		System.out.println("===========================" + res.getErrorMsg());
		if(res.getResult() != null) {
			System.out.println("===========================" + res.getResult().getOrderId());
			System.out.println("===========================" + res.getResult().getCardNo());
		}
	}

	@Test
	public void testCheckCardNoPwd() {
		//根据【卡号、密码】
//		JsonResponse<VOPrdKucun> res = couponService.checkCardNoPwd("111", "222", null, "1");
		//根据【卡ID】 
//		JsonResponse<VOPrdKucun> res = couponService.checkCardNoPwd(null, null, "kucun_id_001", "4", "89");
//		System.out.println("===========================" + res.getStatus());
//		System.out.println("===========================" + res.getErrorMsg());
//		if(res.getResult() != null) {
//			System.out.println("===========================" + res.getResult().getCouponId());
//			System.out.println("===========================" + res.getResult().getCouponName());
//		}
	}

	@Test
	public void testFillData() {
		//根据【卡号、密码】
//		JsonResponse<VOPrdKucun> res1 = couponService.checkCardNoPwd("111", "222", null, "1", "89");
//		JsonResponse<VOPrdKucun> res = couponService.fillData(res1.getResult(), "1", null);
		//根据【卡ID】 
//		JsonResponse<VOPrdKucun> res1 = couponService.checkCardNoPwd(null, null, "kucun_id_001", "4");
////		JsonResponse<VOPrdKucun> res = couponService.fillData(res1.getResult(), "3", "63c16b27-e611-4d7f-8048-f184337ca541");
//		JsonResponse<VOPrdKucun> res = couponService.fillData(res1.getResult(), "4", null);
		
//		System.out.println("===========================" + res.getStatus());
//		System.out.println("===========================" + res.getErrorMsg());
//		if(res.getResult() != null) {
//			System.out.println("===========================" + res.getResult().getCouponId());
//			System.out.println("===========================" + res.getResult().getClinicList().size());
//			System.out.println("===========================" + res.getResult().getCityList().size());
//			System.out.println("===========================" + res.getResult().getParentAccountList().size());
//		}
	}
	
	@Test
	public void testFindOrder() {
		JsonResponse<PageInfo<VOPrdBooking>> result = couponService.findBookingList("111","1","10");
		System.out.print(result);	
	}
	
	@Test
	public void testFindOrderByTime() {
		JsonResponse<String> result = couponService.findExpiryDate("20");
		System.out.print(result);	
	}
	
	@Test
	public void testSendMail() {
		couponService.hyCouponSendMail();
	}
	
	@Test
	public void testSaveOrder() {
//		String userId = "69";
//		VOPrdBooking order = new VOPrdBooking();
//		order.setOrderId("7948c724-32b0-49cb-bb55-8c3874e6ad26");
//		order.setClinicId("24050428-d983-4ccc-b954-1df93fe2f651");
//		order.setPrdKucunId("detail_03");
//		order.setTreatDate("2016-06-18");
//		order.setTreatTime("10:00～11:00");
//		List<HyTreatmentPerson> visitList = new ArrayList<HyTreatmentPerson>();
//		HyTreatmentPerson e1 = new HyTreatmentPerson();
//		e1.setVisitId(31l);
//		e1.setVisitIdCardTypeCode("1");
//		e1.setVisitIdCardCode("42098219911001");
//		e1.setVisitName("云龙");
//		e1.setVisitMobile("13487098657");
//		
//		HyTreatmentPerson e2 = new HyTreatmentPerson();
//		e2.setVisitId(32l);
//		e2.setVisitIdCardTypeCode("1");
//		e2.setVisitIdCardCode("42098219911001");
//		e2.setVisitName("云龙2");
//		e2.setVisitMobile("13487098657");
//		visitList.add(e1);
//		visitList.add(e2);
//		order.setVisitList(visitList );
//		
//		couponService.saveBooking(order,userId,"test");
	}
}
