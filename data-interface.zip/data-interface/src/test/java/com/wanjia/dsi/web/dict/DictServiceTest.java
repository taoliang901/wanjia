package com.wanjia.dsi.web.dict;

import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.invoker.Invoker;
import com.wanjia.dsi.web.dictionary.model.ElementResult;
import com.wanjia.dsi.web.dictionary.service.DictionaryService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class DictServiceTest {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private DictionaryService dictionaryService;
	
	

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetOrderById() throws Exception {
		JsonResponse<List<ElementResult>> dictInfo = dictionaryService.getDictInfo();
		logger.info(dictInfo.toString());
		
	}
	
	@Test
	public void testGetDictionaryList() throws Exception {
		JsonResponse<Map<String, Object>> result = dictionaryService.getDictionaryList(Invoker.clinic.getValue(),"CLINIC_DICT_1,CLINIC_JOB_1,CLINIC_JOB_2,CLINIC_JOB_3,CLINIC_JOB_4,CLINIC_JOB_6,DOCTOR_DICT_2,CLINIC_JOB_7");
		logger.info(result.toString());
		
	}
	
}
