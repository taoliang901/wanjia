package com.wanjia.dsi.product.service.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.model.PickerMUI;
import com.wanjia.dsi.product.model.VOPrdKucunMUI;
import com.wanjia.dsi.product.service.ProductOrderService;
import com.wanjia.dsi.product.vo.VOPrdClinic;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ProductOrderServiceImplTest {
	@Autowired
	private ProductOrderService productOrderService;
	
	
	@Test
	public void testSubmitOrder() {
	}

	@Test
	public void testFindBookingMessage() {
	}

	@Test
	public void testLoadBookingMessage() {
//		JsonResponse<VOPrdKucunMUI> jr = productOrderService.loadBookingMessage("203", "ebec6f5b-6204-4343-9337-dd21f9b52715", null, "16002180", "86430839", null);
//		JsonResponse<VOPrdKucunMUI> jr = productOrderService.loadBookingMessage(null, "2d7aa844-9a68-45b9-8b69-0492cc50692a", "51161f3d-c334-43a8-9b57-369bbcdf385e", null, null, null);
////		System.out.println(jr.getResult().getHyTreatmentPerson());
//		List<PickerMUI<VOPrdClinic>> list = jr.getResult().getParentAccountListMUI();
//		for (PickerMUI<VOPrdClinic> pickerMUI : list) {
//			System.out.println(pickerMUI.getText());
//		}
	}

	@Test
	public void testSubmitOrderForGateWay() {
	}

	@Test
	public void testFindBeforeVisitByCard() {
	}

}
