package com.wanjia.dsi.product;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.model.HyPrdConfig;
import com.wanjia.dsi.product.service.HyPrdClinicConfigService;
import com.wanjia.dsi.product.service.HyPrdClinicService;
import com.wanjia.dsi.product.service.HyPrdConfigService;
import com.wanjia.dsi.product.vo.VOPrdClinic_SZ;
import com.wanjia.dsi.product.vo.VOPrdEditClinic_SZ;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = {"classpath*:spring/*.xml"})
public class HyPrdClinicServiceTest {

	@Autowired
	private HyPrdClinicService hyPrdClinicService;
	
	@Autowired
	private HyPrdConfigService hyPrdConfigService;
	
	@Autowired
	private HyPrdClinicConfigService hyPrdClinicConfigService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void getClinicByRegisterId() {
		JsonResponse<VOPrdClinic_SZ> result = hyPrdClinicService.getClinicByRegisterId("4b52236e-dc4f-47f6-adf5-0cc9168f50bc");
		System.out.print(result);	
	}
	
	@Test
	public void getClinicByCityId() {
		JsonResponse<VOPrdClinic_SZ> result = hyPrdClinicService.getClinicByCityId("4b52236e-dc4f-47f6-adf5-0cc9168f50bc", "838");
		System.out.print(result);	
	}
	
	@Test
	public void getClinicByClinicId() {
		JsonResponse<VOPrdEditClinic_SZ> result = hyPrdClinicService.getClinicByClinicId("4b52236e-dc4f-47f6-adf5-0cc9168f50bc", "c420f4dc-7682-412e-a78c-4601b361cf44");
		System.out.print(result);	
	}
	
	@Test
	public void getPrdConfig() {
		String configCode ="CANCEL_TIME_LIMIT";
		JsonResponse<HyPrdConfig> result = hyPrdConfigService.getPrdConfig(configCode);
		System.out.print(result);
	}
	
	@Test
	public void getPrdConfig1() {
		String configCode ="CREATE_TIME_LIMIT";
		JsonResponse<HyPrdConfig> result = hyPrdConfigService.getPrdConfigByClinic(configCode,"c420f4dc-7682-412e-a78c-4601b361cf44");
		System.out.print(result);
	}
	
	@Test
	public void getPrdConfigByClinic() {
		hyPrdClinicConfigService.getPrdConfigByClinic("123", "123");
	}
}

