package com.wanjia.dsi.product;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.dao.mapper.VOAddressInfoApprovalMapper;
import com.wanjia.dsi.product.model.VOMyProductDetail;
import com.wanjia.dsi.product.model.VOPrdOrderDetailService;
import com.wanjia.dsi.product.service.ProductOrderService;
import com.wanjia.dsi.product.service.impl.MyProductDetailServiceImpl;
import com.wanjia.dsi.product.vo.VOAddressInfoApproval;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class MyProductDetailServiceImplTest {
	@Autowired
	MyProductDetailServiceImpl myProductDetailServiceImpl;
	@Autowired
	private VOAddressInfoApprovalMapper voAddressInfoApprovalMapper;
	
	@Autowired
	private ProductOrderService productOrderService;
	
	@Test
	public void testgetMyProductList(){
		String userId = "640";
		String prdType = "牙科测试11";
		String provinceCode = "23";
		String cityCode = "全部";
		String pageNo = "1"; 
		String pageSize = "10";
		JsonResponse<PageInfo<VOMyProductDetail>> aa = myProductDetailServiceImpl.getMyProductList(userId,null,null,null,null,pageNo,pageSize);
		PageInfo<VOMyProductDetail> pi = aa.getResult();
		List<VOMyProductDetail>  list = pi.getList();
		for(VOMyProductDetail vo:list){
			System.out.println("-------" + vo.getPrdId() + "," + vo.getTakenStatus());
		}
		System.out.println(list.size());
	}

	@Test
	public void testfindMyPrdOrderDetail(){
		
		String prdId="7b54f6e4-3917-4b2a-badb-854f9380167f";
//		String prdId ="liugc-prdid01";
		String userId = "4108";
		String kucunId ="30ed5762-c7e3-4746-b0e7-e46f268e4496";
//		String order_detai_id = "8d962f17-096e-453b-8490-64e240065011";
		JsonResponse<VOMyProductDetail> aa = myProductDetailServiceImpl.findMyPrdOrderDetail(prdId,null,kucunId,null);
//		System.out.println(aa.getResult().getHyTreatmentPerson().getVisitIdCardTypeCodese());
		VOMyProductDetail result = aa.getResult();
		System.out.println(result.getCouponName() + "," + result.getKucunId() + "," + result.getTakenStatus() + "," 
		+ result.getOnlineFlag() + "," + result.getDistributeType());
	}
	@Test
	public void testfindProvinceCityByCode(){
		String province =null;
		if(null != province && !"".equals(province) && !"全部".equals(province)){
		String[] provinceArr = province.split("\\|");
		List<String> provinceList = new ArrayList<String>();
		for(int j=0;j<provinceArr.length;j++){
			provinceList.add(provinceArr[j]);
		}
		
		/*cityCodeList.add("984");
		cityCodeList.add("2397");*/
		String separator ="、";
		String aa = myProductDetailServiceImpl.findProvinceCityByCode(provinceList, separator);
		System.out.println("----------------------" + aa);
		}
	}
	
	@Test
	public void  testgetServiceByDetailList(){
		VOAddressInfoApproval a = new VOAddressInfoApproval();
		a.setPrdId("liugc-prdid01");
		
		List<VOAddressInfoApproval> aa = voAddressInfoApprovalMapper.selectByPrdId(a);
		System.out.println("----------------------" + aa);
		
	}
	
	
	
	@Test
	public void testgetProductState(){
		
		VOMyProductDetail detail15 = new VOMyProductDetail();
		
		SimpleDateFormat sdf =   new SimpleDateFormat( "yyyy-MM-dd" );

		try {
			detail15.setValidEndDate(sdf.parse("2018-10-01"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		VOPrdOrderDetailService service1 = new VOPrdOrderDetailService();
		service1.setServiceCount("2");
		service1.setId("service_1");
		service1.setServiceId("service_1");
		service1.setIsUnlimite("1");
		VOPrdOrderDetailService service2 = new VOPrdOrderDetailService();
		service2.setId("service_2");
		service2.setServiceId("service_2");
		service2.setServiceCount("1");
		service2.setIsUnlimite("1");
		
		List<VOPrdOrderDetailService> serviceList = new ArrayList<VOPrdOrderDetailService>();
		
		serviceList.add(service1);
		serviceList.add(service2);
		detail15.setId("a2b9e220-c630-4e6e-a73f-0b46149bd4ed");
		detail15.setKucunId("kucun_id_001");
		detail15.setUseFrequence("1");
		//detail15.setVoPrdOrderDetailServiceList(serviceList);

		List<VOMyProductDetail> detailList = new ArrayList<VOMyProductDetail>();
		detailList.add(detail15);
		List<String> cardIds = new ArrayList<String>();
		cardIds.add("kucun_id_001");

		
		myProductDetailServiceImpl.getProductState(detailList,cardIds);

	}
	
	@Test
	public void testProductOrderService(){
		productOrderService.findServiceTypeExplain("8a8da8f3-e5de-49b0-af23-9a1f6efae6b6", "2ac2bada-9778-4181-b0c0-cd59bd6d58eb");
	}
}
