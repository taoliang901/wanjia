package com.wanjia.dsi.product.service.impl;

import java.util.Collection;
import java.util.HashSet;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.product.service.PrdFinSettlementDetailService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PrdFinSettlementDetailServiceImplTest {

	@Autowired
	private PrdFinSettlementDetailService prdFinSettlementDetailService;
	
	@Test
	public void testCreateMonthlyBill(){
		Long a1 = System.currentTimeMillis();
		prdFinSettlementDetailService.createMonthlyBill();
		Long a2 = System.currentTimeMillis();
		Long time = a2-a1;
		System.out.println("-------------END-----" + time);
	}
	
	@Test
	public void testCreateMonthlySettlement(){
		System.out.println("-------------BEGINING-----" );
		Long a1 = System.currentTimeMillis();
		prdFinSettlementDetailService.createMonthlySettlement();
		Long a2 = System.currentTimeMillis();
		Long time = a2-a1;
		System.out.println("-------------END-----" + time);
	}
	
	@Test
	public void testSearchHeaderListByClinicId(){
    	Collection set = new HashSet();
    	set.add("00046de6-29fe-42cd-b90c-2165c3268e8e");
    	set.add("0120a5fd-0ee4-4c10-9612-e6b1eb3aca02");
    	set.add("0214a9cc-530a-41c2-908e-9641e9212c75");
		prdFinSettlementDetailService.searchHeaderListByClinicId(set);
	}
}
