/**
 * 
 */
package com.wanjia.dsi.common.utils;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.product.service.impl.StockServiceImplTest;

/**
 * @author huanglei698
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class RedisPublishScribeTest2 {

	private Logger logger = Logger.getLogger(StockServiceImplTest.class);

	@Autowired
	private RedisPublish publish;

	@Autowired
	private RedisScribe scribe;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPublishScribe() {
		// scribe.gogogo();
		publish.publishMessage("test_channel_001", "测试使用");
		publish.publishMessage("test_channel_002", "测试使用+测试使用");
		publish.publishMessage("channel_001", "测试使用!");
		publish.publishMessage("test_001", "测试使用!!");

		// try {
		// Thread.sleep(5 * 1000 * 100);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
	}
}
