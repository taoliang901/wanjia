package com.wanjia.dsi.web.area.service.impl;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.area.model.PickerMUI;
import com.wanjia.dsi.web.area.service.PickerMUIService;
import com.wanjia.dsi.web.clinic.model.VOClinicProduct;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PickerMUIServiceImplTest {
	@Autowired
	PickerMUIService pickerMUIService;

	@Test
	public void testgetCityDistrict() {
		String totalRegisterId = "123";
		String prdId = "0e48c91e-40f5-4627-bdaf-d5625da302eb";
		VOClinicProduct voClinicProduct = new VOClinicProduct();
		voClinicProduct.setPrdId(prdId);
		voClinicProduct.setTotalRegisterId(totalRegisterId);
		JsonResponse<List<PickerMUI>> jr = pickerMUIService.getCityDistrict(voClinicProduct);
		List<PickerMUI> cityDistrict = jr.getResult();
		for (int i = 0; i < cityDistrict.size(); i++) {
			PickerMUI p = cityDistrict.get(i);
			System.out.println("----------ppppp ----begin----------------");
			System.out.println(p.getValue() + "," + p.getText() + ";");
			List<PickerMUI> qList = p.getChildren();
			for (int j = 0; j < qList.size(); j++) {
				PickerMUI q = qList.get(j);
				System.out.println(q.getValue() + "," + q.getText());
			}
			System.out.println("----------ppppp -----end---------------");
		}

	}

}
