package com.wanjia.dsi.web.raffle;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.util.RegisterSource;
import com.wanjia.dsi.web.raffle.model.RaffleUserDetail;
import com.wanjia.dsi.web.raffle.service.RaffleUserDetailService;
import com.wanjia.dsi.web.raffle.util.RaffleKey;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class RaffleUserDetailServiceImplTest {

	@Autowired
	private RaffleUserDetailService raffleUserDetailService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	// 抽奖
	@Test
	public void testStartDrawRaffle() throws Exception {
		for (int i = 0; i < 120; i++) {
			raffleUserDetailService.startDrawRaffle("87641f39-492f-4a52-9978-0d6475b021b4",
					RegisterSource.CLINIC.getCode(), RaffleKey.RAFFLE_KEY_CK_001);
		}
	}

	// 抽奖
	@Test
	public void testStartDrawRaffle2() throws Exception {
		for (int i = 0; i < 120; i++) {
			JsonResponse<RaffleUserDetail> jr = raffleUserDetailService.startDrawRaffle(
					"98f8af18-c93d-4568-9d77-a6628d47dd33", "0050664f-33f7-4fcb-b92b-8365a47d32eb",
					RegisterSource.CLINIC.getCode(), RaffleKey.RAFFLE_KEY_DZP_001);
			System.out.println("----" + jr.getStatus() + " " + jr.getErrorMsg());
		}
	}
}
