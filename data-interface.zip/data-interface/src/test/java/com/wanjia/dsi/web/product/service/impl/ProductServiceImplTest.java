package com.wanjia.dsi.web.product.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.mongodb.Pagination;
import com.wanjia.dsi.common.constant.Consts;
import com.wanjia.dsi.common.utils.CommonJedis;
import com.wanjia.dsi.product.dao.mapper.StockMapper;
import com.wanjia.dsi.product.dao.mapper.VOPrdInfoMapper;
import com.wanjia.dsi.product.model.HealthProduceService;
import com.wanjia.dsi.product.model.PrdInfoBO;
import com.wanjia.dsi.product.model.PrdKucun;
import com.wanjia.dsi.product.model.ProductInfo;
import com.wanjia.dsi.product.model.VOPrdInfo;
import com.wanjia.dsi.product.model.VOPrdInfoBO;
import com.wanjia.dsi.product.service.ProductService;
import com.wanjia.dsi.product.vo.VOPrdService;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ProductServiceImplTest {
	@Autowired
	private ProductService productService;
	@Autowired
	private StockMapper stockMapper;
	
	@Autowired
	private CommonJedis commonJedis;
	
	@Autowired
	private VOPrdInfoMapper voPrdInfoMapper;
	
	@Test
	public void testGetProduceList() {
		ProductInfo productInfo = new ProductInfo();
		productInfo.setStatus("0");
		productInfo.setIsFrontShow("0");
		JsonResponse<PageInfo<ProductInfo>> jr = productService.getProduceList(productInfo);
		System.out.println(jr.getResult());
	}

	@Test
	public void getOnlineProduceInfoForList() {
		Map<String, Object> map = new HashMap<String, Object>();
		String sldPrdTypeName = "健康险-(护齿保)";
		String sldAreaCode = "838";
		String sldPriceSortCode = "DESC";
		String sldStockSortCode = "ASC";
		String prdName = "裴春乐";
		map.put("prdTypeName", sldPrdTypeName);
		map.put("city", sldAreaCode);
		map.put("orderByClause", "IFNULL(USED_TOTAL,0)*1 " + sldStockSortCode);
		map.put("orderByClause", " IFNULL(PRD_PRICE,0)*1 " + sldPriceSortCode);
		// map.put("couponName", prdName);
		map.put("isFrontShow", "0");
		JsonResponse<PageInfo<ProductInfo>> jr = productService.getOnlineProduceInfoForList(map, 10, 1);
		PageInfo<ProductInfo> page = jr.getResult();

		List<ProductInfo> list = page.getList();
		for (ProductInfo p : list) {
			System.out.println(p.getId() + "," + p.getCouponName() + "," + p.getCity() + "," + p.getPrdTypeName());
		}
	}

	@Test
	public void getProduceInfo() {
		ProductInfo product = new ProductInfo();
		product.setStatus("0");
		product.setId("a1180542-e147-40e4-87f3-892751e55101");
		JsonResponse<ProductInfo> jr = productService.getProduceInfo(product);
		System.out.println(jr.getResult());

	}

	@Test
	public void findCouponDetailTest() {
		ProductInfo temp = new ProductInfo();
		temp.setId("b399ff56-5596-4f2d-a155-cc5675b13a2d");
		JsonResponse<ProductInfo> productInfoJson = this.productService.findCouponDetail(temp);
		ProductInfo productInfo = productInfoJson.getResult();
		List<HealthProduceService> list = productInfo.getHps();
		for (HealthProduceService healthProduceService : list) {
			// System.out.println(healthProduceService.getRemark());
		}
	}

	@Test
	public void testgetPrdInfoServiceById() {
		String id = "1d4a0fe3-8fa8-4926-b904-145e68fae53b";
		String visitId = "1972a4c9-8d22-4c39-a619-cc7a8de5d133";
		JsonResponse<VOPrdInfo> jr = productService.getPrdInfoServiceById(id, visitId);
		VOPrdInfo voPrdInfo = jr.getResult();
		System.out.println(voPrdInfo.getId() + "," + voPrdInfo.getCouponName() + voPrdInfo.getUseFrequence());
		System.out.println("-------------------------------------");
		List<VOPrdService> serviceList = voPrdInfo.getPrdServiceList();
		for (VOPrdService v : serviceList) {
			System.out.println(v.getServiceId() + "," + v.getServiceName() + "," + v.getServiceCount());
		}
		List<PrdKucun> kucun = voPrdInfo.getPrdKucunList();
		for (PrdKucun p : kucun) {
			System.out.println(p.getId() + "," + p.getBuyerUserId());
		}

		System.out.println("-------------------------------------");
	}

	@Test
	public void testgetTreatmentPersonByPrdId() {
		String prdId = "1d4a0fe3-8fa8-4926-b904-145e68fae53b";
		String mobile = "13917566072";
		int pageNo = 1;
		int pageSize = 100;
		JsonResponse<PageInfo<HyTreatmentPerson>> jr = productService.getTreatmentPersonByPrdId(prdId, mobile, pageNo,
				pageSize);
		PageInfo<HyTreatmentPerson> page = jr.getResult();
		List<HyTreatmentPerson> list = page.getList();
		System.out.println("-------------------------------------");
		for (HyTreatmentPerson v : list) {
			System.out.println(v.getVisitId() + "," + v.getVisitMobile());
		}
		System.out.println("-------------------------------------");
	}

	@Test
	public void testinsertPrdInfoBO() {
		PrdInfoBO prdInfoBO = new PrdInfoBO();
		prdInfoBO.setPrdId("1122311");
		prdInfoBO.setCouponName("testName");
		prdInfoBO.setCouponStock(1004);
		productService.insertPrdInfoBO(prdInfoBO);

	}

	@Test
	public void testinsertPrdInfoBOByPrdId() {
		String prdId = "0105a6ba-d582-4433-9eac-1dcfb6dfe06b";
		String usedPrdStock = "100";
		String prdStock = "1000";
		// productService.insertPrdInfoBOByPrdId(prdId,prdStock, null);

	}

	@Test
	public void testupdatePrdInfoBO() {
		PrdInfoBO prdInfoBO = new PrdInfoBO();
		prdInfoBO.setPrdId("1231");
		prdInfoBO.setCouponName("testName1");
		// prdInfoBO.setCity("12354");
		// prdInfoBO.setCouponStock(500);
		productService.updatePrdInfoBO(prdInfoBO);
	}

	@Test
	public void testfindPrdInfoBO() {
		VOPrdInfoBO voPrdInfoBO = new VOPrdInfoBO();
		// voPrdInfoBO.setPrdId("123");
		//voPrdInfoBO.setCouponName("testName1");
		// prdInfoBO.setCity("12354");
		// prdInfoBO.setCouponStock(500);
		// voPrdInfoBO.setOnLinePrdStock(222);
		/*voPrdInfoBO.setOrderField("usedPrdStock");
		voPrdInfoBO.setOrderValue("DESC");*/
		voPrdInfoBO.setPageSize(1000);
		JsonResponse<Pagination<PrdInfoBO>> jr = productService.findPrdInfoBO(voPrdInfoBO);
		Pagination<PrdInfoBO> page = jr.getResult();
		List<PrdInfoBO> list = page.getDatas();
		System.out.println("-------------------------");
		for (PrdInfoBO p : list) {
			System.out.println(p.getPrdId() + "," + p.getCouponName() + "," + p.getCity() + "," + p.getCityName() + "," + p.getPrdTypeSeq() + ","
		+ p.getUsedPrdStock() + "," + p.getPrdTypeSeq() + "," + p.getOrderNum());
		}
		System.out.println("-------------------------");
	}
	
	@Test
	public void testinsertPrdInfoBOByList() {
		List<PrdInfoBO> prdInfoBOList = new ArrayList<PrdInfoBO>();
		PrdInfoBO prdInfoBO1 = new PrdInfoBO();
		PrdInfoBO prdInfoBO2 = new PrdInfoBO();
		PrdInfoBO prdInfoBO3 = new PrdInfoBO();
		prdInfoBO1.setPrdId("7675895d-23c3-4dd1-8307-4c05cf18235e");
		prdInfoBO1.setCouponStock(1001);
		prdInfoBO1.setUsedPrdStock(101);
		prdInfoBO2.setPrdId("2dc4a1f4-b784-4423-9e2d-376a27fad14a");
		prdInfoBO2.setCouponStock(1002);
		prdInfoBO2.setUsedPrdStock(102);
		prdInfoBO3.setPrdId("8a6f1ed8-6ba6-4e87-9ff8-f4d1e41e0ea8");
		prdInfoBO3.setCouponStock(1003);
		prdInfoBO3.setUsedPrdStock(103);
		prdInfoBOList.add(prdInfoBO1);
		prdInfoBOList.add(prdInfoBO2);
		prdInfoBOList.add(prdInfoBO3);
		productService.insertPrdInfoBOByList(prdInfoBOList);

	}
	@Test
	public void testgetPrdInfoSeqByIdMongo() {
		String id = "01858000-8195-49eb-b0ca-9febef632f46";
		VOPrdInfo voPrdInfo = voPrdInfoMapper.getPrdInfoSeqByIdMongo(id);
		System.out.println(voPrdInfo.getId() + "," + voPrdInfo.getCouponName() + "," + voPrdInfo.getCity() + "," + voPrdInfo.getPrdTypeSeq());
	}
	
	
	
}
