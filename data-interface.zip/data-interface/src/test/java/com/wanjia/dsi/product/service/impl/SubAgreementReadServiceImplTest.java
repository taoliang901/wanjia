package com.wanjia.dsi.product.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.model.PrdInfo;
import com.wanjia.dsi.product.service.FrameAgreementReadService;
import com.wanjia.dsi.product.vo.VOPrdSubAgreementClinic;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class SubAgreementReadServiceImplTest {

    @Autowired
    private SubAgreementReadServiceImpl subAgreementReadServiceImpl;
    
    @Autowired
    private SubAgreementWriteServiceImpl subAgreementWriteServiceImpl;
    
    @Autowired
    private FrameAgreementReadService frameAgreementReadService;
    
    @Test
    public void testFindClinicsByProduct() {
        
        Map<String,Object> map = new HashMap<String ,Object>();
        map.put("clinicId", "0acd1aa8-0e13-49a6-a801-50500710fe87");
        JsonResponse<List<VOPrdSubAgreementClinic>> jr = subAgreementReadServiceImpl.findSubClinicList(map);
        System.out.println("======================="+jr.getResult().toString());
    }
    
    @Test
    public void testFindPrdList() {
        long startTime = System.currentTimeMillis();
        Map<String,Object> map = new HashMap<String ,Object>();
//        map.put("clinicId", "0acd1aa8-0e13-49a6-a801-50500710fe87");
        JsonResponse<List<PrdInfo>> jr = subAgreementReadServiceImpl.findPrdInfoList(map);
        long endTime = System.currentTimeMillis();
        System.out.println("=============执行时间=========="+(endTime-startTime));
    }
    
    @Test
    public void testFindPrdInfoList() {
        long startTime = System.currentTimeMillis();
        Map<String,Object> map = new HashMap<String ,Object>();
//        map.put("clinicId", "0acd1aa8-0e13-49a6-a801-50500710fe87");
        JsonResponse<List<PrdInfo>> jr = subAgreementReadServiceImpl.findPrdInfoList(map);
        
        long endTime = System.currentTimeMillis();
        System.out.println("=============执行时间=========="+(endTime-startTime));
    }
    
    @Test
    public void testFindSubAgreementInfoList() {
        long startTime = System.currentTimeMillis();
        Map<String,Object> map = new HashMap<String ,Object>();
//        map.put("clinicId", "0acd1aa8-0e13-49a6-a801-50500710fe87");
        map.put("agreementId", "please_dont_delete_thanks");
        map.put("pageSize", 5);
        map.put("pageNo", 1);
        JsonResponse<List<Map<String, Object>>> jr = subAgreementReadServiceImpl.findSubAgreementInfoList(map);
        
        long endTime = System.currentTimeMillis();
        System.out.println("=============执行时间=========="+(endTime-startTime));
    }

    @Test
    public void testUpdateSubAgreementStatus() {
        long startTime = System.currentTimeMillis();
        Map<String,Object> map = new HashMap<String ,Object>();
//        map.put("clinicId", "0acd1aa8-0e13-49a6-a801-50500710fe87");
        map.put("subAgreementId", "ed1f9f88-c754-4784-af38-f4563bfbd27d");
        map.put("subStatus", "1");
        JsonResponse<Void> jr = subAgreementWriteServiceImpl.updateSubAgreementStatus(map);
        
        long endTime = System.currentTimeMillis();
        System.out.println("=============执行时间=========="+(endTime-startTime));
    }
    
    @Test
    public void testFindOneSubAgreementById() {
        long startTime = System.currentTimeMillis();
        Map<String,Object> map = new HashMap<String ,Object>();
//        map.put("clinicId", "0acd1aa8-0e13-49a6-a801-50500710fe87");
//        map.put("agreementId", "10f0a9cf-c11a-4e52-84c0-862b0e7e7910");
        map.put("agreementId", "please_dont_delete_thanks");
        map.put("subAgreementId", "181ad664-6d52-4f16-8140-9ae29eb48089");
        JsonResponse<Map<String, Object>> jr = subAgreementReadServiceImpl.findOneSubAgreementById(map);
        
        long endTime = System.currentTimeMillis();
        System.out.println("=============执行时间=========="+(endTime-startTime));
    }
    
    @Test
    public void testFindOneById() {
        long startTime = System.currentTimeMillis();
        JsonResponse<Map<String, Object>> jr = frameAgreementReadService.findOneById("please_dont_delete_thanks");
        
        long endTime = System.currentTimeMillis();
        System.out.println("=============执行时间=========="+(endTime-startTime));
    }
    
    @Test
    public void testFindSettlementRatio() {
        long startTime = System.currentTimeMillis();
        Map<String,Object> map = new HashMap<String ,Object>();
        map.put("productId", "72e948ab-d859-4fbd-b785-64f6a9d9e9b1");
//        map.put("subAgreementId", "181ad664-6d52-4f16-8140-9ae29eb48089");
        JsonResponse<Map<String, Object>> jr = subAgreementReadServiceImpl.findSettlementRatio(map);
        
        long endTime = System.currentTimeMillis();
        System.out.println("=============执行时间=========="+(endTime-startTime));
    }
    
    @Test
    public void testFindSubClinicList() {
        long startTime = System.currentTimeMillis();
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("clinicId", "420cba73-d83a-4d1e-b33e-40faf3fcca6d");
//        map.put("clinicName","口腔");
        JsonResponse<List<VOPrdSubAgreementClinic>> jr = subAgreementReadServiceImpl.findSubClinicList(map);
        
        long endTime = System.currentTimeMillis();
        System.out.println("=============执行时间=========="+(endTime-startTime));
    }
    
    @Test
    public void checkClinicAndPrdServerTime(){
        
        List<String> list = new ArrayList<String>();
        list.add("1");
        list.add("2");
        list.add("3");
        JsonResponse<Void> jr= subAgreementWriteServiceImpl.terminateContractQuartz();
    }
}
