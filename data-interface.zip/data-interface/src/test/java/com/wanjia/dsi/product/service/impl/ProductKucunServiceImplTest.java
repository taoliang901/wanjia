package com.wanjia.dsi.product.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.dsi.product.service.ProductKucunService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class ProductKucunServiceImplTest {

	@Autowired
	private ProductKucunService productKucunService;
	
	@Test
	public void testUpdateCardBalance(){
		String clinicId="b1a009c4-7743-4d87-90a2-5e0e73bbae85"; //波罗密整形医院
		String prdId = "c840a261-33eb-4e0f-a7f8-c02bdd471618"; //TL-产品1
		String scheduleDate="2016-12-16";
		String cardId = "0247fd6e-7b81-45dc-87ba-c2e83c77bb4f";
		
		productKucunService.updateCardBalance(clinicId, prdId, scheduleDate, cardId);
	}
}
