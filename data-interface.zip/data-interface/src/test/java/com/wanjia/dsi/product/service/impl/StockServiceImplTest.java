/**
 * 
 */
package com.wanjia.dsi.product.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.service.StockService;

/**
 * @author huanglei698
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class StockServiceImplTest {

	private Logger logger = Logger.getLogger(StockServiceImplTest.class);

	@Autowired
	private StockService stockService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	// @Test
	public void test() {
		logger.info("库存总数:["
				+ stockService
						.getStocksNumber("07f78bfa-ed6c-4d31-a329-60477e04e5e5", "128ae3e2-26bf-4515-829c-b12eefeaeeb2",
								"32dd539c-f400-421b-9656-d7f9d0644de0", "123123213")
						.getResult().get(stockService.getStockNumberPrefix() + "07f78bfa-ed6c-4d31-a329-60477e04e5e5")
						.toString()
				+ "]，已预约数:[" + stockService.getStocksStatus("07f78bfa-ed6c-4d31-a329-60477e04e5e5").getResult()
						.get(stockService.getStockPrefix() + "07f78bfa-ed6c-4d31-a329-60477e04e5e5").size()
				+ "]");
		logger.info(
				"库存总数:[" + stockService.getStockNumber("07f78bfa-ed6c-4d31-a329-60477e04e5e5").getResult().toString()
						+ "]，已预约数:["
						+ stockService.getStockStatus("07f78bfa-ed6c-4d31-a329-60477e04e5e5").getResult().size() + "]");
	}

	@Test
	public void updateAllStockStatus() {
		logger.info(stockService.updateAllStockStatus().getResult());
	}

	@Test
	public void updateupdateStockNumber() {
		stockService.updateStockNumber("2dc4a1f4-b784-4423-9e2d-376a27fad14a", 0);
	}

	@Test
	public void getStockNumber() {
		JsonResponse<Map<String, Integer>> jsonResponseScores = stockService
				.getStockUsedNumber("9a4c9e84-aedf-4028-b721-8b9e07ba1098", "a3777d47-11a3-4518-8be6-c7994c761e71");
		JsonResponse<Map<String, Integer>> jsonResponseTotals = stockService
				.getStockTotalNumber("9a4c9e84-aedf-4028-b721-8b9e07ba1098", "a3777d47-11a3-4518-8be6-c7994c761e71");
		logger.info("已消耗：" + jsonResponseScores.getResult().get("9a4c9e84-aedf-4028-b721-8b9e07ba1098"));
		logger.info("总数：" + jsonResponseTotals.getResult().get("9a4c9e84-aedf-4028-b721-8b9e07ba1098"));
	}

	@Test
	public void setStockNumber() {
		JsonResponse<Map<String, Integer>> jsonResponseScores = stockService
				.getStockUsedNumber("9a4c9e84-aedf-4028-b721-8b9e07ba1098");
		JsonResponse<Map<String, Integer>> jsonResponseTotals = stockService
				.getStockTotalNumber("9a4c9e84-aedf-4028-b721-8b9e07ba1098");
		logger.info("原消耗：" + jsonResponseScores.getResult().get("9a4c9e84-aedf-4028-b721-8b9e07ba1098"));
		logger.info("原总数：" + jsonResponseTotals.getResult().get("9a4c9e84-aedf-4028-b721-8b9e07ba1098"));
		Map<String, Map<String, String>> stocks = new HashMap<String, Map<String, String>>();
		Map<String, String> stock = new HashMap<String, String>();
		stock.put("d07e470d-e399-4d6d-b629-8b0830f62ecf", "1");
		stocks.put("9a4c9e84-aedf-4028-b721-8b9e07ba1098", stock);
		// stockService.setStockStatusBatch(stocks);
		stockService.setStockStatus("9a4c9e84-aedf-4028-b721-8b9e07ba1098", "d07e470d-e399-4d6d-b629-8b0830f62ecf",
				"1");
		jsonResponseScores = stockService.getStockUsedNumber("9a4c9e84-aedf-4028-b721-8b9e07ba1098");
		jsonResponseTotals = stockService.getStockTotalNumber("9a4c9e84-aedf-4028-b721-8b9e07ba1098");
		logger.info("已消耗：" + jsonResponseScores.getResult().get("9a4c9e84-aedf-4028-b721-8b9e07ba1098"));
		logger.info("总数：" + jsonResponseTotals.getResult().get("9a4c9e84-aedf-4028-b721-8b9e07ba1098"));
		logger.info("原方法的数量：" + stockService.getStockStatus("9a4c9e84-aedf-4028-b721-8b9e07ba1098").getResult().size());

	}

	@Test
	public void getFreeStockTest() {
		JsonResponse<Map<String, String>> map = stockService.getFreeStock("9a4c9e84-aedf-4028-b721-8b9e07ba1098", 2);
		Set<String> keys = map.getResult().keySet();
		for (String key : keys) {
			logger.info("==========" + key + ":" + map.getResult().get(key));
		}
	}

	@Test
	public void getTotalStockNumber() {
		JsonResponse<Map<String, Integer>> map = stockService
				.getStockTotalNumber("9a4c9e84-aedf-4028-b721-8b9e07ba1098");
		logger.info("=================" + map.getResult().get("9a4c9e84-aedf-4028-b721-8b9e07ba1098"));
	}

}
