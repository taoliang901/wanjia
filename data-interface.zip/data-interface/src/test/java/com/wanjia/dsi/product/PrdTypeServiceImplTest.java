package com.wanjia.dsi.product;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.product.model.PrdType;
import com.wanjia.dsi.product.service.PrdTypeService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PrdTypeServiceImplTest {
	@Autowired
	private PrdTypeService prdTypeService;
	@Test
	public void testGetTypeList() {
		JsonResponse<List<PrdType>> jr = prdTypeService.getTypeList();
		for (PrdType p : jr.getResult()) {
			System.out.println(p.getPrdTypeName());
		}
	}
	
	@Test
	public void testGetOnlineProduceTypeList(){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("status", "0");
		JsonResponse<List<PrdType>> jr = prdTypeService.getOnlineProduceTypeList(map);
		for (PrdType p : jr.getResult()) {
			System.out.println(p.getPrdTypeName());
		}
	}

}
