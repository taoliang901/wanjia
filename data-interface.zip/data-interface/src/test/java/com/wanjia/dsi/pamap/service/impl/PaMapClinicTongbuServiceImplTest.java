package com.wanjia.dsi.pamap.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.pamap.service.impl.PaMapClinicTongbuServiceImpl;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = { "classpath*:spring/*.xml" })
public class PaMapClinicTongbuServiceImplTest {

	@Autowired
	PaMapClinicTongbuServiceImpl paMapClinicTongbuServiceImpl;
	
	@Test
	public void testDoTongbuByDate(){
		JsonResponse<Void>  result =  paMapClinicTongbuServiceImpl.doTongbuByDate("2016-07-13");
		System.out.println("------------------------------");
		System.out.println(result.toString());
		
		
//		String s = "皮肤科|其 他|特种医   学与军  事医学科|内科|外科|心内科";
//		
//		s = s.replace(" ", "");
//		String[] ss = s.split("\\|");
//		int cnt = ss.length;
//		if(cnt > 3) {
//			cnt = 3;
//		}
//		String outS = "";
//		for(int i=0; i<cnt; i++) {
//			outS += ss[i] + ",";
//		}
//		if(StringUtils.isNotBlank(outS)) {
//			outS = outS.substring(0, outS.length()-1);
//		}
//		System.out.println(outS);
	}
}
