package com.wanjia.cms.demo.controller;

/**   
* @Title: DictoryControllerTest.java 
* @Package AgentStoreControllerTest 
* @Description: TODO(用一句话描述该文件做什么) 
* @author CHENKANG560  
* @date 2016年3月7日 下午12:01:51 
* @version V1.0   
*/

import java.util.Date;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.wanjia.dsi.common.utils.RestTemplateUtil;
import com.wanjia.dsi.web.area.model.Area;
import com.wanjia.dsi.web.dictionary.model.Dictionary;



/** 
* @ClassName: DictoryControllerTest 
* @Description: TODO(这里用一句话描述这个类的作用) 
* @author Chenkang 
* @date 2016年3月7日 下午12:01:51 
*  
*/
public class DictoryControllerTest {

	 private static final Logger logger = LoggerFactory.getLogger(DictoryControllerTest.class);
	    @Test
	    public void testCreateOrUpdate() {
	        RestTemplate rt = new RestTemplate();
	        Dictionary dictionary = new Dictionary();
	        dictionary.setDictCode("SYS_DICT_GENDER");
	        String jsonString = JSON.toJSONString(dictionary);
	        logger.info(jsonString);
	        //String jr = rt.postForObject("http://localhost:8080/data-interface/dictionary/getDictionaryList.do", dictionary, String.class);
	        Area area = new Area();
	        area.setParentId("0");
	         String post = RestTemplateUtil.post("http://localhost:8080/data-interface/area/getCityList.do", new ParameterizedTypeReference<String>() {
	        }, area);
	       // logger.info(post);
	         System.out.println("===="+post);
	        
	    }
}
