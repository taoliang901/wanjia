package com.wanjia.cms.demo.controller;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.wanjia.dsi.common.utils.RestTemplateUtil;
import com.wanjia.dsi.web.area.model.Area;

public class ActivityControllerTest {

	@Test
	public void testIndex() {
		RestTemplate rt = new RestTemplate();

		/*
		 * String jr = rt.postForObject(
		 * "http://localhost:8080/data-interface/area/getCityByIpOnTaobao.do?ip=116.226.186.167",
		 * null, String.class); System.out.println(jr);
		 */

		Area area = new Area();
		area.setParentId("0");

		
		List list = new ArrayList();
		list.add("SYS_DICT_GENDER");
		list.add("CLINIC_DICT_1");
		list.add("CLINIC_DICT_2");
		
		
		
		String post = RestTemplateUtil.post("http://localhost:8080/data-interface/dictionary/getDictionaryList.do", new ParameterizedTypeReference<String>() {
		}, list);
		System.out.println(post);

		/*
		 * String jr = rt.postForObject(
		 * "http://localhost:8080/data-interface/client/getRecommendClientList.do",
		 * null, String.class); System.out.println(jr);
		 */

	}

}
