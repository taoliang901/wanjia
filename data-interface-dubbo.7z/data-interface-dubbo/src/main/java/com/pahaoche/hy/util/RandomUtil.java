package com.pahaoche.hy.util;

import java.security.SecureRandom;
import java.util.Random;

public class RandomUtil {
    private static char CHARS[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
            'r', 's', 't', 'u', 'v', 'w', 'y', 'z' };
    private static char NON_VOWELS[] = { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's',
            't', 'v', 'w', 'z' };
    private static char VOWELS[] = { 'a', 'e', 'i', 'o', 'u', 'y' };
    private static char NUMBER[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    private static char picChar[] = {'A', 'B', 'C', 'D', 'E', 'F', 'H' , 'J', 'K', 'M', 'N', 'P',
	        'R', 'S', 'T', 'U', 'V', 'W', 'X','Y'};
    private static char picNum[] = {'3', '4', '5', '6', '7', '8'};
    
    public static char randomChar() {
        return CHARS[randomInt(0, CHARS.length - 1)];
    }
    public static char randomPicChar() {
        return picChar[randomInt(0, picChar.length - 1)];
    }
    public static char randomPicNum() {
        return picNum[randomInt(0, picNum.length - 1)];
    }
    public static char randomNum() {
        return NUMBER[randomInt(0, NUMBER.length - 1)];
    }

    public static char randomVowel() {
        return VOWELS[randomInt(0, VOWELS.length - 1)];
    }

    public static char randomNonVowel() {
        return NON_VOWELS[randomInt(0, NON_VOWELS.length - 1)];
    }
    public static String randomPic(int length) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            sb.append(randomNum());
        }
        return sb.toString();
    }
    /**
     * 生成图片验证码随机数字和字母组合(必须同时含有字母和数字)
     * @param length[生成随机数的长度]
     * @return
     */
	public static String getPicRandom(int length) {
		StringBuffer val = new StringBuffer();
		boolean isChar=false;
		int i=0;
		String regex = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{"+length+"}$";
		while(true){
			i++;
			if(randomInt(0,2) % 2 == 0){
				isChar=false;
			}else {
				isChar=true;
			}
			// 字符串
			if (isChar) {
				val.append(randomPicChar());
			} else{ // 数字
				val.append(randomPicNum());
			}
			if(i==length){
				if(val.toString().matches(regex)){
					break;
				}else{
					i=0;
					val = new StringBuffer();
					continue;
				}
			}
		}
		return val.toString();
	}


    public static int randomInt(int min, int max) {
        try {
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            //chenyunxing seed is too slow
            //            byte seed[] = secureRandom.generateSeed(88);
            //            secureRandom.setSeed(seed);
            //return (int) ((Math.random() * (double) (max + 1 - min)) + min);
            return secureRandom.nextInt(max + 1 - min) + min;
        } catch (Exception e) {
            return 0;
        }
    }

    public static String random(int length) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            sb.append(randomNum());
        }
        return sb.toString();
    }

    public static void main(String[] args) {

		for (int i = 0; i < 220; i++) {
			System.out.println(getPicRandom(6));
		}
    }
}
