package com.pahaoche.hy.bean;

import java.io.Serializable;
import java.sql.Timestamp;

/*********************************************************************************
//* Copyright (C) 2014 Pingan Haoche (PAHAOCHE). All Rights Reserved.
//*
//* Filename:      Region.java
//* Revision:      1.0
//* Author:        康才元
//* Created On:    2014年3月26日
//* Modified by:   
//* Modified On:   
//*
//* Description:   验证码表
/********************************************************************************/
public class TmpCheckCode implements Serializable{

	private static final long serialVersionUID = 1L;
	private String uuid;
    //验证码
    private String checkValue;
    //发送类型
    private String additionInfo;
    private String mobile;
    private String userId;
    private String userName;

    private String channelNum;
    private Timestamp createDate;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getCheckValue() {
        return checkValue;
    }

    /**
     * @return the mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * @param mobile the mobile to set
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setCheckValue(String checkValue) {
        this.checkValue = checkValue;
    }

    public String getAdditionInfo() {
        return additionInfo;
    }

    public void setAdditionInfo(String additionInfo) {
        this.additionInfo = additionInfo;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the channelNum
     */
    public String getChannelNum() {
        return channelNum;
    }

    /**
     * @param channelNum the channelNum to set
     */
    public void setChannelNum(String channelNum) {
        this.channelNum = channelNum;
    }

    @Override
    public String toString() {
        return "TmpCheckCode [uuid=" + uuid + ", additionInfo=" + additionInfo + ", mobile=" + mobile + ", channelNum="
                + channelNum + ", createDate=" + createDate + "]";
    }

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
