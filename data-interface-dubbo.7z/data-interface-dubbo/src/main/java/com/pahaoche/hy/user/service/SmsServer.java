package com.pahaoche.hy.user.service;

import java.util.Map;

/*********************************************************************************
 * //* Copyright (C) 2014 Pingan Haoche (PAHAOCHE). All Rights Reserved. //* //*
 * Filename: SmsService.java //* Revision: 1.0 //* Author: <your name> //*
 * Created On: 2014-3-24 //* Modified by: //* Modified On: //* //* Description:
 * <description> /
 ********************************************************************************/

public interface SmsServer {

    /** The cachename. */
    public static String CACHENAME = "VerifyCodeCache";

    public static String POSTFIX_KEY = "YHN7ujm,IK<vfr43e+dc0u-gdew.qz5z$bn4376n";

	public boolean sendAppSms(String mo, String tempId, String username,String password, String ipAddress) throws Exception;
	public boolean sendSms(String mobile, String smsTempId, String randomStr,String ipAddress) throws Exception;
	public boolean sendAllSms(String mobile, String smsTempId, String ipAddress,Map<String, String> map) throws Exception;
}
