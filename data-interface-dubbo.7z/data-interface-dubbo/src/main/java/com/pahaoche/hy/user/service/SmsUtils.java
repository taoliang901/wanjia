package com.pahaoche.hy.user.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.pahaoche.common.Validate_for_hyfw;

/**
 * 短信工具类：参数校验、发送短信 ...
 */
public class SmsUtils {

    public static boolean checkDate(Date snUpdatedDate) {
    	try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Calendar currentCalendar = Calendar.getInstance();

            Date currentDate = currentCalendar.getTime();
            Date currentFormatDate = formatter.parse(formatter.format(currentDate));

            Date snCreateFormatDate = formatter.parse(formatter.format(snUpdatedDate));
            
            return currentFormatDate.after(snCreateFormatDate);
    	} catch(Exception e) {
    		throw new RuntimeException(e);
    	}
    }

    public static boolean sendMsg(SmsServer smsServer, String mobile, String smsTempId, String ipAddress, String randomStr) {
        boolean tag = false;
        try {
            tag = smsServer.sendSms(mobile, smsTempId, randomStr, ipAddress);
        } catch (Exception e) {
//        	logger.error("sendMsg:   " + e.getMessage(), e);
        }
        return tag;
    }

    public static boolean validateDate_for_sendMoblieCodeMsg(String checkType, String mobile, String smsTempId, String channelNum) {

        boolean isFlag = false;

        if (StringUtils.isNotEmpty(checkType)) {

            if (checkType.equals("2")) {
                if (StringUtils.isNotEmpty(mobile) && StringUtils.isNotEmpty(smsTempId)
                        && StringUtils.isNotEmpty(channelNum) && Validate_for_hyfw.validateMo(mobile)) {
                    isFlag = true;
                }
            }
        }

        return isFlag;
    }

    /**
     * 发送短信，后期发送短信可才重用
     */
    public static boolean sendAllMsg(SmsServer smsServer, String mobile, String smsTempId, String ipAddress, Map<String, String> map) {
        boolean tag = false;
        try {
            tag = smsServer.sendAllSms(mobile, smsTempId, ipAddress, map);
        } catch (Exception e) {

        }
        return tag;
    }
}
