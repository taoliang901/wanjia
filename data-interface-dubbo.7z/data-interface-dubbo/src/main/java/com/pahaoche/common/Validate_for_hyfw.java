package com.pahaoche.common;

import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

/*********************************************************************************
//* Copyright (C) 2014 Pingan Haoche (PAHAOCHE). All Rights Reserved.
//*
//* Filename:      Validate.java
//* Revision:      1.0
//* Author:        <your name>
//* Created On:    2014-3-21
//* Modified by:   
//* Modified On:   
//*
//* Description:   验证类
/********************************************************************************/

public class Validate_for_hyfw {

    public static boolean validateMo(String mo) {
        if (mo == null || mo.trim().equals("")) {
            return false;
        }
        if (mo.length() == 32 || mo.length() == 36)
            return true;//wlt uuid        
        if (mo.toLowerCase().startsWith("wlt"))
            return true;//wlt uuid
        if (mo.toLowerCase().startsWith("weixin"))
            return true;//weixin
        if (mo.toLowerCase().startsWith("toa"))
            return true;//toa
        if (mo.length() < 11) {
            return false;
        }
        char[] array = mo.toCharArray();
        for (char num : array) {
            if (num < 48 || num > 57) {
                return false;
            }
        }
        return true;
    }

    public static boolean validateMoTrue(String mo) {
        return Pattern.compile("^1[34578]\\d{9}$").matcher(mo).find();
    }
    public static boolean validateIdCardTrue(String idCard) {
        return Pattern.compile("([0-9]{17}([0-9]|X))|([0-9]{15})").matcher(idCard).find();
    }
    
    public static boolean validateEmailTrue(String email) {
        return Pattern.compile("^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$").matcher(email).find();
    }
    /***
     * 校验积分是否合法
     * @param point
     * @return
     */
    public static boolean validatePoint(String point, int maxPoint) throws Exception {
        //校验积分是否是数字
        if (!PatternUtil.IsIntNumber(point)) {
            return false;
        }
        //校验是否是5的整数倍
        if (Integer.parseInt(point) % 5 != 0) {
            return false;
        }
        //校验积分不能大于系统最大值
        if (Integer.parseInt(point) > maxPoint) {
            return false;
        }
        return true;
    }

    /**`
     * 校验javaBean里面的String类型的属性是否非空
     * 都非空返回true,只要有一个为空返回false
     * 此校验方法只校验String类型的属性，其他类型的属性不进行校验,使用时请注意
     * @param object
     * @return
     */
    public static boolean isAllParamEmpty(Object object) throws Exception {
        Field[] fs = ((Class) object.getClass()).getDeclaredFields();
        for (Field f : fs) {
            f.setAccessible(true);
            //只对String类型的变量进行校验
            if ("class java.lang.String".equals(f.getType().toString())) {
                if (StringUtils.isBlank((String) f.get(object))) {
                    return false;
                }
            }
        }
        return true;
    }
    /**`
     * 校验密码是否是字母加数字组合并且长度大于6小于16
     * @param password
     * @return boolean
     */
    public static boolean checkPassword(String password) {
        if (Pattern.compile("\\d").matcher(password).find() && Pattern.compile("[a-zA-Z]").matcher(password).find()
                && password.length() >= 6 && password.length() <= 16) {
            return true;
        }
        return false;
    }
    /**
     * 检验是否是合法的IP地址
     * @param address String IP地址
     * @return boolean IP地址是否合法
     */
	public static boolean isIpAddress(String ipaddr) {  
		boolean flag = false;
		Pattern pattern = Pattern.compile("\\b((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\b");
		Matcher m = pattern.matcher(ipaddr);
		flag = m.matches();
		return flag;
    }  
}
