package com.pahaoche.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 正则表达式校验类
 * @author gzw
 *
 */
public class PatternUtil {

    /**
     * 
     * 具体校验方法
     * @param regex
     * @param str
     * @return
     */
    private static boolean match(String regex, String str) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }

    /**
     * 校验字符串为正整数首位非0字符串
     * @param str
     * @return
     */
    public static boolean IsIntNumber(String str) {
        String regex = "^\\+?[1-9][0-9]*$";
        return match(regex, str);
    }

    /**
     * 校验邮箱字符串
     * @param args
     */
    public static boolean IsEmail(String str) {
        String regex = "^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$";
        return match(regex, str);
    }

    public static void main(String[] args) {
        System.out.println(IsIntNumber("0500"));
    }

}
