/*
 *  @author 陈雨茂
 * 	@date 2014/03/31
 */
package com.pahaoche.member.entity.po;

import java.io.Serializable;
import java.util.Date;

/**
 * *
 * 
 * @note 用户信息.
 * 
 * @author chenyumao
 */
public class User implements Serializable {

	/**
	 * Instantiates a new user.
	 */
	public User() {
	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** 用户出生年月 */
	private String birthday;
	
	/** The login name. 登录用户名，一般就是手机号，但也可能不一致 */
	private String loginName;

	/** The name. 用户信息的名字 */
	private String name;

	/** The oldpassword. 旧密码，适用旧密码，修改成新密码功能 */
	private String oldpassword;

	/** The password. 密码 */
	private String password;

	/** The id. 编号 */
	private Long id;

	/** The mobile num. 用户手机号 */
	private String mobileNum;

	/** The mobile num for change password. 适用手机号修改密码 */
	private String mobileNumForChangePassword;

	/** The mobile check num. 手机验证码 */
	private String mobileCheckNum;

	/** The password vilidate. 二次输入确认密码 */
	private String passwordVilidate;

	/** The pic check. 图片验证 */
	private String picCheck;

	/** The email. 用户邮箱 */
	private String email;

	/** The before login time. 上次登录时间 */
	private Date beforeLoginTime;

	/** The sex. 性别 1:男 0:女 2:保密 */
	private String sex;

	/** The city. 城市 */
	private String city;

	/** The id card. 身份证 */
	private String idCard;

	/** The login type. 登录类型 */
	private Integer loginType;

	/** The uuid mo. 手机验证码唯一主键 */
	private String uuidMo;

	/** The uuid pic. 图片验证码唯一主键 */
	private String uuidPic;

	/** The mobileNumFormat. 手机号码的格式化 */
	private String mobileNumFormat;

	/** The province. 省份 */
	private String province;

	/** The province code. 省份code */
	private String provinceCode;

	/** The city code. 城市Code */
	private String cityCode;

	private String wltId; // 万里通ID

	private String tempUserFlag; // 临时账号标识

	private String source; // 来源

	private String memberType;// 万里通账号类型 10：正式，20：临时

	private String payPassword;// 支付密码

	// 个人图像
	private String personalImage;

	// 收货地址省份ID
	private String receiveProvinceId;

	// 收货地址省份名称
	private String receiveProvinceName;

	// 收货地址详情
	private String receiveDetail;

	// 诊所性质
	private String clinicProperty;

	// 诊疗类型
	private String treatmentType;

	// 其他诊疗类型
	private String treatmentTypeExtra;

	// 常居地-区ID
	private String areaId;

	// 常居地-区名称
	private String areaName;

	// 常居地-详情
	private String addressDetail;

	private String payPasswordVilidate;

	private Date createdDate;

	/** app调用时，非空，用于记录日志 */
	private String ipAddress;
	/** app调用时，非空，为true */
	private Boolean appFlg;

	// 是否是医生
	private int isDoctor;
	// 医生执业证书编号
	private String medicalLicenseNo;
	// 医生执业证书
	private String medicalLicensePath;
	// 医生资格证书编号
	private String medicalPracticingNo;
	// 医生资格证书编号
	private String medicalPracticingPath;
	// 医生图片路径
	private String doctorPhotoPath;
	// 医生姓名
	private String doctorName;
	// 注册用户类型
	private String userType;
	// 邀请者的用户ID
	private String invateUserId;
	// 注册Client, 参考IntegralClient.java
	private String clientType;

	public String getPayPasswordVilidate() {
		return payPasswordVilidate;
	}

	public void setPayPasswordVilidate(String payPasswordVilidate) {
		this.payPasswordVilidate = payPasswordVilidate;
	}

	public String getPayPassword() {
		return payPassword;
	}

	public void setPayPassword(String payPassword) {
		this.payPassword = payPassword;
	}

	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 * 
	 * @param name
	 *            the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the password.
	 * 
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 * 
	 * @param password
	 *            the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param id
	 *            the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Gets the mobile num.
	 * 
	 * @return the mobile num
	 */
	public String getMobileNum() {
		return mobileNum;
	}

	/**
	 * Sets the mobile num.
	 * 
	 * @param mobileNum
	 *            the new mobile num
	 */
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	/**
	 * Gets the mobile check num.
	 * 
	 * @return the mobile check num
	 */
	public String getMobileCheckNum() {
		return mobileCheckNum;
	}

	/**
	 * Sets the mobile check num.
	 * 
	 * @param mobileCheckNum
	 *            the new mobile check num
	 */
	public void setMobileCheckNum(String mobileCheckNum) {
		this.mobileCheckNum = mobileCheckNum;
	}

	/**
	 * Gets the password vilidate.
	 * 
	 * @return the password vilidate
	 */
	public String getPasswordVilidate() {
		return passwordVilidate;
	}

	/**
	 * Sets the password vilidate.
	 * 
	 * @param passwordVilidate
	 *            the new password vilidate
	 */
	public void setPasswordVilidate(String passwordVilidate) {
		this.passwordVilidate = passwordVilidate;
	}

	/**
	 * Gets the pic check.
	 * 
	 * @return the pic check
	 */
	public String getPicCheck() {
		return picCheck;
	}

	/**
	 * Sets the pic check.
	 * 
	 * @param picCheck
	 *            the new pic check
	 */
	public void setPicCheck(String picCheck) {
		this.picCheck = picCheck;
	}

	/**
	 * Gets the email.
	 * 
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 * 
	 * @param email
	 *            the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the before login time.
	 * 
	 * @return the before login time
	 */
	public Date getBeforeLoginTime() {
		return beforeLoginTime;
	}

	/**
	 * Sets the before login time.
	 * 
	 * @param beforeLoginTime
	 *            the new before login time
	 */
	public void setBeforeLoginTime(Date beforeLoginTime) {
		this.beforeLoginTime = beforeLoginTime;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	/**
	 * Gets the city.
	 * 
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the city.
	 * 
	 * @param city
	 *            the new city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the id card.
	 * 
	 * @return the id card
	 */
	public String getIdCard() {
		return idCard;
	}

	/**
	 * Sets the id card.
	 * 
	 * @param idCard
	 *            the new id card
	 */
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	/**
	 * Gets the login name.
	 * 
	 * @return the login name
	 */
	public String getLoginName() {
		return loginName;
	}

	/**
	 * Sets the login name.
	 * 
	 * @param loginName
	 *            the new login name
	 */
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	/**
	 * Gets the oldpassword.
	 * 
	 * @return the oldpassword
	 */
	public String getOldpassword() {
		return oldpassword;
	}

	/**
	 * Sets the oldpassword.
	 * 
	 * @param oldpassword
	 *            the new oldpassword
	 */
	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	/**
	 * Gets the login type.
	 * 
	 * @return the login type
	 */
	public Integer getLoginType() {
		return loginType;
	}

	/**
	 * Sets the login type.
	 * 
	 * @param loginType
	 *            the new login type
	 */
	public void setLoginType(Integer loginType) {
		this.loginType = loginType;
	}

	/**
	 * Gets the mobile num for change password.
	 * 
	 * @return the mobile num for change password
	 */
	public String getMobileNumForChangePassword() {
		return mobileNumForChangePassword;
	}

	/**
	 * Sets the mobile num for change password.
	 * 
	 * @param mobileNumForChangePassword
	 *            the new mobile num for change password
	 */
	public void setMobileNumForChangePassword(String mobileNumForChangePassword) {
		this.mobileNumForChangePassword = mobileNumForChangePassword;
	}

	/**
	 * Gets the uuid mo.
	 * 
	 * @return the uuid mo
	 */
	public String getUuidMo() {
		return uuidMo;
	}

	/**
	 * Sets the uuid mo.
	 * 
	 * @param uuidMo
	 *            the new uuid mo
	 */
	public void setUuidMo(String uuidMo) {
		this.uuidMo = uuidMo;
	}

	/**
	 * Gets the uuid pic.
	 * 
	 * @return the uuid pic
	 */
	public String getUuidPic() {
		return uuidPic;
	}

	/**
	 * Sets the uuid pic.
	 * 
	 * @param uuidPic
	 *            the new uuid pic
	 */
	public void setUuidPic(String uuidPic) {
		this.uuidPic = uuidPic;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "User [loginName=" + loginName + "]";
	}

	/**
	 * Gets the mobile num format.
	 * 
	 * @return the mobile num format
	 */
	public String getMobileNumFormat() {
		if (this.mobileNum != null && this.mobileNum.length() > 9)
			return this.mobileNum.substring(0, 3) + "*****" + this.mobileNum.substring(8);
		else
			return this.mobileNum;
	}

	/**
	 * Gets the provice.
	 * 
	 * @return the provice
	 */
	public String getProvince() {
		return province;
	}

	/**
	 * Sets the provice.
	 * 
	 * @param provice
	 *            the new provice
	 */
	public void setProvince(String province) {
		this.province = province;
	}

	/**
	 * Gets the provice code.
	 * 
	 * @return the provice code
	 */
	public String getProvinceCode() {
		return provinceCode;
	}

	/**
	 * Sets the provice code.
	 * 
	 * @param proviceCode
	 *            the new provice code
	 */
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}

	/**
	 * Gets the city code.
	 * 
	 * @return the city code
	 */
	public String getCityCode() {
		return cityCode;
	}

	/**
	 * Sets the city code.
	 * 
	 * @param cityCode
	 *            the new city code
	 */
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getWltId() {
		return wltId;
	}

	public void setWltId(String wltId) {
		this.wltId = wltId;
	}

	public String getTempUserFlag() {
		return tempUserFlag;
	}

	public void setTempUserFlag(String tempUserFlag) {
		this.tempUserFlag = tempUserFlag;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public String getPersonalImage() {
		return personalImage;
	}

	public void setPersonalImage(String personalImage) {
		this.personalImage = personalImage;
	}

	public String getReceiveProvinceId() {
		return receiveProvinceId;
	}

	public void setReceiveProvinceId(String receiveProvinceId) {
		this.receiveProvinceId = receiveProvinceId;
	}

	public String getReceiveProvinceName() {
		return receiveProvinceName;
	}

	public void setReceiveProvinceName(String receiveProvinceName) {
		this.receiveProvinceName = receiveProvinceName;
	}

	public String getReceiveDetail() {
		return receiveDetail;
	}

	public void setReceiveDetail(String receiveDetail) {
		this.receiveDetail = receiveDetail;
	}

	public String getClinicProperty() {
		return clinicProperty;
	}

	public void setClinicProperty(String clinicProperty) {
		this.clinicProperty = clinicProperty;
	}

	public String getTreatmentType() {
		return treatmentType;
	}

	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}

	public String getTreatmentTypeExtra() {
		return treatmentTypeExtra;
	}

	public void setTreatmentTypeExtra(String treatmentTypeExtra) {
		this.treatmentTypeExtra = treatmentTypeExtra;
	}

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId = areaId;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getAddressDetail() {
		return addressDetail;
	}

	public void setAddressDetail(String addressDetail) {
		this.addressDetail = addressDetail;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Boolean getAppFlg() {
		return appFlg;
	}

	public void setAppFlg(Boolean appFlg) {
		this.appFlg = appFlg;
	}

	public int isDoctor() {
		return isDoctor;
	}

	public void setDoctor(int isDoctor) {
		this.isDoctor = isDoctor;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getMedicalLicenseNo() {
		return medicalLicenseNo;
	}

	public void setMedicalLicenseNo(String medicalLicenseNo) {
		this.medicalLicenseNo = medicalLicenseNo;
	}

	public String getMedicalLicensePath() {
		return medicalLicensePath;
	}

	public void setMedicalLicensePath(String medicalLicensePath) {
		this.medicalLicensePath = medicalLicensePath;
	}

	public String getMedicalPracticingNo() {
		return medicalPracticingNo;
	}

	public void setMedicalPracticingNo(String medicalPracticingNo) {
		this.medicalPracticingNo = medicalPracticingNo;
	}

	public String getMedicalPracticingPath() {
		return medicalPracticingPath;
	}

	public void setMedicalPracticingPath(String medicalPracticingPath) {
		this.medicalPracticingPath = medicalPracticingPath;
	}

	public String getDoctorPhotoPath() {
		return doctorPhotoPath;
	}

	public void setDoctorPhotoPath(String doctorPhotoPath) {
		this.doctorPhotoPath = doctorPhotoPath;
	}

	public void setMobileNumFormat(String mobileNumFormat) {
		this.mobileNumFormat = mobileNumFormat;
	}

	public String getInvateUserId() {
		return invateUserId;
	}

	public void setInvateUserId(String invateUserId) {
		this.invateUserId = invateUserId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getClientType() {
		return clientType;
	}

	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
}
