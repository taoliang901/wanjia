/*
 *  @author 陈雨茂
 * 	@date 2014/03/31
 */
package com.pahaoche.member.entity.po;

import java.io.Serializable;
/**
 * *
 * 发布车辆信息.
 *
 * @author chenyumao
 */
public class Vehicle  implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The id. 编号  */
	private Long id;
	
	/** The photo url. 图片URL */
	private String photoUrl;
	
	/** The carmodel. 品牌车型 */
	private String carmodel;
	
	/** The carmake. 品牌车系 */
	private String carmake;
	
	/** The cartrim. 品牌车系 */
	private String cartrim;
	
	/** The exchange id. 交易号 */
	private String exchangeID;
	
	/** The high price. 出价 */
	private String highPrice;
	
	/** The loc. 归属地 */
	private String loc;
	
	/** The publish date. 发布时间 */
	private String publishDate;
	
	/** The status. 状态*/
	private String status;
	
	/** The status. 行驶里程*/
	private String gearmiles;
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * Gets the photo url.
	 *
	 * @return the photo url
	 */
	public String getPhotoUrl() {
		return photoUrl;
	}
	
	/**
	 * Sets the photo url.
	 *
	 * @param photoUrl the new photo url
	 */
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	
	/**
	 * Gets the carmodel.
	 *
	 * @return the carmodel
	 */
	public String getCarmodel() {
		return carmodel;
	}
	
	/**
	 * Sets the carmodel.
	 *
	 * @param carmodel the new carmodel
	 */
	public void setCarmodel(String carmodel) {
		this.carmodel = carmodel;
	}
	
	/**
	 * Gets the exchange id.
	 *
	 * @return the exchange id
	 */
	public String getExchangeID() {
		return exchangeID;
	}
	
	/**
	 * Sets the exchange id.
	 *
	 * @param exchangeID the new exchange id
	 */
	public void setExchangeID(String exchangeID) {
		this.exchangeID = exchangeID;
	}
	
	/**
	 * Gets the high price.
	 *
	 * @return the high price
	 */
	public String getHighPrice() {
		return highPrice;
	}
	
	/**
	 * Sets the high price.
	 *
	 * @param highPrice the new high price
	 */
	public void setHighPrice(String highPrice) {
		this.highPrice = highPrice;
	}
	
	/**
	 * Gets the loc.
	 *
	 * @return the loc
	 */
	public String getLoc() {
		return loc;
	}
	
	/**
	 * Sets the loc.
	 *
	 * @param loc the new loc
	 */
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
	/**
	 * Gets the publish date.
	 *
	 * @return the publish date
	 */
	public String getPublishDate() {
		return publishDate;
	}
	
	/**
	 * Sets the publish date.
	 *
	 * @param publishDate the new publish date
	 */
	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the gearmiles.
	 *
	 * @return the gearmiles
	 */
	public String getGearmiles() {
		return gearmiles;
	}

	/**
	 * Sets the gearmiles.
	 *
	 * @param gearmiles the new gearmiles
	 */
	public void setGearmiles(String gearmiles) {
		this.gearmiles = gearmiles;
	}

	public String getCarmake() {
		return carmake;
	}

	public void setCarmake(String carmake) {
		this.carmake = carmake;
	}

	public String getCartrim() {
		return cartrim;
	}

	public void setCartrim(String cartrim) {
		this.cartrim = cartrim;
	}
}
