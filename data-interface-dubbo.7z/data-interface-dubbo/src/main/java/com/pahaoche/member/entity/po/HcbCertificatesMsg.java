package com.pahaoche.member.entity.po;

/**
 * 好车宝注册开户使用证件信息bean
 * @author EX-LVLIANGHUA600
 *
 */
public class HcbCertificatesMsg {

    private Integer id;

    private Integer userId;

    private String  certificatesType; //证件类型

    private String  certificatesNum; //证件号

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getCertificatesType() {
        return certificatesType;
    }

    public void setCertificatesType(String certificatesType) {
        this.certificatesType = certificatesType;
    }

    public String getCertificatesNum() {
        return certificatesNum;
    }

    public void setCertificatesNum(String certificatesNum) {
        this.certificatesNum = certificatesNum;
    }

}
