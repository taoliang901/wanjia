/*
 *  @author 陈雨茂
 * 	@date 2014/03/31
 */
package com.pahaoche.member.entity.po;

import java.io.Serializable;

/**
 * The Class VerificationCode. 验证码
 */
public class VerificationCode  implements Serializable{
	
	/** The checktype mobile. */
	public static String CHECKTYPE_MOBILE="2";
	
	/** The CHECKTYP e_ pic. */
	public static String CHECKTYPE_Pic="1";
	
	/** The smstempid register. */
	public static String SMSTEMPID_REGISTER="1";
	
	/** The smstempid login. */
	public static String SMSTEMPID_LOGIN="2";
	
	/** The smstempid resetpassword. */
	public static String SMSTEMPID_RESETPWD="3";
	
	/** The smstempid extend. */
	public static String SMSTEMPID_EXTEND="4";
	/** The smstempid extend. */
	public static String SMSTEMPID_HCB="5";
	
	/** The channelnum. */
	public static String CHANNELNUM="WZ";
	/**
	 * Instantiates a new verification code.
	 */
	public VerificationCode() {
		super();
	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The checktype.  验证码类型1：图片验证码/2：手机验证码 */
	private String checkType	;
	
	/** The mobile num. 如果是手机验证码：手机号码*/
	private String mobileNum	;
	
	/** The sms temp id. 手机发送内容 1：注册    2：登录   3：重置密码 */
	private String smsTempId	;
	
	/** The channel num. 渠道号 */
	private String channelNum;
	
	/** The uuid. */
	private String uuid;
	
	/** The check value. */
	private String checkValue;
	/** The Source IP. */
	private String sourceIP;
	/**
	 * Gets the checkType.
	 *
	 * @return the checkType
	 */
	public String getCheckType() {
		return checkType;
	}
	
	/**
	 * Sets the check tpye.
	 *
	 * @param checkType the new check type
	 */
	public void setCheckType(String checkType) {
		this.checkType = checkType;
	}
	
	/**
	 * Gets the mobile num.
	 *
	 * @return the mobile num
	 */
	public String getMobileNum() {
		return mobileNum;
	}
	
	/**
	 * Sets the mobile num.
	 *
	 * @param mobileNum the new mobile num
	 */
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	
	/**
	 * Gets the sms temp id.
	 *
	 * @return the sms temp id
	 */
	public String getSmsTempId() {
		return smsTempId;
	}
	
	/**
	 * Sets the sms temp id.
	 *
	 * @param smsTempId the new sms temp id
	 */
	public void setSmsTempId(String smsTempId) {
		this.smsTempId = smsTempId;
	}
	
	/**
	 * Gets the channel num.
	 *
	 * @return the channel num
	 */
	public String getChannelNum() {
		return channelNum;
	}
	
	/**
	 * Sets the channel num.
	 *
	 * @param channelNum the new channel num
	 */
	public void setChannelNum(String channelNum) {
		this.channelNum = channelNum;
	}
	
	/**
	 * Gets the uuid.
	 *
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}
	
	/**
	 * Sets the uuid.
	 *
	 * @param uuid the new uuid
	 */
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	/**
	 * Gets the check value.
	 *
	 * @return the check value
	 */
	public String getCheckValue() {
		return checkValue;
	}
	
	/**
	 * Sets the check value.
	 *
	 * @param checkValue the new check value
	 */
	public void setCheckValue(String checkValue) {
		this.checkValue = checkValue;
	}

	/**
	 * @return the sourceIP
	 */
	public String getSourceIP() {
		return sourceIP;
	}

	/**
	 * @param sourceIP the sourceIP to set
	 */
	public void setSourceIP(String sourceIP) {
		this.sourceIP = sourceIP;
	}
	
	
}	
