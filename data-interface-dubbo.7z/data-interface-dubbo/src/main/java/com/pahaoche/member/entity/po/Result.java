/*
 *  @author 陈雨茂
 * 	@date 2014/03/31
 */
package com.pahaoche.member.entity.po;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import com.pahaoche.wg.base.database.entity.po.HyUserinfoExtra;

// TODO: Auto-generated Javadoc
/**
 * 接口返回对象
 * The Class Result.
 */
public class Result implements Serializable {

    /** The result success. */
    public static String       RESULT_SUCCESS           = "0001";

    /** The result paramerror. */
    public static String       RESULT_PARAMERROR        = "1000";

    /** The result interfaceerrormsg. */
    public static String       RESULT_INTERFACEERRORMSG = "0002";

    /** The result RESULT_USEREXIST. */
    public static String       RESULT_USEREXIST         = "0003";

    /** The result RESULT_USERNOTEXIST. */
    public static String       RESULT_USERNOTEXIST      = "0004";

    /** The result interfacexception. */
    public static String       RESULT_INTERFACEXCEPTION = "2000";

    /** The result RESULT_PASSWORDNOTEXIST. */
    public static String       RESULT_PWDNOTEXIST       = "0005";

    /** The result RESULT_PASSWORDNOTEXIST. */
    public static String       RESULT_PWDERROR          = "0006";

    /** The result RESULT_TOOMUCHTIME. */
    public static String       RESULT_TOOMUCHTIME       = "0007";

    /** The result RESULT_TOOMUCHTIME. */
    public static String       RESULT_HOURTOOMUCHTIME   = "0008";
    
    /** The result RESULT_USER_EXPERIED. */
    public static String       RESULT_USER_EXPERIED   = "0009";
    
    /** 用户名密码已过期. */
    public static String       RESULT_PWD_EXPERIED   = "0010";
    
    /** 用户名密码已被数据库管理员重置. */
    public static String       RESULT_PWD_INITED_BY_DB   = "0011";
    
    /** 用户名密码已被被管理员重置. */
    public static String       RESULT_PWD_INITED_BY_ADMIN   = "0012";
    
    /** 用户名密码是常用的简单密码. */
    public static String       RESULT_PWD_IS_TOO_SIMPLE   = "0013";

    /** The result ACCOUNT_LOCKED.（临时锁定：提示2小时后解锁） */
    public static String       ACCOUNT_LOCKED           = "412";

    /** The result ACCOUNT_LOCKED_FOREVER.（永久锁定） */
    public static String       ACCOUNT_LOCKED_FOREVER   = "468";
    
    /** UM认证失败  */
    public static String       UM_AUTH_FAILED   = "469";

    /** The Constant serialVersionUID. */
    private static final long  serialVersionUID         = 1L;

    /** The code. 返回编码*/
    private String             code;

    /** The message. 返回文字描述*/
    private String             message;

    /** The user. 返回USER信息*/
    private User               user;

    /** The VerificationCode. 验证码*/
    private VerificationCode   verificationCode;

    /** The vehicles. 发布车辆集合*/
    private List<Vehicle>      vehicles                 = Collections.EMPTY_LIST;

    /** The regions. 城市列表，默认1 返回所有的省，其他的，返回对应省的城市*/
    private List<Region>       regions                  = Collections.EMPTY_LIST;

    /** The regions. 万里通返回数据*/
    private String             wltReturn;

    /** The regions. 验证失败次数*/
    private String             checkFailCount;

	/** The user. 返回额外USER信息 */
	private HyUserinfoExtra hyUserinfoExtra;
    
    /**
     * 返回好车宝开户证件信息
     */
    private HcbCertificatesMsg certificatesMsg;

    public String getCheckFailCount() {
        return checkFailCount;
    }

    public void setCheckFailCount(String checkFailCount) {
        this.checkFailCount = checkFailCount;
    }

    /**
     * Instantiates a new result.
     */
    public Result() {

    }

    /**
     * Instantiates a new result.
     *
     * @param code the code
     * @param message the message
     */
    public Result(String code, String message) {
        super();
        this.code = code;
        this.message = message;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the message.
     *
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Gets the user.
     *
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user.
     *
     * @param user the new user
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * Gets the vehicles.
     *
     * @return the vehicles
     */
    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    /**
     * Sets the vehicles.
     *
     * @param vehicles the new vehicles
     */
    public void setVehicles(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }

    /**
     * Gets the verification code.
     *
     * @return the verification code
     */
    public VerificationCode getVerificationCode() {
        return verificationCode;
    }

    /**
     * Sets the verification code.
     *
     * @param verificationCode the new verification code
     */
    public void setVerificationCode(VerificationCode verificationCode) {
        this.verificationCode = verificationCode;
    }

    /**
     * Gets the regions.
     *
     * @return the regions
     */
    public List<Region> getRegions() {
        return regions;
    }

    /**
     * Sets the regions.
     *
     * @param regions the new regions
     */
    public void setRegions(List<Region> regions) {
        this.regions = regions;
    }

    public String getWltReturn() {
        return wltReturn;
    }

    public void setWltReturn(String wltReturn) {
        this.wltReturn = wltReturn;
    }

    public HcbCertificatesMsg getCertificatesMsg() {
        return certificatesMsg;
    }

    public void setCertificatesMsg(HcbCertificatesMsg certificatesMsg) {
        this.certificatesMsg = certificatesMsg;
    }

	public HyUserinfoExtra getHyUserinfoExtra() {
		return hyUserinfoExtra;
	}

	public void setHyUserinfoExtra(HyUserinfoExtra hyUserinfoExtra) {
		this.hyUserinfoExtra = hyUserinfoExtra;
	}
}
