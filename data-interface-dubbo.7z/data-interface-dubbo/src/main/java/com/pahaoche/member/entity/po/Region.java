package com.pahaoche.member.entity.po;

/*********************************************************************************
//* Copyright (C) 2014 Pingan Haoche (PAHAOCHE). All Rights Reserved.
//*
//* Filename:      Region.java
//* Revision:      1.0
//* Author:        chenyumao
//* Created On:    2014年4月2日
//* Modified by:   
//* Modified On:   
//*
//* Description:   <description>
/********************************************************************************/

/**
 * @Description 省，城市
 * @author chenyumao
 * 
 */
public class Region {

    //行政区划id
    private String regionId;
    //行政区划代码
    private String  regionCode;
    //行政区划名称
    private String  regionName;
    //父行政区划
    private String parentId;
    //层级
    private String regionLevel;
    //排序，用来调整顺序
    private String regionOrder;
    //行政区划英文名称
    private String  regionNameEn;
    //行政区划简称
    private String  regionShortnameEn;

    /**
     * @return the regionId
     */
    public String getRegionId() {
        return regionId;
    }

    /**
     * @param regionId the regionId to set
     */
    public void setRegionId(String regionId) {
        this.regionId = regionId;
    }

    /**
     * @return the regionCode
     */
    public String getRegionCode() {
        return regionCode;
    }

    /**
     * @param regionCode the regionCode to set
     */
    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    /**
     * @return the regionName
     */
    public String getRegionName() {
        return regionName;
    }

    /**
     * @param regionName the regionName to set
     */
    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    /**
     * @return the parentId
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * @param parentId the parentId to set
     */
    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    /**
     * @return the regionLevel
     */
    public String getRegionLevel() {
        return regionLevel;
    }

    /**
     * @param regionLevel the regionLevel to set
     */
    public void setRegionLevel(String regionLevel) {
        this.regionLevel = regionLevel;
    }

    /**
     * @return the regionOrder
     */
    public String getRegionOrder() {
        return regionOrder;
    }

    /**
     * @param regionOrder the regionOrder to set
     */
    public void setRegionOrder(String regionOrder) {
        this.regionOrder = regionOrder;
    }

    /**
     * @return the regionNameEn
     */
    public String getRegionNameEn() {
        return regionNameEn;
    }

    /**
     * @param regionNameEn the regionNameEn to set
     */
    public void setRegionNameEn(String regionNameEn) {
        this.regionNameEn = regionNameEn;
    }

    /**
     * @return the regionShortnameEn
     */
    public String getRegionShortnameEn() {
        return regionShortnameEn;
    }

    /**
     * @param regionShortnameEn the regionShortnameEn to set
     */
    public void setRegionShortnameEn(String regionShortnameEn) {
        this.regionShortnameEn = regionShortnameEn;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Region [regionId=" + regionId + ", regionCode=" + regionCode + ", regionName=" + regionName + ", parentId=" + parentId + ", regionLevel=" + regionLevel + ", regionOrder=" + regionOrder + ", regionNameEn=" + regionNameEn + ", regionShortnameEn=" + regionShortnameEn + "]";
    }
}
