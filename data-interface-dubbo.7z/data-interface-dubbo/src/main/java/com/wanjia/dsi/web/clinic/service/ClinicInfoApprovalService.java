package com.wanjia.dsi.web.clinic.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.clinic.model.ClinicInfoApproval;

/**
 * 
 * ClinicInfoApprovalService
 * 
 * @author LUOXIAOJUN640
 *
 */
public interface ClinicInfoApprovalService extends IBaseService<ClinicInfoApproval, String> {
	
	List<ClinicInfoApproval> findByProperties(Map<String, Object> map);
	/**
	 * 通过诊所idlist查询诊所 (深圳调用接口)
	 * @param ClinicIdList 诊所id的list
	 * @return
	 */
	public JsonResponse<Map<String,String>> getClinicFacadeList(List<String> clinicIdList);
	
	/**
	 * 通过诊所idlist查询诊所 
	 * @param ClinicId 诊所id的list
	 * 
	 * @return
	 */
	public JsonResponse<ClinicInfoApproval> getClinicInfoApprovalById(String clinicId);
	
}