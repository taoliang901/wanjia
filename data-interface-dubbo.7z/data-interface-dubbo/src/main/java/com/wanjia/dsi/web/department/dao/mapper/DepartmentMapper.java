package com.wanjia.dsi.web.department.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.department.model.Department;

public interface DepartmentMapper extends IBaseDao {
	public List<Department> findDepartmentByIds(List<String> id);

	public List<Department> getDepartmentList(Department department);

	public List<Department> findInCmsDepartMent(Department department);

	public List<Department> getDepartmentListbByTime(Map<String, Object> map);

}