package com.wanjia.dsi.web.cms.activity.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.model.CmsActivity;


public interface CmsActivityService {
	
	/**
	 * 通过页面配置id查询页面活动列表
	 * @param pageConfigId 必填
	 * @param imagetype 图像分辨率 必填
	 * @return
	 */
	public JsonResponse<List<CmsActivity>> findByPageConfigId(String pageConfigId,String imagetype);

}