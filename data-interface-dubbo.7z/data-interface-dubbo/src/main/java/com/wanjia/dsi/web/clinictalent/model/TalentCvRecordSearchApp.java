package com.wanjia.dsi.web.clinictalent.model;

import java.io.Serializable;

public class TalentCvRecordSearchApp implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	
	private String talentCvId;
	
	private String talentJobId;
    
    private String memberId;
    
    private String intentionJob;

    private String intentionJobName;

    private String rank;

    private String rankName;
    
    private String jobName;

    private String jobRemark;

    private String memberName;
    
    private String systemTime;
    
    private String createDate;
    
    private String modifyDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getIntentionJob() {
		return intentionJob;
	}

	public void setIntentionJob(String intentionJob) {
		this.intentionJob = intentionJob;
	}

	public String getIntentionJobName() {
		return intentionJobName;
	}

	public void setIntentionJobName(String intentionJobName) {
		this.intentionJobName = intentionJobName;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getRankName() {
		return rankName;
	}

	public void setRankName(String rankName) {
		this.rankName = rankName;
	}

	public String getJobRemark() {
		return jobRemark;
	}

	public void setJobRemark(String jobRemark) {
		this.jobRemark = jobRemark;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getSystemTime() {
		return systemTime;
	}

	public void setSystemTime(String systemTime) {
		this.systemTime = systemTime;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getTalentCvId() {
		return talentCvId;
	}

	public void setTalentCvId(String talentCvId) {
		this.talentCvId = talentCvId;
	}

	public String getTalentJobId() {
		return talentJobId;
	}

	public void setTalentJobId(String talentJobId) {
		this.talentJobId = talentJobId;
	}
    

    
    
    
    
    
}
