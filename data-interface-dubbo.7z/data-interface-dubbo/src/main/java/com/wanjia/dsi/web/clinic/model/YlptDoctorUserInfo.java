package com.wanjia.dsi.web.clinic.model;

public class YlptDoctorUserInfo {
	private String userName;		//用户名
	private String mobile;			//手机号
	private String sex;				//性别
	private String birthday;		//生日
	private String email;			//邮箱
	private String doctorName;		//医生姓名
	private String casUuid;
	private String id;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getCasUuid() {
		return casUuid;
	}
	public void setCasUuid(String casUuid) {
		this.casUuid = casUuid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "YlptDoctorUserInfo [userName=" + userName + ", mobile=" + mobile + ", sex=" + sex + ", birthday="
				+ birthday + ", email=" + email + ", doctorName=" + doctorName + "]";
	}
	
	
	
}
