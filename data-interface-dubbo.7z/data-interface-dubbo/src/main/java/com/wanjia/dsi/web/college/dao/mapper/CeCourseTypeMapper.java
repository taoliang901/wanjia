package com.wanjia.dsi.web.college.dao.mapper;

import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.college.model.CeCourseType;

public interface CeCourseTypeMapper extends IBaseDao {
	public List<CeCourseType> findAllCeCourseType();
}
