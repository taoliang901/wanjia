package com.wanjia.dsi.web.rz.util;

/**
 * 审核状态枚举
 * 
 * @author LUOXIAOJUN640
 *
 */
public enum RzStatus {

	PLAN_RZ("已预认证", "01"), TO_BE_RZ("初评待认证", "02"), IN_RZ("初评认证中", "03"), IN_AUDIT("初评审核中", "04"), AUDIT_FINISHED("初评审核完成",
			"05"), ALREADY_SIGN_UP("初评已报名", "07"), REVIEW_PASS("初评报名通过", "08"), REVIEW_FAILED("初评报名驳回", "09");

	private String code;
	private String value;

	public static RzStatus getInstance(String value) {
		RzStatus rzStatus = null;
		
		if(value != null){ 
			RzStatus[] list = RzStatus.values();
			for(RzStatus status : list){
				if(status.getValue().equals(value)){
					rzStatus = status;
					break;
				}
			}
		}
		
		return rzStatus;
	}
	
	private RzStatus(String code, String value) {
		this.code = code;
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
