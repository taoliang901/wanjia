package com.wanjia.dsi.web.hyPerson.service;

import java.util.List;

import com.wanjia.dsi.web.hyPerson.model.CasUserRole;

/**
 * 
 * 统一会员角色相关接口
 * 
 * @author LUOXIAOJUN640
 *
 */
public interface CasUserRoleService {

	List<CasUserRole> findByUserId(String userId);
}
