package com.wanjia.dsi.web.hyPerson.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.CasUser;
import com.wanjia.dsi.web.hyPerson.util.CasEncrypt;
import com.wanjia.dsi.web.hyPerson.util.RegisterSource;

/**
 * 
 * 统一会员相关接口
 * 
 * UBC：User Business Center
 * 
 * @author LUOXIAOJUN640
 *
 */
public interface CasUserService {

	/**
	 * 统一会员注册接口（20160728版本）:<br>
	 * 
	 * 1. 如需通过UBC进行SSO登录，各子系统必须在用户注册时，同时在UBC中心进行注册登记<br>
	 * 2. 手机号注册时，如果用户名为空，手机号将作为默认用户名进行填充<br>
	 * 3. 用户名、手机号必须唯一，如果多个子系统之间使用同一手机号或者用户名进行注册，UBC以角色区分各个系统用户，<br>
	 * 	     子系统角色定义请参考<code>com.wanjia.dsi.web.hyPerson.util.UserRoleKey</code> <br>
	 * 4. 具体注册场景请参考UBC注册场景<br>
	 *    svn://172.19.21.212/wanjia/doc/会员+外部SSO/20160728版本（财务、医生会员）/02设计/UBC中心用户注册场景.png<br>
	 * 
	 * @param casUser
	 * 1. 用户名字段(loginName)、手机号字段(mobile)必须二存一<br>
	 * 2. 字段createUser不能为空 <br>
	 * 3. 字段roleKey不能为空<br>
	 * 4. 手机号必须满足手机规范<br>
	 * 5. 用户密码必须是6~16位数字与字母的组合，默认将对其进行MD5加密<br>
	 * 6. 用户名不能为当前注册手机号之外的纯数字号码 <br>
	 * 
	 * @return 
	 * 1. 创建成功，返回用户ID<br>
	 * 2. 创建失败，具体errorCode定义请参考 <code>com.wanjia.dsi.web.hyPerson.util.ErrorCode</code><br>
	 * 
	 */
	JsonResponse<String> register(CasUser casUser);
	
	/**
	 * 始终注册一个新用户，如果用户与存在，返回注册失败（20160812版本），具体描述请参考<code>register(CasUser casUser)</code>
	 * 
	 * 
	 * @param casUser
	 * 1. 用户ID不能为空
	 * 2. 用户名字段(loginName)、手机号字段(mobile)必须二存一<br>
	 * 3. 字段createUser不能为空 <br>
	 * 4. 字段roleKey不能为空<br>
	 * 5. 手机号必须满足手机规范<br>
	 * 6. 用户密码必须是6~16位数字与字母的组合，默认将对其进行MD5加密<br>
	 * 7. 用户名不能为当前注册手机号之外的纯数字号码 <br>
	 * 
	 * @return
	 */
	JsonResponse<String> registerNew(CasUser casUser);
	
	/**
	 * 始终注册一个新用户，如果用户与存在，返回注册失败（20160812版本），具体描述请参考<code>register(CasUser casUser, CasEncrypt encrypt)</code>
	 * 
	 * 
	 * @param casUser
	 * 1. 用户ID不能为空
	 * 2. 用户名字段(loginName)、手机号字段(mobile)必须二存一<br>
	 * 3. 字段createUser不能为空 <br>
	 * 4. 字段roleKey不能为空<br>
	 * 5. 手机号必须满足手机规范<br>
	 * 6. 用户密码必须是6~16位数字与字母的组合，默认将对其进行MD5加密<br>
	 * 7. 用户名不能为当前注册手机号之外的纯数字号码 <br>
	 * 
	 * @return
	 */
	JsonResponse<String> registerNew(CasUser casUser, CasEncrypt encrypt);
	
	/**
	 * 统一会员注册接口（20160728版本），具体描述请参考<code>register(CasUser casUser)</code>
	 * 
	 * @param casUser
	 * 1. 用户名字段(loginName)、手机号字段(mobile)必须二存一<br>
	 * 2. 字段createUser不能为空 <br>
	 * 3. 字段roleKey不能为空<br>
	 * 4. 手机号必须满足手机规范<br>
	 * 5. 用户密码必须是6~16位数字与字母的组合，默认将对其进行MD5加密<br>
	 * 6. 用户名不能为当前注册手机号之外的纯数字号码 <br>
	 * 
	 * @param CasEncrypt 系统密码字段加密方式，目前只支持MD5加密
	 * 1. CasEncrypt.NONE, 表示CAS将不再对密码字段进行任何加密
	 * 2. CasEncrypt.MD5, 表示CAS将对密码字段进行MD5加密
	 * 
	 * @return 
	 * 1. 创建成功，返回用户ID<br>
	 * 2. 创建失败，具体errorCode定义请参考 <code>com.wanjia.dsi.web.hyPerson.util.ErrorCode</code><br>
	 * 
	 */
	JsonResponse<String> register(CasUser casUser, CasEncrypt encrypt);
	
	/**
	 * 统一会员注册接口（20160728版本），具体描述请参考<code>register(CasUser casUser)</code>
	 * 
	 * @param casUser
	 * 1. 用户名字段(loginName)、手机号字段(mobile)必须二存一<br>
	 * 2. 字段createUser不能为空 <br>
	 * 3. 字段roleKey不能为空<br>
	 * 4. 手机号必须满足手机规范<br>
	 * 5. 用户密码必须是6~16位数字与字母的组合，默认将对其进行MD5加密<br>
	 * 6. 用户名不能为当前注册手机号之外的纯数字号码 <br>
	 * 
	 * @param CasEncrypt 系统密码字段加密方式，目前只支持MD5加密
	 * 1. CasEncrypt.NONE, 表示CAS将不再对密码字段进行任何加密
	 * 2. CasEncrypt.MD5, 表示CAS将对密码字段进行MD5加密
	 * 
	 * @param RegisterSource 用户注册来源
	 * 1. RegisterSource.PORTAL, 前台门户网站
	 * 2. RegisterSource.MEDICAL, 医疗平台
	 * 3. RegisterSource.CLINIC, 诊所中心
	 * 
	 * @return 
	 * 1. 创建成功，返回用户ID<br>
	 * 2. 创建失败，具体errorCode定义请参考 <code>com.wanjia.dsi.web.hyPerson.util.ErrorCode</code><br>
	 * 
	 */
	JsonResponse<String> register(CasUser casUser, CasEncrypt encrypt, RegisterSource source);

	/**
	 * 通过手机号注册
	 * 
	 * @param casUser
	 * @return 会用用户ID
	 */
	JsonResponse<Long> registerHyByMobile(String mobile, RegisterSource source);
	
	/**
	 * 通过用户ID更新用户名、用户手机号、用户密码（20160728版本）<br>
	 * 
	 * @param ID不能为空，必须为已在UBC中心注册的用户ID<br>
	 * @param loginName 需更新的用户名，不能为纯数字号码，且系统唯一，当参数为空串或者null时，接口将不做更新操作<br>
	 * @param mobile 需更新的手机号，必须符合手机号规范，且系统唯一，当参数为空串或者null时，接口将不做更新操作<br>
	 * @param newPassword 需更新的用户密码，必须符合系统密码规范（6~16位数字与字母组合），当参数为空串或者null时，接口将不做更新操作，默认将对其进行MD5加密<br>
	 * 
	 * @return
	 * 具体errorCode定义请参考<code> com.wanjia.dsi.web.hyPerson.util.ErrorCode</code>
	 * 
	 */
	JsonResponse<String> update(String id, String loginName, String mobile, String newPassword);

	/**
	 * 通过用户ID更新用户名、用户手机号、用户密码（20160728版本）, <br>
	 * 具体定义请参考<code>update(String id, String loginName, String mobile, String newPassword)</code><br>
	 * 
	 * @param CasEncrypt 系统密码字段加密方式，目前只支持MD5加密
	 * 1. CasEncrypt.NONE, 表示CAS将不再对密码字段进行任何加密
	 * 2. CasEncrypt.MD5, 表示CAS将对密码字段进行MD5加密
	 * 
	 * @return
	 */
	JsonResponse<String> update(String id, String loginName, String mobile, String newPassword, CasEncrypt encrypt);
	
	/**
	 * 通过用户ID更新用户对象，如属性字段为空串或者null时，将不做更新（20160728版本）
	 * 
	 * @param casUser 
	 * 1. ID不能为空且必须为已在UBC中心注册的用户ID<br>
	 * 2. loginName 需更新的用户名，不能为纯数字号码，且系统唯一，当参数为空串或者null时，接口将不做更新操作<br>
	 * 3. mobile 需更新的手机号，必须符合手机号规范，且系统唯一，当参数为空串或者null时，接口将不做更新操作<br>
	 * 4. newPassword 需更新的用户密码，必须符合系统密码规范（6~16位数字与字母组合），当参数为空串或者null时，接口将不做更新操作，默认将对其进行MD5加密<br>
	 * 5. 更新操作时，createDate、createUser、delFlag、status字段将不做更新<br>
	 * 6. 更新操作时，不能用于更新角色信息（即设置roleKey将无效） <br>
	 *  
	 * @return
	 * 具体errorCode定义请参考 <code>com.wanjia.dsi.web.hyPerson.util.ErrorCode</code>
	 * 
	 */
	JsonResponse<String> update(CasUser casUser);
	
	/**
	 * 通过用户ID更新用户名、用户手机号、用户密码（20160728版本）, <br>
	 * 具体定义请参考<code>update(CasUser casUser)</code><br>
	 * 
	 * @param CasEncrypt 系统密码字段加密方式，目前只支持MD5加密
	 * 1. CasEncrypt.NONE, 表示CAS将不再对密码字段进行任何加密
	 * 2. CasEncrypt.MD5, 表示CAS将对密码字段进行MD5加密
	 * 
	 * @return
	 */
	JsonResponse<String> update(CasUser casUser, CasEncrypt encrypt);
	
	
	/**
	 * 通过用户ID更新用户名、用户手机号、用户密码（20160907版本）, <br>
	 * 具体定义请参考<code>update(CasUser casUser)</code><br>
	 * 
	 * @param CasEncrypt 系统密码字段加密方式，目前只支持MD5加密
	 * 1. CasEncrypt.NONE, 表示CAS将不再对密码字段进行任何加密
	 * 2. CasEncrypt.MD5, 表示CAS将对密码字段进行MD5加密
	 * 
	 * @param oldPassword 用户旧密码（明文，不需要MD5加密）
	 * 
	 * @return
	 */
	JsonResponse<String> update(CasUser casUser, CasEncrypt encrypt, String oldPassword);
	
	/**
	 * 根据验证码更新用户手机号,并发短信通知旧手机
	 * 
	 * @param id CAS_UUID
	 * @param mobile 新手机号
	 * @param proName 通知短信的proName
	 * @param smsId 短信ID
	 * @param smsCode 短信码
	 * @return
	 */
	JsonResponse<String> updateBySmsCode(String id, String mobile, String proName, String smsId, String smsCode);
	/**
	 * 绑定手机号，根据验证码更新用户手机号
	 * 
	 * @param id CAS_UUID
	 * @param mobile 手机号
	 * @param proName 通知短信的proName
	 * @param smsId 短信ID
	 * @param smsCode 短信码
	 * @return
	 */
	JsonResponse<String> updateBySmsCodeNoSend(String id, String mobile, String proName, String smsId, String smsCode);
	
	/**
	 * 绑定手机号，根据验证码更新用户手机号(app接口)
	 * 
	 * @param id CAS_UUID
	 * @param mobile 手机号
	 * @param proName 通知短信的proName
	 * @param smsId 短信ID
	 * @param smsCode 短信码
	 * @param switchB 万能验证码开关(false:打开开关，不需要校验，true:关闭开关，需要校验验证码) 必填
	 * @return
	 */
	JsonResponse<String> updateBySmsCodeNoSend(String id, String mobile, String proName, String smsId, String smsCode,boolean switchB);
	
	
	/**
	 * 检查当前手机号是否已注册当前角色，当roleKey为空时，表示检查当前手机号是否存在
	 * 
	 * @param mobile 手机号
	 * @param roleKey 角色的key, 具体定义请参考<code>com.wanjia.dsi.web.hyPerson.util.UserRoleKey</code>
	 * @return
	 * 1. 当result返回值为1时，表示此电话号码已经注册当前角色, 其它值表示未注册当前角色<br>
	 * 2. 具体errorCode定义请参考 <code>com.wanjia.dsi.web.hyPerson.util.ErrorCode</code>
	 * 
	 */
	JsonResponse<Integer> checkByMobile(String mobile, String roleKey);
	
	/**
	 * 检查当前登录名是否已注册当前角色，当roleKey为空时，表示检查当前用户名是否存在
	 * 
	 * @param loginName 登录名
	 * @param roleKey 角色的key, 具体定义请参考<code>com.wanjia.dsi.web.hyPerson.util.UserRoleKey</code>
	 * @return
	 * 1. 当result返回值为1时，表示此loginName已经注册当前角色, 其它值表示未注册当前角色<br>
	 * 2. 具体errorCode定义请参考 <code>com.wanjia.dsi.web.hyPerson.util.ErrorCode</code>
	 * 
	 */
	JsonResponse<Integer> checkByLoginName(String loginName, String roleKey);
	
	/**
	 * 根据mobile获取userId
	 * 
	 * @param mobile 手机号
	 * @param roleKey 角色的key, 具体定义请参考<code>com.wanjia.dsi.web.hyPerson.util.UserRoleKey</code>
	 * @return
	 * userId
	 * 
	 */
	JsonResponse<String> getUserIdByMobile(String mobile);
	
	/**
	 * 根据casUser获取casUser
	 * 
	 * @param casUser
	 * @return
	 * List<CasUser>
	 * 
	 */
	JsonResponse<List<CasUser>> findByEntity(CasUser casUser);

	/**
	 * 会员注册后选择角色处理方法
	 * 
	 * @param String userType 
	 * @param String mobile 
	 * @return
	 * Boolean
	 * 
	 */
	JsonResponse<Boolean> registerChooseRole(String userType,String mobile);
	
	
	/**
	 * 通过casUUId和密码校验是否正确 app接口
	 * t_cas_user
	 * @param String casUUId   必填
	 * @param String password  密码 必填
	 * @return
	 * 
	 * 
	 */
	JsonResponse<Boolean> checkCasUUIdPassword(String casUUId,String password);
	
	/**
	 * 根据mobile获取CasUser
	 * 
	 * @param mobile 手机号
	 * @return CasUser
	 * 
	 * 
	 */
	JsonResponse<CasUser> getByMobile(String mobile);
	
	/**
	 * 根据登录名或者手机号获取CasUser
	 * 
	 * @param mobile 手机号
	 * @return CasUser
	 * 
	 * 
	 */
	JsonResponse<List<CasUser>> findByLoginNameORMobile(String loginName, String mobile);
	
	/**
	 * 根据会员ID获取CasUser
	 * 
	 * @param userId 会员ID
	 * @return CasUser
	 * 
	 * 
	 */
	JsonResponse<CasUser> getByUserId(String userId);
}
