package com.wanjia.dsi.web.finance.dao.mapper;

import java.util.List;
import java.util.Map;

public interface FinanceMapper {

	public List<Map<String, Object>> getBankList();


	public List<Map<String, Object>> getBankBranchList(String bankDBID);
	
	
	
	
}
