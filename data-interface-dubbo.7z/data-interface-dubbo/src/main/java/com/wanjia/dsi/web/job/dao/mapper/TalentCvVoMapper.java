package com.wanjia.dsi.web.job.dao.mapper;

import com.wanjia.dsi.web.job.model.TalentCv;

public interface TalentCvVoMapper {
    
    TalentCv selectTransCvByPrimaryKey(String id);
}