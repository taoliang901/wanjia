package com.wanjia.dsi.web.clinic.dao.mongodb.browse;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.wanjia.dsi.web.clinic.model.Clinic;
import com.wanjia.dsi.web.doctor.model.Doctor;


@Document(collection = "clinicBrowse")
public class ClinicBrowse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private String browseId;

    private String clinicId;

    private String userId;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    private String delFlag;

	private Clinic clinic;
	
	private String appSrc;//0-网站，1-M站，2-Android，3-IOS,4-微信，5-
    
    
    public ClinicBrowse() {
		// TODO Auto-generated constructor stub
	}


    
	/**
	 * @return the appSrc
	 */
	public String getAppSrc() {
		return appSrc;
	}



	/**
	 * @param appSrc the appSrc to set
	 */
	public void setAppSrc(String appSrc) {
		this.appSrc = appSrc;
	}



	/**
	 * @return the browseId
	 */
	public String getBrowseId() {
		return browseId;
	}


	/**
	 * @param browseId the browseId to set
	 */
	public void setBrowseId(String browseId) {
		this.browseId = browseId;
	}


	/**
	 * @return the clinicId
	 */
	public String getClinicId() {
		return clinicId;
	}


	/**
	 * @param clinicId the clinicId to set
	 */
	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}


	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}


	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}


	/**
	 * @return the createUser
	 */
	public String getCreateUser() {
		return createUser;
	}


	/**
	 * @param createUser the createUser to set
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}


	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}


	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}


	/**
	 * @return the modifyUser
	 */
	public String getModifyUser() {
		return modifyUser;
	}


	/**
	 * @param modifyUser the modifyUser to set
	 */
	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}


	/**
	 * @return the modifyDate
	 */
	public Date getModifyDate() {
		return modifyDate;
	}


	/**
	 * @param modifyDate the modifyDate to set
	 */
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}


	/**
	 * @return the delFlag
	 */
	public String getDelFlag() {
		return delFlag;
	}


	/**
	 * @param delFlag the delFlag to set
	 */
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}


	/**
	 * @return the clinic
	 */
	public Clinic getClinic() {
		return clinic;
	}


	/**
	 * @param clinic the clinic to set
	 */
	public void setClinic(Clinic clinic) {
		this.clinic = clinic;
	}
	
	
	
	
	
	
	
	

}