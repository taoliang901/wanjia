package com.wanjia.dsi.web.hyPerson.dao.mapper;

import com.wanjia.dsi.web.hyPerson.vo.hy.VoHyUserInfo;

public interface VoHyUserInfoMapper {
	public VoHyUserInfo getVoHyUserInfoByUserId(Long userId);
}
