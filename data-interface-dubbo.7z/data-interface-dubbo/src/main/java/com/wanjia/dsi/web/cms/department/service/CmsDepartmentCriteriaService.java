package com.wanjia.dsi.web.cms.department.service;

import java.util.Date;
import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.cms.common.entity.ClinicDepartment;
import com.wanjia.dsi.web.cms.common.entity.EasyUITreeDataModelBase;
import com.wanjia.dsi.web.cms.department.model.CmsDepartmentCriteria;

/**
 * This element is automatically generated on 16-3-9 下午1:45, do not modify. <br>
 * Service interface
 */
public interface CmsDepartmentCriteriaService extends IBaseService<CmsDepartmentCriteria, Long> {
	/********
	 * 首页科目列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @return
	 * JsonResponse<List<EasyUITreeDataModelBase<ClinicDepartment>>>
	 */
	public  JsonResponse<List<EasyUITreeDataModelBase<ClinicDepartment>>> listInHomepage();
	public  JsonResponse<List<CmsDepartmentCriteria>> getCmsDepartmentByTime(Date beginDate,Date endDate);
}