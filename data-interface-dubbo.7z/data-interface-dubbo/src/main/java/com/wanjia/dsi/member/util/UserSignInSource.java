package com.wanjia.dsi.member.util;

/**
 * 用户签到来源
 * 
 * @author LUOXIAOJUN640
 *
 */
public enum UserSignInSource {

	M("M", "M站");

	private String key;
	private String desc;

	private UserSignInSource(String key, String desc) {
		this.key = key;
		this.desc = desc;
	}

	public static UserSignInSource getInstance(String key) {
		if (key != null) {
			UserSignInSource[] list = UserSignInSource.values();
			for (UserSignInSource source : list) {
				if (source.getKey().equals(key)) {
					return source;
				}
			}
		}

		return null;
	}

	public String getKey() {
		return key;
	}

	public String getDesc() {
		return desc;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
}
