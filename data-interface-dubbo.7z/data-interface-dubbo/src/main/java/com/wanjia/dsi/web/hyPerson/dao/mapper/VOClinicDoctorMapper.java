package com.wanjia.dsi.web.hyPerson.dao.mapper;

import com.wanjia.dsi.web.hyPerson.model.ClinicDoctor;
import com.wanjia.dsi.web.hyPerson.model.VOClinicDoctor;

import java.util.List;

public interface VOClinicDoctorMapper {
   
    List<ClinicDoctor> selectByExampleWithBLOBs(VOClinicDoctor clinicDoctor);
    //通过clinicId得到casUuid
    String getClinicIdByCasUuid(String casUuid);
    
    List<ClinicDoctor> getDoctorListCheckSecrecy(VOClinicDoctor clinicDoctor);
}