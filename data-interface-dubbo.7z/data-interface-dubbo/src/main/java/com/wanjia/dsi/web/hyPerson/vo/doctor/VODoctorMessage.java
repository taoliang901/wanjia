package com.wanjia.dsi.web.hyPerson.vo.doctor;

import java.io.Serializable;
import java.util.List;

import com.wanjia.dsi.web.hyPerson.model.ClinicDoctor;
import com.wanjia.dsi.web.hyPerson.model.HyClinicDoctorExperiences;

public class VODoctorMessage extends ClinicDoctor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/* 医生经历信息 */
	private List<HyClinicDoctorExperiences> experiences;

	// 保存提交标志位
	private String mark;
	
	// 医生ID
	private String doctorId;
	
	public List<HyClinicDoctorExperiences> getExperiences() {
		return experiences;
	}

	public void setExperiences(List<HyClinicDoctorExperiences> experiences) {
		this.experiences = experiences;
	}

	public String getMark() {
		return mark;
	}

	public void setMark(String mark) {
		this.mark = mark;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
}
