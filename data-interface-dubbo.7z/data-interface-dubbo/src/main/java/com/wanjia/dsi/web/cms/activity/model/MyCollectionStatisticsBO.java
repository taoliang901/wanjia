package com.wanjia.dsi.web.cms.activity.model;

import java.io.Serializable;
import java.util.Date;
/**
 * mongodb表对应model
 * @author liuguocai
 *
 */
public class MyCollectionStatisticsBO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1176998236817240547L;
	
	private String type;    //类型 ；资讯：A，药品：M ，疾病：D
	private String infoId; //各个类型统计id; 资讯:activityId;药品:medCode;疾病：diseaseId;
	private long countNum;   //随机数加实际收藏量
	private long realCountNum; //实际收藏量
	private long randomNum;    //随机数
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getInfoId() {
		return infoId;
	}
	public void setInfoId(String infoId) {
		this.infoId = infoId;
	}
	public long getCountNum() {
		return countNum;
	}
	public void setCountNum(long countNum) {
		this.countNum = countNum;
	}
	public long getRealCountNum() {
		return realCountNum;
	}
	public void setRealCountNum(long realCountNum) {
		this.realCountNum = realCountNum;
	}
	public long getRandomNum() {
		return randomNum;
	}
	public void setRandomNum(long randomNum) {
		this.randomNum = randomNum;
	}
	
	
}
