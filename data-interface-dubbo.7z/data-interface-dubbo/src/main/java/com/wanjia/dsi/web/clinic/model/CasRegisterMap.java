package com.wanjia.dsi.web.clinic.model;

import java.util.Date;

public class CasRegisterMap {
    private String id;

    private String casUuid;

    private String clinicRegisterId;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    private String delFlag;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getCasUuid() {
        return casUuid;
    }

    public void setCasUuid(String casUuid) {
        this.casUuid = casUuid == null ? null : casUuid.trim();
    }

    public String getClinicRegisterId() {
        return clinicRegisterId;
    }

    public void setClinicRegisterId(String clinicRegisterId) {
        this.clinicRegisterId = clinicRegisterId == null ? null : clinicRegisterId.trim();
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser == null ? null : modifyUser.trim();
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag == null ? null : delFlag.trim();
    }
}