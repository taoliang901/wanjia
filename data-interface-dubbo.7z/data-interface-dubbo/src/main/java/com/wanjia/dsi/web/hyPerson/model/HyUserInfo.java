package com.wanjia.dsi.web.hyPerson.model;

import java.io.Serializable;
import java.util.Date;

public class HyUserInfo implements Serializable {
	private static final long serialVersionUID = 1L;
  
    private Long memberId;

   
    private String realName;

    
    private String sex;

    
    private Long cityId;

    
    private String idCard;

    
    private String email;

    
    private String deletFlag;

    
    private Date createdDate;

    
    private String createdUser;

    
    private String updatedUser;

    
    private Date updatedDate;

    
    private Long provinceId;

    
    private String provinceName;

    
    private String cityName;
    
    private String birthday;


	public Long getMemberId() {
		return memberId;
	}


	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}


	public String getRealName() {
		return realName;
	}


	public void setRealName(String realName) {
		this.realName = realName;
	}


	public String getSex() {
		return sex;
	}


	public void setSex(String sex) {
		this.sex = sex;
	}


	public Long getCityId() {
		return cityId;
	}


	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}


	public String getIdCard() {
		return idCard;
	}


	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getDeletFlag() {
		return deletFlag;
	}


	public void setDeletFlag(String deletFlag) {
		this.deletFlag = deletFlag;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public String getCreatedUser() {
		return createdUser;
	}


	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}


	public String getUpdatedUser() {
		return updatedUser;
	}


	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}


	public Date getUpdatedDate() {
		return updatedDate;
	}


	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}


	public Long getProvinceId() {
		return provinceId;
	}


	public void setProvinceId(Long provinceId) {
		this.provinceId = provinceId;
	}


	public String getProvinceName() {
		return provinceName;
	}


	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}


	public String getCityName() {
		return cityName;
	}


	public void setCityName(String cityName) {
		this.cityName = cityName;
	}


	public String getBirthday() {
		return birthday;
	}


	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}


	@Override
	public String toString() {
		return "HyUserInfo [memberId=" + memberId + ", realName=" + realName + ", sex=" + sex + ", cityId=" + cityId
				+ ", idCard=" + idCard + ", email=" + email + ", deletFlag=" + deletFlag + ", createdDate="
				+ createdDate + ", createdUser=" + createdUser + ", updatedUser=" + updatedUser + ", updatedDate="
				+ updatedDate + ", provinceId=" + provinceId + ", provinceName=" + provinceName + ", cityName="
				+ cityName + ", birthday=" + birthday + "]";
	}
	
	
    
    
}