package com.wanjia.dsi.web.clinic.dao.mongodb.concern;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.wanjia.dsi.web.clinic.model.Clinic;
import com.wanjia.dsi.web.doctor.model.Doctor;


public class ClinicConcernVo extends ClinicConcern implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3123485822064216040L;
	private String imageRoot;
    
    
	public ClinicConcernVo() {
		// TODO Auto-generated constructor stub
	}


	public String getImageRoot() {
		return imageRoot;
	}


	public void setImageRoot(String imageRoot) {
		this.imageRoot = imageRoot;
	}


	
	
	
	

}