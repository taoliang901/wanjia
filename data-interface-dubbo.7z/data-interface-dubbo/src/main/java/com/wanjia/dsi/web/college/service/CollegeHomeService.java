package com.wanjia.dsi.web.college.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.college.model.CeCourseReleased;

public interface CollegeHomeService {
	/**
	 * 根据typeid查询所有的CeCourseReleased，不同的type显示的数目可以通过pageSize控制
	 * 
	 * @param typeId
	 * @param pageSize
	 * @return
	 */
	public JsonResponse<List<CeCourseReleased>> findCeCourseByType(Integer typeId, Integer pageSize);

	/**
	 * 根据typeid数组查询所有已经发布的课程，返回的map的key是typeId，list是该typeId的结果集
	 * 
	 * @param typeIds
	 * @param pageSize
	 * @return
	 */
	public JsonResponse<Map<Integer, List<CeCourseReleased>>> findCecourseByTypeIds(Integer[] typeIds, Integer pageSize);

	
	/**
	 * 根据标签ID查询已经发布的课程
	 * @param labelId
	 * @param pageSize
	 * @return
	 */
	public JsonResponse<List<CeCourseReleased>> findCeCourseByLabel(String labelId,Integer pageSize);
	
}
