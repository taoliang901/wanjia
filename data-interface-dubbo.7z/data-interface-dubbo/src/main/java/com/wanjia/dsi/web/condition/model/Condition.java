package com.wanjia.dsi.web.condition.model;

import java.io.Serializable;
import java.util.Date;
public class Condition implements Serializable {
	private static final long serialVersionUID = 1L;
	private String conditionId;

	private String conditionName;

	private String conditionCode;

	private String conditionDescription;

	private String createUser;

	private Date createDate;

	private String modifyUser;

	private Date modifyDate;

	private String delFlag;
	
	private String departMentId;
	
	private String departMentName;

	public String getConditionId() {
		return conditionId;
	}

	public void setConditionId(String conditionId) {
		this.conditionId = conditionId;
	}

	public String getConditionName() {
		return conditionName;
	}

	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}

	public String getConditionCode() {
		return conditionCode;
	}

	public void setConditionCode(String conditionCode) {
		this.conditionCode = conditionCode;
	}

	public String getConditionDescription() {
		return conditionDescription;
	}

	public void setConditionDescription(String conditionDescription) {
		this.conditionDescription = conditionDescription;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getDepartMentId() {
		return departMentId;
	}

	public void setDepartMentId(String departMentId) {
		this.departMentId = departMentId;
	}

	public String getDepartMentName() {
		return departMentName;
	}

	public void setDepartMentName(String departMentName) {
		this.departMentName = departMentName;
	}

	@Override
	public String toString() {
		return "Condition [conditionId=" + conditionId + ", conditionName=" + conditionName + ", conditionCode=" + conditionCode + ", conditionDescription=" + conditionDescription + ", createUser=" + createUser + ", createDate=" + createDate + ", modifyUser=" + modifyUser + ", modifyDate=" + modifyDate + ", delFlag=" + delFlag + ", departMentId=" + departMentId + ", departMentName=" + departMentName + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((conditionCode == null) ? 0 : conditionCode.hashCode());
		result = prime * result + ((conditionDescription == null) ? 0 : conditionDescription.hashCode());
		result = prime * result + ((conditionId == null) ? 0 : conditionId.hashCode());
		result = prime * result + ((conditionName == null) ? 0 : conditionName.hashCode());
		result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
		result = prime * result + ((createUser == null) ? 0 : createUser.hashCode());
		result = prime * result + ((delFlag == null) ? 0 : delFlag.hashCode());
		result = prime * result + ((departMentId == null) ? 0 : departMentId.hashCode());
		result = prime * result + ((departMentName == null) ? 0 : departMentName.hashCode());
		result = prime * result + ((modifyDate == null) ? 0 : modifyDate.hashCode());
		result = prime * result + ((modifyUser == null) ? 0 : modifyUser.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Condition other = (Condition) obj;
		if (conditionCode == null) {
			if (other.conditionCode != null)
				return false;
		} else if (!conditionCode.equals(other.conditionCode))
			return false;
		if (conditionDescription == null) {
			if (other.conditionDescription != null)
				return false;
		} else if (!conditionDescription.equals(other.conditionDescription))
			return false;
		if (conditionId == null) {
			if (other.conditionId != null)
				return false;
		} else if (!conditionId.equals(other.conditionId))
			return false;
		if (conditionName == null) {
			if (other.conditionName != null)
				return false;
		} else if (!conditionName.equals(other.conditionName))
			return false;
		if (createDate == null) {
			if (other.createDate != null)
				return false;
		} else if (!createDate.equals(other.createDate))
			return false;
		if (createUser == null) {
			if (other.createUser != null)
				return false;
		} else if (!createUser.equals(other.createUser))
			return false;
		if (delFlag == null) {
			if (other.delFlag != null)
				return false;
		} else if (!delFlag.equals(other.delFlag))
			return false;
		if (departMentId == null) {
			if (other.departMentId != null)
				return false;
		} else if (!departMentId.equals(other.departMentId))
			return false;
		if (departMentName == null) {
			if (other.departMentName != null)
				return false;
		} else if (!departMentName.equals(other.departMentName))
			return false;
		if (modifyDate == null) {
			if (other.modifyDate != null)
				return false;
		} else if (!modifyDate.equals(other.modifyDate))
			return false;
		if (modifyUser == null) {
			if (other.modifyUser != null)
				return false;
		} else if (!modifyUser.equals(other.modifyUser))
			return false;
		return true;
	}

	
}