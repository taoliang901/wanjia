package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.hyPerson.model.CasUserRole;

public interface CasUserRoleVOMapper {
    
    /**
	 * 根据属性字段，查询CasUserRole列表
	 *
	 */
	List<CasUserRole> findByProperties(Map<String, Object> map);
	
}