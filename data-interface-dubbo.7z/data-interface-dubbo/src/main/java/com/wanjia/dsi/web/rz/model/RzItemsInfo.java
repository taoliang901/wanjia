package com.wanjia.dsi.web.rz.model;

import java.util.List;

/**
 * @author QIANXIN510
 *
 */
public class RzItemsInfo extends RzItems{

	private String item;
	
	private String itemDesc;

	private String standardType;
	
	private String improvement;
	
	private String imagePath_array[];
	
	private String scoreType;
	
	private String scoreChoice;
	
	private String imagePathView;
	
	private String isUsed;
	
	public String getScoreChoice() {
		return scoreChoice;
	}

	public void setScoreChoice(String scoreChoice) {
		this.scoreChoice = scoreChoice;
	}

	public String getScoreType() {
		return scoreType;
	}

	public void setScoreType(String scoreType) {
		this.scoreType = scoreType;
	}

	public String getImprovement() {
		return improvement;
	}

	public void setImprovement(String improvement) {
		this.improvement = improvement;
	}

	public String[] getImagePath_array() {
		return imagePath_array;
	}

	public void setImagePath_array(String[] imagePath_array) {
		this.imagePath_array = imagePath_array;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getStandardType() {
		return standardType;
	}

	public void setStandardType(String standardType) {
		this.standardType = standardType;
	}

	public String getImagePathView() {
		return imagePathView;
	}

	public void setImagePathView(String imagePathView) {
		this.imagePathView = imagePathView;
	}

	public String getIsUsed() {
		return isUsed;
	}

	public void setIsUsed(String isUsed) {
		this.isUsed = isUsed;
	}
	
	
}
