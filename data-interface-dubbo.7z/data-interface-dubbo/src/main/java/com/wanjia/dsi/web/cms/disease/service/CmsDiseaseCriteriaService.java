package com.wanjia.dsi.web.cms.disease.service;

import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.cms.disease.model.CmsDiseaseCriteria;

/**
 * This element is automatically generated on 16-3-9 下午1:53, do not modify. <br>
 * Service interface
 */
public interface CmsDiseaseCriteriaService extends IBaseService<CmsDiseaseCriteria, Long> {
}