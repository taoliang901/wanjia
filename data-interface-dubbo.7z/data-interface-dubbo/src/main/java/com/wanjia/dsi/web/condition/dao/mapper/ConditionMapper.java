package com.wanjia.dsi.web.condition.dao.mapper;

import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.condition.model.Condition;

public interface ConditionMapper extends IBaseDao {
	public List<Condition> getConditionList(Condition condition,int offset,int pageSize);
	public Long getConditionListCount(Condition condition);
}