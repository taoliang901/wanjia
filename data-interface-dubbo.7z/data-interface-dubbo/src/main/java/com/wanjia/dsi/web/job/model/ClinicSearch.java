package com.wanjia.dsi.web.job.model;

import java.io.Serializable;
import java.math.BigDecimal;

import com.wanjia.dsi.web.clinic.model.Clinic;

public class ClinicSearch extends Clinic implements Serializable {
    
	private static final long serialVersionUID = 8254640262875339151L;
	
	private String[] areaIdStrs;
	
	private String jobIds;
	private String jobNames;
	private String propertyName;
	
	private int jobCount;
	
	private int cvRecordCount;
	
	private BigDecimal hotPercent;
	
	private String sou;
	public String getJobIds() {
		return jobIds;
	}
	public void setJobIds(String jobIds) {
		this.jobIds = jobIds;
	}
	public String getJobNames() {
		return jobNames;
	}
	public void setJobNames(String jobNames) {
		this.jobNames = jobNames;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public String getSou() {
		return sou;
	}
	public void setSou(String sou) {
		this.sou = sou;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public int getJobCount() {
		return jobCount;
	}
	public void setJobCount(int jobCount) {
		this.jobCount = jobCount;
	}
	public int getCvRecordCount() {
		return cvRecordCount;
	}
	public void setCvRecordCount(int cvRecordCount) {
		this.cvRecordCount = cvRecordCount;
	}
	public BigDecimal getHotPercent() {
		return hotPercent;
	}
	public void setHotPercent(BigDecimal hotPercent) {
		this.hotPercent = hotPercent;
	}
	public String[] getAreaIdStrs() {
		return areaIdStrs;
	}
	public void setAreaIdStrs(String[] areaIdStrs) {
		this.areaIdStrs = areaIdStrs;
	}
}