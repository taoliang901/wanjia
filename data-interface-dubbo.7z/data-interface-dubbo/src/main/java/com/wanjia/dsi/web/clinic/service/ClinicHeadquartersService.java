package com.wanjia.dsi.web.clinic.service;

import java.util.Date;
import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinic.model.ClinicHeadquarters;

public interface ClinicHeadquartersService {
	/**
	 * 通过更新时间查询连锁诊所总部信息 liugc
	 * @param beginDate 必填
	 * @param endDate 必填
	 * @return
	 */
	JsonResponse<List<ClinicHeadquarters>> findClinicHeadquarterByUpdate(Date beginDate,Date endDate);
}
