package com.wanjia.dsi.web.job.dao.mapper;

import java.util.List;

import com.wanjia.dsi.web.job.model.TalentCvExperience;
import com.wanjia.dsi.web.job.model.TalentCvExperienceExample;

public interface TalentCvExperienceVoMapper {
    
	List<TalentCvExperience> selectTransDictByExample(TalentCvExperienceExample example);

}