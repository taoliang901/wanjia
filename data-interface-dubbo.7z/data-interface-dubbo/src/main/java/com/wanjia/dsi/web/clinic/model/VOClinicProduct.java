package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;

public class VOClinicProduct extends Clinic implements Serializable {

	private static final long serialVersionUID = -3542129297036121605L;
	private String prdId; //产品id
	private String totalRegisterId; //总诊所的注册id
	private String mapId; //医生诊室关联表id
	private String priorityShow;  //是否优先显示 默认执业点  0：是优先展示，1：不是优先展示
	private String parentAccountId; // 子诊所的总账号ID
	private String doctorId; //医生id
	private String isShow ; // 医生信息是否展示该诊所（0：展示，1：不展示）
	private String serviceId;
	private String bookingId;
	public String getPrdId() {
		return prdId;
	}

	public void setPrdId(String prdId) {
		this.prdId = prdId;
	}

	public String getTotalRegisterId() {
		return totalRegisterId;
	}

	public void setTotalRegisterId(String totalRegisterId) {
		this.totalRegisterId = totalRegisterId;
	}

	public String getMapId() {
		return mapId;
	}

	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	public String getPriorityShow() {
		return priorityShow;
	}

	public void setPriorityShow(String priorityShow) {
		this.priorityShow = priorityShow;
	}

	public String getParentAccountId() {
		return parentAccountId;
	}

	public void setParentAccountId(String parentAccountId) {
		this.parentAccountId = parentAccountId;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}

	public String getIsShow() {
		return isShow;
	}

	public void setIsShow(String isShow) {
		this.isShow = isShow;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	
}