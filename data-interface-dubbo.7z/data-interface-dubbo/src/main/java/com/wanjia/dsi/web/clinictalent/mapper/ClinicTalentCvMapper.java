package com.wanjia.dsi.web.clinictalent.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.clinictalent.model.TalentCvRecordSearchApp;
import com.wanjia.dsi.web.clinictalent.model.TalentCvSearchApp;
import com.wanjia.dsi.web.job.model.TalentJobRecord;


public interface ClinicTalentCvMapper {


	 /**
	  * 
	  * @param conditions
	  * @return
	  */
	List<TalentCvRecordSearchApp> getTalentCvRecordListByStatus(Map<String, Object> conditions);
	 
	/**
	 * 根据主键更新传入的信息
	 * @param talentJobRecord
	 */
	void updateByPrimaryKeySelective(TalentJobRecord talentJobRecord);
	
	/**
	 * 更加主键更新全部信息
	 * @param talentJobRecord
	 */
	void updateByPrimaryKey(TalentJobRecord talentJobRecord);

	/**
	 * 
	 * @param pkey
	 * @return
	 */
	TalentJobRecord selectByPrimaryKey(String pkey);

	/**
	 * 根据查询条件获取简历list
	 * @param conditions
	 *		intentionJob 		职位类别
	 *		rank				职称要求
	 *		cityId				城市id
	 *		areaIds				地区id
	 *		isNegotiable		是否需要面议
	 *		expectedSalaryMin	期望最低薪水
	 *		expectedSalaryMax	期望最高薪水
	 *		experience			工作经验
	 *		hasCertificate		是否有医师执行证书
	 *		order				排序字段 如：order by id desc
	 * @return
	 */
	List<TalentCvSearchApp> getTalentCvListByConditions(Map<String, Object> conditions);


	 
}
