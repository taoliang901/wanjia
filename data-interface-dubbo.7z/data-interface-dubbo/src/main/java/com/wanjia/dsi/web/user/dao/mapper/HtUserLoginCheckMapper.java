package com.wanjia.dsi.web.user.dao.mapper;

import com.wanjia.dsi.web.user.model.HtUserLoginCheck;

public interface HtUserLoginCheckMapper {
    int deleteByPrimaryKey(String memberId);

    int insert(HtUserLoginCheck record);

    int insertSelective(HtUserLoginCheck record);

    HtUserLoginCheck selectByPrimaryKey(String memberId);

    int updateByPrimaryKeySelective(HtUserLoginCheck record);

    int updateByPrimaryKey(HtUserLoginCheck record);
}