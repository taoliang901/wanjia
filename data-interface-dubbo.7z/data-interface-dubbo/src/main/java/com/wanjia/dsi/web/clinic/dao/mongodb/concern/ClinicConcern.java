package com.wanjia.dsi.web.clinic.dao.mongodb.concern;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.wanjia.dsi.web.clinic.model.Clinic;
import com.wanjia.dsi.web.doctor.model.Doctor;


@Document(collection = "clinicConcern")
public class ClinicConcern implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private String concernId;

    private String clinicId;

    private String userId;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    private String delFlag;

	private Clinic clinic;
	
	private String appSrc;//0-网站，1-M站，2-Android，3-IOS,4-微信，5-
    
    
    
	public ClinicConcern() {
		// TODO Auto-generated constructor stub
	}


	
	
	
	
	/**
	 * @return the appSrc
	 */
	public String getAppSrc() {
		return appSrc;
	}

	/**
	 * @param appSrc the appSrc to set
	 */
	public void setAppSrc(String appSrc) {
		this.appSrc = appSrc;
	}






	public Clinic getClinic() {
		return clinic;
	}

	public void setClinic(Clinic clinic) {
		this.clinic = clinic;
	}

	public String getConcernId() {
		return concernId;
	}


	public ClinicConcern setConcernId(String concernId) {
		this.concernId = concernId;
		return this;
	}


	public String getClinicId() {
		return clinicId;
	}


	public ClinicConcern setClinicId(String clinicId) {
		this.clinicId = clinicId;
		return this;
	}


	public String getUserId() {
		return userId;
	}


	public ClinicConcern setUserId(String userId) {
		this.userId = userId;
		return this;
	}


	public String getCreateUser() {
		return createUser;
	}


	public ClinicConcern setCreateUser(String createUser) {
		this.createUser = createUser;
		return this;
	}


	public Date getCreateDate() {
		return createDate;
	}


	public ClinicConcern setCreateDate(Date createDate) {
		this.createDate = createDate;
		return this;
	}


	public String getModifyUser() {
		return modifyUser;
	}


	public ClinicConcern setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
		return this;
	}


	public Date getModifyDate() {
		return modifyDate;
	}


	public ClinicConcern setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
		return this;
	}


	public String getDelFlag() {
		return delFlag;
	}


	public ClinicConcern setDelFlag(String delFlag) {
		this.delFlag = delFlag;
		return this;
	}

	
	
	
	

}