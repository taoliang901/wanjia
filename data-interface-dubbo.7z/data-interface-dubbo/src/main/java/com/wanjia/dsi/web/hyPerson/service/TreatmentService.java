package com.wanjia.dsi.web.hyPerson.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;

public interface TreatmentService {

	
	public JsonResponse<List<HyTreatmentPerson>> findPersonByIds(List<String> ids);
	
    /**
	 * 获取就诊人列表
	 * 
	 * @param HyTreatmentPerson person
	 * @return
	 */
	public JsonResponse<List<HyTreatmentPerson>> getTreatmentList(HyTreatmentPerson person);
	
	/**
	 * 新增就诊人信息
	 * 
	 * @param HyTreatmentPerson person
	 * @return
	 */
	public JsonResponse<String> addTreatment(HyTreatmentPerson person);
	
	/**
	 * 删除就诊人信息
	 * 
	 * @param Long visitId
	 * @return
	 */
	public JsonResponse<Boolean> delTreatment(String visitId,Long memberId);
	
	/**
	 * 修改就诊人信息
	 * 
	 * @param HyTreatmentPerson person
	 * @param reponse
	 * @return
	 */
	public JsonResponse<Boolean> editTreatment(HyTreatmentPerson person);
	
	/**
	 * 设置默认就诊人
	 * 
	 * @param visitId visitId
	 * @param reponse
	 * @return
	 */
	public JsonResponse<Boolean> setDefaultTreatment(Long memberId,String visitId);
	
	/**
	 * 修改就诊人手机号
	 * @param visitId
	 * @param phone
	 * @param checkCode
	 * @param smsId
	 * @return
	 */
	public JsonResponse<Void> editTreatmentMobile(String visitId,String phone,String checkCode,String smsId);
}
