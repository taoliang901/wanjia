package com.wanjia.dsi.web.dictionary.model;

import java.io.Serializable;
import java.util.List;

public class ElementResult implements Serializable{

	
	private String key;
	private String value;
	private List<Element> list;
	
	
	public ElementResult() {
		// TODO Auto-generated constructor stub
	}


	public String getKey() {
		return key;
	}


	public ElementResult setKey(String key) {
		this.key = key;
		return this;
	}


	public String getValue() {
		return value;
	}


	public ElementResult setValue(String value) {
		this.value = value;
		return this;
	}


	public List<Element> getList() {
		return list;
	}


	public ElementResult setList(List<Element> list) {
		this.list = list;
		return this;
	}


	@Override
	public String toString() {
		return "ElementResult [key=" + key + ", value=" + value + ", list=" + list + ", getKey()=" + getKey() + ", getValue()=" + getValue() + ", getList()=" + getList() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
}
