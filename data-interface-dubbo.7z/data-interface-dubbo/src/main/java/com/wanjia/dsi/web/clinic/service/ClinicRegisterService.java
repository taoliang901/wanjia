/**
 * 
 */
package com.wanjia.dsi.web.clinic.service;

import java.util.Date;
import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinic.model.ClinicRegister;

/**
 * @author Kimi
 *
 */
public interface ClinicRegisterService {

	/**
	 * 诊所注册返回CasUUID接口
	 * 
	 * @param clinicRegister
	 *            1. 用户名（userName）不能为空<br>
	 *            2. 密码（password）不能为空<br>
	 *            3. 手机号（telphone）不能为空
	 * @param resource
	 *            注册来源：0、PC， 1、M， 2、APP
	 * @return 成功：JsonResponse.Status.SUCCESS<br>
	 *         失败：JsonResponse.Status.ERROR<br>
	 *         errorCode<br>
	 *         errorMsg
	 */
	public JsonResponse<Void> clinicRegister(ClinicRegister clinicRegister, String resource);

	/**
	 * 诊所注册接口
	 * 
	 * @param clinicRegister
	 *            1. 用户名（userName）不能为空<br>
	 *            2. 密码（password）不能为空<br>
	 *            3. 手机号（telphone）不能为空
	 * @param resource
	 *            注册来源：0、PC， 1、M， 2、APP
	 * @return 成功：JsonResponse.Status.SUCCESS<br>
	 *         CasUUID 注册统一账户ID<br>
	 *         失败：JsonResponse.Status.ERROR<br>
	 *         errorCode<br>
	 *         errorMsg
	 */
	JsonResponse<String> clinicRegisterReturn(ClinicRegister clinicRegister, String resource);

	/**
	 * 获取诊所账户信息
	 * 
	 * @param registerId
	 *            用户ID（casUuid）
	 * @return ClinicRegister 诊所账户信息
	 */
	public JsonResponse<ClinicRegister> getClinicRegister(String registerId);
	
	

	/**
	 * 根据诊所管理员的userId（user表的id）获取
	 * @return
	 */
	public JsonResponse<ClinicRegister> findClinicRegisterByUserId(String userId);
	
	/**
	 * 通过更新时间查询注册信息 liugc
	 * @param beginDate 必填
	 * @param endDate 必填
	 * @return
	 */
	public JsonResponse<List<ClinicRegister>> findClinicRegisterByUpdate(Date beginDate,Date endDate);

	/**
	 * 普通会员升级成诊所管理员接口
	 * 
	 * @param casUuid
	 *            CAS账户ID
	 * @param resource
	 *            来源：0、PC， 1、M， 2、APP
	 * @return 成功：JsonResponse.Status.SUCCESS<br>
	 *         clinicId 诊所ID<br>
	 *         失败：JsonResponse.Status.ERROR<br>
	 *         errorCode<br>
	 *         errorMsg
	 */
	JsonResponse<String> updateClinicRegister(String casUuid, String resource);

	/**
	 * 根据诊所管理员的用户名获取
	 * @param userName 必填
	 * @return
	 */
	public JsonResponse<ClinicRegister> findClinicRegisterByUserName(String userName);

}
