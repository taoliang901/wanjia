package com.wanjia.dsi.web.callCenter.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.callCenter.model.CcSurvey;



public interface CcSurveyMapper extends IBaseDao<CcSurvey,String> {
    
    public List<CcSurvey> findSurveyList(Map<String,Object> map);
    
    public List<String> selectSurveyType();
    
    public List<CcSurvey> findOvertimeSurvey(); 
        
}