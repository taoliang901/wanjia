package com.wanjia.dsi.web.clinic.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ClinicUserExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ClinicUserExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNull() {
            addCriterion("USER_NAME is null");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNotNull() {
            addCriterion("USER_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andUserNameEqualTo(String value) {
            addCriterion("USER_NAME =", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotEqualTo(String value) {
            addCriterion("USER_NAME <>", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThan(String value) {
            addCriterion("USER_NAME >", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("USER_NAME >=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThan(String value) {
            addCriterion("USER_NAME <", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThanOrEqualTo(String value) {
            addCriterion("USER_NAME <=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLike(String value) {
            addCriterion("USER_NAME like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotLike(String value) {
            addCriterion("USER_NAME not like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameIn(List<String> values) {
            addCriterion("USER_NAME in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotIn(List<String> values) {
            addCriterion("USER_NAME not in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameBetween(String value1, String value2) {
            addCriterion("USER_NAME between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotBetween(String value1, String value2) {
            addCriterion("USER_NAME not between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andPasswordIsNull() {
            addCriterion("PASSWORD is null");
            return (Criteria) this;
        }

        public Criteria andPasswordIsNotNull() {
            addCriterion("PASSWORD is not null");
            return (Criteria) this;
        }

        public Criteria andPasswordEqualTo(String value) {
            addCriterion("PASSWORD =", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotEqualTo(String value) {
            addCriterion("PASSWORD <>", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordGreaterThan(String value) {
            addCriterion("PASSWORD >", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordGreaterThanOrEqualTo(String value) {
            addCriterion("PASSWORD >=", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLessThan(String value) {
            addCriterion("PASSWORD <", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLessThanOrEqualTo(String value) {
            addCriterion("PASSWORD <=", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordLike(String value) {
            addCriterion("PASSWORD like", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotLike(String value) {
            addCriterion("PASSWORD not like", value, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordIn(List<String> values) {
            addCriterion("PASSWORD in", values, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotIn(List<String> values) {
            addCriterion("PASSWORD not in", values, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordBetween(String value1, String value2) {
            addCriterion("PASSWORD between", value1, value2, "password");
            return (Criteria) this;
        }

        public Criteria andPasswordNotBetween(String value1, String value2) {
            addCriterion("PASSWORD not between", value1, value2, "password");
            return (Criteria) this;
        }

        public Criteria andReferrerIsNull() {
            addCriterion("REFERRER is null");
            return (Criteria) this;
        }

        public Criteria andReferrerIsNotNull() {
            addCriterion("REFERRER is not null");
            return (Criteria) this;
        }

        public Criteria andReferrerEqualTo(String value) {
            addCriterion("REFERRER =", value, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerNotEqualTo(String value) {
            addCriterion("REFERRER <>", value, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerGreaterThan(String value) {
            addCriterion("REFERRER >", value, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerGreaterThanOrEqualTo(String value) {
            addCriterion("REFERRER >=", value, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerLessThan(String value) {
            addCriterion("REFERRER <", value, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerLessThanOrEqualTo(String value) {
            addCriterion("REFERRER <=", value, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerLike(String value) {
            addCriterion("REFERRER like", value, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerNotLike(String value) {
            addCriterion("REFERRER not like", value, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerIn(List<String> values) {
            addCriterion("REFERRER in", values, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerNotIn(List<String> values) {
            addCriterion("REFERRER not in", values, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerBetween(String value1, String value2) {
            addCriterion("REFERRER between", value1, value2, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerNotBetween(String value1, String value2) {
            addCriterion("REFERRER not between", value1, value2, "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerTelIsNull() {
            addCriterion("REFERRER_TEL is null");
            return (Criteria) this;
        }

        public Criteria andReferrerTelIsNotNull() {
            addCriterion("REFERRER_TEL is not null");
            return (Criteria) this;
        }

        public Criteria andReferrerTelEqualTo(String value) {
            addCriterion("REFERRER_TEL =", value, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelNotEqualTo(String value) {
            addCriterion("REFERRER_TEL <>", value, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelGreaterThan(String value) {
            addCriterion("REFERRER_TEL >", value, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelGreaterThanOrEqualTo(String value) {
            addCriterion("REFERRER_TEL >=", value, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelLessThan(String value) {
            addCriterion("REFERRER_TEL <", value, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelLessThanOrEqualTo(String value) {
            addCriterion("REFERRER_TEL <=", value, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelLike(String value) {
            addCriterion("REFERRER_TEL like", value, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelNotLike(String value) {
            addCriterion("REFERRER_TEL not like", value, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelIn(List<String> values) {
            addCriterion("REFERRER_TEL in", values, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelNotIn(List<String> values) {
            addCriterion("REFERRER_TEL not in", values, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelBetween(String value1, String value2) {
            addCriterion("REFERRER_TEL between", value1, value2, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andReferrerTelNotBetween(String value1, String value2) {
            addCriterion("REFERRER_TEL not between", value1, value2, "referrerTel");
            return (Criteria) this;
        }

        public Criteria andActivateFlagIsNull() {
            addCriterion("ACTIVATE_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andActivateFlagIsNotNull() {
            addCriterion("ACTIVATE_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andActivateFlagEqualTo(String value) {
            addCriterion("ACTIVATE_FLAG =", value, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagNotEqualTo(String value) {
            addCriterion("ACTIVATE_FLAG <>", value, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagGreaterThan(String value) {
            addCriterion("ACTIVATE_FLAG >", value, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagGreaterThanOrEqualTo(String value) {
            addCriterion("ACTIVATE_FLAG >=", value, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagLessThan(String value) {
            addCriterion("ACTIVATE_FLAG <", value, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagLessThanOrEqualTo(String value) {
            addCriterion("ACTIVATE_FLAG <=", value, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagLike(String value) {
            addCriterion("ACTIVATE_FLAG like", value, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagNotLike(String value) {
            addCriterion("ACTIVATE_FLAG not like", value, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagIn(List<String> values) {
            addCriterion("ACTIVATE_FLAG in", values, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagNotIn(List<String> values) {
            addCriterion("ACTIVATE_FLAG not in", values, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagBetween(String value1, String value2) {
            addCriterion("ACTIVATE_FLAG between", value1, value2, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateFlagNotBetween(String value1, String value2) {
            addCriterion("ACTIVATE_FLAG not between", value1, value2, "activateFlag");
            return (Criteria) this;
        }

        public Criteria andActivateDateIsNull() {
            addCriterion("ACTIVATE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andActivateDateIsNotNull() {
            addCriterion("ACTIVATE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andActivateDateEqualTo(Date value) {
            addCriterion("ACTIVATE_DATE =", value, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateNotEqualTo(Date value) {
            addCriterion("ACTIVATE_DATE <>", value, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateGreaterThan(Date value) {
            addCriterion("ACTIVATE_DATE >", value, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("ACTIVATE_DATE >=", value, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateLessThan(Date value) {
            addCriterion("ACTIVATE_DATE <", value, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateLessThanOrEqualTo(Date value) {
            addCriterion("ACTIVATE_DATE <=", value, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateIn(List<Date> values) {
            addCriterion("ACTIVATE_DATE in", values, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateNotIn(List<Date> values) {
            addCriterion("ACTIVATE_DATE not in", values, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateBetween(Date value1, Date value2) {
            addCriterion("ACTIVATE_DATE between", value1, value2, "activateDate");
            return (Criteria) this;
        }

        public Criteria andActivateDateNotBetween(Date value1, Date value2) {
            addCriterion("ACTIVATE_DATE not between", value1, value2, "activateDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionIsNull() {
            addCriterion("SIGN_AGREEMENT_VERSION is null");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionIsNotNull() {
            addCriterion("SIGN_AGREEMENT_VERSION is not null");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionEqualTo(String value) {
            addCriterion("SIGN_AGREEMENT_VERSION =", value, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionNotEqualTo(String value) {
            addCriterion("SIGN_AGREEMENT_VERSION <>", value, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionGreaterThan(String value) {
            addCriterion("SIGN_AGREEMENT_VERSION >", value, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionGreaterThanOrEqualTo(String value) {
            addCriterion("SIGN_AGREEMENT_VERSION >=", value, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionLessThan(String value) {
            addCriterion("SIGN_AGREEMENT_VERSION <", value, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionLessThanOrEqualTo(String value) {
            addCriterion("SIGN_AGREEMENT_VERSION <=", value, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionLike(String value) {
            addCriterion("SIGN_AGREEMENT_VERSION like", value, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionNotLike(String value) {
            addCriterion("SIGN_AGREEMENT_VERSION not like", value, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionIn(List<String> values) {
            addCriterion("SIGN_AGREEMENT_VERSION in", values, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionNotIn(List<String> values) {
            addCriterion("SIGN_AGREEMENT_VERSION not in", values, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionBetween(String value1, String value2) {
            addCriterion("SIGN_AGREEMENT_VERSION between", value1, value2, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionNotBetween(String value1, String value2) {
            addCriterion("SIGN_AGREEMENT_VERSION not between", value1, value2, "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateIsNull() {
            addCriterion("SIGN_AGREEMENT_DATE is null");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateIsNotNull() {
            addCriterion("SIGN_AGREEMENT_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateEqualTo(Date value) {
            addCriterion("SIGN_AGREEMENT_DATE =", value, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateNotEqualTo(Date value) {
            addCriterion("SIGN_AGREEMENT_DATE <>", value, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateGreaterThan(Date value) {
            addCriterion("SIGN_AGREEMENT_DATE >", value, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateGreaterThanOrEqualTo(Date value) {
            addCriterion("SIGN_AGREEMENT_DATE >=", value, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateLessThan(Date value) {
            addCriterion("SIGN_AGREEMENT_DATE <", value, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateLessThanOrEqualTo(Date value) {
            addCriterion("SIGN_AGREEMENT_DATE <=", value, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateIn(List<Date> values) {
            addCriterion("SIGN_AGREEMENT_DATE in", values, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateNotIn(List<Date> values) {
            addCriterion("SIGN_AGREEMENT_DATE not in", values, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateBetween(Date value1, Date value2) {
            addCriterion("SIGN_AGREEMENT_DATE between", value1, value2, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andSignAgreementDateNotBetween(Date value1, Date value2) {
            addCriterion("SIGN_AGREEMENT_DATE not between", value1, value2, "signAgreementDate");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNull() {
            addCriterion("CREATE_USER is null");
            return (Criteria) this;
        }

        public Criteria andCreateUserIsNotNull() {
            addCriterion("CREATE_USER is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUserEqualTo(String value) {
            addCriterion("CREATE_USER =", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotEqualTo(String value) {
            addCriterion("CREATE_USER <>", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThan(String value) {
            addCriterion("CREATE_USER >", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserGreaterThanOrEqualTo(String value) {
            addCriterion("CREATE_USER >=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThan(String value) {
            addCriterion("CREATE_USER <", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLessThanOrEqualTo(String value) {
            addCriterion("CREATE_USER <=", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserLike(String value) {
            addCriterion("CREATE_USER like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotLike(String value) {
            addCriterion("CREATE_USER not like", value, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserIn(List<String> values) {
            addCriterion("CREATE_USER in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotIn(List<String> values) {
            addCriterion("CREATE_USER not in", values, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserBetween(String value1, String value2) {
            addCriterion("CREATE_USER between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateUserNotBetween(String value1, String value2) {
            addCriterion("CREATE_USER not between", value1, value2, "createUser");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("CREATE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("CREATE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("CREATE_DATE =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("CREATE_DATE <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("CREATE_DATE >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("CREATE_DATE <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("CREATE_DATE in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("CREATE_DATE not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNull() {
            addCriterion("MODIFY_USER is null");
            return (Criteria) this;
        }

        public Criteria andModifyUserIsNotNull() {
            addCriterion("MODIFY_USER is not null");
            return (Criteria) this;
        }

        public Criteria andModifyUserEqualTo(String value) {
            addCriterion("MODIFY_USER =", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotEqualTo(String value) {
            addCriterion("MODIFY_USER <>", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThan(String value) {
            addCriterion("MODIFY_USER >", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserGreaterThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER >=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThan(String value) {
            addCriterion("MODIFY_USER <", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLessThanOrEqualTo(String value) {
            addCriterion("MODIFY_USER <=", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLike(String value) {
            addCriterion("MODIFY_USER like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotLike(String value) {
            addCriterion("MODIFY_USER not like", value, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserIn(List<String> values) {
            addCriterion("MODIFY_USER in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotIn(List<String> values) {
            addCriterion("MODIFY_USER not in", values, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserBetween(String value1, String value2) {
            addCriterion("MODIFY_USER between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserNotBetween(String value1, String value2) {
            addCriterion("MODIFY_USER not between", value1, value2, "modifyUser");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNull() {
            addCriterion("MODIFY_DATE is null");
            return (Criteria) this;
        }

        public Criteria andModifyDateIsNotNull() {
            addCriterion("MODIFY_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andModifyDateEqualTo(Date value) {
            addCriterion("MODIFY_DATE =", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotEqualTo(Date value) {
            addCriterion("MODIFY_DATE <>", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThan(Date value) {
            addCriterion("MODIFY_DATE >", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateGreaterThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE >=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThan(Date value) {
            addCriterion("MODIFY_DATE <", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateLessThanOrEqualTo(Date value) {
            addCriterion("MODIFY_DATE <=", value, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateIn(List<Date> values) {
            addCriterion("MODIFY_DATE in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotIn(List<Date> values) {
            addCriterion("MODIFY_DATE not in", values, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andModifyDateNotBetween(Date value1, Date value2) {
            addCriterion("MODIFY_DATE not between", value1, value2, "modifyDate");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("DEL_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("DEL_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(String value) {
            addCriterion("DEL_FLAG =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(String value) {
            addCriterion("DEL_FLAG <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(String value) {
            addCriterion("DEL_FLAG >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(String value) {
            addCriterion("DEL_FLAG <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLike(String value) {
            addCriterion("DEL_FLAG like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotLike(String value) {
            addCriterion("DEL_FLAG not like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<String> values) {
            addCriterion("DEL_FLAG in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<String> values) {
            addCriterion("DEL_FLAG not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(String value1, String value2) {
            addCriterion("DEL_FLAG between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(String value1, String value2) {
            addCriterion("DEL_FLAG not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andIdLikeInsensitive(String value) {
            addCriterion("upper(ID) like", value.toUpperCase(), "id");
            return (Criteria) this;
        }

        public Criteria andUserNameLikeInsensitive(String value) {
            addCriterion("upper(USER_NAME) like", value.toUpperCase(), "userName");
            return (Criteria) this;
        }

        public Criteria andPasswordLikeInsensitive(String value) {
            addCriterion("upper(PASSWORD) like", value.toUpperCase(), "password");
            return (Criteria) this;
        }

        public Criteria andReferrerLikeInsensitive(String value) {
            addCriterion("upper(REFERRER) like", value.toUpperCase(), "referrer");
            return (Criteria) this;
        }

        public Criteria andReferrerTelLikeInsensitive(String value) {
            addCriterion("upper(REFERRER_TEL) like", value.toUpperCase(), "referrerTel");
            return (Criteria) this;
        }

        public Criteria andActivateFlagLikeInsensitive(String value) {
            addCriterion("upper(ACTIVATE_FLAG) like", value.toUpperCase(), "activateFlag");
            return (Criteria) this;
        }

        public Criteria andSignAgreementVersionLikeInsensitive(String value) {
            addCriterion("upper(SIGN_AGREEMENT_VERSION) like", value.toUpperCase(), "signAgreementVersion");
            return (Criteria) this;
        }

        public Criteria andCreateUserLikeInsensitive(String value) {
            addCriterion("upper(CREATE_USER) like", value.toUpperCase(), "createUser");
            return (Criteria) this;
        }

        public Criteria andModifyUserLikeInsensitive(String value) {
            addCriterion("upper(MODIFY_USER) like", value.toUpperCase(), "modifyUser");
            return (Criteria) this;
        }

        public Criteria andDelFlagLikeInsensitive(String value) {
            addCriterion("upper(DEL_FLAG) like", value.toUpperCase(), "delFlag");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}