package com.wanjia.dsi.web.clinic.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.clinic.model.Clinic;
import com.wanjia.dsi.web.clinic.model.ClinicDailyAccess;
import com.wanjia.dsi.web.clinic.model.ClinicHeadquarters;
import com.wanjia.dsi.web.clinic.model.ClinicInfo;
import com.wanjia.dsi.web.clinic.model.ClinicUser;
import com.wanjia.dsi.web.clinic.model.VOClinicProduct;

/**
 * This element is automatically generated on 16-3-10 ����1:47, do not modify.
 * <br>
 * Service Stringerface
 */
public interface ClinicService extends IBaseService<Clinic, String> {

	/****
	 * 得到最近推荐的诊所
	 * 
	 * @param clinic
	 *            clinic对象
	 * @return
	 */

	JsonResponse<List<Clinic>> getRecentOnlineClinicList(Clinic clinic);

	JsonResponse<List<Clinic>> getClinicHeadquartersList(Clinic clinic);
	
	JsonResponse<List<Map<String,Object>>>getClinicHeadquartersListMap(Map<String,Object> params);

	/*********
	 * 获取总账号信息
	 * 
	 * @param clinic
	 * @return
	 */
	JsonResponse<List<Clinic>> getClinicHeadquartersName(Clinic clinic);

	/*********
	 * 获取当天诊所关注信息
	 * 
	 * @return
	 */
	JsonResponse<List<Clinic>> getClinicConcernFromMongoDB();

	/********
	 * 详情接口 for app
	 * 
	 * @param clinic
	 *            clinic参数
	 * @return
	 */
	JsonResponse<Clinic> getClinicDetailForApp(Clinic clinic);

	/***
	 * insert ClinicDailyAccess
	 * 
	 * @param clinicDailyAccess
	 */
	void insertClinicDailyAccess(ClinicDailyAccess clinicDailyAccess);

	/****
	 * 获取 ClinicDailyAccess 列表
	 * 
	 * @param clinicDailyAccess
	 * @return
	 */
	JsonResponse<List<ClinicDailyAccess>> getClinicDailyAccessList(ClinicDailyAccess clinicDailyAccess);

	/***
	 * 获取诊所关注个数
	 * 
	 * @author chenkang
	 * @since 2016年4月29日
	 * @category TODO:
	 * @throws 无
	 * @param clinic
	 *            对象
	 * @return JsonResponse<Integer>
	 */
	public JsonResponse<Long> getClinicConcernCount(Clinic clinic);

	/***
	 * 多个id，获取列表
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param ids
	 *            诊所id
	 * @return List<Clinic>
	 */
	public JsonResponse<List<Clinic>> findClinicByIds(String requestId, List<String> ids);

	/****
	 * 根据id，获取详情
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param id
	 * @return Clinic
	 */
	public Clinic findClinicById(String requestId, String id);

	/****
	 * 获取推荐的诊所信息
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param areaId
	 * @param pageNo
	 * @param pageSize
	 * @return JsonResponse<PageInfo<Clinic>>
	 */
	public JsonResponse<PageInfo<Clinic>> getRecommendClinicList(String requestId, String areaId, String pageNo,
			String pageSize);

	public List<Clinic> getBrownClinicList(String requestId, Clinic clinic);

	/****
	 * 获取关注的诊所列表
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param clinic
	 *            参数
	 * @return JsonResponse<List<Clinic>>
	 */
	public List<Clinic> getConcernClinicList(String requestId, Clinic clinic);

	/****
	 * 获取诊所排行列表
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param parseObject
	 *            参数
	 * @param pageNo
	 *            页码
	 * @param pageSize
	 *            页数
	 * @return JsonResponse<PageInfo<Clinic>>
	 */
	public JsonResponse<PageInfo<Clinic>> getClinicRank(String requestId, Clinic parseObject, String pageNo,
			String pageSize);

	/****
	 * 获取关注/浏览列表
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param userId
	 *            用户id
	 * @param type
	 *            类型
	 * @param pageNo
	 *            页数
	 * @param pageSize
	 *            每页个数
	 * @param appSrc
	 *            来源
	 * @return JsonResponse<PageInfo<Clinic>>
	 */
	public JsonResponse getClinicListByType(String requestId, String userId, String type, String pageNo,
			String pageSize, String appSrc);

	public JsonResponse<Boolean> insertClinicBrowse(String requestId, String clinicId, String userId, String appSrc)
			throws Exception;

	public JsonResponse<Boolean> deleteClinicBrowse(String requestId, String browseIds, String appSrc) throws Exception;

	/***
	 * 诊所关注插入
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param clinicId
	 * @param userId
	 * @param appSrc
	 * @return
	 * @throws Exception
	 *             JsonResponse<Boolean>
	 */
	public JsonResponse<Boolean> insertClinicConcern(String requestId, String clinicId, String userId, String appSrc)
			throws Exception;

	/**
	 * 
	 * 
	 * @param requestId
	 * @param clinicId
	 * @param userId
	 * @param appSrc
	 * @param clientType 积分获取来源，详情请参考IntegralClient
	 * @return
	 * @throws Exception
	 */
	JsonResponse<Boolean> insertClinicConcern(String requestId, String clinicId, String userId, String appSrc,
			String clientType) throws Exception;
	
	/***
	 * 诊所关注删除
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param concernIds
	 * @param appSrc
	 * @param clinicId
	 * @param userId
	 * @return JsonResponse<Boolean>
	 */
	public JsonResponse<Boolean> deleteClinicConcern(String requestId, String concernIds, String appSrc,
			String clinicId, String userId);

	/***
	 * 同步es方法
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @throws 无
	 * @param clinic
	 */
	public List<Clinic> getClinicDataToEs(Clinic clinic);

	/***
	 * 获取诊所详情
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @category TODO:
	 * @param clinicId
	 *            诊所id
	 * @throws 无
	 * @param clinic
	 */
	public JsonResponse<Clinic> getClinicDetailById(String requestId, String clinicId);

	/***
	 * 获取关注列表
	 * 
	 * @author chenkang
	 * @since 2016年4月24日
	 * @param clinicIds
	 *            诊所id 多个
	 * @param userId
	 *            用户id
	 * @param appSrc
	 *            来源
	 * @category TODO:
	 * @throws 无
	 * @param clinic
	 */
	public JsonResponse<List<Clinic>> getConcernClinicList(String requestId, String clinicIds, String userId,
			String appSrc);

	/**
	 * 
	 * @param clinicId
	 * @param checkStatus
	 * @param oldCheckStatus
	 *            <p>
	 *            诊所提交后，判断是否有需要审核的字段更新，如果有，则提交至后台进行审核，如果没有则自动审核通过
	 * 
	 * @return JsonResponse<Void>
	 */
	public JsonResponse<Void> isNeedCheck(String clinicId, String checkStatus, String oldCheckStatus);

	/**
	 * 
	 * @param clinicId
	 * @param checkStatus
	 * @param oldCheckStatus
	 *            <p>
	 *            诊所提交后，判断是否有需要审核的字段更新，如果有，则提交至后台进行审核，如果没有则自动审核通过
	 * 
	 * @return JsonResponse<Void>
	 */
	public JsonResponse<String> isNeedCheckR(String clinicId, String checkStatus, String oldCheckStatus);

	// +++++++++++++++++++++++ below interface for shenzhen
	// team+++++++++++++++++++++
	// 4,B端用户-新增用户信息的接口 输入：用户登陆账号,密码，手机号码，用户id，邮箱。输出：成功或失败

	public List<Clinic> findClinicAddressForApp(Clinic clinic);

	public void updateAddressInfo(Clinic clinic);

	public List<Clinic> getClinicInfoList(Clinic clinic);

	/***
	 * B端用户-新增用户信息
	 * 
	 * @author chenkang
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param com.wanjia.dsi.web.clinic.model.ClinicUser
	 *            参数
	 * @return JsonResponse<Boolean> true代表成功，false代表失败
	 */
	JsonResponse<Boolean> insertClinicUser(ClinicUser clinicUser);

	// 5,B端用户-查询用户信息的接口
	/***
	 * B端用户-查询用户信息的接口
	 * 
	 * @author chenkang
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param com.wanjia.dsi.web.clinic.model.ClinicUser
	 * @param pageNo
	 *            页码
	 * @param pageSize
	 *            页数
	 * @return * JsonResponse<PageInfo<ClinicUser>>
	 */
	JsonResponse<PageInfo<ClinicUser>> findClinicUserList(ClinicUser clinicUser, int pageNo, int pageSize);

	// 6,B端用户-修改用户信息的接口
	/***
	 * 修改用户信息的接口/修改密码/用户失效(设置delflag =0)
	 * 
	 * @author chenkang
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param com.wanjia.dsi.web.clinic.model.ClinicUser
	 *            参数
	 * @return JsonResponse<Boolean>
	 */
	JsonResponse<Boolean> updateClinicUser(ClinicUser clinicUser);

	// 7,B端用户-删除用户信息的接口。
	/***
	 * B端用户-删除用户信息的接口。
	 * 
	 * @author chenkang
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param id
	 *            用户id
	 * @return JsonResponse<Boolean>
	 */
	JsonResponse<Boolean> deleteClinicUser(String id);

	// 8 B端用户-根据诊所ID返回管理员列表。
	/***
	 * B端用户-根据诊所ID返回管理员列表。
	 * 
	 * @author chenkang
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param clinicId
	 *            诊所id
	 * @param pageNo
	 *            页码
	 * @param pageSize
	 *            页数
	 * @return JsonResponse<PageInfo<ClinicUser>>
	 */
	JsonResponse<PageInfo<ClinicUser>> getClinicUserByClinicId(String clinicId, int pageNo, int pageSize);

	// 11,诊所数据对接-查询诊所信息
	/***
	 * 诊所数据对接-查询诊所信息
	 * 
	 * @author chenkang
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param clinicId
	 *            诊所id
	 * @return JsonResponse<ClinicInfo>
	 */
	JsonResponse<ClinicInfo> getClinicInfoById(String clinicId);

	// 12,诊所数据对接-定时拉取诊所总的列表
	/****
	 * 诊所数据对接-定时拉取诊所总的列表（深圳同步）
	 * 
	 * @author chenkang
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return JsonResponse<List<ClinicInfo>>
	 */
	JsonResponse<List<ClinicInfo>> getClinicInfoByTime(Date beginDate, Date endDate);

	/****
	 * get the list of user 查询总诊所，（深圳同步）
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return
	 */
	JsonResponse<List<ClinicUser>> getClinicUserInfoList(ClinicUser clinicUser);

	// +++++++++++++++++++++++ above interface for shenzhen
	// team+++++++++++++++++++++

	/***
	 * 根据诊所名称查询诊所信息 List<Clinic>
	 */
	public JsonResponse<List<Clinic>> findClinicByName(String requestId, Clinic clinic);
	
	/***
	 * 根据诊所名称查询诊所信息(可以查到所有诊所) add by YUNLONG
	 */
	public JsonResponse<List<Clinic>> findClinicByNameForHy(String requestId, Clinic clinic);


	/***
	 * 根据诊所手机号查询诊所信息 List<Clinic>
	 */
	public JsonResponse<List<Clinic>> findClinicByMobile(String requestId, String mobile);

	/***
	 * 根据城市查询诊所列表（注：查询的是所有的诊所【clinic_info、address_info】表，非approval表）
	 */
	JsonResponse<List<Clinic>> getClinicListByCity(String cityCode);

	/***
	 * 根据区查询诊所列表（注：查询的是所有的诊所【clinic_info、address_info】表，非approval表）
	 */
	JsonResponse<List<Clinic>> getClinicListByDistrict(String districtCode);

	/**
	 * 通过医生手机号，获取诊所
	 * 
	 * @param mobile
	 *            手机号码
	 * @return
	 */
	List<ClinicInfo> findByDoctorMobile(Map<String, Object> map);

	/***
	 * 通过诊所注册用户ID获取诊所信息
	 * 
	 * @author Kimi
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param registerId
	 *            注册用户ID（CasUuid）
	 * @return JsonResponse<ClinicInfo> 诊所信息
	 */
	JsonResponse<ClinicInfo> getClinicByRegisterId(String registerId);

	/***
	 * 更新诊所信息
	 * 
	 * @author Kimi
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param clinicInfo
	 *            诊所信息
	 * @return JsonResponse<Boolean>
	 */
	JsonResponse<Boolean> updateClinicInfo(ClinicInfo clinicInfo);

	/****
	 * 
	 * @author chenkang
	 * @since
	 * @category TODO:
	 * @throws 无
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return JsonResponse<List<ClinicInfo>>
	 */
	JsonResponse<List<ClinicUser>> getClinicByParentAccountId(ClinicUser clinicUser);

	/**
	 * 根据诊所ID获取诊所注册信息
	 * 
	 * @param clinicId
	 *            诊所id
	 * @return
	 */
	JsonResponse<ClinicUser> getClinicRegisterByClinicId(String clinicId);

	/**
	 * 根据诊所ID获取诊所总账号信息
	 * 
	 * @param clinicId
	 *            诊所id
	 * @return
	 */
	JsonResponse<ClinicHeadquarters> getClinicHeadquartersByClinicId(String clinicId);

	/**
	 * 查询所有诊所信息（关注和评价）,需要复用可以自己增加字段
	 * 
	 * @return
	 */
	List<Clinic> getAllClinic();

	/**
	 * 深圳接口获得评价
	 * 
	 * @return
	 */
	public JsonResponse<List<Clinic>> getClinicsWithEvalution();

	/**
	 * 更新 评价和关注
	 * 
	 * @return
	 */
	public JsonResponse updateClinicStatic();

	/**
	 * 通过产品id活动对应诊所信息(查询非总诊所)
	 * 
	 * @param voClinicProduct
	 *            ：prdId必填
	 * @return
	 */
	public JsonResponse<PageInfo<Clinic>> getClinicByProId(VOClinicProduct voClinicProduct);

	/**
	 * 通过诊所名称查询诊所名称、地址、状态
	 * 
	 * @param clinicName
	 *            必填
	 * @return
	 */
	public JsonResponse<List> getClinicStatusByClinicName(String clinicName);

	/**
	 * 按规则推荐诊所
	 * 
	 * @param areaId
	 *            pageSize
	 * @return
	 */
	public JsonResponse<List<Clinic>> getRecommendClinicListByRules(String areaId, int pageSize);

	/**
	 * 生成推荐诊所
	 * 
	 * @return
	 */
	public JsonResponse<String> generateClinicRecommentByRules();

	/**
	 * 
	 * @param clinicId
	 *            <p>
	 *            判断是否有需要审核的字段更新，如果有，则返回true，如果没有则返回false
	 * 
	 * @return JsonResponse<Void>
	 */
	JsonResponse<Boolean> compareNeedCheck(String clinicId);

	/**
	 * 通过医生casUUID获得审核状态和诊所消息
	 * @param casUUID 必填
	 * @return
	 */
	JsonResponse<PageInfo<VOClinicProduct>> findClinicAddrByDocId(VOClinicProduct voClinicProduct);
	/**
	 * 通过医生casUUID获得审核状态和诊所消息(没有分页)app接口
	 * @param casUUID 必填
	 * @return
	 */
	JsonResponse<List<VOClinicProduct>> findClinicListAddrByDocId(VOClinicProduct voClinicProduct);
	
	JsonResponse<Long> getOnlineClinicNum();
	
	JsonResponse<Integer> findClinicNumberByPrdId(String prdId);
	
	public Clinic findClinicInfoById(String requestId, String id);
/**
 * 获取诊所评分
 * @param clinic
 * @return
 */
	public Clinic  getClinicEvalution(Clinic clinic);
	
	
	/**
	 * 根据注册信息获取诊所信息
	 * @param clinic
	 * @return
	 */
	List<Map<String,Object>> findClinicByRegisterInfo(Map<String,Object> params);
	
	/**
	 * 根据医疗机构证书号获取医疗机构类型
	 * @param departNo
	 * @return
	 */
	JsonResponse<String> autoGetClinicTypeDepartments(String departNo);
}