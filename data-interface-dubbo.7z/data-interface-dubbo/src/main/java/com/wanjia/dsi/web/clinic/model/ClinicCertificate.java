package com.wanjia.dsi.web.clinic.model;

import java.math.BigDecimal;
import java.util.Date;

public class ClinicCertificate {
    private String id;

    private String clinicId;

    private String certificateId;

    private String website;

    private String email;

    private String property;

    private BigDecimal allArea;

    private Long annualWeekPerson;

    private Long operation;

    private Long employeeTotal;

    private Long doctorNum;

    private Long radiationDoctorNum;

    private Long radiationTechnicianNum;

    private Long inspectorTechnicianNum;

    private Long pharmacistNum;

    private Long nurseNum;

    private Long manageLogisticsNum;

    private Long firstTotalDoctorNum;

    private Long firstSeniorNum;

    private Long firstIntermediateNum;

    private Long firstJuniorNum;

    private Long stTotalDoctorNum;

    private Long stSeniorNum;

    private Long stIntermediateNum;

    private Long stJuniorNum;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    private String delFlag = "0";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId == null ? null : clinicId.trim();
    }

    public String getCertificateId() {
        return certificateId;
    }

    public void setCertificateId(String certificateId) {
        this.certificateId = certificateId == null ? null : certificateId.trim();
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website == null ? null : website.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property == null ? null : property.trim();
    }

    public BigDecimal getAllArea() {
        return allArea;
    }

    public void setAllArea(BigDecimal allArea) {
        this.allArea = allArea;
    }

    public Long getAnnualWeekPerson() {
        return annualWeekPerson;
    }

    public void setAnnualWeekPerson(Long annualWeekPerson) {
        this.annualWeekPerson = annualWeekPerson;
    }

    public Long getOperation() {
        return operation;
    }

    public void setOperation(Long operation) {
        this.operation = operation;
    }

    public Long getEmployeeTotal() {
        return employeeTotal;
    }

    public void setEmployeeTotal(Long employeeTotal) {
        this.employeeTotal = employeeTotal;
    }

    public Long getDoctorNum() {
        return doctorNum;
    }

    public void setDoctorNum(Long doctorNum) {
        this.doctorNum = doctorNum;
    }

    public Long getRadiationDoctorNum() {
        return radiationDoctorNum;
    }

    public void setRadiationDoctorNum(Long radiationDoctorNum) {
        this.radiationDoctorNum = radiationDoctorNum;
    }

    public Long getRadiationTechnicianNum() {
        return radiationTechnicianNum;
    }

    public void setRadiationTechnicianNum(Long radiationTechnicianNum) {
        this.radiationTechnicianNum = radiationTechnicianNum;
    }

    public Long getInspectorTechnicianNum() {
        return inspectorTechnicianNum;
    }

    public void setInspectorTechnicianNum(Long inspectorTechnicianNum) {
        this.inspectorTechnicianNum = inspectorTechnicianNum;
    }

    public Long getPharmacistNum() {
        return pharmacistNum;
    }

    public void setPharmacistNum(Long pharmacistNum) {
        this.pharmacistNum = pharmacistNum;
    }

    public Long getNurseNum() {
        return nurseNum;
    }

    public void setNurseNum(Long nurseNum) {
        this.nurseNum = nurseNum;
    }

    public Long getManageLogisticsNum() {
        return manageLogisticsNum;
    }

    public void setManageLogisticsNum(Long manageLogisticsNum) {
        this.manageLogisticsNum = manageLogisticsNum;
    }

    public Long getFirstTotalDoctorNum() {
        return firstTotalDoctorNum;
    }

    public void setFirstTotalDoctorNum(Long firstTotalDoctorNum) {
        this.firstTotalDoctorNum = firstTotalDoctorNum;
    }

    public Long getFirstSeniorNum() {
        return firstSeniorNum;
    }

    public void setFirstSeniorNum(Long firstSeniorNum) {
        this.firstSeniorNum = firstSeniorNum;
    }

    public Long getFirstIntermediateNum() {
        return firstIntermediateNum;
    }

    public void setFirstIntermediateNum(Long firstIntermediateNum) {
        this.firstIntermediateNum = firstIntermediateNum;
    }

    public Long getFirstJuniorNum() {
        return firstJuniorNum;
    }

    public void setFirstJuniorNum(Long firstJuniorNum) {
        this.firstJuniorNum = firstJuniorNum;
    }

    public Long getStTotalDoctorNum() {
        return stTotalDoctorNum;
    }

    public void setStTotalDoctorNum(Long stTotalDoctorNum) {
        this.stTotalDoctorNum = stTotalDoctorNum;
    }

    public Long getStSeniorNum() {
        return stSeniorNum;
    }

    public void setStSeniorNum(Long stSeniorNum) {
        this.stSeniorNum = stSeniorNum;
    }

    public Long getStIntermediateNum() {
        return stIntermediateNum;
    }

    public void setStIntermediateNum(Long stIntermediateNum) {
        this.stIntermediateNum = stIntermediateNum;
    }

    public Long getStJuniorNum() {
        return stJuniorNum;
    }

    public void setStJuniorNum(Long stJuniorNum) {
        this.stJuniorNum = stJuniorNum;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser == null ? null : modifyUser.trim();
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag == null ? null : delFlag.trim();
    }
}