package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;
import java.util.Date;

public class ClinicDoctorApproval implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;

    private String doctorName;

    private String doctorGender;

    private String doctorPhoto;

    private String medicalLicenseNo;

    private String medicalLicensePath;

    private String medicalPracticingNo;

    private String medicalPracticingPath;

    private String doctorProperty;

    private String highestEducation;

    private String highestEducationPath;

    private String graduateCollege;

    private String medicineTitle;

    private String medicineTitlePath;

    private String diagnosisTypeCode1;

    private String diagnosisType1;

    private String isAllDiagnosis;

    private String practiceScope;

    private String practiceBeginDate;

    private String workingTime;

    private String workingTimeRemark;

    private String personalIntroduce;

    private String goodArea;

    private String isView;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    private String delFlag;

    private String inspectionStatus;

    private Date inspectionDate;

    private String cardType;

    private String cardTypeCode;

    private String cardPath;

    private String hasClinic;

    private String hasClinicTel;

    private String hasClinicOtherName;

    private String doctorPhotoPath;

    private String practiceArea;

    private String offlineReason;

    private Date onlineDate;

    private Date offlineDate;

    private String practiceAreaCopy1;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getDoctorGender() {
        return doctorGender;
    }

    public void setDoctorGender(String doctorGender) {
        this.doctorGender = doctorGender;
    }

    public String getDoctorPhoto() {
        return doctorPhoto;
    }

    public void setDoctorPhoto(String doctorPhoto) {
        this.doctorPhoto = doctorPhoto;
    }

    public String getMedicalLicenseNo() {
        return medicalLicenseNo;
    }

    public void setMedicalLicenseNo(String medicalLicenseNo) {
        this.medicalLicenseNo = medicalLicenseNo;
    }

    public String getMedicalLicensePath() {
        return medicalLicensePath;
    }

    public void setMedicalLicensePath(String medicalLicensePath) {
        this.medicalLicensePath = medicalLicensePath;
    }

    public String getMedicalPracticingNo() {
        return medicalPracticingNo;
    }

    public void setMedicalPracticingNo(String medicalPracticingNo) {
        this.medicalPracticingNo = medicalPracticingNo;
    }

    public String getMedicalPracticingPath() {
        return medicalPracticingPath;
    }

    public void setMedicalPracticingPath(String medicalPracticingPath) {
        this.medicalPracticingPath = medicalPracticingPath;
    }

    public String getDoctorProperty() {
        return doctorProperty;
    }

    public void setDoctorProperty(String doctorProperty) {
        this.doctorProperty = doctorProperty;
    }

    public String getHighestEducation() {
        return highestEducation;
    }

    public void setHighestEducation(String highestEducation) {
        this.highestEducation = highestEducation;
    }

    public String getHighestEducationPath() {
        return highestEducationPath;
    }

    public void setHighestEducationPath(String highestEducationPath) {
        this.highestEducationPath = highestEducationPath;
    }

    public String getGraduateCollege() {
        return graduateCollege;
    }

    public void setGraduateCollege(String graduateCollege) {
        this.graduateCollege = graduateCollege;
    }

    public String getMedicineTitle() {
        return medicineTitle;
    }

    public void setMedicineTitle(String medicineTitle) {
        this.medicineTitle = medicineTitle;
    }

    public String getMedicineTitlePath() {
        return medicineTitlePath;
    }

    public void setMedicineTitlePath(String medicineTitlePath) {
        this.medicineTitlePath = medicineTitlePath;
    }

    public String getDiagnosisTypeCode1() {
        return diagnosisTypeCode1;
    }

    public void setDiagnosisTypeCode1(String diagnosisTypeCode1) {
        this.diagnosisTypeCode1 = diagnosisTypeCode1;
    }

    public String getDiagnosisType1() {
        return diagnosisType1;
    }

    public void setDiagnosisType1(String diagnosisType1) {
        this.diagnosisType1 = diagnosisType1;
    }

    public String getIsAllDiagnosis() {
        return isAllDiagnosis;
    }

    public void setIsAllDiagnosis(String isAllDiagnosis) {
        this.isAllDiagnosis = isAllDiagnosis;
    }

    public String getPracticeScope() {
        return practiceScope;
    }

    public void setPracticeScope(String practiceScope) {
        this.practiceScope = practiceScope;
    }

    public String getPracticeBeginDate() {
        return practiceBeginDate;
    }

    public void setPracticeBeginDate(String practiceBeginDate) {
        this.practiceBeginDate = practiceBeginDate;
    }

    public String getWorkingTime() {
        return workingTime;
    }

    public void setWorkingTime(String workingTime) {
        this.workingTime = workingTime;
    }

    public String getWorkingTimeRemark() {
        return workingTimeRemark;
    }

    public void setWorkingTimeRemark(String workingTimeRemark) {
        this.workingTimeRemark = workingTimeRemark;
    }

    public String getPersonalIntroduce() {
        return personalIntroduce;
    }

    public void setPersonalIntroduce(String personalIntroduce) {
        this.personalIntroduce = personalIntroduce;
    }

    public String getGoodArea() {
        return goodArea;
    }

    public void setGoodArea(String goodArea) {
        this.goodArea = goodArea;
    }

    public String getIsView() {
        return isView;
    }

    public void setIsView(String isView) {
        this.isView = isView;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getInspectionStatus() {
        return inspectionStatus;
    }

    public void setInspectionStatus(String inspectionStatus) {
        this.inspectionStatus = inspectionStatus;
    }

    public Date getInspectionDate() {
        return inspectionDate;
    }

    public void setInspectionDate(Date inspectionDate) {
        this.inspectionDate = inspectionDate;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardTypeCode() {
        return cardTypeCode;
    }

    public void setCardTypeCode(String cardTypeCode) {
        this.cardTypeCode = cardTypeCode;
    }

    public String getCardPath() {
        return cardPath;
    }

    public void setCardPath(String cardPath) {
        this.cardPath = cardPath;
    }

    public String getHasClinic() {
        return hasClinic;
    }

    public void setHasClinic(String hasClinic) {
        this.hasClinic = hasClinic;
    }

    public String getHasClinicTel() {
        return hasClinicTel;
    }

    public void setHasClinicTel(String hasClinicTel) {
        this.hasClinicTel = hasClinicTel;
    }

    public String getHasClinicOtherName() {
        return hasClinicOtherName;
    }

    public void setHasClinicOtherName(String hasClinicOtherName) {
        this.hasClinicOtherName = hasClinicOtherName;
    }

    public String getDoctorPhotoPath() {
        return doctorPhotoPath;
    }

    public void setDoctorPhotoPath(String doctorPhotoPath) {
        this.doctorPhotoPath = doctorPhotoPath;
    }

    public String getPracticeArea() {
        return practiceArea;
    }

    public void setPracticeArea(String practiceArea) {
        this.practiceArea = practiceArea;
    }

    public String getOfflineReason() {
        return offlineReason;
    }

    public void setOfflineReason(String offlineReason) {
        this.offlineReason = offlineReason;
    }

    public Date getOnlineDate() {
        return onlineDate;
    }

    public void setOnlineDate(Date onlineDate) {
        this.onlineDate = onlineDate;
    }

    public Date getOfflineDate() {
        return offlineDate;
    }

    public void setOfflineDate(Date offlineDate) {
        this.offlineDate = offlineDate;
    }

    public String getPracticeAreaCopy1() {
        return practiceAreaCopy1;
    }

    public void setPracticeAreaCopy1(String practiceAreaCopy1) {
        this.practiceAreaCopy1 = practiceAreaCopy1;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        ClinicDoctorApproval other = (ClinicDoctorApproval) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getDoctorName() == null ? other.getDoctorName() == null : this.getDoctorName().equals(other.getDoctorName()))
            && (this.getDoctorGender() == null ? other.getDoctorGender() == null : this.getDoctorGender().equals(other.getDoctorGender()))
            && (this.getDoctorPhoto() == null ? other.getDoctorPhoto() == null : this.getDoctorPhoto().equals(other.getDoctorPhoto()))
            && (this.getMedicalLicenseNo() == null ? other.getMedicalLicenseNo() == null : this.getMedicalLicenseNo().equals(other.getMedicalLicenseNo()))
            && (this.getMedicalLicensePath() == null ? other.getMedicalLicensePath() == null : this.getMedicalLicensePath().equals(other.getMedicalLicensePath()))
            && (this.getMedicalPracticingNo() == null ? other.getMedicalPracticingNo() == null : this.getMedicalPracticingNo().equals(other.getMedicalPracticingNo()))
            && (this.getMedicalPracticingPath() == null ? other.getMedicalPracticingPath() == null : this.getMedicalPracticingPath().equals(other.getMedicalPracticingPath()))
            && (this.getDoctorProperty() == null ? other.getDoctorProperty() == null : this.getDoctorProperty().equals(other.getDoctorProperty()))
            && (this.getHighestEducation() == null ? other.getHighestEducation() == null : this.getHighestEducation().equals(other.getHighestEducation()))
            && (this.getHighestEducationPath() == null ? other.getHighestEducationPath() == null : this.getHighestEducationPath().equals(other.getHighestEducationPath()))
            && (this.getGraduateCollege() == null ? other.getGraduateCollege() == null : this.getGraduateCollege().equals(other.getGraduateCollege()))
            && (this.getMedicineTitle() == null ? other.getMedicineTitle() == null : this.getMedicineTitle().equals(other.getMedicineTitle()))
            && (this.getMedicineTitlePath() == null ? other.getMedicineTitlePath() == null : this.getMedicineTitlePath().equals(other.getMedicineTitlePath()))
            && (this.getDiagnosisTypeCode1() == null ? other.getDiagnosisTypeCode1() == null : this.getDiagnosisTypeCode1().equals(other.getDiagnosisTypeCode1()))
            && (this.getDiagnosisType1() == null ? other.getDiagnosisType1() == null : this.getDiagnosisType1().equals(other.getDiagnosisType1()))
            && (this.getIsAllDiagnosis() == null ? other.getIsAllDiagnosis() == null : this.getIsAllDiagnosis().equals(other.getIsAllDiagnosis()))
            && (this.getPracticeScope() == null ? other.getPracticeScope() == null : this.getPracticeScope().equals(other.getPracticeScope()))
            && (this.getPracticeBeginDate() == null ? other.getPracticeBeginDate() == null : this.getPracticeBeginDate().equals(other.getPracticeBeginDate()))
            && (this.getWorkingTime() == null ? other.getWorkingTime() == null : this.getWorkingTime().equals(other.getWorkingTime()))
            && (this.getWorkingTimeRemark() == null ? other.getWorkingTimeRemark() == null : this.getWorkingTimeRemark().equals(other.getWorkingTimeRemark()))
            && (this.getPersonalIntroduce() == null ? other.getPersonalIntroduce() == null : this.getPersonalIntroduce().equals(other.getPersonalIntroduce()))
            && (this.getGoodArea() == null ? other.getGoodArea() == null : this.getGoodArea().equals(other.getGoodArea()))
            && (this.getIsView() == null ? other.getIsView() == null : this.getIsView().equals(other.getIsView()))
            && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser()))
            && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate()))
            && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser()))
            && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getInspectionStatus() == null ? other.getInspectionStatus() == null : this.getInspectionStatus().equals(other.getInspectionStatus()))
            && (this.getInspectionDate() == null ? other.getInspectionDate() == null : this.getInspectionDate().equals(other.getInspectionDate()))
            && (this.getCardType() == null ? other.getCardType() == null : this.getCardType().equals(other.getCardType()))
            && (this.getCardTypeCode() == null ? other.getCardTypeCode() == null : this.getCardTypeCode().equals(other.getCardTypeCode()))
            && (this.getCardPath() == null ? other.getCardPath() == null : this.getCardPath().equals(other.getCardPath()))
            && (this.getHasClinic() == null ? other.getHasClinic() == null : this.getHasClinic().equals(other.getHasClinic()))
            && (this.getHasClinicTel() == null ? other.getHasClinicTel() == null : this.getHasClinicTel().equals(other.getHasClinicTel()))
            && (this.getHasClinicOtherName() == null ? other.getHasClinicOtherName() == null : this.getHasClinicOtherName().equals(other.getHasClinicOtherName()))
            && (this.getDoctorPhotoPath() == null ? other.getDoctorPhotoPath() == null : this.getDoctorPhotoPath().equals(other.getDoctorPhotoPath()))
            && (this.getPracticeArea() == null ? other.getPracticeArea() == null : this.getPracticeArea().equals(other.getPracticeArea()))
            && (this.getOfflineReason() == null ? other.getOfflineReason() == null : this.getOfflineReason().equals(other.getOfflineReason()))
            && (this.getOnlineDate() == null ? other.getOnlineDate() == null : this.getOnlineDate().equals(other.getOnlineDate()))
            && (this.getOfflineDate() == null ? other.getOfflineDate() == null : this.getOfflineDate().equals(other.getOfflineDate()))
            && (this.getPracticeAreaCopy1() == null ? other.getPracticeAreaCopy1() == null : this.getPracticeAreaCopy1().equals(other.getPracticeAreaCopy1()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getDoctorName() == null) ? 0 : getDoctorName().hashCode());
        result = prime * result + ((getDoctorGender() == null) ? 0 : getDoctorGender().hashCode());
        result = prime * result + ((getDoctorPhoto() == null) ? 0 : getDoctorPhoto().hashCode());
        result = prime * result + ((getMedicalLicenseNo() == null) ? 0 : getMedicalLicenseNo().hashCode());
        result = prime * result + ((getMedicalLicensePath() == null) ? 0 : getMedicalLicensePath().hashCode());
        result = prime * result + ((getMedicalPracticingNo() == null) ? 0 : getMedicalPracticingNo().hashCode());
        result = prime * result + ((getMedicalPracticingPath() == null) ? 0 : getMedicalPracticingPath().hashCode());
        result = prime * result + ((getDoctorProperty() == null) ? 0 : getDoctorProperty().hashCode());
        result = prime * result + ((getHighestEducation() == null) ? 0 : getHighestEducation().hashCode());
        result = prime * result + ((getHighestEducationPath() == null) ? 0 : getHighestEducationPath().hashCode());
        result = prime * result + ((getGraduateCollege() == null) ? 0 : getGraduateCollege().hashCode());
        result = prime * result + ((getMedicineTitle() == null) ? 0 : getMedicineTitle().hashCode());
        result = prime * result + ((getMedicineTitlePath() == null) ? 0 : getMedicineTitlePath().hashCode());
        result = prime * result + ((getDiagnosisTypeCode1() == null) ? 0 : getDiagnosisTypeCode1().hashCode());
        result = prime * result + ((getDiagnosisType1() == null) ? 0 : getDiagnosisType1().hashCode());
        result = prime * result + ((getIsAllDiagnosis() == null) ? 0 : getIsAllDiagnosis().hashCode());
        result = prime * result + ((getPracticeScope() == null) ? 0 : getPracticeScope().hashCode());
        result = prime * result + ((getPracticeBeginDate() == null) ? 0 : getPracticeBeginDate().hashCode());
        result = prime * result + ((getWorkingTime() == null) ? 0 : getWorkingTime().hashCode());
        result = prime * result + ((getWorkingTimeRemark() == null) ? 0 : getWorkingTimeRemark().hashCode());
        result = prime * result + ((getPersonalIntroduce() == null) ? 0 : getPersonalIntroduce().hashCode());
        result = prime * result + ((getGoodArea() == null) ? 0 : getGoodArea().hashCode());
        result = prime * result + ((getIsView() == null) ? 0 : getIsView().hashCode());
        result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
        result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
        result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
        result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getInspectionStatus() == null) ? 0 : getInspectionStatus().hashCode());
        result = prime * result + ((getInspectionDate() == null) ? 0 : getInspectionDate().hashCode());
        result = prime * result + ((getCardType() == null) ? 0 : getCardType().hashCode());
        result = prime * result + ((getCardTypeCode() == null) ? 0 : getCardTypeCode().hashCode());
        result = prime * result + ((getCardPath() == null) ? 0 : getCardPath().hashCode());
        result = prime * result + ((getHasClinic() == null) ? 0 : getHasClinic().hashCode());
        result = prime * result + ((getHasClinicTel() == null) ? 0 : getHasClinicTel().hashCode());
        result = prime * result + ((getHasClinicOtherName() == null) ? 0 : getHasClinicOtherName().hashCode());
        result = prime * result + ((getDoctorPhotoPath() == null) ? 0 : getDoctorPhotoPath().hashCode());
        result = prime * result + ((getPracticeArea() == null) ? 0 : getPracticeArea().hashCode());
        result = prime * result + ((getOfflineReason() == null) ? 0 : getOfflineReason().hashCode());
        result = prime * result + ((getOnlineDate() == null) ? 0 : getOnlineDate().hashCode());
        result = prime * result + ((getOfflineDate() == null) ? 0 : getOfflineDate().hashCode());
        result = prime * result + ((getPracticeAreaCopy1() == null) ? 0 : getPracticeAreaCopy1().hashCode());
        return result;
    }
}