package com.wanjia.dsi.web.user.dao.mapper;

import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.user.model.HtUser;

public interface HtUserMapper extends IBaseDao<HtUser, String> {

	List<HtUser> getUserListByAreaId(HtUser user);

}