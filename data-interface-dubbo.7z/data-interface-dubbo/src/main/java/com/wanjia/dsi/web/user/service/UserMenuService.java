package com.wanjia.dsi.web.user.service;

import java.util.List;


import com.wanjia.dsi.web.user.model.TreeDataModel;
import com.wanjia.dsi.web.user.model.UserMenuBean;
import com.wanjia.common.json.JsonResponse;


public interface UserMenuService {


	
	public JsonResponse<List<TreeDataModel<UserMenuBean>>> getUserList(String sysCode,String userCode);
}
