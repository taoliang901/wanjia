package com.wanjia.dsi.web.cms.activity.model;

import java.io.Serializable;

public class VOMyCollection implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -972766808678358724L;
	private String type; // 类型 ；资讯：A，药品：M ，疾病：D
	private String userId; // 用户id
	private String infoId; // 各个类型统计id; 资讯:activityId;药品:medCode;疾病：diseaseId;
	private String pageSize;
	private String pageNo;
	private long collectionStatistic;  //收藏量

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getInfoId() {
		return infoId;
	}

	public void setInfoId(String infoId) {
		this.infoId = infoId;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	public String getPageNo() {
		return pageNo;
	}

	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}

	public long getCollectionStatistic() {
		return collectionStatistic;
	}

	public void setCollectionStatistic(long collectionStatistic) {
		this.collectionStatistic = collectionStatistic;
	}

}
