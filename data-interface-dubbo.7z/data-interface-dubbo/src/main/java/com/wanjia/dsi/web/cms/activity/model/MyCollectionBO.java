package com.wanjia.dsi.web.cms.activity.model;

import java.io.Serializable;
import java.util.Date;
/**
 * mongodb表对应model
 * @author liuguocai
 *
 */
public class MyCollectionBO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4925770793955250803L;
	private String type;    //类型 ；资讯：A，药品：M ，疾病：D
	private String userId;  //用户id
	private String infoId; //各个类型统计id; 资讯:activityId;药品:medCode;疾病：diseaseId;
	private String source; //设备号或ip
	//yyyy-MM-dd
	private String collectionDate; //日期
	private Date collectionTime; //时间
	private String clientType;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getInfoId() {
		return infoId;
	}
	public void setInfoId(String infoId) {
		this.infoId = infoId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getCollectionDate() {
		return collectionDate;
	}
	public void setCollectionDate(String collectionDate) {
		this.collectionDate = collectionDate;
	}
	public Date getCollectionTime() {
		return collectionTime;
	}
	public void setCollectionTime(Date collectionTime) {
		this.collectionTime = collectionTime;
	}
	public String getClientType() {
		return clientType;
	}
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}

	
}
