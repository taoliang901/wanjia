package com.wanjia.dsi.web.department.model;

import java.io.Serializable;
import java.util.Date;

public class Department implements Serializable {
	private static final long serialVersionUID = 1L;
	private String departmentId;

	private String departmentName;

	private String departmentCode;

	private String departmentDescription;

	private String createUser;

	private Date createDate;

	private String modifyUser;

	private Date modifyDate;

	private String delFlag;

	// 医生
	private String doctorId;

	private String doctorName;
	// 疾病
	private String conditionId;

	private String conditionIdName;

	private String parentId;

	private String parentName;

	// cmsdepartment
	private String cmsDepartmentId;

	private Long publishGroupId;

	private Integer publishFlag;

	private Date publishDate;

	private String orderbyNum;

	private String originalParentId;

	public Department() {
		// TODO Auto-generated constructor stub
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getOriginalParentId() {
		return originalParentId;
	}

	public void setOriginalParentId(String originalParentId) {
		this.originalParentId = originalParentId;
	}

	public String getOrderbyNum() {
		return orderbyNum;
	}

	public void setOrderbyNum(String orderbyNum) {
		this.orderbyNum = orderbyNum;
	}

	public String getCmsDepartmentId() {
		return cmsDepartmentId;
	}

	public void setCmsDepartmentId(String cmsDepartmentId) {
		this.cmsDepartmentId = cmsDepartmentId;
	}

	public Long getPublishGroupId() {
		return publishGroupId;
	}

	public void setPublishGroupId(Long publishGroupId) {
		this.publishGroupId = publishGroupId;
	}

	public Integer getPublishFlag() {
		return publishFlag;
	}

	public void setPublishFlag(Integer publishFlag) {
		this.publishFlag = publishFlag;
	}

	public Date getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getConditionId() {
		return conditionId;
	}

	public void setConditionId(String conditionId) {
		this.conditionId = conditionId;
	}

	public String getConditionIdName() {
		return conditionIdName;
	}

	public void setConditionIdName(String conditionIdName) {
		this.conditionIdName = conditionIdName;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	public String getDepartmentDescription() {
		return departmentDescription;
	}

	public void setDepartmentDescription(String departmentDescription) {
		this.departmentDescription = departmentDescription;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		Department other = (Department) that;
		return (this.getDepartmentId() == null ? other.getDepartmentId() == null : this.getDepartmentId().equals(other.getDepartmentId())) && (this.getDepartmentName() == null ? other.getDepartmentName() == null : this.getDepartmentName().equals(other.getDepartmentName())) && (this.getDepartmentCode() == null ? other.getDepartmentCode() == null : this.getDepartmentCode().equals(other.getDepartmentCode())) && (this.getDepartmentDescription() == null ? other.getDepartmentDescription() == null : this.getDepartmentDescription().equals(other.getDepartmentDescription())) && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser())) && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate())) && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser())) && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate())) && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getDepartmentId() == null) ? 0 : getDepartmentId().hashCode());
		result = prime * result + ((getDepartmentName() == null) ? 0 : getDepartmentName().hashCode());
		result = prime * result + ((getDepartmentCode() == null) ? 0 : getDepartmentCode().hashCode());
		result = prime * result + ((getDepartmentDescription() == null) ? 0 : getDepartmentDescription().hashCode());
		result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
		result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
		result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
		result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
		result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
		return result;
	}
}