package com.wanjia.dsi.sso.util;

/**
 * 二维码相关接口返回的错误代码
 * 
 * @author LUOXIAOJUN640
 *
 */
public class QRCodeErrorCode {

	// 参数非法
	public static String INVALID_PARA = "101";

	// 二维码已过期
	public static String QRCODE_EXPIRED = "102";

	// 二维码登录时，无效的用户ID
	public static String QRCODE_LOGIN_INVALID_CASUUID = "103";

	// 二维码扫描绑定时，消息发送失败
	public static String QRCODE_LOGIN_NOTICE_FAILED = "104";
}
