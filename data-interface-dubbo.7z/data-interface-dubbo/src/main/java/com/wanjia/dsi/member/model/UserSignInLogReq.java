package com.wanjia.dsi.member.model;

import java.io.Serializable;

import com.wanjia.dsi.member.util.UserSignInSource;
import com.wanjia.dsi.member.util.UserSignInType;

/**
 * 用户积分日志查询接口
 * 
 * @author LUOXIAOJUN640
 *
 */
public class UserSignInLogReq implements Serializable {
	private static final long serialVersionUID = 3722058634240971923L;

	// 用户ID
	private String userId;

	// 日志记录的开始日期(如：2016-09-11)
	private String startDate;

	// 日志记录的开结束日期(如：2016-09-11)
	private String endDate;

	// 签到类型
	private UserSignInType signInType;

	// 签到来源
	private UserSignInSource source;

	// 排序字段
	private String orderField;

	// 排序方式(desc或者asc)
	private String orderDirection;

	public String getUserId() {
		return userId;
	}

	public String getStartDate() {
		return startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public UserSignInType getSignInType() {
		return signInType;
	}

	public UserSignInSource getSource() {
		return source;
	}

	public String getOrderField() {
		return orderField;
	}

	public String getOrderDirection() {
		return orderDirection;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setSignInType(UserSignInType signInType) {
		this.signInType = signInType;
	}

	public void setSource(UserSignInSource source) {
		this.source = source;
	}

	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}

	public void setOrderDirection(String orderDirection) {
		this.orderDirection = orderDirection;
	}

}