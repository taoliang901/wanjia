package com.wanjia.dsi.web.clinic.model.RG;

import java.io.Serializable;

public class RGCertificates implements Serializable{

	private static final long serialVersionUID = -8318546163756636625L;

	/**
	 * 证件类型： 	1-企业营业执照,2-药品经营（生产）许可证,3-GSP证书,4-组织机构代码证,
	 * 				5-税务登记证,6-医疗器械经营许可证,7-食品流通许可证,8-身份证,
	 * 				9-法人授权委托书,10-其他,11-开户许可证,12-GMP证书,
	 * 				13-医疗机构执业许可证,14-药品经营质量保证协议,15-合格供货方档案表,16-供货企业质量保证体系调查表,
	 * 				17-出库单样本表,18-毒麻精神药品类经营批复件,19-印章印模（鲜章）,20-税票样本
	 */
	private int epId;
	
	private int epType;		
	
	private String epNo;		//证件号码
	
	private String epPic;		//图片地址
	
	private String epStartTime;	//证件有效期开始时间
	
	private String epEndTime;	//证件有效期结束时间
	
	private int eId;			//诊所ID
	
	private String bucket_key;
	
	private String epAddTime;
	
	private String epTypeName;

	public int getEpId() {
		return epId;
	}

	public void setEpId(int epId) {
		this.epId = epId;
	}

	public int getEpType() {
		return epType;
	}

	public void setEpType(int epType) {
		this.epType = epType;
	}

	public String getEpNo() {
		return epNo;
	}

	public void setEpNo(String epNo) {
		this.epNo = epNo;
	}

	public String getEpPic() {
		return epPic;
	}

	public void setEpPic(String epPic) {
		this.epPic = epPic;
	}

	public String getEpStartTime() {
		return epStartTime;
	}

	public void setEpStartTime(String epStartTime) {
		this.epStartTime = epStartTime;
	}

	public String getEpEndTime() {
		return epEndTime;
	}

	public void setEpEndTime(String epEndTime) {
		this.epEndTime = epEndTime;
	}

	public int geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId = eId;
	}

	public String getBucket_key() {
		return bucket_key;
	}

	public void setBucket_key(String bucket_key) {
		this.bucket_key = bucket_key;
	}

	public String getEpAddTime() {
		return epAddTime;
	}

	public void setEpAddTime(String epAddTime) {
		this.epAddTime = epAddTime;
	}

	public String getEpTypeName() {
		return epTypeName;
	}

	public void setEpTypeName(String epTypeName) {
		this.epTypeName = epTypeName;
	}
	
}
