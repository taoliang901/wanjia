package com.wanjia.dsi.web.hyPerson.model;

import java.io.Serializable;
import java.util.List;

import com.wanjia.dsi.web.clinic.model.ClinicInfo;

public class VOClinicInfo extends ClinicInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4249149916224574373L;

	private String relationStatus; // 关联关系代码

	private String dictDescription; // 关联关系名称

	private String priorityShow; // 是否优先显示 默认执业点 0：是优先展示，1：不是优先展示

	private String doctorId; // 医生id

	private String mapId; // map表id

	private String auditResult;  //认证结果代码
	
	private String parentAccountId; // 子诊所的总账号ID
	
	private List<String> parentAccountIdList; //存放子诊所对应的总账号id
	
	public String getParentAccountId() {
		return parentAccountId;
	}

	public void setParentAccountId(String parentAccountId) {
		this.parentAccountId = parentAccountId;
	}

	public String getRelationStatus() {
		return relationStatus;
	}

	public void setRelationStatus(String relationStatus) {
		this.relationStatus = relationStatus;
	}

	public String getDictDescription() {
		return dictDescription;
	}

	public void setDictDescription(String dictDescription) {
		this.dictDescription = dictDescription;
	}

	public String getPriorityShow() {
		return priorityShow;
	}

	public void setPriorityShow(String priorityShow) {
		this.priorityShow = priorityShow;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}

	public String getMapId() {
		return mapId;
	}

	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	public String getAuditResult() {
		return auditResult;
	}

	public void setAuditResult(String auditResult) {
		this.auditResult = auditResult;
	}

	public List<String> getParentAccountIdList() {
		return parentAccountIdList;
	}

	public void setParentAccountIdList(List<String> parentAccountIdList) {
		this.parentAccountIdList = parentAccountIdList;
	}

}