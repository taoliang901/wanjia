package com.wanjia.dsi.web.clinic.model.RG;

import java.io.Serializable;

public class RGHttpResponseBody<T> implements Serializable {

	private static final long serialVersionUID = 5573220309343484410L;


	private String code;				//消息返回码  000000: 成功
	
	private String message;				//消息返回描述
	
	private T result;	//业务处理结果

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public T getResult() {
		return result;
	}

	public void setResult(T result) {
		this.result = result;
	}
	
	
	
}
