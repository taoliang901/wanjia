package com.wanjia.dsi.web.user.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.user.model.UserMenuBean;







public interface UserMenuMapper  {

	
	public List<UserMenuBean> queryMenuResourceBeanByUserCode(Map<String,Object> map);
			
	public List<UserMenuBean> queryParentMenuByUserCode(Map<String,Object> map);
}