package com.wanjia.dsi.web.hyPerson.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.VOHyUserInfoExtra;

public interface VOHyUserInfoExtraService {
	
	JsonResponse<List<VOHyUserInfoExtra>> getHyUserInfoByTime(VOHyUserInfoExtra voHyUserInfoExtra);
}
