package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.hyPerson.model.VOClinicInfo;


public interface VOClinicInfoMapper extends IBaseDao {

	/**
	 * 获取诊所列表，包含关联关系状态和认证结果（app接口）
	 */
	public List<VOClinicInfo> getClinicList(VOClinicInfo voClinicInfo);
	
	/**defaultFlag 医生信息优先展示（0：是优先展示，1：不是优先展示）
	 * doctorId
	 * clinicId
	 * 设置医生的默认执业点（app接口）
	 */
	public void updateDefaultClinic(VOClinicInfo voClinicInfo);
	
	/**defaultFlag 医生信息优先展示（0：是优先展示，1：不是优先展示）
	 * mapId map表id
	 * 设置医生的默认执业点（app接口）
	 * 
	 */
	public void updateDefaultClinicByMapId(VOClinicInfo voClinicInfo);
	
	/**
	 * 查询医生所在诊所的总诊所id
	 * @param doctorId
	 * @return
	 */
	public List<String> getParentIdByDoctorId(VOClinicInfo voClinicInfo);
	
	/**
	 * 通过诊所名称模糊查询诊所
	 * @param doctorId
	 * @return
	 */
	public List<VOClinicInfo> getClinicListByName(VOClinicInfo voClinicInfo);
	
	
	/**
	 * 查询医生为关联的诊所和医生诊所对应总诊所下的所有子诊所，不包括已经关联的诊所
	 * @param doctorId
	 * @return
	 */
	public List<VOClinicInfo> getClinicListBeyondRelated(VOClinicInfo voClinicInfo);
}