package com.wanjia.dsi.web.clinic.dao.mapper;

import com.wanjia.dsi.web.clinic.model.ClinicYear;

public interface ClinicYearMapper {
	
    int deleteByPrimaryKey(Integer id);

    int insert(ClinicYear record);

    int insertSelective(ClinicYear record);

    ClinicYear selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ClinicYear record);

    int updateByPrimaryKey(ClinicYear record);

    /**
     * 根据诊所Id查询
     * @param clinicId
     * @return
     */
	ClinicYear getClinicYearByClinicId(String clinicId);
}