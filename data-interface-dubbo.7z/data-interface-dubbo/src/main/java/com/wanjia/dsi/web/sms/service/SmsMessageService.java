package com.wanjia.dsi.web.sms.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.sms.model.SmsMessage;

public interface SmsMessageService {
	/**
	 * 根据手机号查询该手机近三天的注册短信信息
	 * 
	 * @param phone
	 * @return
	 */
	public JsonResponse<List<SmsMessage>> findMessageByPhone(String phone);
}
