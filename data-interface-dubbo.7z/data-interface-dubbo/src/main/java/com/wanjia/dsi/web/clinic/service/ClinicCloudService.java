package com.wanjia.dsi.web.clinic.service;

import com.wanjia.common.json.JsonResponse;

public interface ClinicCloudService {
	
	/**
	 * 三星认证通过的诊所根据clinicId自动开通云诊所和赠送产品包
	 * @param clinicId			诊所ID
	 * @param clinicType		诊所类别编码
	 * @param departmentId		科室ID
	 * @param content			模板内容
	 * @return
	 */
	public JsonResponse<Void> doAutoOpenCloudClinic(String clinicId, String clinicType, String departmentId, String content);

	/**
	 * 诊所报名申请开通云诊所
	 * @param clinicId			诊所ID
	 * @return
	 */
	JsonResponse<Void> applyClinicCloud(String clinicId);
	/**
	 * 是否首次申请云诊所  app接口
	 * @param clinicId 诊所Id 必填
	 * @return true:首次申请云诊所；false :非首次申请云诊所
	 */
	
	JsonResponse<Boolean> isClinicCloud(String clinicId);
}
