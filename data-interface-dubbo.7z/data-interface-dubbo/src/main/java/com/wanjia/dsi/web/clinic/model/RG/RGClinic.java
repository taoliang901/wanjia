package com.wanjia.dsi.web.clinic.model.RG;

import java.io.Serializable;
import java.util.List;

public class RGClinic implements Serializable{
	
	private static final long serialVersionUID = -3976578537209370667L;

	private String eName;			//诊所名称
	
	private int eId;				//诊所ID
	
	private String eAddress;		//详细地址
	
	private String eContactor;		//联系人
			
	private String eLegal;			//法人名称
	
	private String eLegalNo;		//法人身份证号
	
	private String eLicenseNo;		//工商注册号
	
	private String eMobile;			//联系人手机号
	
	private int eProvince;		//省, 行政区域标准编码
	
	private int eCity;			//市, 行政区域标准编码
	
	private int eRegion;			//区, 行政区域标准编码
	
	private String eTel;			//联系人固话
	
	private double eLongitude;		//经度
	
	private double eLatitude;		//纬度
	
	private String eUpdated;		
	
	private List<RGClinic> epList;	//资质集合
	
	private String isErp;
	
	private String roleId;

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public int geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId = eId;
	}

	public String geteAddress() {
		return eAddress;
	}

	public void seteAddress(String eAddress) {
		this.eAddress = eAddress;
	}

	public String geteContactor() {
		return eContactor;
	}

	public void seteContactor(String eContactor) {
		this.eContactor = eContactor;
	}

	public String geteLegal() {
		return eLegal;
	}

	public void seteLegal(String eLegal) {
		this.eLegal = eLegal;
	}

	public String geteLegalNo() {
		return eLegalNo;
	}

	public void seteLegalNo(String eLegalNo) {
		this.eLegalNo = eLegalNo;
	}

	public String geteLicenseNo() {
		return eLicenseNo;
	}

	public void seteLicenseNo(String eLicenseNo) {
		this.eLicenseNo = eLicenseNo;
	}

	public String geteMobile() {
		return eMobile;
	}

	public void seteMobile(String eMobile) {
		this.eMobile = eMobile;
	}

	public String geteTel() {
		return eTel;
	}

	public void seteTel(String eTel) {
		this.eTel = eTel;
	}

	public double geteLongitude() {
		return eLongitude;
	}

	public void seteLongitude(double eLongitude) {
		this.eLongitude = eLongitude;
	}

	public double geteLatitude() {
		return eLatitude;
	}

	public void seteLatitude(double eLatitude) {
		this.eLatitude = eLatitude;
	}

	public String geteUpdated() {
		return eUpdated;
	}

	public void seteUpdated(String eUpdated) {
		this.eUpdated = eUpdated;
	}

	public List<RGClinic> getEpList() {
		return epList;
	}

	public void setEpList(List<RGClinic> epList) {
		this.epList = epList;
	}

	public String getIsErp() {
		return isErp;
	}

	public void setIsErp(String isErp) {
		this.isErp = isErp;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public int geteProvince() {
		return eProvince;
	}

	public void seteProvince(int eProvince) {
		this.eProvince = eProvince;
	}

	public int geteCity() {
		return eCity;
	}

	public void seteCity(int eCity) {
		this.eCity = eCity;
	}

	public int geteRegion() {
		return eRegion;
	}

	public void seteRegion(int eRegion) {
		this.eRegion = eRegion;
	}

	
	
	
}
