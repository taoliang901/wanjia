package com.wanjia.dsi.web.callCenter.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.callCenter.model.CcSurvey;



/**
 * This element is automatically generated on 16-8-5 上午11:17, do not modify. <br>
 * Service interface
 */
public interface CcSurveyService extends IBaseService<CcSurvey, String> {
    
    
    public List<CcSurvey> findSurveyList(Map<String, Object> map);
    
    public JsonResponse<CcSurvey> findOvertimeSurvey();
}