package com.wanjia.dsi.web.clinic.dao.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.clinic.model.ClinicInfo;

public interface ClinicInfoMapper extends IBaseDao<ClinicInfo,String> {
	
	
	List<ClinicInfo> getClinicInfoByTime(ClinicInfo clinicInfo);
	
	List<ClinicInfo> findByDoctorMobile(Map<String, Object> map);

	ClinicInfo selectByResiterId(String registerId);

	void updateAddress(ClinicInfo clinicInfo);

	ClinicInfo findClinicInfoById(String id);
	
	public List<Map<String,Object>> findClinicByRegisterInfo(Map<String,Object> param);

	ClinicInfo selectByClinicId(String clinicId);

	List<ClinicInfo> selectByPracticingLicenseNo(String practicingLicenseNo);

	ClinicInfo findClinicInfoByRegisterId(String registerId);
	List<String> selectChildClinicIds(String clinicId);}