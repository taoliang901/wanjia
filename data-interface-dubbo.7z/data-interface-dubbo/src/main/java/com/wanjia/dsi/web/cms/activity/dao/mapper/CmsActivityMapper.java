package com.wanjia.dsi.web.cms.activity.dao.mapper;


import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.cms.activity.model.CmsActivity;


public interface CmsActivityMapper extends IBaseDao {
	
	List<CmsActivity> findByPageConfigId(String pageConfigId);
	
	
	
	
}