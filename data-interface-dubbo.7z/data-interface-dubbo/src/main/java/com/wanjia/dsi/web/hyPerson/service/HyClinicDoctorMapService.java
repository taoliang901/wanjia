package com.wanjia.dsi.web.hyPerson.service;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.ClinicDoctorMap;
import com.wanjia.dsi.web.hyPerson.model.HyClinicInfoApproval;
import com.wanjia.dsi.web.hyPerson.vo.HyClinicDoctorMapVO;

public interface HyClinicDoctorMapService {

	/**
	 * 查询医生诊所关联信息（会员端使用）
	 * 
	 * @param ClinicDoctorMap
	 *            clinicDoctorMap
	 * @return
	 */
	JsonResponse<List<HyClinicDoctorMapVO>> getDoctorMapList(ClinicDoctorMap clinicDoctorMap);

	/**
	 * 新增医生诊所关联信息（诊所端和会员端使用&&网关调用）
	 * 
	 * @param ClinicDoctorMap
	 *            clinicDoctorMap
	 * @return
	 */
	JsonResponse<Long> addDoctorMap(ClinicDoctorMap clinicDoctorMap);

	/**
	 * 编辑医生诊所关联信息（会员端使用&&网关调用）
	 * 
	 * @param ClinicDoctorMap
	 *            clinicDoctorMap
	 * @return
	 */
	JsonResponse<Boolean> editDoctorMap(ClinicDoctorMap clinicDoctorMap);

	/**
	 * 医生端查询关联信息（会员端使用）
	 * 
	 * @param ClinicDoctorMap
	 *            clinicDoctorMap
	 * @return
	 */
	JsonResponse<List<HyClinicDoctorMapVO>> getDoctorMapForHy(String doctorId, List<String> statusList);

	/**
	 * 医生是否可关联该诊所（会员端使用）
	 * 
	 * @param String
	 *            doctorId
	 * @param String
	 *            clinicId
	 * @return
	 */
	JsonResponse<Boolean> doctorCanRelation(String mapId, String doctorId, String clinicId);

	/**
	 * 根据医生ID查询已经关联的诊所信息,只返回前台显示的（网站使用）
	 * 
	 * @param String
	 *            doctorId
	 * @return
	 */
	JsonResponse<List<HyClinicInfoApproval>> getClinicByDoctorId(String doctorId);

	/**
	 * 检测当前医生是否可与当前诊所建立关联
	 * 
	 */
	JsonResponse<Void> validateClinicDoctorMap(String doctorId, String clinicId);

	/**
	 * 根据诊所ID与关联状态，统计关联数量
	 * 
	 */
	JsonResponse<Integer> countByStatus(String clinicId, String relationStatus);

	/**
	 * 根据属性，获取医生与诊所的关联医生
	 * 
	 */
	JsonResponse<PageInfo<HyClinicDoctorMapVO>> selectClinicDoctorMapByProperties(Map<String, Object> map, int pageSize,
			int pageNum);
	
	/**
	 * 根据属性，获取医生与诊所的关联医生
	 * 
	 */
	JsonResponse<List<HyClinicDoctorMapVO>> selectClinicDoctorMapByProperties(Map<String, Object> map);
	
	/**
	 * 根据mapid获取clinicDocotrMap实体类
	 * @param id
	 * @return
	 */
	JsonResponse<ClinicDoctorMap> findById(String id);
	/**
	 * 设置设置是否展示在医生主页（app接口）
	 * @param doctorId
	 * @param mapId
	 * @param userId
	 * @param isShow
	 * @return
	 */
	JsonResponse<String> updateIsShowOnDoctor(String doctorId, String mapId, String userId,String isShow);
}
