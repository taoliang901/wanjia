package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;

public class PropertyModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1794477810221362730L;

	private String id; // 诊所id
	private String property; // 诊所对应的一个属性,为list转换成map减少数据传输量

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

}
