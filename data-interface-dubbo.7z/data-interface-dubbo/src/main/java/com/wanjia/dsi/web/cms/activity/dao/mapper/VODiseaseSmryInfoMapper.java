package com.wanjia.dsi.web.cms.activity.dao.mapper;

import com.wanjia.dsi.web.cms.activity.model.DiseaseSmryInfo;
import com.wanjia.dsi.web.cms.activity.model.VODiseaseSmryInfo;

import java.util.List;

public interface VODiseaseSmryInfoMapper {

    List<DiseaseSmryInfo> getDiseaseSmryInfo(List<String> infoIdList);
    
    public List<String> getAllDiseaseId(VODiseaseSmryInfo vodiseaseSmryInfo);
}