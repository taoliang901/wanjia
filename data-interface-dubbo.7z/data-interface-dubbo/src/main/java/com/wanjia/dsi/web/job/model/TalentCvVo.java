package com.wanjia.dsi.web.job.model;

import java.io.Serializable;
import java.util.Date;

public class TalentCvVo extends TalentCv implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// 查询时数据库的当前系统时间
	private Date currentDate;

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
}