package com.wanjia.dsi.web.cms.department.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.cms.department.model.CmsDepartmentCriteria;

public interface CmsDepartmentCriteriaMapper extends IBaseDao {
	 /**
     * 查询最近的一个group_id
     * @param criteria
     * @return
     */
    Long findPublishGroupId(CmsDepartmentCriteria criteria);
    /**
     * 
     * @param criteria
     * @return
     */
    List<CmsDepartmentCriteria> selectBySelective(CmsDepartmentCriteria criteria);
    
    
    List<CmsDepartmentCriteria> getCmsDepartmentByTime(Map<String,Object> map);
}