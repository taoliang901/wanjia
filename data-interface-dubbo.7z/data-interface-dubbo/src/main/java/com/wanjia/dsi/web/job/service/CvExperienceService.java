package com.wanjia.dsi.web.job.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job.model.TalentCvExperience;

public interface CvExperienceService {

	/**
	 * 获取工作经历列表
	 * 
	 * @param String memberId
	 * @return
	 */
	public JsonResponse<List<TalentCvExperience>> getCvExperienceList(String cvId,String expId);

	/**
	 * 修改工作经历
	 * 
	 * @param TalentCvExperience cvExperience
	 * @return
	 */
	public JsonResponse<Void> modifyCvExperience(TalentCvExperience cvExperience);

	/**
	 * 新增工作经历
	 * 
	 * @param TalentCvExperience cvExperience
	 * @param reponse
	 * @return
	 */
	public JsonResponse<Void> addCvExperience(TalentCvExperience cvExperience);
	
	/**
	 * 获取工作经历列表
	 * 
	 * @param String memberId
	 * @return
	 */
	public JsonResponse<List<TalentCvExperience>> getCvExperienceTransDictList(String cvId,String expId);
}
