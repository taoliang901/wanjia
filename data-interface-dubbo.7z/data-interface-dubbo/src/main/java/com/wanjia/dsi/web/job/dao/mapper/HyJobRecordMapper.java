package com.wanjia.dsi.web.job.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.job.model.HyJobRecord;
import com.wanjia.dsi.web.job.model.TalentCvVo;

// 会员查询投递记录
public interface HyJobRecordMapper {
	
	/**
	 * 查询投递记录
	 * 
	 * @param HyJobRecord hyJobRecord
	 * @return
	 */
	public List<HyJobRecord> getHyJobRecordList(HyJobRecord hyJobRecord);
	
	/**
	 * 查询诊所查看简历记录
	 * 
	 * @param HyJobRecord hyJobRecord
	 * @return
	 */
	public List<HyJobRecord> getClinicViewList(HyJobRecord hyJobRecord);
	
	/**
	 * 查询用户简历
	 * 
	 * @param Map<String, Object> param
	 * @return
	 */
	public List<TalentCvVo> selectCvByMap(Map<String, Object> param);
}