package com.wanjia.dsi.web.sms.dao.mapper;

import java.util.List;

import com.wanjia.dsi.web.sms.model.SmsLogInfo;

public interface SmsLogInfoMapper {

	public List<SmsLogInfo> findMessageByPhone(String phone);
}