package com.wanjia.dsi.member.dao.mapper;

import com.wanjia.dsi.member.model.HyUserLoginCheck;

public interface HyUserLoginCheckMapper {
    int deleteByPrimaryKey(String memberId);

    int insert(HyUserLoginCheck record);

    int insertSelective(HyUserLoginCheck record);

    HyUserLoginCheck selectByPrimaryKey(String memberId);

    int updateByPrimaryKeySelective(HyUserLoginCheck record);

    int updateByPrimaryKey(HyUserLoginCheck record);
}