package com.wanjia.dsi.web.hyPerson.vo.hy;

import com.wanjia.dsi.web.hyPerson.model.HyUserInfo;

/**
 * 拓展userInfo数据
 * @author peichunle
 *
 */
public class VoHyUserInfo extends HyUserInfo{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3302808580154565430L;


	//手机号
	private String mobile;


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	
}
