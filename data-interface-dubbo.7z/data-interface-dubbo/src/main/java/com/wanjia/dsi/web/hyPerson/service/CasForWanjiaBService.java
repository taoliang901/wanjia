//package com.wanjia.dsi.web.hyPerson.service;
//
//import com.pahaoche.member.entity.po.Result;
//import com.pahaoche.member.entity.po.User;
//import com.pahaoche.member.entity.po.VerificationCode;
//import com.wanjia.common.json.JsonResponse;
//
///**
// * CAS相关服务【B端】
// */
//public interface CasForWanjiaBService {
//
//	/**
//	 * 生成短信验证码，并发送至手机
//	 */
//	JsonResponse<Result> sendMoblieCodeMsg(VerificationCode verificationCode);
//
//	/**
//	 * 校验短信验证码
//	 */
//	JsonResponse<Result> checkSMSValidateCode(VerificationCode verificationCode);
//
//	/**
//	 * 忘记密码后进行重置
//	 */
//	JsonResponse<Result> modifyPasswordbyMo(User userInfo);
//}
