package com.wanjia.dsi.sso.util;


import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.Provider;
import java.security.PublicKey;
import java.security.spec.KeySpec;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Hex;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import sun.misc.BASE64Encoder;

@SuppressWarnings("restriction")
public class RSA2 {
	private static final String ALGORITHOM = "RSA";
	private static final Provider DEFAULT_PROVIDER = new BouncyCastleProvider();

	public static PublicKey genPublicKey(String modulus, String exponent) throws Exception {
		KeySpec publicKeySpec = new RSAPublicKeySpec(new BigInteger(modulus, 16), new BigInteger(exponent, 16));
		KeyFactory factory = KeyFactory.getInstance(ALGORITHOM);
		return factory.generatePublic(publicKeySpec);
	}

	public static byte[] encrypt(Key key, byte[] data) throws Exception {
		Cipher ci = Cipher.getInstance(ALGORITHOM, DEFAULT_PROVIDER);
		ci.init(Cipher.ENCRYPT_MODE, key);
		return ci.doFinal(data);
	}

	public static String encrypt(Key key, String plaintext) throws Exception {
		if (key == null || plaintext == null) {
			return null;
		}

		byte[] data = new BASE64Encoder().encode(plaintext.getBytes()).getBytes();
		byte[] enData = encrypt(key, data);
		return new String(Hex.encodeHex(enData));
	}

	public static void main(String[] args) throws Exception {
		// modulus
		// 开发：91BD4192E7531F50B3E89F6563A0B4AE751E6EC977DA9F2DD124C75362F664C9BF9E028143F3539A2A22086D0A8DCA93AD927E4273FA2484349C1F6FE8B73D4C5C734AFFB9C13BD1FBE3F56BEA002722C3D5CC06081AE188A15DC81CA8234F1EA42109EDB794F0C764D24645CC32BFB928C446595ED62DEB044ACC4C64E78A2F
		// 测试：E61B28C3DF81923D491CB4D0BCDA1CB4E2B7B44D0999D8FC59638F5D1FCEBB06F48AD1B4E7B192F511754F11E9AE51AB046B4CF9DE04EFC8D52DCAF2D539BCDF03877E37D3F5D36C34EECC6E172886BCAE4AF5A6735CD7F8D32904084774E7CD31B56312CC0D6FCBFD14FB6D19EBE8E5E224F615732EB87B8488894AA08F612F
		// 生产：A56E6F9AEE316E6BED0EAE1E3B97CE901E21541390A5C9FE5F03E99A480191583709AD085793DCF1986BF7C59CB7C1AD4D1A8E278FFDF2311B4BDA01586CE382C04C4B74D4312CCEFE967E52E6DBF553B96AE0999ECA5CC39F7C8437470244C5EDC6E045DC39F924F7077BD2889DDE6DB6AF4ECF347D52A48AE135B2C8A7400D
		String modulus = "A56E6F9AEE316E6BED0EAE1E3B97CE901E21541390A5C9FE5F03E99A480191583709AD085793DCF1986BF7C59CB7C1AD4D1A8E278FFDF2311B4BDA01586CE382C04C4B74D4312CCEFE967E52E6DBF553B96AE0999ECA5CC39F7C8437470244C5EDC6E045DC39F924F7077BD2889DDE6DB6AF4ECF347D52A48AE135B2C8A7400D";

		String exponent = "10001";
		PublicKey pubKey = genPublicKey(modulus, exponent);
		// 时间\n\nUM账号\n密码
		String orgData = System.currentTimeMillis() + "\n\nLUOXIAOJUN640\nJustin_0501";
		String ciphertext = encrypt(pubKey, orgData);
		System.out.println("加密结果：" + ciphertext);

	}
}
