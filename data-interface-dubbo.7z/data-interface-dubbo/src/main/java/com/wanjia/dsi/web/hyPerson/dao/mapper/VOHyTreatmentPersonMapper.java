package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;

import com.wanjia.dsi.product.vo.VOPrdKucun;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;
import com.wanjia.dsi.web.hyPerson.model.VOHyTreatmentPerson;

public interface VOHyTreatmentPersonMapper {
	
    //通过电话查询对应userId
    public List<String> getUserIdByMobile(String mobile);
    // String prdId,List<String> userIds
 // 通过产品id和就诊人对应userid交集
    public List<String> getUserIdByPrdId(VOHyTreatmentPerson voHyTreatmentPerson);

  //通过电话查询对应userId和mobile
    public List<HyTreatmentPerson> getTreatmentPersonByUserId(VOHyTreatmentPerson voHyTreatmentPerson);
    
    public List<HyTreatmentPerson> getOnlyTreatmentPersonByUserIds(VOPrdKucun voPrdKucun);
}