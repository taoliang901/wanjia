package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;

public class Picture implements Serializable {

	
	//门诊外观
	private String businessLicensePath;
	private String practicingLicensePath;
	private String organizationPath;
	private String taxRegistrationPath;
	private String civilAffairsPath;
	private String authorizeMagPath;
	
	private String clinicPhotoPath;
	private String clinicFacadeName;
	private String clinicWaitingName;
	private String clinicMedLabName;
	private String clinicOtherName;
	
	private String practicingLicenseF2Path;
	private String practicingLicenseFpath;
	private String radiationDiagnosisPath;
	private String radiationSaftyPath;
	private String legalRepresentativeIda;
	private String legalRepresentativeIdb;
	
	public Picture() {
		// TODO Auto-generated constructor stub
	}

	public String getBusinessLicensePath() {
		return businessLicensePath;
	}

	public void setBusinessLicensePath(String businessLicensePath) {
		this.businessLicensePath = businessLicensePath;
	}

	public String getPracticingLicensePath() {
		return practicingLicensePath;
	}

	public void setPracticingLicensePath(String practicingLicensePath) {
		this.practicingLicensePath = practicingLicensePath;
	}

	public String getOrganizationPath() {
		return organizationPath;
	}

	public void setOrganizationPath(String organizationPath) {
		this.organizationPath = organizationPath;
	}

	public String getTaxRegistrationPath() {
		return taxRegistrationPath;
	}

	public void setTaxRegistrationPath(String taxRegistrationPath) {
		this.taxRegistrationPath = taxRegistrationPath;
	}

	public String getCivilAffairsPath() {
		return civilAffairsPath;
	}

	public void setCivilAffairsPath(String civilAffairsPath) {
		this.civilAffairsPath = civilAffairsPath;
	}

	public String getAuthorizeMagPath() {
		return authorizeMagPath;
	}

	public void setAuthorizeMagPath(String authorizeMagPath) {
		this.authorizeMagPath = authorizeMagPath;
	}

	public String getClinicPhotoPath() {
		return clinicPhotoPath;
	}

	public void setClinicPhotoPath(String clinicPhotoPath) {
		this.clinicPhotoPath = clinicPhotoPath;
	}

	public String getClinicFacadeName() {
		return clinicFacadeName;
	}

	public void setClinicFacadeName(String clinicFacadeName) {
		this.clinicFacadeName = clinicFacadeName;
	}

	public String getClinicWaitingName() {
		return clinicWaitingName;
	}

	public void setClinicWaitingName(String clinicWaitingName) {
		this.clinicWaitingName = clinicWaitingName;
	}

	public String getClinicMedLabName() {
		return clinicMedLabName;
	}

	public void setClinicMedLabName(String clinicMedLabName) {
		this.clinicMedLabName = clinicMedLabName;
	}

	public String getClinicOtherName() {
		return clinicOtherName;
	}

	public void setClinicOtherName(String clinicOtherName) {
		this.clinicOtherName = clinicOtherName;
	}

	public String getPracticingLicenseF2Path() {
		return practicingLicenseF2Path;
	}

	public void setPracticingLicenseF2Path(String practicingLicenseF2Path) {
		this.practicingLicenseF2Path = practicingLicenseF2Path;
	}

	public String getPracticingLicenseFpath() {
		return practicingLicenseFpath;
	}

	public void setPracticingLicenseFpath(String practicingLicenseFpath) {
		this.practicingLicenseFpath = practicingLicenseFpath;
	}

	public String getRadiationDiagnosisPath() {
		return radiationDiagnosisPath;
	}

	public void setRadiationDiagnosisPath(String radiationDiagnosisPath) {
		this.radiationDiagnosisPath = radiationDiagnosisPath;
	}

	public String getRadiationSaftyPath() {
		return radiationSaftyPath;
	}

	public void setRadiationSaftyPath(String radiationSaftyPath) {
		this.radiationSaftyPath = radiationSaftyPath;
	}

	public String getLegalRepresentativeIda() {
		return legalRepresentativeIda;
	}

	public void setLegalRepresentativeIda(String legalRepresentativeIda) {
		this.legalRepresentativeIda = legalRepresentativeIda;
	}

	public String getLegalRepresentativeIdb() {
		return legalRepresentativeIdb;
	}

	public void setLegalRepresentativeIdb(String legalRepresentativeIdb) {
		this.legalRepresentativeIdb = legalRepresentativeIdb;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
