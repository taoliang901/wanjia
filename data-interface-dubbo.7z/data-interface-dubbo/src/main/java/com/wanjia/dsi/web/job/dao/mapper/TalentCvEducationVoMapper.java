package com.wanjia.dsi.web.job.dao.mapper;

import com.wanjia.dsi.web.job.model.TalentCvEducation;
import com.wanjia.dsi.web.job.model.TalentCvEducationExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TalentCvEducationVoMapper {

    List<TalentCvEducation> selectTransDictByExample(TalentCvEducationExample example);

}