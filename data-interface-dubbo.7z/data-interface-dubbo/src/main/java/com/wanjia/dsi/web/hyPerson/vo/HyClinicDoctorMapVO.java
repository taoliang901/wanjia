package com.wanjia.dsi.web.hyPerson.vo;

import java.io.Serializable;
import com.wanjia.dsi.web.hyPerson.model.ClinicDoctorMap;

public class HyClinicDoctorMapVO extends ClinicDoctorMap implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5654161594703207851L;

	/** 诊所名称 */
	private String clinicName;
	
	/** 诊所状态 */
	private String checkStatus;
	
	/** 医生姓名 */
	private String doctorName;
	
	/** 医生职称 */
	private String medicineTitle;
	
	/** 医生手机号 */
	private String mobile;
	
	/** 医生的CAS_UUID */
	private String doctorCasUuid;
	
	/** 医生的头像 */
	private String doctorPhoto;
	
	/** 医生职业范围 */
	private String practiceArea;
	
	/** 医生诊疗科室 */
	private String diagnosisType1;

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public String getMedicineTitle() {
		return medicineTitle;
	}

	public String getMobile() {
		return mobile;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public void setMedicineTitle(String medicineTitle) {
		this.medicineTitle = medicineTitle;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDoctorCasUuid() {
		return doctorCasUuid;
	}

	public void setDoctorCasUuid(String doctorCasUuid) {
		this.doctorCasUuid = doctorCasUuid;
	}

	public String getDoctorPhoto() {
		return doctorPhoto;
	}

	public void setDoctorPhoto(String doctorPhoto) {
		this.doctorPhoto = doctorPhoto;
	}

	public String getPracticeArea() {
		return practiceArea;
	}

	public String getDiagnosisType1() {
		return diagnosisType1;
	}

	public void setPracticeArea(String practiceArea) {
		this.practiceArea = practiceArea;
	}

	public void setDiagnosisType1(String diagnosisType1) {
		this.diagnosisType1 = diagnosisType1;
	}
}
