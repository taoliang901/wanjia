package com.wanjia.dsi.web.user.model;

import java.io.Serializable;
import java.util.List;

public class TreeDataModel<T> implements Serializable{

	
	private String id;
	private String text;
	private String state;
	private String iconCls;
	private Boolean checked;
	private T attributes;
	private String sysCode;
	
	private List<TreeDataModel<T>> children;
	
	public TreeDataModel(String id,String text){
		this.id = id;
		this.text = text;
	}

	public TreeDataModel(String id, String text, T attributes, List<TreeDataModel<T>> children) {
		super();
		this.id = id;
		this.text = text;
		this.attributes = attributes;
		this.children = children;
	}
	
	public TreeDataModel(String id, String text, String state, String iconCls, Boolean checked,  T attributes, List<TreeDataModel<T>> children) {
		super();
		this.id = id;
		this.text = text;
		this.state = state;
		this.iconCls = iconCls;
		this.checked = checked;
		this.attributes = attributes;
		this.children = children;
	}


	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getIconCls() {
		return iconCls;
	}
	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}
	

	public Boolean getChecked() {
		return checked;
	}

	public void setChecked(Boolean checked) {
		this.checked = checked;
	}

	public T getAttributes() {
		return attributes;
	}

	public void setAttributes(T attributes) {
		this.attributes = attributes;
	}

	public List<TreeDataModel<T>> getChildren() {
		return children;
	}

	public void setChildren(List<TreeDataModel<T>> children) {
		this.children = children;
	}

	public String getSysCode() {
		return sysCode;
	}

	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}
	
}

