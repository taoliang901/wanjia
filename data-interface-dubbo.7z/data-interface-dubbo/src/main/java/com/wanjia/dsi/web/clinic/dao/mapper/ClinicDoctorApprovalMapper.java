package com.wanjia.dsi.web.clinic.dao.mapper;

import com.wanjia.dsi.base.dao.IBaseDao;

public interface ClinicDoctorApprovalMapper extends IBaseDao {
	

}