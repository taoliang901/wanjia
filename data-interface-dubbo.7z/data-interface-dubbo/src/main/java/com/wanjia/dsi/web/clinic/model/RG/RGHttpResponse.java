package com.wanjia.dsi.web.clinic.model.RG;

public class RGHttpResponse<T> {
	private String mac;					
	
	private RGHttpResponseHead head;	//响应体head
	
	private RGHttpResponseBody<T> body;	//响应体body

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public RGHttpResponseHead getHead() {
		return head;
	}

	public void setHead(RGHttpResponseHead head) {
		this.head = head;
	}

	public RGHttpResponseBody<T> getBody() {
		return body;
	}

	public void setBody(RGHttpResponseBody<T> body) {
		this.body = body;
	}

}
