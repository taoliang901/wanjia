package com.wanjia.dsi.cms.page.model;

import java.io.Serializable;
import java.util.Date;

public class PageRecommendInfoCriteria implements Serializable {
    private static final long serialVersionUID = 1L;

    private String pageKey;
    
    private String pageName;

    private String siteKey;
    
    private String siteName;

    private String picSizeKey;

    private String roleKey;
    
    
    private String id;
    
    private String pageId;
    
    private String siteId;
    
    private String siteTypeId;
    
    private String siteType;
    
    private String recordId;
    
    private String recordName;
    
    private String status;
    
    private String delFlag;
    
    private String recommendId;
    
    private Date nowDateTime;

	public String getPageKey() {
		return pageKey;
	}

	public void setPageKey(String pageKey) {
		this.pageKey = pageKey;
	}

	public String getSiteKey() {
		return siteKey;
	}

	public void setSiteKey(String siteKey) {
		this.siteKey = siteKey;
	}

	public String getPicSizeKey() {
		return picSizeKey;
	}

	public void setPicSizeKey(String picSizeKey) {
		this.picSizeKey = picSizeKey;
	}

	public String getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(String roleKey) {
		this.roleKey = roleKey;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getSiteTypeId() {
		return siteTypeId;
	}

	public void setSiteTypeId(String siteTypeId) {
		this.siteTypeId = siteTypeId;
	}

	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRecommendId() {
		return recommendId;
	}

	public void setRecommendId(String recommendId) {
		this.recommendId = recommendId;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public Date getNowDateTime() {
		return nowDateTime;
	}

	public void setNowDateTime(Date nowDateTime) {
		this.nowDateTime = nowDateTime;
	}

	public String getRecordName() {
		return recordName;
	}

	public void setRecordName(String recordName) {
		this.recordName = recordName;
	}
	
}