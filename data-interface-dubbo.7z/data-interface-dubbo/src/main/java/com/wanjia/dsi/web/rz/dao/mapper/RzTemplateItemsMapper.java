package com.wanjia.dsi.web.rz.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.rz.model.Radar;

public interface RzTemplateItemsMapper extends IBaseDao {
	List<Radar> getStandardScore(Map<String,Object> map);
	
	List<Radar> getClinicStandardScore(Map<String,Object> map);
	
	Map<String,Object> getradarItems(Map<String,Object> map);
	
	List<Radar> getTotalRadarItems(Map<String,Object> map);
}