package com.wanjia.dsi.web.hyPerson.service.doctor;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.VOClinicInfo;

public interface HyClinicInfoService {

	/**
	 * 获取医生的默认执业点（app接口）
	 * 
	 * @param doctorId医生id 必填
	 * @return 
	 */
	public JsonResponse<VOClinicInfo> getDefaultClinicByDoctorId(String doctorId);
	
	/**
	 * 设置医生的默认执业点（app接口）
	 * 
	 * @param doctorId 医生id 必填
	 * @param mapId 关联关系表id 必填
	 * @return 
	 */
	public JsonResponse<String> updateDefaultClinic(String doctorId,String mapId,String userId);
/**
 * 通过医生id查询对应关联诊所信息（app接口）
 * @param doctorId
 * @param clinicName 选填
 * @param pageNo
 * @param pageSize
 * @return
 */
	public JsonResponse<PageInfo<VOClinicInfo>>getClinicByDoctorId(String doctorId,String clinicName,String pageNo,String pageSize);
	/**
	 * 通过医生id查询所在诊所对应总账号下的所有诊所（app接口）
	 * @param doctorId 必填
	 * @param pageNo必填
	 * @param pageSize必填
	 * @return
	 */
	public JsonResponse<PageInfo<VOClinicInfo>>getClinicBySubClinic(String doctorId,String pageNo,String pageSize);
	/**
	 * 通过诊所名称查询诊所信息（app接口）
	 * @param clinicName 选填
	 * @param pageNo必填
	 * @param pageSize必填
	 * @return
	 */
	public JsonResponse<PageInfo<VOClinicInfo>>getClinicListByName(String clinicName,String pageNo,String pageSize);
	/**
	 * 设置设置是否展示在医生主页（app接口）
	 * 
	 * @param doctorId 医生id 必填
	 * @param mapId 关联关系表id 必填
	 * @param isShow 是否展示在医生主页 必填  0：展示，1：不展示
	 * @return 
	 */
	public JsonResponse<Void> updateIsShowOnDoctor(String doctorId,String mapId,String userId,String isShow);
}
