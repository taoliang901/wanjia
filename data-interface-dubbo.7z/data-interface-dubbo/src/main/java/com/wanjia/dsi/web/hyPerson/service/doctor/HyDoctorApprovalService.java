package com.wanjia.dsi.web.hyPerson.service.doctor;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.HyClinicDoctorApproval;

/**
 * 查询医生上线信息
 */
public interface HyDoctorApprovalService  {
	/**
	 * 查询医生经历信息
	 * @param String doctorId 医生ID
	 * @return HyUser HyUser 返回会员用户信息(用户名，密码)
	 */
	JsonResponse<HyClinicDoctorApproval> getDoctorOnlineInfo(String doctorId);
}
