package com.wanjia.dsi.web.rz.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.rz.model.RzItemsInfo;

public interface RzItemsMapper extends IBaseDao {
	
	List<RzItemsInfo> searchClinicRzInfo(Map<String,Object> map);
	
	public String countPassItemNum(Map<String, Object> map);
	
	public String countFailItemNum(Map<String, Object> map);
	
	public String countUnusedItemNum(Map<String, Object> map);
	
}