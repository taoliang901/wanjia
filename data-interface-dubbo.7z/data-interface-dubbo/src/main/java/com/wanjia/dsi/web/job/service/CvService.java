package com.wanjia.dsi.web.job.service;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job.model.HyJobRecord;
import com.wanjia.dsi.web.job.model.TalentCv;
import com.wanjia.dsi.web.job.model.TalentCvDetail;
import com.wanjia.dsi.web.job.model.TalentCvVo;
import com.wanjia.dsi.web.job.model.TalentJobRecord;

public interface CvService {

	/**
	 * 获取投递记录列表
	 * 
	 * @param status
	 * @param cVId
	 * @return
	 */
	public JsonResponse<PageInfo<HyJobRecord>> getHyJobRecordList(
			String requestId, String pageNo, String pageSize, String status,
			String cvId);

	/**
	 * 获取投递记录列表(不分页)
	 * 
	 * @param status
	 * @param cVId
	 * @return
	 */
	public JsonResponse<List<HyJobRecord>> getHyJobRecordList(String requestId, String status,String cvId);
	
	/**
	 * 获取诊所查看简历列表记录
	 * 
	 * @param TalentCv
	 *            cv
	 * @return
	 */
	public JsonResponse<PageInfo<HyJobRecord>> getClinicViewList(
			String requestId, String pageNo, String pageSize, String cvId);
	
	
	/**
	 * 获取简历详情
	 * 
	 * @param TalentCv
	 *            cv
	 * @return
	 */
	public JsonResponse<TalentCvDetail> getCvDetailById(String requestId, String cvId);
	
	/**
	 * 获取简历列表
	 * 
	 * @param TalentCv
	 *            cv
	 * @return
	 */
	public JsonResponse<List<TalentCvVo>> getCvList(String requestId, Map<String, Object> param);

	/**
	 * 新增简历OR更新简历
	 * 
	 * @param TalentCv
	 *            cv
	 * @return
	 */
	public JsonResponse<Long> modifyCv(String requestId, TalentCv cv);

	/**
	 * 删除简历
	 * 
	 * @param Long
	 *            Id
	 * @return
	 */
	public JsonResponse<Boolean> delCv(String requestId, String visitId);

	
	/**
	 * 删除投递信息
	 * 
	 * @param talentJobRecord          
	 * @param reponse
	 * @return
	 */
	public JsonResponse<Boolean> editJobRecord(String requestId, TalentJobRecord talentJobRecord);
	
	/**
	 * 更新简历状态（根据简历类型和资料完整度）
	 * 
	 * @param String cvId
	 * @return
	 */
	public JsonResponse<Void> modifyCvStatus(String cvId);

	
	/**
	 * 查询简历并且将相应字典数据中文查询出来
	 * @param requestId
	 * @param cvId
	 * @return
	 */
	JsonResponse<TalentCvDetail> getCvDetailTransDictById(String requestId, String cvId);
}
