package com.wanjia.dsi.web.rz.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class Radar  implements Serializable {

	private static final long serialVersionUID = -8543715424888198783L;

	private String standardType;//标准类型
	private String standardTypeDesc;//标准类型名称
	private BigDecimal totalCount;//每种标准项数量
	private BigDecimal totalScore;//每种标准总分
	private BigDecimal average;//每种标准平均分
	private BigDecimal clinicTotalCount;//诊所实际每种标准项数量
	private BigDecimal clinicTotalScore;//诊所实际每种标准总分
	private BigDecimal clinicAverage;//诊所实际每种标准平均分
	public String getStandardType() {
		return standardType;
	}
	public void setStandardType(String standardType) {
		this.standardType = standardType;
	}
	public String getStandardTypeDesc() {
		return standardTypeDesc;
	}
	public void setStandardTypeDesc(String standardTypeDesc) {
		this.standardTypeDesc = standardTypeDesc;
	}
	public BigDecimal getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(BigDecimal totalCount) {
		this.totalCount = totalCount;
	}
	public BigDecimal getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(BigDecimal totalScore) {
		this.totalScore = totalScore;
	}
	public BigDecimal getAverage() {
		return average;
	}
	public void setAverage(BigDecimal average) {
		this.average = average;
	}
	public BigDecimal getClinicTotalCount() {
		return clinicTotalCount;
	}
	public void setClinicTotalCount(BigDecimal clinicTotalCount) {
		this.clinicTotalCount = clinicTotalCount;
	}
	public BigDecimal getClinicTotalScore() {
		return clinicTotalScore;
	}
	public void setClinicTotalScore(BigDecimal clinicTotalScore) {
		this.clinicTotalScore = clinicTotalScore;
	}
	public BigDecimal getClinicAverage() {
		return clinicAverage;
	}
	public void setClinicAverage(BigDecimal clinicAverage) {
		this.clinicAverage = clinicAverage;
	}
}
