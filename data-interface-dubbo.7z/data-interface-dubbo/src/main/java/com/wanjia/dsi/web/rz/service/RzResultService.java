package com.wanjia.dsi.web.rz.service;

import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.rz.model.RzResult;

/**
 * This element is automatically generated on 16-6-16 上午9:57, do not modify.
 * <br>
 * Service interface
 */
public interface RzResultService extends IBaseService<RzResult, String> {

}