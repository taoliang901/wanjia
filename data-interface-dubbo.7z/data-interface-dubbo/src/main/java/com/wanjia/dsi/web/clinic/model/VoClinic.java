package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;

import com.wanjia.elasticsearch.annotation.Id;

/**
 * 诊所列表显示的model
 * @author peichunle
 *
 */
public class VoClinic implements Serializable,Comparable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 240031448424423630L;
	
	@Id
	private String id;
	private String clinicName;
	private String diagnosisType1;
	private String clinicFacadeName;
	private String isMedicalInsurance;
	private String isView;
	private String province;
	private String city;
	private String district;
	private String address;
	private String distance;
	private double evalution;// 评价分数
	private String openingTime;
	
	private String longitude;
	private String latitude;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getClinicName() {
		return clinicName;
	}
	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}
	public String getDiagnosisType1() {
		return diagnosisType1;
	}
	public void setDiagnosisType1(String diagnosisType1) {
		this.diagnosisType1 = diagnosisType1;
	}
	public String getClinicFacadeName() {
		return clinicFacadeName;
	}
	public void setClinicFacadeName(String clinicFacadeName) {
		this.clinicFacadeName = clinicFacadeName;
	}
	public String getIsMedicalInsurance() {
		return isMedicalInsurance;
	}
	public void setIsMedicalInsurance(String isMedicalInsurance) {
		this.isMedicalInsurance = isMedicalInsurance;
	}
	public String getIsView() {
		return isView;
	}
	public void setIsView(String isView) {
		this.isView = isView;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDistance() {
		return distance;
	}
	public void setDistance(String distance) {
		this.distance = distance;
	}
	public double getEvalution() {
		return evalution;
	}
	public void setEvalution(double evalution) {
		this.evalution = evalution;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getOpeningTime() {
		return openingTime;
	}
	public void setOpeningTime(String openingTime) {
		this.openingTime = openingTime;
	}
	
	
	
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	/**
	 * 通过距离排序
	 */
	@Override
	public int compareTo(Object VoClinic) {
		VoClinic otherVoClinic = (VoClinic) VoClinic;
		String otherDistance = otherVoClinic.getDistance();
		if(this.getDistance() == null){
			return 1;
		}else if(otherDistance == null){
			return -1;
		}else{
			return Double.valueOf(this.getDistance()).compareTo(Double.valueOf(otherDistance));
		}
	}
	@Override
	public String toString() {
		return "VoClinic [id=" + id + ", clinicName=" + clinicName + ", diagnosisType1=" + diagnosisType1
				+ ", clinicFacadeName=" + clinicFacadeName + ", isMedicalInsurance=" + isMedicalInsurance + ", isView="
				+ isView + ", province=" + province + ", city=" + city + ", district=" + district + ", address="
				+ address + ", distance=" + distance + ", evalution=" + evalution + ", openingTime=" + openingTime
				+ ", longitude=" + longitude + ", latitude=" + latitude + "]";
	}
	
	
		
}
