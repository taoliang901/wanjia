package com.wanjia.dsi.web.hyPerson.util;

public class ErrorCode {

	// 注册对象不能为空
	public static String CAS_USER_IS_NULL = "E001";

	// 手机号[mobile]与用户登录名[loginName]不能同时为空!
	public static String CAS_USER_NAME_AND_MOBILE_NULL = "E0002";

	// 创建者[createUser]不能为空!
	public static String CAS_USER_CREATER_IS_NULL = "E003";

	// 用户角色[roleKey]不能为空!
	public static String CAS_USER_ROLE_IS_NULL = "E004";

	// 用户名注册登记（无手机号），密码为空
	public static String CAS_USER_LOGIN_NAME_EXISTED_BUT_PWD_IS_NULL = "E005";

	// 通过用户名注册登记（无手机号），且用户名存在，但密码输入不正确
	public static String CAS_USER_LOGIN_NAME_EXISTED_BUT_PWD_IS_INVALID = "E006";

	// 通过用户名、手机号注册登记；
	// 1. 用户名存在，且手机号也已存在，但不是同一记录，此时以用户手机号为准，提示用户名已存在，请更改用户名
	// 2. 用户名存在，且手机号不存在，此时以用户手机号为准，提示用户名已存在，请更改用户名
	public static String CAS_USER_LOGIN_NAME_EXISTED = "E007";

	// 用户名不能大于100字节
	public static String CAS_USER_LOGIN_NAME_UP_LIMIT = "E008";

	// 手机电话号码不正确
	public static String CAS_USER_MOBILE_IS_VALID = "E009";

	// 密码必须是6至16位字母与数字的组合
	public static String CAS_USER_PASSWORD_IS_VALID = "E010";

	// 用户ID不能为空
	public static String CAS_USER_UPDATE_ID_IS_NULL = "E011";

	// 非法的用户ID，未找到相应记录
	public static String CAS_USER_UPDATE_ID_IS_INVALID = "E012";
	
	// 更新时，用户手机号已存在
	public static String CAS_USER_UPDATE_MOBILE_EXISTED = "E013";
	
	// 更新时，用户名已存在
	public static String CAS_USER_UPDATE_LOGIN_NAME_EXISTED = "E014";
	
	// 用户名不能是手机号码之外的纯数字
	public static String CAS_USER_LOGIN_NAME_CAN_BE_NUMBER = "E015";
	
	// mobile不能为空
	public static String CAS_USER_MOBILE_IS_NULL = "E016";
	
	// loginName不能为空
	public static String CAS_USER_LOGIN_NAME_IS_NULL = "E017";
	
	// UUID不能为空
	public static String CAS_USER_UUID_IS_NULL = "E018";
	
	// 用户密码不正确
	public static String CAS_USER_PASSWORD_IS_INVALID = "E019";
	
	// 用户已是医生，不能在成为诊所员工
	public static String CAS_USER_IS_DOCTOR = "E020";
	
	// 医疗平台注册，手机号码正确，但是用户名不正确
	public static String CAS_USER_LOGIN_NAME_IS_INVALID = "E021";
	
	// 密码位于简单词库中，不能注册
	public static String CAS_USER_PWD_IS_SIMPLE = "E022";

	// 注册时带手机号，且手机号已存在，角色添加成功!
	public static String CAS_USER_ROLE_CREATED_EXIST_PHONE = "A001";

	// 通过用户名注册登记（无手机号），且用户名存在，角色添加成功!
	public static String CAS_USER_ROLE_CREATED_EXIST_LOGIN_NAME = "A002";

}
