package com.wanjia.dsi.web.job.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job.model.TalentJobRecord;

public interface TalentJobRecordService {
	
	public JsonResponse<List<TalentJobRecord>> getJobRecordList(String requestId,String userId,String[] jobIdList);
	
	@SuppressWarnings("rawtypes")
	public JsonResponse insertTalentJobRecord(String requestId,TalentJobRecord talentJobRecord);

}
