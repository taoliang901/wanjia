package com.wanjia.dsi.sso.service;

import com.wanjia.common.json.JsonResponse;

/**
 * UM登录业务层
 */
public interface UMLoginService {

	/**
	 * 根据UM账号登录
	 * 
	 * @param userName
	 * @param password
	 * @return
	 * 
	 */
	JsonResponse<Void> login(String userName, String password, String loginType);
}
