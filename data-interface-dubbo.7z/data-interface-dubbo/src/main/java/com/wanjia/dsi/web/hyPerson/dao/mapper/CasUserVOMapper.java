package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.hyPerson.model.CasUser;

public interface CasUserVOMapper {
	/**
	 * 根据属性字段，查询CasUser列表
	 *
	 */
	List<CasUser> findByProperties(Map<String, Object> map);

	/**
	 * 根据用户登录名，或者用户手机号查询用户列表
	 *
	 */
	List<CasUser> findByKey(Map<String, Object> map);

	/**
	 * 根据(用户登录名+角色Key)或者(用户手机号+角色Key)查询用户列表
	 *
	 */
	List<CasUser> findByRoleKey(Map<String, Object> map);

	/**
	 * 根据用户登录名或手机号查询用户列表
	 * 
	 * 
	 * @param map
	 *        loginName: 登录名 
	 *        mobile：手机号
	 * @return
	 */
	List<CasUser> findByLoginNameORMobile(Map<String, Object> map);
}