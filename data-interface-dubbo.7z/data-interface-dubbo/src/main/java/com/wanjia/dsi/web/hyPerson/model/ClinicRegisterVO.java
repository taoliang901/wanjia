package com.wanjia.dsi.web.hyPerson.model;

import java.io.Serializable;

public class ClinicRegisterVO extends HyClinicRegister implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5654161594703207851L;

	/** 诊所总账号名称 */
	private String enterpriseFullName;

	public String getEnterpriseFullName() {
		return enterpriseFullName;
	}

	public void setEnterpriseFullName(String enterpriseFullName) {
		this.enterpriseFullName = enterpriseFullName;
	}
}
