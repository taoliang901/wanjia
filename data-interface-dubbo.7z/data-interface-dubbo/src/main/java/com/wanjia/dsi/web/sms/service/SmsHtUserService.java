package com.wanjia.dsi.web.sms.service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.sms.model.HtUser;

public interface SmsHtUserService {

	/**
	 * 根据mobile和password（要先进行md5加密）查询htuser所在的角色组，查询不到状态码仍是success，内容为空，查询到内容为查询的htuser
	 * 
	 * @param htUser
	 * @return
	 */
	public JsonResponse<HtUser> findByMobileAndPassWord(HtUser htUser);
}
