package com.wanjia.dsi.web.job.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job.model.TalentCvEducation;

public interface CvEducationService {

	/**
	 * 获取学习经历列表
	 * 
	 * @param String memberId
	 * @return
	 */
	public JsonResponse<List<TalentCvEducation>> getCvEducationList(String cvId,String eduId);

	/**
	 * 修改学习经历
	 * 
	 * @param TalentCvEducation cvEducation
	 * @return
	 */
	public JsonResponse<Void> modifyCvEducation(TalentCvEducation cvEducation);

	/**
	 * 修改学习经历
	 * 
	 * @param TalentCvEducation cvEducation
	 * @param reponse
	 * @return
	 */
	public JsonResponse<Void> addCvEducation(TalentCvEducation cvEducation);
}
