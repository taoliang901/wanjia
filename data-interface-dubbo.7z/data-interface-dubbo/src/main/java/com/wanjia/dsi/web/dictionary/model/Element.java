package com.wanjia.dsi.web.dictionary.model;

import java.io.Serializable;

public class Element implements Serializable {

	private String parentCode;
	private String parentKey;
	private String parentDesc;
	private String childKey;
	private String childCode;
	private String childDesc;

	public Element() {
		// TODO Auto-generated constructor stub
	}

	public String getChildDesc() {
		return childDesc;
	}

	public Element setChildDesc(String childDesc) {
		this.childDesc = childDesc;
		return this;
	}

	public String getParentCode() {
		return parentCode;
	}

	public Element setParentCode(String parentCode) {
		this.parentCode = parentCode;
		return this;
	}

	public String getParentKey() {
		return parentKey;
	}

	public Element setParentKey(String parentKey) {
		this.parentKey = parentKey;
		return this;
	}

	public String getParentDesc() {
		return parentDesc;
	}

	public Element setParentDesc(String parentDesc) {
		this.parentDesc = parentDesc;
		return this;
	}

	public String getChildKey() {
		return childKey;
	}

	public Element setChildKey(String childKey) {
		this.childKey = childKey;
		return this;
	}

	public String getChildCode() {
		return childCode;
	}

	public Element setChildCode(String childCode) {
		this.childCode = childCode;
		return this;
	}

	@Override
	public String toString() {
		return "Element [parentCode=" + parentCode + ", parentKey=" + parentKey + ", parentDesc=" + parentDesc + ", childKey=" + childKey + ", childCode=" + childCode + ", childDesc=" + childDesc + ", getChildDesc()=" + getChildDesc() + ", getParentCode()=" + getParentCode() + ", getParentKey()=" + getParentKey() + ", getParentDesc()=" + getParentDesc() + ", getChildKey()=" + getChildKey() + ", getChildCode()=" + getChildCode() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
