package com.wanjia.dsi.web.cms.activity.model;

import java.io.Serializable;
import java.util.Date;

public class InfomationStatistcBO  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7845322187426891798L;
	private String userId;
	private String type;    //类型 ；资讯：A，药品：M ，疾病：D
	private String infoId; //各个类型统计id; 资讯:activityId;药品:medCode;疾病：diseaseId;
	private long countNum; //访问每次访问增加1
	private long realCountNum; //实际收藏量
	private long randomNum;    //随机数
	private String clientType;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getInfoId() {
		return infoId;
	}
	public void setInfoId(String infoId) {
		this.infoId = infoId;
	}
	public long getCountNum() {
		return countNum;
	}
	public void setCountNum(long countNum) {
		this.countNum = countNum;
	}
	public long getRealCountNum() {
		return realCountNum;
	}
	public void setRealCountNum(long realCountNum) {
		this.realCountNum = realCountNum;
	}
	public long getRandomNum() {
		return randomNum;
	}
	public void setRandomNum(long randomNum) {
		this.randomNum = randomNum;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getClientType() {
		return clientType;
	}
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
	
}
