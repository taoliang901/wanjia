package com.wanjia.dsi.web.department.service;

import java.util.Date;
import java.util.List;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.department.model.Department;
import com.wanjia.dsi.web.department.model.DepartmentTree;

/**
 * This element is automatically generated on 16-3-2 下午2:07, do not modify. <br>
 * Service interface
 */
public interface DepartmentService extends IBaseService<Department, Long> {
	
	
	/***
	 * 诊疗类型，内部使用 不对外公开
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param code 诊疗码
	 * @param parentIds 多个部门id
	 */
	String getDiagnosisType(String code);
	
	
	
	/***
	 * 获取多个科目列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param parentIds 多个部门id
	 * * @param parentNames 多个部门名称
	 * @return
	 * List<Department>
	 */
	public JsonResponse<List<DepartmentTree>> findDepartmentByParentIds(List<String> parentIds,List<String> parentNames);
	
	
	
	
	
	
	
	
	
	/***
	 * 获取多个科目列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param ids 部门多个id 以逗号分隔
	 * @return
	 * List<Department>
	 */
	public JsonResponse<List<Department>> findDepartmentByIds(String requestId,List<String> ids);
	/****
	 * 根据department 属性 获取科目列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param department 对象
	 * @return
	 * List<Department>
	 */
	public List<Department> getDepartmentList(String requestId,Department department);
	
	
	
	public JsonResponse<PageInfo<Department>> getDepartmentList(String requestId,String pageNo, String pageSize);
	
	
	/****
	 * 根据各个属性，获取科目列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param pageNo 页码
	 * @param pageSize 每页个数
	 * @param departmentId 部门id
	 * @param departmentName 部门名字
	 * @param departmentCode 部门code
	 * @param departmentDescription 部门描述
	 * @param parentId 父id
	 * @return
	 * JsonResponse<PageInfo<Department>>
	 */
	public JsonResponse<PageInfo<Department>> getDepartmentList(String requestId,String pageNo,String pageSize,String departmentId,String departmentName,String departmentCode,String departmentDescription,String parentId);
	/****
	 * 根据各个属性，从缓存获取科目列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	* @param pageNo 页码
	 * @param pageSize 每页个数
	 * @param departmentId 部门id
	 * @param departmentName 部门名字
	 * @param departmentCode 部门code
	 * @param departmentDescription 部门描述
	 * @param parentId 父id
	 * @return
	 * JsonResponse<PageInfo<Department>>
	 */
	public JsonResponse<PageInfo<Department>> getDepartmentListInRedis(String requestId,String pageNo,String pageSize,String departmentId,String departmentName,String departmentCode,String departmentDescription,String parentId);
	/****
	 * 根据各个属性，获取cms配置的科目列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param pageNo 页码
	 * @param pageSize 每页个数
	 * @param departmentId 部门id
	 * @param departmentName 部门名字
	 * @param departmentCode 部门code
	 * @param departmentDescription 部门描述
	 * @param parentId 父id
	 * @return
	 * JsonResponse<PageInfo<Department>>
	 */
	public JsonResponse<List<Department>> findInCmsDepartMent(String requestId,String cmsDepartmentId,String publishGroupId,String departmentId,String departmentName,String departmentCode,String parentId);
	
	//public List<Map> findInCmsDepartMent(Map department);
	
	public JsonResponse<List<Department>> getDepartmentListByTime(Date beginDate,Date endDate); 
	
}