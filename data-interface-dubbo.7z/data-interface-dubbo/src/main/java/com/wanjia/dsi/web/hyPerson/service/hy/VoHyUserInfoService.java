package com.wanjia.dsi.web.hyPerson.service.hy;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.vo.hy.VoHyUserInfo;

public interface VoHyUserInfoService {
	public JsonResponse<VoHyUserInfo>  getVoHyUserInfoByUserId(Long userId);
}
