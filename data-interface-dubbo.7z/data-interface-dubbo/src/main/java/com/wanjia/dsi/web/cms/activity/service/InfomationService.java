package com.wanjia.dsi.web.cms.activity.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.model.InfomationClickBO;
import com.wanjia.dsi.web.cms.activity.model.InfomationStatistcBO;

public interface InfomationService {
	/**
	 * 将资讯、疾病、药品的访问信息插入到mongodb,没有插入，有数据时更新访问量
	 * @param infoId  各个类型统计id 必填 ; 资讯:activityId;药品:medCode;疾病：diseaseId;
	 * @param type 类型 ；资讯：A，药品：M ，疾病：D  必填
	 * @param source  设备号或ip  选填
	 * @return
	 */
public JsonResponse<Void>  insertOrUpdateInfomation(InfomationClickBO infomationClickBO);



/**
 * 得到统计量
 * @param type 必填 ；资讯：A,疾病:D,药品:M
 * @param infoIds 必填
 * @return
 */
JsonResponse<List<InfomationStatistcBO>> getInfomationStatistic(String type,List<String> infoIds); 
/**
 * 将原来点击明细activityClickBO同步到新明细表infomationClickBO中
 * @param type 必填 ；资讯：A,疾病:D,药品:M
 * @param dateStr 必填,格式：yyyy-MM-dd
 * @return
 */
/*JsonResponse<String> syncInfomationClick(String dateStr,String type);*/
/**
 * 将点击明细infomationClickBO汇总到统计表infomationStatistcBO
 * @param type 必填 ；资讯：A,疾病:D,药品:M
 * @param dateStr 格式：yyyy-MM-dd,不填统计全部
 * @return
 */
JsonResponse<String> syncInfomationStatistc(String dateStr,String type);

/**
 * 初始化阅读量统计myCollectionStatisticsBO表
 * @param infoIds 必填；资讯,疾病,药品等id
 * @param type 必填 ；资讯：A,疾病:D,药品:M
 * @return
 */
JsonResponse<String> initInfomationStatistic(String type, List<String> infoIds);
}
