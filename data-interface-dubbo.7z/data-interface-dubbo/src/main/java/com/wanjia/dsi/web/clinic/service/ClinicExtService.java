package com.wanjia.dsi.web.clinic.service;


import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.clinic.model.ClinicExt;


/**
 * This element is automatically generated on 17-1-12 下午2:36, do not modify. <br>
 * Service interface
 */
public interface ClinicExtService  extends IBaseService<ClinicExt, String> {
	
	
	public JsonResponse searchClinicQRCodeByClinicId(String clinicId);
}