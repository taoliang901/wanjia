package com.wanjia.dsi.web.clinic.model;

/**
 * 诊所类型枚举类
 * @author whq
 *
 */
public enum ClinicTypeEnum {
	
	/**
	 * 综合门诊部/普通门诊
	 */
	Clinic_Type_ZH("N01"),
	/**
	 * 专科门诊部/诊所
	 */
	Clinic_Type_ZKMK("N02"),
	/**
	 * 中医门诊部/诊所
	 */
	Clinic_Type_ZY("N03"),
	/**
	 * 社区卫生服务中心/站
	 */
	Clinic_Type_SQFW("N04"),
	/**
	 * 专科医院
	 */
	Clinic_Type_ZKYY("N05"),
	/**
	 * 其他
	 */
	Clinic_Type_Other("N06"),
	;
	
	/**
	 * @param value
	 */
	public final String value;

	private ClinicTypeEnum(String value) {
		this.value = value;
	}

}
