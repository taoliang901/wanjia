package com.wanjia.dsi.web.cms.activity.model;

import java.io.Serializable;
import java.util.Date;

public class VOLocalMedicine extends LocalMedicine  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3192375654124807868L;
	private Date beginDate; // 开始时间
	private Date endDate; // 结束时间

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

}
