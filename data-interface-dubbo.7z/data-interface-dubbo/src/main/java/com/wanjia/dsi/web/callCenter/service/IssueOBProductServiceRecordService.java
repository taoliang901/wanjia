package com.wanjia.dsi.web.callCenter.service;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.callCenter.model.Issue;
import com.wanjia.dsi.web.callCenter.model.IssueOBInfo;
import com.wanjia.dsi.web.callCenter.model.IssueOBProductServiceRecord;

/**
 * This element is automatically generated on 16-9-14 下午7:54, do not modify. <br>
 * Service interface
 */
public interface IssueOBProductServiceRecordService extends IBaseService<IssueOBProductServiceRecord, Long> {
	
	public List<IssueOBProductServiceRecord> getEntityByApptCode(String apptCode);
	
	void insertAllBatch(List<Issue> issues,List<IssueOBInfo> issueOBInfos,List<IssueOBProductServiceRecord> issueOBpsrs);
	
	public List<IssueOBProductServiceRecord> findEntityByParams(Map<String,Object> params);
	
	public int createIssuesOfLowEvaluation();
	
}