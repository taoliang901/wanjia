package com.wanjia.dsi.web.hyPerson.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.ClinicDoctor;
import com.wanjia.dsi.web.hyPerson.model.ClinicDoctorMap;
import com.wanjia.dsi.web.hyPerson.model.HyClinicDoctorExperiences;
import com.wanjia.dsi.web.hyPerson.vo.HyChangeMobileVO;

public interface HyClinicDoctorService {

	/**
	 * 获取医生列表
	 * 
	 * @param ClinicDoctor
	 *            doctor
	 * @return
	 */
	JsonResponse<List<ClinicDoctor>> getDoctorList(ClinicDoctor doctor);

	/**
	 * 注册&&修改医生信息 (诊所和网关调用)
	 * 
	 * @param ClinicDoctor
	 *            doctor
	 * @param String
	 *            operateMark 用户操作标志（0：保存，1：提交）
	 * @param String
	 *            dataMark 用户操作标志（1：资质数据保存，6：上线数据保存）
	 * @param String
	 *            clinicMark 诊所医生标志（0：注册，1：编辑）
	 * @param String
	 *            mobile 手机号
	 * @param ClinicDoctorMap
	 *            clinicDoctorMap 诊所申请医生关联实体类
	 * @param String
	 *            ipAddress 用于注册短信发送
	 * @param String
	 *            clientType 积分来源，具体定义请参考IntegralClient.java
	 * @param reponse
	 * @return
	 */
	JsonResponse<String> editClinicDoctor(ClinicDoctor doctor, String operateMark, String dataMark, String clinicMark,
			String mobile, ClinicDoctorMap clinicDoctorMap, String ipAddress, String clientType);

	/**
	 * 注册&&修改医生信息(会员调用)
	 * 
	 * @param ClinicDoctor
	 *            doctor
	 * @param String
	 *            operateMark 用户操作标志（0：保存，1：提交）
	 * @param String
	 *            dataMark 用户操作标志（1：资质数据保存，6：上线数据保存）
	 * @param String
	 *            clinicMark 诊所医生标志（0：注册，1：编辑）
	 * @param String
	 *            mobile 手机号
	 * @param ClinicDoctorMap
	 *            clinicDoctorMap 诊所申请医生关联实体类
	 * @param String
	 *            ipAddress 用于注册短信发送
	 * @param String
	 *            userName 用户名，普通会员升级医生使用
	 * @param String
	 *            casId 会员casId，普通会员升级医生使用（已废弃）
	 * @param String
	 *            clientType 积分来源，具体定义请参考IntegralClient.java
	 * @param reponse
	 * @return
	 */
	JsonResponse<String> editClinicDoctor(ClinicDoctor doctor, List<HyClinicDoctorExperiences> experiences,
			String operateMark, String dataMark, String clinicMark, String mobile, ClinicDoctorMap clinicDoctorMap,
			String ipAddress, String loginName, String casId, String clientType);

	/**
	 * 发送短信
	 * 
	 * @param String
	 *            mobile 手机号
	 * @param String
	 *            smsTempId 场景ID
	 * @param String
	 *            ipAddress IP地址
	 * @param reponse
	 *            String UUID
	 * @return
	 */
	JsonResponse<String> sendMessage(String mobile, String smsTempId, String ipAddress);

	/**
	 * 更换手机号验证
	 * 
	 * @param HyChangeMobileVO
	 *            hyChangeMobileVO
	 * @param reponse
	 * @return
	 */
	JsonResponse<Boolean> checkMessage(HyChangeMobileVO hyChangeMobileVO);

	/**
	 * 更换手机号成功发送短信
	 * 
	 * @param String
	 *            mobile
	 * @param reponse
	 * @return
	 */
	JsonResponse<String> sendChangeMobileMsg(String mobileBefore, String mobileAfter, String ipAddress);

	/**
	 * 诊所关联
	 * 
	 * @param mobile
	 * @param ipAddress
	 * @return
	 */
	JsonResponse<String> sendClinicMobileMsg(Map<String, String> msgMap);

	/**
	 * 通过id获得医生信息
	 * 
	 * @param id
	 */
	ClinicDoctor findDoctorByPrimaryKey(String id);

	/**
	 * 插入数据
	 */
	void insertClinicDoctor(ClinicDoctor clinicDoctor);

	/**
	 * 普通会员升级医生
	 * 
	 * @param String
	 *            casUuid
	 * @return
	 */
	JsonResponse<Boolean> upgradeToDoctor(String casUuid);

	/**
	 * 根据手机号查询ClinicDoctor信息
	 *
	 */
	JsonResponse<ClinicDoctor> findByMobile(String mobile);
	/**
	 * 查询医生信息，
	 * @param doctor
	 * @param flag true：casUuid和userId是同一个人
	 * @return
	 */
	public JsonResponse<List<ClinicDoctor>> getDoctorListCheckSecrecy(ClinicDoctor doctor,String userId);
}
