package com.wanjia.dsi.web.cms.activity.service;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.model.InfomationStatistcBO;
import com.wanjia.dsi.web.cms.activity.model.VOInfomationStatistc;

public interface InfomationStatistcService {
	/**
	 * 将资讯、疾病、药品的访问信息插入到mongodb,没有插入，有数据时更新访问量
	 * @param infoId  各个类型统计id 必填 ; 资讯:activityId;药品:medCode;疾病：diseaseId;
	 * @param type 类型 ；资讯：A，药品：M ，疾病：D  必填
	 * @param source  设备号或ip  选填
	 * @return
	 */
public JsonResponse<Void>  insertOrUpdateInfomationStatistc(InfomationStatistcBO infomationStatistcBO);

/**
 * 得到访问量
 * @param type 必填 ；资讯：A,疾病:D,药品:M
 * @param infoId 选填
 * @return
 */
JsonResponse<PageInfo<InfomationStatistcBO>> getInfomationStatistic(VOInfomationStatistc voInfomationStatistc); 


}
