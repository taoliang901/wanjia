package com.wanjia.dsi.web.condition.service;

import java.util.List;

import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.condition.model.Condition;

/**
 * This element is automatically generated on 16-3-2 下午2:40, do not modify. <br>
 * Service interface
 */
public interface ConditionService extends IBaseService<Condition, Long> {
	public List<Condition> getConditionList(Condition condition,int offset,int pageSize);
	public Long getConditionListCount(Condition condition);
}