package com.wanjia.dsi.web.hyPerson.model;

import java.util.List;

public class VOHyTreatmentPerson extends HyTreatmentPerson {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1568659853487879154L;
	private String prdId;
	List<String> memberIdList;

	public String getPrdId() {
		return prdId;
	}

	public void setPrdId(String prdId) {
		this.prdId = prdId;
	}

	public List<String> getMemberIdList() {
		return memberIdList;
	}

	public void setMemberIdList(List<String> memberIdList) {
		this.memberIdList = memberIdList;
	}

}