package com.wanjia.dsi.web.job51.service;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job51.model.Job51Account;

public interface Job51Service {
	
	//新增用户
	@SuppressWarnings("rawtypes")
	public JsonResponse addUser(Job51Account job51Account);
	
	//修改用户密码
	@SuppressWarnings("rawtypes")
	public JsonResponse modifypassword(String clinicId,String password);
		
	//删除用户
	@SuppressWarnings("rawtypes")
	public JsonResponse deleteuser(String clinicId);
	
	//简历搜索
	@SuppressWarnings("rawtypes")
	public JsonResponse searchresume(String hruid,String access_token,String lastupdatefrom,String lastupdateto,String lastupdate);
	
	//查看简历详情
	public JsonResponse<HashMap<String,Object>> viewresume(String clinicId,String resumeid);
	
	//查看简历详情
	public JsonResponse<HashMap<String,Object>> viewresumeFromDownload(String clinicId,String resumeid);
		
	//下载简历
	@SuppressWarnings("rawtypes")
	public JsonResponse downloadresume(String clinicId,String resumeid);

	//判断诊所是否已下载过简历
	public JsonResponse<Boolean> hasDownload(String clinicId, String cvId);
	
	public String getParamStrFromMap(LinkedHashMap<String,String> paramMap);

	//批量添加所有历史简历
	@SuppressWarnings("rawtypes")
	public JsonResponse search51JOBIntoMysql(String startDate,String endDate);
	
	public JsonResponse<PageInfo<LinkedHashMap<String,Object>>> search51JOBList(Map<String,String> searchPramMap);
}
