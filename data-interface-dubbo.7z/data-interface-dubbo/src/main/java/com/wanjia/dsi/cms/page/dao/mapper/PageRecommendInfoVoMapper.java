package com.wanjia.dsi.cms.page.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.cms.page.model.PageRecommendInfoCriteria;
import com.wanjia.dsi.cms.page.model.PageRecommendInfoVo;

public interface PageRecommendInfoVoMapper {

	/**
	 * 根据参数模型查询页面推荐数据信息列表
	 * 
	 * @param criteria
	 * @return
	 */
	List<PageRecommendInfoVo> selectInfoVoByEntity(PageRecommendInfoCriteria criteria);
	
	/**
	 * 根据参数模型查询页面推荐数据信息列表并排序
	 * 
	 * @param map
	 * @return
	 */
	List<PageRecommendInfoVo> selectEntityByPreperties(Map<String, Object> map);
	
	/**
	 * 根据参数模型统计页面推荐数据信息数量
	 * 
	 * @param map
	 * @return
	 */
	Long countEntityByPreperties(Map<String, Object> map);
	
	/**
	 * 根据参数模型统计页面推荐数据信息数量
	 * 
	 * @param criteria
	 * @return
	 */
	Long countByEntityForInfo(PageRecommendInfoCriteria criteria);
	
	/**
	 * 根据有角色参数模型查询页面推荐数据信息列表
	 * 
	 * @param criteria
	 * @return
	 */
	List<PageRecommendInfoVo> selectInfoVoByEntityWithRole(PageRecommendInfoCriteria criteria);
	
	/**
	 * 根据有角色参数模型统计页面推荐数据信息数量
	 * 
	 * @param criteria
	 * @return
	 */
	Long countByEntityForInfoWithRole(PageRecommendInfoCriteria criteria);
	
	/**
	 * 根据有角色和分辨率参数模型统计页面推荐数据信息数量
	 * 
	 * @param criteria
	 * @return
	 */
	Long countInfoVoByEntityWithRoleAndImg(PageRecommendInfoCriteria criteria);
	
	
	
	
}