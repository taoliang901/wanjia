package com.wanjia.dsi.web.clinic.model;

public class YlptDoctorInfo {
	private String id;				//id
	private String doctorName;		//医生姓名
	private String mobile;			//手机号
	private String medicineTitle;	//职称
	private String practiceArea;	//执业范围
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMedicineTitle() {
		return medicineTitle;
	}
	public void setMedicineTitle(String medicineTitle) {
		this.medicineTitle = medicineTitle;
	}
	public String getPracticeArea() {
		return practiceArea;
	}
	public void setPracticeArea(String practiceArea) {
		this.practiceArea = practiceArea;
	}
	
	

}
