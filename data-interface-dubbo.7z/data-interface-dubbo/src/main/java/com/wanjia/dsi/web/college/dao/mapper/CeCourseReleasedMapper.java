package com.wanjia.dsi.web.college.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.college.model.CeCourseReleased;

public interface CeCourseReleasedMapper extends IBaseDao {

	public List<CeCourseReleased> findAllCeCourseReleasedByKey(CeCourseReleased ceCourseReleased);

	public List<CeCourseReleased> findAllCeCourseReleasedByType(@Param(value = "typeId") Integer typeId);

	public List<CeCourseReleased> findAllCeCourseReleased();

	public CeCourseReleased findCeCourseReleasedByCourseId(String courseId);

	public List<CeCourseReleased> findCeCourseByLabel(@Param("labelId") String labelId,
			@Param("pageSize") Integer pageSize);
}
