package com.wanjia.dsi.web.college.model;

import java.io.Serializable;
import java.util.Date;

import com.wanjia.dsi.base.vo.BaseEntity;
import com.wanjia.elasticsearch.annotation.Document;
import com.wanjia.elasticsearch.annotation.Id;
@Document(index = "com_wanjia_course", type = "course")
public class Course extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    private String courseId;

    private String courseTitle;

    private String courseSubhead;

    private Integer typeId;

    private String authorId;

    private String courseIntro;

    private String contentType;

    private String courseFrom;

    private String courseFromLink;

    private String coursePic;
    private String authorName;

    private String courseContent;

    private String courseLink;

    private String courseTargetLink;

    private Integer coursePermission;

    private String courseStatus;

    private Integer stickFlag;

    private Integer orderNum;

    private Integer delFlag;

    private Date createTime;

    private Date updateTime;

    private Date deleteTime;

    private Date releasedTime;

    public String getCourseId() {
        return courseId;
    }

    
  
    
    
    public String getAuthorName() {
		return authorName;
	}


	public Course setAuthorName(String authorName) {
		this.authorName = authorName;
		return this;
	}





	public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getCourseSubhead() {
        return courseSubhead;
    }

    public void setCourseSubhead(String courseSubhead) {
        this.courseSubhead = courseSubhead;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public String getAuthorId() {
        return authorId;
    }

    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }

    public String getCourseIntro() {
        return courseIntro;
    }

    public void setCourseIntro(String courseIntro) {
        this.courseIntro = courseIntro;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getCourseFrom() {
        return courseFrom;
    }

    public void setCourseFrom(String courseFrom) {
        this.courseFrom = courseFrom;
    }

    public String getCourseFromLink() {
        return courseFromLink;
    }

    public void setCourseFromLink(String courseFromLink) {
        this.courseFromLink = courseFromLink;
    }

    public String getCoursePic() {
        return coursePic;
    }

    public void setCoursePic(String coursePic) {
        this.coursePic = coursePic;
    }

    public String getCourseContent() {
        return courseContent;
    }

    public void setCourseContent(String courseContent) {
        this.courseContent = courseContent;
    }

    public String getCourseLink() {
        return courseLink;
    }

    public void setCourseLink(String courseLink) {
        this.courseLink = courseLink;
    }

    public String getCourseTargetLink() {
        return courseTargetLink;
    }

    public void setCourseTargetLink(String courseTargetLink) {
        this.courseTargetLink = courseTargetLink;
    }

    public Integer getCoursePermission() {
        return coursePermission;
    }

    public void setCoursePermission(Integer coursePermission) {
        this.coursePermission = coursePermission;
    }

    public String getCourseStatus() {
        return courseStatus;
    }

    public void setCourseStatus(String courseStatus) {
        this.courseStatus = courseStatus;
    }

    public Integer getStickFlag() {
        return stickFlag;
    }

    public void setStickFlag(Integer stickFlag) {
        this.stickFlag = stickFlag;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(Date deleteTime) {
        this.deleteTime = deleteTime;
    }

    public Date getReleasedTime() {
        return releasedTime;
    }

    public void setReleasedTime(Date releasedTime) {
        this.releasedTime = releasedTime;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Course other = (Course) that;
        return (this.getCourseId() == null ? other.getCourseId() == null : this.getCourseId().equals(other.getCourseId()))
            && (this.getCourseTitle() == null ? other.getCourseTitle() == null : this.getCourseTitle().equals(other.getCourseTitle()))
            && (this.getCourseSubhead() == null ? other.getCourseSubhead() == null : this.getCourseSubhead().equals(other.getCourseSubhead()))
            && (this.getTypeId() == null ? other.getTypeId() == null : this.getTypeId().equals(other.getTypeId()))
            && (this.getAuthorId() == null ? other.getAuthorId() == null : this.getAuthorId().equals(other.getAuthorId()))
            && (this.getCourseIntro() == null ? other.getCourseIntro() == null : this.getCourseIntro().equals(other.getCourseIntro()))
            && (this.getContentType() == null ? other.getContentType() == null : this.getContentType().equals(other.getContentType()))
            && (this.getCourseFrom() == null ? other.getCourseFrom() == null : this.getCourseFrom().equals(other.getCourseFrom()))
            && (this.getCourseFromLink() == null ? other.getCourseFromLink() == null : this.getCourseFromLink().equals(other.getCourseFromLink()))
            && (this.getCoursePic() == null ? other.getCoursePic() == null : this.getCoursePic().equals(other.getCoursePic()))
            && (this.getCourseContent() == null ? other.getCourseContent() == null : this.getCourseContent().equals(other.getCourseContent()))
            && (this.getCourseLink() == null ? other.getCourseLink() == null : this.getCourseLink().equals(other.getCourseLink()))
            && (this.getCourseTargetLink() == null ? other.getCourseTargetLink() == null : this.getCourseTargetLink().equals(other.getCourseTargetLink()))
            && (this.getCoursePermission() == null ? other.getCoursePermission() == null : this.getCoursePermission().equals(other.getCoursePermission()))
            && (this.getCourseStatus() == null ? other.getCourseStatus() == null : this.getCourseStatus().equals(other.getCourseStatus()))
            && (this.getStickFlag() == null ? other.getStickFlag() == null : this.getStickFlag().equals(other.getStickFlag()))
            && (this.getOrderNum() == null ? other.getOrderNum() == null : this.getOrderNum().equals(other.getOrderNum()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getDeleteTime() == null ? other.getDeleteTime() == null : this.getDeleteTime().equals(other.getDeleteTime()))
            && (this.getReleasedTime() == null ? other.getReleasedTime() == null : this.getReleasedTime().equals(other.getReleasedTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getCourseId() == null) ? 0 : getCourseId().hashCode());
        result = prime * result + ((getCourseTitle() == null) ? 0 : getCourseTitle().hashCode());
        result = prime * result + ((getCourseSubhead() == null) ? 0 : getCourseSubhead().hashCode());
        result = prime * result + ((getTypeId() == null) ? 0 : getTypeId().hashCode());
        result = prime * result + ((getAuthorId() == null) ? 0 : getAuthorId().hashCode());
        result = prime * result + ((getCourseIntro() == null) ? 0 : getCourseIntro().hashCode());
        result = prime * result + ((getContentType() == null) ? 0 : getContentType().hashCode());
        result = prime * result + ((getCourseFrom() == null) ? 0 : getCourseFrom().hashCode());
        result = prime * result + ((getCourseFromLink() == null) ? 0 : getCourseFromLink().hashCode());
        result = prime * result + ((getCoursePic() == null) ? 0 : getCoursePic().hashCode());
        result = prime * result + ((getCourseContent() == null) ? 0 : getCourseContent().hashCode());
        result = prime * result + ((getCourseLink() == null) ? 0 : getCourseLink().hashCode());
        result = prime * result + ((getCourseTargetLink() == null) ? 0 : getCourseTargetLink().hashCode());
        result = prime * result + ((getCoursePermission() == null) ? 0 : getCoursePermission().hashCode());
        result = prime * result + ((getCourseStatus() == null) ? 0 : getCourseStatus().hashCode());
        result = prime * result + ((getStickFlag() == null) ? 0 : getStickFlag().hashCode());
        result = prime * result + ((getOrderNum() == null) ? 0 : getOrderNum().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getDeleteTime() == null) ? 0 : getDeleteTime().hashCode());
        result = prime * result + ((getReleasedTime() == null) ? 0 : getReleasedTime().hashCode());
        return result;
    }
}