package com.wanjia.dsi.web.sms.model;

import java.io.Serializable;
import java.util.Date;

/**
 * sms日志表的message里面的json对象
 * 
 *
 *
 */
public class SmsMessage implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String jsonParam;
	/**
	 * 手机号码
	 */
	private String mobileNo;
	private String msgContent = "sysDefContent";
	/**
	 * 用途的业务描述
	 */
	private String proBusiness;
	/**
	 * 请求发送短信的项目名称 表：t_sms_cfg
	 */
	private String proName;
	/**
	 * 短信模板ID
	 */
	private String templateID;

	// 第二套模板字段
	// private String REQUEST_MOBILE_NO;

	private String validateCode;

	// private String REQUEST_MSG_CONTENT;

	// private String REQUEST_TEMPLET_ID;

	// 发送时间也需要传过去,
	private Date createDate;

	public String getJsonParam() {
		return jsonParam;
	}

	public void setJsonParam(String jsonParam) {
		this.jsonParam = jsonParam;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMsgContent() {
		return msgContent;
	}

	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}

	public String getProBusiness() {
		return proBusiness;
	}

	public void setProBusiness(String proBusiness) {
		this.proBusiness = proBusiness;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getTemplateID() {
		return templateID;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public String getREQUEST_MOBILE_NO() {
		return mobileNo;
	}

	public void setREQUEST_MOBILE_NO(String rEQUEST_MOBILE_NO) {
		mobileNo = rEQUEST_MOBILE_NO;
	}

	public String getValidateCode() {
		return validateCode;
	}

	public void setValidateCode(String validateCode) {
		this.validateCode = validateCode;
	}

	public String getREQUEST_MSG_CONTENT() {
		return msgContent;
	}

	public void setREQUEST_MSG_CONTENT(String rEQUEST_MSG_CONTENT) {
		msgContent = rEQUEST_MSG_CONTENT;
	}

	public String getREQUEST_TEMPLET_ID() {
		return templateID;
	}

	public void setREQUEST_TEMPLET_ID(String rEQUEST_TEMPLET_ID) {
		templateID = rEQUEST_TEMPLET_ID;
	}

	/*
	 * public String getREQUEST_MOBILE_NO() { return REQUEST_MOBILE_NO; }
	 * 
	 * public void setREQUEST_MOBILE_NO(String rEQUEST_MOBILE_NO) { REQUEST_MOBILE_NO = rEQUEST_MOBILE_NO; }
	 * 
	 * public String getValidateCode() { return validateCode; }
	 * 
	 * public void setValidateCode(String validateCode) { this.validateCode = validateCode; }
	 * 
	 * public String getREQUEST_MSG_CONTENT() { return REQUEST_MSG_CONTENT; }
	 * 
	 * public void setREQUEST_MSG_CONTENT(String rEQUEST_MSG_CONTENT) { REQUEST_MSG_CONTENT = rEQUEST_MSG_CONTENT; }
	 * 
	 * public String getREQUEST_TEMPLET_ID() { return REQUEST_TEMPLET_ID; }
	 * 
	 * public void setREQUEST_TEMPLET_ID(String rEQUEST_TEMPLET_ID) { REQUEST_TEMPLET_ID = rEQUEST_TEMPLET_ID; }
	 */

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

}
