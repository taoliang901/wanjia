package com.wanjia.dsi.web.college.model;

import java.io.Serializable;
import java.util.Date;

public class CeCourseReleased implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String courseId;
	private String courseTitle;
	private String courseSubhead;
	private Integer typeId;

	private String authorId;

	private String courseIntro;
	private String contentType;
	private String courseFrom;
	private String courseFromLink;
	private String coursePic;
	private String courseContent;
	private String courseLink;
	private String courseTargetLink;
	private Integer coursePermission;
	private String courseStatus;
	private Integer stickFlag;
	private Integer orderNum;
	private Integer delFlag;
	private Date createTime;
	private Date updateTime;
	private Date deleteTime;
	private Date releasedTime;
	private String courseVideoLink;
	//--扩展
	private CeAuthor ceAuthor;
	private CeCourseType ceCourseType;
	
	
	public CeCourseType getCeCourseType() {
		return ceCourseType;
	}

	public void setCeCourseType(CeCourseType ceCourseType) {
		this.ceCourseType = ceCourseType;
	}

	public String getCourseVideoLink() {
		return courseVideoLink;
	}

	public void setCourseVideoLink(String courseVideoLink) {
		this.courseVideoLink = courseVideoLink;
	}

	public CeAuthor getCeAuthor() {
		return ceAuthor;
	}

	public void setCeAuthor(CeAuthor ceAuthor) {
		this.ceAuthor = ceAuthor;
	}

	public String getAuthorName() {
		return ceAuthor.getAuthorName();
	}



	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getCourseTitle() {
		return courseTitle;
	}

	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}

	public String getCourseSubhead() {
		return courseSubhead;
	}

	public void setCourseSubhead(String courseSubhead) {
		this.courseSubhead = courseSubhead;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getAuthorId() {
		return authorId;
	}

	public void setAuthorId(String authorId) {
		this.authorId = authorId;
	}

	public String getCourseIntro() {
		return courseIntro;
	}

	public void setCourseIntro(String courseIntro) {
		this.courseIntro = courseIntro;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getCourseFrom() {
		return courseFrom;
	}

	public void setCourseFrom(String courseFrom) {
		this.courseFrom = courseFrom;
	}

	public String getCourseFromLink() {
		return courseFromLink;
	}

	public void setCourseFromLink(String courseFromLink) {
		this.courseFromLink = courseFromLink;
	}

	public String getCoursePic() {
		return coursePic;
	}

	public void setCoursePic(String coursePic) {
		this.coursePic = coursePic;
	}

	public String getCourseContent() {
		return courseContent;
	}

	public void setCourseContent(String courseContent) {
		this.courseContent = courseContent;
	}

	public String getCourseLink() {
		return courseLink;
	}

	public void setCourseLink(String courseLink) {
		this.courseLink = courseLink;
	}

	public String getCourseTargetLink() {
		return courseTargetLink;
	}

	public void setCourseTargetLink(String courseTargetLink) {
		this.courseTargetLink = courseTargetLink;
	}

	public Integer getCoursePermission() {
		return coursePermission;
	}

	public void setCoursePermission(Integer coursePermission) {
		this.coursePermission = coursePermission;
	}

	public String getCourseStatus() {
		return courseStatus;
	}

	public void setCourseStatus(String courseStatus) {
		this.courseStatus = courseStatus;
	}

	public Integer getStickFlag() {
		return stickFlag;
	}

	public void setStickFlag(Integer stickFlag) {
		this.stickFlag = stickFlag;
	}

	public Integer getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(Integer orderNum) {
		this.orderNum = orderNum;
	}

	public Integer getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(Integer delFlag) {
		this.delFlag = delFlag;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getDeleteTime() {
		return deleteTime;
	}

	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}

	public Date getReleasedTime() {
		return releasedTime;
	}

	public void setReleasedTime(Date releasedTime) {
		this.releasedTime = releasedTime;
	}



}