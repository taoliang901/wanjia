package com.wanjia.dsi.web.sms.model;

import java.util.Date;

public class SmsLogInfo {
    
	private Integer id;

	private String phone;
	
	private String message;
	
    private String proName;

    private String proBusiness;

    private String proIp;

    private String requestMsg;

    private String responseMsg;

    private Date createDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProName() {
        return proName;
    }

    public void setProName(String proName) {
        this.proName = proName == null ? null : proName.trim();
    }

    public String getProBusiness() {
        return proBusiness;
    }

    public void setProBusiness(String proBusiness) {
        this.proBusiness = proBusiness == null ? null : proBusiness.trim();
    }

    public String getProIp() {
        return proIp;
    }

    public void setProIp(String proIp) {
        this.proIp = proIp == null ? null : proIp.trim();
    }

    public String getRequestMsg() {
        return requestMsg;
    }

    public void setRequestMsg(String requestMsg) {
        this.requestMsg = requestMsg == null ? null : requestMsg.trim();
    }

    public String getResponseMsg() {
        return responseMsg;
    }

    public void setResponseMsg(String responseMsg) {
        this.responseMsg = responseMsg == null ? null : responseMsg.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone == null ? null : phone.trim();
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message == null ? null : message.trim();
	}
}