package com.wanjia.dsi.web.clinic.service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinic.model.ClinicYear;

public interface ClinicYearService {

	/**
	 * 根据诊所Id查询
	 * @param clinicId
	 * @return
	 */
	JsonResponse<ClinicYear> getClinicYearByClinicId(String clinicId);

	
}
