package com.wanjia.dsi.web.rz.util;

/**
 * 审核结果枚举
 * 
 * @author LUOXIAOJUN640
 *
 */
public enum RzResultEnum {

	NO_RESULT("暂无", "01"), THREE_STAR_PASS("三星认证通过", "02"), THREE_STAR_FAILED("三星认证未通过", "03");

	private String code;
	private String value;

	private RzResultEnum(String code, String value) {
		this.code = code;
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
