package com.wanjia.dsi.web.callCenter.service;

import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.callCenter.model.Issue;

public interface IssueService extends IBaseService<Issue, Long> {	
	/**
	 * 创建工单
	 * @param issue
	 */
	void createIssueForPrd(Issue issue);
	
	/**
	 * 更新工单（用于申请流转的功能）
	 * @param issue
	 */
	void updateIssueForPrd(Issue issue);
	

}