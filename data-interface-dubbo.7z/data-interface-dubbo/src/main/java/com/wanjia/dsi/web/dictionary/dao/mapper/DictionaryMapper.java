package com.wanjia.dsi.web.dictionary.dao.mapper;

import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.dictionary.model.Dictionary;
import com.wanjia.dsi.web.dictionary.model.Element;

public interface DictionaryMapper extends IBaseDao<Dictionary, String> {
	
	List<Element> getDictInfo();
	
	
	
}