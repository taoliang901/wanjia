package com.wanjia.dsi.web.clinic.service;

import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.clinic.model.ClinicInfo;

/**
 * 
 * ClinicInfoService
 * 
 * @author LUOXIAOJUN640
 *
 */
public interface ClinicInfoService extends IBaseService<ClinicInfo, String> {
	/**
	 * m端专用，只返回诊所id，名称，地址，状态
	 * @param id
	 * @return
	 */
	ClinicInfo findClinicInfoById(String id);

	ClinicInfo findClinicInfoByRegisterId(String registerId);
	
}