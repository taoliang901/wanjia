package com.wanjia.dsi.web.callCenter.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class IssueOBProductServiceRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;

    private String obId;

    private String apptorderCode;

    private Integer apptStatus;

    private String apptTime;

    private String clinicId;

    private String clinicName;

    private String scheduleDate;

    private String timeSpanStartTime;

    private String timeSpanEndTime;

    private Integer isClinicApptConfirm;

    private Integer isUserTreatmentConfirm;

    private Integer isClinicTreatmentConfirm;

    private String apptCancelType;

    private String cardId;

    private String cardNo;

    private String healthProductId;

    private String healthProductName;

    private String productTypeName;

    private String healthProductItemId;

    private String healthProductItemName;

    private Float clinicScore;

    private Integer clinicTreatmentConfirmImageCount;

    private String userId;
    
	/** 预约操作人员类型（0：会员，1：诊所工作人员，2，运营客服人员） */
	private Integer apptOptUserType;

	/** 运营客服人员用户ID */
	private String agentUserId;

    private String patientVisitId;
    
    private String patientVisitName;
    
    private String patientMobile; 

    private Integer isClinicApptConfirmOvertime;

    private Integer isUserTreatmentConfirmOvertime;

    private Date createDate;

    private String createUser;

    private Date modifyDate;

    private String modifyUser;

    private String delFlag;

    
    public String getPatientMobile() {
		return patientMobile;
	}

	public void setPatientMobile(String patientMobile) {
		this.patientMobile = patientMobile;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getObId() {
        return obId;
    }

    public void setObId(String obId) {
        this.obId = obId;
    }

    public String getApptorderCode() {
        return apptorderCode;
    }

    public void setApptorderCode(String apptorderCode) {
        this.apptorderCode = apptorderCode;
    }

    public Integer getApptStatus() {
        return apptStatus;
    }

    public void setApptStatus(Integer apptStatus) {
        this.apptStatus = apptStatus;
    }

    public String getApptTime() {
        return apptTime;
    }

    public void setApptTime(String apptTime) {
        this.apptTime = apptTime;
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getScheduleDate() {
        return scheduleDate;
    }

    public void setScheduleDate(String scheduleDate) {
        this.scheduleDate = scheduleDate;
    }

    public String getTimeSpanStartTime() {
        return timeSpanStartTime;
    }

    public void setTimeSpanStartTime(String timeSpanStartTime) {
        this.timeSpanStartTime = timeSpanStartTime;
    }

    public String getTimeSpanEndTime() {
        return timeSpanEndTime;
    }

    public void setTimeSpanEndTime(String timeSpanEndTime) {
        this.timeSpanEndTime = timeSpanEndTime;
    }

    public Integer getIsClinicApptConfirm() {
        return isClinicApptConfirm;
    }

    public void setIsClinicApptConfirm(Integer isClinicApptConfirm) {
        this.isClinicApptConfirm = isClinicApptConfirm;
    }

    public Integer getIsUserTreatmentConfirm() {
        return isUserTreatmentConfirm;
    }

    public void setIsUserTreatmentConfirm(Integer isUserTreatmentConfirm) {
        this.isUserTreatmentConfirm = isUserTreatmentConfirm;
    }

    public Integer getIsClinicTreatmentConfirm() {
        return isClinicTreatmentConfirm;
    }

    public void setIsClinicTreatmentConfirm(Integer isClinicTreatmentConfirm) {
        this.isClinicTreatmentConfirm = isClinicTreatmentConfirm;
    }

    public String getApptCancelType() {
        return apptCancelType;
    }

    public void setApptCancelType(String apptCancelType) {
        this.apptCancelType = apptCancelType;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getHealthProductId() {
        return healthProductId;
    }

    public void setHealthProductId(String healthProductId) {
        this.healthProductId = healthProductId;
    }

    public String getHealthProductName() {
        return healthProductName;
    }

    public void setHealthProductName(String healthProductName) {
        this.healthProductName = healthProductName;
    }

    public String getProductTypeName() {
        return productTypeName;
    }

    public void setProductTypeName(String productTypeName) {
        this.productTypeName = productTypeName;
    }

    public String getHealthProductItemId() {
        return healthProductItemId;
    }

    public void setHealthProductItemId(String healthProductItemId) {
        this.healthProductItemId = healthProductItemId;
    }

    public String getHealthProductItemName() {
        return healthProductItemName;
    }

    public void setHealthProductItemName(String healthProductItemName) {
        this.healthProductItemName = healthProductItemName;
    }

    public Float getClinicScore() {
        return clinicScore;
    }

    public void setClinicScore(Float clinicScore) {
        this.clinicScore = clinicScore;
    }

    public Integer getClinicTreatmentConfirmImageCount() {
        return clinicTreatmentConfirmImageCount;
    }

    public void setClinicTreatmentConfirmImageCount(Integer clinicTreatmentConfirmImageCount) {
        this.clinicTreatmentConfirmImageCount = clinicTreatmentConfirmImageCount;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getApptOptUserType() {
		return apptOptUserType;
	}

	public void setApptOptUserType(Integer apptOptUserType) {
		this.apptOptUserType = apptOptUserType;
	}

	public String getAgentUserId() {
		return agentUserId;
	}

	public void setAgentUserId(String agentUserId) {
		this.agentUserId = agentUserId;
	}

	public String getPatientVisitId() {
        return patientVisitId;
    }

    public void setPatientVisitId(String patientVisitId) {
        this.patientVisitId = patientVisitId;
    }

    public String getPatientVisitName() {
		return patientVisitName;
	}

	public void setPatientVisitName(String patientVisitName) {
		this.patientVisitName = patientVisitName;
	}

	public Integer getIsClinicApptConfirmOvertime() {
        return isClinicApptConfirmOvertime;
    }

    public void setIsClinicApptConfirmOvertime(Integer isClinicApptConfirmOvertime) {
        this.isClinicApptConfirmOvertime = isClinicApptConfirmOvertime;
    }

    public Integer getIsUserTreatmentConfirmOvertime() {
        return isUserTreatmentConfirmOvertime;
    }

    public void setIsUserTreatmentConfirmOvertime(Integer isUserTreatmentConfirmOvertime) {
        this.isUserTreatmentConfirmOvertime = isUserTreatmentConfirmOvertime;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        IssueOBProductServiceRecord other = (IssueOBProductServiceRecord) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getObId() == null ? other.getObId() == null : this.getObId().equals(other.getObId()))
            && (this.getApptorderCode() == null ? other.getApptorderCode() == null : this.getApptorderCode().equals(other.getApptorderCode()))
            && (this.getApptStatus() == null ? other.getApptStatus() == null : this.getApptStatus().equals(other.getApptStatus()))
            && (this.getApptTime() == null ? other.getApptTime() == null : this.getApptTime().equals(other.getApptTime()))
            && (this.getClinicId() == null ? other.getClinicId() == null : this.getClinicId().equals(other.getClinicId()))
            && (this.getClinicName() == null ? other.getClinicName() == null : this.getClinicName().equals(other.getClinicName()))
            && (this.getScheduleDate() == null ? other.getScheduleDate() == null : this.getScheduleDate().equals(other.getScheduleDate()))
            && (this.getTimeSpanStartTime() == null ? other.getTimeSpanStartTime() == null : this.getTimeSpanStartTime().equals(other.getTimeSpanStartTime()))
            && (this.getTimeSpanEndTime() == null ? other.getTimeSpanEndTime() == null : this.getTimeSpanEndTime().equals(other.getTimeSpanEndTime()))
            && (this.getIsClinicApptConfirm() == null ? other.getIsClinicApptConfirm() == null : this.getIsClinicApptConfirm().equals(other.getIsClinicApptConfirm()))
            && (this.getIsUserTreatmentConfirm() == null ? other.getIsUserTreatmentConfirm() == null : this.getIsUserTreatmentConfirm().equals(other.getIsUserTreatmentConfirm()))
            && (this.getIsClinicTreatmentConfirm() == null ? other.getIsClinicTreatmentConfirm() == null : this.getIsClinicTreatmentConfirm().equals(other.getIsClinicTreatmentConfirm()))
            && (this.getApptCancelType() == null ? other.getApptCancelType() == null : this.getApptCancelType().equals(other.getApptCancelType()))
            && (this.getCardId() == null ? other.getCardId() == null : this.getCardId().equals(other.getCardId()))
            && (this.getCardNo() == null ? other.getCardNo() == null : this.getCardNo().equals(other.getCardNo()))
            && (this.getHealthProductId() == null ? other.getHealthProductId() == null : this.getHealthProductId().equals(other.getHealthProductId()))
            && (this.getHealthProductName() == null ? other.getHealthProductName() == null : this.getHealthProductName().equals(other.getHealthProductName()))
            && (this.getProductTypeName() == null ? other.getProductTypeName() == null : this.getProductTypeName().equals(other.getProductTypeName()))
            && (this.getHealthProductItemId() == null ? other.getHealthProductItemId() == null : this.getHealthProductItemId().equals(other.getHealthProductItemId()))
            && (this.getHealthProductItemName() == null ? other.getHealthProductItemName() == null : this.getHealthProductItemName().equals(other.getHealthProductItemName()))
            && (this.getClinicScore() == null ? other.getClinicScore() == null : this.getClinicScore().equals(other.getClinicScore()))
            && (this.getClinicTreatmentConfirmImageCount() == null ? other.getClinicTreatmentConfirmImageCount() == null : this.getClinicTreatmentConfirmImageCount().equals(other.getClinicTreatmentConfirmImageCount()))
            && (this.getUserId() == null ? other.getUserId() == null : this.getUserId().equals(other.getUserId()))
            && (this.getPatientVisitId() == null ? other.getPatientVisitId() == null : this.getPatientVisitId().equals(other.getPatientVisitId()))
            && (this.getIsClinicApptConfirmOvertime() == null ? other.getIsClinicApptConfirmOvertime() == null : this.getIsClinicApptConfirmOvertime().equals(other.getIsClinicApptConfirmOvertime()))
            && (this.getIsUserTreatmentConfirmOvertime() == null ? other.getIsUserTreatmentConfirmOvertime() == null : this.getIsUserTreatmentConfirmOvertime().equals(other.getIsUserTreatmentConfirmOvertime()))
            && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate()))
            && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser()))
            && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate()))
            && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getObId() == null) ? 0 : getObId().hashCode());
        result = prime * result + ((getApptorderCode() == null) ? 0 : getApptorderCode().hashCode());
        result = prime * result + ((getApptStatus() == null) ? 0 : getApptStatus().hashCode());
        result = prime * result + ((getApptTime() == null) ? 0 : getApptTime().hashCode());
        result = prime * result + ((getClinicId() == null) ? 0 : getClinicId().hashCode());
        result = prime * result + ((getClinicName() == null) ? 0 : getClinicName().hashCode());
        result = prime * result + ((getScheduleDate() == null) ? 0 : getScheduleDate().hashCode());
        result = prime * result + ((getTimeSpanStartTime() == null) ? 0 : getTimeSpanStartTime().hashCode());
        result = prime * result + ((getTimeSpanEndTime() == null) ? 0 : getTimeSpanEndTime().hashCode());
        result = prime * result + ((getIsClinicApptConfirm() == null) ? 0 : getIsClinicApptConfirm().hashCode());
        result = prime * result + ((getIsUserTreatmentConfirm() == null) ? 0 : getIsUserTreatmentConfirm().hashCode());
        result = prime * result + ((getIsClinicTreatmentConfirm() == null) ? 0 : getIsClinicTreatmentConfirm().hashCode());
        result = prime * result + ((getApptCancelType() == null) ? 0 : getApptCancelType().hashCode());
        result = prime * result + ((getCardId() == null) ? 0 : getCardId().hashCode());
        result = prime * result + ((getCardNo() == null) ? 0 : getCardNo().hashCode());
        result = prime * result + ((getHealthProductId() == null) ? 0 : getHealthProductId().hashCode());
        result = prime * result + ((getHealthProductName() == null) ? 0 : getHealthProductName().hashCode());
        result = prime * result + ((getProductTypeName() == null) ? 0 : getProductTypeName().hashCode());
        result = prime * result + ((getHealthProductItemId() == null) ? 0 : getHealthProductItemId().hashCode());
        result = prime * result + ((getHealthProductItemName() == null) ? 0 : getHealthProductItemName().hashCode());
        result = prime * result + ((getClinicScore() == null) ? 0 : getClinicScore().hashCode());
        result = prime * result + ((getClinicTreatmentConfirmImageCount() == null) ? 0 : getClinicTreatmentConfirmImageCount().hashCode());
        result = prime * result + ((getUserId() == null) ? 0 : getUserId().hashCode());
        result = prime * result + ((getPatientVisitId() == null) ? 0 : getPatientVisitId().hashCode());
        result = prime * result + ((getIsClinicApptConfirmOvertime() == null) ? 0 : getIsClinicApptConfirmOvertime().hashCode());
        result = prime * result + ((getIsUserTreatmentConfirmOvertime() == null) ? 0 : getIsUserTreatmentConfirmOvertime().hashCode());
        result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
        result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
        result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
        result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        return result;
    }
}