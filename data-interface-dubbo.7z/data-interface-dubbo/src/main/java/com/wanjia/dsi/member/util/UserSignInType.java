package com.wanjia.dsi.member.util;

/**
 * 用户签到类型
 * 
 * @author LUOXIAOJUN640
 *
 */
public enum UserSignInType {

	RED_PACKET_20161204("RED_PACKET_20161204", "day", "累计签到5次，获取红包");

	private String key;
	private String type;
	private String desc;

	private UserSignInType(String key, String type, String desc) {
		this.key = key;
		this.setType(type);
		this.desc = desc;
	}

	public static UserSignInType getInstance(String key) {
		if (key != null) {
			UserSignInType[] list = UserSignInType.values();
			for (UserSignInType source : list) {
				if (source.getKey().equals(key)) {
					return source;
				}
			}
		}

		return null;
	}

	public String getKey() {
		return key;
	}

	public String getDesc() {
		return desc;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
