package com.wanjia.dsi.web.job.service;

import java.util.List;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job.model.TalentJobHot;


public interface TalentJobHotService {
	
	public JsonResponse<List<TalentJobHot>> getAllClinicJobHotList(String requestId,TalentJobHot clinicJobHot);

}
