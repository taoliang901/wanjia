package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ClinicInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	private String id;

	private String clinicRegisterId;

	private String clinicName;

	private String clinicLogoPath;

	private String bankId;

	private String bankBranchId;

	private String accountNo;

	private String isMedicalInsurance;

	private String mobile;

	private String phone;

	private String openingTime;

    private String openingTimeBegin;

    private String openingTimeEnd;

    private String openingTimeType;

    private String openingTimeOther;

    private String clinicTypeProperty;

	private String clinicTypeDepartments;

	private String diagnosisTypeCode1;

	private String diagnosisType1;

    private String diagnosisTypeCode2;

    private String diagnosisType2;

    private String diagnosisItem;

	private String clinicIntroduce;

	private String businessLicenseNo;

	private String businessLicensePath;

	private String practicingLicenseNo;

	private String practicingLicensePath;

	private String practicingLicenseFPath;

    private String practicingLicenseF2Path;

    private String practicingLicenseF3Path;

    private String organizationNo;

	private String organizationPath;

	private String taxRegistrationNo;

	private String taxRegistrationPath;

	private String civilAffairsFiling;

    private String civilAffairsPath;

    private String radiationDiagnosisNo;

    private String radiationDiagnosisPath;

    private String radiationSaftyNo;

    private String radiationSaftyPath;

    private String legalRepresentativeNo;

    private String legalRepresentativeIda;

    private String legalRepresentativeIdb;

	private String administratorName;

	private String administratorTel;

	private String administratorIda;

	private String administratorIdb;

	private String authorizeMagPath;

	private String clinicPhotoPath;

	private String clinicFacadeName;

	private String clinicWaitingName;

	private String clinicMedLabName;

	private String clinicOtherName;

	private BigDecimal operatingArea;

	private Long aloneRoom;

	private BigDecimal waitingArea;

	private BigDecimal childrenArea;

	private String specialTechnology;

	private Long annualDiagnosisPerson;

	private Long medicalServiceIncome;

	private String operatingBeginDate;

	private String sameClinicIntroduce;

	private String managementSystem;

	private String systemBrand;

	private String hardwareFacility;

	private String operatingDifficulty;

	private String checkStatus;

	private String checkReason;

	private String createUser;

	private Date createDate;

	private String modifyUser;

	private Date modifyDate;

    private String delFlag = "0";

	private String clinicCompleteFlag1;

	private String clinicCompleteFlag2;

	private String clinicCompleteFlag3;

	private String dataResource;

    private String registerResource;

    private String isWanjia;

    private Date submitDate;

    private Date checkDate;

    private String checkUser;

	private Date beginDate;

	private Date endDate;
	
	private String country;
	
	private String countryCode;
	
	private String province;
	
	private String city;
	
	private String district;

	private String provinceCode;
	
	private String cityCode;
	
	private String districtCode;

	private String address;
	
	private String isView;
	
	private String email;
	
	private String referred;
	
	// 诊所审核状态(1:有效, 0:无效)
	private String checkIsValid;
		
	//诊所上线状态(1:有效, 0:无效)
	private String onlineIsValid;
	
	//诊所是否开通云诊所服务(E1:已开通, E0:未开通)
	private String isCloudService;
	// 认证审核结果，数据字典为CLINIC_RZ_RESULT，00-未认证过、01-暂无（认证中），02-三星认证通过，03-三星认证未通过
	private String auditResult; 
	
	public ClinicInfo() {
		// TODO Auto-generated constructor stub
	}

	public String getIsView() {
		return isView;
	}

	public void setIsView(String isView) {
		this.isView = isView;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClinicRegisterId() {
		return clinicRegisterId;
	}

	public void setClinicRegisterId(String clinicRegisterId) {
		this.clinicRegisterId = clinicRegisterId;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getClinicLogoPath() {
		return clinicLogoPath;
	}

	public void setClinicLogoPath(String clinicLogoPath) {
		this.clinicLogoPath = clinicLogoPath;
	}

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getBankBranchId() {
		return bankBranchId;
	}

	public void setBankBranchId(String bankBranchId) {
		this.bankBranchId = bankBranchId;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getIsMedicalInsurance() {
		return isMedicalInsurance;
	}

	public void setIsMedicalInsurance(String isMedicalInsurance) {
		this.isMedicalInsurance = isMedicalInsurance;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getOpeningTime() {
		return openingTime;
	}

	public void setOpeningTime(String openingTime) {
		this.openingTime = openingTime;
	}

    public String getOpeningTimeBegin() {
        return openingTimeBegin;
    }

    public void setOpeningTimeBegin(String openingTimeBegin) {
        this.openingTimeBegin = openingTimeBegin == null ? null : openingTimeBegin.trim();
    }

    public String getOpeningTimeEnd() {
        return openingTimeEnd;
    }

    public void setOpeningTimeEnd(String openingTimeEnd) {
        this.openingTimeEnd = openingTimeEnd == null ? null : openingTimeEnd.trim();
    }

    public String getOpeningTimeType() {
        return openingTimeType;
    }

    public void setOpeningTimeType(String openingTimeType) {
        this.openingTimeType = openingTimeType == null ? null : openingTimeType.trim();
    }

    public String getOpeningTimeOther() {
        return openingTimeOther;
    }

    public void setOpeningTimeOther(String openingTimeOther) {
        this.openingTimeOther = openingTimeOther == null ? null : openingTimeOther.trim();
    }

	public String getClinicTypeProperty() {
		return clinicTypeProperty;
	}

	public void setClinicTypeProperty(String clinicTypeProperty) {
		this.clinicTypeProperty = clinicTypeProperty;
	}

	public String getClinicTypeDepartments() {
		return clinicTypeDepartments;
	}

	public void setClinicTypeDepartments(String clinicTypeDepartments) {
		this.clinicTypeDepartments = clinicTypeDepartments;
	}

	public String getDiagnosisTypeCode1() {
		return diagnosisTypeCode1;
	}

	public void setDiagnosisTypeCode1(String diagnosisTypeCode1) {
		this.diagnosisTypeCode1 = diagnosisTypeCode1;
	}

	public String getDiagnosisType1() {
		return diagnosisType1;
	}

	public void setDiagnosisType1(String diagnosisType1) {
		this.diagnosisType1 = diagnosisType1;
	}

    public String getDiagnosisTypeCode2() {
        return diagnosisTypeCode2;
    }

    public void setDiagnosisTypeCode2(String diagnosisTypeCode2) {
        this.diagnosisTypeCode2 = diagnosisTypeCode2 == null ? null : diagnosisTypeCode2.trim();
    }

    public String getDiagnosisType2() {
        return diagnosisType2;
    }

    public void setDiagnosisType2(String diagnosisType2) {
        this.diagnosisType2 = diagnosisType2 == null ? null : diagnosisType2.trim();
    }

    public String getDiagnosisItem() {
        return diagnosisItem;
    }

	public void setDiagnosisItem(String diagnosisItem) {
		this.diagnosisItem = diagnosisItem;
	}

	public String getClinicIntroduce() {
		return clinicIntroduce;
	}

	public void setClinicIntroduce(String clinicIntroduce) {
		this.clinicIntroduce = clinicIntroduce;
	}

	public String getBusinessLicenseNo() {
		return businessLicenseNo;
	}

	public void setBusinessLicenseNo(String businessLicenseNo) {
		this.businessLicenseNo = businessLicenseNo;
	}

	public String getBusinessLicensePath() {
		return businessLicensePath;
	}

	public void setBusinessLicensePath(String businessLicensePath) {
		this.businessLicensePath = businessLicensePath;
	}

	public String getPracticingLicenseNo() {
		return practicingLicenseNo;
	}

	public void setPracticingLicenseNo(String practicingLicenseNo) {
		this.practicingLicenseNo = practicingLicenseNo;
	}

	public String getPracticingLicensePath() {
		return practicingLicensePath;
	}

	public void setPracticingLicensePath(String practicingLicensePath) {
		this.practicingLicensePath = practicingLicensePath;
	}

	public String getPracticingLicenseFPath() {
		return practicingLicenseFPath;
	}

	public void setPracticingLicenseFPath(String practicingLicenseFPath) {
		this.practicingLicenseFPath = practicingLicenseFPath;
	}

    public String getPracticingLicenseF2Path() {
        return practicingLicenseF2Path;
    }

    public void setPracticingLicenseF2Path(String practicingLicenseF2Path) {
        this.practicingLicenseF2Path = practicingLicenseF2Path == null ? null : practicingLicenseF2Path.trim();
    }

    public String getPracticingLicenseF3Path() {
        return practicingLicenseF3Path;
    }

    public void setPracticingLicenseF3Path(String practicingLicenseF3Path) {
        this.practicingLicenseF3Path = practicingLicenseF3Path == null ? null : practicingLicenseF3Path.trim();
    }

    public String getOrganizationNo() {
        return organizationNo;
    }

	public void setOrganizationNo(String organizationNo) {
		this.organizationNo = organizationNo;
	}

	public String getOrganizationPath() {
		return organizationPath;
	}

	public void setOrganizationPath(String organizationPath) {
		this.organizationPath = organizationPath;
	}

	public String getTaxRegistrationNo() {
		return taxRegistrationNo;
	}

	public void setTaxRegistrationNo(String taxRegistrationNo) {
		this.taxRegistrationNo = taxRegistrationNo;
	}

	public String getTaxRegistrationPath() {
		return taxRegistrationPath;
	}

	public void setTaxRegistrationPath(String taxRegistrationPath) {
		this.taxRegistrationPath = taxRegistrationPath;
	}

	public String getCivilAffairsFiling() {
		return civilAffairsFiling;
	}

	public void setCivilAffairsFiling(String civilAffairsFiling) {
		this.civilAffairsFiling = civilAffairsFiling;
	}

	public String getCivilAffairsPath() {
		return civilAffairsPath;
	}

	public void setCivilAffairsPath(String civilAffairsPath) {
		this.civilAffairsPath = civilAffairsPath;
	}

    public String getRadiationDiagnosisNo() {
        return radiationDiagnosisNo;
    }

    public void setRadiationDiagnosisNo(String radiationDiagnosisNo) {
        this.radiationDiagnosisNo = radiationDiagnosisNo == null ? null : radiationDiagnosisNo.trim();
    }

    public String getRadiationDiagnosisPath() {
        return radiationDiagnosisPath;
    }

    public void setRadiationDiagnosisPath(String radiationDiagnosisPath) {
        this.radiationDiagnosisPath = radiationDiagnosisPath == null ? null : radiationDiagnosisPath.trim();
    }

    public String getRadiationSaftyNo() {
        return radiationSaftyNo;
    }

    public void setRadiationSaftyNo(String radiationSaftyNo) {
        this.radiationSaftyNo = radiationSaftyNo == null ? null : radiationSaftyNo.trim();
    }

    public String getRadiationSaftyPath() {
        return radiationSaftyPath;
    }

    public void setRadiationSaftyPath(String radiationSaftyPath) {
        this.radiationSaftyPath = radiationSaftyPath == null ? null : radiationSaftyPath.trim();
    }

    public String getLegalRepresentativeNo() {
        return legalRepresentativeNo;
    }

    public void setLegalRepresentativeNo(String legalRepresentativeNo) {
        this.legalRepresentativeNo = legalRepresentativeNo == null ? null : legalRepresentativeNo.trim();
    }

    public String getLegalRepresentativeIda() {
        return legalRepresentativeIda;
    }

    public void setLegalRepresentativeIda(String legalRepresentativeIda) {
        this.legalRepresentativeIda = legalRepresentativeIda == null ? null : legalRepresentativeIda.trim();
    }

    public String getLegalRepresentativeIdb() {
        return legalRepresentativeIdb;
    }

    public void setLegalRepresentativeIdb(String legalRepresentativeIdb) {
        this.legalRepresentativeIdb = legalRepresentativeIdb == null ? null : legalRepresentativeIdb.trim();
    }

    public String getAdministratorName() {
        return administratorName;
    }

	public void setAdministratorName(String administratorName) {
		this.administratorName = administratorName;
	}

	public String getAdministratorTel() {
		return administratorTel;
	}

	public void setAdministratorTel(String administratorTel) {
		this.administratorTel = administratorTel;
	}

	public String getAdministratorIda() {
		return administratorIda;
	}

	public void setAdministratorIda(String administratorIda) {
		this.administratorIda = administratorIda;
	}

	public String getAdministratorIdb() {
		return administratorIdb;
	}

	public void setAdministratorIdb(String administratorIdb) {
		this.administratorIdb = administratorIdb;
	}

	public String getAuthorizeMagPath() {
		return authorizeMagPath;
	}

	public void setAuthorizeMagPath(String authorizeMagPath) {
		this.authorizeMagPath = authorizeMagPath;
	}

	public String getClinicPhotoPath() {
		return clinicPhotoPath;
	}

	public void setClinicPhotoPath(String clinicPhotoPath) {
		this.clinicPhotoPath = clinicPhotoPath;
	}

	public String getClinicFacadeName() {
		return clinicFacadeName;
	}

	public void setClinicFacadeName(String clinicFacadeName) {
		this.clinicFacadeName = clinicFacadeName;
	}

	public String getClinicWaitingName() {
		return clinicWaitingName;
	}

	public void setClinicWaitingName(String clinicWaitingName) {
		this.clinicWaitingName = clinicWaitingName;
	}

	public String getClinicMedLabName() {
		return clinicMedLabName;
	}

	public void setClinicMedLabName(String clinicMedLabName) {
		this.clinicMedLabName = clinicMedLabName;
	}

	public String getClinicOtherName() {
		return clinicOtherName;
	}

	public void setClinicOtherName(String clinicOtherName) {
		this.clinicOtherName = clinicOtherName;
	}

	public BigDecimal getOperatingArea() {
		return operatingArea;
	}

	public void setOperatingArea(BigDecimal operatingArea) {
		this.operatingArea = operatingArea;
	}

	public Long getAloneRoom() {
		return aloneRoom;
	}

	public void setAloneRoom(Long aloneRoom) {
		this.aloneRoom = aloneRoom;
	}

	public BigDecimal getWaitingArea() {
		return waitingArea;
	}

	public void setWaitingArea(BigDecimal waitingArea) {
		this.waitingArea = waitingArea;
	}

	public BigDecimal getChildrenArea() {
		return childrenArea;
	}

	public void setChildrenArea(BigDecimal childrenArea) {
		this.childrenArea = childrenArea;
	}

	public String getSpecialTechnology() {
		return specialTechnology;
	}

	public void setSpecialTechnology(String specialTechnology) {
		this.specialTechnology = specialTechnology;
	}

	public Long getAnnualDiagnosisPerson() {
		return annualDiagnosisPerson;
	}

	public void setAnnualDiagnosisPerson(Long annualDiagnosisPerson) {
		this.annualDiagnosisPerson = annualDiagnosisPerson;
	}

	public Long getMedicalServiceIncome() {
		return medicalServiceIncome;
	}

	public void setMedicalServiceIncome(Long medicalServiceIncome) {
		this.medicalServiceIncome = medicalServiceIncome;
	}

	public String getOperatingBeginDate() {
		return operatingBeginDate;
	}

	public void setOperatingBeginDate(String operatingBeginDate) {
		this.operatingBeginDate = operatingBeginDate;
	}

	public String getSameClinicIntroduce() {
		return sameClinicIntroduce;
	}

	public void setSameClinicIntroduce(String sameClinicIntroduce) {
		this.sameClinicIntroduce = sameClinicIntroduce;
	}

	public String getManagementSystem() {
		return managementSystem;
	}

	public void setManagementSystem(String managementSystem) {
		this.managementSystem = managementSystem;
	}

	public String getSystemBrand() {
		return systemBrand;
	}

	public void setSystemBrand(String systemBrand) {
		this.systemBrand = systemBrand;
	}

	public String getHardwareFacility() {
		return hardwareFacility;
	}

	public void setHardwareFacility(String hardwareFacility) {
		this.hardwareFacility = hardwareFacility;
	}

	public String getOperatingDifficulty() {
		return operatingDifficulty;
	}

	public void setOperatingDifficulty(String operatingDifficulty) {
		this.operatingDifficulty = operatingDifficulty;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	public String getCheckReason() {
		return checkReason;
	}

	public void setCheckReason(String checkReason) {
		this.checkReason = checkReason;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getClinicCompleteFlag1() {
		return clinicCompleteFlag1;
	}

	public void setClinicCompleteFlag1(String clinicCompleteFlag1) {
		this.clinicCompleteFlag1 = clinicCompleteFlag1;
	}

	public String getClinicCompleteFlag2() {
		return clinicCompleteFlag2;
	}

	public void setClinicCompleteFlag2(String clinicCompleteFlag2) {
		this.clinicCompleteFlag2 = clinicCompleteFlag2;
	}

	public String getClinicCompleteFlag3() {
		return clinicCompleteFlag3;
	}

	public void setClinicCompleteFlag3(String clinicCompleteFlag3) {
		this.clinicCompleteFlag3 = clinicCompleteFlag3;
	}

	public String getDataResource() {
		return dataResource;
	}

	public void setDataResource(String dataResource) {
		this.dataResource = dataResource;
	}

    public String getRegisterResource() {
        return registerResource;
    }

    public void setRegisterResource(String registerResource) {
        this.registerResource = registerResource == null ? null : registerResource.trim();
    }

    public String getIsWanjia() {
        return isWanjia;
    }

    public void setIsWanjia(String isWanjia) {
        this.isWanjia = isWanjia == null ? null : isWanjia.trim();
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(Date submitDate) {
        this.submitDate = submitDate;
    }

    public Date getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(Date checkDate) {
        this.checkDate = checkDate;
    }

    public String getCheckUser() {
        return checkUser;
    }

    public void setCheckUser(String checkUser) {
        this.checkUser = checkUser == null ? null : checkUser.trim();
    }

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getProvinceCode() {
		return provinceCode;
	}

	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getReferred() {
		return referred;
	}

	public void setReferred(String referred) {
		this.referred = referred;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIsCloudService() {
		return isCloudService;
	}

	public void setIsCloudService(String isCloudService) {
		this.isCloudService = isCloudService;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		ClinicInfo other = (ClinicInfo) that;
		return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
				&& (this.getClinicRegisterId() == null ? other.getClinicRegisterId() == null
						: this.getClinicRegisterId().equals(other.getClinicRegisterId()))
				&& (this.getClinicName() == null ? other.getClinicName() == null
						: this.getClinicName().equals(other.getClinicName()))
				&& (this.getClinicLogoPath() == null ? other.getClinicLogoPath() == null
						: this.getClinicLogoPath().equals(other.getClinicLogoPath()))
				&& (this.getBankId() == null ? other.getBankId() == null : this.getBankId().equals(other.getBankId()))
				&& (this.getBankBranchId() == null ? other.getBankBranchId() == null
						: this.getBankBranchId().equals(other.getBankBranchId()))
				&& (this.getAccountNo() == null ? other.getAccountNo() == null
						: this.getAccountNo().equals(other.getAccountNo()))
				&& (this.getIsMedicalInsurance() == null ? other.getIsMedicalInsurance() == null
						: this.getIsMedicalInsurance().equals(other.getIsMedicalInsurance()))
				&& (this.getMobile() == null ? other.getMobile() == null : this.getMobile().equals(other.getMobile()))
				&& (this.getPhone() == null ? other.getPhone() == null : this.getPhone().equals(other.getPhone()))
				&& (this.getOpeningTime() == null ? other.getOpeningTime() == null
						: this.getOpeningTime().equals(other.getOpeningTime()))
				&& (this.getClinicTypeProperty() == null ? other.getClinicTypeProperty() == null
						: this.getClinicTypeProperty().equals(other.getClinicTypeProperty()))
				&& (this.getClinicTypeDepartments() == null ? other.getClinicTypeDepartments() == null
						: this.getClinicTypeDepartments().equals(other.getClinicTypeDepartments()))
				&& (this.getDiagnosisTypeCode1() == null ? other.getDiagnosisTypeCode1() == null
						: this.getDiagnosisTypeCode1().equals(other.getDiagnosisTypeCode1()))
				&& (this.getDiagnosisType1() == null ? other.getDiagnosisType1() == null
						: this.getDiagnosisType1().equals(other.getDiagnosisType1()))
				&& (this.getDiagnosisItem() == null ? other.getDiagnosisItem() == null
						: this.getDiagnosisItem().equals(other.getDiagnosisItem()))
				&& (this.getClinicIntroduce() == null ? other.getClinicIntroduce() == null
						: this.getClinicIntroduce().equals(other.getClinicIntroduce()))
				&& (this.getBusinessLicenseNo() == null ? other.getBusinessLicenseNo() == null
						: this.getBusinessLicenseNo().equals(other.getBusinessLicenseNo()))
				&& (this.getBusinessLicensePath() == null ? other.getBusinessLicensePath() == null
						: this.getBusinessLicensePath().equals(other.getBusinessLicensePath()))
				&& (this.getPracticingLicenseNo() == null ? other.getPracticingLicenseNo() == null
						: this.getPracticingLicenseNo().equals(other.getPracticingLicenseNo()))
				&& (this.getPracticingLicensePath() == null ? other.getPracticingLicensePath() == null
						: this.getPracticingLicensePath().equals(other.getPracticingLicensePath()))
				&& (this.getPracticingLicenseFPath() == null ? other.getPracticingLicenseFPath() == null
						: this.getPracticingLicenseFPath().equals(other.getPracticingLicenseFPath()))
				&& (this.getOrganizationNo() == null ? other.getOrganizationNo() == null
						: this.getOrganizationNo().equals(other.getOrganizationNo()))
				&& (this.getOrganizationPath() == null ? other.getOrganizationPath() == null
						: this.getOrganizationPath().equals(other.getOrganizationPath()))
				&& (this.getTaxRegistrationNo() == null ? other.getTaxRegistrationNo() == null
						: this.getTaxRegistrationNo().equals(other.getTaxRegistrationNo()))
				&& (this.getTaxRegistrationPath() == null ? other.getTaxRegistrationPath() == null
						: this.getTaxRegistrationPath().equals(other.getTaxRegistrationPath()))
				&& (this.getCivilAffairsFiling() == null ? other.getCivilAffairsFiling() == null
						: this.getCivilAffairsFiling().equals(other.getCivilAffairsFiling()))
				&& (this.getCivilAffairsPath() == null ? other.getCivilAffairsPath() == null
						: this.getCivilAffairsPath().equals(other.getCivilAffairsPath()))
				&& (this.getAdministratorName() == null ? other.getAdministratorName() == null
						: this.getAdministratorName().equals(other.getAdministratorName()))
				&& (this.getAdministratorTel() == null ? other.getAdministratorTel() == null
						: this.getAdministratorTel().equals(other.getAdministratorTel()))
				&& (this.getAdministratorIda() == null ? other.getAdministratorIda() == null
						: this.getAdministratorIda().equals(other.getAdministratorIda()))
				&& (this.getAdministratorIdb() == null ? other.getAdministratorIdb() == null
						: this.getAdministratorIdb().equals(other.getAdministratorIdb()))
				&& (this.getAuthorizeMagPath() == null ? other.getAuthorizeMagPath() == null
						: this.getAuthorizeMagPath().equals(other.getAuthorizeMagPath()))
				&& (this.getClinicPhotoPath() == null ? other.getClinicPhotoPath() == null
						: this.getClinicPhotoPath().equals(other.getClinicPhotoPath()))
				&& (this.getClinicFacadeName() == null ? other.getClinicFacadeName() == null
						: this.getClinicFacadeName().equals(other.getClinicFacadeName()))
				&& (this.getClinicWaitingName() == null ? other.getClinicWaitingName() == null
						: this.getClinicWaitingName().equals(other.getClinicWaitingName()))
				&& (this.getClinicMedLabName() == null ? other.getClinicMedLabName() == null
						: this.getClinicMedLabName().equals(other.getClinicMedLabName()))
				&& (this.getClinicOtherName() == null ? other.getClinicOtherName() == null
						: this.getClinicOtherName().equals(other.getClinicOtherName()))
				&& (this.getOperatingArea() == null ? other.getOperatingArea() == null
						: this.getOperatingArea().equals(other.getOperatingArea()))
				&& (this.getAloneRoom() == null ? other.getAloneRoom() == null
						: this.getAloneRoom().equals(other.getAloneRoom()))
				&& (this.getWaitingArea() == null ? other.getWaitingArea() == null
						: this.getWaitingArea().equals(other.getWaitingArea()))
				&& (this.getChildrenArea() == null ? other.getChildrenArea() == null
						: this.getChildrenArea().equals(other.getChildrenArea()))
				&& (this.getSpecialTechnology() == null ? other.getSpecialTechnology() == null
						: this.getSpecialTechnology().equals(other.getSpecialTechnology()))
				&& (this.getAnnualDiagnosisPerson() == null ? other.getAnnualDiagnosisPerson() == null
						: this.getAnnualDiagnosisPerson().equals(other.getAnnualDiagnosisPerson()))
				&& (this.getMedicalServiceIncome() == null ? other.getMedicalServiceIncome() == null
						: this.getMedicalServiceIncome().equals(other.getMedicalServiceIncome()))
				&& (this.getOperatingBeginDate() == null ? other.getOperatingBeginDate() == null
						: this.getOperatingBeginDate().equals(other.getOperatingBeginDate()))
				&& (this.getSameClinicIntroduce() == null ? other.getSameClinicIntroduce() == null
						: this.getSameClinicIntroduce().equals(other.getSameClinicIntroduce()))
				&& (this.getManagementSystem() == null ? other.getManagementSystem() == null
						: this.getManagementSystem().equals(other.getManagementSystem()))
				&& (this.getSystemBrand() == null ? other.getSystemBrand() == null
						: this.getSystemBrand().equals(other.getSystemBrand()))
				&& (this.getHardwareFacility() == null ? other.getHardwareFacility() == null
						: this.getHardwareFacility().equals(other.getHardwareFacility()))
				&& (this.getOperatingDifficulty() == null ? other.getOperatingDifficulty() == null
						: this.getOperatingDifficulty().equals(other.getOperatingDifficulty()))
				&& (this.getCheckStatus() == null ? other.getCheckStatus() == null
						: this.getCheckStatus().equals(other.getCheckStatus()))
				&& (this.getCheckReason() == null ? other.getCheckReason() == null
						: this.getCheckReason().equals(other.getCheckReason()))
				&& (this.getCreateUser() == null ? other.getCreateUser() == null
						: this.getCreateUser().equals(other.getCreateUser()))
				&& (this.getCreateDate() == null ? other.getCreateDate() == null
						: this.getCreateDate().equals(other.getCreateDate()))
				&& (this.getModifyUser() == null ? other.getModifyUser() == null
						: this.getModifyUser().equals(other.getModifyUser()))
				&& (this.getModifyDate() == null ? other.getModifyDate() == null
						: this.getModifyDate().equals(other.getModifyDate()))
				&& (this.getDelFlag() == null ? other.getDelFlag() == null
						: this.getDelFlag().equals(other.getDelFlag()))
				&& (this.getClinicCompleteFlag1() == null ? other.getClinicCompleteFlag1() == null
						: this.getClinicCompleteFlag1().equals(other.getClinicCompleteFlag1()))
				&& (this.getClinicCompleteFlag2() == null ? other.getClinicCompleteFlag2() == null
						: this.getClinicCompleteFlag2().equals(other.getClinicCompleteFlag2()))
				&& (this.getClinicCompleteFlag3() == null ? other.getClinicCompleteFlag3() == null
						: this.getClinicCompleteFlag3().equals(other.getClinicCompleteFlag3()))
				&& (this.getDataResource() == null ? other.getDataResource() == null
						: this.getDataResource().equals(other.getDataResource()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		result = prime * result + ((getClinicRegisterId() == null) ? 0 : getClinicRegisterId().hashCode());
		result = prime * result + ((getClinicName() == null) ? 0 : getClinicName().hashCode());
		result = prime * result + ((getClinicLogoPath() == null) ? 0 : getClinicLogoPath().hashCode());
		result = prime * result + ((getBankId() == null) ? 0 : getBankId().hashCode());
		result = prime * result + ((getBankBranchId() == null) ? 0 : getBankBranchId().hashCode());
		result = prime * result + ((getAccountNo() == null) ? 0 : getAccountNo().hashCode());
		result = prime * result + ((getIsMedicalInsurance() == null) ? 0 : getIsMedicalInsurance().hashCode());
		result = prime * result + ((getMobile() == null) ? 0 : getMobile().hashCode());
		result = prime * result + ((getPhone() == null) ? 0 : getPhone().hashCode());
		result = prime * result + ((getOpeningTime() == null) ? 0 : getOpeningTime().hashCode());
		result = prime * result + ((getClinicTypeProperty() == null) ? 0 : getClinicTypeProperty().hashCode());
		result = prime * result + ((getClinicTypeDepartments() == null) ? 0 : getClinicTypeDepartments().hashCode());
		result = prime * result + ((getDiagnosisTypeCode1() == null) ? 0 : getDiagnosisTypeCode1().hashCode());
		result = prime * result + ((getDiagnosisType1() == null) ? 0 : getDiagnosisType1().hashCode());
		result = prime * result + ((getDiagnosisItem() == null) ? 0 : getDiagnosisItem().hashCode());
		result = prime * result + ((getClinicIntroduce() == null) ? 0 : getClinicIntroduce().hashCode());
		result = prime * result + ((getBusinessLicenseNo() == null) ? 0 : getBusinessLicenseNo().hashCode());
		result = prime * result + ((getBusinessLicensePath() == null) ? 0 : getBusinessLicensePath().hashCode());
		result = prime * result + ((getPracticingLicenseNo() == null) ? 0 : getPracticingLicenseNo().hashCode());
		result = prime * result + ((getPracticingLicensePath() == null) ? 0 : getPracticingLicensePath().hashCode());
		result = prime * result + ((getPracticingLicenseFPath() == null) ? 0 : getPracticingLicenseFPath().hashCode());
		result = prime * result + ((getOrganizationNo() == null) ? 0 : getOrganizationNo().hashCode());
		result = prime * result + ((getOrganizationPath() == null) ? 0 : getOrganizationPath().hashCode());
		result = prime * result + ((getTaxRegistrationNo() == null) ? 0 : getTaxRegistrationNo().hashCode());
		result = prime * result + ((getTaxRegistrationPath() == null) ? 0 : getTaxRegistrationPath().hashCode());
		result = prime * result + ((getCivilAffairsFiling() == null) ? 0 : getCivilAffairsFiling().hashCode());
		result = prime * result + ((getCivilAffairsPath() == null) ? 0 : getCivilAffairsPath().hashCode());
		result = prime * result + ((getAdministratorName() == null) ? 0 : getAdministratorName().hashCode());
		result = prime * result + ((getAdministratorTel() == null) ? 0 : getAdministratorTel().hashCode());
		result = prime * result + ((getAdministratorIda() == null) ? 0 : getAdministratorIda().hashCode());
		result = prime * result + ((getAdministratorIdb() == null) ? 0 : getAdministratorIdb().hashCode());
		result = prime * result + ((getAuthorizeMagPath() == null) ? 0 : getAuthorizeMagPath().hashCode());
		result = prime * result + ((getClinicPhotoPath() == null) ? 0 : getClinicPhotoPath().hashCode());
		result = prime * result + ((getClinicFacadeName() == null) ? 0 : getClinicFacadeName().hashCode());
		result = prime * result + ((getClinicWaitingName() == null) ? 0 : getClinicWaitingName().hashCode());
		result = prime * result + ((getClinicMedLabName() == null) ? 0 : getClinicMedLabName().hashCode());
		result = prime * result + ((getClinicOtherName() == null) ? 0 : getClinicOtherName().hashCode());
		result = prime * result + ((getOperatingArea() == null) ? 0 : getOperatingArea().hashCode());
		result = prime * result + ((getAloneRoom() == null) ? 0 : getAloneRoom().hashCode());
		result = prime * result + ((getWaitingArea() == null) ? 0 : getWaitingArea().hashCode());
		result = prime * result + ((getChildrenArea() == null) ? 0 : getChildrenArea().hashCode());
		result = prime * result + ((getSpecialTechnology() == null) ? 0 : getSpecialTechnology().hashCode());
		result = prime * result + ((getAnnualDiagnosisPerson() == null) ? 0 : getAnnualDiagnosisPerson().hashCode());
		result = prime * result + ((getMedicalServiceIncome() == null) ? 0 : getMedicalServiceIncome().hashCode());
		result = prime * result + ((getOperatingBeginDate() == null) ? 0 : getOperatingBeginDate().hashCode());
		result = prime * result + ((getSameClinicIntroduce() == null) ? 0 : getSameClinicIntroduce().hashCode());
		result = prime * result + ((getManagementSystem() == null) ? 0 : getManagementSystem().hashCode());
		result = prime * result + ((getSystemBrand() == null) ? 0 : getSystemBrand().hashCode());
		result = prime * result + ((getHardwareFacility() == null) ? 0 : getHardwareFacility().hashCode());
		result = prime * result + ((getOperatingDifficulty() == null) ? 0 : getOperatingDifficulty().hashCode());
		result = prime * result + ((getCheckStatus() == null) ? 0 : getCheckStatus().hashCode());
		result = prime * result + ((getCheckReason() == null) ? 0 : getCheckReason().hashCode());
		result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
		result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
		result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
		result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
		result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
		result = prime * result + ((getClinicCompleteFlag1() == null) ? 0 : getClinicCompleteFlag1().hashCode());
		result = prime * result + ((getClinicCompleteFlag2() == null) ? 0 : getClinicCompleteFlag2().hashCode());
		result = prime * result + ((getClinicCompleteFlag3() == null) ? 0 : getClinicCompleteFlag3().hashCode());
		result = prime * result + ((getDataResource() == null) ? 0 : getDataResource().hashCode());
		return result;
	}

	public String getCheckIsValid() {
		return checkIsValid;
	}

	public void setCheckIsValid(String checkIsValid) {
		this.checkIsValid = checkIsValid;
	}

	public String getOnlineIsValid() {
		return onlineIsValid;
	}

	public void setOnlineIsValid(String onlineIsValid) {
		this.onlineIsValid = onlineIsValid;
	}

	public String getAuditResult() {
		return auditResult;
	}

	public void setAuditResult(String auditResult) {
		this.auditResult = auditResult;
	}
	
}