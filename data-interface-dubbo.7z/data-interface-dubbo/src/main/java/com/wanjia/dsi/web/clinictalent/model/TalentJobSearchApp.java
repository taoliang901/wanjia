package com.wanjia.dsi.web.clinictalent.model;

import java.io.Serializable;
import java.util.Date;

public class TalentJobSearchApp implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;

    private String clinicId;

    private String intentionJob;

    private String intentionJobName;

    private String rank;

    private String rankName;

    private String jobRemark;

    private Integer recruitNum;

    private String status;

    private Date releaseTime;

    private String remark;
    
    //岗位全称（不包含自定义内容）
    private String jobName;
    
    //接收简历数
    private int acceptCvCount;
    
    //面试邀请数
    private int interviewInvationCount;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClinicId() {
		return clinicId;
	}

	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}

	public String getIntentionJob() {
		return intentionJob;
	}

	public void setIntentionJob(String intentionJob) {
		this.intentionJob = intentionJob;
	}

	public String getIntentionJobName() {
		return intentionJobName;
	}

	public void setIntentionJobName(String intentionJobName) {
		this.intentionJobName = intentionJobName;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getRankName() {
		return rankName;
	}

	public void setRankName(String rankName) {
		this.rankName = rankName;
	}

	public String getJobRemark() {
		return jobRemark;
	}

	public void setJobRemark(String jobRemark) {
		this.jobRemark = jobRemark;
	}

	public Integer getRecruitNum() {
		return recruitNum;
	}

	public void setRecruitNum(Integer recruitNum) {
		this.recruitNum = recruitNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getReleaseTime() {
		return releaseTime;
	}

	public void setReleaseTime(Date releaseTime) {
		this.releaseTime = releaseTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public int getAcceptCvCount() {
		return acceptCvCount;
	}

	public void setAcceptCvCount(int acceptCvCount) {
		this.acceptCvCount = acceptCvCount;
	}

	public int getInterviewInvationCount() {
		return interviewInvationCount;
	}

	public void setInterviewInvationCount(int interviewInvationCount) {
		this.interviewInvationCount = interviewInvationCount;
	}

    
    
    
}
