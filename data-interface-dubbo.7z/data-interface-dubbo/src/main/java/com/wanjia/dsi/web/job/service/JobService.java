package com.wanjia.dsi.web.job.service;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.job.model.ClinicSearch;
import com.wanjia.dsi.web.job.model.JobSearch;

public interface JobService {
	
	public JsonResponse<PageInfo<JobSearch>> getJobSearchList(String requestId,JobSearch jobSearch);
	
	public JsonResponse<PageInfo<ClinicSearch>> getClinicSearchList(String requestId,ClinicSearch clinicSearch);
	
	public JsonResponse<JobSearch> getJobSearchDetailById(String requestId,String jobId);
	
	public JsonResponse<ClinicSearch> getClinicSearchDetailById(String requestId,String clinicId);
	
	@SuppressWarnings("rawtypes")
	public JsonResponse updateClinicJobStatic();

}
