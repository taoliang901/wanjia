package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;
import java.util.Date;

public class ClinicDailyAccessKey implements Serializable {
    private static final long serialVersionUID = 1L;

    private Date clinicAccessDate;

    private String clinicId;

    public Date getClinicAccessDate() {
        return clinicAccessDate;
    }

    public void setClinicAccessDate(Date clinicAccessDate) {
        this.clinicAccessDate = clinicAccessDate;
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        ClinicDailyAccessKey other = (ClinicDailyAccessKey) that;
        return (this.getClinicAccessDate() == null ? other.getClinicAccessDate() == null : this.getClinicAccessDate().equals(other.getClinicAccessDate()))
            && (this.getClinicId() == null ? other.getClinicId() == null : this.getClinicId().equals(other.getClinicId()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getClinicAccessDate() == null) ? 0 : getClinicAccessDate().hashCode());
        result = prime * result + ((getClinicId() == null) ? 0 : getClinicId().hashCode());
        return result;
    }
}