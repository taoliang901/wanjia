package com.wanjia.dsi.web.clinictalent.service;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinictalent.model.TalentCvRecordSearchApp;
import com.wanjia.dsi.web.clinictalent.model.TalentCvSearchApp;
import com.wanjia.dsi.web.clinictalent.model.TalentJobSearchApp;
import com.wanjia.dsi.web.job.model.TalentCv;
import com.wanjia.dsi.web.job.model.TalentCvRecord;
import com.wanjia.dsi.web.job.model.TalentJob;
import com.wanjia.dsi.web.job.model.TalentJobRecord;
import com.wanjia.dsi.web.job.model.TalentJobWithBLOBs;

public interface TalentJobService {
	
	
	
	/**
	 * 根据主键获取岗位信息
	 * @param pkey 岗位表主键
	 * @return
	 */
	public JsonResponse<TalentJobWithBLOBs> getTalentJobByPk(String pkey);
	
	/**
	 * 根据主键获取接收简历记录信息
	 * @param pkey 记录表主键
	 * @return
	 */
	public JsonResponse<TalentJobRecord> getTalentJobRecordByPk(String pkey);
	
	
	
	/**
	 * 更新简历接收记录（根据主键全部更新）
	 * @param talentJobWithBLOBs
	 * @return 
	 */
	public JsonResponse<String> updateByPrimaryKey(TalentJobRecord TalentJobRecord);
	
	/**
	 * 更新简历接收记录（根据主键局部更新）
	 * @param talentJobRecord
	 * @return 
	 */
	public JsonResponse<String> updateByPrimaryKeySelective(TalentJobRecord talentJobRecord);
	
	/**
	 * 更新岗位信息（根据主键全部更新）
	 * @param talentJobWithBLOBs
	 * @return 
	 */
	public JsonResponse<String> updateTalentJobByPrimaryKey(TalentJobWithBLOBs talentJob);
	
	/**
	 * 更新岗位信息（根据主键局部更新）
	 * @param talentJobWithBLOBs
	 * @return 
	 */
	public JsonResponse<String> updateTalentJobByPrimaryKeySelective(TalentJobWithBLOBs talentJob);
	/**
	 * 根据状态获取岗位信息
	 * @param conditions 查询条件Map
	 * 		 必传参数：	1.clinicId 诊所id
	 * 		 可传参数   	2.status 岗位状态
	 * 					3.pageSize 一页显示的数据量
	 * 					4.pageNo 当前页码
	 * 					5.如果status传空map，则查询所有状态数据
	 * 
	 * 					
	 * @return JsonResponse<PageInfo<TalentJobApp>>
	 */
	public JsonResponse<PageInfo<TalentJobSearchApp>> getTalentJobListByStatus(Map<String,Object> conditions);
	
	
	/**
	 * 根据状态获取接收的简历信息
	 * @param conditions 查询条件Map
	 * 		  可传参数：	1.clinicId 诊所id
	 * 				   	2.status 投递简历被查看的状态
	 * 					3.pageSize 一页显示的数据量
	 * 					4.pageNo 当前页码
	 * 					5.如果status传空map，则查询所有状态数据
	 * @return
	 */
	public JsonResponse<PageInfo<TalentCvRecordSearchApp>> getTalentCvRecordListByStatus(Map<String,Object> conditions);
	
	
	/**
	 * 根据查询条件搜索对应简历数据
	 * @param conditions
	 * 		  
	 * @return
	 */
	public JsonResponse<PageInfo<TalentCvSearchApp>> getTalentCvListByConditions(Map<String,Object> conditions);
	
	
	/**
	 * 根据id查询简历信息
	 * pdfPath,phone
	 * @param id
	 * @return
	 */
	public JsonResponse<Map<String, Object>> getTalentCvInfoById(String id);
	
	/**
	 * 根据状态获取岗位信息
	 * @param conditions 查询条件Map
	 * 		 必传参数：	1.clinicId 诊所id
	 * 		 可传参数   	2.status 岗位状态
	 * 				3.如果status传空map，则查询所有状态数据
	 * 
	 * 					
	 * @return JsonResponse<List<Map<String, Object>>>
	 */
	public JsonResponse<List<TalentJobWithBLOBs>> getTalentJobListByClinicId(Map<String,String> conditions);
}
