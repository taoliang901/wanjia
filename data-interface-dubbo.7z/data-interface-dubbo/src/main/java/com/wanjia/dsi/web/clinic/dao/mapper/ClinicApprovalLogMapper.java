package com.wanjia.dsi.web.clinic.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.clinic.model.ClinicApprovalLog;

public interface ClinicApprovalLogMapper extends IBaseDao<ClinicApprovalLog,String> {
	
	public List<ClinicApprovalLog> findNewDoctorLog(Map<String,Object> map);
	
	public List<ClinicApprovalLog> viewClinicPreonlineLog(Map<String,Object> map);
	
	public List<ClinicApprovalLog> viewClinicLog(Map<String,Object> map);
	
}