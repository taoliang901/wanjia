package com.wanjia.dsi.web.user.service;

import java.util.List;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.user.model.HtUser;

public interface HtUserService {

	/***
	 * 根据地区id，查询该地区下部门的所有user
	 * 
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param areaId
	 * @return JsonResponse<List<HtUser>>
	 */
	JsonResponse<List<HtUser>> getUserListByAreaId(String areaId);

	/**
	 * 根据登录用户名查询后台用户
	 * 
	 * @param userCode
	 * @return
	 */
	JsonResponse<HtUser> getByUserCode(String userCode);

	/**
	 * 插入后台用户
	 * 
	 * @param userCode
	 * @return
	 */
	void insert(HtUser htUser);

	/**
	 * 更新后台用户
	 * 
	 * @param userCode
	 * @return
	 */
	void update(HtUser htUser);
}
