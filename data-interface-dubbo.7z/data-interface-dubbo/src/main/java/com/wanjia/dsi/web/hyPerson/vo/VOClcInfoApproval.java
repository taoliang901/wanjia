package com.wanjia.dsi.web.hyPerson.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.wanjia.dsi.web.hyPerson.model.ClcInfoApproval;
import com.wanjia.dsi.web.hyPerson.model.HyTreatmentPerson;

public class VOClcInfoApproval extends ClcInfoApproval implements Serializable {

	private String cityCode;
	private String city;
	private String districtCode;
	private String district;
	private String parentAccountId;
	private String mobileOfChild;
	private String mobileOfParent;

	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getParentAccountId() {
		return parentAccountId;
	}
	public void setParentAccountId(String parentAccountId) {
		this.parentAccountId = parentAccountId;
	}
	public String getMobileOfChild() {
		return mobileOfChild;
	}
	public void setMobileOfChild(String mobileOfChild) {
		this.mobileOfChild = mobileOfChild;
	}
	public String getMobileOfParent() {
		return mobileOfParent;
	}
	public void setMobileOfParent(String mobileOfParent) {
		this.mobileOfParent = mobileOfParent;
	}
	public String getDistrictCode() {
		return districtCode;
	}
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
}
