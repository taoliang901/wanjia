package com.wanjia.dsi.web.clinic.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class ClinicDailyAccessExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ClinicDailyAccessExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andClinicAccessDateIsNull() {
            addCriterion("CLINIC_ACCESS_DATE is null");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateIsNotNull() {
            addCriterion("CLINIC_ACCESS_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateEqualTo(Date value) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE =", value, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateNotEqualTo(Date value) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE <>", value, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateGreaterThan(Date value) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE >", value, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE >=", value, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateLessThan(Date value) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE <", value, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE <=", value, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateIn(List<Date> values) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE in", values, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateNotIn(List<Date> values) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE not in", values, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE between", value1, value2, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("CLINIC_ACCESS_DATE not between", value1, value2, "clinicAccessDate");
            return (Criteria) this;
        }

        public Criteria andClinicIdIsNull() {
            addCriterion("CLINIC_ID is null");
            return (Criteria) this;
        }

        public Criteria andClinicIdIsNotNull() {
            addCriterion("CLINIC_ID is not null");
            return (Criteria) this;
        }

        public Criteria andClinicIdEqualTo(String value) {
            addCriterion("CLINIC_ID =", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdNotEqualTo(String value) {
            addCriterion("CLINIC_ID <>", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdGreaterThan(String value) {
            addCriterion("CLINIC_ID >", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_ID >=", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdLessThan(String value) {
            addCriterion("CLINIC_ID <", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_ID <=", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdLike(String value) {
            addCriterion("CLINIC_ID like", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdNotLike(String value) {
            addCriterion("CLINIC_ID not like", value, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdIn(List<String> values) {
            addCriterion("CLINIC_ID in", values, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdNotIn(List<String> values) {
            addCriterion("CLINIC_ID not in", values, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdBetween(String value1, String value2) {
            addCriterion("CLINIC_ID between", value1, value2, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicIdNotBetween(String value1, String value2) {
            addCriterion("CLINIC_ID not between", value1, value2, "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicNameIsNull() {
            addCriterion("CLINIC_NAME is null");
            return (Criteria) this;
        }

        public Criteria andClinicNameIsNotNull() {
            addCriterion("CLINIC_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andClinicNameEqualTo(String value) {
            addCriterion("CLINIC_NAME =", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotEqualTo(String value) {
            addCriterion("CLINIC_NAME <>", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameGreaterThan(String value) {
            addCriterion("CLINIC_NAME >", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameGreaterThanOrEqualTo(String value) {
            addCriterion("CLINIC_NAME >=", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLessThan(String value) {
            addCriterion("CLINIC_NAME <", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLessThanOrEqualTo(String value) {
            addCriterion("CLINIC_NAME <=", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameLike(String value) {
            addCriterion("CLINIC_NAME like", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotLike(String value) {
            addCriterion("CLINIC_NAME not like", value, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameIn(List<String> values) {
            addCriterion("CLINIC_NAME in", values, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotIn(List<String> values) {
            addCriterion("CLINIC_NAME not in", values, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameBetween(String value1, String value2) {
            addCriterion("CLINIC_NAME between", value1, value2, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicNameNotBetween(String value1, String value2) {
            addCriterion("CLINIC_NAME not between", value1, value2, "clinicName");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumIsNull() {
            addCriterion("CLINIC_ACCESS_DAILY_NUM is null");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumIsNotNull() {
            addCriterion("CLINIC_ACCESS_DAILY_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumEqualTo(Long value) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM =", value, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumNotEqualTo(Long value) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM <>", value, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumGreaterThan(Long value) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM >", value, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumGreaterThanOrEqualTo(Long value) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM >=", value, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumLessThan(Long value) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM <", value, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumLessThanOrEqualTo(Long value) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM <=", value, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumIn(List<Long> values) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM in", values, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumNotIn(List<Long> values) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM not in", values, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumBetween(Long value1, Long value2) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM between", value1, value2, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessDailyNumNotBetween(Long value1, Long value2) {
            addCriterion("CLINIC_ACCESS_DAILY_NUM not between", value1, value2, "clinicAccessDailyNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumIsNull() {
            addCriterion("CLINIC_ACCESS_SUM_NUM is null");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumIsNotNull() {
            addCriterion("CLINIC_ACCESS_SUM_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumEqualTo(Long value) {
            addCriterion("CLINIC_ACCESS_SUM_NUM =", value, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumNotEqualTo(Long value) {
            addCriterion("CLINIC_ACCESS_SUM_NUM <>", value, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumGreaterThan(Long value) {
            addCriterion("CLINIC_ACCESS_SUM_NUM >", value, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumGreaterThanOrEqualTo(Long value) {
            addCriterion("CLINIC_ACCESS_SUM_NUM >=", value, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumLessThan(Long value) {
            addCriterion("CLINIC_ACCESS_SUM_NUM <", value, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumLessThanOrEqualTo(Long value) {
            addCriterion("CLINIC_ACCESS_SUM_NUM <=", value, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumIn(List<Long> values) {
            addCriterion("CLINIC_ACCESS_SUM_NUM in", values, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumNotIn(List<Long> values) {
            addCriterion("CLINIC_ACCESS_SUM_NUM not in", values, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumBetween(Long value1, Long value2) {
            addCriterion("CLINIC_ACCESS_SUM_NUM between", value1, value2, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessSumNumNotBetween(Long value1, Long value2) {
            addCriterion("CLINIC_ACCESS_SUM_NUM not between", value1, value2, "clinicAccessSumNum");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingIsNull() {
            addCriterion("CLINIC_ACCESS_RANKING is null");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingIsNotNull() {
            addCriterion("CLINIC_ACCESS_RANKING is not null");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingEqualTo(Integer value) {
            addCriterion("CLINIC_ACCESS_RANKING =", value, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingNotEqualTo(Integer value) {
            addCriterion("CLINIC_ACCESS_RANKING <>", value, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingGreaterThan(Integer value) {
            addCriterion("CLINIC_ACCESS_RANKING >", value, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingGreaterThanOrEqualTo(Integer value) {
            addCriterion("CLINIC_ACCESS_RANKING >=", value, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingLessThan(Integer value) {
            addCriterion("CLINIC_ACCESS_RANKING <", value, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingLessThanOrEqualTo(Integer value) {
            addCriterion("CLINIC_ACCESS_RANKING <=", value, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingIn(List<Integer> values) {
            addCriterion("CLINIC_ACCESS_RANKING in", values, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingNotIn(List<Integer> values) {
            addCriterion("CLINIC_ACCESS_RANKING not in", values, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingBetween(Integer value1, Integer value2) {
            addCriterion("CLINIC_ACCESS_RANKING between", value1, value2, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andClinicAccessRankingNotBetween(Integer value1, Integer value2) {
            addCriterion("CLINIC_ACCESS_RANKING not between", value1, value2, "clinicAccessRanking");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("DEL_FLAG is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("DEL_FLAG is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(String value) {
            addCriterion("DEL_FLAG =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(String value) {
            addCriterion("DEL_FLAG <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(String value) {
            addCriterion("DEL_FLAG >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(String value) {
            addCriterion("DEL_FLAG <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(String value) {
            addCriterion("DEL_FLAG <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLike(String value) {
            addCriterion("DEL_FLAG like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotLike(String value) {
            addCriterion("DEL_FLAG not like", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<String> values) {
            addCriterion("DEL_FLAG in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<String> values) {
            addCriterion("DEL_FLAG not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(String value1, String value2) {
            addCriterion("DEL_FLAG between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(String value1, String value2) {
            addCriterion("DEL_FLAG not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andCreateDtIsNull() {
            addCriterion("CREATE_DT is null");
            return (Criteria) this;
        }

        public Criteria andCreateDtIsNotNull() {
            addCriterion("CREATE_DT is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDtEqualTo(Date value) {
            addCriterion("CREATE_DT =", value, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtNotEqualTo(Date value) {
            addCriterion("CREATE_DT <>", value, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtGreaterThan(Date value) {
            addCriterion("CREATE_DT >", value, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_DT >=", value, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtLessThan(Date value) {
            addCriterion("CREATE_DT <", value, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_DT <=", value, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtIn(List<Date> values) {
            addCriterion("CREATE_DT in", values, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtNotIn(List<Date> values) {
            addCriterion("CREATE_DT not in", values, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtBetween(Date value1, Date value2) {
            addCriterion("CREATE_DT between", value1, value2, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateDtNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_DT not between", value1, value2, "createDt");
            return (Criteria) this;
        }

        public Criteria andCreateUsrIsNull() {
            addCriterion("CREATE_USR is null");
            return (Criteria) this;
        }

        public Criteria andCreateUsrIsNotNull() {
            addCriterion("CREATE_USR is not null");
            return (Criteria) this;
        }

        public Criteria andCreateUsrEqualTo(String value) {
            addCriterion("CREATE_USR =", value, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrNotEqualTo(String value) {
            addCriterion("CREATE_USR <>", value, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrGreaterThan(String value) {
            addCriterion("CREATE_USR >", value, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrGreaterThanOrEqualTo(String value) {
            addCriterion("CREATE_USR >=", value, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrLessThan(String value) {
            addCriterion("CREATE_USR <", value, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrLessThanOrEqualTo(String value) {
            addCriterion("CREATE_USR <=", value, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrLike(String value) {
            addCriterion("CREATE_USR like", value, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrNotLike(String value) {
            addCriterion("CREATE_USR not like", value, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrIn(List<String> values) {
            addCriterion("CREATE_USR in", values, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrNotIn(List<String> values) {
            addCriterion("CREATE_USR not in", values, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrBetween(String value1, String value2) {
            addCriterion("CREATE_USR between", value1, value2, "createUsr");
            return (Criteria) this;
        }

        public Criteria andCreateUsrNotBetween(String value1, String value2) {
            addCriterion("CREATE_USR not between", value1, value2, "createUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateDtIsNull() {
            addCriterion("UPDATE_DT is null");
            return (Criteria) this;
        }

        public Criteria andUpdateDtIsNotNull() {
            addCriterion("UPDATE_DT is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateDtEqualTo(Date value) {
            addCriterion("UPDATE_DT =", value, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtNotEqualTo(Date value) {
            addCriterion("UPDATE_DT <>", value, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtGreaterThan(Date value) {
            addCriterion("UPDATE_DT >", value, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_DT >=", value, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtLessThan(Date value) {
            addCriterion("UPDATE_DT <", value, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_DT <=", value, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtIn(List<Date> values) {
            addCriterion("UPDATE_DT in", values, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtNotIn(List<Date> values) {
            addCriterion("UPDATE_DT not in", values, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtBetween(Date value1, Date value2) {
            addCriterion("UPDATE_DT between", value1, value2, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateDtNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_DT not between", value1, value2, "updateDt");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrIsNull() {
            addCriterion("UPDATE_USR is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrIsNotNull() {
            addCriterion("UPDATE_USR is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrEqualTo(String value) {
            addCriterion("UPDATE_USR =", value, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrNotEqualTo(String value) {
            addCriterion("UPDATE_USR <>", value, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrGreaterThan(String value) {
            addCriterion("UPDATE_USR >", value, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_USR >=", value, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrLessThan(String value) {
            addCriterion("UPDATE_USR <", value, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_USR <=", value, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrLike(String value) {
            addCriterion("UPDATE_USR like", value, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrNotLike(String value) {
            addCriterion("UPDATE_USR not like", value, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrIn(List<String> values) {
            addCriterion("UPDATE_USR in", values, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrNotIn(List<String> values) {
            addCriterion("UPDATE_USR not in", values, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrBetween(String value1, String value2) {
            addCriterion("UPDATE_USR between", value1, value2, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrNotBetween(String value1, String value2) {
            addCriterion("UPDATE_USR not between", value1, value2, "updateUsr");
            return (Criteria) this;
        }

        public Criteria andClinicIdLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_ID) like", value.toUpperCase(), "clinicId");
            return (Criteria) this;
        }

        public Criteria andClinicNameLikeInsensitive(String value) {
            addCriterion("upper(CLINIC_NAME) like", value.toUpperCase(), "clinicName");
            return (Criteria) this;
        }

        public Criteria andDelFlagLikeInsensitive(String value) {
            addCriterion("upper(DEL_FLAG) like", value.toUpperCase(), "delFlag");
            return (Criteria) this;
        }

        public Criteria andCreateUsrLikeInsensitive(String value) {
            addCriterion("upper(CREATE_USR) like", value.toUpperCase(), "createUsr");
            return (Criteria) this;
        }

        public Criteria andUpdateUsrLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_USR) like", value.toUpperCase(), "updateUsr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}