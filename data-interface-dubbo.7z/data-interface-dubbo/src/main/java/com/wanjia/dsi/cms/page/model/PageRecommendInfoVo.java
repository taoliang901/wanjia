package com.wanjia.dsi.cms.page.model;

import java.io.Serializable;
import java.util.List;

import com.wanjia.dsi.cms.page.model.PageRecommendImg;
import com.wanjia.dsi.cms.page.model.PageRecommendInfo;
import com.wanjia.dsi.cms.page.model.PageRecommendRole;

public class PageRecommendInfoVo extends PageRecommendInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3025825696099799376L;
   
	private List<PageRecommendImg> pageRecommendImgList;
	
	private List<PageRecommendRole> pageRecommendRoleList;

	public List<PageRecommendImg> getPageRecommendImgList() {
		return pageRecommendImgList;
	}

	public void setPageRecommendImgList(List<PageRecommendImg> pageRecommendImgList) {
		this.pageRecommendImgList = pageRecommendImgList;
	}

	public List<PageRecommendRole> getPageRecommendRoleList() {
		return pageRecommendRoleList;
	}

	public void setPageRecommendRoleList(List<PageRecommendRole> pageRecommendRoleList) {
		this.pageRecommendRoleList = pageRecommendRoleList;
	}
	
	
	
}