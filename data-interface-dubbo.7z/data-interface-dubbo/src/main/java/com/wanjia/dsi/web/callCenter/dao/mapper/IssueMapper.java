package com.wanjia.dsi.web.callCenter.dao.mapper;

import com.wanjia.dsi.base.dao.IBaseDao;



public interface IssueMapper extends IBaseDao {

}