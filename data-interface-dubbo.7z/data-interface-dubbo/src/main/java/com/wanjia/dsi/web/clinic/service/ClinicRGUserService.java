package com.wanjia.dsi.web.clinic.service;


public interface ClinicRGUserService {

	
	
}
