package com.wanjia.dsi.web.cms.activity.model;

import java.io.Serializable;
import java.util.Date;

public class InfomationClickBO  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7778322582836709090L;
	private String type;    //类型 ；资讯：A，药品：M ，疾病：D
	private String infoId; //各个类型统计id; 资讯:activityId;药品:medCode;疾病：diseaseId;
	private String source; //设备号或ip
	private String userId;  //
	//yyyy-MM-dd
	private String clickDate; //日期
	private Date clickTime; //时间
	private String clientType;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getInfoId() {
		return infoId;
	}
	public void setInfoId(String infoId) {
		this.infoId = infoId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getClickDate() {
		return clickDate;
	}
	public void setClickDate(String clickDate) {
		this.clickDate = clickDate;
	}
	public Date getClickTime() {
		return clickTime;
	}
	public void setClickTime(Date clickTime) {
		this.clickTime = clickTime;
	}
	public String getClientType() {
		return clientType;
	}
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
