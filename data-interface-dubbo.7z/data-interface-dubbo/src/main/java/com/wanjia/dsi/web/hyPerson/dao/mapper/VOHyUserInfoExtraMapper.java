package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;

import com.wanjia.dsi.web.hyPerson.model.VOHyUserInfoExtra;

public interface VOHyUserInfoExtraMapper {

	List<VOHyUserInfoExtra> getHyUserInfoByTime(VOHyUserInfoExtra voHyUserInfoExtra);
}
