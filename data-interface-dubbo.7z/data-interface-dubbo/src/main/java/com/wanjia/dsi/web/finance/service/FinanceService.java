package com.wanjia.dsi.web.finance.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;

public interface FinanceService {
	
	/*****
	 * 得到银行列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @return
	 * JsonResponse<List<Map<String,Object>>>
	 */
	public JsonResponse<List<Map<String, Object>>> getBankList(String requestId);

	/***
	 * 得到支行列表
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param bankDBID
	 * @return
	 * JsonResponse<List<Map<String,Object>>>
	 */
	public JsonResponse<List<Map<String, Object>>> getBankBranchList(String requestId,String bankDBID);
	
	
	
	
	
	
	
	
	
	

}
