package com.wanjia.dsi.web.clinic.dao.mapper;

import java.util.List;
import com.wanjia.dsi.web.clinic.model.ClinicInfo;
import com.wanjia.dsi.web.hyPerson.model.ClinicRegisterVO;

// 查询注册信息
public interface ClinicRegisterVOMapper {
	
	/**
	 * 查询注册信息
	 * 
	 * @param ClinicInfo clinicInfo
	 * @return
	 */
	public List<ClinicRegisterVO> getClinicRegisterList(ClinicInfo clinicInfo);
}