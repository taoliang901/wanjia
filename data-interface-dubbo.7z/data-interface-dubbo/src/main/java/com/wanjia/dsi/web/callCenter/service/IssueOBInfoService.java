package com.wanjia.dsi.web.callCenter.service;

import java.util.List;

import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.callCenter.model.Issue;
import com.wanjia.dsi.web.callCenter.model.IssueOBInfo;



/**
 * This element is automatically generated on 16-8-3 下午8:14, do not modify. <br>
 * Service interface
 */
public interface IssueOBInfoService extends IBaseService<IssueOBInfo, String> {
	
	public void createUploadIssueForPrd(List<Issue> issueList,List<IssueOBInfo> oblist);
	
}