package com.wanjia.dsi.web.clinic.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;

public interface ClinicRGEnterpriseService {

	/**
	 * 查询融贯时间段内诊所
	 * 
	 * @param beginDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return
	 */
	JsonResponse<List<Map<String, Object>>> getRGClinicByDate(String beginDate, String endDate);

	/**
	 * 用户登录验证用户名、密码
	 * 
	 * @param username
	 *            用户名
	 * @param password
	 *            密码
	 * @return authCode 授权码
	 */
	JsonResponse<String> validateUser(String username, String password);

	/**
	 * 用户登录验证用户名、密码
	 * 
	 * @param authCode
	 *            授权码
	 * @return sessionId
	 */
	JsonResponse<String> authorizeAuthCode(String authCode);

}
