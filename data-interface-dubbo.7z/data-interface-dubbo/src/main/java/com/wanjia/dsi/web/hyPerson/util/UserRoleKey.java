package com.wanjia.dsi.web.hyPerson.util;

/**
 * UBC中个各子系统角色定义
 * 
 * @author LUOXIAOJUN640
 *
 */
public enum UserRoleKey {

	HY("1", "普通会员"), DOCTOR("2", "医生"), CLINIC_ADMIN("3", "诊所管理员"), CLINIC_EMPLOYE("4", "诊所员工");

	private String code;
	private String value;

	public static UserRoleKey getInstance(String code) {
		UserRoleKey userRoleKey = null;

		if (code != null) {
			UserRoleKey[] list = UserRoleKey.values();
			for (UserRoleKey key : list) {
				if (key.getCode().equals(code)) {
					userRoleKey = key;
					break;
				}
			}
		}

		return userRoleKey;
	}

	private UserRoleKey(String code, String value) {
		this.code = code;
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
