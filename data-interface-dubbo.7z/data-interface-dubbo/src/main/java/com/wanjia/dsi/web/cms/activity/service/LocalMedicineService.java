package com.wanjia.dsi.web.cms.activity.service;

import java.util.Date;
import java.util.List;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.model.LocalMedicine;

public interface LocalMedicineService {

	JsonResponse<PageInfo<LocalMedicine>> getLocalMedicine(List<String> infoIdList,String pageSize,String pageNo);
	
	/**
	 * 得到资讯药品id
	 * @param beginDate 选填 修改时间段开始时间
	 * @param endDate 选填 修改时间段结束时间
	 * @return
	 */
	JsonResponse<List<String>> getAllMedicineId(Date beginDate, Date endDate);
}
