package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wanjia.dsi.base.vo.BaseEntity;
import com.wanjia.dsi.web.doctor.model.Doctor;
import com.wanjia.elasticsearch.annotation.Document;
import com.wanjia.elasticsearch.annotation.Id;

@Document(index = "com_wanjia_clinic", type = "clinic")
public class Clinic extends BaseEntity implements Serializable,Comparable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String clinicRegisterId;

	private String clinicName;

	private String mobile;

	private String phone;

	private String openingTime;

	private String openingTimeWeek;

	private String openingTimeHours;

	private String clinicTypeProperty;

	private String clinicTypeDepartments;

	private String diagnosisTypeCode1;

	private String diagnosisType1;

	private String diagnosisItem;

	private String clinicIntroduce;

	private String businessLicenseNo;

	private String businessLicensePath;

	private String practicingLicenseNo;

	private String practicingLicensePath;

	private String organizationNo;

	private String organizationPath;

	private String taxRegistrationNo;

	private String taxRegistrationPath;

	private String civilAffairsFiling;

	private String civilAffairsPath;

	private String administratorName;

	private String administratorTel;

	private String authorizeMagPath;

	private String clinicPhotoPath;

	private String clinicFacadeName;

	private String clinicWaitingName;

	private String clinicMedLabName;

	private String clinicOtherName;

	private BigDecimal operatingArea;

	private Long aloneRoom;

	private BigDecimal waitingArea;

	private BigDecimal childrenArea;

	private String specialTechnology;

	private Long annualDiagnosisPerson;

	private Long medicalServiceIncome;

	private String operatingBeginDate;

	private String sameClinicIntroduce;

	private String managementSystem;

	private String systemBrand;

	private String hardwareFacility;

	private String operatingDifficulty;

	private String createUser;

	private Date createDate;

	private String modifyUser;

	private Date modifyDate;

	private String delFlag;

	private String isMedicalInsurance;

	private String isView;

	private String userId;

	private String followNum;

	private String recommentReason;

	private String recommentOrder;

	private String areaId;

	private String browseId;

	private String concernId;

	private String isConcern;

	private String practicingLicenseClinicName;

	private String country;
	private String province;
	private String city;
	private String district;

	private String countryCode;
	private String provinceCode;
	private String cityCode;
	private String districtCode;

	private String address;

	private String aboutId;

	private String esId;

	// clinic 经纬度
	private String longitude;
	private String latitude;

	// 诊所 logo
	private String clinicLogoPath;
	// 是否使用自定义定位
	private Integer customPositioningFlag;

	// mobile phone 经纬度
	private String mobilephoneLongitude;
	private String mobilephoneLatitude;
	private String distance;
	private String distanceWithIn;
	private String appSrc;
	private List<Doctor> doctors;
	private List<ClinicHardware> clinicHardware;

	// 存放es的医生名字
	private String doctorNames;

	private String practicingCount;// 执业医师
	private String laboratoryCount;// 检验医师
	private String radiologistCount;// 放射医师
	private String pharmacistCount;// 药剂师
	private String nurseCount;// 护理师

	private String isBooking;

	private String enterpriseFullName;

	private long concernCount;

	private double[] clinicLocation;

	private String diagnosisTypeCode2;// 诊疗科目

	private String diagnosisType2;// 诊疗科目

	private double evalution;// 评价分数

	private String practicingLicenseF2Path;
	private String practicingLicenseFpath;
	private String radiationDiagnosisNo;
	private String radiationDiagnosisPath;
	private String radiationSaftyNo;
	private String radiationSaftyPath;
	private String legalRepresentativeNo;
	private String legalRepresentativeIda;
	private String legalRepresentativeIdb;

	private String imageRoot;

	private String rzStatus;

	private String auditResult;

	// private Picture picture;

	private List<String> pictureList;

	private Date onlineDate;

	private Date onlineBeginDate;

	private Date onlineEndDate;
	
	private long concernNum; //关注数
    private String accountType;//账号类型：0、连锁诊所总账号，1、诊所账号
    private String sort;//存放排序字段
    private String doctorId;  //医生id
    private String doctorName; //医生名称
    private String casUUID;   //医生uuid
    private String resourceFlag;  //来源：0、诊所新增，1、诊所申请关联，2、医生申请关联
    private String relationStatus;  //关联状态：01、待审核（申请关联），02、审核通过（申请关联），03、审核退回（申请关联），04、待审核（取消关联），05、审核通过（取消关联），06、审核退回（取消关联），90、审核失败（申请关联），91、取消申请
    private String relationCheckReason;  //关联审核原因
    private String relationCancelRemark;  //取消关联原因备注
    private String relationCancelReason;  //取消关联原因
    private String isWanjia ; //是否是万家诊所：1、是，0、否
    
    //审核状态
    private String[] checkStatus;
    
	public long getConcernNum() {
		return concernNum;
	}

	public void setConcernNum(long concernNum) {
		this.concernNum = concernNum;
	}

	public Clinic() {
		// TODO Auto-generated constructor stub
	}

	public Date getOnlineDate() {
		return onlineDate;
	}

	public void setOnlineDate(Date onlineDate) {
		this.onlineDate = onlineDate;
	}

	public Date getOnlineBeginDate() {
		return onlineBeginDate;
	}

	public void setOnlineBeginDate(Date onlineBeginDate) {
		this.onlineBeginDate = onlineBeginDate;
	}

	public Date getOnlineEndDate() {
		return onlineEndDate;
	}

	public void setOnlineEndDate(Date onlineEndDate) {
		this.onlineEndDate = onlineEndDate;
	}

	public String getAuditResult() {
		return auditResult;
	}

	public void setAuditResult(String auditResult) {
		this.auditResult = auditResult;
	}

	public String getRzStatus() {
		return rzStatus;
	}

	public void setRzStatus(String rzStatus) {
		this.rzStatus = rzStatus;
	}

	public String getEnterpriseFullName() {
		return enterpriseFullName;
	}

	public void setEnterpriseFullName(String enterpriseFullName) {
		this.enterpriseFullName = enterpriseFullName;
	}

	public List<String> getPictureList() {
		return pictureList;
	}

	public void setPictureList(List<String> pictureList) {
		this.pictureList = pictureList;
	}

	public String getImageRoot() {
		return imageRoot;
	}

	public void setImageRoot(String imageRoot) {
		this.imageRoot = imageRoot;
	}

	public String getPracticingLicenseF2Path() {
		return practicingLicenseF2Path;
	}

	public void setPracticingLicenseF2Path(String practicingLicenseF2Path) {
		this.practicingLicenseF2Path = practicingLicenseF2Path;
	}

	public String getPracticingLicenseFpath() {
		return practicingLicenseFpath;
	}

	public void setPracticingLicenseFpath(String practicingLicenseFpath) {
		this.practicingLicenseFpath = practicingLicenseFpath;
	}

	public String getRadiationDiagnosisPath() {
		return radiationDiagnosisPath;
	}

	public void setRadiationDiagnosisPath(String radiationDiagnosisPath) {
		this.radiationDiagnosisPath = radiationDiagnosisPath;
	}

	public String getRadiationDiagnosisNo() {
		return radiationDiagnosisNo;
	}

	public void setRadiationDiagnosisNo(String radiationDiagnosisNo) {
		this.radiationDiagnosisNo = radiationDiagnosisNo;
	}

	public String getRadiationSaftyNo() {
		return radiationSaftyNo;
	}

	public void setRadiationSaftyNo(String radiationSaftyNo) {
		this.radiationSaftyNo = radiationSaftyNo;
	}

	public String getRadiationSaftyPath() {
		return radiationSaftyPath;
	}

	public void setRadiationSaftyPath(String radiationSaftyPath) {
		this.radiationSaftyPath = radiationSaftyPath;
	}

	public String getLegalRepresentativeNo() {
		return legalRepresentativeNo;
	}

	public void setLegalRepresentativeNo(String legalRepresentativeNo) {
		this.legalRepresentativeNo = legalRepresentativeNo;
	}

	public String getLegalRepresentativeIda() {
		return legalRepresentativeIda;
	}

	public void setLegalRepresentativeIda(String legalRepresentativeIda) {
		this.legalRepresentativeIda = legalRepresentativeIda;
	}

	public String getLegalRepresentativeIdb() {
		return legalRepresentativeIdb;
	}

	public void setLegalRepresentativeIdb(String legalRepresentativeIdb) {
		this.legalRepresentativeIdb = legalRepresentativeIdb;
	}

	public double getEvalution() {
		return evalution;
	}

	public void setEvalution(double evalution) {
		this.evalution = evalution;
	}

	public String getDiagnosisType2() {
		return diagnosisType2;
	}

	public void setDiagnosisType2(String diagnosisType2) {
		this.diagnosisType2 = diagnosisType2;
	}

	public String getDiagnosisTypeCode2() {
		return diagnosisTypeCode2;
	}

	public void setDiagnosisTypeCode2(String diagnosisTypeCode2) {
		this.diagnosisTypeCode2 = diagnosisTypeCode2;
	}

	public double[] getClinicLocation() {
		return clinicLocation;
	}

	public void setClinicLocation(double[] clinicLocation) {
		this.clinicLocation = clinicLocation;
	}

	public long getConcernCount() {
		return concernCount;
	}

	public void setConcernCount(long concernCount) {
		this.concernCount = concernCount;
	}

	public String getDistanceWithIn() {
		return distanceWithIn;
	}

	public void setDistanceWithIn(String distanceWithIn) {
		this.distanceWithIn = distanceWithIn;
	}

	public String getAppSrc() {
		return appSrc;
	}

	public void setAppSrc(String appSrc) {
		this.appSrc = appSrc;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getIsBooking() {
		return isBooking;
	}

	public void setIsBooking(String isBooking) {
		this.isBooking = isBooking;
	}

	public String getPracticingCount() {
		return practicingCount;
	}

	public void setPracticingCount(String practicingCount) {
		this.practicingCount = practicingCount;
	}

	public String getLaboratoryCount() {
		return laboratoryCount;
	}

	public void setLaboratoryCount(String laboratoryCount) {
		this.laboratoryCount = laboratoryCount;
	}

	public String getRadiologistCount() {
		return radiologistCount;
	}

	public void setRadiologistCount(String radiologistCount) {
		this.radiologistCount = radiologistCount;
	}

	public String getPharmacistCount() {
		return pharmacistCount;
	}

	public void setPharmacistCount(String pharmacistCount) {
		this.pharmacistCount = pharmacistCount;
	}

	public String getNurseCount() {
		return nurseCount;
	}

	public void setNurseCount(String nurseCount) {
		this.nurseCount = nurseCount;
	}

	public List<ClinicHardware> getClinicHardware() {
		return clinicHardware;
	}

	public void setClinicHardware(List<ClinicHardware> clinicHardware) {
		this.clinicHardware = clinicHardware;
	}

	public String getEsId() {
		return esId;
	}

	public void setEsId(String esId) {
		this.esId = esId;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getConcernId() {
		return concernId;
	}

	public void setConcernId(String concernId) {
		this.concernId = concernId;
	}

	public String getAboutId() {
		return aboutId;
	}

	public void setAboutId(String aboutId) {
		this.aboutId = aboutId;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBrowseId() {
		return browseId;
	}

	public void setBrowseId(String browseId) {
		this.browseId = browseId;
	}

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId = areaId;
	}

	public String getRecommentReason() {
		return recommentReason;
	}

	public void setRecommentReason(String recommentReason) {
		this.recommentReason = recommentReason;
	}

	public String getRecommentOrder() {
		return recommentOrder;
	}

	public void setRecommentOrder(String recommentOrder) {
		this.recommentOrder = recommentOrder;
	}

	public String getFollowNum() {
		return followNum;
	}

	public void setFollowNum(String followNum) {
		this.followNum = followNum;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClinicRegisterId() {
		return clinicRegisterId;
	}

	public void setClinicRegisterId(String clinicRegisterId) {
		this.clinicRegisterId = clinicRegisterId;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getOpeningTime() {
		return openingTime;
	}

	public void setOpeningTime(String openingTime) {
		this.openingTime = openingTime;
	}

	public String getOpeningTimeWeek() {
		return openingTimeWeek;
	}

	public void setOpeningTimeWeek(String openingTimeWeek) {
		this.openingTimeWeek = openingTimeWeek;
	}

	public String getOpeningTimeHours() {
		return openingTimeHours;
	}

	public void setOpeningTimeHours(String openingTimeHours) {
		this.openingTimeHours = openingTimeHours;
	}

	public String getClinicTypeProperty() {
		return clinicTypeProperty;
	}

	public void setClinicTypeProperty(String clinicTypeProperty) {
		this.clinicTypeProperty = clinicTypeProperty;
	}

	public String getClinicTypeDepartments() {
		return clinicTypeDepartments;
	}

	public void setClinicTypeDepartments(String clinicTypeDepartments) {
		this.clinicTypeDepartments = clinicTypeDepartments;
	}

	public String getDiagnosisTypeCode1() {
		return diagnosisTypeCode1;
	}

	public void setDiagnosisTypeCode1(String diagnosisTypeCode1) {
		this.diagnosisTypeCode1 = diagnosisTypeCode1;
	}

	public String getDiagnosisType1() {
		return diagnosisType1;
	}

	public void setDiagnosisType1(String diagnosisType1) {
		this.diagnosisType1 = diagnosisType1;
	}

	public String getDiagnosisItem() {
		return diagnosisItem;
	}

	public void setDiagnosisItem(String diagnosisItem) {
		this.diagnosisItem = diagnosisItem;
	}

	public String getClinicIntroduce() {
		return clinicIntroduce;
	}

	public void setClinicIntroduce(String clinicIntroduce) {
		this.clinicIntroduce = clinicIntroduce;
	}

	public String getBusinessLicenseNo() {
		return businessLicenseNo;
	}

	public void setBusinessLicenseNo(String businessLicenseNo) {
		this.businessLicenseNo = businessLicenseNo;
	}

	public String getBusinessLicensePath() {
		return businessLicensePath;
	}

	public void setBusinessLicensePath(String businessLicensePath) {
		this.businessLicensePath = businessLicensePath;
	}

	public String getPracticingLicenseNo() {
		return practicingLicenseNo;
	}

	public void setPracticingLicenseNo(String practicingLicenseNo) {
		this.practicingLicenseNo = practicingLicenseNo;
	}

	public String getPracticingLicensePath() {
		return practicingLicensePath;
	}

	public void setPracticingLicensePath(String practicingLicensePath) {
		this.practicingLicensePath = practicingLicensePath;
	}

	public String getOrganizationNo() {
		return organizationNo;
	}

	public void setOrganizationNo(String organizationNo) {
		this.organizationNo = organizationNo;
	}

	public String getOrganizationPath() {
		return organizationPath;
	}

	public void setOrganizationPath(String organizationPath) {
		this.organizationPath = organizationPath;
	}

	public String getTaxRegistrationNo() {
		return taxRegistrationNo;
	}

	public void setTaxRegistrationNo(String taxRegistrationNo) {
		this.taxRegistrationNo = taxRegistrationNo;
	}

	public String getTaxRegistrationPath() {
		return taxRegistrationPath;
	}

	public void setTaxRegistrationPath(String taxRegistrationPath) {
		this.taxRegistrationPath = taxRegistrationPath;
	}

	public String getCivilAffairsFiling() {
		return civilAffairsFiling;
	}

	public void setCivilAffairsFiling(String civilAffairsFiling) {
		this.civilAffairsFiling = civilAffairsFiling;
	}

	public String getCivilAffairsPath() {
		return civilAffairsPath;
	}

	public void setCivilAffairsPath(String civilAffairsPath) {
		this.civilAffairsPath = civilAffairsPath;
	}

	public String getAdministratorName() {
		return administratorName;
	}

	public void setAdministratorName(String administratorName) {
		this.administratorName = administratorName;
	}

	public String getAdministratorTel() {
		return administratorTel;
	}

	public void setAdministratorTel(String administratorTel) {
		this.administratorTel = administratorTel;
	}

	public String getAuthorizeMagPath() {
		return authorizeMagPath;
	}

	public void setAuthorizeMagPath(String authorizeMagPath) {
		this.authorizeMagPath = authorizeMagPath;
	}

	public String getClinicPhotoPath() {
		return clinicPhotoPath;
	}

	public void setClinicPhotoPath(String clinicPhotoPath) {
		this.clinicPhotoPath = clinicPhotoPath;
	}

	public String getClinicFacadeName() {
		return clinicFacadeName;
	}

	public void setClinicFacadeName(String clinicFacadeName) {
		this.clinicFacadeName = clinicFacadeName;
	}

	public String getClinicWaitingName() {
		return clinicWaitingName;
	}

	public void setClinicWaitingName(String clinicWaitingName) {
		this.clinicWaitingName = clinicWaitingName;
	}

	public String getClinicMedLabName() {
		return clinicMedLabName;
	}

	public void setClinicMedLabName(String clinicMedLabName) {
		this.clinicMedLabName = clinicMedLabName;
	}

	public String getClinicOtherName() {
		return clinicOtherName;
	}

	public void setClinicOtherName(String clinicOtherName) {
		this.clinicOtherName = clinicOtherName;
	}

	public BigDecimal getOperatingArea() {
		return operatingArea;
	}

	public void setOperatingArea(BigDecimal operatingArea) {
		this.operatingArea = operatingArea;
	}

	public Long getAloneRoom() {
		return aloneRoom;
	}

	public void setAloneRoom(Long aloneRoom) {
		this.aloneRoom = aloneRoom;
	}

	public BigDecimal getWaitingArea() {
		return waitingArea;
	}

	public void setWaitingArea(BigDecimal waitingArea) {
		this.waitingArea = waitingArea;
	}

	public BigDecimal getChildrenArea() {
		return childrenArea;
	}

	public void setChildrenArea(BigDecimal childrenArea) {
		this.childrenArea = childrenArea;
	}

	public String getSpecialTechnology() {
		return specialTechnology;
	}

	public void setSpecialTechnology(String specialTechnology) {
		this.specialTechnology = specialTechnology;
	}

	public Long getAnnualDiagnosisPerson() {
		return annualDiagnosisPerson;
	}

	public void setAnnualDiagnosisPerson(Long annualDiagnosisPerson) {
		this.annualDiagnosisPerson = annualDiagnosisPerson;
	}

	public Long getMedicalServiceIncome() {
		return medicalServiceIncome;
	}

	public void setMedicalServiceIncome(Long medicalServiceIncome) {
		this.medicalServiceIncome = medicalServiceIncome;
	}

	public String getOperatingBeginDate() {
		return operatingBeginDate;
	}

	public void setOperatingBeginDate(String operatingBeginDate) {
		this.operatingBeginDate = operatingBeginDate;
	}

	public String getSameClinicIntroduce() {
		return sameClinicIntroduce;
	}

	public void setSameClinicIntroduce(String sameClinicIntroduce) {
		this.sameClinicIntroduce = sameClinicIntroduce;
	}

	public String getManagementSystem() {
		return managementSystem;
	}

	public void setManagementSystem(String managementSystem) {
		this.managementSystem = managementSystem;
	}

	public String getSystemBrand() {
		return systemBrand;
	}

	public void setSystemBrand(String systemBrand) {
		this.systemBrand = systemBrand;
	}

	public String getHardwareFacility() {
		return hardwareFacility;
	}

	public void setHardwareFacility(String hardwareFacility) {
		this.hardwareFacility = hardwareFacility;
	}

	public String getOperatingDifficulty() {
		return operatingDifficulty;
	}

	public void setOperatingDifficulty(String operatingDifficulty) {
		this.operatingDifficulty = operatingDifficulty;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getIsConcern() {
		return isConcern;
	}

	public void setIsConcern(String isConcern) {
		this.isConcern = isConcern;
	}

	public List<Doctor> getDoctors() {
		return doctors;
	}

	public void setDoctors(List<Doctor> doctors) {
		this.doctors = doctors;
	}

	public String getPracticingLicenseClinicName() {
	    return practicingLicenseClinicName;
	}

	public void setPracticingLicenseClinicName(String practicingLicenseClinicName) {
	    this.practicingLicenseClinicName = practicingLicenseClinicName;
	}
	
	/**
	 * @return the provinceCode
	 */
	public String getProvinceCode() {
		return provinceCode;
	}

	/**
	 * @param provinceCode
	 *            the provinceCode to set
	 */
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}

	/**
	 * @return the cityCode
	 */
	public String getCityCode() {
		return cityCode;
	}

	/**
	 * @param cityCode
	 *            the cityCode to set
	 */
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getIsMedicalInsurance() {
		return isMedicalInsurance;
	}

	public void setIsMedicalInsurance(String isMedicalInsurance) {
		this.isMedicalInsurance = isMedicalInsurance;
	}

	/**
	 * @return the districtCode
	 */
	public String getDistrictCode() {
		return districtCode;
	}

	/**
	 * @param districtCode
	 *            the districtCode to set
	 */
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getIsView() {
		return isView;
	}

	public void setIsView(String isView) {
		this.isView = isView;
	}

	public String getDoctorNames() {
		return doctorNames;
	}

	public void setDoctorNames(String doctorNames) {
		this.doctorNames = doctorNames;
	}

	public String getMobilephoneLongitude() {
		return mobilephoneLongitude;
	}

	public void setMobilephoneLongitude(String mobilephoneLongitude) {
		this.mobilephoneLongitude = mobilephoneLongitude;
	}

	public String getMobilephoneLatitude() {
		return mobilephoneLatitude;
	}

	public void setMobilephoneLatitude(String mobilephoneLatitude) {
		this.mobilephoneLatitude = mobilephoneLatitude;
	}

	public Integer getCustomPositioningFlag() {
		return customPositioningFlag;
	}

	public void setCustomPositioningFlag(Integer customPositioningFlag) {
		this.customPositioningFlag = customPositioningFlag;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getCasUUID() {
		return casUUID;
	}

	public void setCasUUID(String casUUID) {
		this.casUUID = casUUID;
	}

	public String getResourceFlag() {
		return resourceFlag;
	}

	public void setResourceFlag(String resourceFlag) {
		this.resourceFlag = resourceFlag;
	}

	public String getRelationStatus() {
		return relationStatus;
	}

	public void setRelationStatus(String relationStatus) {
		this.relationStatus = relationStatus;
	}

	public String getRelationCheckReason() {
		return relationCheckReason;
	}

	public void setRelationCheckReason(String relationCheckReason) {
		this.relationCheckReason = relationCheckReason;
	}

	public String getRelationCancelRemark() {
		return relationCancelRemark;
	}

	public void setRelationCancelRemark(String relationCancelRemark) {
		this.relationCancelRemark = relationCancelRemark;
	}

	public String getRelationCancelReason() {
		return relationCancelReason;
	}

	public void setRelationCancelReason(String relationCancelReason) {
		this.relationCancelReason = relationCancelReason;
	}

	public String getIsWanjia() {
		return isWanjia;
	}

	public void setIsWanjia(String isWanjia) {
		this.isWanjia = isWanjia;
	}

	public String[] getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String[] checkStatus) {
		this.checkStatus = checkStatus;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		Clinic other = (Clinic) that;
		return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId())) && (this.getClinicRegisterId() == null ? other.getClinicRegisterId() == null : this.getClinicRegisterId().equals(other.getClinicRegisterId())) && (this.getClinicName() == null ? other.getClinicName() == null : this.getClinicName().equals(other.getClinicName())) && (this.getMobile() == null ? other.getMobile() == null : this.getMobile().equals(other.getMobile())) && (this.getPhone() == null ? other.getPhone() == null : this.getPhone().equals(other.getPhone())) && (this.getOpeningTime() == null ? other.getOpeningTime() == null : this.getOpeningTime().equals(other.getOpeningTime())) && (this.getOpeningTimeWeek() == null ? other.getOpeningTimeWeek() == null : this.getOpeningTimeWeek().equals(other.getOpeningTimeWeek())) && (this.getOpeningTimeHours() == null ? other.getOpeningTimeHours() == null : this.getOpeningTimeHours().equals(other.getOpeningTimeHours())) && (this.getClinicTypeProperty() == null ? other.getClinicTypeProperty() == null : this.getClinicTypeProperty().equals(other.getClinicTypeProperty())) && (this.getClinicTypeDepartments() == null ? other.getClinicTypeDepartments() == null : this.getClinicTypeDepartments().equals(other.getClinicTypeDepartments())) && (this.getDiagnosisTypeCode1() == null ? other.getDiagnosisTypeCode1() == null : this.getDiagnosisTypeCode1().equals(other.getDiagnosisTypeCode1())) && (this.getDiagnosisType1() == null ? other.getDiagnosisType1() == null : this.getDiagnosisType1().equals(other.getDiagnosisType1())) && (this.getDiagnosisItem() == null ? other.getDiagnosisItem() == null : this.getDiagnosisItem().equals(other.getDiagnosisItem())) && (this.getClinicIntroduce() == null ? other.getClinicIntroduce() == null : this.getClinicIntroduce().equals(other.getClinicIntroduce())) && (this.getBusinessLicenseNo() == null ? other.getBusinessLicenseNo() == null : this.getBusinessLicenseNo().equals(other.getBusinessLicenseNo())) && (this.getBusinessLicensePath() == null ? other.getBusinessLicensePath() == null : this.getBusinessLicensePath().equals(other.getBusinessLicensePath())) && (this.getPracticingLicenseNo() == null ? other.getPracticingLicenseNo() == null : this.getPracticingLicenseNo().equals(other.getPracticingLicenseNo())) && (this.getPracticingLicensePath() == null ? other.getPracticingLicensePath() == null : this.getPracticingLicensePath().equals(other.getPracticingLicensePath())) && (this.getOrganizationNo() == null ? other.getOrganizationNo() == null : this.getOrganizationNo().equals(other.getOrganizationNo())) && (this.getOrganizationPath() == null ? other.getOrganizationPath() == null : this.getOrganizationPath().equals(other.getOrganizationPath())) && (this.getTaxRegistrationNo() == null ? other.getTaxRegistrationNo() == null : this.getTaxRegistrationNo().equals(other.getTaxRegistrationNo())) && (this.getTaxRegistrationPath() == null ? other.getTaxRegistrationPath() == null : this.getTaxRegistrationPath().equals(other.getTaxRegistrationPath())) && (this.getCivilAffairsFiling() == null ? other.getCivilAffairsFiling() == null : this.getCivilAffairsFiling().equals(other.getCivilAffairsFiling())) && (this.getCivilAffairsPath() == null ? other.getCivilAffairsPath() == null : this.getCivilAffairsPath().equals(other.getCivilAffairsPath())) && (this.getAdministratorName() == null ? other.getAdministratorName() == null : this.getAdministratorName().equals(other.getAdministratorName())) && (this.getAdministratorTel() == null ? other.getAdministratorTel() == null : this.getAdministratorTel().equals(other.getAdministratorTel())) && (this.getAuthorizeMagPath() == null ? other.getAuthorizeMagPath() == null : this.getAuthorizeMagPath().equals(other.getAuthorizeMagPath())) && (this.getClinicPhotoPath() == null ? other.getClinicPhotoPath() == null : this.getClinicPhotoPath().equals(other.getClinicPhotoPath())) && (this.getClinicFacadeName() == null ? other.getClinicFacadeName() == null : this.getClinicFacadeName().equals(other.getClinicFacadeName())) && (this.getClinicWaitingName() == null ? other.getClinicWaitingName() == null : this.getClinicWaitingName().equals(other.getClinicWaitingName())) && (this.getClinicMedLabName() == null ? other.getClinicMedLabName() == null : this.getClinicMedLabName().equals(other.getClinicMedLabName())) && (this.getClinicOtherName() == null ? other.getClinicOtherName() == null : this.getClinicOtherName().equals(other.getClinicOtherName())) && (this.getOperatingArea() == null ? other.getOperatingArea() == null : this.getOperatingArea().equals(other.getOperatingArea())) && (this.getAloneRoom() == null ? other.getAloneRoom() == null : this.getAloneRoom().equals(other.getAloneRoom())) && (this.getWaitingArea() == null ? other.getWaitingArea() == null : this.getWaitingArea().equals(other.getWaitingArea())) && (this.getChildrenArea() == null ? other.getChildrenArea() == null : this.getChildrenArea().equals(other.getChildrenArea())) && (this.getSpecialTechnology() == null ? other.getSpecialTechnology() == null : this.getSpecialTechnology().equals(other.getSpecialTechnology())) && (this.getAnnualDiagnosisPerson() == null ? other.getAnnualDiagnosisPerson() == null : this.getAnnualDiagnosisPerson().equals(other.getAnnualDiagnosisPerson())) && (this.getMedicalServiceIncome() == null ? other.getMedicalServiceIncome() == null : this.getMedicalServiceIncome().equals(other.getMedicalServiceIncome())) && (this.getOperatingBeginDate() == null ? other.getOperatingBeginDate() == null : this.getOperatingBeginDate().equals(other.getOperatingBeginDate())) && (this.getSameClinicIntroduce() == null ? other.getSameClinicIntroduce() == null : this.getSameClinicIntroduce().equals(other.getSameClinicIntroduce())) && (this.getManagementSystem() == null ? other.getManagementSystem() == null : this.getManagementSystem().equals(other.getManagementSystem())) && (this.getSystemBrand() == null ? other.getSystemBrand() == null : this.getSystemBrand().equals(other.getSystemBrand())) && (this.getHardwareFacility() == null ? other.getHardwareFacility() == null : this.getHardwareFacility().equals(other.getHardwareFacility())) && (this.getOperatingDifficulty() == null ? other.getOperatingDifficulty() == null : this.getOperatingDifficulty().equals(other.getOperatingDifficulty())) && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser())) && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate())) && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser())) && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate())) && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		result = prime * result + ((getClinicRegisterId() == null) ? 0 : getClinicRegisterId().hashCode());
		result = prime * result + ((getClinicName() == null) ? 0 : getClinicName().hashCode());
		result = prime * result + ((getMobile() == null) ? 0 : getMobile().hashCode());
		result = prime * result + ((getPhone() == null) ? 0 : getPhone().hashCode());
		result = prime * result + ((getOpeningTime() == null) ? 0 : getOpeningTime().hashCode());
		result = prime * result + ((getOpeningTimeWeek() == null) ? 0 : getOpeningTimeWeek().hashCode());
		result = prime * result + ((getOpeningTimeHours() == null) ? 0 : getOpeningTimeHours().hashCode());
		result = prime * result + ((getClinicTypeProperty() == null) ? 0 : getClinicTypeProperty().hashCode());
		result = prime * result + ((getClinicTypeDepartments() == null) ? 0 : getClinicTypeDepartments().hashCode());
		result = prime * result + ((getDiagnosisTypeCode1() == null) ? 0 : getDiagnosisTypeCode1().hashCode());
		result = prime * result + ((getDiagnosisType1() == null) ? 0 : getDiagnosisType1().hashCode());
		result = prime * result + ((getDiagnosisItem() == null) ? 0 : getDiagnosisItem().hashCode());
		result = prime * result + ((getClinicIntroduce() == null) ? 0 : getClinicIntroduce().hashCode());
		result = prime * result + ((getBusinessLicenseNo() == null) ? 0 : getBusinessLicenseNo().hashCode());
		result = prime * result + ((getBusinessLicensePath() == null) ? 0 : getBusinessLicensePath().hashCode());
		result = prime * result + ((getPracticingLicenseNo() == null) ? 0 : getPracticingLicenseNo().hashCode());
		result = prime * result + ((getPracticingLicensePath() == null) ? 0 : getPracticingLicensePath().hashCode());
		result = prime * result + ((getOrganizationNo() == null) ? 0 : getOrganizationNo().hashCode());
		result = prime * result + ((getOrganizationPath() == null) ? 0 : getOrganizationPath().hashCode());
		result = prime * result + ((getTaxRegistrationNo() == null) ? 0 : getTaxRegistrationNo().hashCode());
		result = prime * result + ((getTaxRegistrationPath() == null) ? 0 : getTaxRegistrationPath().hashCode());
		result = prime * result + ((getCivilAffairsFiling() == null) ? 0 : getCivilAffairsFiling().hashCode());
		result = prime * result + ((getCivilAffairsPath() == null) ? 0 : getCivilAffairsPath().hashCode());
		result = prime * result + ((getAdministratorName() == null) ? 0 : getAdministratorName().hashCode());
		result = prime * result + ((getAdministratorTel() == null) ? 0 : getAdministratorTel().hashCode());
		result = prime * result + ((getAuthorizeMagPath() == null) ? 0 : getAuthorizeMagPath().hashCode());
		result = prime * result + ((getClinicPhotoPath() == null) ? 0 : getClinicPhotoPath().hashCode());
		result = prime * result + ((getClinicFacadeName() == null) ? 0 : getClinicFacadeName().hashCode());
		result = prime * result + ((getClinicWaitingName() == null) ? 0 : getClinicWaitingName().hashCode());
		result = prime * result + ((getClinicMedLabName() == null) ? 0 : getClinicMedLabName().hashCode());
		result = prime * result + ((getClinicOtherName() == null) ? 0 : getClinicOtherName().hashCode());
		result = prime * result + ((getOperatingArea() == null) ? 0 : getOperatingArea().hashCode());
		result = prime * result + ((getAloneRoom() == null) ? 0 : getAloneRoom().hashCode());
		result = prime * result + ((getWaitingArea() == null) ? 0 : getWaitingArea().hashCode());
		result = prime * result + ((getChildrenArea() == null) ? 0 : getChildrenArea().hashCode());
		result = prime * result + ((getSpecialTechnology() == null) ? 0 : getSpecialTechnology().hashCode());
		result = prime * result + ((getAnnualDiagnosisPerson() == null) ? 0 : getAnnualDiagnosisPerson().hashCode());
		result = prime * result + ((getMedicalServiceIncome() == null) ? 0 : getMedicalServiceIncome().hashCode());
		result = prime * result + ((getOperatingBeginDate() == null) ? 0 : getOperatingBeginDate().hashCode());
		result = prime * result + ((getSameClinicIntroduce() == null) ? 0 : getSameClinicIntroduce().hashCode());
		result = prime * result + ((getManagementSystem() == null) ? 0 : getManagementSystem().hashCode());
		result = prime * result + ((getSystemBrand() == null) ? 0 : getSystemBrand().hashCode());
		result = prime * result + ((getHardwareFacility() == null) ? 0 : getHardwareFacility().hashCode());
		result = prime * result + ((getOperatingDifficulty() == null) ? 0 : getOperatingDifficulty().hashCode());
		result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
		result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
		result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
		result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
		result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "Clinic [id=" + id + ", clinicRegisterId=" + clinicRegisterId + ", clinicName=" + clinicName + ", mobile=" + mobile + ", phone=" + phone + ", openingTime=" + openingTime + ", openingTimeWeek=" + openingTimeWeek + ", openingTimeHours=" + openingTimeHours + ", clinicTypeProperty=" + clinicTypeProperty + ", clinicTypeDepartments=" + clinicTypeDepartments + ", diagnosisTypeCode1=" + diagnosisTypeCode1 + ", diagnosisType1=" + diagnosisType1 + ", diagnosisItem=" + diagnosisItem + ", clinicIntroduce=" + clinicIntroduce + ", businessLicenseNo=" + businessLicenseNo + ", businessLicensePath=" + businessLicensePath + ", practicingLicenseNo=" + practicingLicenseNo + ", practicingLicensePath=" + practicingLicensePath + ", organizationNo=" + organizationNo + ", organizationPath=" + organizationPath + ", taxRegistrationNo=" + taxRegistrationNo + ", taxRegistrationPath=" + taxRegistrationPath + ", civilAffairsFiling=" + civilAffairsFiling + ", civilAffairsPath=" + civilAffairsPath + ", administratorName=" + administratorName + ", administratorTel=" + administratorTel + ", authorizeMagPath=" + authorizeMagPath + ", clinicPhotoPath=" + clinicPhotoPath + ", clinicFacadeName=" + clinicFacadeName + ", clinicWaitingName=" + clinicWaitingName + ", clinicMedLabName=" + clinicMedLabName + ", clinicOtherName=" + clinicOtherName + ", operatingArea=" + operatingArea + ", aloneRoom=" + aloneRoom + ", waitingArea=" + waitingArea + ", childrenArea=" + childrenArea + ", specialTechnology=" + specialTechnology + ", annualDiagnosisPerson=" + annualDiagnosisPerson + ", medicalServiceIncome=" + medicalServiceIncome + ", operatingBeginDate=" + operatingBeginDate + ", sameClinicIntroduce=" + sameClinicIntroduce + ", managementSystem=" + managementSystem + ", systemBrand=" + systemBrand + ", hardwareFacility=" + hardwareFacility + ", operatingDifficulty=" + operatingDifficulty + ", createUser=" + createUser + ", createDate=" + createDate + ", modifyUser=" + modifyUser + ", modifyDate=" + modifyDate + ", delFlag=" + delFlag + ", isMedicalInsurance=" + isMedicalInsurance + ", isView=" + isView + ", userId=" + userId + ", followNum=" + followNum + ", recommentReason=" + recommentReason + ", recommentOrder=" + recommentOrder + ", areaId=" + areaId + ", browseId=" + browseId + ", concernId=" + concernId + ", isConcern=" + isConcern + ", province=" + province + ", city=" + city + ", district=" + district + ", provinceCode=" + provinceCode + ", cityCode=" + cityCode + ", districtCode=" + districtCode + ", address=" + address + ", aboutId=" + aboutId + ", esId=" + esId + ", longitude=" + longitude + ", latitude=" + latitude + ", doctors=" + doctors + ", clinicHardware=" + clinicHardware + ", doctorNames=" + doctorNames + ", practicingCount=" + practicingCount + ", laboratoryCount=" + laboratoryCount + ", radiologistCount=" + radiologistCount + ", pharmacistCount=" + pharmacistCount + ", nurseCount=" + nurseCount + "]";
	}

	public String getClinicLogoPath() {
		return clinicLogoPath;
	}

	public void setClinicLogoPath(String clinicLogoPath) {
		this.clinicLogoPath = clinicLogoPath;
	}
/**
 * 通过距离排序
 */
	@Override
	public int compareTo(Object clinic) {
		Clinic otherClinic = (Clinic) clinic;
		String otherDistance = otherClinic.getDistance();
		if(this.getDistance() == null){
			return 1;
		}else if(otherDistance == null){
			return -1;
		}else{
			//return this.getDistance().compareTo(otherDistance);
			return Double.valueOf(this.getDistance()).compareTo(Double.valueOf(otherDistance));
		}
	}

public String getCountryCode() {
	return countryCode;
}

public void setCountryCode(String countryCode) {
	this.countryCode = countryCode;
}
}