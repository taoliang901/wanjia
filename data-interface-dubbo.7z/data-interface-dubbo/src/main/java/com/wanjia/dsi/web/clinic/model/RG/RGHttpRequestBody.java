package com.wanjia.dsi.web.clinic.model.RG;

public class RGHttpRequestBody {

	
}
