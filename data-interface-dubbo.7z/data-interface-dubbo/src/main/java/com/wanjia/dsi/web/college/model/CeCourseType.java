package com.wanjia.dsi.web.college.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class CeCourseType implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer typeId;

	private String typeName;

	private Integer typePid;

	private Integer isHome;

	private Integer orderNum;

	private Integer delFlag;

	private Date createTime;

	private Date updateTime;

	private Date deleteTime;

	// -----扩展字段
	private List<CeCourseType> subitem;


	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName == null ? null : typeName.trim();
	}

	public Integer getTypePid() {
		return typePid;
	}

	public void setTypePid(Integer typePid) {
		this.typePid = typePid;
	}

	public Integer getIsHome() {
		return isHome;
	}

	public void setIsHome(Integer isHome) {
		this.isHome = isHome;
	}

	public Integer getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(Integer orderNum) {
		this.orderNum = orderNum;
	}

	public Integer getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(Integer delFlag) {
		this.delFlag = delFlag;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getDeleteTime() {
		return deleteTime;
	}

	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}

	public List<CeCourseType> getSubitem() {
		return subitem;
	}

	public void setSubitem(List<CeCourseType> subitem) {
		this.subitem = subitem;
	}

}