package com.wanjia.dsi.web.sms.model;

public class ValidateCode {
	private String validateCode;

	public String getValidateCode() {
		return validateCode;
	}

	public void setValidateCode(String validateCode) {
		this.validateCode = validateCode;
	}
}
