package com.wanjia.dsi.web.cms.activity.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.activity.model.MyCollectionBO;
import com.wanjia.dsi.web.cms.activity.model.MyCollectionStatisticsBO;
import com.wanjia.dsi.web.cms.activity.model.VOMyCollection;
import com.wanjia.dsi.web.cms.activity.model.LocalMedicine;
import com.wanjia.dsi.web.activity.model.Activity;
import com.wanjia.dsi.web.cms.activity.model.DiseaseSmryInfo;

public interface MycollectionService {
/**
 * 将资讯、疾病、药品的收藏信息插入到mongodb
 * @param userId 用户id 必填
 * @param infoId  各个类型统计id 必填
 * @param type 类型 ；资讯：A，药品：M ，疾病：D  必填
 * @param source  设备号或ip  选填
 * @return
 */
	JsonResponse<Void>  insertMycollection(MyCollectionBO infomationClickBO);
	/**
	 * 将所有信息同步到infomation_statistic中
	 * @return
	 */
	//JsonResponse<Void> synchroAllInfomation();
	/**
	 * 将昨天的数据同步到infomation_statistic中
	 * @param date
	 * @return
	 */
	//JsonResponse<Void> synchroInfomation(Date date);
	
	//List<CmsInfomationStatistic> getInfomationCountNow(CmsInfomationStatistic cmsInfomationStatistic); //查询统计量
	/**
	 * 获得我的收藏药品
	 * @param userId 必填
	 * @param type 必填 ，值 M
	 * @return
	 */
	JsonResponse<PageInfo<LocalMedicine>> getMyLocalMedicine(VOMyCollection voMyCollection); 
	/**
	 * 获得我的收藏疾病
	 * @param userId 必填
	 * @param type 必填 值 D
	 * @return
	 */
	JsonResponse<PageInfo<DiseaseSmryInfo>> getMyDiseaseSmryInfo(VOMyCollection voMyCollection); 
	/**
	 * 获得我的收藏资讯
	 * @param userId 必填
	 * @param type  必填 值A
	 * @return
	 */
	JsonResponse<PageInfo<Activity>>  getMyActivity(VOMyCollection voMyCollection); 
	
	/**
	 * 取消我的收藏资讯
	 * @param userId 必填
	 * @param infoId 必填
	 * @param type  必填 ；资讯：A,疾病:D,药品:M
	 * @return
	 */
	public JsonResponse<Void> deleteMyCollection(String userId,String type,String infoId); 
	/**
	 * 是否已收藏
	 * @param userId 必填
	 * @param infoId 必填
	 * @param type  必填 ；资讯：A,疾病:D,药品:M
	 * @return false：未收藏；true:已收藏
	 */
	public JsonResponse<Boolean>  isExists(String userId,String type,String infoId);
	
	/**
	 * 得到收藏量
	 * @param type 必填 ；资讯：A,疾病:D,药品:M
	 * @param infoId 选填
	 * @return
	 */
	JsonResponse<PageInfo<VOMyCollection>> getCollectionStatistic(VOMyCollection voMyCollection); 

	
	/**
	 * 初始化收藏量
	 * @param type 必填 ；资讯：A,疾病:D,药品:M
	 * @param infoIds 必填
	 * @return
	 */
	JsonResponse<List<MyCollectionStatisticsBO>> getCollectionStatistic(String type,List<String> infoIds); 
	/**
	 * 将收藏明细myCollectionBO统计到收藏统计表myCollectionStatisticsBO中
	 * @param dateStr 随便输入当月的任何一个日期，格式：yyyy-MM-dd,不填统计全部
	 * @param type 必填 ；资讯：A,疾病:D,药品:M
	 * @return
	 */
	JsonResponse<String>syncMycollectionStatistc(String dateStr,String type);
	/**
	 * 初始化收藏统计myCollectionStatisticsBO表
	 * @param infoIds 必填；资讯,疾病,药品等id
	 * @param type 必填 ；资讯：A,疾病:D,药品:M
	 * @return
	 */
	JsonResponse<String> initMycollectionStatistc(String type, List<String> infoIds);

}
