package com.wanjia.dsi.web.hyPerson.service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.vo.HyUserVO;

/**
 * 会员注册绑定SERVICE
 */
public interface RegisterBindService {

	/**
	 * 平安地图注册绑定方法
	 * @param String toaId 一帐通ID
	 * @param String mobile 一帐通对应手机号
	 * @return HyUser HyUser 返回会员用户信息(用户名，密码)
	 */
	JsonResponse<HyUserVO> paMapRegisterBind(String toaId, String mobile);
	
	/**
	 * 微信账号绑定会员
	 * @param String openId 微信用户标识
	 * @param String userId C端会员用户ID
	 * @return Boolean Boolean 返回结果成功OR失败
	 */
	JsonResponse<Boolean> wxUserBind(String openId, String userId);
	
	/**
	 * 微信账号解绑会员
	 * @param String openId 微信用户标识
	 * @param String userId C端会员用户ID
	 * @return Boolean Boolean 返回结果成功OR失败
	 */
	JsonResponse<Boolean> wxUserUnBind(String openId, String userId);
	
	/**
	 * 根据openID获取C端用户信息
	 * @param String openId 微信用户标识
	 * @return HyUserVO HyUserVO 
	 */
	JsonResponse<HyUserVO> getHyUserByOpenId(String openId);
	
	/**
	 * 验证OPENID是否有效
	 * @param String openId 微信用户标识
	 * @return Boolean Boolean 返回结果成功OR失败
	 */
	JsonResponse<String> validateOpenId(String openId);
	
	JsonResponse<String> getOpenIdByUserId(String userId);
	
	/**
	 * 微信绑定前置判断（是否已绑定）
	 * @param String openId 微信用户标识，加密的
	 * @param String userId C端会员用户ID
	 * @return Boolean Boolean 返回结果成功OR失败
	 */
	JsonResponse<Boolean> validateBindMsg(String openId, String userId);
}
