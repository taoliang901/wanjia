package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;
import java.util.Date;

public class ClinicUser implements Serializable {
	private static final long serialVersionUID = 1L;

	private String id;

	private String userName;

	private String password;

	private String telphone;

	private String email;

	private String sourceFlag;

	private String referrer;

	private String referrerTel;

	private String activateFlag;

	private Date activateDate;

	private String signAgreementVersion;

	private Date signAgreementDate;

	private String createUser;

	private Date createDate;

	private String modifyUser;

	private Date modifyDate;

	private String delFlag;

	private String clinicId;
	private String accountType;
	private String parentAccountId;

	private String enterpriseFullName;
	
	private String casUuid;

	private Date beginDate;

	private Date endDate;

	public ClinicUser() {
		// TODO Auto-generated constructor stub
	}

	public String getEnterpriseFullName() {
		return enterpriseFullName;
	}

	public void setEnterpriseFullName(String enterpriseFullName) {
		this.enterpriseFullName = enterpriseFullName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getParentAccountId() {
		return parentAccountId;
	}

	public void setParentAccountId(String parentAccountId) {
		this.parentAccountId = parentAccountId;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getClinicId() {
		return clinicId;
	}

	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTelphone() {
		return telphone;
	}

	public void setTelphone(String telphone) {
		this.telphone = telphone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSourceFlag() {
		return sourceFlag;
	}

	public void setSourceFlag(String sourceFlag) {
		this.sourceFlag = sourceFlag;
	}

	public String getReferrer() {
		return referrer;
	}

	public void setReferrer(String referrer) {
		this.referrer = referrer;
	}

	public String getReferrerTel() {
		return referrerTel;
	}

	public void setReferrerTel(String referrerTel) {
		this.referrerTel = referrerTel;
	}

	public String getActivateFlag() {
		return activateFlag;
	}

	public void setActivateFlag(String activateFlag) {
		this.activateFlag = activateFlag;
	}

	public Date getActivateDate() {
		return activateDate;
	}

	public void setActivateDate(Date activateDate) {
		this.activateDate = activateDate;
	}

	public String getSignAgreementVersion() {
		return signAgreementVersion;
	}

	public void setSignAgreementVersion(String signAgreementVersion) {
		this.signAgreementVersion = signAgreementVersion;
	}

	public Date getSignAgreementDate() {
		return signAgreementDate;
	}

	public void setSignAgreementDate(Date signAgreementDate) {
		this.signAgreementDate = signAgreementDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getCasUuid() {
		return casUuid;
	}

	public void setCasUuid(String casUuid) {
		this.casUuid = casUuid;
	}

	@Override
	public String toString() {
		return "ClinicUser [id=" + id + ", userName=" + userName + ", password=" + password + ", telphone=" + telphone + ", email=" + email + ", sourceFlag=" + sourceFlag + ", referrer=" + referrer + ", referrerTel=" + referrerTel + ", activateFlag=" + activateFlag + ", activateDate=" + activateDate + ", signAgreementVersion=" + signAgreementVersion + ", signAgreementDate=" + signAgreementDate + ", createUser=" + createUser + ", createDate=" + createDate + ", modifyUser=" + modifyUser + ", modifyDate=" + modifyDate + ", delFlag=" + delFlag + "]";
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		ClinicUser other = (ClinicUser) that;
		return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId())) && (this.getUserName() == null ? other.getUserName() == null : this.getUserName().equals(other.getUserName())) && (this.getPassword() == null ? other.getPassword() == null : this.getPassword().equals(other.getPassword())) && (this.getTelphone() == null ? other.getTelphone() == null : this.getTelphone().equals(other.getTelphone())) && (this.getEmail() == null ? other.getEmail() == null : this.getEmail().equals(other.getEmail())) && (this.getSourceFlag() == null ? other.getSourceFlag() == null : this.getSourceFlag().equals(other.getSourceFlag())) && (this.getReferrer() == null ? other.getReferrer() == null : this.getReferrer().equals(other.getReferrer())) && (this.getReferrerTel() == null ? other.getReferrerTel() == null : this.getReferrerTel().equals(other.getReferrerTel())) && (this.getActivateFlag() == null ? other.getActivateFlag() == null : this.getActivateFlag().equals(other.getActivateFlag())) && (this.getActivateDate() == null ? other.getActivateDate() == null : this.getActivateDate().equals(other.getActivateDate())) && (this.getSignAgreementVersion() == null ? other.getSignAgreementVersion() == null : this.getSignAgreementVersion().equals(other.getSignAgreementVersion())) && (this.getSignAgreementDate() == null ? other.getSignAgreementDate() == null : this.getSignAgreementDate().equals(other.getSignAgreementDate())) && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser())) && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate())) && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser())) && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate())) && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		result = prime * result + ((getUserName() == null) ? 0 : getUserName().hashCode());
		result = prime * result + ((getPassword() == null) ? 0 : getPassword().hashCode());
		result = prime * result + ((getTelphone() == null) ? 0 : getTelphone().hashCode());
		result = prime * result + ((getEmail() == null) ? 0 : getEmail().hashCode());
		result = prime * result + ((getSourceFlag() == null) ? 0 : getSourceFlag().hashCode());
		result = prime * result + ((getReferrer() == null) ? 0 : getReferrer().hashCode());
		result = prime * result + ((getReferrerTel() == null) ? 0 : getReferrerTel().hashCode());
		result = prime * result + ((getActivateFlag() == null) ? 0 : getActivateFlag().hashCode());
		result = prime * result + ((getActivateDate() == null) ? 0 : getActivateDate().hashCode());
		result = prime * result + ((getSignAgreementVersion() == null) ? 0 : getSignAgreementVersion().hashCode());
		result = prime * result + ((getSignAgreementDate() == null) ? 0 : getSignAgreementDate().hashCode());
		result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
		result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
		result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
		result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
		result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
		return result;
	}
}