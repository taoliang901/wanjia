package com.wanjia.dsi.web.hyPerson.service;

import com.wanjia.dsi.web.hyPerson.model.HyUserInfo;

/**
 * 会员用户相关Service
 */
public interface HyUserInfoService  {
	HyUserInfo getHyUserInfoByHyids(Long hyId);
}
