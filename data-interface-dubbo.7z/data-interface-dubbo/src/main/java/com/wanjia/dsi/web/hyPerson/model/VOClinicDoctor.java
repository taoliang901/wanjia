package com.wanjia.dsi.web.hyPerson.model;

import java.io.Serializable;

public class VOClinicDoctor extends ClinicDoctor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7940747344599035888L;
	private String relationStatus;
	private String clinicId;

	public String getRelationStatus() {
		return relationStatus;
	}

	public void setRelationStatus(String relationStatus) {
		this.relationStatus = relationStatus;
	}

	public String getClinicId() {
		return clinicId;
	}

	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}

}