package com.wanjia.dsi.web.cms.disease.model;

import java.io.Serializable;
import java.util.Date;

import com.wanjia.dsi.web.cms.department.model.CmsDepartmentCriteria;

public class CmsDiseaseCriteria implements Serializable {
    private static final long serialVersionUID = 1L;

    private String cmsDiseaseId;

    private Long publishGroupId;

    private String diseaseId;

    private String diseaseName;

    private String diseaseCode;

    private String diseaseDescription;

    private String departmentId;

    private Integer publishFlag;

    private Date publishDate;

    private Integer delFlag;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    public String getCmsDiseaseId() {
        return cmsDiseaseId;
    }

    public void setCmsDiseaseId(String cmsDiseaseId) {
        this.cmsDiseaseId = cmsDiseaseId;
    }

    public Long getPublishGroupId() {
        return publishGroupId;
    }

    public void setPublishGroupId(Long publishGroupId) {
        this.publishGroupId = publishGroupId;
    }

    public String getDiseaseId() {
        return diseaseId;
    }

    public void setDiseaseId(String diseaseId) {
        this.diseaseId = diseaseId;
    }

    public String getDiseaseName() {
        return diseaseName;
    }

    public void setDiseaseName(String diseaseName) {
        this.diseaseName = diseaseName;
    }

    public String getDiseaseCode() {
        return diseaseCode;
    }

    public void setDiseaseCode(String diseaseCode) {
        this.diseaseCode = diseaseCode;
    }

    public String getDiseaseDescription() {
        return diseaseDescription;
    }

    public void setDiseaseDescription(String diseaseDescription) {
        this.diseaseDescription = diseaseDescription;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public Integer getPublishFlag() {
        return publishFlag;
    }

    public void setPublishFlag(Integer publishFlag) {
        this.publishFlag = publishFlag;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        CmsDiseaseCriteria other = (CmsDiseaseCriteria) that;
        return (this.getCmsDiseaseId() == null ? other.getCmsDiseaseId() == null : this.getCmsDiseaseId().equals(other.getCmsDiseaseId()))
            && (this.getPublishGroupId() == null ? other.getPublishGroupId() == null : this.getPublishGroupId().equals(other.getPublishGroupId()))
            && (this.getDiseaseId() == null ? other.getDiseaseId() == null : this.getDiseaseId().equals(other.getDiseaseId()))
            && (this.getDiseaseName() == null ? other.getDiseaseName() == null : this.getDiseaseName().equals(other.getDiseaseName()))
            && (this.getDiseaseCode() == null ? other.getDiseaseCode() == null : this.getDiseaseCode().equals(other.getDiseaseCode()))
            && (this.getDiseaseDescription() == null ? other.getDiseaseDescription() == null : this.getDiseaseDescription().equals(other.getDiseaseDescription()))
            && (this.getDepartmentId() == null ? other.getDepartmentId() == null : this.getDepartmentId().equals(other.getDepartmentId()))
            && (this.getPublishFlag() == null ? other.getPublishFlag() == null : this.getPublishFlag().equals(other.getPublishFlag()))
            && (this.getPublishDate() == null ? other.getPublishDate() == null : this.getPublishDate().equals(other.getPublishDate()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser()))
            && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate()))
            && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser()))
            && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getCmsDiseaseId() == null) ? 0 : getCmsDiseaseId().hashCode());
        result = prime * result + ((getPublishGroupId() == null) ? 0 : getPublishGroupId().hashCode());
        result = prime * result + ((getDiseaseId() == null) ? 0 : getDiseaseId().hashCode());
        result = prime * result + ((getDiseaseName() == null) ? 0 : getDiseaseName().hashCode());
        result = prime * result + ((getDiseaseCode() == null) ? 0 : getDiseaseCode().hashCode());
        result = prime * result + ((getDiseaseDescription() == null) ? 0 : getDiseaseDescription().hashCode());
        result = prime * result + ((getDepartmentId() == null) ? 0 : getDepartmentId().hashCode());
        result = prime * result + ((getPublishFlag() == null) ? 0 : getPublishFlag().hashCode());
        result = prime * result + ((getPublishDate() == null) ? 0 : getPublishDate().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
        result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
        result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
        result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
        return result;
    }
    
    
    /**
     * 对象转换
     * @return
     */
    public CmsDepartmentCriteria transCmsDepartmentField(){
    	CmsDepartmentCriteria dpt = new CmsDepartmentCriteria();
    	dpt.setDepartmentId(this.getDiseaseId());
    	dpt.setDepartmentName(this.getDiseaseName());
    	dpt.setDepartmentDescription(this.getDiseaseDescription());
    	dpt.setDepartmentCode(this.getDiseaseCode());
    	dpt.setParentId(this.getDepartmentId());
    	return dpt;
    }
    
    
    
    
    
    
    
    
}