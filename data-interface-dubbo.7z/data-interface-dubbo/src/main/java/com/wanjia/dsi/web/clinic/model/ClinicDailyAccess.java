package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;
import java.util.Date;

public class ClinicDailyAccess extends ClinicDailyAccessKey implements Serializable {
	private static final long serialVersionUID = 1L;

	private String clinicName;

	private Long clinicAccessDailyNum;

	private Long clinicAccessSumNum;

	private Integer clinicAccessRanking;

	private String delFlag;

	private Date createDt;

	private String createUsr;

	private Date updateDt;

	private String updateUsr;

	private Date beginDate;

	private Date endDate;

	public ClinicDailyAccess() {
		// TODO Auto-generated constructor stub
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public Long getClinicAccessDailyNum() {
		return clinicAccessDailyNum;
	}

	public void setClinicAccessDailyNum(Long clinicAccessDailyNum) {
		this.clinicAccessDailyNum = clinicAccessDailyNum;
	}

	public Long getClinicAccessSumNum() {
		return clinicAccessSumNum;
	}

	public void setClinicAccessSumNum(Long clinicAccessSumNum) {
		this.clinicAccessSumNum = clinicAccessSumNum;
	}

	public Integer getClinicAccessRanking() {
		return clinicAccessRanking;
	}

	public void setClinicAccessRanking(Integer clinicAccessRanking) {
		this.clinicAccessRanking = clinicAccessRanking;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getCreateUsr() {
		return createUsr;
	}

	public void setCreateUsr(String createUsr) {
		this.createUsr = createUsr;
	}

	public Date getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateUsr() {
		return updateUsr;
	}

	public void setUpdateUsr(String updateUsr) {
		this.updateUsr = updateUsr;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		ClinicDailyAccess other = (ClinicDailyAccess) that;
		return (this.getClinicAccessDate() == null ? other.getClinicAccessDate() == null : this.getClinicAccessDate().equals(other.getClinicAccessDate())) && (this.getClinicId() == null ? other.getClinicId() == null : this.getClinicId().equals(other.getClinicId())) && (this.getClinicName() == null ? other.getClinicName() == null : this.getClinicName().equals(other.getClinicName())) && (this.getClinicAccessDailyNum() == null ? other.getClinicAccessDailyNum() == null : this.getClinicAccessDailyNum().equals(other.getClinicAccessDailyNum())) && (this.getClinicAccessSumNum() == null ? other.getClinicAccessSumNum() == null : this.getClinicAccessSumNum().equals(other.getClinicAccessSumNum())) && (this.getClinicAccessRanking() == null ? other.getClinicAccessRanking() == null : this.getClinicAccessRanking().equals(other.getClinicAccessRanking())) && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag())) && (this.getCreateDt() == null ? other.getCreateDt() == null : this.getCreateDt().equals(other.getCreateDt())) && (this.getCreateUsr() == null ? other.getCreateUsr() == null : this.getCreateUsr().equals(other.getCreateUsr())) && (this.getUpdateDt() == null ? other.getUpdateDt() == null : this.getUpdateDt().equals(other.getUpdateDt())) && (this.getUpdateUsr() == null ? other.getUpdateUsr() == null : this.getUpdateUsr().equals(other.getUpdateUsr()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getClinicAccessDate() == null) ? 0 : getClinicAccessDate().hashCode());
		result = prime * result + ((getClinicId() == null) ? 0 : getClinicId().hashCode());
		result = prime * result + ((getClinicName() == null) ? 0 : getClinicName().hashCode());
		result = prime * result + ((getClinicAccessDailyNum() == null) ? 0 : getClinicAccessDailyNum().hashCode());
		result = prime * result + ((getClinicAccessSumNum() == null) ? 0 : getClinicAccessSumNum().hashCode());
		result = prime * result + ((getClinicAccessRanking() == null) ? 0 : getClinicAccessRanking().hashCode());
		result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
		result = prime * result + ((getCreateDt() == null) ? 0 : getCreateDt().hashCode());
		result = prime * result + ((getCreateUsr() == null) ? 0 : getCreateUsr().hashCode());
		result = prime * result + ((getUpdateDt() == null) ? 0 : getUpdateDt().hashCode());
		result = prime * result + ((getUpdateUsr() == null) ? 0 : getUpdateUsr().hashCode());
		return result;
	}
}