package com.wanjia.dsi.web.job.dao.mapper;

import java.util.List;

import com.wanjia.dsi.web.job.model.ClinicSearch;
import com.wanjia.dsi.web.job.model.JobSearch;

public interface JobMapper {
	
    List<JobSearch> getJobSearchList(JobSearch jobSearch);
	
    List<ClinicSearch> getClinicSearchList(ClinicSearch clinicSearch);
	
//	JobSearch getJobSearchDetailById(String jobId);
//	
//	ClinicSearch getClinicSearchDetailById(String clinicId);
	
	void insertClinicStatic();
	
	void updateClinicCvcount();
	
	void updateClinicJobcount();
	
	void updateClinicHotPercent();
	
	void insertJobStatic();
	
	void updateJobRecordCount();
}