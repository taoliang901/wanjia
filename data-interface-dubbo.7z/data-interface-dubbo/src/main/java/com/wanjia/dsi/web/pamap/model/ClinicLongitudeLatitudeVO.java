package com.wanjia.dsi.web.pamap.model;

import java.io.Serializable;

public class ClinicLongitudeLatitudeVO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4129259464964271104L;
	/** 该类型数据唯一主键*/
	private String syncId;
	/** 网点名称(诊所名称)*/
	private String name;
	/** 网点的icon，url（诊所LOGO图片路径）*/
	private String icon;
	/** 网点地址（地址表详细地址）*/
	private String address;
	/** 网点详细地址（地址表详细地址）*/
	private String detailAddress;
	/** 联系电话（诊所电话_手机）*/
	private String phoneNumber;
	/** 省份编码(省code)*/
	private String provinceCode;
	/** 城市编码（市code）*/
	private String cityCode;
	/** 区域编码（区code）*/
	private String districtCode;
	/** 经度 */
	private String longitude;
	/** 纬度 */
	private String latitude;
	/** 服务列表，以空格分隔 */
	private String serviceList;
	/** 0=正常，1=删除 */
	private String delFlag;
	/** 是否可预约(1:可预约；0:不可预约) */
	private String isBooking;
	/** 一级科室 */
	private String diagnosisType1;
	/** 一级科室 */
	private String diagnosisType2;
	/** 是否上线（不上线的需删除） */
	private String isView;

	public String getSyncId() {
		return syncId;
	}

	public void setSyncId(String syncId) {
		this.syncId = syncId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDetailAddress() {
		return detailAddress;
	}

	public void setDetailAddress(String detailAddress) {
		this.detailAddress = detailAddress;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getProvinceCode() {
		return provinceCode;
	}

	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getServiceList() {
		return serviceList;
	}

	public void setServiceList(String serviceList) {
		this.serviceList = serviceList;
	}

	@Override
	public String toString() {
		return "ClinicLongitudeLatitudeVO [syncId=" + syncId + ", name=" + name + ", icon=" + icon + ", address="
				+ address + ", detailAddress=" + detailAddress + ", phoneNumber=" + phoneNumber + ", provinceCode="
				+ provinceCode + ", cityCode=" + cityCode + ", districtCode=" + districtCode + ", longitude="
				+ longitude + ", latitude=" + latitude + ", serviceList=" + serviceList + "]";
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getIsBooking() {
		return isBooking;
	}

	public void setIsBooking(String isBooking) {
		this.isBooking = isBooking;
	}

	public String getDiagnosisType1() {
		return diagnosisType1;
	}

	public void setDiagnosisType1(String diagnosisType1) {
		this.diagnosisType1 = diagnosisType1;
	}

	public String getDiagnosisType2() {
		return diagnosisType2;
	}

	public void setDiagnosisType2(String diagnosisType2) {
		this.diagnosisType2 = diagnosisType2;
	}

	public String getIsView() {
		return isView;
	}

	public void setIsView(String isView) {
		this.isView = isView;
	}

}
