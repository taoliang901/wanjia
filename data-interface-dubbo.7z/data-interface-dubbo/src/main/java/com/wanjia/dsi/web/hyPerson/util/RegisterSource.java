package com.wanjia.dsi.web.hyPerson.util;

/**
 * 用户注册来源
 * 
 * @author LUOXIAOJUN640
 *
 */
public enum RegisterSource {

	NONE("none", "未知来源"), PORTAL("cas-portal", "门户网站"), DOCTOR("cas-doctor", "医生注册"), MEDICAL("cas-medical",
			"医疗平台"), CLINIC("cas-clinic", "诊所管理员注册"), CAS("cas", "CAS中心"), TOA("toa",
					"一账通"), JINGXIAOSHANG("jingxiaoshang", "网关1"), NBWG("nbwg", "网关2"), M("m", "M站");

	private String code;
	private String value;

	private RegisterSource(String code, String value) {
		this.code = code;
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
