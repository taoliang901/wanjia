package com.wanjia.dsi.web.cms.common.entity;

import java.util.List;

public class ClinicDepartmentTree extends ClinicDepartment{
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<ClinicDepartmentTree> subitemList;
	
	public List<ClinicDepartmentTree> getSubitemList() {
		return subitemList;
	}
	
	public void setSubitemList(List<ClinicDepartmentTree> subitemList) {
		this.subitemList = subitemList;
	}
	
	public ClinicDepartment getClinicDepartment(){
		ClinicDepartment dpt = new ClinicDepartment(super.getDepartmentId(), super.getDepartmentName(), 
				super.getDepartmentCode(), super.getDepartmentDescription(), super.getParentId(),
				super.getDelFlag(), super.getCreateUser(), 
				super.getCreateDate(), 
				super.getModifyUser(), super.getModifyDate(),super.getOriginalParentId());
		return dpt;
	}
}
