package com.wanjia.dsi.web.rz.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.rz.model.Radar;
import com.wanjia.dsi.web.rz.model.RzItemsInfo;

public interface RzItemsService {
	
	/**
	 * 查询诊所网站中认证报告的认证项
	 * @param map 
	 * 		  参数包含：resultId（认证结果id）、clinicId（诊所id）
	 * @return
	 */
	JsonResponse<List<RzItemsInfo>> queryClinicItems(Map<String,Object> map);
	
	public String countPassItemNum(Map<String, Object> map);
	
	public String countFailItemNum(Map<String, Object> map);
	
	public String countUnusedItemNum(Map<String, Object> map);
	
	public JsonResponse<Map<String,Object>> queryRzScoreStatistic(String resultId);
	
	/**
	 * 查询雷达图的平均分
	 * @param map
	 * @return
	 */
	JsonResponse<List<Radar>> queryRadar(Map<String,Object> map);
	
	/**
	 * 查询诊所网站中认证报告的认证项
	 * @param map
	 * @return
	 */
	JsonResponse<List<RzItemsInfo>> queryRzItemsForClinic(Map<String,Object> map);
	
	/**
	 * 诊所报告查看接口
	 * @param map
	 * 		   参数包含：resultId（认证结果id）、clinicId（诊所id）
	 * @return
	 */
	JsonResponse<Map<String,Object>> getAuditReport(Map<String,Object> map);
}
