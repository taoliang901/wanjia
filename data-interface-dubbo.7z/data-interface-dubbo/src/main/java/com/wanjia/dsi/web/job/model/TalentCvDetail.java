package com.wanjia.dsi.web.job.model;
import java.io.Serializable;
import java.util.List;

public class TalentCvDetail implements Serializable{
	private static final long serialVersionUID = 2715617712387254696L;
	
	private TalentCv talentCvBasic;
	private List<TalentCvExperience> experienceList;
	private List<TalentCvEducation> educationList;
	
	public List<TalentCvExperience> getExperienceList() {
		return experienceList;
	}
	public void setExperienceList(List<TalentCvExperience> experienceList) {
		this.experienceList = experienceList;
	}
	public List<TalentCvEducation> getEducationList() {
		return educationList;
	}
	public void setEducationList(List<TalentCvEducation> educationList) {
		this.educationList = educationList;
	}
	public TalentCv getTalentCvBasic() {
		return talentCvBasic;
	}
	public void setTalentCvBasic(TalentCv talentCvBasic) {
		this.talentCvBasic = talentCvBasic;
	}
}