package com.wanjia.dsi.web.cms.disease.dao.mapper;

import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.cms.disease.model.CmsDiseaseCriteria;

public interface CmsDiseaseCriteriaMapper extends IBaseDao {
	List<CmsDiseaseCriteria> selectBySelective(CmsDiseaseCriteria criteria);
}