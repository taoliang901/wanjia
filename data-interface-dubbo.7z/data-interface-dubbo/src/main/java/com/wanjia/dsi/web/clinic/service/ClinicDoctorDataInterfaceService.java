package com.wanjia.dsi.web.clinic.service;

import java.util.Map;


import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinic.model.YlptDoctor;
import com.wanjia.dsi.web.clinic.model.YlptDoctorUserInfo;

public interface ClinicDoctorDataInterfaceService {
	
	/**
	 * 新增医生
	 * @param params
	 * @param ClinicDoctorDataInterface doctor	必输（页面医生相关信息记录）
	 * @param String saveOrSubmitFlg			必输（判断是保存操作还是提交操作）
	 * @param String clinicId					必输（诊所id）
	 * @param String ipAddress					选填（IP地址）
	 * @return JsonResponse<String>
	 */
	public JsonResponse<String> addDoctor(Map<String,Object> params);
	
	/**
	 * 诊所申请关联医生
	 * @param params
	 * @param clinicId 		必输
	 * @param doctorId 		必输
	 * @return
	 */
	public JsonResponse<String> applyConnDoctor(Map<String,Object> params);
	
	/**
	 * 诊所取消关联医生
	 * @param mapId ClinicDoctorMap表的id 		必输
	 * @param params
	 * @return
	 */
	public JsonResponse<String> cancelConnDoctor(Map<String,Object> params);
	
	/**
	 * 诊所取消申请关联
	 * @param mapId ClinicDoctorMap表的id 		必输
	 * @param params
	 * @return
	 */	
	public JsonResponse<String> cancelApplyDoctor(Map<String,Object> params);
	
	/**
	 * 诊所重新申请关联医生
	 * @param mapId ClinicDoctorMap表的id 		必输
	 * @param params
	 * @return
	 */
	public JsonResponse<String> reApplyDoctor(Map<String,Object> params);
	
	
	/**
	 * 诊所同意关联医生
	 * @param params
	 * @param mapId ClinicDoctorMap表的id 		必输
	 * @return
	 */
	public JsonResponse<String> agreeApplyDoctor(Map<String,Object> params);
	
	/**
	 * 诊所拒绝医生申请
	 * @param mapId ClinicDoctorMap表的id 		必输
	 * @param params
	 * @return
	 */
	public JsonResponse<String> refuseApplyDoctor(Map<String,Object> params);
	
	
	/**
	 * 更新诊所医生关联关系表
	 * @param mapId					map表id		必输
	 * @param doctorId				医生id		必输
	 * @param clinicId				诊所id		必输
	 * @param proFlg				操作标识		
	 * @param relationStatus		关联关系状态	必输
	 * @param relationCancelRemark	取消原因		
	 * @param params
	 * @return
	 */
	public JsonResponse<String> updateClinicDoctorMap(Map<String,Object> params);

	
	/**
	 * 校验手机号码是否已经被注册
	 * @param phone		医生手机号	必输
	 * @param clinicId	诊所id		必输
	 * @return 返回类型为Map<String，Object>
	 * @return String isDoctor -- if(isDoctor == 0){ 未注册，新增关联 } else { 医生会员已注册，申请关联}
	 * @return Map<String,Object> doctorInfo --  医生相关信息  id，doctorName,mobile,medicineTitle,practiceArea
	 */
	public JsonResponse<Map<String, Object>> validateDoctorPhone(String phone, String clinicId);

	
	
	/**
	 * 根据手机号获取医生相关信息：角色，是否已关联诊所，医生信息（id，姓名，手机号，职称，职称范围）
	 * @param mobile
	 * @return JsonResponse<YlptDoctor>，状态为JsonResponse.Status.SUCCESS，说明获取信息成功
	 */
	JsonResponse<YlptDoctor> getDoctorByMobile(String mobile, String ClinicId);
	
	
	/**
	 * 根据手机号关联诊所
	 * @param mobile
	 * @param clinicId
	 * @return 状态为JsonResponse.Status.SUCCESS，说明申请关联成功
	 */
	public JsonResponse<String> connDoctorByPhone(String mobile,String clinicId);
	
	
	
	/**
	 * 新增医生信息
	 * clinicId				当前诊所Id 必填
	 * doctorInfo.userName 	用户名 必填
	 * doctorInfo.mobile 	手机号 必填
	 * doctorInfo.doctorName 医生姓名 必填
	 * doctorInfo.sex 		性别
	 * doctorInfo.birthday 	生日
	 * doctorInfo.email 	邮箱
	 * sex: 1：男 2：女
	 * @param doctorInfo
	 * @return JsonResponse<String> 医生Id 如果status为JsonResponse.Status.SUCCESS，则说明新增成功
	 */
	public JsonResponse<String> addYlptDoctor(YlptDoctorUserInfo doctorInfo, String clinicId);
	
	
	/**
	 * 修改医生信息
	 * clinicId				当前诊所Id 必填
	 * doctorInfo.id		被编辑医生的医生Id 必填
	 * doctorInfo.casUuid	被编辑医生的医生casUuid 必填
	 * doctorInfo.userName 	用户名 必填
	 * doctorInfo.mobile 	手机号 必填
	 * @param doctorInfo
	 * @return JsonResponse<String> 返回医生Id 如果status为JsonResponse.Status.SUCCESS，则说明新增成功
	 */
	public JsonResponse<String> editYlptDoctor(YlptDoctorUserInfo doctorInfo, String clinicId);
	
	
}
