package com.wanjia.dsi.web.pamap.service;

import com.wanjia.common.json.JsonResponse;

/**
 * 同步诊所至【平安地图】
 */
public interface PaMapClinicTongbuService {

	/**
	 * 按天同步诊所至【平安地图】
	 * 
	 * @注1	增量同步
	 * @注2	经纬度不空
	 * 
	 * @param nowDate 当日日期，格式yyyy-mm-dd
	 */
	public JsonResponse<Void> doTongbuByDate(String nowDate);

}