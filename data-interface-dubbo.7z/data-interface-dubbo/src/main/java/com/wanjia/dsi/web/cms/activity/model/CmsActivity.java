package com.wanjia.dsi.web.cms.activity.model;

import java.io.Serializable;
import java.util.Date;

public class CmsActivity implements Serializable {

	private static final long serialVersionUID = 2674137407454487174L;

	private String activityId;

	private String pageConfigId;

	private String activityTitle;

	private String activityTitleHtml;

	private String activityHref;

	private Integer activityOrder;

	private String activityBreif;

	private String activityContent;

	private String activitySource;

	private String activityAuthor;

	private Date activityEndDate;

	private Integer activityTopFlag;

	private String activityImageLocation;

	private String activityImageAlt;

	private String activityImageBorderColor;

	private String activityFullScreenFlag;

	private String activityKeyword;

	private String herfType;

	private String createUser;

	private Date createDate;

	private String modifyUser;

	private Date modifyDate;

	private String delFlag;

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getPageConfigId() {
		return pageConfigId;
	}

	public void setPageConfigId(String pageConfigId) {
		this.pageConfigId = pageConfigId;
	}

	public String getActivityTitle() {
		return activityTitle;
	}

	public void setActivityTitle(String activityTitle) {
		this.activityTitle = activityTitle;
	}

	public String getActivityTitleHtml() {
		return activityTitleHtml;
	}

	public void setActivityTitleHtml(String activityTitleHtml) {
		this.activityTitleHtml = activityTitleHtml;
	}

	public String getActivityHref() {
		return activityHref;
	}

	public void setActivityHref(String activityHref) {
		this.activityHref = activityHref;
	}

	public Integer getActivityOrder() {
		return activityOrder;
	}

	public void setActivityOrder(Integer activityOrder) {
		this.activityOrder = activityOrder;
	}

	public String getActivityBreif() {
		return activityBreif;
	}

	public void setActivityBreif(String activityBreif) {
		this.activityBreif = activityBreif;
	}

	public String getActivityContent() {
		return activityContent;
	}

	public void setActivityContent(String activityContent) {
		this.activityContent = activityContent;
	}

	public String getActivitySource() {
		return activitySource;
	}

	public void setActivitySource(String activitySource) {
		this.activitySource = activitySource;
	}

	public String getActivityAuthor() {
		return activityAuthor;
	}

	public void setActivityAuthor(String activityAuthor) {
		this.activityAuthor = activityAuthor;
	}

	public Date getActivityEndDate() {
		return activityEndDate;
	}

	public void setActivityEndDate(Date activityEndDate) {
		this.activityEndDate = activityEndDate;
	}

	public Integer getActivityTopFlag() {
		return activityTopFlag;
	}

	public void setActivityTopFlag(Integer activityTopFlag) {
		this.activityTopFlag = activityTopFlag;
	}

	public String getActivityImageLocation() {
		return activityImageLocation;
	}

	public void setActivityImageLocation(String activityImageLocation) {
		this.activityImageLocation = activityImageLocation;
	}

	public String getActivityImageAlt() {
		return activityImageAlt;
	}

	public void setActivityImageAlt(String activityImageAlt) {
		this.activityImageAlt = activityImageAlt;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getActivityKeyword() {
		return activityKeyword;
	}

	public void setActivityKeyword(String activityKeyword) {
		this.activityKeyword = activityKeyword;
	}

	public String getActivityImageBorderColor() {
		return activityImageBorderColor;
	}

	public void setActivityImageBorderColor(String activityImageBorderColor) {
		this.activityImageBorderColor = activityImageBorderColor;
	}

	public String getActivityFullScreenFlag() {
		return activityFullScreenFlag;
	}

	public void setActivityFullScreenFlag(String activityFullScreenFlag) {
		this.activityFullScreenFlag = activityFullScreenFlag;
	}
	
	public String getHerfType() {
		return herfType;
	}

	public void setHerfType(String herfType) {
		this.herfType = herfType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((activityAuthor == null) ? 0 : activityAuthor.hashCode());
		result = prime * result + ((activityBreif == null) ? 0 : activityBreif.hashCode());
		result = prime * result + ((activityContent == null) ? 0 : activityContent.hashCode());
		result = prime * result + ((activityEndDate == null) ? 0 : activityEndDate.hashCode());
		result = prime * result + ((activityFullScreenFlag == null) ? 0 : activityFullScreenFlag.hashCode());
		result = prime * result + ((activityHref == null) ? 0 : activityHref.hashCode());
		result = prime * result + ((activityId == null) ? 0 : activityId.hashCode());
		result = prime * result + ((activityImageAlt == null) ? 0 : activityImageAlt.hashCode());
		result = prime * result + ((activityImageBorderColor == null) ? 0 : activityImageBorderColor.hashCode());
		result = prime * result + ((activityImageLocation == null) ? 0 : activityImageLocation.hashCode());
		result = prime * result + ((activityKeyword == null) ? 0 : activityKeyword.hashCode());
		result = prime * result + ((activityOrder == null) ? 0 : activityOrder.hashCode());
		result = prime * result + ((activitySource == null) ? 0 : activitySource.hashCode());
		result = prime * result + ((activityTitle == null) ? 0 : activityTitle.hashCode());
		result = prime * result + ((activityTitleHtml == null) ? 0 : activityTitleHtml.hashCode());
		result = prime * result + ((activityTopFlag == null) ? 0 : activityTopFlag.hashCode());
		result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
		result = prime * result + ((createUser == null) ? 0 : createUser.hashCode());
		result = prime * result + ((delFlag == null) ? 0 : delFlag.hashCode());
		result = prime * result + ((modifyDate == null) ? 0 : modifyDate.hashCode());
		result = prime * result + ((modifyUser == null) ? 0 : modifyUser.hashCode());
		result = prime * result + ((pageConfigId == null) ? 0 : pageConfigId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CmsActivity other = (CmsActivity) obj;
		if (activityAuthor == null) {
			if (other.activityAuthor != null)
				return false;
		} else if (!activityAuthor.equals(other.activityAuthor))
			return false;
		if (activityBreif == null) {
			if (other.activityBreif != null)
				return false;
		} else if (!activityBreif.equals(other.activityBreif))
			return false;
		if (activityContent == null) {
			if (other.activityContent != null)
				return false;
		} else if (!activityContent.equals(other.activityContent))
			return false;
		if (activityEndDate == null) {
			if (other.activityEndDate != null)
				return false;
		} else if (!activityEndDate.equals(other.activityEndDate))
			return false;
		if (activityFullScreenFlag == null) {
			if (other.activityFullScreenFlag != null)
				return false;
		} else if (!activityFullScreenFlag.equals(other.activityFullScreenFlag))
			return false;
		if (activityHref == null) {
			if (other.activityHref != null)
				return false;
		} else if (!activityHref.equals(other.activityHref))
			return false;
		if (activityId == null) {
			if (other.activityId != null)
				return false;
		} else if (!activityId.equals(other.activityId))
			return false;
		if (activityImageAlt == null) {
			if (other.activityImageAlt != null)
				return false;
		} else if (!activityImageAlt.equals(other.activityImageAlt))
			return false;
		if (activityImageBorderColor == null) {
			if (other.activityImageBorderColor != null)
				return false;
		} else if (!activityImageBorderColor.equals(other.activityImageBorderColor))
			return false;
		if (activityImageLocation == null) {
			if (other.activityImageLocation != null)
				return false;
		} else if (!activityImageLocation.equals(other.activityImageLocation))
			return false;
		if (activityKeyword == null) {
			if (other.activityKeyword != null)
				return false;
		} else if (!activityKeyword.equals(other.activityKeyword))
			return false;
		if (activityOrder == null) {
			if (other.activityOrder != null)
				return false;
		} else if (!activityOrder.equals(other.activityOrder))
			return false;
		if (activitySource == null) {
			if (other.activitySource != null)
				return false;
		} else if (!activitySource.equals(other.activitySource))
			return false;
		if (activityTitle == null) {
			if (other.activityTitle != null)
				return false;
		} else if (!activityTitle.equals(other.activityTitle))
			return false;
		if (activityTitleHtml == null) {
			if (other.activityTitleHtml != null)
				return false;
		} else if (!activityTitleHtml.equals(other.activityTitleHtml))
			return false;
		if (activityTopFlag == null) {
			if (other.activityTopFlag != null)
				return false;
		} else if (!activityTopFlag.equals(other.activityTopFlag))
			return false;
		if (createDate == null) {
			if (other.createDate != null)
				return false;
		} else if (!createDate.equals(other.createDate))
			return false;
		if (createUser == null) {
			if (other.createUser != null)
				return false;
		} else if (!createUser.equals(other.createUser))
			return false;
		if (delFlag == null) {
			if (other.delFlag != null)
				return false;
		} else if (!delFlag.equals(other.delFlag))
			return false;
		if (modifyDate == null) {
			if (other.modifyDate != null)
				return false;
		} else if (!modifyDate.equals(other.modifyDate))
			return false;
		if (modifyUser == null) {
			if (other.modifyUser != null)
				return false;
		} else if (!modifyUser.equals(other.modifyUser))
			return false;
		if (pageConfigId == null) {
			if (other.pageConfigId != null)
				return false;
		} else if (!pageConfigId.equals(other.pageConfigId))
			return false;
		return true;
	}

}