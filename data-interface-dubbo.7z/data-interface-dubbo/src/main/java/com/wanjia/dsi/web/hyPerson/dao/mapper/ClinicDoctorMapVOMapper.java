package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.hyPerson.model.ClinicDoctorMap;
import com.wanjia.dsi.web.hyPerson.model.VOClinicInfo;
import com.wanjia.dsi.web.hyPerson.vo.HyClinicDoctorMapVO;

public interface ClinicDoctorMapVOMapper {

    List<HyClinicDoctorMapVO> selectByMap(Map<String, Object> param);
    
    List<HyClinicDoctorMapVO> selectByMapForHy(Map<String, Object> param);
    
	List<HyClinicDoctorMapVO> selectClinicDoctorMapByProperties(Map<String, Object> param);
	
    /**
     * 根据条件查询不同的关联关系
     * @param conditions
     * @return
     */
    List<ClinicDoctorMap> selectByConditions(Map<String,Object> conditions);

    
    /**
     * 查询当前诊所与医生的关联状态
     * @param conditions
     * @return
     */
	List<ClinicDoctorMap> selectclinicDoctorMapByConditions(Map<String, Object> conditions);
	
	/**
	 * 查询当前诊所与医生的关联状态(不关注是否已删除)
	 * @param conditions
	 * @return
	 */
	List<ClinicDoctorMap> selectByConditionsWithOutDelFlg(Map<String, Object> conditions);
	
	/**
	 * 根据关联状态，统计关联数量
	 * @param conditions
	 * @return
	 */
	Integer countByStatus(Map<String, Object> map);
	
	List<ClinicDoctorMap> getMapByDoctorid(VOClinicInfo voClinicInfo);
	
}