package com.wanjia.dsi.web.hyPerson.service;

import com.wanjia.common.json.JsonResponse;


public interface HyCouponDingdanService {
/**
 * 新增订单信息
 * 第一次使用卡和微信认领时保存到数据库
 * @param couponId: varchar(36) 非空, 产品id 
 * @param userId:   bigint(20) 非空, 用户id
 * @param cardId：  varchar(36) 可为null，不能空字符串， 卡id
 * @return
 */
public JsonResponse<Long> insertSelective(String couponId, long userId,String cardId);
}
