package com.wanjia.dsi.web.callCenter.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.callCenter.model.IssueOBProductServiceRecord;

public interface IssueOBProductServiceRecordMapper extends IBaseDao {
	List<IssueOBProductServiceRecord> getEntityByApptCode(String apptCode);
	
	List<IssueOBProductServiceRecord> findEntityByParams(Map<String,Object> params);
}