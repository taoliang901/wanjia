package com.wanjia.dsi.cms.page.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.cms.page.model.PageInfo;
import com.wanjia.dsi.cms.page.model.PageRecommendImg;
import com.wanjia.dsi.cms.page.model.PageRecommendInfo;
import com.wanjia.dsi.cms.page.model.PageRecommendInfoCriteria;
import com.wanjia.dsi.cms.page.model.PageRecommendInfoVo;
import com.wanjia.dsi.cms.page.model.PageRecommendRole;
import com.wanjia.dsi.cms.page.model.PageSite;
import com.wanjia.dsi.cms.page.model.PageSiteType;

public interface PageRecommendInfoService {

	/**
	 * 根据参数模型查询页面推荐数据及其附属信息列表
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<List<PageRecommendInfoVo>> getPageRecommendInfoVoList(PageRecommendInfoCriteria criteria);
	
	/**
	 * 根据参数ID删除页面推荐数据及其附属信息
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<Void> deletePageRecommendInfoVo(PageRecommendInfoCriteria criteria);
	
	/**
	 * 根据参数模型统计所有页面推荐数据及其附属数量
	 * 
	 * @param map
	 * @return
	 */
	JsonResponse<Long> countPageRecommendInfoAllData(Map<String,Object> map);
	
	/**
	 * 根据参数模型查询所有页面推荐数据及其附属信息列表
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<List<PageRecommendInfoVo>> getPageRecommendInfoAllList(Map<String,Object> map);
	
	/**
	 * 根据参数模型查询页面推荐数据信息列表
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<List<PageRecommendInfo>> getPageRecommendInfoList(PageRecommendInfoCriteria criteria);
	
	/**
	 * 添加页面推荐数据信息
	 * 
	 * @param record
	 * @return
	 */
	JsonResponse<Void> insertPageRecommendInfo(PageRecommendInfo record);
	
	/**
	 * 修改页面推荐数据信息
	 * 
	 * @param record
	 * @return
	 */
	JsonResponse<Void> updatePageRecommendInfo(PageRecommendInfo record);
	
	/**
	 * 根据参数模型查询页面推荐数据图片信息列表
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<List<PageRecommendImg>> getPageRecommendImgList(PageRecommendImg model);
	
	/**
	 * 添加页面推荐数据图片信息
	 * 
	 * @param record
	 * @return
	 */
	JsonResponse<Void> insertPageRecommendImg(PageRecommendImg record);
	
	/**
	 * 修改页面推荐数据图片信息
	 * 
	 * @param record
	 * @return
	 */
	JsonResponse<Void> updatePageRecommendImg(PageRecommendImg record);
	
	/**
	 * 根据参数模型查询页面推荐角色数据信息列表
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<List<PageRecommendRole>> getPageRecommendRoleList(PageRecommendRole model);
	
	/**
	 * 添加页面推荐角色数据信息
	 * 
	 * @param record
	 * @return
	 */
	JsonResponse<Void> insertPageRecommendRole(PageRecommendRole record);
	
	/**
	 * 根据参数模型统计页面推荐角色数量
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<Long> countPageRecommendRole(PageRecommendInfoCriteria record);
	
	/**
	 * 修改页面推荐角色数据信息
	 * 
	 * @param record
	 * @return
	 */
	JsonResponse<Void> updatePageRecommendRole(PageRecommendRole record);
	
	/**
	 * 根据参数查询CMS配置的页面信息列表
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<List<PageInfo>> getPageInfoListByParam(PageInfo model);
	
	/**
	 * 根据参数查询页面推荐位数据信息列表
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<List<PageSite>> getPageSiteListByParam(PageSite model);
	
	/**
	 * 根据参数查询页面推荐类型数据信息列表
	 * 
	 * @param model
	 * @return
	 */
	JsonResponse<List<PageSiteType>> getPageSiteTypeListByParam(PageSiteType model);
}
