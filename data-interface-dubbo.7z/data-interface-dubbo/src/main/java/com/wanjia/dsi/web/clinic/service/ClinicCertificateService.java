package com.wanjia.dsi.web.clinic.service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinic.model.ClinicCertificate;


public interface ClinicCertificateService {
	

	/**
	 * 根据clinicId获取认证相关信息
	 * @param clinicId
	 * @return
	 */
	JsonResponse<ClinicCertificate>  selectByClinicId(String clinicId);
	
}