package com.wanjia.dsi.web.atlas.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.clinic.model.Clinic;

public interface AtlasSearchService {
	/**
	 * 根据ip 查询诊所
	 * @author chenkang
	 * @since 2016年4月22日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param ip
	 * @param radius
	 * @param pageSize
	 * @return
	 * JsonResponse<List<Clinic>>
	 */
	public JsonResponse<List<Clinic>> findClinicListByIpAddr(String requestId,String ip,float radius,Integer pageSize);
	
	
	
	/***
	 * 根据经纬度，查询附近诊所
	 * @author chenkang
	 * @since 2016年4月22日
	 * @category TODO:
	 * @throws 无
	 * @param lat
	 * @param lon
	 * @param radius
	 * @param pageSize
	 * @return
	 * JsonResponse<List<Clinic>>
	 */
	public JsonResponse<List<Clinic>> findClinicListByLatAndLon(String lat,String lon,float radius,Integer pageSize);
	
	
}
