package com.wanjia.dsi.web.cms.appmanager.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.cms.appmanager.model.AppVersion;

public interface AppVersionService {
	/**
	 * @param appNameCode 必填  app类型：B,C,认证app; 
	 * @param releasePlatform 必填  发布平台： 2--android, 3--ios 1--网站；
	 * @return
	 */
	JsonResponse<AppVersion> getAppVersion(AppVersion appVersion);

}
