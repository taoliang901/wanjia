package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;
import java.util.Date;

public class ClinicYear implements Serializable {
	
	private static final long serialVersionUID = 1520398438047801594L;

	private Integer id;

    private String year;

    private String clinicId;

    private String clinicName;

    private Date registerDate;

    private Date rzDate;

    private Date yzsDate;

    private Date appDate;

    private Integer accessNum;

    private Date ctcEnteredDate;

    private Integer ctcVoteNum;

    private String ctcAwardDesc;

    private Date customerFirstBookingDate;

    private Date customerFirstTreatmentDate;

    private Integer bookingNum;

    private Integer yzsUseNum;

    private String delFlag;

    private Date createDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year == null ? null : year.trim();
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId == null ? null : clinicId.trim();
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName == null ? null : clinicName.trim();
    }

    public Date getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(Date registerDate) {
        this.registerDate = registerDate;
    }

    public Date getRzDate() {
        return rzDate;
    }

    public void setRzDate(Date rzDate) {
        this.rzDate = rzDate;
    }

    public Date getYzsDate() {
        return yzsDate;
    }

    public void setYzsDate(Date yzsDate) {
        this.yzsDate = yzsDate;
    }

    public Date getAppDate() {
        return appDate;
    }

    public void setAppDate(Date appDate) {
        this.appDate = appDate;
    }

    public Integer getAccessNum() {
        return accessNum;
    }

    public void setAccessNum(Integer accessNum) {
        this.accessNum = accessNum;
    }

    public Date getCtcEnteredDate() {
        return ctcEnteredDate;
    }

    public void setCtcEnteredDate(Date ctcEnteredDate) {
        this.ctcEnteredDate = ctcEnteredDate;
    }

    public Integer getCtcVoteNum() {
        return ctcVoteNum;
    }

    public void setCtcVoteNum(Integer ctcVoteNum) {
        this.ctcVoteNum = ctcVoteNum;
    }

    public String getCtcAwardDesc() {
        return ctcAwardDesc;
    }

    public void setCtcAwardDesc(String ctcAwardDesc) {
        this.ctcAwardDesc = ctcAwardDesc == null ? null : ctcAwardDesc.trim();
    }

    public Date getCustomerFirstBookingDate() {
        return customerFirstBookingDate;
    }

    public void setCustomerFirstBookingDate(Date customerFirstBookingDate) {
        this.customerFirstBookingDate = customerFirstBookingDate;
    }

    public Date getCustomerFirstTreatmentDate() {
        return customerFirstTreatmentDate;
    }

    public void setCustomerFirstTreatmentDate(Date customerFirstTreatmentDate) {
        this.customerFirstTreatmentDate = customerFirstTreatmentDate;
    }

    public Integer getBookingNum() {
        return bookingNum;
    }

    public void setBookingNum(Integer bookingNum) {
        this.bookingNum = bookingNum;
    }

    public Integer getYzsUseNum() {
        return yzsUseNum;
    }

    public void setYzsUseNum(Integer yzsUseNum) {
        this.yzsUseNum = yzsUseNum;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag == null ? null : delFlag.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}