package com.wanjia.dsi.web.clinic.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.clinic.model.ClinicInfoApproval;

public interface ClinicInfoApprovalMapper extends IBaseDao<ClinicInfoApproval,String> {
	
	public long countRegisterDoctorByClinicId(String Id);
	
	public ClinicInfoApproval getClinicApprovalByDoctorPK(Map<String,Object> map);
	
	public ClinicInfoApproval findClinicInfoById(String Id);
	
	public List<ClinicInfoApproval> findClinicByInspectionDate(Map<String, Object> map);
	
	public void updateForUnselective(ClinicInfoApproval clinicInfoApproval);
}