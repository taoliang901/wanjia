package com.wanjia.dsi.web.clinic.model.RG;

public class RGHttpRequestHead {
	private String method;			//接口编号
	private String serialNumber;	//请求唯一流水号
	private String version = "1.0";	//接口版本号
	private String tokenId;			//标识用户登录状态的令牌	
	private int appId = 9;	//接入应用id，固定值为1.0
	private String appSecret = "cf09a04d9fec676d0584aac2235c27b6";		//接入应用密码，固定值
	private String sourceCode = "pawj";	//请求来源
	
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getAppSecret() {
		return appSecret;
	}
	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}
	public String getSourceCode() {
		return sourceCode;
	}
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}
	
}
