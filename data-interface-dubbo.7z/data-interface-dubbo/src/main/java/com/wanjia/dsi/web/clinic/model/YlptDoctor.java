package com.wanjia.dsi.web.clinic.model;

public class YlptDoctor {

	private String role;		//角色
	private String isBindClinic;//是否绑定诊所  1、还没有绑定诊所 2、已经绑定自家连锁诊所下其他子诊所（不包括当前诊所），3、关联别家诊所,4、绑定当前诊所
	private YlptDoctorInfo ylptDoctorInfo;//医生信息
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getIsBindClinic() {
		return isBindClinic;
	}
	public void setIsBindClinic(String isBindClinic) {
		this.isBindClinic = isBindClinic;
	}
	public YlptDoctorInfo getYlptDoctorInfo() {
		return ylptDoctorInfo;
	}
	public void setYlptDoctorInfo(YlptDoctorInfo ylptDoctorInfo) {
		this.ylptDoctorInfo = ylptDoctorInfo;
	}
	
	
}
