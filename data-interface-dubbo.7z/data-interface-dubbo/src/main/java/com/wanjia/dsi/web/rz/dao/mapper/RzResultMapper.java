package com.wanjia.dsi.web.rz.dao.mapper;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.rz.model.RzResult;

public interface RzResultMapper extends IBaseDao<RzResult, String> {
	
}