package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;
import java.util.Date;

public class ClinicHeadquarters implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;

    private String clinicId;
    
    private String clinicRegisterId;

    private String enterpriseFullName;

    private String enterpriseLogoPath;

    private String legalRepresentative;

    private String enterpriseBankId;

    private String enterpriseBankBranchId;

    private String enterpriseAccountNo;

    private String isThreeMergeOne;

    private String enterpriseLicenseNo;

    private String enterpriseLicensePath;

    private String enterpriseBusinessNo;

    private String enterpriseBusinessPath;

    private String enterpriseOrganizationNo;

    private String enterpriseOrganizationPath;

    private String enterpriseTaxNo;

    private String enterpriseTaxPath;

    private String enterpriseOperationName;

    private String enterpriseOperationTel;

    private String enterpriseOperationNo;

    private String enterpriseOperationIda;

    private String enterpriseOperationIdb;

    private String checkStatus;

    private String checkReason;

    private Integer sequenceNum;

    private String createUser;

    private Date createDate;

    private String modifyUser;

    private Date modifyDate;

    private String delFlag;
    
    private Date beginDate; 

	private Date endDate;

	
    public String getClinicId() {
		return clinicId;
	}

	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClinicRegisterId() {
        return clinicRegisterId;
    }

    public void setClinicRegisterId(String clinicRegisterId) {
        this.clinicRegisterId = clinicRegisterId;
    }

    public String getEnterpriseFullName() {
        return enterpriseFullName;
    }

    public void setEnterpriseFullName(String enterpriseFullName) {
        this.enterpriseFullName = enterpriseFullName;
    }

    public String getEnterpriseLogoPath() {
        return enterpriseLogoPath;
    }

    public void setEnterpriseLogoPath(String enterpriseLogoPath) {
        this.enterpriseLogoPath = enterpriseLogoPath;
    }

    public String getLegalRepresentative() {
        return legalRepresentative;
    }

    public void setLegalRepresentative(String legalRepresentative) {
        this.legalRepresentative = legalRepresentative;
    }

    public String getEnterpriseBankId() {
        return enterpriseBankId;
    }

    public void setEnterpriseBankId(String enterpriseBankId) {
        this.enterpriseBankId = enterpriseBankId;
    }

    public String getEnterpriseBankBranchId() {
        return enterpriseBankBranchId;
    }

    public void setEnterpriseBankBranchId(String enterpriseBankBranchId) {
        this.enterpriseBankBranchId = enterpriseBankBranchId;
    }

    public String getEnterpriseAccountNo() {
        return enterpriseAccountNo;
    }

    public void setEnterpriseAccountNo(String enterpriseAccountNo) {
        this.enterpriseAccountNo = enterpriseAccountNo;
    }

    public String getIsThreeMergeOne() {
        return isThreeMergeOne;
    }

    public void setIsThreeMergeOne(String isThreeMergeOne) {
        this.isThreeMergeOne = isThreeMergeOne;
    }

    public String getEnterpriseLicenseNo() {
        return enterpriseLicenseNo;
    }

    public void setEnterpriseLicenseNo(String enterpriseLicenseNo) {
        this.enterpriseLicenseNo = enterpriseLicenseNo;
    }

    public String getEnterpriseLicensePath() {
        return enterpriseLicensePath;
    }

    public void setEnterpriseLicensePath(String enterpriseLicensePath) {
        this.enterpriseLicensePath = enterpriseLicensePath;
    }

    public String getEnterpriseBusinessNo() {
        return enterpriseBusinessNo;
    }

    public void setEnterpriseBusinessNo(String enterpriseBusinessNo) {
        this.enterpriseBusinessNo = enterpriseBusinessNo;
    }

    public String getEnterpriseBusinessPath() {
        return enterpriseBusinessPath;
    }

    public void setEnterpriseBusinessPath(String enterpriseBusinessPath) {
        this.enterpriseBusinessPath = enterpriseBusinessPath;
    }

    public String getEnterpriseOrganizationNo() {
        return enterpriseOrganizationNo;
    }

    public void setEnterpriseOrganizationNo(String enterpriseOrganizationNo) {
        this.enterpriseOrganizationNo = enterpriseOrganizationNo;
    }

    public String getEnterpriseOrganizationPath() {
        return enterpriseOrganizationPath;
    }

    public void setEnterpriseOrganizationPath(String enterpriseOrganizationPath) {
        this.enterpriseOrganizationPath = enterpriseOrganizationPath;
    }

    public String getEnterpriseTaxNo() {
        return enterpriseTaxNo;
    }

    public void setEnterpriseTaxNo(String enterpriseTaxNo) {
        this.enterpriseTaxNo = enterpriseTaxNo;
    }

    public String getEnterpriseTaxPath() {
        return enterpriseTaxPath;
    }

    public void setEnterpriseTaxPath(String enterpriseTaxPath) {
        this.enterpriseTaxPath = enterpriseTaxPath;
    }

    public String getEnterpriseOperationName() {
        return enterpriseOperationName;
    }

    public void setEnterpriseOperationName(String enterpriseOperationName) {
        this.enterpriseOperationName = enterpriseOperationName;
    }

    public String getEnterpriseOperationTel() {
        return enterpriseOperationTel;
    }

    public void setEnterpriseOperationTel(String enterpriseOperationTel) {
        this.enterpriseOperationTel = enterpriseOperationTel;
    }

    public String getEnterpriseOperationNo() {
        return enterpriseOperationNo;
    }

    public void setEnterpriseOperationNo(String enterpriseOperationNo) {
        this.enterpriseOperationNo = enterpriseOperationNo;
    }

    public String getEnterpriseOperationIda() {
        return enterpriseOperationIda;
    }

    public void setEnterpriseOperationIda(String enterpriseOperationIda) {
        this.enterpriseOperationIda = enterpriseOperationIda;
    }

    public String getEnterpriseOperationIdb() {
        return enterpriseOperationIdb;
    }

    public void setEnterpriseOperationIdb(String enterpriseOperationIdb) {
        this.enterpriseOperationIdb = enterpriseOperationIdb;
    }

    public String getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }

    public String getCheckReason() {
        return checkReason;
    }

    public void setCheckReason(String checkReason) {
        this.checkReason = checkReason;
    }

    public Integer getSequenceNum() {
        return sequenceNum;
    }

    public void setSequenceNum(Integer sequenceNum) {
        this.sequenceNum = sequenceNum;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        ClinicHeadquarters other = (ClinicHeadquarters) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getClinicRegisterId() == null ? other.getClinicRegisterId() == null : this.getClinicRegisterId().equals(other.getClinicRegisterId()))
            && (this.getEnterpriseFullName() == null ? other.getEnterpriseFullName() == null : this.getEnterpriseFullName().equals(other.getEnterpriseFullName()))
            && (this.getEnterpriseLogoPath() == null ? other.getEnterpriseLogoPath() == null : this.getEnterpriseLogoPath().equals(other.getEnterpriseLogoPath()))
            && (this.getLegalRepresentative() == null ? other.getLegalRepresentative() == null : this.getLegalRepresentative().equals(other.getLegalRepresentative()))
            && (this.getEnterpriseBankId() == null ? other.getEnterpriseBankId() == null : this.getEnterpriseBankId().equals(other.getEnterpriseBankId()))
            && (this.getEnterpriseBankBranchId() == null ? other.getEnterpriseBankBranchId() == null : this.getEnterpriseBankBranchId().equals(other.getEnterpriseBankBranchId()))
            && (this.getEnterpriseAccountNo() == null ? other.getEnterpriseAccountNo() == null : this.getEnterpriseAccountNo().equals(other.getEnterpriseAccountNo()))
            && (this.getIsThreeMergeOne() == null ? other.getIsThreeMergeOne() == null : this.getIsThreeMergeOne().equals(other.getIsThreeMergeOne()))
            && (this.getEnterpriseLicenseNo() == null ? other.getEnterpriseLicenseNo() == null : this.getEnterpriseLicenseNo().equals(other.getEnterpriseLicenseNo()))
            && (this.getEnterpriseLicensePath() == null ? other.getEnterpriseLicensePath() == null : this.getEnterpriseLicensePath().equals(other.getEnterpriseLicensePath()))
            && (this.getEnterpriseBusinessNo() == null ? other.getEnterpriseBusinessNo() == null : this.getEnterpriseBusinessNo().equals(other.getEnterpriseBusinessNo()))
            && (this.getEnterpriseBusinessPath() == null ? other.getEnterpriseBusinessPath() == null : this.getEnterpriseBusinessPath().equals(other.getEnterpriseBusinessPath()))
            && (this.getEnterpriseOrganizationNo() == null ? other.getEnterpriseOrganizationNo() == null : this.getEnterpriseOrganizationNo().equals(other.getEnterpriseOrganizationNo()))
            && (this.getEnterpriseOrganizationPath() == null ? other.getEnterpriseOrganizationPath() == null : this.getEnterpriseOrganizationPath().equals(other.getEnterpriseOrganizationPath()))
            && (this.getEnterpriseTaxNo() == null ? other.getEnterpriseTaxNo() == null : this.getEnterpriseTaxNo().equals(other.getEnterpriseTaxNo()))
            && (this.getEnterpriseTaxPath() == null ? other.getEnterpriseTaxPath() == null : this.getEnterpriseTaxPath().equals(other.getEnterpriseTaxPath()))
            && (this.getEnterpriseOperationName() == null ? other.getEnterpriseOperationName() == null : this.getEnterpriseOperationName().equals(other.getEnterpriseOperationName()))
            && (this.getEnterpriseOperationTel() == null ? other.getEnterpriseOperationTel() == null : this.getEnterpriseOperationTel().equals(other.getEnterpriseOperationTel()))
            && (this.getEnterpriseOperationNo() == null ? other.getEnterpriseOperationNo() == null : this.getEnterpriseOperationNo().equals(other.getEnterpriseOperationNo()))
            && (this.getEnterpriseOperationIda() == null ? other.getEnterpriseOperationIda() == null : this.getEnterpriseOperationIda().equals(other.getEnterpriseOperationIda()))
            && (this.getEnterpriseOperationIdb() == null ? other.getEnterpriseOperationIdb() == null : this.getEnterpriseOperationIdb().equals(other.getEnterpriseOperationIdb()))
            && (this.getCheckStatus() == null ? other.getCheckStatus() == null : this.getCheckStatus().equals(other.getCheckStatus()))
            && (this.getCheckReason() == null ? other.getCheckReason() == null : this.getCheckReason().equals(other.getCheckReason()))
            && (this.getSequenceNum() == null ? other.getSequenceNum() == null : this.getSequenceNum().equals(other.getSequenceNum()))
            && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser()))
            && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate()))
            && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser()))
            && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getClinicRegisterId() == null) ? 0 : getClinicRegisterId().hashCode());
        result = prime * result + ((getEnterpriseFullName() == null) ? 0 : getEnterpriseFullName().hashCode());
        result = prime * result + ((getEnterpriseLogoPath() == null) ? 0 : getEnterpriseLogoPath().hashCode());
        result = prime * result + ((getLegalRepresentative() == null) ? 0 : getLegalRepresentative().hashCode());
        result = prime * result + ((getEnterpriseBankId() == null) ? 0 : getEnterpriseBankId().hashCode());
        result = prime * result + ((getEnterpriseBankBranchId() == null) ? 0 : getEnterpriseBankBranchId().hashCode());
        result = prime * result + ((getEnterpriseAccountNo() == null) ? 0 : getEnterpriseAccountNo().hashCode());
        result = prime * result + ((getIsThreeMergeOne() == null) ? 0 : getIsThreeMergeOne().hashCode());
        result = prime * result + ((getEnterpriseLicenseNo() == null) ? 0 : getEnterpriseLicenseNo().hashCode());
        result = prime * result + ((getEnterpriseLicensePath() == null) ? 0 : getEnterpriseLicensePath().hashCode());
        result = prime * result + ((getEnterpriseBusinessNo() == null) ? 0 : getEnterpriseBusinessNo().hashCode());
        result = prime * result + ((getEnterpriseBusinessPath() == null) ? 0 : getEnterpriseBusinessPath().hashCode());
        result = prime * result + ((getEnterpriseOrganizationNo() == null) ? 0 : getEnterpriseOrganizationNo().hashCode());
        result = prime * result + ((getEnterpriseOrganizationPath() == null) ? 0 : getEnterpriseOrganizationPath().hashCode());
        result = prime * result + ((getEnterpriseTaxNo() == null) ? 0 : getEnterpriseTaxNo().hashCode());
        result = prime * result + ((getEnterpriseTaxPath() == null) ? 0 : getEnterpriseTaxPath().hashCode());
        result = prime * result + ((getEnterpriseOperationName() == null) ? 0 : getEnterpriseOperationName().hashCode());
        result = prime * result + ((getEnterpriseOperationTel() == null) ? 0 : getEnterpriseOperationTel().hashCode());
        result = prime * result + ((getEnterpriseOperationNo() == null) ? 0 : getEnterpriseOperationNo().hashCode());
        result = prime * result + ((getEnterpriseOperationIda() == null) ? 0 : getEnterpriseOperationIda().hashCode());
        result = prime * result + ((getEnterpriseOperationIdb() == null) ? 0 : getEnterpriseOperationIdb().hashCode());
        result = prime * result + ((getCheckStatus() == null) ? 0 : getCheckStatus().hashCode());
        result = prime * result + ((getCheckReason() == null) ? 0 : getCheckReason().hashCode());
        result = prime * result + ((getSequenceNum() == null) ? 0 : getSequenceNum().hashCode());
        result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
        result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
        result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
        result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        return result;
    }
}