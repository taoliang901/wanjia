package com.wanjia.dsi.web.rz.model;

public class RzResultModel extends RzResult {

	private static final long serialVersionUID = 3231853089673554386L;

	// 诊所名称
	private String clinicName;
	// 诊所城市
	private String cityName;
	// 诊所地址
	private String address;
	// 认证标准
	private String templateName;
	// 认证人员名称
	private String rzUserName;
	// 审核人员名称
	private String auditUserName;

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getRzUserName() {
		return rzUserName;
	}

	public void setRzUserName(String rzUserName) {
		this.rzUserName = rzUserName;
	}

	public String getAuditUserName() {
		return auditUserName;
	}

	public void setAuditUserName(String auditUserName) {
		this.auditUserName = auditUserName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}