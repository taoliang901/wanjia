package com.wanjia.dsi.web.hyPerson.vo;

import java.io.Serializable;

// 用于更换手机号参数传递
public class HyChangeMobileVO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4302236721502513475L;

	// 用户ID
	private String id;
	
	// 更换手机号方式（0：密码验证。1：手机号验证码验证）
	private String changeWay;
	
	// 原手机号
	private String mobileBefore;
	
	// 原手机号验证码
	private String checkNumBefore;
	
	// 原手机号UUID KEY
	private String uuidBefore;
	
	// 新手机号
	private String mobileAfter;
	
	// 新手机号验证码
	private String checkNumAfter;
	
	// 新手机号UUID KEY
	private String uuidAfter;
	
	// 密码
	private String password;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getChangeWay() {
		return changeWay;
	}

	public void setChangeWay(String changeWay) {
		this.changeWay = changeWay;
	}

	public String getMobileBefore() {
		return mobileBefore;
	}

	public void setMobileBefore(String mobileBefore) {
		this.mobileBefore = mobileBefore;
	}

	public String getCheckNumBefore() {
		return checkNumBefore;
	}

	public void setCheckNumBefore(String checkNumBefore) {
		this.checkNumBefore = checkNumBefore;
	}

	public String getUuidBefore() {
		return uuidBefore;
	}

	public void setUuidBefore(String uuidBefore) {
		this.uuidBefore = uuidBefore;
	}

	public String getMobileAfter() {
		return mobileAfter;
	}

	public void setMobileAfter(String mobileAfter) {
		this.mobileAfter = mobileAfter;
	}

	public String getCheckNumAfter() {
		return checkNumAfter;
	}

	public void setCheckNumAfter(String checkNumAfter) {
		this.checkNumAfter = checkNumAfter;
	}

	public String getUuidAfter() {
		return uuidAfter;
	}

	public void setUuidAfter(String uuidAfter) {
		this.uuidAfter = uuidAfter;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
