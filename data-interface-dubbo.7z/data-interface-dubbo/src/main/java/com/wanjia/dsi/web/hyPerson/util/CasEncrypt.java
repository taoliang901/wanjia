package com.wanjia.dsi.web.hyPerson.util;

/**
 * CAS系统加密方式
 * 
 * @author LUOXIAOJUN640
 *
 */
public enum CasEncrypt {

	NONE("1", "不加密"), MD5("2", "MD5加密");

	private String code;
	private String value;

//	public static CasEncrypt getInstance(String code) {
//		CasEncrypt encrypt  = null;
//
//		if (code != null) {
//			CasEncrypt[] list = CasEncrypt.values();
//			for (CasEncrypt key : list) {
//				if (key.getCode().equals(code)) {
//					encrypt = key;
//					break;
//				}
//			}
//		}
//
//		return encrypt;
//	}

	private CasEncrypt(String code, String value) {
		this.code = code;
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
