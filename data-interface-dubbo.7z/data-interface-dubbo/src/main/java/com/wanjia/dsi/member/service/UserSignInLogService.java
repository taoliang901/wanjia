package com.wanjia.dsi.member.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.common.query.Page;
import com.wanjia.dsi.member.model.UserSignInLog;
import com.wanjia.dsi.member.model.UserSignInLogReq;
import com.wanjia.dsi.member.util.UserSignInSource;
import com.wanjia.dsi.member.util.UserSignInType;

/**
 * 用户签到数据接口
 * 
 * @author LUOXIAOJUN640
 *
 */
public interface UserSignInLogService {

	/**
	 * 插入签到日志
	 * 
	 * @param userId：签到的用户ID(CAS_UUID)
	 * @param signType：签到类型
	 * @param source：签到来源
	 * @return status：为JsonResponse.Status.SUCCESS时表示成功， result为获取的UserSignInLog对象
	 *         status：不为 JsonResponse.Status.SUCCESS时，result为获取null
	 */
	JsonResponse<UserSignInLog> insert(String userId, UserSignInType signType, UserSignInSource source);

	// 获取用户签到日志列表
	List<UserSignInLog> getList(UserSignInLogReq req, Integer limit);

	// 获取用户签到日志列表(分页)
	Page<UserSignInLog> getPage(UserSignInLogReq req, int pageSize, int pageNo);

	// 获取总的签到天数
	int getTotalDaysByUserId(String userId, String signInType);

}
