package com.wanjia.dsi.web.hyPerson.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.HyUser;
import com.wanjia.dsi.web.hyPerson.vo.HyUserVO;

/**
 * 会员用户相关Service
 */
public interface HyUserService {

	/**
	 * 根据用户名（即手机号）查询对应的用户信息
	 */
	JsonResponse<HyUserVO> getUserByLoginName(String loginName, String partnerid);

	/**
	 * 根据在redis中缓存的【AppTGT】来进行登陆（APP专用）
	 */
	JsonResponse<HyUserVO> loginWithAppTGT(String tgt);

	/**
	 * 根据会员ID list 查询会员信息，返回字段如下：
	 * 
	 * id				会员ID（数字）
	 * casUuid			casUUID（36位）
	 * loginName		用户登陆名（非空）
	 * realName			昵称（可空）
	 * docName			医生姓名（可空）
	 * mobile			手机号（可空）
	 * personalImageAll	会员头像（可空）
	 */
	JsonResponse<List<HyUserVO>> getUserListByHyids(List<String> hyids);
	
	
	/**
	 * 根据会员id获取hyuser
	 * @param userId
	 * @return
	 */
	JsonResponse<HyUserVO> getUserByUserId(String userId);
	
	JsonResponse<HyUser> getHyUser(HyUser param);
}
