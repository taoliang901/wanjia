package com.wanjia.dsi.web.hyPerson.service.doctor;

import java.util.List;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.HyClinicDoctorExperiences;

/**
 * 医生经历相关Service
 */
public interface HyDoctorExperiencesService  {
	/**
	 * 查询医生经历信息
	 * @param String doctorId 医生ID
	 * @param String experienceType 经历类型(0:学习经历,1:工作经历,2:获奖经历)
	 * @return HyUser HyUser 返回会员用户信息(用户名，密码)
	 */
	JsonResponse<List<HyClinicDoctorExperiences>> queryDoctorExp(String doctorId, String experienceType);
}
