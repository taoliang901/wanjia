package com.wanjia.dsi.web.hyPerson.service;

/**
 * 
 * 简单密码词库相关接口
 * 
 * @author LUOXIAOJUN640
 *
 */
public interface CasSimplePwdService {

	/**
	 * 简单密码词库中，是否包含此简单密码
	 * 
	 * @return
	 */
	boolean contains(String pwdType, String pwd, boolean isMd5);
}
