package com.wanjia.dsi.web.college.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.college.model.Course;
public interface CourseService {

	
	public JsonResponse<List<Course>> getCourseList(Course course) ;
	
	
}
