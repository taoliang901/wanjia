package com.wanjia.dsi.web.college.service;

import java.util.List;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.college.model.CeCourseType;

public interface CeCourseTypeService {
	/**
	 * 查询所有未删除的CeCourseType
	 * 
	 * @return
	 */
	public JsonResponse<List<CeCourseType>> findAllCeCourseType();

	/**
	 * 查询pageSize数目的cecoursetype，必须传一个正整数
	 * 
	 * @param pageSize
	 * @return
	 */
	public JsonResponse<List<CeCourseType>> findAllCeCourseType(int pageSize);
}
