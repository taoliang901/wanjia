package com.wanjia.dsi.web.college.service;

import com.github.pagehelper.PageInfo;
import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.college.model.CeCourseReleased;

public interface CeCourseReleasedService {



	/**
	 * 根据类型查询全部已经发布的课程
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param typeId
	 * @return
	 */
	public JsonResponse<PageInfo<CeCourseReleased>> findAllCeCourseReleasedByType(int pageNo, int pageSize, int typeId);

	/**
	 * 查询课程详情接口，
	 * 
	 * @param course_id
	 * @return
	 */
	public JsonResponse<CeCourseReleased> findCeCourseReleasedByCourseId(String course_id);

}
