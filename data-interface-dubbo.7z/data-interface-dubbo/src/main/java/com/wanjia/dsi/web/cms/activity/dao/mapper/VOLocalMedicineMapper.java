package com.wanjia.dsi.web.cms.activity.dao.mapper;

import com.wanjia.dsi.web.cms.activity.model.LocalMedicine;
import com.wanjia.dsi.web.cms.activity.model.VOLocalMedicine;

import java.util.List;

public interface VOLocalMedicineMapper {

    List<LocalMedicine> getLocalMedicine(List<String> infoIdList);
    
    public List<String> getAllMedicineId(VOLocalMedicine volocalMedicine);

}