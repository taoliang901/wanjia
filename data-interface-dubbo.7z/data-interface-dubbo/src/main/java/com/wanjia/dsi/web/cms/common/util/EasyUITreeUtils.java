package com.wanjia.dsi.web.cms.common.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.wanjia.dsi.web.cms.common.entity.ClinicDepartment;
import com.wanjia.dsi.web.cms.common.entity.ClinicDepartmentTree;
import com.wanjia.dsi.web.cms.common.entity.EasyUITreeDataModelBase;



public class EasyUITreeUtils {

	
	/**
	 * 根据Java类的树形结构 转换成EasyUI的树形结构
	 * @param easyUITreeModel
	 * @param treeId
	 * @param treeText
	 * @param list
	 * @return
	 */
	public static List<EasyUITreeDataModelBase<ClinicDepartment>> createCmsDptEasyUITree(String treeId,String treeText,
				List<ClinicDepartmentTree> list){
		List<EasyUITreeDataModelBase<ClinicDepartment>> 
		eyTreeList = new ArrayList<EasyUITreeDataModelBase<ClinicDepartment>>();
		for(Iterator<ClinicDepartmentTree> it =  list.iterator();it.hasNext();){
			//子项
			ClinicDepartmentTree dptTree = it.next();
			List<ClinicDepartmentTree> subitemList = dptTree.getSubitemList();
			//转换
			EasyUITreeDataModelBase<ClinicDepartment> subitemModel 
			= new EasyUITreeDataModelBase<ClinicDepartment>(dptTree.getDepartmentId(),dptTree.getDepartmentName());
			subitemModel.setAttributes(dptTree.getClinicDepartment());
			if(null != subitemList && subitemList.size()>0){
				subitemModel.setChildren(createCmsDptEasyUITree(dptTree.getDepartmentId(),
						dptTree.getDepartmentName(),dptTree.getSubitemList()));
			} 
			eyTreeList.add(subitemModel);
		}
		return eyTreeList;
	}
}
