package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.hyPerson.vo.VOClcInfoApproval;

public interface VOClcInfoApprovalMapper {

    VOClcInfoApproval selectByPrimaryKey(String pk);

    List<VOClcInfoApproval> selectByMap(Map<String, Object> param);

}