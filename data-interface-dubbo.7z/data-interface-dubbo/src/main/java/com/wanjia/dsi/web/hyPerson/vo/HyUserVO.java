package com.wanjia.dsi.web.hyPerson.vo;

import com.wanjia.dsi.web.hyPerson.model.HyUser;

public class HyUserVO extends HyUser {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 348038851176543516L;
	/** 登陆用户名 */
	private String loginName;
	/** 手机号 */
    private String mobile;
	/** 昵称 */
	private String realName;
	/** 密码 */
    private String password;
	/** userRoles */
	private String userRoles;
	/** 医生姓名 */
	private String doctorName;
	/** 医生头像 */
	private String doctorPhoto;
	/** 会员头像 */
	private String personalImage;
	/** 会员头像（全路径） */
	private String personalImageAll;

	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getUserRoles() {
		return userRoles;
	}
	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPersonalImage() {
		return personalImage;
	}
	public void setPersonalImage(String personalImage) {
		this.personalImage = personalImage;
	}
	public String getPersonalImageAll() {
		return personalImageAll;
	}
	public void setPersonalImageAll(String personalImageAll) {
		this.personalImageAll = personalImageAll;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDoctorPhoto() {
		return doctorPhoto;
	}
	public void setDoctorPhoto(String doctorPhoto) {
		this.doctorPhoto = doctorPhoto;
	}
}
