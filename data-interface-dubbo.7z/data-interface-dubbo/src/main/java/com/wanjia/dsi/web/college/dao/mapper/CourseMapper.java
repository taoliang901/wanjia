package com.wanjia.dsi.web.college.dao.mapper;

import java.util.List;

import com.wanjia.dsi.web.college.model.Course;

public interface CourseMapper {

	List<Course> getCourseList(Course course);

}