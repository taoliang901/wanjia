package com.wanjia.dsi.web.callCenter.model;

import java.io.Serializable;
import java.util.Date;

public class CcSurvey implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;

    private String surveySequence;

    private String surveyName;

    private String surveyType;

    private String surveyStatus;

    private String overtimeFlag;
    
    private String healthOvertimeFlag;
    
    private Date createDate;

    private String createUser;

    private Date modifyDate;

    private String modifyUser;

    private String delFlag;
    
    private String prdTypeId;
    
    private String issueType;
    
    

    

    public String getPrdTypeId() {
		return prdTypeId;
	}

	public void setPrdTypeId(String prdTypeId) {
		this.prdTypeId = prdTypeId;
	}

	public String getIssueType() {
		return issueType;
	}

	public void setIssueType(String issueType) {
		this.issueType = issueType;
	}

	public String getHealthOvertimeFlag() {
		return healthOvertimeFlag;
	}

	public void setHealthOvertimeFlag(String healthOvertimeFlag) {
		this.healthOvertimeFlag = healthOvertimeFlag;
	}

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSurveySequence() {
        return surveySequence;
    }

    public void setSurveySequence(String surveySequence) {
        this.surveySequence = surveySequence;
    }

    public String getSurveyName() {
        return surveyName;
    }

    public void setSurveyName(String surveyName) {
        this.surveyName = surveyName;
    }

    public String getSurveyType() {
        return surveyType;
    }

    public void setSurveyType(String surveyType) {
        this.surveyType = surveyType;
    }

    public String getSurveyStatus() {
        return surveyStatus;
    }

    public void setSurveyStatus(String surveyStatus) {
        this.surveyStatus = surveyStatus;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }
    
    
	public String getOvertimeFlag() {
		return overtimeFlag;
	}

	public void setOvertimeFlag(String overtimeFlag) {
		this.overtimeFlag = overtimeFlag;
	}

	@Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        CcSurvey other = (CcSurvey) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getSurveySequence() == null ? other.getSurveySequence() == null : this.getSurveySequence().equals(other.getSurveySequence()))
            && (this.getSurveyName() == null ? other.getSurveyName() == null : this.getSurveyName().equals(other.getSurveyName()))
            && (this.getSurveyType() == null ? other.getSurveyType() == null : this.getSurveyType().equals(other.getSurveyType()))
            && (this.getSurveyStatus() == null ? other.getSurveyStatus() == null : this.getSurveyStatus().equals(other.getSurveyStatus()))
            && (this.getCreateDate() == null ? other.getCreateDate() == null : this.getCreateDate().equals(other.getCreateDate()))
            && (this.getCreateUser() == null ? other.getCreateUser() == null : this.getCreateUser().equals(other.getCreateUser()))
            && (this.getModifyDate() == null ? other.getModifyDate() == null : this.getModifyDate().equals(other.getModifyDate()))
            && (this.getModifyUser() == null ? other.getModifyUser() == null : this.getModifyUser().equals(other.getModifyUser()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getSurveySequence() == null) ? 0 : getSurveySequence().hashCode());
        result = prime * result + ((getSurveyName() == null) ? 0 : getSurveyName().hashCode());
        result = prime * result + ((getSurveyType() == null) ? 0 : getSurveyType().hashCode());
        result = prime * result + ((getSurveyStatus() == null) ? 0 : getSurveyStatus().hashCode());
        result = prime * result + ((getCreateDate() == null) ? 0 : getCreateDate().hashCode());
        result = prime * result + ((getCreateUser() == null) ? 0 : getCreateUser().hashCode());
        result = prime * result + ((getModifyDate() == null) ? 0 : getModifyDate().hashCode());
        result = prime * result + ((getModifyUser() == null) ? 0 : getModifyUser().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        return result;
    }
}