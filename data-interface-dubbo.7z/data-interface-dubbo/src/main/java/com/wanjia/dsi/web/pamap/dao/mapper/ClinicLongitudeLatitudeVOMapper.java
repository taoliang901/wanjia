package com.wanjia.dsi.web.pamap.dao.mapper;

import java.util.List;

import com.wanjia.dsi.web.pamap.model.ClinicLongitudeLatitudeVO;

// 查询注册信息
public interface ClinicLongitudeLatitudeVOMapper {
	
	/**
	 * 查询诊所信息和经纬度
	 * 
	 * @param String nowDate 当日日期
	 * @return
	 */
	public List<ClinicLongitudeLatitudeVO> getClinicLongitudeLatitudeList(String nowDate);
}