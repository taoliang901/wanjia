package com.wanjia.dsi.web.sms.dao.mapper;

import java.util.Collection;
import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.sms.model.HtUser;

public interface SmsHtUserMapper extends IBaseDao {
	
	public HtUser findByMobileAndPassWord(HtUser htuser);
	
	public List<HtUser> searchHtUserListByid(Collection ids);
}

