package com.wanjia.dsi.web.job.model;

import java.io.Serializable;

public class JobSearch extends TalentJobWithBLOBs implements Serializable {
	
	private static final long serialVersionUID = -7537471612561928741L;

	private String[] areaIdStrs;
    
	private String clinicName;
	private String clinicProvice;
	private String clinicCity;
	private String clinicArea;
	private String clinicAddress;
	private String clinicPhone;
	private String clinicMobile;
	
	private String clinicProperty;
	private String clinicPropertyName;
	
	private String experienceName;
	private String educationName;
	
	private String sorts;
	private String sou;
	
	private String pageSize;
	private String pageNo;
	
	public String getClinicName() {
		return clinicName;
	}
	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}
	public String getClinicProvice() {
		return clinicProvice;
	}
	public void setClinicProvice(String clinicProvice) {
		this.clinicProvice = clinicProvice;
	}
	public String getClinicCity() {
		return clinicCity;
	}
	public void setClinicCity(String clinicCity) {
		this.clinicCity = clinicCity;
	}
	public String getClinicArea() {
		return clinicArea;
	}
	public void setClinicArea(String clinicArea) {
		this.clinicArea = clinicArea;
	}
	public String getClinicAddress() {
		return clinicAddress;
	}
	public void setClinicAddress(String clinicAddress) {
		this.clinicAddress = clinicAddress;
	}
	public String getClinicPhone() {
		return clinicPhone;
	}
	public void setClinicPhone(String clinicPhone) {
		this.clinicPhone = clinicPhone;
	}
	public String getClinicMobile() {
		return clinicMobile;
	}
	public String[] getAreaIdStrs() {
		return areaIdStrs;
	}
	public void setAreaIdStrs(String[] areaIdStrs) {
		this.areaIdStrs = areaIdStrs;
	}
	public void setClinicMobile(String clinicMobile) {
		this.clinicMobile = clinicMobile;
	}
	public String getExperienceName() {
		return experienceName;
	}
	public void setExperienceName(String experienceName) {
		this.experienceName = experienceName;
	}
	public String getEducationName() {
		return educationName;
	}
	public void setEducationName(String educationName) {
		this.educationName = educationName;
	}
	public String getSou() {
		return sou;
	}
	public void setSou(String sou) {
		this.sou = sou;
	}
	public String getPageSize() {
		return pageSize;
	}
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}
	public String getPageNo() {
		return pageNo;
	}
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}
	public String getClinicProperty() {
		return clinicProperty;
	}
	public void setClinicProperty(String clinicProperty) {
		this.clinicProperty = clinicProperty;
	}
	public String getSorts() {
		return sorts;
	}
	public void setSorts(String sorts) {
		this.sorts = sorts;
	}
	public String getClinicPropertyName() {
		return clinicPropertyName;
	}
	public void setClinicPropertyName(String clinicPropertyName) {
		this.clinicPropertyName = clinicPropertyName;
	}
	
	
}