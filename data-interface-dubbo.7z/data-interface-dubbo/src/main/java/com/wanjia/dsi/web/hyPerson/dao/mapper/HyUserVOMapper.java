package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.hyPerson.vo.HyUserVO;

public interface HyUserVOMapper {

    HyUserVO selectByPrimaryKey(String pk);

    List<HyUserVO> selectByMap(Map<String, Object> param);

}