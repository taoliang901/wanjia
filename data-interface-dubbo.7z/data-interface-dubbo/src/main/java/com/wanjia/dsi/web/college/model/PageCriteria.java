package com.wanjia.dsi.web.college.model;

/**
 * 分页参数
 * @author XIONGXING
 *
 */
public class PageCriteria {

	private int pageNo=1;
	private int pageSize=10;
	
	public PageCriteria(){}
	
	public PageCriteria(int pageNo,int pageSize){
		this.pageNo = pageNo;
		this.pageSize = pageSize;
	}
	
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
