package com.wanjia.dsi.web.hyPerson.dao.mapper;

import java.util.List;

import com.wanjia.dsi.web.hyPerson.model.ClinicDoctor;

public interface ClinicDoctorVOMapper {

	/**
	 * 根据手机号查询ClinicDoctor信息
	 *
	 */
	List<ClinicDoctor> findByMobile(String mobile);
}