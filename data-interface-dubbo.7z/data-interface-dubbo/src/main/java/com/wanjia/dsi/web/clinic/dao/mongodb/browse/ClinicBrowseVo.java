package com.wanjia.dsi.web.clinic.dao.mongodb.browse;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.wanjia.dsi.web.clinic.model.Clinic;
import com.wanjia.dsi.web.doctor.model.Doctor;


public class ClinicBrowseVo extends ClinicBrowse implements Serializable {
	
    
	private String imageRoot;
    
    public ClinicBrowseVo() {
		// TODO Auto-generated constructor stub
	}

	public String getImageRoot() {
		return imageRoot;
	}

	public void setImageRoot(String imageRoot) {
		this.imageRoot = imageRoot;
	}


    
	
	
	
	
	
	
	

}