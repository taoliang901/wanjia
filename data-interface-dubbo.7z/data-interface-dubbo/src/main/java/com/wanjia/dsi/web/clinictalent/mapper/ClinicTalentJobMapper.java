package com.wanjia.dsi.web.clinictalent.mapper;

import java.util.List;
import java.util.Map;

import com.wanjia.dsi.web.clinictalent.model.TalentJobSearchApp;
import com.wanjia.dsi.web.job.model.TalentJob;
import com.wanjia.dsi.web.job.model.TalentJobWithBLOBs;



public interface ClinicTalentJobMapper {

	/**
	 * 
	 * @param conditions
	 * @return
	 */
	 List<TalentJobSearchApp> getTalentJobList(Map<String,Object> conditions);
	 
	 /**
	  * 
	  * @param key
	  * @return
	  */
	 TalentJobWithBLOBs selectByPrimaryKey(String key);
	 
	/**
	 * 
	 * @param talentJob
	 */
	void updateTalentJobByPrimaryKeySelective(TalentJobWithBLOBs talentJob);

	/**
	 * 
	 */
	void updateTalentJobByPrimaryKey(TalentJobWithBLOBs talentJob);

	List<TalentJobWithBLOBs> getTalentJobListByClinicId(Map<String, String> conditions);
}
