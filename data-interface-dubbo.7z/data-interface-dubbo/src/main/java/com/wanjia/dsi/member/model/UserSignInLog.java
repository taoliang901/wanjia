package com.wanjia.dsi.member.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 用户签到日志
 * 
 * @author LUOXIAOJUN640
 *
 */
@Document(collection = "userSignInLog")
public class UserSignInLog implements Serializable {
	private static final long serialVersionUID = -58823618722559973L;

	@Id
	private String id;

	// 用户ID，T_CAS_USER表ID
	@Indexed(name = "_userId_")
	private String userId;

	// 用户签到类型，关联UserSignInType
	@Indexed(name = "_signInType_")
	private String signInType;

	// 签到描述
	private String signInTypeDesc;

	// 签到日期（精确到天）
	private String signInDay;

	// 签到日期（精确到秒）
	private String signInDate;

	// 用户ID的HASH,并对HASH的值1024取模
	private int hash1024;

	// 签到来源(M:m站)
	private String source;

	// 签到来源描述
	private String sourceDesc;

	public String getId() {
		return id;
	}

	public String getUserId() {
		return userId;
	}

	public String getSignInType() {
		return signInType;
	}

	public String getSignInTypeDesc() {
		return signInTypeDesc;
	}

	public String getSignInDay() {
		return signInDay;
	}

	public String getSignInDate() {
		return signInDate;
	}

	public int getHash1024() {
		return hash1024;
	}

	public String getSource() {
		return source;
	}

	public String getSourceDesc() {
		return sourceDesc;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setSignInType(String signInType) {
		this.signInType = signInType;
	}

	public void setSignInTypeDesc(String signInTypeDesc) {
		this.signInTypeDesc = signInTypeDesc;
	}

	public void setSignInDay(String signInDay) {
		this.signInDay = signInDay;
	}

	public void setSignInDate(String signInDate) {
		this.signInDate = signInDate;
	}

	public void setHash1024(int hash1024) {
		this.hash1024 = hash1024;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setSourceDesc(String sourceDesc) {
		this.sourceDesc = sourceDesc;
	}

}