package com.wanjia.dsi.web.cms.activity.dao.mapper;

import java.util.List;

import com.wanjia.dsi.base.dao.IBaseDao;
import com.wanjia.dsi.web.activity.model.Activity;
import com.wanjia.dsi.web.activity.model.VOActivity;



public interface VOActivityMapper extends IBaseDao {
	
	
	public List<Activity> getActivity(List<String> infoIdList);

	public List<String> getAllActivityId(VOActivity voActivity);
	
}