package com.wanjia.dsi.web.dictionary.service;

import java.util.List;
import java.util.Map;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.base.service.IBaseService;
import com.wanjia.dsi.web.dictionary.model.Dictionary;
import com.wanjia.dsi.web.dictionary.model.Element;
import com.wanjia.dsi.web.dictionary.model.ElementResult;

/**
 * This element is automatically generated on 16-3-2 下午1:29, do not modify. <br>
 * Service interface
 */
public interface DictionaryService extends IBaseService<Dictionary, String> {

	/***
	 * 获取多个字典列表
	 * 
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param dictCode 字典码
	 * @return JsonResponse<Map<String,Object>>
	 */
	public JsonResponse<Map<String, Object>> getDictionaryList(String requestId, String dictCode);

	public JsonResponse<Boolean> updateRedis(String requestId, String dictCode);
	/***
	 * app 获取字典列表
	 * 
	 * @author chenkang
	 * @since 2016年4月25日
	 * @category TODO:
	 * @throws 无
	 * @param requestId
	 * @param dictCode
	 * @return JsonResponse<Map<String,Object>>
	 */
	JsonResponse<List<ElementResult>> getDictInfo();

}