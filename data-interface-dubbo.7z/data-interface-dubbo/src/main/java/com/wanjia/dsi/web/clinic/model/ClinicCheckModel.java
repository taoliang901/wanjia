package com.wanjia.dsi.web.clinic.model;

import java.util.List;

public class ClinicCheckModel {
	/*--start clinicInfo*/
    private String id;

    private String clinicRegisterId;

    private String clinicName;

//    private String clinicLogoPath;

//    private String bankId;

//    private String bankBranchId;

//    private String accountNo;

//    private String isMedicalInsurance;

//    private String mobile;

//    private String phone;

    private String openingTime;

    private String clinicTypeProperty;

    private String clinicTypeDepartments;

    private String diagnosisTypeCode1;

    private String diagnosisType1;

    private String diagnosisTypeCode2;

    private String diagnosisType2;

//    private String diagnosisItem;

    private String clinicIntroduce;

    private String businessLicenseNo;

    private String businessLicensePath;

    private String practicingLicenseNo;

    private String practicingLicensePath;

    private String practicingLicenseFPath;

    private String practicingLicenseF2Path;

    private String practicingLicenseF3Path;
    
    private String organizationNo;

    private String organizationPath;

    private String taxRegistrationNo;

    private String taxRegistrationPath;

    private String civilAffairsFiling;

    private String civilAffairsPath;

    private String radiationDiagnosisNo;

    private String radiationDiagnosisPath;

    private String radiationSaftyNo;

    private String radiationSaftyPath;

    private String legalRepresentativeNo;

    private String legalRepresentativeIda;

    private String legalRepresentativeIdb;

    private String administratorName;

//    private String administratorTel;

    private String administratorIda;

    private String administratorIdb;

//    private String authorizeMagPath;

    private String clinicPhotoPath;

    private String clinicFacadeName;

    private String clinicWaitingName;

    private String clinicMedLabName;

    private String clinicOtherName;

    private String specialTechnology;

    /*--end clinicInfo*/
    
    /*--start addressInfo--*/
    private String foreignId;

    private String foreignType;

    private String province;

    private String provinceCode;

    private String city;

    private String cityCode;

    private String district;

    private String districtCode;

    private String address;

    /*--end addressInfo--*/
    
    /*--start hardware--*/
    private List<Hadware> hadwareList;
    /*--end hardware--*/

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClinicRegisterId() {
		return clinicRegisterId;
	}

	public void setClinicRegisterId(String clinicRegisterId) {
		this.clinicRegisterId = clinicRegisterId;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getOpeningTime() {
		return openingTime;
	}

	public void setOpeningTime(String openingTime) {
		this.openingTime = openingTime;
	}

	public String getClinicTypeProperty() {
		return clinicTypeProperty;
	}

	public void setClinicTypeProperty(String clinicTypeProperty) {
		this.clinicTypeProperty = clinicTypeProperty;
	}

	public String getClinicTypeDepartments() {
		return clinicTypeDepartments;
	}

	public void setClinicTypeDepartments(String clinicTypeDepartments) {
		this.clinicTypeDepartments = clinicTypeDepartments;
	}

	public String getDiagnosisTypeCode1() {
		return diagnosisTypeCode1;
	}

	public void setDiagnosisTypeCode1(String diagnosisTypeCode1) {
		this.diagnosisTypeCode1 = diagnosisTypeCode1;
	}

	public String getDiagnosisType1() {
		return diagnosisType1;
	}

	public void setDiagnosisType1(String diagnosisType1) {
		this.diagnosisType1 = diagnosisType1;
	}

	public String getDiagnosisTypeCode2() {
		return diagnosisTypeCode2;
	}

	public void setDiagnosisTypeCode2(String diagnosisTypeCode2) {
		this.diagnosisTypeCode2 = diagnosisTypeCode2;
	}

	public String getDiagnosisType2() {
		return diagnosisType2;
	}

	public void setDiagnosisType2(String diagnosisType2) {
		this.diagnosisType2 = diagnosisType2;
	}

	public String getClinicIntroduce() {
		return clinicIntroduce;
	}

	public void setClinicIntroduce(String clinicIntroduce) {
		this.clinicIntroduce = clinicIntroduce;
	}

	public String getBusinessLicenseNo() {
		return businessLicenseNo;
	}

	public void setBusinessLicenseNo(String businessLicenseNo) {
		this.businessLicenseNo = businessLicenseNo;
	}

	public String getBusinessLicensePath() {
		return businessLicensePath;
	}

	public void setBusinessLicensePath(String businessLicensePath) {
		this.businessLicensePath = businessLicensePath;
	}

	public String getPracticingLicenseNo() {
		return practicingLicenseNo;
	}

	public void setPracticingLicenseNo(String practicingLicenseNo) {
		this.practicingLicenseNo = practicingLicenseNo;
	}

	public String getPracticingLicensePath() {
		return practicingLicensePath;
	}

	public void setPracticingLicensePath(String practicingLicensePath) {
		this.practicingLicensePath = practicingLicensePath;
	}

	public String getPracticingLicenseFPath() {
		return practicingLicenseFPath;
	}

	public void setPracticingLicenseFPath(String practicingLicenseFPath) {
		this.practicingLicenseFPath = practicingLicenseFPath;
	}

	public String getPracticingLicenseF2Path() {
		return practicingLicenseF2Path;
	}

	public void setPracticingLicenseF2Path(String practicingLicenseF2Path) {
		this.practicingLicenseF2Path = practicingLicenseF2Path;
	}

	public String getOrganizationNo() {
		return organizationNo;
	}

	public void setOrganizationNo(String organizationNo) {
		this.organizationNo = organizationNo;
	}

	public String getOrganizationPath() {
		return organizationPath;
	}

	public void setOrganizationPath(String organizationPath) {
		this.organizationPath = organizationPath;
	}

	public String getTaxRegistrationNo() {
		return taxRegistrationNo;
	}

	public void setTaxRegistrationNo(String taxRegistrationNo) {
		this.taxRegistrationNo = taxRegistrationNo;
	}

	public String getTaxRegistrationPath() {
		return taxRegistrationPath;
	}

	public void setTaxRegistrationPath(String taxRegistrationPath) {
		this.taxRegistrationPath = taxRegistrationPath;
	}

	public String getCivilAffairsFiling() {
		return civilAffairsFiling;
	}

	public void setCivilAffairsFiling(String civilAffairsFiling) {
		this.civilAffairsFiling = civilAffairsFiling;
	}

	public String getCivilAffairsPath() {
		return civilAffairsPath;
	}

	public void setCivilAffairsPath(String civilAffairsPath) {
		this.civilAffairsPath = civilAffairsPath;
	}

	public String getRadiationDiagnosisNo() {
		return radiationDiagnosisNo;
	}

	public void setRadiationDiagnosisNo(String radiationDiagnosisNo) {
		this.radiationDiagnosisNo = radiationDiagnosisNo;
	}

	public String getRadiationDiagnosisPath() {
		return radiationDiagnosisPath;
	}

	public void setRadiationDiagnosisPath(String radiationDiagnosisPath) {
		this.radiationDiagnosisPath = radiationDiagnosisPath;
	}

	public String getRadiationSaftyNo() {
		return radiationSaftyNo;
	}

	public void setRadiationSaftyNo(String radiationSaftyNo) {
		this.radiationSaftyNo = radiationSaftyNo;
	}

	public String getRadiationSaftyPath() {
		return radiationSaftyPath;
	}

	public void setRadiationSaftyPath(String radiationSaftyPath) {
		this.radiationSaftyPath = radiationSaftyPath;
	}

	public String getLegalRepresentativeNo() {
		return legalRepresentativeNo;
	}

	public void setLegalRepresentativeNo(String legalRepresentativeNo) {
		this.legalRepresentativeNo = legalRepresentativeNo;
	}

	public String getLegalRepresentativeIda() {
		return legalRepresentativeIda;
	}

	public void setLegalRepresentativeIda(String legalRepresentativeIda) {
		this.legalRepresentativeIda = legalRepresentativeIda;
	}

	public String getLegalRepresentativeIdb() {
		return legalRepresentativeIdb;
	}

	public void setLegalRepresentativeIdb(String legalRepresentativeIdb) {
		this.legalRepresentativeIdb = legalRepresentativeIdb;
	}

	public String getAdministratorName() {
		return administratorName;
	}

	public void setAdministratorName(String administratorName) {
		this.administratorName = administratorName;
	}

	public String getAdministratorIda() {
		return administratorIda;
	}

	public void setAdministratorIda(String administratorIda) {
		this.administratorIda = administratorIda;
	}

	public String getAdministratorIdb() {
		return administratorIdb;
	}

	public void setAdministratorIdb(String administratorIdb) {
		this.administratorIdb = administratorIdb;
	}

	public String getClinicPhotoPath() {
		return clinicPhotoPath;
	}

	public void setClinicPhotoPath(String clinicPhotoPath) {
		this.clinicPhotoPath = clinicPhotoPath;
	}

	public String getClinicFacadeName() {
		return clinicFacadeName;
	}

	public void setClinicFacadeName(String clinicFacadeName) {
		this.clinicFacadeName = clinicFacadeName;
	}

	public String getClinicWaitingName() {
		return clinicWaitingName;
	}

	public void setClinicWaitingName(String clinicWaitingName) {
		this.clinicWaitingName = clinicWaitingName;
	}

	public String getClinicMedLabName() {
		return clinicMedLabName;
	}

	public void setClinicMedLabName(String clinicMedLabName) {
		this.clinicMedLabName = clinicMedLabName;
	}

	public String getClinicOtherName() {
		return clinicOtherName;
	}

	public void setClinicOtherName(String clinicOtherName) {
		this.clinicOtherName = clinicOtherName;
	}

	public String getSpecialTechnology() {
		return specialTechnology;
	}

	public void setSpecialTechnology(String specialTechnology) {
		this.specialTechnology = specialTechnology;
	}

	public String getForeignId() {
		return foreignId;
	}

	public void setForeignId(String foreignId) {
		this.foreignId = foreignId;
	}

	public String getForeignType() {
		return foreignType;
	}

	public void setForeignType(String foreignType) {
		this.foreignType = foreignType;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getProvinceCode() {
		return provinceCode;
	}

	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<Hadware> getHadwareList() {
		return hadwareList;
	}

	public void setHadwareList(List<Hadware> hadwareList) {
		this.hadwareList = hadwareList;
	}

	public String getPracticingLicenseF3Path() {
		return practicingLicenseF3Path;
	}

	public void setPracticingLicenseF3Path(String practicingLicenseF3Path) {
		this.practicingLicenseF3Path = practicingLicenseF3Path;
	}
    
}
