package com.wanjia.dsi.sso.service;

import com.wanjia.common.json.JsonResponse;
import com.wanjia.dsi.web.hyPerson.model.CasUser;

/**
 * 二维码扫描登录接口
 * 
 * @author LUOXIAOJUN640
 *
 */
public interface QRCodeService {

	/**
	 * 
	 * 生产登录二维码，并写入输出流
	 * 
	 * @param redisKey
	 *            二维码在redis中的key
	 * @param timeOut
	 *            二维码超时时间
	 * @return
	 */
	JsonResponse<String> generateLoginQRCode(String redisKey, int timeOut);

	/**
	 * 二维码串的key与用户CAS_ID建立关联，并返回用户信息
	 * 
	 * @param redisKey
	 *            二维码在redis中的key
	 * @param casUuid
	 *            登录用户的casUuid
	 * @return
	 */
	JsonResponse<Void> bindCasUser(String redisKey, String casUuid);

	/**
	 * 通过二维码登录
	 * 
	 * @param eventList
	 * @return
	 */
	JsonResponse<CasUser> loginByQRcode(String redisKey);
}
