package com.wanjia.dsi.web.clinic.model;

import java.io.Serializable;

public class Hadware implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;

    private String clinicId;

    private String medicalFacilityName;

    private String medicalFacilityStar;

    private String medicalFacilityNo;

    private String picturePath;

    private String delFlag;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    public String getMedicalFacilityName() {
        return medicalFacilityName;
    }

    public void setMedicalFacilityName(String medicalFacilityName) {
        this.medicalFacilityName = medicalFacilityName;
    }

    public String getMedicalFacilityStar() {
        return medicalFacilityStar;
    }

    public void setMedicalFacilityStar(String medicalFacilityStar) {
        this.medicalFacilityStar = medicalFacilityStar;
    }

    public String getMedicalFacilityNo() {
        return medicalFacilityNo;
    }

    public void setMedicalFacilityNo(String medicalFacilityNo) {
        this.medicalFacilityNo = medicalFacilityNo;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Hadware other = (Hadware) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getClinicId() == null ? other.getClinicId() == null : this.getClinicId().equals(other.getClinicId()))
            && (this.getMedicalFacilityName() == null ? other.getMedicalFacilityName() == null : this.getMedicalFacilityName().equals(other.getMedicalFacilityName()))
            && (this.getMedicalFacilityStar() == null ? other.getMedicalFacilityStar() == null : this.getMedicalFacilityStar().equals(other.getMedicalFacilityStar()))
            && (this.getMedicalFacilityNo() == null ? other.getMedicalFacilityNo() == null : this.getMedicalFacilityNo().equals(other.getMedicalFacilityNo()))
            && (this.getPicturePath() == null ? other.getPicturePath() == null : this.getPicturePath().equals(other.getPicturePath()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getClinicId() == null) ? 0 : getClinicId().hashCode());
        result = prime * result + ((getMedicalFacilityName() == null) ? 0 : getMedicalFacilityName().hashCode());
        result = prime * result + ((getMedicalFacilityStar() == null) ? 0 : getMedicalFacilityStar().hashCode());
        result = prime * result + ((getMedicalFacilityNo() == null) ? 0 : getMedicalFacilityNo().hashCode());
        result = prime * result + ((getPicturePath() == null) ? 0 : getPicturePath().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        return result;
    }
}