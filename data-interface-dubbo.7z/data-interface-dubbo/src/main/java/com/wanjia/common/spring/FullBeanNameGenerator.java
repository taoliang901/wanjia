package com.wanjia.common.spring;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.AnnotationBeanNameGenerator;

import com.wanjia.dsi.web.activity.model.Activity;

public class FullBeanNameGenerator extends AnnotationBeanNameGenerator {

	@Override
	protected String buildDefaultBeanName(BeanDefinition definition) {
		String className = definition.getBeanClassName();
		System.out.println(className);
		return className;
	}

	public static void main(String[] args) {
		Activity model = new Activity();
		System.out.println(model.getClass().getName());
	}
}
